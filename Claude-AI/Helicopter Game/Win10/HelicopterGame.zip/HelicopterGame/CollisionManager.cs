namespace HelicopterGame;

/// <summary>Collision tests between the helicopter and the tunnel walls and barriers.</summary>
public static class CollisionManager
{
    /// <summary>True when any part of the helicopter touches a wall, a barrier or leaves the playing area.</summary>
    public static bool Hits(Helicopter heli, float heliWorldX, TunnelGenerator tunnel)
    {
        foreach (RectangleF shape in Helicopter.Shapes)
        {
            RectangleF r = new RectangleF(heliWorldX + shape.X, heli.Y + shape.Y, shape.Width, shape.Height);

            if (r.Top <= 0f || r.Bottom >= GameConfig.AreaH) return true;

            // walls: sample the boundary along the whole width of the shape (every 4 px, plus the far edge)
            for (float x = r.Left; ; x += 4f)
            {
                float sx = Math.Min(x, r.Right);
                if (tunnel.TopAt(sx) >= r.Top) return true;
                if (tunnel.BottomAt(sx) <= r.Bottom) return true;
                if (sx >= r.Right) break;
            }

            foreach (Barrier b in tunnel.Barriers)
            {
                if (b.Rect.Right < r.Left || b.Rect.Left > r.Right) continue;
                if (b.Rect.IntersectsWith(r)) return true;
            }
        }
        return false;
    }
}
