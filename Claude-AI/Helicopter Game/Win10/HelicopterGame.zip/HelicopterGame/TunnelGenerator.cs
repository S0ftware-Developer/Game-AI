namespace HelicopterGame;

/// <summary>A static rock barrier growing out of the upper or lower wall of the tunnel.</summary>
public sealed class Barrier
{
    public RectangleF Rect;         // world coordinates
    public bool FromTop;
}

/// <summary>
/// Endless procedural tunnel stored as columns (top edge and bottom edge of the corridor). The centre line follows a
/// target that changes from section to section, but its slope is limited and eased, and the corridor height changes
/// slowly, so the geometry never jumps. Difficulty grows with the score.
/// </summary>
public sealed class TunnelGenerator
{
    private readonly List<float> top = new List<float>();
    private readonly List<float> bottom = new List<float>();
    private readonly List<Barrier> barriers = new List<Barrier>();
    private Random rng = new Random();
    private int firstCol;           // world column index of top[0]
    private float center;
    private float slope;            // centre-line change per column
    private float gap;
    private float targetCenter;
    private float targetGap;
    private int sectionLeft;
    private int generated;          // columns generated so far
    private int barrierCol = -1;    // column where the next barrier is planned
    private bool barrierTop;
    private float lastBarrierX = -10000f;

    public IReadOnlyList<Barrier> Barriers { get { return barriers; } }

    public void Reset()
    {
        rng = new Random();
        top.Clear();
        bottom.Clear();
        barriers.Clear();
        firstCol = 0;
        center = GameConfig.AreaH / 2f;
        slope = 0f;
        gap = GameConfig.StartGap;
        targetCenter = center;
        targetGap = gap;
        sectionLeft = GameConfig.WarmupColumns;
        generated = 0;
        barrierCol = -1;
        lastBarrierX = -10000f;
    }

    private float MinCenter(float g) { return GameConfig.WallMargin + g / 2f; }
    private float MaxCenter(float g) { return GameConfig.AreaH - GameConfig.WallMargin - g / 2f; }

    private static float Clamp(float v, float lo, float hi)
    {
        return Math.Max(lo, Math.Min(hi, v));
    }

    /// <summary>Generates columns until the tunnel is defined up to the given world x.</summary>
    public void EnsureCovered(float worldXRight, int score)
    {
        int needed = (int)(worldXRight / GameConfig.ColumnWidth) + 2;
        while (firstCol + top.Count < needed)
        {
            GenerateColumn(score);
        }
    }

    /// <summary>Forgets columns and barriers that are far to the left of the screen.</summary>
    public void Trim(float worldXLeft)
    {
        int keepFrom = (int)(worldXLeft / GameConfig.ColumnWidth) - 2;
        int remove = keepFrom - firstCol;
        if (remove > 0 && remove < top.Count)
        {
            top.RemoveRange(0, remove);
            bottom.RemoveRange(0, remove);
            firstCol += remove;
        }
        for (int i = barriers.Count - 1; i >= 0; i--)
        {
            if (barriers[i].Rect.Right < worldXLeft) barriers.RemoveAt(i);
        }
    }

    private void NewSection(int score)
    {
        float diff = GameConfig.DifficultyAt(score);
        sectionLeft = rng.Next(40, 91);

        // the corridor height: between the base value for this distance and a little wider, never below the minimum
        float baseGap = GameConfig.GapAt(score);
        targetGap = Math.Max(GameConfig.MinGap, baseGap + (float)(rng.NextDouble() * 50.0));

        float swing = 110f + 150f * diff;
        float t = center + (float)((rng.NextDouble() * 2.0 - 1.0) * swing);
        targetCenter = Clamp(t, MinCenter(targetGap), MaxCenter(targetGap));

        // maybe plan one static barrier in the middle of this section
        if (score >= GameConfig.BarrierStartScore && targetGap >= GameConfig.BarrierMinGap && rng.NextDouble() < 0.4)
        {
            barrierCol = firstCol + top.Count + sectionLeft / 2;
            barrierTop = rng.Next(2) == 0;
        }
    }

    private void GenerateColumn(int score)
    {
        if (sectionLeft <= 0) NewSection(score);
        sectionLeft--;

        float diff = GameConfig.DifficultyAt(score);
        float maxSlope = 0.35f + 0.17f * diff;           // steeper tunnels later, but always flyable
        float accel = 0.03f;

        float error = targetCenter - center;
        float desired = Clamp(error * 0.03f, -maxSlope, maxSlope);
        slope += Clamp(desired - slope, -accel, accel);
        center += slope;

        gap += Clamp(targetGap - gap, -0.4f, 0.4f);
        float lo = MinCenter(gap);
        float hi = MaxCenter(gap);
        if (center < lo) { center = lo; if (slope < 0f) slope = 0f; }
        if (center > hi) { center = hi; if (slope > 0f) slope = 0f; }

        float t = center - gap / 2f;
        float b = center + gap / 2f;
        int col = firstCol + top.Count;
        top.Add(t);
        bottom.Add(b);
        generated++;

        if (col == barrierCol)
        {
            float x = col * GameConfig.ColumnWidth;
            if (x - lastBarrierX >= GameConfig.BarrierMinSpacing)
            {
                float h = gap * 0.33f;
                Barrier br = new Barrier();
                br.FromTop = barrierTop;
                if (barrierTop) br.Rect = new RectangleF(x - 22f, t - 40f, 44f, h + 40f);
                else br.Rect = new RectangleF(x - 22f, b - h, 44f, h + 40f);
                barriers.Add(br);
                lastBarrierX = x;
            }
            barrierCol = -1;
        }
    }

    public float TopColumn(int col)
    {
        int i = col - firstCol;
        if (i < 0) i = 0;
        if (i >= top.Count) i = top.Count - 1;
        return top[i];
    }

    public float BottomColumn(int col)
    {
        int i = col - firstCol;
        if (i < 0) i = 0;
        if (i >= bottom.Count) i = bottom.Count - 1;
        return bottom[i];
    }

    /// <summary>Upper boundary (y of the lowest rock point) at a world x, linearly interpolated.</summary>
    public float TopAt(float worldX)
    {
        float f = worldX / GameConfig.ColumnWidth;
        int c = (int)Math.Floor(f);
        float k = f - c;
        return TopColumn(c) * (1f - k) + TopColumn(c + 1) * k;
    }

    public float BottomAt(float worldX)
    {
        float f = worldX / GameConfig.ColumnWidth;
        int c = (int)Math.Floor(f);
        float k = f - c;
        return BottomColumn(c) * (1f - k) + BottomColumn(c + 1) * k;
    }
}
