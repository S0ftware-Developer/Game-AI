namespace HelicopterGame;

public enum GameState { Menu, Playing, Paused, GameOver }

public struct Particle
{
    public float X, Y, VX, VY, Gravity, Size;
    public float Life, MaxLife;
    public int Kind;                 // 0 smoke, 1 spark, 2 debris
    public Color Color;
}

/// <summary>Game rules and the fixed-step simulation (1/120 s): flight, scrolling, scoring, collisions, states.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;

    public GameState State = GameState.Menu;
    public readonly Helicopter Heli = new Helicopter();
    public readonly TunnelGenerator Tunnel = new TunnelGenerator();
    public readonly ScoreManager Scores = new ScoreManager();
    public readonly List<Particle> Particles = new List<Particle>();

    public bool Thrust;                 // held flight input, set by the window
    public float Scroll;                // distance scrolled, in pixels
    public float Speed;
    public int Score;
    public float Clock;                 // keeps running for menu animations
    public bool NewBest;
    public float DeathTimer;

    private readonly Random rng = new Random();
    private float smokeTimer;

    public float HeliWorldX { get { return Scroll + GameConfig.HeliScreenX; } }

    public GameEngine()
    {
        Scores.Load();
        Heli.Reset();
        Tunnel.Reset();
        Tunnel.EnsureCovered(GameConfig.LogicalW + 400f, 0);
        Speed = GameConfig.BaseSpeed;
    }

    // ------------------------------------------------------------------ flow

    public void StartGame()
    {
        Heli.Reset();
        Tunnel.Reset();
        Scroll = 0f;
        Score = 0;
        Speed = GameConfig.BaseSpeed;
        NewBest = false;
        DeathTimer = 0f;
        smokeTimer = 0f;
        Particles.Clear();
        Tunnel.EnsureCovered(GameConfig.LogicalW + 400f, 0);
        State = GameState.Playing;
        Sfx.Play(SfxId.Start);
        Sfx.StartRotor();
    }

    public void Resume()
    {
        if (State != GameState.Paused) return;
        Sfx.Play(SfxId.Click);
        State = GameState.Playing;
        Sfx.StartRotor();
    }

    public void Pause()
    {
        if (State != GameState.Playing) return;
        Thrust = false;
        Sfx.StopRotor();
        Sfx.Play(SfxId.Click);
        State = GameState.Paused;
    }

    public void GoToMenu()
    {
        Thrust = false;
        Sfx.StopRotor();
        Sfx.Play(SfxId.Click);
        State = GameState.Menu;
    }

    public void AutoPause()
    {
        Thrust = false;
        if (State == GameState.Playing)
        {
            Sfx.StopRotor();
            State = GameState.Paused;
        }
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                if (State == GameState.Menu || State == GameState.GameOver) StartGame();
                else if (State == GameState.Paused) Resume();
                break;
            case Keys.Space:
                if (State == GameState.Menu) StartGame();
                break;
            case Keys.Escape:
            case Keys.P:
                if (State == GameState.Playing) Pause();
                else if (State == GameState.Paused) Resume();
                else if (State == GameState.GameOver && key == Keys.Escape) GoToMenu();
                break;
            case Keys.R:
                if (State == GameState.Playing || State == GameState.Paused || State == GameState.GameOver) StartGame();
                break;
            case Keys.M:
                if (State == GameState.Paused || State == GameState.GameOver) GoToMenu();
                break;
            case Keys.N:
                Sfx.SetMuted(!Sfx.Muted);
                if (!Sfx.Muted && State == GameState.Playing) Sfx.StartRotor();
                break;
        }
    }

    // ------------------------------------------------------------------ simulation

    public void Update()
    {
        Clock += Dt;
        if (State == GameState.Menu || State == GameState.Paused) return;

        if (State == GameState.GameOver)
        {
            UpdateParticles(Dt);
            return;
        }

        if (!Heli.Dead) UpdateFlight(Dt);
        else UpdateCrash(Dt);
        UpdateParticles(Dt);
    }

    private void UpdateFlight(float dt)
    {
        Speed = GameConfig.SpeedAt(Score);
        Scroll += Speed * dt;
        Score = (int)(Scroll / GameConfig.PixelsPerPoint);

        Heli.Update(Thrust, dt);
        Tunnel.EnsureCovered(Scroll + GameConfig.LogicalW + 300f, Score);
        Tunnel.Trim(Scroll - 300f);

        if (CollisionManager.Hits(Heli, HeliWorldX, Tunnel))
        {
            Crash();
            return;
        }

        smokeTimer -= dt;
        if (smokeTimer <= 0f)
        {
            smokeTimer = 0.05f;
            Particle p = new Particle();
            p.X = HeliWorldX - 56f;
            p.Y = Heli.Y - 4f;
            p.VX = -30f - (float)(rng.NextDouble() * 30.0);
            p.VY = -8f + (float)(rng.NextDouble() * 16.0);
            p.Gravity = -10f;
            p.Size = 3f + (float)rng.NextDouble() * 3f;
            p.MaxLife = 0.5f;
            p.Life = p.MaxLife;
            p.Kind = 0;
            p.Color = Color.FromArgb(215, 225, 240);
            Particles.Add(p);
        }
    }

    private void Crash()
    {
        Heli.Dead = true;
        Heli.DeadTime = 0f;
        DeathTimer = 0f;
        Thrust = false;
        Sfx.StopRotor();
        Sfx.Play(SfxId.Crash);
        float cx = HeliWorldX;
        for (int i = 0; i < 30; i++) Spark(cx, Heli.Y, (i % 2 == 0) ? Color.FromArgb(255, 200, 60) : Color.FromArgb(255, 100, 30), 300f);
        for (int i = 0; i < 12; i++) Debris(cx, Heli.Y);
    }

    private void UpdateCrash(float dt)
    {
        DeathTimer += dt;
        Speed = Math.Max(0f, Speed - Speed * 3.5f * dt);
        Scroll += Speed * dt;
        Heli.UpdateDead(dt);
        if (DeathTimer >= 1.0f) EndGame();
    }

    private void EndGame()
    {
        NewBest = Score > Scores.Best;
        if (NewBest)
        {
            Scores.Best = Score;
            Scores.Save();
        }
        State = GameState.GameOver;
    }

    // ------------------------------------------------------------------ effects

    private void Spark(float x, float y, Color c, float speed)
    {
        double a = rng.NextDouble() * Math.PI * 2.0;
        float sp = (float)(rng.NextDouble() * 0.8 + 0.2) * speed;
        Particle p = new Particle();
        p.X = x;
        p.Y = y;
        p.VX = (float)Math.Cos(a) * sp;
        p.VY = (float)Math.Sin(a) * sp;
        p.Gravity = 300f;
        p.Size = 2f + (float)rng.NextDouble() * 3f;
        p.MaxLife = 0.35f + (float)rng.NextDouble() * 0.4f;
        p.Life = p.MaxLife;
        p.Kind = 1;
        p.Color = c;
        Particles.Add(p);
    }

    private void Debris(float x, float y)
    {
        double a = rng.NextDouble() * Math.PI * 2.0;
        float sp = (float)(rng.NextDouble() * 220.0 + 60.0);
        Particle p = new Particle();
        p.X = x;
        p.Y = y;
        p.VX = (float)Math.Cos(a) * sp;
        p.VY = (float)Math.Sin(a) * sp - 120f;
        p.Gravity = 700f;
        p.Size = 4f + (float)rng.NextDouble() * 5f;
        p.MaxLife = 0.8f + (float)rng.NextDouble() * 0.5f;
        p.Life = p.MaxLife;
        p.Kind = 2;
        p.Color = (rng.Next(2) == 0) ? Color.FromArgb(215, 50, 45) : Color.FromArgb(60, 66, 90);
        Particles.Add(p);
    }

    private void UpdateParticles(float dt)
    {
        for (int i = Particles.Count - 1; i >= 0; i--)
        {
            Particle p = Particles[i];
            p.Life -= dt;
            if (p.Life <= 0f)
            {
                Particles.RemoveAt(i);
                continue;
            }
            p.VY += p.Gravity * dt;
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            Particles[i] = p;
        }
    }
}
