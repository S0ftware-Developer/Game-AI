namespace HelicopterGame;

/// <summary>The helicopter: vertical velocity and position with acceleration, gravity and speed limits.</summary>
public sealed class Helicopter
{
    public float Y;                 // centre of the helicopter on screen
    public float VY;
    public float Thrust;            // 0..1, how strongly the rotor is lifting
    public bool Dead;
    public float DeadTime;
    public float RotorAngle;
    public float TailAngle;

    public void Reset()
    {
        Y = GameConfig.AreaH / 2f;
        VY = 0f;
        Thrust = 0f;
        Dead = false;
        DeadTime = 0f;
        RotorAngle = 0f;
        TailAngle = 0f;
    }

    /// <summary>One fixed step of flight. Holding the control accelerates upward, releasing it lets gravity win.</summary>
    public void Update(bool held, float dt)
    {
        if (held) Thrust = Math.Min(1f, Thrust + dt / GameConfig.ThrustRampTime);
        else Thrust = 0f;

        float ay = GameConfig.Gravity - GameConfig.ThrustAccel * Thrust;
        VY += ay * dt;
        if (VY < -GameConfig.MaxUpSpeed) VY = -GameConfig.MaxUpSpeed;
        if (VY > GameConfig.MaxDownSpeed) VY = GameConfig.MaxDownSpeed;
        Y += VY * dt;

        RotorAngle += dt * (28f + 10f * Thrust);
        TailAngle += dt * 46f;
    }

    /// <summary>After a crash the helicopter just falls and spins.</summary>
    public void UpdateDead(float dt)
    {
        DeadTime += dt;
        Thrust = 0f;
        VY = Math.Min(GameConfig.MaxDownSpeed, VY + GameConfig.Gravity * dt);
        Y += VY * dt;
        RotorAngle += dt * 8f;
        TailAngle += dt * 8f;
    }

    /// <summary>Pitch for drawing: nose up when climbing, nose down when falling (degrees).</summary>
    public float Tilt
    {
        get { return Math.Max(-1f, Math.Min(1f, VY / GameConfig.MaxDownSpeed)) * 10f; }
    }

    /// <summary>
    /// Collision shapes relative to the helicopter centre: the body, the tail boom and the rotor mast.
    /// They are a bit smaller than the picture so that touches feel fair.
    /// </summary>
    public static readonly RectangleF[] Shapes =
    {
        new RectangleF(-26f, -11f, 54f, 24f),     // fuselage and cockpit
        new RectangleF(-62f, -9f, 38f, 8f),       // tail boom
        new RectangleF(-12f, -22f, 22f, 12f)      // rotor mast and hub
    };
}
