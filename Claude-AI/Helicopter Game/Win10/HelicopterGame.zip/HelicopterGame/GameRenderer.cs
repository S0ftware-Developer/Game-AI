using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace HelicopterGame;

/// <summary>
/// GDI+ renderer in logical 960x640 coordinates scaled to the window. The sky, clouds and mountains are pre-rendered
/// once and scrolled at different speeds; the tunnel, barriers, helicopter, particles and interface are drawn live.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    public static readonly Rectangle PlayButton = new Rectangle(330, 478, 300, 54);
    public static readonly Rectangle ResumeButton = new Rectangle(360, 262, 240, 46);
    public static readonly Rectangle PauseRestartButton = new Rectangle(360, 318, 240, 46);
    public static readonly Rectangle PauseMenuButton = new Rectangle(360, 374, 240, 46);
    public static readonly Rectangle OverRestartButton = new Rectangle(255, 412, 210, 52);
    public static readonly Rectangle OverMenuButton = new Rectangle(495, 412, 210, 52);

    private const int W = GameConfig.LogicalW;
    private const int AreaH = GameConfig.AreaH;
    private const float ColW = GameConfig.ColumnWidth;

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fHud;
    private readonly Font fLabel;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fBig;
    private readonly Font fFooter;
    private readonly Font fTitle;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;
    private readonly StringFormat sfRight;
    private readonly Bitmap skyBmp;
    private readonly Bitmap cloudBmp;
    private readonly Bitmap farBmp;
    private readonly Bitmap nearBmp;
    private readonly LinearGradientBrush wallTopBrush;
    private readonly LinearGradientBrush wallBottomBrush;
    private readonly GraphicsPath titlePath1;
    private readonly GraphicsPath titlePath2;
    private readonly LinearGradientBrush titleFill1;
    private readonly LinearGradientBrush titleFill2;
    private readonly PointF[] poly = new PointF[8];

    public GameRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;

        fHud = new Font("Segoe UI", 30f, FontStyle.Bold, GraphicsUnit.Pixel);
        fLabel = new Font("Segoe UI", 12f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Segoe UI", 26f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Segoe UI", 18f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBig = new Font("Segoe UI", 54f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitle = new Font("Impact", 100f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;
        sfRight = new StringFormat();
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfRight.FormatFlags = StringFormatFlags.NoWrap;

        skyBmp = MakeSky();
        cloudBmp = MakeClouds();
        farBmp = MakeMountains(1280, 250, 340, Color.FromArgb(150, 126, 168, 222), false, 3);
        nearBmp = MakeMountains(1280, 330, 200, Color.FromArgb(235, 70, 118, 176), true, 8);

        wallTopBrush = new LinearGradientBrush(new Rectangle(0, 0, 10, AreaH), Color.FromArgb(22, 28, 54), Color.FromArgb(56, 66, 104), 90f);
        wallBottomBrush = new LinearGradientBrush(new Rectangle(0, 0, 10, AreaH), Color.FromArgb(56, 66, 104), Color.FromArgb(18, 24, 46), 90f);

        titlePath1 = MakeTitlePath("HELICOPTER", 100f, 480f, 108f);
        titlePath2 = MakeTitlePath("GAME", 84f, 480f, 196f);
        titleFill1 = new LinearGradientBrush(new RectangleF(0f, 60f, 10f, 100f), Color.FromArgb(255, 240, 70), Color.FromArgb(255, 140, 20), 90f);
        titleFill2 = new LinearGradientBrush(new RectangleF(0f, 160f, 10f, 80f), Color.FromArgb(255, 255, 255), Color.FromArgb(150, 175, 225), 90f);
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fHud.Dispose();
        fLabel.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fBig.Dispose();
        fFooter.Dispose();
        fTitle.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        sfRight.Dispose();
        skyBmp.Dispose();
        cloudBmp.Dispose();
        farBmp.Dispose();
        nearBmp.Dispose();
        wallTopBrush.Dispose();
        wallBottomBrush.Dispose();
        titlePath1.Dispose();
        titlePath2.Dispose();
        titleFill1.Dispose();
        titleFill2.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private static int Hash(int c)
    {
        unchecked
        {
            int h = c * 374761393;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow) g.DrawString(s, f, B(Color.FromArgb(Math.Min((int)c.A, 190), 6, 10, 28)), x + 2f, y + 2f, sf);
        g.DrawString(s, f, B(c), x, y, sf);
    }

    private static GraphicsPath RoundRect(float x, float y, float w, float h, float r)
    {
        GraphicsPath p = new GraphicsPath();
        float d = r * 2f;
        p.AddArc(x, y, d, d, 180f, 90f);
        p.AddArc(x + w - d, y, d, d, 270f, 90f);
        p.AddArc(x + w - d, y + h - d, d, d, 0f, 90f);
        p.AddArc(x, y + h - d, d, d, 90f, 90f);
        p.CloseFigure();
        return p;
    }

    private void Panel(Graphics g, float x, float y, float w, float h, int alpha)
    {
        using (GraphicsPath p = RoundRect(x, y, w, h, 10f))
        {
            g.FillPath(B(Color.FromArgb(alpha, 12, 20, 48)), p);
            g.DrawPath(P(Color.FromArgb(255, 70, 110, 190), 2f), p);
        }
    }

    private void Button(Graphics g, Rectangle r, string text, Color fill, bool glow, float clock)
    {
        using (GraphicsPath p = RoundRect(r.X, r.Y, r.Width, r.Height, 10f))
        {
            g.FillPath(B(fill), p);
            float k = glow ? 0.5f + 0.5f * MathF.Sin(clock * 4f) : 1f;
            g.DrawPath(P(Color.FromArgb(A(180 + 75 * k), 255, 255, 255), 3f), p);
        }
        Txt(g, text, fText, Color.White, r.X + r.Width / 2f, r.Y + r.Height / 2f, sfCenter, true);
    }

    private void DrawLayer(Graphics g, Bitmap bmp, double offset)
    {
        int w = bmp.Width;
        float x = -(float)(((offset % w) + w) % w);
        while (x < W)
        {
            g.DrawImageUnscaled(bmp, (int)x, 0);
            x += w;
        }
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)GameConfig.LogicalW, clientH / (float)GameConfig.LogicalH);
        float offX = (clientW - GameConfig.LogicalW * scale) / 2f;
        float offY = (clientH - GameConfig.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, GameConfig.LogicalW, GameConfig.LogicalH));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (e.State == GameState.Menu) DrawMenu(g, e);
            else
            {
                DrawGame(g, e);
                if (e.State == GameState.Paused) DrawPause(g, e);
                else if (e.State == GameState.GameOver) DrawGameOver(g, e);
            }
            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ game screen

    private void DrawBackground(Graphics g, double scroll)
    {
        g.DrawImageUnscaled(skyBmp, 0, 0);
        DrawLayer(g, cloudBmp, scroll * 0.04);
        DrawLayer(g, farBmp, scroll * 0.09);
        DrawLayer(g, nearBmp, scroll * 0.22);
    }

    private void DrawGame(Graphics g, GameEngine e)
    {
        float scroll = e.Scroll;
        DrawBackground(g, scroll);
        DrawTunnel(g, e);

        foreach (Particle p in e.Particles)
        {
            float k = p.Life / p.MaxLife;
            float px = p.X - scroll;
            if (px < -20f || px > W + 20f) continue;
            if (p.Kind == 0)
            {
                float r = p.Size * (1.7f - k);
                g.FillEllipse(B(Color.FromArgb(A(170 * k), p.Color.R, p.Color.G, p.Color.B)), px - r, p.Y - r, r * 2f, r * 2f);
            }
            else
            {
                g.FillRectangle(B(Color.FromArgb(A(255 * k), p.Color.R, p.Color.G, p.Color.B)), px - p.Size / 2f, p.Y - p.Size / 2f, p.Size, p.Size);
            }
        }

        if (!(e.Heli.Dead && e.Heli.DeadTime > 0.45f))
        {
            float tilt = e.Heli.Dead ? e.Heli.DeadTime * 420f : e.Heli.Tilt;
            DrawHeli(g, GameConfig.HeliScreenX, e.Heli.Y, tilt, e.Heli.RotorAngle, e.Heli.TailAngle, 1f);
        }

        DrawHud(g, e);
        if (e.Heli.Dead && e.Heli.DeadTime < 0.2f)
        {
            g.FillRectangle(B(Color.FromArgb(A(170 * (1f - e.Heli.DeadTime / 0.2f)), 255, 255, 255)), 0, 0, W, AreaH);
        }
    }

    private void DrawHud(Graphics g, GameEngine e)
    {
        Panel(g, 16f, 12f, 210f, 70f, 190);
        Txt(g, "СЧЁТ", fLabel, Color.FromArgb(255, 150, 185, 235), 32f, 26f, sfLeft, false);
        Txt(g, e.Score.ToString(), fHud, Color.White, 32f, 54f, sfLeft, true);

        Panel(g, W - 226f, 12f, 210f, 70f, 190);
        Txt(g, "РЕКОРД", fLabel, Color.FromArgb(255, 150, 185, 235), W - 32f, 26f, sfRight, false);
        Txt(g, Math.Max(e.Scores.Best, e.Score).ToString(), fHud, Color.FromArgb(255, 255, 220, 70), W - 32f, 54f, sfRight, true);
    }

    private void DrawTunnel(Graphics g, GameEngine e)
    {
        float scroll = e.Scroll;
        int c0 = (int)Math.Floor(scroll / ColW) - 1;
        int c1 = (int)Math.Floor((scroll + W) / ColW) + 2;
        int n = c1 - c0 + 1;
        PointF[] topLine = new PointF[n];
        PointF[] botLine = new PointF[n];
        for (int i = 0; i < n; i++)
        {
            int col = c0 + i;
            float x = col * ColW - scroll;
            topLine[i] = new PointF(x, e.Tunnel.TopColumn(col));
            botLine[i] = new PointF(x, e.Tunnel.BottomColumn(col));
        }
        PointF[] topPoly = new PointF[n + 2];
        PointF[] botPoly = new PointF[n + 2];
        Array.Copy(topLine, topPoly, n);
        Array.Copy(botLine, botPoly, n);
        topPoly[n] = new PointF(topLine[n - 1].X, -30f);
        topPoly[n + 1] = new PointF(topLine[0].X, -30f);
        botPoly[n] = new PointF(botLine[n - 1].X, AreaH + 30f);
        botPoly[n + 1] = new PointF(botLine[0].X, AreaH + 30f);
        DrawWalls(g, topLine, botLine, topPoly, botPoly, c0);

        foreach (Barrier b in e.Tunnel.Barriers)
        {
            float x = b.Rect.X - scroll;
            if (x > W + 40f || x + b.Rect.Width < -40f) continue;
            RectangleF r = new RectangleF(x, b.Rect.Y, b.Rect.Width, b.Rect.Height);
            float mx = r.X + r.Width / 2f;
            if (b.FromTop)
            {
                poly[0] = new PointF(r.Left, r.Top);
                poly[1] = new PointF(r.Right, r.Top);
                poly[2] = new PointF(r.Right - 7f, r.Bottom - 12f);
                poly[3] = new PointF(mx, r.Bottom);
                poly[4] = new PointF(r.Left + 7f, r.Bottom - 12f);
            }
            else
            {
                poly[0] = new PointF(r.Left, r.Bottom);
                poly[1] = new PointF(r.Right, r.Bottom);
                poly[2] = new PointF(r.Right - 7f, r.Top + 12f);
                poly[3] = new PointF(mx, r.Top);
                poly[4] = new PointF(r.Left + 7f, r.Top + 12f);
            }
            PointF[] rock = new PointF[5];
            Array.Copy(poly, rock, 5);
            g.FillPolygon(B(Color.FromArgb(255, 54, 62, 98)), rock);
            g.DrawLines(P(Color.FromArgb(255, 14, 18, 36), 6f), new PointF[] { rock[4], rock[3], rock[2] });
            g.DrawLines(P(Color.FromArgb(255, 222, 190, 110), 3f), new PointF[] { rock[4], rock[3], rock[2] });
            g.DrawLine(P(Color.FromArgb(90, 8, 10, 24), 2f), mx - 4f, b.FromTop ? r.Top + 20f : r.Bottom - 20f, mx + 5f, b.FromTop ? r.Bottom - 16f : r.Top + 16f);
        }
    }

    private void DrawWalls(Graphics g, PointF[] topLine, PointF[] botLine, PointF[] topPoly, PointF[] botPoly, int c0)
    {
        g.FillPolygon(wallTopBrush, topPoly);
        g.FillPolygon(wallBottomBrush, botPoly);

        // cracks in the rock
        for (int i = 0; i < topLine.Length; i++)
        {
            int h = Hash(c0 + i);
            if (h % 5 != 0) continue;
            float dx = (h % 17) - 8f;
            float depth = 22f + (h % 40);
            g.DrawLine(P(Color.FromArgb(70, 6, 8, 22), 2f), topLine[i].X, topLine[i].Y, topLine[i].X + dx, topLine[i].Y - depth);
            h = Hash(c0 + i + 7777);
            if (h % 4 == 0)
            {
                dx = (h % 15) - 7f;
                depth = 22f + (h % 44);
                g.DrawLine(P(Color.FromArgb(70, 6, 8, 22), 2f), botLine[i].X, botLine[i].Y, botLine[i].X + dx, botLine[i].Y + depth);
            }
        }

        // rims: a dark outline with a sandy edge on top, like a rock face
        g.DrawLines(P(Color.FromArgb(255, 12, 16, 34), 9f), topLine);
        g.DrawLines(P(Color.FromArgb(255, 12, 16, 34), 9f), botLine);
        g.DrawLines(P(Color.FromArgb(255, 222, 190, 110), 3.5f), topLine);
        g.DrawLines(P(Color.FromArgb(255, 222, 190, 110), 3.5f), botLine);

        // grass and moss
        for (int i = 0; i < botLine.Length; i++)
        {
            int h = Hash(c0 + i + 31);
            if (h % 9 == 0)
            {
                float x = botLine[i].X;
                float y = botLine[i].Y;
                poly[0] = new PointF(x - 9f, y);
                poly[1] = new PointF(x - 4f, y - 11f);
                poly[2] = new PointF(x, y - 4f);
                poly[3] = new PointF(x + 4f, y - 13f);
                poly[4] = new PointF(x + 10f, y);
                PointF[] tuft = new PointF[5];
                Array.Copy(poly, tuft, 5);
                g.FillPolygon(B(Color.FromArgb(255, 96, 176, 60)), tuft);
            }
            h = Hash(c0 + i + 97);
            if (h % 11 == 0)
            {
                g.FillEllipse(B(Color.FromArgb(255, 96, 176, 60)), topLine[i].X - 7f, topLine[i].Y - 2f, 14f, 8f);
            }
        }
    }

    // ------------------------------------------------------------------ helicopter

    private void DrawHeli(Graphics g, float cx, float cy, float tilt, float rotor, float tail, float scale)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(cx, cy);
        g.RotateTransform(tilt);
        g.ScaleTransform(scale, scale);

        // tail boom and fin
        PointF[] boom = { new PointF(-24f, -8f), new PointF(-66f, -7f), new PointF(-66f, -1f), new PointF(-24f, 6f) };
        g.FillPolygon(B(Color.FromArgb(255, 184, 36, 38)), boom);
        g.DrawPolygon(P(Color.FromArgb(255, 60, 14, 20), 2f), boom);
        PointF[] fin = { new PointF(-66f, -7f), new PointF(-78f, -24f), new PointF(-64f, -24f), new PointF(-54f, -7f) };
        g.FillPolygon(B(Color.FromArgb(255, 214, 48, 44)), fin);
        g.DrawPolygon(P(Color.FromArgb(255, 60, 14, 20), 2f), fin);

        // tail rotor
        float tx = -72f;
        float ty = -14f;
        float ta = tail;
        g.FillEllipse(B(Color.FromArgb(50, 40, 50, 70)), tx - 9f, ty - 9f, 18f, 18f);
        g.DrawLine(P(Color.FromArgb(255, 30, 36, 60), 2.5f), tx + MathF.Cos(ta) * 9f, ty + MathF.Sin(ta) * 9f, tx - MathF.Cos(ta) * 9f, ty - MathF.Sin(ta) * 9f);
        g.DrawLine(P(Color.FromArgb(255, 30, 36, 60), 2.5f), tx + MathF.Cos(ta + 1.57f) * 9f, ty + MathF.Sin(ta + 1.57f) * 9f, tx - MathF.Cos(ta + 1.57f) * 9f, ty - MathF.Sin(ta + 1.57f) * 9f);
        g.FillEllipse(B(Color.FromArgb(255, 200, 205, 220)), tx - 2.5f, ty - 2.5f, 5f, 5f);

        // skids
        g.DrawLine(P(Color.FromArgb(255, 28, 34, 58), 3.5f), -28f, 27f, 34f, 27f);
        g.DrawLine(P(Color.FromArgb(255, 28, 34, 58), 3.5f), 34f, 27f, 40f, 22f);
        g.DrawLine(P(Color.FromArgb(255, 28, 34, 58), 3f), -14f, 15f, -16f, 27f);
        g.DrawLine(P(Color.FromArgb(255, 28, 34, 58), 3f), 14f, 15f, 16f, 27f);

        // fuselage
        g.FillEllipse(B(Color.FromArgb(255, 214, 48, 44)), -30f, -15f, 66f, 36f);
        g.FillEllipse(B(Color.FromArgb(255, 160, 30, 34)), -26f, 8f, 58f, 12f);
        g.FillEllipse(B(Color.FromArgb(255, 250, 250, 252)), -22f, 1f, 46f, 6f);
        g.DrawEllipse(P(Color.FromArgb(255, 60, 14, 20), 2.5f), -30f, -15f, 66f, 36f);

        // cockpit glass
        g.FillEllipse(B(Color.FromArgb(255, 36, 64, 122)), 6f, -11f, 28f, 22f);
        g.FillEllipse(B(Color.FromArgb(200, 150, 205, 250)), 11f, -8f, 11f, 7f);
        g.DrawEllipse(P(Color.FromArgb(255, 20, 30, 70), 2f), 6f, -11f, 28f, 22f);

        // rotor mast and main rotor (a flat view: the blade length follows the rotation angle)
        g.FillRectangle(B(Color.FromArgb(255, 40, 46, 70)), -7f, -24f, 8f, 10f);
        float hx = -3f;
        float hy = -26f;
        g.FillEllipse(B(Color.FromArgb(40, 30, 40, 70)), hx - 66f, hy - 4f, 132f, 8f);
        float l1 = 64f * MathF.Cos(rotor);
        float l2 = 64f * MathF.Sin(rotor);
        g.DrawLine(P(Color.FromArgb(235, 28, 34, 58), 4.5f), hx - l1, hy, hx + l1, hy);
        g.DrawLine(P(Color.FromArgb(190, 28, 34, 58), 3.5f), hx - l2, hy, hx + l2, hy);
        g.FillEllipse(B(Color.FromArgb(255, 210, 214, 228)), hx - 4f, hy - 4f, 8f, 8f);

        g.Restore(st);
    }

    // ------------------------------------------------------------------ menu and overlays

    private void DrawMenu(Graphics g, GameEngine e)
    {
        float clock = e.Clock;
        DrawBackground(g, clock * 70.0);

        // a decorative tunnel
        int n = W / 8 + 3;
        PointF[] top = new PointF[n];
        PointF[] bot = new PointF[n];
        for (int i = 0; i < n; i++)
        {
            float x = i * 8f - 8f;
            float t = clock * 70f;
            float ty = 150f + 34f * MathF.Sin((x + t) * 0.011f) + 20f * MathF.Sin((x + t) * 0.027f) + 55f * MathF.Max(0f, MathF.Sin((x + t) * 0.018f + 1.3f));
            float by = 505f - 30f * MathF.Sin((x + t) * 0.008f + 2f) - 22f * MathF.Max(0f, MathF.Sin((x + t) * 0.021f)) + 38f * MathF.Sin((x + t) * 0.03f);
            top[i] = new PointF(x, ty);
            bot[i] = new PointF(x, by);
        }
        PointF[] topPoly = new PointF[n + 2];
        PointF[] botPoly = new PointF[n + 2];
        Array.Copy(top, topPoly, n);
        Array.Copy(bot, botPoly, n);
        topPoly[n] = new PointF(top[n - 1].X, -30f);
        topPoly[n + 1] = new PointF(top[0].X, -30f);
        botPoly[n] = new PointF(bot[n - 1].X, AreaH + 30f);
        botPoly[n + 1] = new PointF(bot[0].X, AreaH + 30f);
        DrawWalls(g, top, bot, topPoly, botPoly, (int)(clock * 70f / 8f));

        // helicopter with a speed trail
        float bob = MathF.Sin(clock * 2.2f) * 10f;
        for (int i = 0; i < 4; i++)
        {
            g.DrawLine(P(Color.FromArgb(150 - i * 30, 255, 255, 255), 2.5f), 150f - i * 6f, 330f + bob + i * 9f, 40f - i * 16f, 345f + bob + i * 11f);
        }
        DrawHeli(g, 300f, 330f + bob, 4f, clock * 30f, clock * 46f, 1.5f);

        // title with wings
        PointF[] wing = { new PointF(232f, 118f), new PointF(372f, 90f), new PointF(372f, 118f), new PointF(334f, 130f), new PointF(300f, 160f), new PointF(262f, 142f) };
        g.FillPolygon(B(Color.FromArgb(255, 255, 170, 30)), wing);
        g.DrawPolygon(P(Color.FromArgb(255, 20, 30, 70), 4f), wing);
        PointF[] wing2 = new PointF[wing.Length];
        for (int i = 0; i < wing.Length; i++) wing2[i] = new PointF(W - wing[i].X, wing[i].Y);
        g.FillPolygon(B(Color.FromArgb(255, 255, 170, 30)), wing2);
        g.DrawPolygon(P(Color.FromArgb(255, 20, 30, 70), 4f), wing2);
        g.DrawPath(P(Color.FromArgb(255, 20, 30, 70), 14f), titlePath1);
        g.FillPath(titleFill1, titlePath1);
        g.DrawPath(P(Color.FromArgb(255, 20, 30, 70), 12f), titlePath2);
        g.FillPath(titleFill2, titlePath2);

        // control hints
        Panel(g, 742f, 228f, 206f, 118f, 215);
        PointF[] up = { new PointF(768f, 246f), new PointF(780f, 262f), new PointF(773f, 262f), new PointF(773f, 280f), new PointF(763f, 280f), new PointF(763f, 262f), new PointF(756f, 262f) };
        g.FillPolygon(B(Color.White), up);
        Txt(g, "ЗАЖАТЬ —", fLabel, Color.White, 792f, 254f, sfLeft, false);
        Txt(g, "ВВЕРХ", fLabel, Color.White, 792f, 270f, sfLeft, false);
        PointF[] down = { new PointF(768f, 318f), new PointF(780f, 302f), new PointF(773f, 302f), new PointF(773f, 284f), new PointF(763f, 284f), new PointF(763f, 302f), new PointF(756f, 302f) };
        g.FillPolygon(B(Color.White), down);
        Txt(g, "ОТПУСТИТЬ —", fLabel, Color.White, 792f, 296f, sfLeft, false);
        Txt(g, "ВНИЗ", fLabel, Color.White, 792f, 312f, sfLeft, false);
        Txt(g, "Пробел / левая кнопка мыши", fLabel, Color.FromArgb(255, 160, 195, 240), 845f, 336f, sfCenter, false);

        Button(g, PlayButton, "ИГРАТЬ  [ENTER]", Color.FromArgb(255, 16, 28, 66), true, clock);
        Txt(g, "РЕКОРД: " + e.Scores.Best, fText, Color.FromArgb(255, 255, 220, 70), W / 2f, 560f, sfCenter, true);
        Txt(g, "Esc / P — пауза     R — заново     N — звук     F11 — полный экран", fSmall, Color.FromArgb(255, 235, 242, 255), W / 2f, 584f, sfCenter, true);
    }

    private void DrawPause(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(165, 4, 8, 22)), 0, 0, W, AreaH);
        Txt(g, "ПАУЗА", fBig, Color.White, W / 2f, 205f, sfCenter, true);
        Button(g, ResumeButton, "ПРОДОЛЖИТЬ [ESC]", Color.FromArgb(255, 30, 110, 60), false, e.Clock);
        Button(g, PauseRestartButton, "ЗАНОВО [R]", Color.FromArgb(255, 50, 70, 130), false, e.Clock);
        Button(g, PauseMenuButton, "В МЕНЮ [M]", Color.FromArgb(255, 50, 70, 130), false, e.Clock);
    }

    private void DrawGameOver(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(175, 4, 8, 22)), 0, 0, W, AreaH);
        Panel(g, 230f, 110f, 500f, 380f, 240);
        Txt(g, "GAME OVER", fBig, Color.FromArgb(255, 255, 90, 80), W / 2f, 170f, sfCenter, true);
        if (e.NewBest) Txt(g, "НОВЫЙ РЕКОРД!", fMid, Color.FromArgb(255, 255, 220, 70), W / 2f, 222f, sfCenter, true);
        Txt(g, "СЧЁТ", fLabel, Color.FromArgb(255, 150, 185, 235), W / 2f, 262f, sfCenter, false);
        Txt(g, e.Score.ToString(), fBig, Color.White, W / 2f, 300f, sfCenter, true);
        Txt(g, "РЕКОРД: " + e.Scores.Best, fText, Color.FromArgb(255, 255, 220, 70), W / 2f, 360f, sfCenter, true);
        Button(g, OverRestartButton, "ЗАНОВО [R]", Color.FromArgb(255, 30, 110, 60), true, e.Clock);
        Button(g, OverMenuButton, "В МЕНЮ [M]", Color.FromArgb(255, 50, 70, 130), false, e.Clock);
    }

    private void DrawFooter(Graphics g)
    {
        Rectangle r = new Rectangle(0, GameConfig.LogicalH - GameConfig.FooterH, W, GameConfig.FooterH);
        g.FillRectangle(B(Color.FromArgb(255, 8, 12, 30)), r);
        g.FillRectangle(B(Color.FromArgb(255, 255, 190, 40)), 0, r.Y, W, 2);
        g.DrawString(FooterText, fFooter, B(Color.FromArgb(255, 225, 234, 252)),
            new RectangleF(0f, r.Y + 3f, W, r.Height - 3f), sfCenter);
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private GraphicsPath MakeTitlePath(string text, float size, float cx, float cy)
    {
        GraphicsPath path = new GraphicsPath();
        path.AddString(text, fTitle.FontFamily, (int)FontStyle.Regular, size, new PointF(0f, 0f), StringFormat.GenericTypographic);
        RectangleF b = path.GetBounds();
        using (Matrix m = new Matrix())
        {
            m.Translate(cx - (b.X + b.Width / 2f), cy - (b.Y + b.Height / 2f));
            path.Transform(m);
        }
        return path;
    }

    private static Bitmap MakeSky()
    {
        Bitmap bmp = new Bitmap(W, AreaH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush sky = new LinearGradientBrush(new Rectangle(0, 0, W, AreaH), Color.FromArgb(58, 150, 232), Color.FromArgb(196, 232, 252), 90f))
            {
                g.FillRectangle(sky, 0, 0, W, AreaH);
            }
            using (SolidBrush glow = new SolidBrush(Color.FromArgb(22, 255, 255, 240)))
            {
                for (int i = 5; i >= 1; i--)
                {
                    float r = 46f + i * 22f;
                    g.FillEllipse(glow, 700f - r, 340f - r, r * 2f, r * 2f);
                }
            }
            using (SolidBrush sun = new SolidBrush(Color.FromArgb(255, 255, 255, 240)))
            {
                g.FillEllipse(sun, 700f - 46f, 340f - 46f, 92f, 92f);
            }
        }
        return bmp;
    }

    private static Bitmap MakeClouds()
    {
        int cw = 1920;
        Bitmap bmp = new Bitmap(cw, AreaH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(11);
            using (SolidBrush cloud = new SolidBrush(Color.FromArgb(185, 255, 255, 255)))
            using (SolidBrush shade = new SolidBrush(Color.FromArgb(70, 170, 200, 235)))
            {
                for (int i = 0; i < 11; i++)
                {
                    float x = rnd.Next(cw - 200);
                    float y = 120 + rnd.Next(240);
                    float s = 0.7f + (float)rnd.NextDouble() * 0.9f;
                    g.FillEllipse(shade, x, y + 14f * s, 180f * s, 34f * s);
                    g.FillEllipse(cloud, x, y, 170f * s, 40f * s);
                    g.FillEllipse(cloud, x + 30f * s, y - 20f * s, 100f * s, 46f * s);
                    g.FillEllipse(cloud, x + 80f * s, y - 10f * s, 90f * s, 40f * s);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeMountains(int mw, int baseTop, int height, Color color, bool trees, int seed)
    {
        Bitmap bmp = new Bitmap(mw, AreaH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(seed);
            int count = 14;
            PointF[] pts = new PointF[count + 3];
            pts[0] = new PointF(0f, AreaH);
            for (int i = 0; i <= count; i++)
            {
                float x = i * (mw / (float)count);
                float peak = (i % 2 == 0) ? baseTop - rnd.Next(height / 2, height) : baseTop - rnd.Next(0, height / 3);
                if (i == 0 || i == count) peak = baseTop - height / 3f;     // seamless tiling
                pts[i + 1] = new PointF(x, peak);
            }
            pts[count + 2] = new PointF(mw, AreaH);
            using (SolidBrush mb = new SolidBrush(color))
            {
                g.FillPolygon(mb, pts);
            }
            if (trees)
            {
                using (SolidBrush tree = new SolidBrush(Color.FromArgb(235, 40, 84, 100)))
                {
                    for (int x = 10; x < mw - 20; x += 22 + rnd.Next(28))
                    {
                        float ty = baseTop + 90 + rnd.Next(80);
                        PointF[] t = { new PointF(x, ty), new PointF(x + 10, ty), new PointF(x + 5, ty - 26 - rnd.Next(10)) };
                        g.FillPolygon(tree, t);
                    }
                }
            }
        }
        return bmp;
    }
}
