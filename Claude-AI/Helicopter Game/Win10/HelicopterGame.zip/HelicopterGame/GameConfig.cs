namespace HelicopterGame;

/// <summary>All tunable numbers of the game in one place.</summary>
public static class GameConfig
{
    // ---- layout (logical pixels)
    public const int LogicalW = 960;
    public const int LogicalH = 640;
    public const int FooterH = 32;
    public const int AreaH = LogicalH - FooterH;     // height of the playing area: 608
    public const float HeliScreenX = 270f;           // the helicopter stays in the left third of the screen

    // ---- helicopter physics (pixels and seconds, y grows downward)
    public const float Gravity = 900f;               // downward acceleration while the button is released
    public const float ThrustAccel = 1900f;          // upward acceleration while it is held (net upward = 1000)
    public const float MaxUpSpeed = 340f;
    public const float MaxDownSpeed = 420f;
    public const float ThrustRampTime = 0.05f;       // the lift builds up smoothly; releasing cuts it at once

    // ---- scrolling and score
    public const float BaseSpeed = 280f;             // px/s at the start
    public const float SpeedPerScore = 0.06f;        // extra px/s for every score point
    public const float MaxSpeed = 520f;
    public const float PixelsPerPoint = 10f;         // 10 px of travelled distance = 1 point

    // ---- tunnel
    public const float ColumnWidth = 8f;             // the tunnel is stored as columns this wide
    public const float StartGap = 340f;              // corridor height at the start
    public const float MinGap = 210f;                // the corridor never becomes narrower than this
    public const float GapShrinkPerScore = 0.035f;
    public const float WallMargin = 40f;             // minimum wall thickness at the top and the bottom
    public const int WarmupColumns = 160;            // a straight, easy stretch at the start (1280 px)
    public const float BarrierStartScore = 400f;     // static barriers appear after this score
    public const float BarrierMinGap = 250f;         // and only where the corridor is at least this high
    public const float BarrierMinSpacing = 600f;

    /// <summary>Speed of the world in px/s for the given score.</summary>
    public static float SpeedAt(int score)
    {
        return Math.Min(MaxSpeed, BaseSpeed + SpeedPerScore * score);
    }

    /// <summary>Corridor height for the given score before random variation.</summary>
    public static float GapAt(float score)
    {
        return Math.Max(MinGap, StartGap - GapShrinkPerScore * score);
    }

    /// <summary>0..1 difficulty factor used to widen the tunnel's curves.</summary>
    public static float DifficultyAt(float score)
    {
        return Math.Max(0f, Math.Min(1f, score / 3000f));
    }
}
