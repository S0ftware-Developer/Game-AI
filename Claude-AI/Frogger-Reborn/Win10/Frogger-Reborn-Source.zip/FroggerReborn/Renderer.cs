using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace FroggerReborn
{
    /// <summary>Draws one frame into a 960x564 logical bitmap. Reads game state only.</summary>
    internal sealed class Renderer
    {
        public const int LW = Game.W, LH = Game.H;

        // clickable areas (logical coordinates)
        public static readonly Rectangle BtnStart = new Rectangle(360, 448, 240, 48);
        public static readonly Rectangle BtnMenuSound = new Rectangle(410, 508, 140, 30);
        public static readonly Rectangle BtnSound = new Rectangle(824, 9, 128, 26);
        public static readonly Rectangle BtnRestart = new Rectangle(326, 316, 150, 44);
        public static readonly Rectangle BtnToMenu = new Rectangle(484, 316, 150, 44);

        private static readonly Color Yellow = Color.FromArgb(255, 204, 30);
        private static readonly Color Cyan = Color.FromArgb(80, 224, 255);
        private static readonly Color Green = Color.FromArgb(90, 255, 90);
        private static readonly Color Orange = Color.FromArgb(255, 150, 20);
        private static readonly Color Navy = Color.FromArgb(6, 16, 50);
        private static readonly Color Ink = Color.FromArgb(20, 20, 30);

        private readonly Bitmap bg;
        private readonly Font f12 = MakeFont(12, FontStyle.Bold), f16 = MakeFont(16, FontStyle.Bold),
            f20 = MakeFont(20, FontStyle.Bold), f28 = MakeFont(28, FontStyle.Bold),
            f48 = MakeFont(48, FontStyle.Bold), f72 = MakeFont(72, FontStyle.Bold | FontStyle.Italic),
            f96 = MakeFont(96, FontStyle.Bold);
        private readonly StringFormat sf = new StringFormat(StringFormatFlags.NoWrap);

        private static Font MakeFont(float px, FontStyle st)
        {
            return new Font("Consolas", px, st, GraphicsUnit.Pixel);
        }

        public Renderer()
        {
            bg = BuildBackground();
        }

        // =====================================================================
        //  Small drawing helpers
        // =====================================================================
        private static void Fill(Graphics g, Color c, float x, float y, float w, float h)
        {
            using (var b = new SolidBrush(c)) g.FillRectangle(b, x, y, w, h);
        }

        private static void Oval(Graphics g, Color c, float x, float y, float w, float h)
        {
            using (var b = new SolidBrush(c)) g.FillEllipse(b, x, y, w, h);
        }

        private static void OvalLine(Graphics g, Color c, float width, float x, float y, float w, float h)
        {
            using (var p = new Pen(c, width)) g.DrawEllipse(p, x, y, w, h);
        }

        private static Color Mix(Color a, Color b, float t)
        {
            return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t),
                (int)(a.B + (b.B - a.B) * t));
        }

        private static void Bush(Graphics g, float cx, float cy, float r)
        {
            Oval(g, Color.FromArgb(20, 92, 32), cx - r, cy - r * 0.8f, r * 2, r * 1.6f);
            Oval(g, Color.FromArgb(38, 142, 48), cx - r * 0.8f, cy - r * 0.9f, r * 1.3f, r * 1.2f);
            Oval(g, Color.FromArgb(84, 204, 72), cx - r * 0.3f, cy - r * 0.75f, r * 0.7f, r * 0.6f);
        }

        private static void Flower(Graphics g, float x, float y)
        {
            Fill(g, Color.White, x - 1, y - 3, 3, 7);
            Fill(g, Color.White, x - 3, y - 1, 7, 3);
            Fill(g, Color.FromArgb(255, 210, 40), x - 1, y - 1, 3, 3);
        }

        private static void Rock(Graphics g, float cx, float cy, float rw, float rh)
        {
            Oval(g, Color.FromArgb(142, 142, 150), cx - rw, cy - rh, rw * 2, rh * 2);
            OvalLine(g, Color.FromArgb(70, 70, 80), 2, cx - rw, cy - rh, rw * 2, rh * 2);
            Oval(g, Color.FromArgb(190, 190, 198), cx - rw * 0.6f, cy - rh * 0.7f, rw * 0.8f, rh * 0.6f);
        }

        private static void Sign(Graphics g, float x, float y)
        {
            Fill(g, Color.FromArgb(110, 70, 30), x - 3, y, 6, 24);
            GraphicsState st = g.Save();
            g.TranslateTransform(x, y);
            g.RotateTransform(-12f);
            Fill(g, Color.FromArgb(80, 45, 15), -18, -14, 36, 24);
            Fill(g, Color.FromArgb(176, 120, 58), -16, -12, 32, 20);
            Oval(g, Color.FromArgb(70, 40, 15), -6, -4, 12, 9);
            Oval(g, Color.FromArgb(70, 40, 15), -11, -9, 5, 6);
            Oval(g, Color.FromArgb(70, 40, 15), -4, -11, 5, 6);
            Oval(g, Color.FromArgb(70, 40, 15), 3, -11, 5, 6);
            Oval(g, Color.FromArgb(70, 40, 15), 8, -9, 5, 6);
            g.Restore(st);
        }

        // =====================================================================
        //  Static background (baked once)
        // =====================================================================
        private Bitmap BuildBackground()
        {
            var bmp = new Bitmap(LW, LH, PixelFormat.Format32bppPArgb);
            var r = new Random(3);
            int T = Game.T;
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.None;
                g.Clear(Color.FromArgb(8, 20, 50));

                // ---- home row: hedge with five water pockets ----
                int y0 = Game.RowTop(0);
                Fill(g, Color.FromArgb(24, 98, 36), 0, y0, LW, T);
                for (int i = 0; i < 300; i++)
                    Fill(g, r.Next(2) == 0 ? Color.FromArgb(40, 136, 50) : Color.FromArgb(16, 74, 28),
                        r.Next(LW / 6) * 6, y0 + r.Next(T / 6) * 6, 6, 6);
                for (int i = 0; i < Game.SlotCount; i++)
                {
                    int cx = (int)Game.SlotX(i);
                    Fill(g, Color.FromArgb(8, 44, 100), cx - 33, y0 + 2, 66, 37);
                    Fill(g, Color.FromArgb(30, 150, 240), cx - 30, y0 + 5, 60, 31);
                    Fill(g, Color.FromArgb(120, 210, 255), cx - 26, y0 + 9, 18, 2);
                    Oval(g, Color.FromArgb(56, 168, 60), cx + 6, y0 + 14, 20, 14);
                    Fill(g, Color.FromArgb(30, 150, 240), cx + 14, y0 + 14, 5, 7);
                }

                // ---- river ----
                int yr = Game.RowTop(1);
                var riverRect = new Rectangle(0, yr, LW, 5 * T);
                using (var br = new LinearGradientBrush(riverRect, Color.FromArgb(16, 108, 218),
                    Color.FromArgb(44, 168, 250), 90f))
                    g.FillRectangle(br, riverRect);
                for (int x = -10; x < LW + 20; x += 36 + r.Next(30))
                    Rock(g, x, yr + 1, 14 + r.Next(8), 8 + r.Next(4));
                for (int x = 0; x < LW; x += 46 + r.Next(40))
                    Bush(g, x, y0 + T - 6, 12);

                // ---- median ----
                int ym = Game.RowTop(6);
                Fill(g, Color.FromArgb(66, 176, 58), 0, ym, LW, T);
                for (int i = 0; i < 260; i++)
                    Fill(g, r.Next(2) == 0 ? Color.FromArgb(82, 196, 70) : Color.FromArgb(50, 150, 46),
                        r.Next(LW / 6) * 6, ym + 8 + r.Next((T - 16) / 6) * 6, 6, 6);
                for (int i = 0; i < 26; i++) Flower(g, 30 + r.Next(LW - 60), ym + 12 + r.Next(T - 24));
                Bush(g, 24, ym + 22, 16); Bush(g, LW - 24, ym + 22, 16);
                DrawStoneStrip(g, ym, 6);
                DrawStoneStrip(g, ym + T - 6, 6);

                // ---- road ----
                int yd = Game.RowTop(7);
                Fill(g, Color.FromArgb(46, 48, 58), 0, yd, LW, 5 * T);
                for (int i = 0; i < 500; i++)
                    Fill(g, Color.FromArgb(58, 60, 72), r.Next(LW), yd + r.Next(5 * T), 3, 2);
                for (int row = 8; row <= 11; row++)
                    for (int x = 8; x < LW; x += 60)
                        Fill(g, Color.FromArgb(228, 228, 232), x, Game.RowTop(row) - 1, 28, 3);
                DrawStoneStrip(g, yd, 6);
                DrawStoneStrip(g, yd + 5 * T - 6, 6);

                // ---- start zone ----
                int ys = Game.RowTop(12);
                Fill(g, Color.FromArgb(60, 170, 55), 0, ys, LW, T);
                for (int i = 0; i < 160; i++)
                    Fill(g, r.Next(2) == 0 ? Color.FromArgb(78, 192, 68) : Color.FromArgb(46, 140, 44),
                        r.Next(LW / 6) * 6, ys + 6 + r.Next((T - 6) / 6) * 6, 6, 6);
                Fill(g, Color.FromArgb(196, 152, 92), LW / 2 - 70, ys + 6, 140, T - 6);
                for (int i = 0; i < 40; i++)
                    Fill(g, Color.FromArgb(160, 118, 68), LW / 2 - 66 + r.Next(130), ys + 8 + r.Next(T - 12), 3, 3);
                DrawStoneStrip(g, ys, 6);
                for (int x = 20; x < LW / 2 - 100; x += 50 + r.Next(30)) Bush(g, x, ys + 26, 13);
                for (int x = LW / 2 + 110; x < LW - 10; x += 50 + r.Next(30)) Bush(g, x, ys + 26, 13);
                for (int i = 0; i < 14; i++)
                {
                    int fx = 20 + r.Next(LW - 40);
                    if (Math.Abs(fx - LW / 2) > 90) Flower(g, fx, ys + 14 + r.Next(T - 20));
                }
                Sign(g, 70, ys + 12);
                Sign(g, LW - 70, ys + 12);
                Rock(g, 200, ys + 28, 12, 8);
                Rock(g, LW - 200, ys + 28, 12, 8);
            }
            return bmp;
        }

        private static void DrawStoneStrip(Graphics g, int y, int h)
        {
            Fill(g, Color.FromArgb(150, 150, 158), 0, y, LW, h);
            Fill(g, Color.FromArgb(196, 196, 204), 0, y, LW, 2);
            for (int x = 0; x < LW; x += 40) Fill(g, Color.FromArgb(96, 96, 106), x, y, 2, h);
        }

        // =====================================================================
        //  Frame
        // =====================================================================
        public void Render(Graphics g, Game game, bool muted)
        {
            g.DrawImage(bg, 0, 0, LW, LH);
            DrawWaves(g, game);
            DrawPlatforms(g, game);
            DrawFilledSlots(g, game);
            DrawVehicles(g, game);
            DrawFrogLayer(g, game);

            if (game.Phase != Phase.Menu && game.LevelPause > 0f)
                Ctr(g, "LEVEL COMPLETE!", f48, LW / 2f, 200, Yellow, Color.FromArgb(90, 40, 0), 3);

            DrawHud(g, game, muted);

            switch (game.Phase)
            {
                case Phase.Menu: DrawMenu(g, game, muted); break;
                case Phase.Paused: DrawPaused(g); break;
                case Phase.GameOver: DrawGameOver(g, game); break;
            }
        }

        private void DrawWaves(Graphics g, Game game)
        {
            foreach (var l in game.Lanes)
            {
                if (l.Kind != LaneKind.River) continue;
                int top = Game.RowTop(l.Row);
                float off = game.Time * l.Dir * 16f + l.Row * 17f;
                for (int k = 0; k < 14; k++)
                {
                    float x = Game.Mod(k * 84f + off, LW + 40f) - 20f;
                    Fill(g, Color.FromArgb(150, 215, 255), x, top + 8, 22, 3);
                    Fill(g, Color.FromArgb(110, 190, 250), x + 40, top + 29, 16, 3);
                }
            }
        }

        // ---------- river platforms ----------
        private void DrawPlatforms(Graphics g, Game game)
        {
            foreach (var l in game.Lanes)
            {
                if (l.Kind != LaneKind.River) continue;
                int top = Game.RowTop(l.Row);
                for (int i = 0; i < l.Count; i++)
                {
                    float x = game.ObjX(l, i);
                    if (x > LW || x + l.Len < 0) continue;
                    if (l.Style == LaneStyle.Log) DrawLog(g, x, top, l.Len);
                    else DrawTurtles(g, x, top, (int)(l.Len / 40f), l.Dir, game.Submerge(l, i));
                }
            }
        }

        private void DrawLog(Graphics g, float x, int top, float len)
        {
            Fill(g, Color.FromArgb(60, 34, 14), x, top + 6, len, 28);
            Fill(g, Color.FromArgb(124, 78, 36), x + 2, top + 8, len - 4, 24);
            Fill(g, Color.FromArgb(152, 100, 50), x + 8, top + 12, len - 16, 3);
            Fill(g, Color.FromArgb(152, 100, 50), x + 14, top + 19, len - 28, 3);
            Fill(g, Color.FromArgb(96, 58, 26), x + 8, top + 26, len - 16, 3);
            Fill(g, Color.FromArgb(70, 160, 50), x + len * 0.30f, top + 8, 22, 5);
            Fill(g, Color.FromArgb(70, 160, 50), x + len * 0.62f, top + 27, 18, 5);
            // end rings
            Oval(g, Color.FromArgb(60, 34, 14), x - 3, top + 5, 16, 30);
            Oval(g, Color.FromArgb(214, 168, 104), x - 1, top + 7, 12, 26);
            OvalLine(g, Color.FromArgb(150, 104, 56), 2, x + 2, top + 12, 6, 16);
            Oval(g, Color.FromArgb(60, 34, 14), x + len - 13, top + 5, 16, 30);
            Oval(g, Color.FromArgb(214, 168, 104), x + len - 11, top + 7, 12, 26);
            OvalLine(g, Color.FromArgb(150, 104, 56), 2, x + len - 8, top + 12, 6, 16);
        }

        private void DrawTurtles(Graphics g, float x, int top, int n, int dir, float sub)
        {
            int a = (int)(255 * (1f - sub * 0.92f));
            for (int k = 0; k < n; k++)
            {
                float tx = x + k * 40;
                float hx = dir > 0 ? tx + 28 : tx + 1;
                Oval(g, Color.FromArgb(a, 66, 160, 56), hx, top + 15, 11, 10);                 // head
                Oval(g, Color.FromArgb(a, 255, 255, 255), hx + (dir > 0 ? 6 : 1), top + 17, 3, 3);
                Oval(g, Color.FromArgb(a, 66, 160, 56), tx + 8, top + 5, 9, 8);                // legs
                Oval(g, Color.FromArgb(a, 66, 160, 56), tx + 23, top + 5, 9, 8);
                Oval(g, Color.FromArgb(a, 66, 160, 56), tx + 8, top + 27, 9, 8);
                Oval(g, Color.FromArgb(a, 66, 160, 56), tx + 23, top + 27, 9, 8);
                Oval(g, Color.FromArgb(a, 60, 34, 14), tx + 5, top + 7, 30, 26);               // shell
                Oval(g, Color.FromArgb(a, 134, 94, 48), tx + 7, top + 9, 26, 22);
                Fill(g, Color.FromArgb(a, 176, 132, 72), tx + 18, top + 11, 4, 18);
                Fill(g, Color.FromArgb(a, 176, 132, 72), tx + 10, top + 18, 20, 4);
                if (sub > 0.4f)
                    OvalLine(g, Color.FromArgb((int)(160 * sub), 255, 255, 255), 2, tx + 2, top + 6, 36, 28);
            }
        }

        // ---------- vehicles ----------
        private void DrawVehicles(Graphics g, Game game)
        {
            foreach (var l in game.Lanes)
            {
                if (l.Kind != LaneKind.Road) continue;
                int top = Game.RowTop(l.Row);
                for (int i = 0; i < l.Count; i++)
                {
                    float x = game.ObjX(l, i);
                    if (x > LW || x + l.Len < 0) continue;
                    DrawVehicle(g, l.Style, x, top, l.Len, l.Colors[i % l.Colors.Length], l.Dir);
                }
            }
        }

        private void DrawVehicle(Graphics g, LaneStyle style, float x, int top, float len, Color body, int dir)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(x + len / 2f, top + Game.T / 2f);
            if (dir < 0) g.ScaleTransform(-1f, 1f);        // drawn facing right, mirrored for left-moving lanes
            float hl = len / 2f;
            Color wheel = Color.FromArgb(24, 24, 30);
            Color glass = Color.FromArgb(130, 200, 255);

            Fill(g, Color.FromArgb(70, 255, 255, 255), -hl - 22, -7, 20, 2);     // speed lines
            Fill(g, Color.FromArgb(70, 255, 255, 255), -hl - 32, 5, 30, 2);

            using (var line = new Pen(Ink, 2))
            {
                switch (style)
                {
                    case LaneStyle.Truck:
                        Fill(g, wheel, -hl + 8, -17, 14, 5); Fill(g, wheel, -hl + 8, 12, 14, 5);
                        Fill(g, wheel, -hl + 32, -17, 14, 5); Fill(g, wheel, -hl + 32, 12, 14, 5);
                        Fill(g, wheel, hl - 24, -17, 14, 5); Fill(g, wheel, hl - 24, 12, 14, 5);
                        Fill(g, body, -hl, -14, len - 34, 28);
                        g.DrawRectangle(line, -hl, -14, len - 34, 28);
                        for (int k = 1; k < 5; k++) Fill(g, Mix(body, Color.Black, 0.25f), -hl + k * 13, -12, 2, 24);
                        Fill(g, Color.FromArgb(50, 110, 220), hl - 32, -12, 32, 24);
                        g.DrawRectangle(line, hl - 32, -12, 32, 24);
                        Fill(g, glass, hl - 13, -9, 8, 18);
                        Fill(g, Color.FromArgb(255, 240, 150), hl - 3, -10, 3, 5);
                        Fill(g, Color.FromArgb(255, 240, 150), hl - 3, 5, 3, 5);
                        break;

                    case LaneStyle.Van:
                        Fill(g, wheel, -hl + 8, -16, 12, 5); Fill(g, wheel, -hl + 8, 11, 12, 5);
                        Fill(g, wheel, hl - 20, -16, 12, 5); Fill(g, wheel, hl - 20, 11, 12, 5);
                        Fill(g, body, -hl, -13, len, 26);
                        g.DrawRectangle(line, -hl, -13, len, 26);
                        Fill(g, Mix(body, Color.Black, 0.18f), -hl + 6, -9, len - 30, 18);
                        Fill(g, glass, hl - 19, -9, 9, 18);
                        Fill(g, Color.FromArgb(230, 60, 60), -hl + 6, -2, len - 30, 4);
                        Fill(g, Color.FromArgb(255, 240, 150), hl - 3, -10, 3, 5);
                        Fill(g, Color.FromArgb(255, 240, 150), hl - 3, 5, 3, 5);
                        break;

                    default:   // Car
                        Fill(g, wheel, -hl + 7, -16, 12, 5); Fill(g, wheel, -hl + 7, 11, 12, 5);
                        Fill(g, wheel, hl - 19, -16, 12, 5); Fill(g, wheel, hl - 19, 11, 12, 5);
                        Fill(g, body, -hl, -12, len, 24);
                        g.DrawRectangle(line, -hl, -12, len, 24);
                        Fill(g, Mix(body, Color.White, 0.35f), -hl + 14, -9, len * 0.38f, 18);
                        Fill(g, glass, hl - 18, -8, 7, 16);
                        Fill(g, Color.FromArgb(90, 140, 190), -hl + 6, -8, 5, 16);
                        Fill(g, Color.FromArgb(255, 240, 150), hl - 3, -10, 3, 5);
                        Fill(g, Color.FromArgb(255, 240, 150), hl - 3, 5, 3, 5);
                        Fill(g, Color.FromArgb(220, 40, 40), -hl, -10, 2, 5);
                        Fill(g, Color.FromArgb(220, 40, 40), -hl, 5, 2, 5);
                        break;
                }
            }
            g.Restore(st);
        }

        // ---------- frog ----------
        private void DrawFilledSlots(Graphics g, Game game)
        {
            for (int i = 0; i < Game.SlotCount; i++)
                if (game.Filled[i])
                    DrawFrog(g, Game.SlotX(i), Game.RowTop(0) + Game.T / 2f, 180f, 0.8f, false);
        }

        private void DrawFrog(Graphics g, float cx, float cy, float rot, float scale, bool stretched)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(cx, cy);
            g.RotateTransform(rot);
            g.ScaleTransform(scale, scale);

            Color body = Color.FromArgb(70, 205, 70), dark = Color.FromArgb(18, 88, 30),
                belly = Color.FromArgb(160, 240, 120);
            float ext = stretched ? 4f : 0f;

            // back legs
            Oval(g, dark, -19, 0 + ext, 12, 20); Oval(g, body, -17, 2 + ext, 8, 16);
            Oval(g, dark, 7, 0 + ext, 12, 20); Oval(g, body, 9, 2 + ext, 8, 16);
            // front legs
            Oval(g, dark, -17, -12 - ext, 10, 12); Oval(g, body, -15, -10 - ext, 6, 8);
            Oval(g, dark, 7, -12 - ext, 10, 12); Oval(g, body, 9, -10 - ext, 6, 8);
            // body
            Oval(g, dark, -12, -13, 24, 28);
            Oval(g, body, -10, -11, 20, 24);
            Oval(g, belly, -5, -2, 10, 12);
            Oval(g, Color.FromArgb(40, 150, 50), -7, 3, 4, 4);
            Oval(g, Color.FromArgb(40, 150, 50), 3, 1, 4, 4);
            // eyes
            Oval(g, dark, -11, -19, 11, 11); Oval(g, Color.White, -10, -18, 9, 9);
            Oval(g, dark, 0, -19, 11, 11); Oval(g, Color.White, 1, -18, 9, 9);
            Oval(g, Ink, -7, -17, 4, 5); Oval(g, Ink, 4, -17, 4, 5);
            g.Restore(st);
        }

        private void DrawFrogLayer(Graphics g, Game game)
        {
            if (game.Phase == Phase.Menu) return;

            if (game.DeathTimer > 0f)
            {
                float p = 1f - game.DeathTimer / 0.9f;
                float x = game.FrogX, y = game.FrogY;
                if (game.DeathKind == 1)
                {
                    Oval(g, Color.FromArgb(18, 88, 30), x - 20, y - 9, 40, 18);
                    Oval(g, Color.FromArgb(70, 205, 70), x - 17, y - 7, 34, 14);
                    Oval(g, Color.FromArgb(200, 40, 40), x - 6, y - 3, 6, 5);
                    using (var pen = new Pen(Ink, 2))
                    {
                        g.DrawLine(pen, x - 12, y - 5, x - 7, y);
                        g.DrawLine(pen, x - 7, y - 5, x - 12, y);
                        g.DrawLine(pen, x + 7, y - 5, x + 12, y);
                        g.DrawLine(pen, x + 12, y - 5, x + 7, y);
                    }
                }
                else
                {
                    int a = (int)(255 * (1f - p));
                    for (int k = 0; k < 3; k++)
                        OvalLine(g, Color.FromArgb(Math.Max(0, a - k * 50), 255, 255, 255), 3,
                            x - (8 + p * 30 + k * 9), y - (6 + p * 18 + k * 6), 2 * (8 + p * 30 + k * 9), 2 * (6 + p * 18 + k * 6));
                    for (int k = 0; k < 5; k++)
                        Oval(g, Color.FromArgb(a, 200, 235, 255), x - 14 + k * 7, y - 6 - p * 26 - (k % 2) * 8, 5, 5);
                }
                return;
            }

            float hopY = 0f, scale = 1f;
            if (game.Hopping)
            {
                hopY = (float)Math.Sin(Math.PI * Math.Min(1f, game.HopT)) * 10f;
                scale = 1.15f;
                Oval(g, Color.FromArgb(70, 0, 0, 0), game.FrogX - 12, game.FrogY + 8, 24, 8);   // shadow
            }
            DrawFrog(g, game.FrogX, game.FrogY - hopY, game.FrogRot, scale, game.Hopping);
        }

        // =====================================================================
        //  Text / panels / HUD
        // =====================================================================
        private void DrawTxt(Graphics g, string s, Font f, float x, float y, Color fill, Color outline, int th,
            StringAlignment al)
        {
            sf.Alignment = al;
            if (th > 0)
            {
                using (var ob = new SolidBrush(outline))
                    for (int dx = -th; dx <= th; dx += th)
                        for (int dy = -th; dy <= th; dy += th)
                            if (dx != 0 || dy != 0) g.DrawString(s, f, ob, x + dx, y + dy, sf);
            }
            using (var fb = new SolidBrush(fill)) g.DrawString(s, f, fb, x, y, sf);
        }

        private void Ctr(Graphics g, string s, Font f, float x, float y, Color fill, Color outline, int th)
        {
            DrawTxt(g, s, f, x, y, fill, outline, th, StringAlignment.Center);
        }

        private static Point[] Chamfer(Rectangle r, int c)
        {
            return new[]
            {
                new Point(r.Left + c, r.Top), new Point(r.Right - c, r.Top),
                new Point(r.Right, r.Top + c), new Point(r.Right, r.Bottom - c),
                new Point(r.Right - c, r.Bottom), new Point(r.Left + c, r.Bottom),
                new Point(r.Left, r.Bottom - c), new Point(r.Left, r.Top + c)
            };
        }

        private void Panel(Graphics g, Rectangle r, Color border, int alpha)
        {
            var poly = Chamfer(r, 6);
            using (var fill = new SolidBrush(Color.FromArgb(alpha, 8, 22, 64))) g.FillPolygon(fill, poly);
            using (var glow = new Pen(Color.FromArgb(60, border), 4)) g.DrawPolygon(glow, poly);
            using (var pen = new Pen(border, 2)) g.DrawPolygon(pen, poly);
        }

        private void Button(Graphics g, Rectangle r, string label)
        {
            var poly = Chamfer(r, 6);
            using (var fill = new SolidBrush(Color.FromArgb(14, 100, 36))) g.FillPolygon(fill, poly);
            using (var glow = new Pen(Color.FromArgb(70, 90, 255, 90), 4)) g.DrawPolygon(glow, poly);
            using (var pen = new Pen(Color.FromArgb(90, 255, 90), 2)) g.DrawPolygon(pen, poly);
            Ctr(g, label, f28, r.X + r.Width / 2f, r.Y + (r.Height - 28) / 2f - 1, Green, Color.FromArgb(0, 50, 10), 1);
        }

        private void Dim(Graphics g, int alpha)
        {
            using (var b = new SolidBrush(Color.FromArgb(alpha, 0, 0, 20))) g.FillRectangle(b, 0, Game.HudH, LW, LH - Game.HudH);
        }

        private void Stat(Graphics g, string label, string value, float x, Color labelColor)
        {
            DrawTxt(g, label, f12, x, 5, labelColor, Navy, 0, StringAlignment.Near);
            DrawTxt(g, value, f20, x, 19, Color.White, Navy, 0, StringAlignment.Near);
        }

        private void DrawHud(Graphics g, Game game, bool muted)
        {
            Fill(g, Color.FromArgb(8, 20, 54), 0, 0, LW, Game.HudH);
            Fill(g, Color.FromArgb(0, 170, 255), 0, Game.HudH - 3, LW, 3);
            Fill(g, Color.FromArgb(120, 230, 255), 0, Game.HudH - 3, LW, 1);

            Stat(g, "SCORE", game.Score.ToString("D6"), 14, Cyan);
            Stat(g, "HI-SCORE", game.HiScore.ToString("D6"), 180, Yellow);
            Stat(g, "LEVEL", game.Level.ToString("D2"), 346, Green);

            DrawTxt(g, "LIVES", f12, 450, 5, Yellow, Navy, 0, StringAlignment.Near);
            for (int i = 0; i < Math.Max(0, game.Lives); i++)
                DrawFrog(g, 462 + i * 30, 29, 0f, 0.6f, false);

            DrawTxt(g, "TIME", f12, 640, 5, Cyan, Navy, 0, StringAlignment.Near);
            float frac = Math.Max(0f, Math.Min(1f, game.TimeLeft / game.TimeMax));
            Color tc = frac > 0.5f ? Color.FromArgb(70, 230, 100) : (frac > 0.25f ? Yellow : Color.FromArgb(255, 70, 60));
            Fill(g, Color.FromArgb(4, 12, 34), 640, 21, 160, 14);
            Fill(g, tc, 642, 23, 156 * frac, 10);
            using (var p = new Pen(Color.FromArgb(0, 170, 255), 1)) g.DrawRectangle(p, 640, 21, 160, 14);

            Panel(g, BtnSound, muted ? Color.FromArgb(255, 110, 110) : Color.FromArgb(0, 170, 255), 220);
            Ctr(g, muted ? "[M] SOUND OFF" : "[M] SOUND ON", f12, BtnSound.X + BtnSound.Width / 2f, BtnSound.Y + 7,
                muted ? Color.FromArgb(255, 150, 150) : Color.White, Navy, 0);
        }

        // =====================================================================
        //  Screens
        // =====================================================================
        private void DrawMenu(Graphics g, Game game, bool muted)
        {
            Dim(g, 110);
            float cx = LW / 2f;
            Ctr(g, "FROGGER", f96, cx, 54, Color.FromArgb(110, 235, 40), Color.FromArgb(10, 40, 10), 4);
            Ctr(g, "REBORN", f72, cx, 150, Orange, Color.FromArgb(80, 20, 0), 3);

            float bob = (float)Math.Sin(game.Time * 4f) * 4f;
            DrawFrog(g, cx, 296 + bob, 0f, 2.2f, false);

            var panel = new Rectangle(250, 352, 460, 84);
            Panel(g, panel, Color.FromArgb(0, 190, 255), 225);
            Ctr(g, "CROSS THE ROAD, RIDE THE LOGS, FILL ALL 5 HOMES", f12, cx, 362, Yellow, Navy, 0);
            Ctr(g, "ARROWS / WASD : HOP      P : PAUSE      M : SOUND", f16, cx, 384, Color.White, Navy, 1);
            Ctr(g, "ESC : PAUSE / QUIT TO MENU", f16, cx, 406, Cyan, Navy, 1);

            Button(g, BtnStart, "START GAME");
            Panel(g, BtnMenuSound, muted ? Color.FromArgb(255, 110, 110) : Color.FromArgb(0, 170, 255), 225);
            Ctr(g, muted ? "SOUND: OFF" : "SOUND: ON", f16, BtnMenuSound.X + BtnMenuSound.Width / 2f,
                BtnMenuSound.Y + 6, Color.White, Navy, 0);
        }

        private void DrawPaused(Graphics g)
        {
            Dim(g, 140);
            var r = new Rectangle(300, 200, 360, 150);
            Panel(g, r, Color.FromArgb(0, 190, 255), 240);
            float cx = r.X + r.Width / 2f;
            Ctr(g, "PAUSED", f48, cx, r.Y + 18, Yellow, Color.FromArgb(90, 40, 0), 2);
            Ctr(g, "P = RESUME", f20, cx, r.Y + 88, Color.White, Navy, 1);
            Ctr(g, "ESC = QUIT TO MENU", f16, cx, r.Y + 118, Cyan, Navy, 0);
        }

        private void DrawGameOver(Graphics g, Game game)
        {
            Dim(g, 150);
            var r = new Rectangle(300, 130, 360, 290);
            Panel(g, r, Color.FromArgb(255, 80, 70), 242);
            float cx = r.X + r.Width / 2f;
            Ctr(g, "GAME OVER", f48, cx, r.Y + 16, Color.FromArgb(255, 80, 60), Color.FromArgb(70, 0, 0), 3);
            Ctr(g, "SCORE", f16, cx, r.Y + 84, Cyan, Navy, 0);
            Ctr(g, game.Score.ToString("D6"), f28, cx, r.Y + 104, Color.White, Navy, 1);
            Ctr(g, "HI-SCORE", f16, cx, r.Y + 142, Yellow, Navy, 0);
            Ctr(g, game.HiScore.ToString("D6"), f28, cx, r.Y + 162, Color.White, Navy, 1);
            Button(g, BtnRestart, "RESTART");
            Button(g, BtnToMenu, "MENU");
            Ctr(g, "R = RESTART      ESC = MENU", f12, cx, r.Y + 258, Cyan, Navy, 0);
        }
    }
}
