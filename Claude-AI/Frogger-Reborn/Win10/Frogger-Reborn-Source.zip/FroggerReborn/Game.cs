using System;
using System.Collections.Generic;
using System.Drawing;

namespace FroggerReborn
{
    internal enum Phase { Menu, Playing, Paused, GameOver }
    internal enum LaneKind { Road, River }
    internal enum LaneStyle { Car, Truck, Van, Log, Turtle }

    /// <summary>One horizontal lane of traffic or river platforms. Objects are evenly spaced on a looping belt.</summary>
    internal sealed class Lane
    {
        public int Row;
        public LaneKind Kind;
        public LaneStyle Style;
        public int Dir;              // +1 = moves right, -1 = moves left
        public float BaseSpeed;      // px per second at level 1
        public float Len;            // object length in px
        public float Spacing;        // distance between object starts
        public bool Dives;           // turtles that periodically submerge
        public Color[] Colors;       // vehicle body colours
        public int Count;
        public float Loop;
        public float Scroll;
    }

    /// <summary>
    /// Pure game logic, no drawing. Layout: 13 rows of 40 px under a 44 px HUD.
    /// Row 0 = home slots, 1-5 = river, 6 = median, 7-11 = road, 12 = start.
    /// </summary>
    internal sealed class Game
    {
        public const int W = 960, HudH = 44, T = 40, Rows = 13;
        public const int FY = HudH;
        public const int H = HudH + Rows * T;      // 564
        public const int SlotCount = 5;
        private const float SlotHalf = 30f;
        private const float HopDur = 0.11f;
        private const float DeathDur = 0.9f;

        public static int RowTop(int row) { return FY + row * T; }
        public static float SlotX(int i) { return W * (i + 0.5f) / SlotCount; }
        public static float Mod(float a, float b) { return a - b * (float)Math.Floor(a / b); }

        // ---------- state read by the renderer ----------
        public Phase Phase = Phase.Menu;
        public int Score, HiScore, Level = 1, Lives = 3, FrogRow = 12, DeathKind;
        public float FrogX = W / 2f, FrogY, FrogRot, HopT, DeathTimer, TimeLeft = 30f, TimeMax = 30f, LevelPause, Time;
        public bool Hopping;
        public readonly bool[] Filled = new bool[SlotCount];
        public readonly Lane[] Lanes;
        public Action<string> Sound;

        private float hopFromX, hopFromY, hopToX, hopToY, endTimer;
        private int hopToRow, bestRow = 12;

        public bool CanRestart { get { return endTimer <= 0f; } }

        public Game()
        {
            HiScore = HighScoreStore.Load();
            Color[] c1 = { Color.FromArgb(230, 50, 50), Color.FromArgb(250, 205, 40), Color.FromArgb(60, 130, 235) };
            Color[] c2 = { Color.FromArgb(235, 150, 40), Color.FromArgb(70, 170, 80) };
            Color[] c3 = { Color.FromArgb(170, 80, 220), Color.FromArgb(60, 130, 235), Color.FromArgb(230, 50, 50) };
            Color[] c4 = { Color.FromArgb(235, 235, 240), Color.FromArgb(250, 205, 40) };
            Color[] c5 = { Color.FromArgb(70, 200, 200), Color.FromArgb(230, 50, 50), Color.FromArgb(170, 80, 220) };

            Lanes = new[]
            {
                MakeLane(1, LaneKind.River, LaneStyle.Log, +1, 55, 120, 300, false, null),
                MakeLane(2, LaneKind.River, LaneStyle.Turtle, -1, 48, 120, 280, true, null),
                MakeLane(3, LaneKind.River, LaneStyle.Log, +1, 38, 200, 440, false, null),
                MakeLane(4, LaneKind.River, LaneStyle.Turtle, -1, 65, 80, 260, true, null),
                MakeLane(5, LaneKind.River, LaneStyle.Log, +1, 50, 140, 340, false, null),
                MakeLane(7, LaneKind.Road, LaneStyle.Car, -1, 90, 56, 220, false, c1),
                MakeLane(8, LaneKind.Road, LaneStyle.Truck, +1, 65, 104, 340, false, c2),
                MakeLane(9, LaneKind.Road, LaneStyle.Car, -1, 130, 56, 290, false, c3),
                MakeLane(10, LaneKind.Road, LaneStyle.Van, +1, 85, 72, 260, false, c4),
                MakeLane(11, LaneKind.Road, LaneStyle.Car, -1, 110, 56, 240, false, c5)
            };
            Respawn();
        }

        private static Lane MakeLane(int row, LaneKind kind, LaneStyle style, int dir, float speed,
            float len, float spacing, bool dives, Color[] colors)
        {
            int count = (int)Math.Ceiling((W + len) / spacing) + 1;
            return new Lane
            {
                Row = row, Kind = kind, Style = style, Dir = dir, BaseSpeed = speed, Len = len,
                Spacing = spacing, Dives = dives, Colors = colors, Count = count,
                Loop = count * spacing, Scroll = row * 53f
            };
        }

        // ---------- lane helpers ----------
        public float Speed(Lane l) { return l.BaseSpeed * Math.Min(1.8f, 1f + 0.1f * (Level - 1)); }

        /// <summary>Left x of object i in lane l. Stateless: derived from the lane scroll offset.</summary>
        public float ObjX(Lane l, int i) { return Mod(i * l.Spacing + l.Scroll, l.Loop) - l.Len; }

        /// <summary>0 = fully up, 1 = fully submerged (turtles only). Unsafe when >= 0.9.</summary>
        public float Submerge(Lane l, int i)
        {
            if (!l.Dives) return 0f;
            float p = Mod(Time + i * 1.9f + l.Row * 0.7f, 7f);
            if (p < 4.5f) return 0f;
            if (p < 5.5f) return p - 4.5f;
            if (p < 6.5f) return 1f;
            return 1f - (p - 6.5f) * 2f;
        }

        private Lane PlatformUnder(int row, float x)
        {
            foreach (var l in Lanes)
            {
                if (l.Kind != LaneKind.River || l.Row != row) continue;
                for (int i = 0; i < l.Count; i++)
                {
                    float px = ObjX(l, i);
                    if (x >= px + 3 && x <= px + l.Len - 3 && Submerge(l, i) < 0.9f) return l;
                }
            }
            return null;
        }

        private void ScrollLanes(float dt)
        {
            foreach (var l in Lanes) l.Scroll += l.Dir * Speed(l) * dt;
        }

        // ---------- flow ----------
        public void NewGame()
        {
            Score = 0; Level = 1; Lives = 3;
            Array.Clear(Filled, 0, Filled.Length);
            DeathTimer = 0; LevelPause = 0; endTimer = 0; Time = 0;
            Respawn();
            Phase = Phase.Playing;
        }

        public void GoMenu() { SaveHi(); Phase = Phase.Menu; }

        public void TogglePause()
        {
            if (Phase == Phase.Playing) Phase = Phase.Paused;
            else if (Phase == Phase.Paused) Phase = Phase.Playing;
        }

        public void SaveHi()
        {
            if (Score > HiScore) HiScore = Score;
            HighScoreStore.Save(HiScore);
        }

        private void AddScore(int n)
        {
            Score += n;
            if (Score > HiScore) HiScore = Score;
        }

        private void Respawn()
        {
            FrogRow = 12; bestRow = 12;
            FrogX = W / 2f; FrogY = RowTop(12) + T / 2f; FrogRot = 0;
            Hopping = false; HopT = 0;
            TimeMax = Math.Max(18f, 32f - 2f * Level);
            TimeLeft = TimeMax;
        }

        private void EndGame()
        {
            Phase = Phase.GameOver;
            endTimer = 0.6f;
            SaveHi();
            Sound?.Invoke("lose");
        }

        private void Kill(int kind)
        {
            if (DeathTimer > 0f) return;      // dies only once
            DeathKind = kind;                  // 1 = run over, 2 = drowned
            DeathTimer = DeathDur;
            Hopping = false;
            Lives--;
            Sound?.Invoke(kind == 1 ? "squash" : "splash");
        }

        // ---------- input ----------
        public void RequestHop(int dx, int dy)
        {
            if (Phase != Phase.Playing || Hopping || DeathTimer > 0f || LevelPause > 0f) return;
            int newRow = FrogRow + dy;
            if (newRow < 0 || newRow >= Rows) return;
            float nx = FrogX + dx * T;
            if (dx != 0 && (nx < T / 2f || nx > W - T / 2f)) return;

            hopFromX = FrogX; hopFromY = FrogY;
            hopToX = nx; hopToY = RowTop(newRow) + T / 2f; hopToRow = newRow;
            Hopping = true; HopT = 0f;
            FrogRot = dy < 0 ? 0f : (dy > 0 ? 180f : (dx > 0 ? 90f : 270f));
            Sound?.Invoke("hop");
        }

        // ---------- update ----------
        public void Update(float dt)
        {
            if (Phase == Phase.Menu) { Time += dt; ScrollLanes(dt); }
            else if (Phase == Phase.Playing) UpdatePlaying(dt);
            if (endTimer > 0f) endTimer -= dt;
        }

        private void UpdatePlaying(float dt)
        {
            Time += dt;
            ScrollLanes(dt);

            if (DeathTimer > 0f)
            {
                DeathTimer -= dt;
                if (DeathTimer <= 0f)
                {
                    if (Lives <= 0) EndGame(); else Respawn();
                }
                return;
            }
            if (LevelPause > 0f)
            {
                LevelPause -= dt;
                if (LevelPause <= 0f)
                {
                    Level++;
                    Array.Clear(Filled, 0, Filled.Length);
                    Respawn();
                }
                return;
            }

            TimeLeft -= dt;
            if (TimeLeft <= 0f) { Kill(1); return; }

            if (Hopping)
            {
                HopT += dt / HopDur;
                float t = Math.Min(1f, HopT);
                FrogX = hopFromX + (hopToX - hopFromX) * t;
                FrogY = hopFromY + (hopToY - hopFromY) * t;
                if (HopT >= 1f)
                {
                    Hopping = false;
                    FrogRow = hopToRow;
                    FrogX = hopToX; FrogY = hopToY;
                    if (FrogRow < bestRow) { bestRow = FrogRow; AddScore(10); }
                    if (FrogRow == 0) { TryHome(); if (DeathTimer > 0f || LevelPause > 0f) return; }
                }
            }

            if (!Hopping && FrogRow >= 1 && FrogRow <= 5)
            {
                var lane = PlatformUnder(FrogRow, FrogX);
                if (lane == null) { Kill(2); return; }
                FrogX += lane.Dir * Speed(lane) * dt;          // ride the platform
                if (FrogX < 8f || FrogX > W - 8f) { Kill(2); return; }
            }

            CheckVehicles();
        }

        private void TryHome()
        {
            int slot = -1;
            for (int i = 0; i < SlotCount; i++)
                if (Math.Abs(FrogX - SlotX(i)) <= SlotHalf) slot = i;

            if (slot < 0 || Filled[slot]) { Kill(1); return; }

            Filled[slot] = true;
            AddScore(50 + (int)TimeLeft * 2);
            bool all = true;
            foreach (bool f in Filled) all &= f;
            if (all)
            {
                AddScore(500);
                LevelPause = 1.8f;
                Sound?.Invoke("level");
            }
            else Sound?.Invoke("home");
            Respawn();
        }

        private void CheckVehicles()
        {
            var fr = new RectangleF(FrogX - 11, FrogY - 11, 22, 22);
            foreach (var l in Lanes)
            {
                if (l.Kind != LaneKind.Road) continue;
                float ly = RowTop(l.Row) + 6;
                if (fr.Bottom < ly || fr.Top > ly + T - 12) continue;
                for (int i = 0; i < l.Count; i++)
                {
                    float px = ObjX(l, i);
                    if (fr.IntersectsWith(new RectangleF(px + 2, ly, l.Len - 4, T - 12)))
                    {
                        Kill(1);
                        return;
                    }
                }
            }
        }
    }
}
