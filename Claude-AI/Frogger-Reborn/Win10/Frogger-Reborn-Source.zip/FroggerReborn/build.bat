@echo off
rem Frogger Reborn - restore, publish a self-contained single-file Windows x64 exe, copy it to .\dist
setlocal
cd /d "%~dp0"

dotnet --version >nul 2>&1
if errorlevel 1 (
  echo .NET SDK not found. Install the .NET 8 SDK: https://dotnet.microsoft.com/download
  pause
  exit /b 1
)

echo [1/3] dotnet restore
dotnet restore FroggerReborn.csproj -r win-x64
if errorlevel 1 goto fail

echo [2/3] dotnet publish
dotnet publish FroggerReborn.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true --no-restore -o publish
if errorlevel 1 goto fail

echo [3/3] copying to dist
if exist dist rmdir /s /q dist
mkdir dist
copy /y "publish\FroggerReborn.exe" "dist\FroggerReborn.exe" >nul
if errorlevel 1 goto fail

echo.
echo SUCCESS. Game: %~dp0dist\FroggerReborn.exe
pause
exit /b 0

:fail
echo.
echo BUILD FAILED - see the messages above.
pause
exit /b 1
