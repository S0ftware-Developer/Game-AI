using System;
using System.IO;

namespace FroggerReborn
{
    /// <summary>Hi-score persistence: one integer in %LocalAppData%\FroggerReborn\highscore.txt.</summary>
    internal static class HighScoreStore
    {
        private static readonly string FilePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "FroggerReborn", "highscore.txt");

        public static int Load()
        {
            try
            {
                int v;
                if (File.Exists(FilePath) && int.TryParse(File.ReadAllText(FilePath).Trim(), out v) && v > 0)
                    return v;
            }
            catch { }
            return 0;
        }

        public static void Save(int value)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
                File.WriteAllText(FilePath, value.ToString());
            }
            catch { }
        }
    }
}
