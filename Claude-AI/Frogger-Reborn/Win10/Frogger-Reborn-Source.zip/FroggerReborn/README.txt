FROGGER REBORN  -  C# / .NET 8 / Windows Forms  (Windows 10/11 x64)
====================================================================

A retro Frogger remake: cross the road, ride logs and turtles over the river, fill all five
home slots to clear a level. 3 lives, a timer per life, rising difficulty, saved hi-score.
No external assets or NuGet packages: graphics are drawn in code, sounds are synthesised.

REQUIREMENTS (to BUILD)
  - Windows 10/11 x64
  - .NET 8 SDK  (https://dotnet.microsoft.com/download)  -  check with:  dotnet --version
  - Internet access on the first build: the SDK downloads the win-x64 runtime pack from NuGet
    (needed for a self-contained build). After that it is cached.

BUILD AND PUBLISH (easy way)
  1. Unzip the archive anywhere.
  2. Double-click build.bat
  3. Result: dist\FroggerReborn.exe  (single file, no .NET installation needed to run it)

BUILD AND PUBLISH (manual commands, in the folder with FroggerReborn.csproj)
  dotnet restore
  dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
  Output: bin\Release\net8.0-windows\win-x64\publish\FroggerReborn.exe

  The .csproj already contains win-x64, SelfContained, PublishSingleFile,
  IncludeNativeLibrariesForSelfExtract and compression, so the commands above are enough.
  If Windows Forms ever needs a native file that cannot be embedded, it is extracted to a
  temp folder at first start (IncludeNativeLibrariesForSelfExtract); no extra files to ship.

QUICK DEV RUN
  dotnet run -c Release

CONTROLS
  Arrow keys / WASD ... hop one tile
  P ................... pause / resume          Esc ... pause (in game) / quit to menu (paused, game over)
  M ................... sound on/off            R / Enter / Space ... restart after Game Over
  Mouse ............... START GAME, RESTART, MENU and SOUND buttons

RULES
  Row 0 = five home slots, rows 1-5 = river (stand on logs/turtles; turtles dive!),
  row 6 = safe median, rows 7-11 = road, row 12 = start.
  Scoring: +10 per new row reached, +50 (+time bonus) per home, +500 for clearing a level.
  You lose a life when hit by a vehicle, falling in the water, being carried off screen,
  landing outside a free slot, or running out of time.
  Hi-score file: %LocalAppData%\FroggerReborn\highscore.txt

FILES
  Game.cs (all rules, no drawing) | Renderer.cs (all drawing) | GameForm.cs (window, input, loop)
  Sfx.cs (sounds) | Storage.cs (hi-score) | Program.cs | FroggerReborn.csproj | build.bat

VERIFICATION STATUS
  The source was written WITHOUT access to a .NET SDK, so it has NOT been compiled or run by
  its author. Please run build.bat; if the compiler reports errors, send them back to be fixed.

(c) 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space
