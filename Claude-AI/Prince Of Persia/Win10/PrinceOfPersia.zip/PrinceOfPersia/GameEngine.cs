namespace PrinceOfPersia;

public enum GameState { Title, Playing, Paused, Dead, LevelComplete, Victory }

public sealed class Particle
{
    public float X;
    public float Y;
    public float VX;
    public float VY;
    public float Gravity;
    public int Size;
    public int Life;
    public int MaxLife;
    public Color Color;
}

/// <summary>Game rules, state machine, interactions, hazards and camera. Updated 60 times per second.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 60f;

    public GameState State = GameState.Title;
    public int LevelIndex;
    public GameLevel Level;
    public readonly Player Player = new Player();
    public readonly HashSet<int> Triggered = new HashSet<int>();
    public readonly List<Particle> Particles = new List<Particle>();
    public int Frame;
    public float Time;
    public float TotalTime;
    public int Deaths;
    public float CamX;
    public float CamY;
    public string Message = "";
    public float MessageTimer;
    public string DeathReason = "";
    public float BannerTimer;
    public float ExitProgress;
    public bool ExitOpening;
    public float HurtFlash;

    private readonly Random rng = new Random();
    private readonly HashSet<int> shownHints = new HashSet<int>();
    private bool jumpRequest;
    private bool interactRequest;
    private float deathTimer;

    public int LevelCount { get { return LevelLibrary.All.Length; } }

    public bool ExitUnlocked
    {
        get
        {
            foreach (int id in Level.ExitNeeds)
            {
                if (!Triggered.Contains(id)) return false;
            }
            return true;
        }
    }

    public int ExitNeedsDone
    {
        get
        {
            int n = 0;
            foreach (int id in Level.ExitNeeds)
            {
                if (Triggered.Contains(id)) n++;
            }
            return n;
        }
    }

    public GameEngine()
    {
        foreach (LevelDef def in LevelLibrary.All)
        {
            GameLevel.Load(def); // validates every level before the game can start
        }
        Level = GameLevel.Load(LevelLibrary.All[0]);
        Player.Reset(Level.Start);
        SnapCamera();
    }

    // ------------------------------------------------------------------ flow control

    public void StartNewGame()
    {
        LevelIndex = 0;
        Deaths = 0;
        TotalTime = 0f;
        LoadLevel();
        State = GameState.Playing;
        Sfx.Play(SfxId.Start);
    }

    private void LoadLevel()
    {
        Level = GameLevel.Load(LevelLibrary.All[LevelIndex]);
        Triggered.Clear();
        shownHints.Clear();
        Particles.Clear();
        Player.Reset(Level.Start);
        Time = 0f;
        ExitOpening = false;
        ExitProgress = 0f;
        HurtFlash = 0f;
        deathTimer = 0f;
        jumpRequest = false;
        interactRequest = false;
        Message = "";
        MessageTimer = 0f;
        BannerTimer = 3.2f;
        SnapCamera();
    }

    public void RestartLevel()
    {
        LoadLevel();
        State = GameState.Playing;
    }

    private void NextLevel()
    {
        if (LevelIndex + 1 >= LevelLibrary.All.Length)
        {
            State = GameState.Victory;
            Sfx.Play(SfxId.Complete);
            return;
        }
        LevelIndex++;
        LoadLevel();
        State = GameState.Playing;
        Sfx.Play(SfxId.Start);
    }

    public void AutoPause()
    {
        if (State == GameState.Playing && !Player.Dead) State = GameState.Paused;
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                switch (State)
                {
                    case GameState.Title: StartNewGame(); break;
                    case GameState.Paused: State = GameState.Playing; break;
                    case GameState.Dead: RestartLevel(); break;
                    case GameState.LevelComplete: NextLevel(); break;
                    case GameState.Victory: State = GameState.Title; break;
                }
                break;
            case Keys.Escape:
                if (State == GameState.Playing) State = GameState.Paused;
                else if (State == GameState.Paused) State = GameState.Playing;
                else if (State == GameState.Dead || State == GameState.LevelComplete || State == GameState.Victory) State = GameState.Title;
                break;
            case Keys.R:
                if (State == GameState.Playing || State == GameState.Paused || State == GameState.Dead) RestartLevel();
                break;
            case Keys.M:
                if (State == GameState.Paused) State = GameState.Title;
                break;
            case Keys.N:
                Sfx.Muted = !Sfx.Muted;
                break;
            case Keys.Space:
                if (State == GameState.Title) StartNewGame();
                else if (State == GameState.Playing) jumpRequest = true;
                break;
            case Keys.Up:
            case Keys.W:
                if (State == GameState.Playing) interactRequest = true;
                break;
        }
    }

    // ------------------------------------------------------------------ main update

    public void Update(bool left, bool right, bool up, bool down)
    {
        Frame++;
        if (State != GameState.Playing)
        {
            jumpRequest = false;
            interactRequest = false;
            return;
        }

        float dt = Dt;
        Time += dt;
        TotalTime += dt;
        UpdateParticles();
        if (MessageTimer > 0f) MessageTimer -= dt;
        if (BannerTimer > 0f) BannerTimer -= dt;
        if (HurtFlash > 0f) HurtFlash = Math.Max(0f, HurtFlash - dt);

        UpdateTraps(dt);

        if (Player.Dead)
        {
            Player.UpdateDead(dt, Level);
            deathTimer += dt;
            UpdateCamera(dt);
            jumpRequest = false;
            interactRequest = false;
            if (deathTimer > 1.4f) State = GameState.Dead;
            return;
        }

        if (ExitOpening)
        {
            ExitProgress += dt / 1.0f;
            UpdateCamera(dt);
            if (ExitProgress >= 1f) State = GameState.LevelComplete;
            return;
        }

        PlayerInput inp = new PlayerInput();
        inp.Left = left;
        inp.Right = right;
        inp.Up = up;
        inp.Down = down;
        inp.Jump = jumpRequest;
        inp.Interact = interactRequest;
        jumpRequest = false;
        interactRequest = false;

        Player.Update(dt, Level, inp);
        HandlePlayerEvents();
        CheckCrumbles();
        if (inp.Interact) Interact();
        CheckPlates();
        CheckGateCrush();
        CheckHazards();
        CheckHints();
        UpdateCamera(dt);
    }

    private void HandlePlayerEvents()
    {
        Player p = Player;
        if (p.EvJump) Sfx.Play(SfxId.Jump);
        if (p.EvLand)
        {
            Sfx.Play(SfxId.Land);
            Dust(p.CenterX, p.FeetY, p.EvHardLand ? 12 : 6);
        }
        if (p.EvLethalFall) Kill("Падение с большой высоты");
    }

    private void UpdateTraps(float dt)
    {
        foreach (SpikeTrap s in Level.SpikeTraps) s.Update(Time);
        foreach (Blade b in Level.Blades) b.Update(Time);
        foreach (Gate g in Level.Gates) g.Update(dt, Time, Level, Triggered);
        foreach (Door d in Level.Doors) d.Update(dt, Level);
        foreach (Crumble k in Level.Crumbles)
        {
            k.Update(dt, Level);
            if (k.JustFell)
            {
                Sfx.Play(SfxId.Crumble);
                Debris(k.Col * Cfg.T + 20f, k.Row * Cfg.T + 20f, 14);
            }
        }
    }

    private void CheckCrumbles()
    {
        Player p = Player;
        if (!p.OnGround || p.Climbing) return;
        int row = (int)Math.Floor((p.FeetY + 0.5f) / Cfg.T);
        int c0 = (int)Math.Floor(p.X / Cfg.T);
        int c1 = (int)Math.Floor((p.X + Player.W - 0.01f) / Cfg.T);
        for (int c = c0; c <= c1; c++)
        {
            if (Level.Get(c, row) != Tile.Crumble) continue;
            Crumble? k = Level.CrumbleAt(c, row);
            if (k != null && k.State == CrumbleState.Idle)
            {
                k.Trigger();
                Sfx.Play(SfxId.Rumble);
            }
        }
    }

    private RectangleF PlayerBox(float inset)
    {
        return new RectangleF(Player.X + inset, Player.Y + inset, Player.W - inset * 2f, Player.H - inset * 2f);
    }

    private void CheckPlates()
    {
        Player p = Player;
        foreach (Trigger t in Level.Triggers)
        {
            if (!t.Plate || t.Pulled) continue;
            RectangleF box = PlayerBox(0f);
            bool overX = box.Right > t.Col * Cfg.T + 6 && box.Left < (t.Col + 1) * Cfg.T - 6;
            bool onIt = p.OnGround && Math.Abs(p.FeetY - (t.Row + 1) * Cfg.T) < 2f;
            if (overX && onIt)
            {
                Fire(t, "Плита нажата — ворота открываются!");
            }
        }
    }

    private void Fire(Trigger t, string text)
    {
        t.Pulled = true;
        Triggered.Add(t.Id);
        Sfx.Play(SfxId.Lever);
        if (Level.ExitNeeds.Length > 0 && Array.IndexOf(Level.ExitNeeds, t.Id) >= 0)
        {
            Say(text + "  (" + ExitNeedsDone + "/" + Level.ExitNeeds.Length + ")");
        }
        else
        {
            Say(text);
        }
    }

    private void Interact()
    {
        Player p = Player;
        RectangleF reach = new RectangleF(p.X - 20f, p.Y, Player.W + 40f, Player.H);

        // exit door
        Rectangle exit = new Rectangle(Level.ExitCell.X * Cfg.T, (Level.ExitCell.Y - 1) * Cfg.T, Cfg.T, 2 * Cfg.T);
        if (reach.IntersectsWith(exit))
        {
            if (ExitUnlocked)
            {
                ExitOpening = true;
                ExitProgress = 0f;
                Sfx.Play(SfxId.Door);
                Say("Дверь открыта — вперёд!");
            }
            else if (Level.ExitNeeds.Length > 0)
            {
                Say("Выход заперт: активируйте рычаги (" + ExitNeedsDone + "/" + Level.ExitNeeds.Length + ")");
                Sfx.Play(SfxId.Locked);
            }
            return;
        }

        // wooden doors
        foreach (Door d in Level.Doors)
        {
            if (d.State != DoorState.Closed) continue;
            if (!reach.IntersectsWith(d.Bounds)) continue;
            if (d.IsLocked(Triggered))
            {
                Say("Дверь заперта. Найдите рычаг.");
                Sfx.Play(SfxId.Locked);
            }
            else
            {
                d.Begin();
                Sfx.Play(SfxId.Door);
                Say("Дверь открывается…");
            }
            return;
        }

        // levers
        foreach (Trigger t in Level.Triggers)
        {
            if (t.Plate || t.Pulled) continue;
            if (reach.IntersectsWith(t.Bounds))
            {
                Fire(t, "Рычаг потянут!");
                return;
            }
        }
    }

    private void CheckGateCrush()
    {
        foreach (Gate g in Level.Gates)
        {
            if (!g.JustClosed) continue;
            RectangleF box = PlayerBox(2f);
            if (box.IntersectsWith(g.Bounds))
            {
                Kill("Вас раздавили ворота");
                return;
            }
        }
    }

    private void CheckHazards()
    {
        Player p = Player;
        if (p.Dead) return;
        RectangleF box = PlayerBox(4f);

        int c0 = (int)Math.Floor(p.X / Cfg.T) - 1;
        int c1 = (int)Math.Floor((p.X + Player.W) / Cfg.T) + 1;
        int r0 = (int)Math.Floor(p.Y / Cfg.T) - 1;
        int r1 = (int)Math.Floor((p.Y + Player.H) / Cfg.T) + 1;
        for (int r = r0; r <= r1; r++)
        {
            for (int c = c0; c <= c1; c++)
            {
                Tile t = Level.Get(c, r);
                bool deadly = false;
                if (t == Tile.Spikes) deadly = true;
                else if (t == Tile.TimedSpikes)
                {
                    SpikeTrap? s = Level.TimedSpikeAt(c, r);
                    if (s != null && s.Lethal) deadly = true;
                }
                if (!deadly) continue;
                RectangleF spike = new RectangleF(c * Cfg.T + 4, r * Cfg.T + 22, Cfg.T - 8, 18);
                if (box.IntersectsWith(spike))
                {
                    Kill("Вас пронзили шипы");
                    return;
                }
            }
        }

        foreach (Blade b in Level.Blades)
        {
            if (b.Hits(box.X, box.Y, box.Width, box.Height))
            {
                Kill("Вас рассекло лезвие");
                return;
            }
        }

        if (p.Y > Level.Rows * Cfg.T + 60f) Kill("Вы упали в пропасть");
    }

    private void CheckHints()
    {
        Player p = Player;
        int c = (int)Math.Floor(p.CenterX / Cfg.T);
        int r = (int)Math.Floor((p.Y + Player.H / 2f) / Cfg.T);
        for (int i = 0; i < Level.Hints.Length; i++)
        {
            HintDef h = Level.Hints[i];
            if (shownHints.Contains(i)) continue;
            if (c >= h.C0 && c <= h.C1 && r >= h.R0 && r <= h.R1)
            {
                shownHints.Add(i);
                Say(h.Text);
            }
        }
    }

    private void Say(string text)
    {
        Message = text;
        MessageTimer = 4.0f;
    }

    private void Kill(string reason)
    {
        if (Player.Dead) return;
        Player.Kill();
        DeathReason = reason;
        Deaths++;
        deathTimer = 0f;
        HurtFlash = 0.5f;
        Sfx.Play(SfxId.Death);
        Burst(Player.CenterX, Player.Y + 26f, 14, Color.FromArgb(200, 40, 40), Color.FromArgb(255, 150, 90), 3f);
    }

    // ------------------------------------------------------------------ camera and effects

    private void SnapCamera()
    {
        CamX = TargetCamX();
        CamY = TargetCamY();
    }

    private float TargetCamX()
    {
        float max = Math.Max(0f, Level.Cols * Cfg.T - Cfg.LogicalW);
        float t = Player.CenterX - Cfg.LogicalW / 2f + Player.Facing * 50f;
        return Math.Max(0f, Math.Min(max, t));
    }

    private float TargetCamY()
    {
        float max = Math.Max(0f, Level.Rows * Cfg.T - Cfg.ViewH);
        float t = Player.Y + Player.H / 2f - Cfg.ViewH / 2f;
        return Math.Max(0f, Math.Min(max, t));
    }

    private void UpdateCamera(float dt)
    {
        float k = Math.Min(1f, dt * 6f);
        CamX += (TargetCamX() - CamX) * k;
        CamY += (TargetCamY() - CamY) * k;
    }

    private void UpdateParticles()
    {
        for (int i = Particles.Count - 1; i >= 0; i--)
        {
            Particle p = Particles[i];
            p.VY += p.Gravity;
            p.X += p.VX;
            p.Y += p.VY;
            p.Life--;
            if (p.Life <= 0) Particles.RemoveAt(i);
        }
    }

    private void Dust(float x, float y, int count)
    {
        Burst(x, y - 2f, count, Color.FromArgb(222, 180, 130), Color.FromArgb(170, 120, 90), 1.8f);
    }

    private void Debris(float x, float y, int count)
    {
        Burst(x, y, count, Color.FromArgb(214, 150, 90), Color.FromArgb(120, 70, 50), 3f);
    }

    private void Burst(float x, float y, int count, Color c1, Color c2, float speed)
    {
        for (int i = 0; i < count; i++)
        {
            double a = rng.NextDouble() * Math.PI * 2.0;
            float sp = (float)(rng.NextDouble() * speed + speed * 0.3);
            Particle p = new Particle();
            p.X = x;
            p.Y = y;
            p.VX = (float)Math.Cos(a) * sp;
            p.VY = (float)Math.Sin(a) * sp - 1.2f;
            p.Gravity = 0.18f;
            p.Size = 2 + rng.Next(3) * 2;
            p.MaxLife = 28 + rng.Next(14);
            p.Life = p.MaxLife;
            p.Color = (i % 2 == 0) ? c1 : c2;
            Particles.Add(p);
        }
    }
}
