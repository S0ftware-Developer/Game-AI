namespace PrinceOfPersia;

/// <summary>Keyboard state handed to the player each simulation step.</summary>
public sealed class PlayerInput
{
    public bool Left;
    public bool Right;
    public bool Up;
    public bool Down;
    public bool Jump;       // true only on the step where Space was pressed
    public bool Interact;   // true only on the step where Up was pressed
}

/// <summary>
/// The prince: tile-collision platformer physics with acceleration, coyote time, jump buffering,
/// ladders, fall distance tracking and death. Fixed time step (1/60 s).
/// </summary>
public sealed class Player
{
    public const int W = 24;
    public const int H = 52;

    public const float Gravity = 1800f;
    public const float MaxFall = 900f;
    public const float JumpSpeed = 600f;     // apex about 100 px
    public const float RunSpeed = 230f;
    public const float GroundAccel = 1500f;
    public const float GroundDecel = 1900f;
    public const float AirAccel = 800f;
    public const float ClimbSpeed = 130f;
    public const float LethalFall = 300f;    // px from the highest point to the landing

    public float X;
    public float Y;
    public float VX;
    public float VY;
    public int Facing = 1;
    public bool OnGround;
    public bool Climbing;
    public bool ClimbMoving;
    public bool Skidding;
    public bool Dead;
    public float DeadTime;
    public float LandTimer;
    public float AnimTime;

    // events consumed by the engine after every step
    public bool EvJump;
    public bool EvLand;
    public bool EvHardLand;
    public bool EvLethalFall;

    private int climbCol;
    private float coyote;
    private float jumpBuffer;
    private float ignoreTop;
    private float peakFeet;

    public float CenterX { get { return X + W / 2f; } }
    public float FeetY { get { return Y + H; } }

    public void Reset(Point startCell)
    {
        X = startCell.X * Cfg.T + (Cfg.T - W) / 2f;
        Y = (startCell.Y + 1) * Cfg.T - H;
        VX = 0f;
        VY = 0f;
        Facing = 1;
        OnGround = true;
        Climbing = false;
        ClimbMoving = false;
        Skidding = false;
        Dead = false;
        DeadTime = 0f;
        LandTimer = 0f;
        AnimTime = 0f;
        coyote = 0f;
        jumpBuffer = 0f;
        ignoreTop = 0f;
        peakFeet = FeetY;
        ClearEvents();
    }

    private void ClearEvents()
    {
        EvJump = false;
        EvLand = false;
        EvHardLand = false;
        EvLethalFall = false;
    }

    public void Kill()
    {
        if (Dead) return;
        Dead = true;
        DeadTime = 0f;
        Climbing = false;
        VX = -Facing * 70f;
        VY = -180f;
        OnGround = false;
    }

    private static float MoveToward(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    public void Update(float dt, GameLevel lv, PlayerInput inp)
    {
        ClearEvents();
        AnimTime += dt;
        jumpBuffer = Math.Max(0f, jumpBuffer - dt);
        if (inp.Jump) jumpBuffer = 0.12f;
        coyote = OnGround ? 0.09f : Math.Max(0f, coyote - dt);
        ignoreTop = Math.Max(0f, ignoreTop - dt);
        if (LandTimer > 0f) LandTimer = Math.Max(0f, LandTimer - dt);

        int dir = (inp.Right ? 1 : 0) - (inp.Left ? 1 : 0);

        if (!Climbing && (inp.Up || inp.Down)) TryGrabLadder(lv, inp);
        if (Climbing)
        {
            UpdateClimb(dt, lv, inp, dir);
            return;
        }

        // ---- horizontal control
        float maxSpeed = RunSpeed;
        if (LandTimer > 0f && OnGround) maxSpeed *= 0.35f;
        Skidding = false;
        if (dir != 0)
        {
            float accel = OnGround ? GroundAccel : AirAccel;
            if (OnGround && VX != 0f && Math.Sign(VX) != dir)
            {
                accel *= 1.8f;
                Skidding = Math.Abs(VX) > 100f;
            }
            VX = MoveToward(VX, dir * maxSpeed, accel * dt);
            Facing = dir;
        }
        else if (OnGround)
        {
            VX = MoveToward(VX, 0f, GroundDecel * dt);
            Skidding = Math.Abs(VX) > 110f;
        }

        // ---- jump (needs a fresh key press; coyote time and a short buffer make it forgiving)
        if (jumpBuffer > 0f && coyote > 0f)
        {
            VY = -JumpSpeed;
            OnGround = false;
            coyote = 0f;
            jumpBuffer = 0f;
            EvJump = true;
            peakFeet = FeetY;
        }

        // ---- physics
        VY = Math.Min(MaxFall, VY + Gravity * dt);
        bool wasGround = OnGround;
        float feetBefore = FeetY;
        MoveX(VX * dt, lv);
        bool landed = MoveY(VY * dt, lv);

        if (landed)
        {
            if (!wasGround)
            {
                float drop = FeetY - peakFeet;
                if (drop > LethalFall) EvLethalFall = true;
                else if (drop > 120f)
                {
                    LandTimer = 0.22f;
                    EvHardLand = true;
                }
                if (drop > 24f) EvLand = true;
            }
            OnGround = true;
            peakFeet = FeetY;
        }
        else
        {
            if (wasGround) peakFeet = feetBefore;
            peakFeet = Math.Min(peakFeet, FeetY);
            OnGround = false;
        }
    }

    // ------------------------------------------------------------------ ladders

    private void TryGrabLadder(GameLevel lv, PlayerInput inp)
    {
        int cx = (int)Math.Floor(CenterX / Cfg.T);
        if (Math.Abs(CenterX - (cx * Cfg.T + Cfg.T / 2f)) > 18f) return;

        int rTop = (int)Math.Floor((Y + 6f) / Cfg.T);
        int rBot = (int)Math.Floor((FeetY - 1f) / Cfg.T);
        bool ladderBody = false;
        for (int r = rTop; r <= rBot; r++)
        {
            if (lv.Get(cx, r) == Tile.Ladder) ladderBody = true;
        }

        if (inp.Up && ladderBody)
        {
            StartClimb(cx);
            return;
        }

        int below = (int)Math.Floor((FeetY + 1f) / Cfg.T);
        if (inp.Down && OnGround && lv.Get(cx, below) == Tile.Ladder)
        {
            Y += 3f;
            ignoreTop = 0.3f;
            StartClimb(cx);
            return;
        }
        if (inp.Down && ladderBody) StartClimb(cx);
    }

    private void StartClimb(int col)
    {
        Climbing = true;
        climbCol = col;
        VX = 0f;
        VY = 0f;
        OnGround = false;
        coyote = 0f;
        peakFeet = FeetY;
    }

    private void UpdateClimb(float dt, GameLevel lv, PlayerInput inp, int dir)
    {
        ClimbMoving = false;
        Skidding = false;
        float target = climbCol * Cfg.T + Cfg.T / 2f;
        float shift = target - CenterX;
        X += Math.Max(-240f * dt, Math.Min(240f * dt, shift));

        if (inp.Jump)
        {
            Climbing = false;
            VY = -JumpSpeed * 0.7f;
            VX = dir * RunSpeed * 0.7f;
            if (dir != 0) Facing = dir;
            ignoreTop = 0.25f;
            jumpBuffer = 0f;
            coyote = 0f;
            EvJump = true;
            peakFeet = FeetY;
            return;
        }

        int dirV = (inp.Down ? 1 : 0) - (inp.Up ? 1 : 0);
        if (dirV == 0) return;

        int fr = (int)Math.Floor((FeetY - 1f) / Cfg.T);
        if (lv.Get(climbCol, fr) != Tile.Ladder)
        {
            Climbing = false;
            return;
        }
        int rt = fr;
        while (lv.Get(climbCol, rt - 1) == Tile.Ladder) rt--;
        int rb = fr;
        while (lv.Get(climbCol, rb + 1) == Tile.Ladder) rb++;
        float topFeet = rt * Cfg.T;
        float botFeet = (rb + 1) * Cfg.T;
        float step = dirV * ClimbSpeed * dt;
        float newFeet = FeetY + step;

        if (dirV < 0 && newFeet <= topFeet)
        {
            Y = topFeet - H;
            Climbing = false;
            OnGround = true;
            VY = 0f;
            peakFeet = FeetY;
            return;
        }
        if (dirV > 0 && newFeet >= botFeet)
        {
            Y = botFeet - H;
            Climbing = false;
            OnGround = lv.IsSolid(climbCol, rb + 1);
            VY = 0f;
            peakFeet = FeetY;
            return;
        }
        Y += step;
        ClimbMoving = true;
        peakFeet = FeetY;
    }

    // ------------------------------------------------------------------ collision

    private void MoveX(float dx, GameLevel lv)
    {
        X += dx;
        int r0 = (int)Math.Floor(Y / Cfg.T);
        int r1 = (int)Math.Floor((Y + H - 0.01f) / Cfg.T);
        if (dx > 0f)
        {
            int c = (int)Math.Floor((X + W - 0.01f) / Cfg.T);
            for (int r = r0; r <= r1; r++)
            {
                if (lv.IsSolid(c, r))
                {
                    X = c * Cfg.T - W;
                    VX = 0f;
                    break;
                }
            }
        }
        else if (dx < 0f)
        {
            int c = (int)Math.Floor(X / Cfg.T);
            for (int r = r0; r <= r1; r++)
            {
                if (lv.IsSolid(c, r))
                {
                    X = (c + 1) * Cfg.T;
                    VX = 0f;
                    break;
                }
            }
        }
    }

    /// <summary>Moves vertically and returns true when the player came to rest on a floor.</summary>
    private bool MoveY(float dy, GameLevel lv)
    {
        float prevBottom = FeetY;
        Y += dy;
        int c0 = (int)Math.Floor(X / Cfg.T);
        int c1 = (int)Math.Floor((X + W - 0.01f) / Cfg.T);
        if (dy > 0f)
        {
            int r = (int)Math.Floor((FeetY - 0.01f) / Cfg.T);
            for (int c = c0; c <= c1; c++)
            {
                bool solid = lv.IsSolid(c, r);
                if (!solid && ignoreTop <= 0f && lv.Get(c, r) == Tile.Ladder && lv.Get(c, r - 1) != Tile.Ladder
                    && prevBottom <= r * Cfg.T + 0.01f)
                {
                    solid = true; // the top of a ladder can be stood on
                }
                if (solid)
                {
                    Y = r * Cfg.T - H;
                    VY = 0f;
                    return true;
                }
            }
        }
        else if (dy < 0f)
        {
            int r = (int)Math.Floor(Y / Cfg.T);
            for (int c = c0; c <= c1; c++)
            {
                if (lv.IsSolid(c, r))
                {
                    Y = (r + 1) * Cfg.T;
                    VY = 0f;
                    break;
                }
            }
        }
        return false;
    }

    /// <summary>After death the body keeps obeying gravity until it comes to rest.</summary>
    public void UpdateDead(float dt, GameLevel lv)
    {
        DeadTime += dt;
        AnimTime += dt;
        VX = MoveToward(VX, 0f, 600f * dt);
        VY = Math.Min(MaxFall, VY + Gravity * dt);
        MoveX(VX * dt, lv);
        MoveY(VY * dt, lv);
    }
}
