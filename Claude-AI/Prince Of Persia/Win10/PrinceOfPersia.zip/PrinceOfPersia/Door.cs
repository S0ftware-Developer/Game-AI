namespace PrinceOfPersia;

/// <summary>A portcullis. Either opened by a lever/plate (Id) or cycling on a timer.</summary>
public sealed class Gate
{
    public const float CycleTime = 6f;

    public readonly int Id;
    public readonly int Col;
    public readonly int Row;
    public readonly int Height;
    public readonly bool Timed;
    private readonly float phase;
    public float Open;          // 0 closed .. 1 fully open
    public bool Warning;        // timed gate about to close
    public bool Solid = true;
    public bool JustClosed;

    public Gate(GateDef d)
    {
        Id = d.Id;
        Col = d.Col;
        Row = d.Row;
        Height = d.Height;
        Timed = d.Timed;
        phase = d.Phase;
        Open = 0f;
    }

    public void Update(float dt, float time, GameLevel lv, HashSet<int> triggered)
    {
        JustClosed = false;
        if (Timed)
        {
            float t = (time + phase * CycleTime) % CycleTime;
            Warning = false;
            if (t < 2.4f) { Open = 1f; Warning = t > 1.7f; }
            else if (t < 3.0f) Open = 1f - (t - 2.4f) / 0.6f;
            else if (t < 5.2f) Open = 0f;
            else Open = (t - 5.2f) / 0.8f;
        }
        else if (triggered.Contains(Id))
        {
            Open = Math.Min(1f, Open + dt * 0.9f);
        }

        bool solidNow = Open < 0.5f;
        if (solidNow != Solid || dt == 0f)
        {
            if (solidNow && !Solid) JustClosed = true;
            Solid = solidNow;
            Apply(lv);
        }
    }

    private void Apply(GameLevel lv)
    {
        for (int k = 0; k < Height; k++)
        {
            lv.Cells[Col, Row + k] = Solid ? Tile.Closed : Tile.Interior;
        }
    }

    public Rectangle Bounds
    {
        get { return new Rectangle(Col * Cfg.T, Row * Cfg.T, Cfg.T, Height * Cfg.T); }
    }
}

public enum DoorState { Closed, Opening, Open }

/// <summary>A wooden door (two tiles tall). Opened with the Up key, optionally locked until a trigger fires.</summary>
public sealed class Door
{
    public const float OpenTime = 0.6f;

    public readonly int Col;
    public readonly int Row;       // bottom cell
    public readonly int LockId;
    public DoorState State = DoorState.Closed;
    public float Openness;

    public Door(DoorDef d)
    {
        Col = d.Col;
        Row = d.Row;
        LockId = d.LockId;
    }

    public bool IsLocked(HashSet<int> triggered)
    {
        return LockId != 0 && !triggered.Contains(LockId);
    }

    public void Begin()
    {
        if (State == DoorState.Closed) State = DoorState.Opening;
    }

    public void Update(float dt, GameLevel lv)
    {
        if (State != DoorState.Opening) return;
        Openness += dt / OpenTime;
        if (Openness >= 1f)
        {
            Openness = 1f;
            State = DoorState.Open;
            lv.Cells[Col, Row] = Tile.Interior;
            lv.Cells[Col, Row - 1] = Tile.Interior;
        }
    }

    public Rectangle Bounds
    {
        get { return new Rectangle(Col * Cfg.T, (Row - 1) * Cfg.T, Cfg.T, 2 * Cfg.T); }
    }
}

/// <summary>A lever (pulled with Up) or a pressure plate (stepped on). Fires its Id once.</summary>
public sealed class Trigger
{
    public readonly int Id;
    public readonly int Col;
    public readonly int Row;
    public readonly bool Plate;
    public bool Pulled;

    public Trigger(TriggerDef d)
    {
        Id = d.Id;
        Col = d.Col;
        Row = d.Row;
        Plate = d.Plate;
    }

    public Rectangle Bounds
    {
        get { return new Rectangle(Col * Cfg.T, Row * Cfg.T, Cfg.T, Cfg.T); }
    }
}
