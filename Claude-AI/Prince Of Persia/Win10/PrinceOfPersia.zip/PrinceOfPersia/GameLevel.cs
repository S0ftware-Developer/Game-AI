namespace PrinceOfPersia;

public static class Cfg
{
    public const int T = 40;            // tile size in pixels
    public const int LogicalW = 800;
    public const int HudH = 48;
    public const int ViewH = 560;       // visible world height
    public const int FooterH = 32;
    public const int LogicalH = 640;    // HudH + ViewH + FooterH
}

/// <summary>Terrain tiles. Interior/Sky/Window/Torch are passable background; Wall, Crumble and Closed are solid.</summary>
public enum Tile
{
    Interior,
    Sky,
    Window,
    Torch,
    Wall,
    Ladder,
    Spikes,
    TimedSpikes,
    Crumble,
    Closed
}

public sealed class GateDef
{
    public readonly int Id, Col, Row, Height;
    public readonly bool Timed;
    public readonly float Phase;
    public GateDef(int id, int col, int row, int height, bool timed, float phase)
    {
        Id = id; Col = col; Row = row; Height = height; Timed = timed; Phase = phase;
    }
}

public sealed class TriggerDef
{
    public readonly int Id, Col, Row;
    public readonly bool Plate;
    public TriggerDef(int id, int col, int row, bool plate)
    {
        Id = id; Col = col; Row = row; Plate = plate;
    }
}

public sealed class DoorDef
{
    public readonly int Col, Row, LockId;
    public DoorDef(int col, int row, int lockId)
    {
        Col = col; Row = row; LockId = lockId;
    }
}

public sealed class BladeDef
{
    public readonly int Col, Row;
    public readonly float Length, Period, Phase, Amplitude;
    public BladeDef(int col, int row, float length, float period, float phase, float amplitude)
    {
        Col = col; Row = row; Length = length; Period = period; Phase = phase; Amplitude = amplitude;
    }
}

public sealed class HintDef
{
    public readonly int C0, R0, C1, R1;
    public readonly string Text;
    public HintDef(int c0, int r0, int c1, int r1, string text)
    {
        C0 = c0; R0 = r0; C1 = c1; R1 = r1; Text = text;
    }
}

public sealed class LevelDef
{
    public readonly string Name, Subtitle;
    public readonly string[] Map;
    public readonly GateDef[] Gates;
    public readonly TriggerDef[] Triggers;
    public readonly DoorDef[] Doors;
    public readonly BladeDef[] Blades;
    public readonly HintDef[] Hints;
    public readonly int[] ExitNeeds;

    public LevelDef(string name, string subtitle, string[] map, GateDef[] gates, TriggerDef[] triggers,
        DoorDef[] doors, BladeDef[] blades, HintDef[] hints, int[] exitNeeds)
    {
        Name = name; Subtitle = subtitle; Map = map; Gates = gates; Triggers = triggers;
        Doors = doors; Blades = blades; Hints = hints; ExitNeeds = exitNeeds;
    }
}

/// <summary>
/// Map legend:  '.' palace interior   ' ' open sky   '#' stone   'H' ladder   '^' floor spikes
///              '*' timed spikes      'c' crumbling slab   'o' window   't' wall torch
///              'P' player start      'E' exit door (bottom cell)
/// Gates, doors, levers/plates and blades are declared next to each map.
/// </summary>
public static class LevelLibrary
{
    public static readonly LevelDef[] All =
    {
        new LevelDef("Sunset Entrance", "Вход во дворец", new[]
        {
            "                    ################################", // 0
            "                    ################################", // 1
            "                    ################################", // 2
            "                    ##........................#....#", // 3
            "                    ##.....o.......o.......o..#....#", // 4
            "                    ##........t.........t.....#....#", // 5
            "                    ##.t.......^.^^...........#....#", // 6
            "                    ##..####H########ccc####H##....#", // 7
            "                    ##......H...............H.#....#", // 8
            "                    ##....t.H.....t......t..H......#", // 9
            "                ##  ........H...............H......#", // 10
            "   P          # ##  ....^...H...............H....E.#", // 11
            "###########  #######################################", // 12
            "###########  #######################################", // 13
            "###########  #######################################", // 14
            "###########  #######################################" // 15
        },
        new[] { new GateDef(1, 46, 9, 3, false, 0.0f) },
        new[] { new TriggerDef(1, 41, 6, false) },
        new[] { new DoorDef(21, 11, 0) },
        new BladeDef[0],
        new[] { new HintDef(0, 0, 9, 11, "← → — бег,  ПРОБЕЛ — прыжок. Перепрыгните пропасть!"), new HintDef(13, 0, 19, 11, "Перепрыгивайте ступени. У двери нажмите ↑"), new HintDef(22, 0, 26, 11, "Шипы! Разбегитесь и перепрыгните"), new HintDef(26, 0, 30, 11, "У лестницы нажмите ↑ — подняться"), new HintDef(36, 0, 40, 6, "Плиты рушатся — не задерживайтесь!"), new HintDef(40, 0, 43, 6, "У рычага нажмите ↑"), new HintDef(44, 7, 46, 11, "Ворота открыты? Идите к выходу и нажмите ↑") },
        new int[0]),
        new LevelDef("Hall of Blades", "Зал клинков", new[]
        {
            "########################################################", // 0
            "########################################################", // 1
            "########################################################", // 2
            "#.....############...............#...................#.#", // 3
            "#.....####o#######............o..#..............o......#", // 4
            "#.....############...............#.....................#", // 5
            "#.....############...............#....................E#", // 6
            "#................................#..##H###...cc...######", // 7
            "#................................#....H..#.............#", // 8
            "#...t.......t...........t......t....t.H..#.............#", // 9
            "#......t.........t....................H..#.............#", // 10
            "#.P.......................***.........H..#.............#", // 11
            "####################...##################...............", // 12
            "####################...##################...............", // 13
            "####################...##################...............", // 14
            "####################...##################..............." // 15
        },
        new[] { new GateDef(1, 33, 9, 3, true, 0.0f), new GateDef(2, 53, 4, 3, false, 0.0f) },
        new[] { new TriggerDef(2, 50, 6, true) },
        new DoorDef[0],
        new[] { new BladeDef(9, 7, 160.0f, 3.0f, 0.0f, 62.0f), new BladeDef(14, 7, 160.0f, 3.0f, 0.5f, 62.0f), new BladeDef(43, 3, 120.0f, 3.2f, 0.25f, 62.0f) },
        new[] { new HintDef(1, 0, 5, 11, "Лезвия качаются по ритму — ждите момент"), new HintDef(18, 0, 23, 11, "Пропасть в три клетки — прыгайте с разбега"), new HintDef(24, 0, 29, 11, "Шипы выдвигаются по таймеру — следите за вспышкой"), new HintDef(29, 0, 33, 11, "Ворота закрываются — проходите, пока открыты"), new HintDef(36, 0, 40, 6, "Осторожно: шахта. Падение — смерть"), new HintDef(49, 0, 52, 6, "Нажмите на плиту — ворота откроются") },
        new int[0]),
        new LevelDef("Royal Sunset Chamber", "Царская палата", new[]
        {
            "############################################################", // 0
            "############################################################", // 1
            "##.....................#...................................#", // 2
            "##....o...................o...t.....o.............t...o....#", // 3
            "##........t................................................#", // 4
            "##..............^^.............................**........E.#", // 5
            "#########....###############################H###############", // 6
            "##....................########..............H..............#", // 7
            "##....................########...t..........H..............#", // 8
            "##....................########..............H..........t...#", // 9
            "##...t......t.......t.##############H#######################", // 10
            "##..................................H......................#", // 11
            "##..................................H....t.................#", // 12
            "##P.....***..^......................H........^....***......#", // 13
            "################cccc########################################", // 14
            "################....########################################" // 15
        },
        new[] { new GateDef(1, 23, 3, 3, true, 0.0f) },
        new[] { new TriggerDef(1, 3, 5, false), new TriggerDef(2, 57, 13, false) },
        new DoorDef[0],
        new[] { new BladeDef(25, 11, 88.0f, 3.0f, 0.0f, 65.0f), new BladeDef(30, 11, 88.0f, 3.0f, 0.5f, 65.0f), new BladeDef(40, 7, 80.0f, 2.8f, 0.2f, 65.0f), new BladeDef(7, 2, 132.0f, 3.0f, 0.0f, 62.0f), new BladeDef(54, 2, 132.0f, 3.2f, 0.6f, 62.0f) },
        new[] { new HintDef(2, 7, 7, 13, "Лёгкая пробежка. Шипы — по таймеру"), new HintDef(14, 7, 21, 13, "Мост рассыпается — не останавливайтесь!"), new HintDef(22, 11, 29, 13, "Лезвия — выбирайте момент"), new HintDef(36, 11, 40, 13, "Лестница вверх — ↑"), new HintDef(53, 11, 58, 13, "Рычаг №2 — нажмите ↑"), new HintDef(2, 2, 6, 5, "Рычаг №1 — нажмите ↑"), new HintDef(50, 2, 58, 5, "Выход открыт после двух рычагов") },
        new[] { 1, 2 })
    };
}

/// <summary>A loaded, playable level: terrain grid plus live trap and door objects.</summary>
public sealed class GameLevel
{
    public readonly int Cols;
    public readonly int Rows;
    public readonly Tile[,] Cells;
    public readonly string Name;
    public readonly string Subtitle;
    public Point Start;
    public Point ExitCell;
    public readonly int[] ExitNeeds;
    public readonly List<SpikeTrap> SpikeTraps = new List<SpikeTrap>();
    public readonly List<Crumble> Crumbles = new List<Crumble>();
    public readonly List<Gate> Gates = new List<Gate>();
    public readonly List<Door> Doors = new List<Door>();
    public readonly List<Trigger> Triggers = new List<Trigger>();
    public readonly List<Blade> Blades = new List<Blade>();
    public readonly HintDef[] Hints;

    private GameLevel(int cols, int rows, string name, string subtitle, int[] exitNeeds, HintDef[] hints)
    {
        Cols = cols;
        Rows = rows;
        Cells = new Tile[cols, rows];
        Name = name;
        Subtitle = subtitle;
        ExitNeeds = exitNeeds;
        Hints = hints;
    }

    /// <summary>Terrain lookup. Left, right and top edges behave like walls; below the map is an open void.</summary>
    public Tile Get(int c, int r)
    {
        if (c < 0 || c >= Cols || r < 0) return Tile.Wall;
        if (r >= Rows) return Tile.Interior;
        return Cells[c, r];
    }

    public bool IsSolid(int c, int r)
    {
        Tile t = Get(c, r);
        return t == Tile.Wall || t == Tile.Crumble || t == Tile.Closed;
    }

    public SpikeTrap? TimedSpikeAt(int c, int r)
    {
        foreach (SpikeTrap s in SpikeTraps)
        {
            if (s.Col == c && s.Row == r) return s;
        }
        return null;
    }

    public Crumble? CrumbleAt(int c, int r)
    {
        foreach (Crumble k in Crumbles)
        {
            if (k.Col == c && k.Row == r) return k;
        }
        return null;
    }

    /// <summary>True when a standing character in cell (c,r) has something under its feet.</summary>
    private bool Supported(int c, int r)
    {
        Tile below = Get(c, r + 1);
        if (below == Tile.Wall || below == Tile.Crumble || below == Tile.Closed) return true;
        return below == Tile.Ladder && Get(c, r) != Tile.Ladder;
    }

    public static GameLevel Load(LevelDef d)
    {
        int rows = d.Map.Length;
        if (rows < 8) throw new InvalidDataException(d.Name + ": the map is too small.");
        int cols = d.Map[0].Length;
        GameLevel lv = new GameLevel(cols, rows, d.Name, d.Subtitle, d.ExitNeeds, d.Hints);
        int starts = 0;
        int exits = 0;

        for (int r = 0; r < rows; r++)
        {
            if (d.Map[r].Length != cols)
                throw new InvalidDataException(d.Name + ": row " + r + " has " + d.Map[r].Length + " columns, expected " + cols + ".");
            for (int c = 0; c < cols; c++)
            {
                char ch = d.Map[r][c];
                Tile t;
                switch (ch)
                {
                    case '.': t = Tile.Interior; break;
                    case ' ': t = Tile.Sky; break;
                    case '#': t = Tile.Wall; break;
                    case 'H': t = Tile.Ladder; break;
                    case '^': t = Tile.Spikes; break;
                    case '*': t = Tile.TimedSpikes; lv.SpikeTraps.Add(new SpikeTrap(c, r)); break;
                    case 'c': t = Tile.Crumble; lv.Crumbles.Add(new Crumble(c, r)); break;
                    case 'o': t = Tile.Window; break;
                    case 't': t = Tile.Torch; break;
                    case 'P': t = Tile.Interior; lv.Start = new Point(c, r); starts++; break;
                    case 'E': t = Tile.Interior; lv.ExitCell = new Point(c, r); exits++; break;
                    default:
                        throw new InvalidDataException(d.Name + ": unknown map character '" + ch + "' at " + c + "," + r + ".");
                }
                lv.Cells[c, r] = t;
            }
        }
        if (starts != 1) throw new InvalidDataException(d.Name + ": needs exactly one start (P).");
        if (exits != 1) throw new InvalidDataException(d.Name + ": needs exactly one exit (E).");

        foreach (GateDef g in d.Gates)
        {
            if (g.Col < 0 || g.Col >= cols || g.Row < 1 || g.Row + g.Height > rows)
                throw new InvalidDataException(d.Name + ": a gate is outside the map.");
            lv.Gates.Add(new Gate(g));
        }
        foreach (DoorDef dr in d.Doors)
        {
            if (dr.Col < 0 || dr.Col >= cols || dr.Row < 1 || dr.Row >= rows)
                throw new InvalidDataException(d.Name + ": a door is outside the map.");
            lv.Doors.Add(new Door(dr));
            lv.Cells[dr.Col, dr.Row] = Tile.Closed;
            lv.Cells[dr.Col, dr.Row - 1] = Tile.Closed;
        }
        foreach (TriggerDef tr in d.Triggers)
        {
            if (tr.Col < 0 || tr.Col >= cols || tr.Row < 0 || tr.Row >= rows)
                throw new InvalidDataException(d.Name + ": a lever or plate is outside the map.");
            lv.Triggers.Add(new Trigger(tr));
        }
        foreach (BladeDef b in d.Blades)
        {
            if (b.Col < 0 || b.Col >= cols || b.Row < 0 || b.Row >= rows)
                throw new InvalidDataException(d.Name + ": a blade is anchored outside the map.");
            lv.Blades.Add(new Blade(b));
        }
        foreach (int need in d.ExitNeeds)
        {
            bool found = false;
            foreach (TriggerDef tr in d.Triggers)
            {
                if (tr.Id == need) found = true;
            }
            if (!found) throw new InvalidDataException(d.Name + ": the exit needs trigger " + need + " which does not exist.");
        }

        // starting gate state (closed gates become solid)
        foreach (Gate g in lv.Gates) g.Update(0f, 0f, lv, new HashSet<int>());

        Point s = lv.Start;
        if (lv.IsSolid(s.X, s.Y) || lv.IsSolid(s.X, s.Y - 1) || !lv.Supported(s.X, s.Y))
            throw new InvalidDataException(d.Name + ": the start position is blocked or has no floor.");
        Point e = lv.ExitCell;
        if (lv.IsSolid(e.X, e.Y) || lv.IsSolid(e.X, e.Y - 1) || !lv.Supported(e.X, e.Y))
            throw new InvalidDataException(d.Name + ": the exit has no floor or no headroom.");
        return lv;
    }
}
