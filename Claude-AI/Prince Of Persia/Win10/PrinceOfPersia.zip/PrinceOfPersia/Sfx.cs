using System.Media;
using System.Text;

namespace PrinceOfPersia;

public enum SfxId { Jump, Land, Crumble, Rumble, Lever, Door, Locked, Death, Complete, Start }

/// <summary>Sound effects synthesised at start-up as 16-bit mono WAV data held in memory (no files).</summary>
public static class Sfx
{
    private const int Rate = 22050;
    private static readonly Dictionary<SfxId, SoundPlayer> Players = new Dictionary<SfxId, SoundPlayer>();
    private static readonly Random Rng = new Random(5);
    private static bool inited;
    public static bool Muted;

    public static void Init()
    {
        if (inited) return;
        inited = true;
        try
        {
            Add(SfxId.Jump, Tone(260, 460, 110, 0.28, false));
            Add(SfxId.Land, Cat(Noise(40, 0.25), Tone(130, 60, 80, 0.35, true)));
            Add(SfxId.Crumble, Cat(Noise(140, 0.35), Tone(90, 50, 160, 0.25, true)));
            Add(SfxId.Rumble, Cat(Noise(60, 0.18), Tone(80, 70, 90, 0.22, true)));
            Add(SfxId.Lever, Cat(Tone(520, 520, 40, 0.28, true), Tone(300, 300, 70, 0.28, true)));
            Add(SfxId.Door, Cat(Tone(180, 150, 160, 0.26, true), Tone(150, 120, 200, 0.26, true)));
            Add(SfxId.Locked, Cat(Tone(160, 160, 80, 0.30, true), Tone(120, 120, 120, 0.30, true)));
            Add(SfxId.Death, Cat(Noise(50, 0.30), Tone(320, 50, 520, 0.38, true)));
            Add(SfxId.Complete, Cat(Tone(392, 392, 110, 0.30, false), Tone(523, 523, 110, 0.30, false), Tone(659, 659, 110, 0.30, false), Tone(784, 784, 260, 0.30, false)));
            Add(SfxId.Start, Cat(Tone(330, 330, 90, 0.28, false), Tone(440, 440, 90, 0.28, false), Tone(587, 587, 180, 0.28, false)));
        }
        catch (Exception)
        {
            // Audio is optional: the game stays fully playable without it.
        }
    }

    public static void Play(SfxId id)
    {
        if (Muted) return;
        try
        {
            SoundPlayer? sp;
            if (Players.TryGetValue(id, out sp) && sp != null) sp.Play();
        }
        catch (Exception)
        {
        }
    }

    private static void Add(SfxId id, short[] samples)
    {
        SoundPlayer sp = new SoundPlayer(new MemoryStream(ToWav(samples)));
        sp.Load();
        Players[id] = sp;
    }

    private static short[] Tone(double f0, double f1, int ms, double vol, bool square)
    {
        int n = Rate * ms / 1000;
        short[] d = new short[n];
        double phase = 0.0;
        for (int i = 0; i < n; i++)
        {
            double t = (double)i / n;
            double f = f0 + (f1 - f0) * t;
            phase += 2.0 * Math.PI * f / Rate;
            double v = square ? (Math.Sin(phase) >= 0.0 ? 0.6 : -0.6) : Math.Sin(phase);
            double env = Math.Min(1.0, i / 120.0) * (1.0 - t);
            d[i] = (short)(v * env * vol * 32000.0);
        }
        return d;
    }

    private static short[] Noise(int ms, double vol)
    {
        int n = Rate * ms / 1000;
        short[] d = new short[n];
        double last = 0.0;
        for (int i = 0; i < n; i++)
        {
            double t = (double)i / n;
            double raw = Rng.NextDouble() * 2.0 - 1.0;
            last = last * 0.6 + raw * 0.4;
            d[i] = (short)(last * (1.0 - t) * vol * 32000.0);
        }
        return d;
    }

    private static short[] Cat(params short[][] parts)
    {
        int total = 0;
        foreach (short[] p in parts) total += p.Length;
        short[] all = new short[total];
        int pos = 0;
        foreach (short[] p in parts)
        {
            Array.Copy(p, 0, all, pos, p.Length);
            pos += p.Length;
        }
        return all;
    }

    private static byte[] ToWav(short[] samples)
    {
        int dataLen = samples.Length * 2;
        using MemoryStream ms = new MemoryStream();
        using BinaryWriter bw = new BinaryWriter(ms);
        bw.Write(Encoding.ASCII.GetBytes("RIFF"));
        bw.Write(36 + dataLen);
        bw.Write(Encoding.ASCII.GetBytes("WAVE"));
        bw.Write(Encoding.ASCII.GetBytes("fmt "));
        bw.Write(16);
        bw.Write((short)1);
        bw.Write((short)1);
        bw.Write(Rate);
        bw.Write(Rate * 2);
        bw.Write((short)2);
        bw.Write((short)16);
        bw.Write(Encoding.ASCII.GetBytes("data"));
        bw.Write(dataLen);
        foreach (short s in samples) bw.Write(s);
        bw.Flush();
        return ms.ToArray();
    }
}
