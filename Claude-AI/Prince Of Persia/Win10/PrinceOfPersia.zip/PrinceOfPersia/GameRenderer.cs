using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace PrinceOfPersia;

public enum Pose { Idle, Run, Skid, Jump, Fall, Land, Climb, Dead }

/// <summary>
/// GDI+ renderer in a 16-bit pixel style with a sunset-palace palette. The world is drawn at logical size into a
/// back buffer (with parallax sky, tiles, traps, doors and the prince) and then scaled to the window with
/// nearest-neighbour filtering; HUD, screens and the footer are drawn directly so text stays crisp.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    public static readonly Rectangle TitleButton = new Rectangle(250, 410, 300, 54);
    public static readonly Rectangle RetryButton = new Rectangle(270, 392, 260, 44);

    private const int T = Cfg.T;

    // ---- palette
    private static readonly Color cInk = Color.FromArgb(22, 12, 34);
    private static readonly Color cWhite = Color.FromArgb(255, 252, 240);
    private static readonly Color cGold = Color.FromArgb(255, 214, 90);
    private static readonly Color cGoldD = Color.FromArgb(214, 140, 40);
    private static readonly Color cRed = Color.FromArgb(226, 56, 56);
    private static readonly Color cGreen = Color.FromArgb(120, 255, 160);
    private static readonly Color cSteel = Color.FromArgb(186, 196, 224);
    private static readonly Color cSteelD = Color.FromArgb(96, 104, 150);

    private static readonly Color[] SetSkin = { Color.FromArgb(255, 226, 190), Color.FromArgb(244, 176, 128), Color.FromArgb(190, 118, 84) };
    private static readonly Color[] SetHair = { Color.FromArgb(96, 70, 90), Color.FromArgb(44, 28, 44), Color.FromArgb(22, 12, 24) };
    private static readonly Color[] SetVest = { Color.FromArgb(120, 158, 255), Color.FromArgb(46, 84, 204), Color.FromArgb(24, 40, 130) };
    private static readonly Color[] SetSash = { Color.FromArgb(255, 120, 100), Color.FromArgb(220, 50, 56), Color.FromArgb(140, 20, 40) };
    private static readonly Color[] SetPants = { Color.FromArgb(255, 252, 244), Color.FromArgb(226, 218, 232), Color.FromArgb(170, 156, 200) };
    private static readonly Color[] SetPantsD = { Color.FromArgb(226, 220, 236), Color.FromArgb(186, 176, 210), Color.FromArgb(130, 118, 168) };
    private static readonly Color[] SetBoot = { Color.FromArgb(182, 120, 70), Color.FromArgb(118, 70, 38), Color.FromArgb(64, 36, 20) };
    private static readonly Color[] SetGoldTrim = { Color.FromArgb(255, 240, 150), Color.FromArgb(240, 190, 60), Color.FromArgb(170, 110, 30) };
    private static readonly Color[] SetStone = { Color.FromArgb(255, 214, 150), Color.FromArgb(204, 134, 82), Color.FromArgb(110, 62, 52) };

    private readonly Bitmap board = new Bitmap(Cfg.LogicalW, Cfg.ViewH, PixelFormat.Format32bppPArgb);
    private readonly ImageAttributes boardAttrs = new ImageAttributes();
    private readonly SolidBrush pBrush = new SolidBrush(Color.Black);
    private readonly Pen leverPen = new Pen(Color.FromArgb(200, 206, 230), 4f);
    private readonly Bitmap sky;
    private readonly Bitmap far;
    private readonly Bitmap near;
    private readonly Bitmap vignette;
    private readonly Bitmap[] wall = new Bitmap[4];
    private readonly Bitmap[] back = new Bitmap[2];
    private readonly Bitmap tileWindow;
    private readonly Bitmap tileLadder;
    private readonly Bitmap tileCrumble;
    private readonly Bitmap titleBmp;
    private readonly Bitmap subBmp;
    private readonly Blade titleBlade = new Blade(new BladeDef(15, 0, 250f, 3.0f, 0f, 38f));

    private readonly Font fHud;
    private readonly Font fLabel;
    private readonly Font fBig;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fFooter;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;
    private readonly StringFormat sfRight;

    private int pOx;
    private int pOy;
    private int pU = 1;
    private bool pFlip;

    private static readonly string[] FlameA =
    {
        "...1...",
        "..111..",
        ".11211.",
        ".12221.",
        "1123211",
        "1123211",
        ".11211.",
        "..111.."
    };

    private static readonly string[] FlameB =
    {
        "....1..",
        "..1111.",
        ".11211.",
        "112221.",
        "1123211",
        "1123211",
        ".11211.",
        "..111.."
    };

    public GameRenderer()
    {
        boardAttrs.SetWrapMode(WrapMode.TileFlipXY);
        leverPen.StartCap = LineCap.Round;
        leverPen.EndCap = LineCap.Round;

        fHud = new Font("Consolas", 17f, FontStyle.Bold, GraphicsUnit.Pixel);
        fLabel = new Font("Consolas", 12f, FontStyle.Bold, GraphicsUnit.Pixel);
        fBig = new Font("Consolas", 38f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Consolas", 22f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Consolas", 18f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Consolas", 14f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;
        sfRight = new StringFormat();
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfRight.FormatFlags = StringFormatFlags.NoWrap;

        sky = MakeSky();
        far = MakeFar();
        near = MakeNear();
        vignette = MakeVignette();
        for (int i = 0; i < wall.Length; i++) wall[i] = MakeWall(i);
        for (int i = 0; i < back.Length; i++) back[i] = MakeBack(i);
        tileWindow = MakeWindow();
        tileLadder = MakeLadder();
        tileCrumble = MakeCrumble();
        titleBmp = MakeTitle("PRINCE OF PERSIA", 19f, 230, 28,
            Color.FromArgb(255, 248, 170), Color.FromArgb(255, 222, 90), Color.FromArgb(238, 160, 40), Color.FromArgb(184, 92, 24));
        subBmp = MakeTitle("SUNSET PALACE", 14f, 150, 20,
            Color.FromArgb(255, 190, 150), Color.FromArgb(250, 120, 90), Color.FromArgb(214, 60, 70), Color.FromArgb(150, 30, 60));
    }

    public void Dispose()
    {
        board.Dispose();
        boardAttrs.Dispose();
        pBrush.Dispose();
        leverPen.Dispose();
        sky.Dispose();
        far.Dispose();
        near.Dispose();
        vignette.Dispose();
        foreach (Bitmap b in wall) b.Dispose();
        foreach (Bitmap b in back) b.Dispose();
        tileWindow.Dispose();
        tileLadder.Dispose();
        tileCrumble.Dispose();
        titleBmp.Dispose();
        subBmp.Dispose();
        fHud.Dispose();
        fLabel.Dispose();
        fBig.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fFooter.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        sfRight.Dispose();
    }

    // ------------------------------------------------------------------ painter helpers

    private void Begin(int x, int y, int u, bool flip)
    {
        pOx = x;
        pOy = y;
        pU = u;
        pFlip = flip;
    }

    /// <summary>Rectangle on the 20-wide sprite grid.</summary>
    private void R(Graphics g, int px, int py, int pw, int ph, Color c)
    {
        int x = pFlip ? 20 - px - pw : px;
        pBrush.Color = c;
        g.FillRectangle(pBrush, pOx + x * pU, pOy + py * pU, pw * pU, ph * pU);
    }

    /// <summary>Rectangle on the half-pixel grid (for highlights and shadows).</summary>
    private void H(Graphics g, int hx, int hy, int hw, int hh, Color c)
    {
        int hu = Math.Max(1, pU / 2);
        int x = pFlip ? 40 - hx - hw : hx;
        pBrush.Color = c;
        g.FillRectangle(pBrush, pOx + x * hu, pOy + hy * hu, hw * hu, hh * hu);
    }

    private void RS(Graphics g, int px, int py, int pw, int ph, Color[] s)
    {
        R(g, px, py, pw, ph, s[1]);
        int x0 = px * 2;
        int y0 = py * 2;
        int w2 = pw * 2;
        int h2 = ph * 2;
        H(g, x0, y0, 1, h2, pFlip ? s[2] : s[0]);
        H(g, x0 + w2 - 1, y0, 1, h2, pFlip ? s[0] : s[2]);
        H(g, x0, y0, w2, 1, s[0]);
        H(g, x0, y0 + h2 - 1, w2, 1, s[2]);
    }

    private void ROS(Graphics g, int px, int py, int pw, int ph, Color[] s)
    {
        R(g, px - 1, py - 1, pw + 2, ph + 2, cInk);
        RS(g, px, py, pw, ph, s);
    }

    private void Rect(Graphics g, int x, int y, int w, int h, Color c)
    {
        pBrush.Color = c;
        g.FillRectangle(pBrush, x, y, w, h);
    }

    private static Color Lerp(Color a, Color b, float t)
    {
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        return Color.FromArgb(
            (int)(a.R + (b.R - a.R) * t),
            (int)(a.G + (b.G - a.G) * t),
            (int)(a.B + (b.B - a.B) * t));
    }

    private static int Hash(int a, int b)
    {
        unchecked
        {
            int h = a * 374761393 + b * 668265263;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    private void Bands(Graphics g, int x, int y, int w, int h, Color top, Color bottom, int bandH)
    {
        for (int by = 0; by < h; by += bandH)
        {
            float t = h <= 1 ? 0f : by / (float)(h - 1);
            Rect(g, x, y + by, w, Math.Min(bandH, h - by), Lerp(top, bottom, t));
        }
    }

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow)
        {
            using (SolidBrush sb = new SolidBrush(cInk))
            {
                g.DrawString(s, f, sb, x + 2f, y + 2f, sf);
                g.DrawString(s, f, sb, x + 1f, y + 2f, sf);
                g.DrawString(s, f, sb, x + 2f, y + 1f, sf);
            }
        }
        using (SolidBrush b = new SolidBrush(c))
        {
            g.DrawString(s, f, b, x, y, sf);
        }
    }

    private void DrawBox(Graphics g, Rectangle r)
    {
        Rect(g, r.X, r.Y, r.Width, r.Height, cInk);
        Bands(g, r.X + 2, r.Y + 2, r.Width - 4, r.Height - 4, Color.FromArgb(255, 222, 140), Color.FromArgb(150, 80, 40), 4);
        Bands(g, r.X + 6, r.Y + 6, r.Width - 12, r.Height - 12, Color.FromArgb(56, 34, 78), Color.FromArgb(22, 12, 44), 4);
        Rect(g, r.X + 6, r.Y + 6, r.Width - 12, 1, Color.FromArgb(200, 140, 120));
        Rect(g, r.X + 2, r.Y + 2, r.Width - 4, 1, cWhite);
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)Cfg.LogicalW, clientH / (float)Cfg.LogicalH);
        float offX = (clientW - Cfg.LogicalW * scale) / 2f;
        float offY = (clientH - Cfg.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, Cfg.LogicalW, Cfg.LogicalH));
            g.SmoothingMode = SmoothingMode.None;
            g.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (e.State == GameState.Title)
            {
                DrawTitle(g, e);
            }
            else
            {
                DrawGame(g, e);
                switch (e.State)
                {
                    case GameState.Paused:
                        DrawPanel(g, e, "ПАУЗА", cGold,
                            new[] { "Enter / Esc — продолжить", "R — начать уровень заново", "M — главное меню" }, null);
                        break;
                    case GameState.Dead:
                        DrawPanel(g, e, "ВЫ ПОГИБЛИ", cRed,
                            new[] { e.DeathReason, "Попыток на всём пути: " + e.Deaths }, "ПОВТОРИТЬ  (R / Enter)");
                        break;
                    case GameState.LevelComplete:
                        DrawPanel(g, e, "УРОВЕНЬ ПРОЙДЕН", cGreen,
                            new[] { "Время: " + FormatTime(e.Time), "Смертей всего: " + e.Deaths },
                            e.LevelIndex + 1 >= e.LevelCount ? "Enter — финал" : "Enter — следующий уровень");
                        break;
                    case GameState.Victory:
                        DrawPanel(g, e, "ПРИКЛЮЧЕНИЕ ЗАВЕРШЕНО", cGold,
                            new[] { "Вы пересекли закатный дворец!", "Общее время: " + FormatTime(e.TotalTime), "Смертей: " + e.Deaths },
                            "Enter — в главное меню");
                        break;
                }
            }
            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    private static string FormatTime(float seconds)
    {
        int s = (int)seconds;
        return (s / 60).ToString("D2") + ":" + (s % 60).ToString("D2");
    }

    // ------------------------------------------------------------------ game screen

    private void DrawGame(Graphics g, GameEngine e)
    {
        using (Graphics bg = Graphics.FromImage(board))
        {
            bg.SmoothingMode = SmoothingMode.None;
            bg.PixelOffsetMode = PixelOffsetMode.Half;
            bg.InterpolationMode = InterpolationMode.NearestNeighbor;
            bg.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
            DrawWorld(bg, e);
        }

        g.DrawImage(board, new Rectangle(0, Cfg.HudH, Cfg.LogicalW, Cfg.ViewH),
            0, 0, Cfg.LogicalW, Cfg.ViewH, GraphicsUnit.Pixel, boardAttrs);

        DrawHud(g, e);

        if (e.HurtFlash > 0f)
        {
            int a = (int)Math.Min(110f, e.HurtFlash * 220f);
            using (SolidBrush red = new SolidBrush(Color.FromArgb(a, 200, 20, 20)))
            {
                g.FillRectangle(red, 0, Cfg.HudH, Cfg.LogicalW, Cfg.ViewH);
            }
        }

        if (e.State == GameState.Playing || e.State == GameState.Paused)
        {
            if (e.BannerTimer > 0f)
            {
                int a = (int)Math.Min(255f, e.BannerTimer * 255f);
                Txt(g, "УРОВЕНЬ " + (e.LevelIndex + 1), fBig, Color.FromArgb(a, cGold), Cfg.LogicalW / 2f, Cfg.HudH + 130f, sfCenter, true);
                Txt(g, e.Level.Name.ToUpperInvariant(), fMid, Color.FromArgb(a, cWhite), Cfg.LogicalW / 2f, Cfg.HudH + 178f, sfCenter, true);
                Txt(g, e.Level.Subtitle, fText, Color.FromArgb(a, 255, 190, 140), Cfg.LogicalW / 2f, Cfg.HudH + 208f, sfCenter, true);
            }
            if (e.MessageTimer > 0f && e.Message.Length > 0)
            {
                int a = (int)Math.Min(235f, e.MessageTimer * 300f);
                Rectangle m = new Rectangle(80, Cfg.HudH + Cfg.ViewH - 52, Cfg.LogicalW - 160, 36);
                using (SolidBrush shade = new SolidBrush(Color.FromArgb(a * 7 / 10, 20, 8, 30)))
                {
                    g.FillRectangle(shade, m);
                }
                Txt(g, e.Message, fText, Color.FromArgb(a, 255, 240, 200), m.X + m.Width / 2f, m.Y + m.Height / 2f, sfCenter, true);
            }
        }
    }

    private void DrawHud(Graphics g, GameEngine e)
    {
        Bands(g, 0, 0, Cfg.LogicalW, Cfg.HudH - 4, Color.FromArgb(96, 52, 84), Color.FromArgb(34, 18, 48), 4);
        Rect(g, 0, 0, Cfg.LogicalW, 1, Color.FromArgb(255, 200, 160));
        Rect(g, 0, Cfg.HudH - 4, Cfg.LogicalW, 4, cGoldD);
        Rect(g, 0, Cfg.HudH - 4, Cfg.LogicalW, 1, cGold);
        Rect(g, 0, Cfg.HudH - 1, Cfg.LogicalW, 1, Color.FromArgb(110, 60, 20));

        Txt(g, "УРОВЕНЬ " + (e.LevelIndex + 1) + " / " + e.LevelCount, fLabel, Color.FromArgb(255, 190, 150), 16f, 13f, sfLeft, false);
        Txt(g, e.Level.Name.ToUpperInvariant(), fHud, cGold, 16f, 30f, sfLeft, true);
        Txt(g, "СМЕРТЕЙ", fLabel, Color.FromArgb(255, 190, 150), 600f, 13f, sfLeft, false);
        Txt(g, e.Deaths.ToString(), fHud, cWhite, 600f, 30f, sfLeft, true);
        Txt(g, "ВРЕМЯ", fLabel, Color.FromArgb(255, 190, 150), 704f, 13f, sfLeft, false);
        Txt(g, FormatTime(e.Time), fHud, cWhite, 704f, 30f, sfLeft, true);

        if (e.Level.ExitNeeds.Length > 0)
        {
            Txt(g, "РЫЧАГИ", fLabel, Color.FromArgb(255, 190, 150), 470f, 13f, sfLeft, false);
            Txt(g, e.ExitNeedsDone + " / " + e.Level.ExitNeeds.Length, fHud, e.ExitUnlocked ? cGreen : cWhite, 470f, 30f, sfLeft, true);
        }
    }

    private void DrawWorld(Graphics g, GameEngine e)
    {
        GameLevel lv = e.Level;
        int camX = (int)Math.Round(e.CamX);
        int camY = (int)Math.Round(e.CamY);
        float time = e.Time;

        // ---- parallax sky (screen space)
        g.DrawImage(sky, new Rectangle(0, 0, Cfg.LogicalW, Cfg.ViewH), 0, 0, Cfg.LogicalW, Cfg.ViewH, GraphicsUnit.Pixel);
        DrawLayer(g, far, camX * 0.12f, camY * 0.06f);
        DrawLayer(g, near, camX * 0.3f, camY * 0.12f);

        GraphicsState st = g.Save();
        g.TranslateTransform(-camX, -camY);

        int c0 = Math.Max(0, camX / T);
        int c1 = Math.Min(lv.Cols - 1, (camX + Cfg.LogicalW) / T);
        int r0 = Math.Max(0, camY / T);
        int r1 = Math.Min(lv.Rows - 1, (camY + Cfg.ViewH) / T);

        for (int r = r0; r <= r1; r++)
        {
            for (int c = c0; c <= c1; c++)
            {
                DrawTile(g, e, lv, c, r);
            }
        }

        // torches and window light (after the tiles so the glow overlaps neighbours)
        for (int r = r0; r <= r1; r++)
        {
            for (int c = c0; c <= c1; c++)
            {
                Tile t = lv.Cells[c, r];
                if (t == Tile.Torch) DrawTorch(g, c * T + 20, r * T + 10, e.Frame);
                else if (t == Tile.Window) DrawWindowLight(g, c * T, r * T);
            }
        }

        foreach (Crumble k in lv.Crumbles)
        {
            if (k.State != CrumbleState.Falling) continue;
            float f = k.Timer;
            int fy = (int)(f * f * 420f);
            int fx = (int)(f * 14f);
            g.DrawImage(tileCrumble, k.Col * T + fx, k.Row * T + fy);
        }

        DrawTriggers(g, e, lv);
        DrawExit(g, e, lv);
        foreach (Door d in lv.Doors) DrawDoor(g, d, e);
        foreach (Gate gt in lv.Gates) DrawGate(g, gt, e.Frame);
        foreach (Blade b in lv.Blades) DrawBlade(g, b, time);

        DrawPlayer(g, e);

        foreach (Particle p in e.Particles)
        {
            int sz = p.Life * 3 < p.MaxLife ? 2 : p.Size;
            Rect(g, ((int)p.X / 2) * 2, ((int)p.Y / 2) * 2, sz, sz, p.Color);
        }

        g.Restore(st);

        // warm sunset grading and vignette
        using (SolidBrush warm = new SolidBrush(Color.FromArgb(18, 255, 140, 60)))
        {
            g.FillRectangle(warm, 0, 0, Cfg.LogicalW, Cfg.ViewH);
        }
        g.DrawImageUnscaled(vignette, 0, 0);
    }

    private void DrawLayer(Graphics g, Bitmap layer, float dx, float dy)
    {
        int w = layer.Width;
        int ox = -(int)(dx % w);
        int oy = -(int)dy;
        g.DrawImageUnscaled(layer, ox, oy);
        g.DrawImageUnscaled(layer, ox + w, oy);
    }

    private void DrawTile(Graphics g, GameEngine e, GameLevel lv, int c, int r)
    {
        int x = c * T;
        int y = r * T;
        Tile t = lv.Cells[c, r];
        switch (t)
        {
            case Tile.Sky:
                break;
            case Tile.Interior:
            case Tile.Closed:
            case Tile.Torch:
                g.DrawImageUnscaled(back[(c + r) & 1], x, y);
                break;
            case Tile.Window:
                g.DrawImageUnscaled(tileWindow, x, y);
                break;
            case Tile.Ladder:
                g.DrawImageUnscaled(back[(c + r) & 1], x, y);
                g.DrawImageUnscaled(tileLadder, x, y);
                break;
            case Tile.Wall:
                g.DrawImageUnscaled(wall[(c * 7 + r * 13) & 3], x, y);
                if (!lv.IsSolid(c, r - 1))
                {
                    Rect(g, x, y, T, 3, Color.FromArgb(255, 226, 168));
                    Rect(g, x, y + 3, T, 2, Color.FromArgb(240, 178, 108));
                    Rect(g, x, y + 5, T, 1, Color.FromArgb(120, 62, 52));
                }
                if (!lv.IsSolid(c, r + 1) && lv.Get(c, r + 1) != Tile.Ladder)
                {
                    Rect(g, x, y + T - 3, T, 3, Color.FromArgb(80, 42, 50));
                }
                break;
            case Tile.Crumble:
            {
                g.DrawImageUnscaled(back[(c + r) & 1], x, y);
                Crumble? k = lv.CrumbleAt(c, r);
                int sx = 0;
                int sy = 0;
                if (k != null && k.State == CrumbleState.Armed)
                {
                    sx = ((e.Frame / 2) % 2 == 0) ? -2 : 2;
                    sy = ((e.Frame / 3) % 2 == 0) ? 0 : 1;
                }
                g.DrawImageUnscaled(tileCrumble, x + sx, y + sy);
                if (!lv.IsSolid(c, r - 1))
                {
                    Rect(g, x + sx, y + sy, T, 3, Color.FromArgb(255, 226, 168));
                }
                break;
            }
            case Tile.Spikes:
                DrawBackFor(g, lv, c, r);
                DrawSpikeRow(g, x, y, 1f, false, e.Frame);
                break;
            case Tile.TimedSpikes:
            {
                DrawBackFor(g, lv, c, r);
                SpikeTrap? s = lv.TimedSpikeAt(c, r);
                float h = s != null ? s.Height : 0f;
                bool warn = s != null && s.Warning;
                DrawSpikeRow(g, x, y, h, warn, e.Frame);
                break;
            }
        }
    }

    private void DrawBackFor(Graphics g, GameLevel lv, int c, int r)
    {
        if (lv.Get(c, r - 1) == Tile.Sky) return;
        g.DrawImageUnscaled(back[(c + r) & 1], c * T, r * T);
    }

    private void DrawSpikeRow(Graphics g, int x, int y, float h, bool warn, int frame)
    {
        int baseY = y + 38;
        Rect(g, x + 2, y + 36, T - 4, 4, Color.FromArgb(70, 62, 90));
        Rect(g, x + 2, y + 36, T - 4, 1, Color.FromArgb(150, 140, 180));
        if (warn)
        {
            Color glow = ((frame / 4) % 2 == 0) ? Color.FromArgb(255, 70, 50) : Color.FromArgb(255, 170, 60);
            Rect(g, x + 2, y + 34, T - 4, 2, glow);
        }
        int sh = (int)(h * 20f);
        if (sh <= 0) return;
        for (int i = 0; i < 5; i++)
        {
            int sx = x + 4 + i * 8;
            Point[] tri = { new Point(sx, baseY), new Point(sx + 8, baseY), new Point(sx + 4, baseY - sh) };
            Point[] lit = { new Point(sx, baseY), new Point(sx + 4, baseY), new Point(sx + 4, baseY - sh) };
            pBrush.Color = Color.FromArgb(140, 150, 188);
            g.FillPolygon(pBrush, tri);
            pBrush.Color = Color.FromArgb(232, 238, 255);
            g.FillPolygon(pBrush, lit);
            Rect(g, sx + 3, baseY - sh, 2, 2, warn ? Color.FromArgb(255, 90, 70) : cWhite);
        }
    }

    // ------------------------------------------------------------------ props

    private void DrawTorch(Graphics g, int cx, int top, int frame)
    {
        using (SolidBrush glow1 = new SolidBrush(Color.FromArgb(22, 255, 160, 50)))
        using (SolidBrush glow2 = new SolidBrush(Color.FromArgb(26, 255, 200, 90)))
        {
            g.FillEllipse(glow1, cx - 80, top - 60, 160, 150);
            g.FillEllipse(glow2, cx - 46, top - 30, 92, 90);
        }
        Rect(g, cx - 3, top + 22, 6, 18, Color.FromArgb(104, 62, 34));
        Rect(g, cx - 3, top + 22, 2, 18, Color.FromArgb(170, 112, 60));
        Rect(g, cx - 7, top + 18, 14, 6, Color.FromArgb(110, 80, 64));
        Rect(g, cx - 7, top + 18, 14, 2, Color.FromArgb(200, 160, 110));
        DrawGrid(g, ((frame / 8) % 2 == 0) ? FlameA : FlameB, cx - 10, top - 4, 3,
            Color.FromArgb(250, 120, 30), Color.FromArgb(255, 214, 80), Color.FromArgb(255, 252, 220));
    }

    private void DrawGrid(Graphics g, string[] rows, int x, int y, int u, Color a, Color b, Color c)
    {
        for (int r = 0; r < rows.Length; r++)
        {
            for (int col = 0; col < rows[r].Length; col++)
            {
                char ch = rows[r][col];
                if (ch == '.') continue;
                pBrush.Color = ch == '1' ? a : (ch == '2' ? b : c);
                g.FillRectangle(pBrush, x + col * u, y + r * u, u, u);
            }
        }
    }

    private void DrawWindowLight(Graphics g, int x, int y)
    {
        Point[] beam =
        {
            new Point(x + 10, y + 34), new Point(x + 30, y + 34),
            new Point(x + 64, y + 170), new Point(x - 24, y + 170)
        };
        using (SolidBrush b = new SolidBrush(Color.FromArgb(20, 255, 190, 100)))
        {
            g.FillPolygon(b, beam);
        }
    }

    private void DrawGate(Graphics g, Gate gt, int frame)
    {
        int x = gt.Col * T;
        int y = gt.Row * T;
        int full = gt.Height * T;
        int vis = (int)(full * (1f - gt.Open));
        Rect(g, x, y, 4, full, Color.FromArgb(150, 92, 70));
        Rect(g, x + T - 4, y, 4, full, Color.FromArgb(120, 70, 56));
        if (vis > 0)
        {
            for (int i = 0; i < 4; i++)
            {
                int bx = x + 6 + i * 8;
                Rect(g, bx, y, 5, vis, Color.FromArgb(120, 128, 164));
                Rect(g, bx, y, 2, vis, Color.FromArgb(228, 234, 255));
                Rect(g, bx + 4, y, 1, vis, Color.FromArgb(50, 54, 90));
                Point[] tip = { new Point(bx, y + vis), new Point(bx + 5, y + vis), new Point(bx + 2, y + vis + 6) };
                pBrush.Color = Color.FromArgb(200, 208, 236);
                g.FillPolygon(pBrush, tip);
            }
            for (int k = 6; k < vis; k += 40)
            {
                Rect(g, x + 4, y + k, T - 8, 4, Color.FromArgb(76, 80, 120));
                Rect(g, x + 4, y + k, T - 8, 1, Color.FromArgb(190, 196, 230));
            }
        }
        Rect(g, x, y - 4, T, 6, Color.FromArgb(170, 104, 76));
        Color lamp;
        if (gt.Timed) lamp = gt.Warning ? (((frame / 4) % 2 == 0) ? Color.FromArgb(255, 70, 50) : Color.FromArgb(120, 20, 20)) : (gt.Open > 0.5f ? Color.FromArgb(90, 230, 120) : Color.FromArgb(220, 60, 50));
        else lamp = gt.Open > 0.5f ? Color.FromArgb(90, 230, 120) : Color.FromArgb(220, 60, 50);
        Rect(g, x + T / 2 - 3, y - 3, 6, 4, lamp);
    }

    private void DrawDoor(Graphics g, Door d, GameEngine e)
    {
        int x = d.Col * T;
        int y = (d.Row - 1) * T;
        int h = 2 * T;
        Rect(g, x + 2, y + 4, T - 4, h - 4, Color.FromArgb(18, 10, 24));           // doorway
        if (d.State != DoorState.Open)
        {
            int pw = (int)((T - 10) * (1f - d.Openness));
            if (pw > 0)
            {
                Rect(g, x + 4, y + 8, pw, h - 8, Color.FromArgb(134, 82, 44));
                for (int k = 0; k < pw; k += 7)
                {
                    Rect(g, x + 4 + k, y + 8, 1, h - 8, Color.FromArgb(176, 116, 64));
                    Rect(g, x + 4 + k + 5, y + 8, 1, h - 8, Color.FromArgb(78, 44, 28));
                }
                Rect(g, x + 4, y + 22, pw, 4, Color.FromArgb(54, 48, 70));
                Rect(g, x + 4, y + h - 24, pw, 4, Color.FromArgb(54, 48, 70));
                if (pw > 20)
                {
                    Rect(g, x + pw - 6, y + h / 2, 6, 6, cGold);
                    Rect(g, x + pw - 5, y + h / 2 + 1, 2, 2, Color.FromArgb(255, 250, 200));
                }
            }
        }
        // stone arch around the door
        Rect(g, x, y + 2, 4, h - 2, Color.FromArgb(204, 134, 82));
        Rect(g, x + T - 4, y + 2, 4, h - 2, Color.FromArgb(158, 96, 64));
        Rect(g, x, y, T, 6, Color.FromArgb(238, 176, 108));
        Rect(g, x, y + 5, T, 1, Color.FromArgb(110, 62, 52));
        if (d.State == DoorState.Closed && d.IsLocked(e.Triggered))
        {
            Rect(g, x + 14, y + h / 2 - 12, 12, 10, cGold);
            Rect(g, x + 16, y + h / 2 - 18, 2, 7, cSteel);
            Rect(g, x + 22, y + h / 2 - 18, 2, 7, cSteel);
            Rect(g, x + 16, y + h / 2 - 20, 8, 2, cSteel);
        }
    }

    private void DrawExit(Graphics g, GameEngine e, GameLevel lv)
    {
        int x = lv.ExitCell.X * T;
        int y = (lv.ExitCell.Y - 1) * T;
        int h = 2 * T;
        bool open = e.ExitUnlocked;
        float glow = 0.5f + 0.5f * MathF.Sin(e.Frame * 0.1f);

        if (open)
        {
            using (SolidBrush b1 = new SolidBrush(Color.FromArgb(24, 255, 214, 100)))
            using (SolidBrush b2 = new SolidBrush(Color.FromArgb(30, 255, 236, 150)))
            {
                g.FillEllipse(b1, x - 40, y - 30, T + 80, h + 60);
                g.FillEllipse(b2, x - 18, y - 8, T + 36, h + 16);
            }
        }

        // doorway and light
        Rect(g, x + 2, y + 6, T - 4, h - 6, open ? Color.FromArgb(255, 230, 150) : Color.FromArgb(30, 18, 40));
        if (open)
        {
            Rect(g, x + 8, y + 12, T - 16, h - 12, Color.FromArgb(255, 246, 210));
            Rect(g, x + 14, y + 18, T - 28, h - 18, Color.FromArgb(255, 255, 240));
        }

        // door panel: iron when locked, slides up while opening
        float slide = e.ExitOpening ? e.ExitProgress : 0f;
        int panelH = (int)((h - 8) * (1f - slide));
        if (!open)
        {
            Rect(g, x + 4, y + 8, T - 8, h - 8, Color.FromArgb(70, 66, 94));
            for (int k = 0; k < T - 8; k += 8) Rect(g, x + 4 + k, y + 8, 1, h - 8, Color.FromArgb(38, 34, 58));
            Rect(g, x + 4, y + 28, T - 8, 3, Color.FromArgb(150, 156, 190));
            Rect(g, x + 4, y + h - 26, T - 8, 3, Color.FromArgb(150, 156, 190));
            Rect(g, x + 14, y + h / 2 - 8, 12, 10, cGold);
            Rect(g, x + 16, y + h / 2 - 14, 2, 7, cSteel);
            Rect(g, x + 22, y + h / 2 - 14, 2, 7, cSteel);
            Rect(g, x + 16, y + h / 2 - 16, 8, 2, cSteel);
        }
        else if (panelH > 0)
        {
            Rect(g, x + 4, y + 8, T - 8, panelH, Color.FromArgb(220, 170, 70));
            for (int k = 0; k < T - 8; k += 8) Rect(g, x + 4 + k, y + 8, 1, panelH, Color.FromArgb(250, 214, 120));
            Rect(g, x + 4, y + 8, T - 8, 2, Color.FromArgb(255, 240, 170));
            if (panelH > 24) Rect(g, x + T / 2 - 2, y + 8 + panelH / 2 - 2, 4, 4, Color.FromArgb(120, 70, 20));
        }

        // frame
        Color arch = open ? Color.FromArgb(255, 214, 120) : Color.FromArgb(204, 134, 82);
        Color archD = open ? Color.FromArgb(214, 150, 60) : Color.FromArgb(158, 96, 64);
        Rect(g, x, y + 2, 4, h - 2, arch);
        Rect(g, x + T - 4, y + 2, 4, h - 2, archD);
        Rect(g, x, y, T, 6, open ? Color.FromArgb(255, 240, 170) : Color.FromArgb(238, 176, 108));
        Rect(g, x + 8, y - 6, T - 16, 6, open ? Color.FromArgb(255, 226, 130) : Color.FromArgb(204, 134, 82));
        Rect(g, x + 16, y - 10, T - 32, 4, open ? Color.FromArgb(255, 214, 90) : Color.FromArgb(180, 110, 70));
        if (open) Rect(g, x + T / 2 - 2, y - 8, 4, 4, Color.FromArgb(255, (int)(180 + 60 * glow), 120));
    }

    private void DrawTriggers(Graphics g, GameEngine e, GameLevel lv)
    {
        foreach (Trigger t in lv.Triggers)
        {
            int x = t.Col * T;
            int y = t.Row * T;
            if (t.Plate)
            {
                int dip = t.Pulled ? 3 : 0;
                Rect(g, x + 4, y + 33 + dip, T - 8, 7 - dip, Color.FromArgb(120, 70, 56));
                Rect(g, x + 6, y + 33 + dip, T - 12, 3, t.Pulled ? Color.FromArgb(90, 220, 120) : Color.FromArgb(240, 190, 90));
                Rect(g, x + 6, y + 36 + dip, T - 12, 1, Color.FromArgb(70, 40, 40));
            }
            else
            {
                Rect(g, x + 12, y + 20, 16, 18, Color.FromArgb(94, 100, 140));
                Rect(g, x + 12, y + 20, 16, 2, Color.FromArgb(190, 198, 230));
                Rect(g, x + 14, y + 36, 12, 2, Color.FromArgb(40, 44, 70));
                int hx = t.Pulled ? x + 30 : x + 10;
                g.DrawLine(leverPen, x + 20, y + 30, hx, y + 14);
                Rect(g, hx - 3, y + 11, 6, 6, t.Pulled ? Color.FromArgb(90, 230, 120) : cRed);
                Rect(g, hx - 3, y + 11, 2, 2, cWhite);
            }
        }
    }

    private void DrawBlade(Graphics g, Blade b, float time)
    {
        int ax = (int)b.AnchorX;
        int ay = (int)b.AnchorY;
        Rect(g, ax - 10, ay - 6, 20, 8, Color.FromArgb(90, 84, 118));
        Rect(g, ax - 10, ay - 6, 20, 2, Color.FromArgb(200, 206, 240));
        int links = (int)(b.Length / 8f);
        for (int i = 1; i < links; i++)
        {
            float t = i / (float)links;
            int lx = (int)(b.AnchorX + (b.TipX - b.AnchorX) * t);
            int ly = (int)(b.AnchorY + (b.TipY - b.AnchorY) * t);
            Rect(g, lx - 2, ly - 2, 4, 4, (i % 2 == 0) ? Color.FromArgb(150, 156, 190) : Color.FromArgb(94, 98, 132));
        }
        // spinning toothed disc
        float spin = time * 9f;
        PointF[] pts = new PointF[16];
        for (int i = 0; i < 16; i++)
        {
            float a = spin + i * MathF.PI / 8f;
            float rad = (i % 2 == 0) ? 20f : 13f;
            pts[i] = new PointF(b.TipX + MathF.Cos(a) * rad, b.TipY + MathF.Sin(a) * rad);
        }
        pBrush.Color = Color.FromArgb(200, 208, 236);
        g.FillPolygon(pBrush, pts);
        pBrush.Color = Color.FromArgb(118, 126, 166);
        g.FillEllipse(pBrush, b.TipX - 11f, b.TipY - 11f, 22f, 22f);
        pBrush.Color = Color.FromArgb(240, 244, 255);
        g.FillEllipse(pBrush, b.TipX - 11f, b.TipY - 11f, 10f, 10f);
        pBrush.Color = cInk;
        g.FillEllipse(pBrush, b.TipX - 4f, b.TipY - 4f, 8f, 8f);
    }

    // ------------------------------------------------------------------ the prince

    private void DrawPlayer(Graphics g, GameEngine e)
    {
        Player p = e.Player;
        if (e.ExitOpening && e.ExitProgress > 0.45f) return;     // the prince has stepped through the door

        Pose pose = Pose.Idle;
        float t = p.AnimTime;
        if (p.Dead) pose = Pose.Dead;
        else if (p.Climbing) { pose = Pose.Climb; if (!p.ClimbMoving) t = 0f; }
        else if (!p.OnGround) pose = p.VY < 0f ? Pose.Jump : Pose.Fall;
        else if (p.LandTimer > 0f) pose = Pose.Land;
        else if (p.Skidding) pose = Pose.Skid;
        else if (Math.Abs(p.VX) > 30f) pose = Pose.Run;

        int sx = (int)Math.Round(p.CenterX) - 20;
        int sy = (int)Math.Round(p.FeetY) - 60;

        if (pose == Pose.Dead)
        {
            float k = Math.Min(1f, p.DeadTime / 0.45f);
            GraphicsState st = g.Save();
            g.TranslateTransform(sx + 20, sy + 52);
            g.RotateTransform(-p.Facing * 90f * k);
            DrawPrince(g, -20, -52, 2, p.Facing, pose, t);
            g.Restore(st);
            return;
        }
        DrawPrince(g, sx, sy, 2, p.Facing, pose, t);
    }

    private void Limb(Graphics g, float x0, float y0, float x1, float y1, int w, Color[] set)
    {
        int steps = (int)Math.Max(Math.Abs(x1 - x0), Math.Abs(y1 - y0));
        if (steps < 1) steps = 1;
        for (int pass = 0; pass < 2; pass++)
        {
            for (int i = 0; i <= steps; i++)
            {
                float f = i / (float)steps;
                int x = (int)MathF.Round(x0 + (x1 - x0) * f - w / 2f + 0.5f);
                int y = (int)MathF.Round(y0 + (y1 - y0) * f);
                if (pass == 0)
                {
                    R(g, x - 1, y - 1, w + 2, 3, cInk);
                }
                else
                {
                    R(g, x, y, w, 2, set[1]);
                    H(g, x * 2, y * 2, 1, 4, set[0]);
                }
            }
        }
    }

    private void Boot(Graphics g, float fx, float fy)
    {
        RS(g, (int)MathF.Round(fx) - 1, (int)MathF.Round(fy) - 2, 5, 3, SetBoot);
    }

    /// <summary>The prince on a 20x30 grid (one grid cell = u screen pixels), facing right unless flipped.</summary>
    private void DrawPrince(Graphics g, int x, int y, int u, int facing, Pose pose, float t)
    {
        bool front = pose == Pose.Climb;
        Begin(x, y, u, !front && facing < 0);

        float ph = t * 14f;
        float s = MathF.Sin(ph);
        float c = MathF.Cos(ph);
        int dy = 0;
        int lean = 0;
        int hipRow = 19;
        float fax = 8f, fay = 29f, fbx = 12f, fby = 29f;
        float hbx = 6f, hby = 19f, hfx = 14f, hfy = 19f;

        switch (pose)
        {
            case Pose.Idle:
            case Pose.Dead:
                dy = ((int)(t * 2f)) % 2;
                fax = 7f; fbx = 12f;
                break;
            case Pose.Run:
                dy = -(int)MathF.Round(MathF.Abs(c));
                lean = 1;
                fax = 10f + 6f * s; fay = 29f - 5f * MathF.Max(0f, c);
                fbx = 10f - 6f * s; fby = 29f - 5f * MathF.Max(0f, -c);
                hfx = 11f - 5f * s; hfy = 18f;
                hbx = 8f + 5f * s; hby = 18f;
                break;
            case Pose.Skid:
                lean = -1;
                fax = 13f; fbx = 8f;
                hfx = 17f; hfy = 13f; hbx = 3f; hby = 15f;
                break;
            case Pose.Jump:
                lean = 1;
                fax = 13f; fay = 24f; fbx = 8f; fby = 28f;
                hfx = 16f; hfy = 7f; hbx = 4f; hby = 11f;
                break;
            case Pose.Fall:
                fax = 14f; fay = 28f; fbx = 5f; fby = 27f;
                hfx = 17f; hfy = 5f; hbx = 3f; hby = 6f;
                break;
            case Pose.Land:
                dy = 4;
                hipRow = 23;
                fax = 13f; fbx = 6f;
                hfx = 15f; hfy = 23f; hbx = 4f; hby = 23f;
                break;
            case Pose.Climb:
            {
                int ci = ((int)(t * 5f)) % 2;
                fax = 7f; fay = ci == 0 ? 29f : 25f;
                fbx = 12f; fby = ci == 0 ? 25f : 29f;
                hfx = 13f; hfy = ci == 0 ? 5f : 12f;
                hbx = 6f; hby = ci == 0 ? 12f : 5f;
                break;
            }
        }

        int fl = ((int)(t * 6f)) % 2;
        int shy = 11 + dy;

        // flowing cloth behind the body
        if (!front)
        {
            R(g, 3 + lean, 4 + dy + fl, 4, 1, SetSash[1]);
            R(g, 1 + lean, 5 + dy + fl, 3, 1, SetSash[2]);
        }
        RS(g, 5 + lean, 17 + dy, 2, 5 + fl, SetSash);

        // back arm (bare skin with a gold bracer)
        Limb(g, 7 + lean, shy, hbx, hby, 2, SetSkin);
        R(g, (int)MathF.Round((7 + lean + hbx) / 2f + 0.3f * (hbx - (7 + lean))), (int)MathF.Round(shy + (hby - shy) * 0.7f), 2, 1, SetGoldTrim[1]);

        // back leg
        Limb(g, 9f, hipRow + 2f, fbx, fby - 2f, 3, SetPantsD);
        Boot(g, fbx, fby);

        // torso: vest, bare chest, gold trim, sash and baggy trousers
        ROS(g, 6 + lean, 10 + dy, 8, 7, SetVest);
        R(g, 9 + lean, 10 + dy, 2, 5, SetSkin[1]);
        R(g, 6 + lean, 10 + dy, 1, 7, SetGoldTrim[1]);
        R(g, 13 + lean, 10 + dy, 1, 7, SetGoldTrim[1]);
        ROS(g, 6 + lean, 17 + dy, 8, 2, SetSash);
        RS(g, 5, hipRow, 9, 3, SetPants);

        // front leg
        Limb(g, 11f, hipRow + 2f, fax, fay - 2f, 3, SetPants);
        Boot(g, fax, fay);

        // head
        if (front)
        {
            ROS(g, 7 + lean, 3 + dy, 6, 6, SetHair);
            RS(g, 7 + lean, 4 + dy, 6, 1, SetSash);
            R(g, 9 + lean, 9 + dy, 2, 1, SetSkin[1]);
        }
        else
        {
            RS(g, 6 + lean, 4 + dy, 2, 5, SetHair);
            ROS(g, 7 + lean, 2 + dy, 7, 3, SetHair);
            ROS(g, 8 + lean, 4 + dy, 5, 5, SetSkin);
            RS(g, 7 + lean, 4 + dy, 7, 1, SetSash);
            R(g, 9 + lean, 9 + dy, 3, 1, SetSkin[1]);
            R(g, 11 + lean, 5 + dy, 2, 1, SetHair[2]);
            if (pose == Pose.Dead)
            {
                R(g, 10 + lean, 6 + dy, 1, 1, cInk);
                R(g, 12 + lean, 6 + dy, 1, 1, cInk);
                R(g, 11 + lean, 7 + dy, 1, 1, cInk);
            }
            else
            {
                R(g, 11 + lean, 6 + dy, 1, 1, cInk);
                H(g, (11 + lean) * 2 + 1, (6 + dy) * 2, 1, 1, cWhite);
                R(g, 13 + lean, 7 + dy, 1, 1, SetSkin[2]);
                R(g, 11 + lean, 8 + dy, 2, 1, Color.FromArgb(170, 70, 60));
            }
        }

        // front arm
        Limb(g, 12 + lean, shy, hfx, hfy, 2, SetSkin);
        R(g, (int)MathF.Round(12 + lean + (hfx - (12 + lean)) * 0.7f), (int)MathF.Round(shy + (hfy - shy) * 0.7f), 2, 1, SetGoldTrim[1]);
    }

    // ------------------------------------------------------------------ screens

    private void DrawTitle(Graphics g, GameEngine e)
    {
        int f = e.Frame;
        int areaH = Cfg.HudH + Cfg.ViewH;
        g.DrawImage(sky, new Rectangle(0, 0, Cfg.LogicalW, areaH), 0, 0, Cfg.LogicalW, Math.Min(sky.Height, areaH), GraphicsUnit.Pixel);
        DrawLayer(g, far, f * 0.25f, 0f);
        DrawLayer(g, near, f * 0.6f, 0f);

        // stone walls framing the view and a floor
        for (int r = 0; r < 16; r++)
        {
            for (int c = 0; c < 3; c++)
            {
                g.DrawImageUnscaled(wall[(c * 7 + r * 13) & 3], c * T, r * T);
                g.DrawImageUnscaled(wall[(c * 5 + r * 11 + 1) & 3], (19 - c) * T, r * T);
            }
        }
        for (int c = 3; c < 17; c++)
        {
            g.DrawImageUnscaled(wall[(c * 7) & 3], c * T, 14 * T);
            Rect(g, c * T, 14 * T, T, 3, Color.FromArgb(255, 226, 168));
            Rect(g, c * T, 14 * T + 3, T, 2, Color.FromArgb(240, 178, 108));
        }
        for (int c = 0; c < 3; c++)
        {
            Rect(g, c * T, 0, T, 0, Color.Black);
        }
        Rect(g, 3 * T - 6, 0, 6, 15 * T, Color.FromArgb(240, 178, 108));
        Rect(g, 17 * T, 0, 6, 15 * T, Color.FromArgb(150, 90, 60));
        DrawTorch(g, 60, 200, f);
        DrawTorch(g, 740, 200, f);

        DrawSpikeRow(g, 150, 520, 1f, false, f);
        DrawSpikeRow(g, 190, 520, 1f, false, f);
        DrawSpikeRow(g, 230, 520, 1f, false, f);
        DrawSpikeRow(g, 530, 520, 1f, false, f);
        DrawSpikeRow(g, 570, 520, 1f, false, f);
        DrawSpikeRow(g, 610, 520, 1f, false, f);

        titleBlade.Update(f / 60f);
        DrawBlade(g, titleBlade, f / 60f);

        // the prince leaps across the screen
        float jump = MathF.Sin(f * 0.035f);
        int py = 250 - (int)(MathF.Abs(jump) * 24f);
        DrawPrince(g, 350, py, 5, 1, Pose.Jump, f / 60f);

        g.DrawImage(titleBmp, new Rectangle(60, 14, 690, 84), 0, 0, titleBmp.Width, titleBmp.Height, GraphicsUnit.Pixel);
        g.DrawImage(subBmp, new Rectangle(175, 104, 450, 60), 0, 0, subBmp.Width, subBmp.Height, GraphicsUnit.Pixel);

        DrawBox(g, TitleButton);
        Color pc = ((f / 30) % 2 == 0) ? cWhite : cGold;
        Txt(g, "НАЧАТЬ ИГРУ  [Enter]", fText, pc, TitleButton.X + TitleButton.Width / 2f, TitleButton.Y + TitleButton.Height / 2f, sfCenter, true);

        Txt(g, "← →  бег     ПРОБЕЛ  прыжок     ↑ ↓  лестницы, двери, рычаги", fSmall, cWhite, Cfg.LogicalW / 2f, 484f, sfCenter, true);
        Txt(g, "Esc  пауза     R  заново     F11  полный экран     N  звук", fSmall, Color.FromArgb(255, 210, 160), Cfg.LogicalW / 2f, 504f, sfCenter, true);
    }

    private void DrawPanel(Graphics g, GameEngine e, string title, Color titleColor, string[] lines, string? prompt)
    {
        using (SolidBrush dim = new SolidBrush(Color.FromArgb(150, 10, 4, 24)))
        {
            g.FillRectangle(dim, 0, 0, Cfg.LogicalW, Cfg.HudH + Cfg.ViewH);
        }
        Rectangle r = new Rectangle(130, 150, 540, 320);
        DrawBox(g, r);
        Txt(g, title, fMid, titleColor, r.X + r.Width / 2f, r.Y + 52f, sfCenter, true);
        for (int i = 0; i < lines.Length; i++)
        {
            Txt(g, lines[i], fText, cWhite, r.X + r.Width / 2f, r.Y + 112f + i * 34f, sfCenter, true);
        }
        if (prompt != null)
        {
            Color pc = ((e.Frame / 30) % 2 == 0) ? cWhite : cGold;
            if (e.State == GameState.Dead)
            {
                DrawBox(g, RetryButton);
                Txt(g, prompt, fSmall, pc, RetryButton.X + RetryButton.Width / 2f, RetryButton.Y + RetryButton.Height / 2f, sfCenter, true);
                Txt(g, "Esc — главное меню", fSmall, Color.FromArgb(255, 210, 160), r.X + r.Width / 2f, r.Y + r.Height - 26f, sfCenter, true);
            }
            else
            {
                Txt(g, prompt, fText, pc, r.X + r.Width / 2f, r.Y + r.Height - 40f, sfCenter, true);
            }
        }
    }

    private void DrawFooter(Graphics g)
    {
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        Rectangle r = new Rectangle(0, Cfg.LogicalH - Cfg.FooterH, Cfg.LogicalW, Cfg.FooterH);
        Bands(g, r.X, r.Y, r.Width, r.Height, Color.FromArgb(56, 30, 60), Color.FromArgb(14, 8, 26), 4);
        Rect(g, 0, r.Y, Cfg.LogicalW, 1, Color.FromArgb(255, 200, 160));
        Rect(g, 0, r.Y + 1, Cfg.LogicalW, 2, cGoldD);
        using (SolidBrush tb = new SolidBrush(cWhite))
        {
            g.DrawString(FooterText, fFooter, tb, new RectangleF(0f, r.Y + 3f, Cfg.LogicalW, r.Height - 3f), sfCenter);
        }
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private Bitmap MakeTitle(string text, float size, int w, int h, Color b1, Color b2, Color b3, Color b4)
    {
        Bitmap bmp = new Bitmap(w, h, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        using (Font f = new Font("Georgia", size, FontStyle.Bold, GraphicsUnit.Pixel))
        using (StringFormat sf = new StringFormat())
        using (SolidBrush ink = new SolidBrush(cInk))
        using (SolidBrush a1 = new SolidBrush(b1))
        using (SolidBrush a2 = new SolidBrush(b2))
        using (SolidBrush a3 = new SolidBrush(b3))
        using (SolidBrush a4 = new SolidBrush(b4))
        {
            g.SmoothingMode = SmoothingMode.None;
            g.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            sf.FormatFlags = StringFormatFlags.NoWrap;
            for (int dx = -1; dx <= 1; dx++)
            {
                for (int dy = -1; dy <= 2; dy++)
                {
                    if (dx == 0 && dy == 0) continue;
                    g.DrawString(text, f, ink, new RectangleF(dx, dy, w, h), sf);
                }
            }
            int q = h / 4;
            g.SetClip(new Rectangle(0, 0, w, q));
            g.DrawString(text, f, a1, new RectangleF(0, 0, w, h), sf);
            g.SetClip(new Rectangle(0, q, w, q));
            g.DrawString(text, f, a2, new RectangleF(0, 0, w, h), sf);
            g.SetClip(new Rectangle(0, q * 2, w, q));
            g.DrawString(text, f, a3, new RectangleF(0, 0, w, h), sf);
            g.SetClip(new Rectangle(0, q * 3, w, h - q * 3));
            g.DrawString(text, f, a4, new RectangleF(0, 0, w, h), sf);
            g.ResetClip();
        }
        return bmp;
    }

    private Bitmap MakeSky()
    {
        int W = Cfg.LogicalW;
        int Hh = Cfg.HudH + Cfg.ViewH;
        Bitmap bmp = new Bitmap(W, Hh, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.None;
            Color[] stops =
            {
                Color.FromArgb(22, 18, 76), Color.FromArgb(86, 44, 128), Color.FromArgb(204, 84, 116),
                Color.FromArgb(252, 146, 76), Color.FromArgb(255, 210, 124)
            };
            for (int y = 0; y < Hh; y += 8)
            {
                float t = y / (float)(Hh - 1) * (stops.Length - 1);
                int i = Math.Min(stops.Length - 2, (int)t);
                Rect(g, 0, y, W, 8, Lerp(stops[i], stops[i + 1], t - i));
            }
            // sun with banded halo
            int sx = 560;
            int sy = 400;
            for (int i = 5; i >= 1; i--)
            {
                using (SolidBrush halo = new SolidBrush(Color.FromArgb(22, 255, 220, 140)))
                {
                    g.FillEllipse(halo, sx - 40 - i * 26, sy - 40 - i * 26, (40 + i * 26) * 2, (40 + i * 26) * 2);
                }
            }
            Rect(g, 0, 0, 0, 0, Color.Black);
            using (SolidBrush sun = new SolidBrush(Color.FromArgb(255, 238, 176)))
            {
                g.FillEllipse(sun, sx - 40, sy - 40, 80, 80);
            }
            using (SolidBrush sun2 = new SolidBrush(Color.FromArgb(255, 252, 226)))
            {
                g.FillEllipse(sun2, sx - 30, sy - 30, 60, 60);
            }
            // pixel clouds
            Random rnd = new Random(21);
            for (int i = 0; i < 26; i++)
            {
                int cx = rnd.Next(W / 4) * 4;
                int cy = 60 + rnd.Next(60) * 4;
                int cw = 40 + rnd.Next(18) * 8;
                int ch = 4 + rnd.Next(2) * 4;
                using (SolidBrush cl = new SolidBrush(Color.FromArgb(150, 255, 160 + rnd.Next(40), 120 + rnd.Next(40))))
                {
                    g.FillRectangle(cl, cx, cy, cw, ch);
                }
                using (SolidBrush cl2 = new SolidBrush(Color.FromArgb(120, 110, 56, 130)))
                {
                    g.FillRectangle(cl2, cx + 6, cy + ch, cw - 12, 3);
                }
            }
        }
        return bmp;
    }

    private Bitmap MakeFar()
    {
        int W = 1200;
        Bitmap bmp = new Bitmap(W, Cfg.HudH + Cfg.ViewH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.None;
            using (SolidBrush m1 = new SolidBrush(Color.FromArgb(140, 70, 120)))
            using (SolidBrush m2 = new SolidBrush(Color.FromArgb(110, 56, 110)))
            {
                int baseY = 520;
                PointF[] a = { new PointF(0, baseY), new PointF(120, 410), new PointF(220, 450), new PointF(330, 380), new PointF(460, 470), new PointF(520, baseY) };
                PointF[] b = { new PointF(480, baseY), new PointF(610, 420), new PointF(700, 440), new PointF(830, 360), new PointF(960, 450), new PointF(1060, 420), new PointF(1200, baseY) };
                g.FillPolygon(m1, a);
                g.FillPolygon(m2, b);
            }
        }
        return bmp;
    }

    private Bitmap MakeNear()
    {
        int W = 1200;
        int baseY = 540;
        Bitmap bmp = new Bitmap(W, Cfg.HudH + Cfg.ViewH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        using (SolidBrush sil = new SolidBrush(Color.FromArgb(78, 38, 96)))
        using (SolidBrush silD = new SolidBrush(Color.FromArgb(58, 28, 78)))
        using (SolidBrush glow = new SolidBrush(Color.FromArgb(255, 210, 120)))
        {
            g.SmoothingMode = SmoothingMode.None;
            // palace skyline
            int[] bx = { 120, 260, 420, 600, 760, 940 };
            int[] bw = { 90, 70, 130, 110, 80, 100 };
            int[] bh = { 120, 190, 150, 220, 130, 170 };
            for (int i = 0; i < bx.Length; i++)
            {
                g.FillRectangle(sil, bx[i], baseY - bh[i], bw[i], bh[i]);
                g.FillEllipse(sil, bx[i] + 6, baseY - bh[i] - bw[i] / 3, bw[i] - 12, bw[i] / 2 + 8);
                g.FillRectangle(sil, bx[i] + bw[i] / 2 - 2, baseY - bh[i] - bw[i] / 3 - 22, 4, 22);
                g.FillRectangle(glow, bx[i] + 14, baseY - bh[i] + 22, 8, 14);
                g.FillRectangle(glow, bx[i] + bw[i] - 22, baseY - bh[i] + 40, 8, 14);
            }
            // minarets
            int[] mx = { 40, 210, 520, 880, 1090 };
            for (int i = 0; i < mx.Length; i++)
            {
                int mh = 230 + (i % 3) * 40;
                g.FillRectangle(silD, mx[i], baseY - mh, 16, mh);
                g.FillRectangle(silD, mx[i] - 4, baseY - mh + 40, 24, 6);
                g.FillEllipse(silD, mx[i] - 2, baseY - mh - 14, 20, 24);
                g.FillRectangle(silD, mx[i] + 7, baseY - mh - 28, 2, 16);
            }
            g.FillRectangle(silD, 0, baseY, W, Cfg.HudH + Cfg.ViewH - baseY);
            // palms
            int[] px = { 90, 340, 700, 1010 };
            for (int i = 0; i < px.Length; i++)
            {
                g.FillRectangle(silD, px[i], baseY - 70, 5, 70);
                for (int k = 0; k < 5; k++)
                {
                    float a = -2.5f + k * 1.25f;
                    g.FillEllipse(silD, px[i] + 2 + MathF.Cos(a) * 18f - 14f, baseY - 76 + MathF.Sin(a) * 9f - 3f, 28f, 7f);
                }
            }
        }
        return bmp;
    }

    private Bitmap MakeVignette()
    {
        Bitmap bmp = new Bitmap(Cfg.LogicalW, Cfg.ViewH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.None;
            for (int i = 0; i < 12; i++)
            {
                int a = 8 + i * 3;
                using (SolidBrush b = new SolidBrush(Color.FromArgb(Math.Min(110, a), 12, 4, 28)))
                {
                    int e = (12 - i) * 6;
                    g.FillRectangle(b, 0, 0, e, Cfg.ViewH);
                    g.FillRectangle(b, Cfg.LogicalW - e, 0, e, Cfg.ViewH);
                    g.FillRectangle(b, 0, 0, Cfg.LogicalW, e / 2);
                    g.FillRectangle(b, 0, Cfg.ViewH - e / 2, Cfg.LogicalW, e / 2);
                }
            }
        }
        return bmp;
    }

    private static Color StoneRamp(int lvl)
    {
        Color[] ramp =
        {
            Color.FromArgb(58, 30, 44), Color.FromArgb(112, 62, 58), Color.FromArgb(160, 96, 68),
            Color.FromArgb(206, 134, 84), Color.FromArgb(240, 178, 108), Color.FromArgb(255, 218, 156)
        };
        return ramp[Math.Max(0, Math.Min(5, lvl))];
    }

    private Bitmap MakeWall(int seed)
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        for (int y = 0; y < T; y++)
        {
            for (int x = 0; x < T; x++)
            {
                int row = y / 20;
                int ry = y % 20;
                int xx = x + ((row + seed) % 2) * 20;
                int bx = xx % 40;
                Color c;
                if (ry == 19 || bx == 39)
                {
                    c = StoneRamp(0);
                }
                else
                {
                    int lvl;
                    if (ry == 0) lvl = 5;
                    else if (ry <= 2) lvl = 4;
                    else if (ry <= 9) lvl = 3;
                    else if (ry <= 15) lvl = 2;
                    else lvl = 1;
                    if (bx == 0) lvl++;
                    else if (bx >= 37) lvl--;
                    int n = Hash(x + seed * 53, y + row * 7) % 19;
                    if (ry > 2 && ry < 17 && n == 0) lvl--;
                    else if (ry > 2 && ry < 17 && n == 1) lvl++;
                    c = StoneRamp(lvl);
                }
                bmp.SetPixel(x, y, c);
            }
        }
        // carved decoration on one variant
        if (seed == 3)
        {
            for (int i = -5; i <= 5; i++)
            {
                int d = 5 - Math.Abs(i);
                bmp.SetPixel(19 + i, 8 + d, StoneRamp(1));
                bmp.SetPixel(19 + i, 8 - d, StoneRamp(1));
            }
        }
        return bmp;
    }

    private Bitmap MakeBack(int seed)
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color[] ramp =
        {
            Color.FromArgb(24, 14, 34), Color.FromArgb(44, 26, 52), Color.FromArgb(66, 38, 66), Color.FromArgb(88, 52, 78)
        };
        for (int y = 0; y < T; y++)
        {
            for (int x = 0; x < T; x++)
            {
                int row = y / 10;
                int ry = y % 10;
                int xx = x + ((row + seed) % 2) * 10;
                int bx = xx % 20;
                Color c;
                if (ry == 9 || bx == 19) c = ramp[0];
                else
                {
                    int lvl = ry <= 1 ? 3 : (ry <= 6 ? 2 : 1);
                    if (bx == 0) lvl = Math.Min(3, lvl + 1);
                    int n = Hash(x + seed * 31, y) % 17;
                    if (n == 0) lvl = Math.Max(1, lvl - 1);
                    c = ramp[lvl];
                }
                bmp.SetPixel(x, y, c);
            }
        }
        return bmp;
    }

    private Bitmap MakeWindow()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color[] ramp =
        {
            Color.FromArgb(24, 14, 34), Color.FromArgb(44, 26, 52), Color.FromArgb(66, 38, 66), Color.FromArgb(88, 52, 78)
        };
        for (int y = 0; y < T; y++)
        {
            for (int x = 0; x < T; x++)
            {
                int row = y / 10;
                int ry = y % 10;
                int bx = (x + (row % 2) * 10) % 20;
                Color c = (ry == 9 || bx == 19) ? ramp[0] : ramp[ry <= 1 ? 3 : 2];
                float dx = x - 19.5f;
                float dy = y - 16f;
                bool openArea = x >= 11 && x <= 28 && y <= 33 && (y >= 16 || dx * dx + dy * dy <= 8.5f * 8.5f);
                bool frame = x >= 8 && x <= 31 && y <= 35 && (y >= 16 || dx * dx + dy * dy <= 11.5f * 11.5f);
                if (frame && !openArea)
                {
                    c = x < 19.5f ? StoneRamp(4) : StoneRamp(2);
                    if (y >= 34) c = StoneRamp(5);
                }
                if (openArea)
                {
                    float t = (y - 6f) / 27f;
                    c = t < 0.5f ? Lerp(Color.FromArgb(70, 44, 130), Color.FromArgb(230, 100, 110), t * 2f)
                                 : Lerp(Color.FromArgb(230, 100, 110), Color.FromArgb(255, 200, 100), (t - 0.5f) * 2f);
                    if (x == 19 || x == 20 || y == 22) c = ramp[0];
                }
                bmp.SetPixel(x, y, c);
            }
        }
        return bmp;
    }

    private Bitmap MakeLadder()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color[] rail =
        {
            Color.FromArgb(150, 94, 50), Color.FromArgb(222, 164, 96), Color.FromArgb(182, 120, 64), Color.FromArgb(94, 56, 30)
        };
        Color[] rung =
        {
            Color.FromArgb(226, 170, 100), Color.FromArgb(182, 120, 64), Color.FromArgb(122, 76, 40), Color.FromArgb(70, 40, 24)
        };
        int[] railX = { 8, 28 };
        foreach (int rx in railX)
        {
            for (int y = 0; y < T; y++)
            {
                bmp.SetPixel(rx - 1, y, cInk);
                bmp.SetPixel(rx + 4, y, cInk);
                for (int i = 0; i < 4; i++) bmp.SetPixel(rx + i, y, rail[i]);
            }
        }
        int[] rungY = { 4, 14, 24, 34 };
        foreach (int ry in rungY)
        {
            for (int x = 12; x < 28; x++)
            {
                if (ry - 1 >= 0) bmp.SetPixel(x, ry - 1, cInk);
                if (ry + 4 < T) bmp.SetPixel(x, ry + 4, cInk);
                for (int i = 0; i < 4; i++) bmp.SetPixel(x, ry + i, rung[i]);
            }
        }
        return bmp;
    }

    private Bitmap MakeCrumble()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        for (int y = 0; y < T; y++)
        {
            for (int x = 0; x < T; x++)
            {
                int d = Math.Min(Math.Min(x, y), Math.Min(T - 1 - x, T - 1 - y));
                int lvl;
                if (d == 0) lvl = 0;
                else if (y <= 2) lvl = 5;
                else if (y < 14) lvl = 3;
                else if (y < 30) lvl = 2;
                else lvl = 1;
                if (d == 1 && y > 2) lvl = (x < 20) ? Math.Min(5, lvl + 1) : Math.Max(1, lvl - 1);
                int n = Hash(x, y + 91) % 23;
                if (d > 1 && n == 0) lvl = Math.Max(1, lvl - 1);
                bmp.SetPixel(x, y, StoneRamp(lvl));
            }
        }
        // cracks
        int[][] cracks =
        {
            new[] { 10, 4, 14, 12, 12, 18, 18, 26, 16, 34 },
            new[] { 30, 6, 26, 14, 30, 22, 24, 30, 28, 38 }
        };
        foreach (int[] cr in cracks)
        {
            for (int i = 0; i + 3 < cr.Length; i += 2)
            {
                int x0 = cr[i], y0 = cr[i + 1], x1 = cr[i + 2], y1 = cr[i + 3];
                int steps = Math.Max(Math.Abs(x1 - x0), Math.Abs(y1 - y0));
                for (int k = 0; k <= steps; k++)
                {
                    int px = x0 + (x1 - x0) * k / Math.Max(1, steps);
                    int py = y0 + (y1 - y0) * k / Math.Max(1, steps);
                    bmp.SetPixel(px, py, StoneRamp(0));
                    if (px + 1 < T) bmp.SetPixel(px + 1, py, StoneRamp(1));
                }
            }
        }
        return bmp;
    }
}
