namespace PrinceOfPersia;

/// <summary>Floor spikes that cycle: hidden, warning (tips peek out and flash), then up and deadly.</summary>
public sealed class SpikeTrap
{
    public const float Cycle = 3.2f;
    public const float DownTime = 1.6f;
    public const float WarnTime = 0.6f;

    public readonly int Col;
    public readonly int Row;
    public float Height;      // 0..1
    public bool Warning;
    private readonly float offset;

    public SpikeTrap(int col, int row)
    {
        Col = col;
        Row = row;
        offset = (col / 4) * 1.1f;
    }

    public bool Lethal { get { return Height > 0.5f; } }

    public void Update(float time)
    {
        float t = (time + offset) % Cycle;
        if (t < DownTime)
        {
            Height = 0f;
            Warning = false;
        }
        else if (t < DownTime + WarnTime)
        {
            Height = 0.15f;
            Warning = true;
        }
        else
        {
            float u = t - DownTime - WarnTime;
            Height = Math.Min(1f, 0.15f + u * 12f);
            Warning = false;
        }
    }
}

/// <summary>A pendulum blade hanging from the ceiling. Only the blade head is deadly.</summary>
public sealed class Blade
{
    public const float Radius = 13f;

    public readonly int Col;
    public readonly int Row;
    public readonly float Length;
    public readonly float Period;
    public readonly float Phase;
    public readonly float Amplitude;
    public float Angle;       // degrees
    public float AnchorX;
    public float AnchorY;
    public float TipX;
    public float TipY;

    public Blade(BladeDef d)
    {
        Col = d.Col;
        Row = d.Row;
        Length = d.Length;
        Period = d.Period;
        Phase = d.Phase;
        Amplitude = d.Amplitude;
        AnchorX = Col * Cfg.T + Cfg.T / 2f;
        AnchorY = Row * Cfg.T;
        Update(0f);
    }

    public void Update(float time)
    {
        Angle = Amplitude * MathF.Sin(2f * MathF.PI * (time / Period + Phase));
        float rad = Angle * MathF.PI / 180f;
        TipX = AnchorX + Length * MathF.Sin(rad);
        TipY = AnchorY + Length * MathF.Cos(rad);
    }

    /// <summary>Circle against rectangle test.</summary>
    public bool Hits(float x, float y, float w, float h)
    {
        float nx = Math.Max(x, Math.Min(TipX, x + w));
        float ny = Math.Max(y, Math.Min(TipY, y + h));
        float dx = TipX - nx;
        float dy = TipY - ny;
        return dx * dx + dy * dy <= Radius * Radius;
    }
}

public enum CrumbleState { Idle, Armed, Falling, Gone }

/// <summary>A slab that shakes shortly after being touched and then drops away.</summary>
public sealed class Crumble
{
    public const float ArmTime = 0.45f;
    public const float FallTime = 0.8f;

    public readonly int Col;
    public readonly int Row;
    public CrumbleState State = CrumbleState.Idle;
    public float Timer;
    public bool JustFell;

    public Crumble(int col, int row)
    {
        Col = col;
        Row = row;
    }

    public void Trigger()
    {
        if (State != CrumbleState.Idle) return;
        State = CrumbleState.Armed;
        Timer = 0f;
    }

    public void Update(float dt, GameLevel lv)
    {
        JustFell = false;
        if (State == CrumbleState.Armed)
        {
            Timer += dt;
            if (Timer >= ArmTime)
            {
                State = CrumbleState.Falling;
                Timer = 0f;
                lv.Cells[Col, Row] = Tile.Interior;
                JustFell = true;
            }
        }
        else if (State == CrumbleState.Falling)
        {
            Timer += dt;
            if (Timer >= FallTime) State = CrumbleState.Gone;
        }
    }
}
