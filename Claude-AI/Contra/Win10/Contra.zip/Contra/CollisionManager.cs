namespace Contra;

/// <summary>Body-versus-level physics and all hit tests between shots, soldiers, barrels, the boss and pickups.</summary>
public static class CollisionManager
{
    public static bool CircleRect(float cx, float cy, float r, RectangleF rc)
    {
        float nx = Math.Max(rc.Left, Math.Min(cx, rc.Right));
        float ny = Math.Max(rc.Top, Math.Min(cy, rc.Bottom));
        float dx = cx - nx;
        float dy = cy - ny;
        return dx * dx + dy * dy <= r * r;
    }

    /// <summary>
    /// Moves a box (centre x, bottom y, half width hw, height h) by its velocity against the solids of the level, one axis
    /// at a time. Thin platforms can only be landed on from above. Returns true when the box stands on something.
    /// </summary>
    public static bool MoveBody(Level lv, ref float x, ref float y, ref float vx, ref float vy, float hw, float h, float dt)
    {
        // horizontal
        x += vx * dt;
        float top = y - h;
        float bottom = y;
        foreach (Solid s in lv.Solids)
        {
            if (s.OneWay) continue;
            RectangleF r = s.Rect;
            if (x + hw > r.Left && x - hw < r.Right && bottom > r.Top + 1.5f && top < r.Bottom)
            {
                if (vx > 0f) x = r.Left - hw;
                else if (vx < 0f) x = r.Right + hw;
                else x += (x < r.Left + r.Width / 2f) ? -1f : 1f;
                vx = 0f;
            }
        }

        // vertical
        float prevBottom = y;
        y += vy * dt;
        bool grounded = false;
        foreach (Solid s in lv.Solids)
        {
            RectangleF r = s.Rect;
            if (x + hw <= r.Left || x - hw >= r.Right) continue;
            if (vy >= 0f)
            {
                if (y >= r.Top && prevBottom <= r.Top + 1f)
                {
                    y = r.Top;
                    vy = 0f;
                    grounded = true;
                }
            }
            else if (!s.OneWay)
            {
                if (y - h < r.Bottom && prevBottom - h >= r.Bottom - 1f)
                {
                    y = r.Bottom + h;
                    vy = 0f;
                }
            }
        }
        return grounded;
    }

    public static void Resolve(GameEngine g)
    {
        PlayerShots(g);
        EnemyShots(g);
        Contacts(g);
        PickupsVsPlayer(g);
    }

    private static void PlayerShots(GameEngine g)
    {
        List<Projectile> items = g.Shots.Items;
        for (int i = 0; i < items.Count; i++)
        {
            Projectile p = items[i];
            if (!p.Alive || !p.FromPlayer) continue;

            // explosive barrels and ammunition containers
            List<Barrel> barrels = g.Barrels.Items;
            for (int k = 0; k < barrels.Count; k++)
            {
                Barrel b = barrels[k];
                if (!b.Alive || !CircleRect(p.X, p.Y, p.Radius, b.Rect)) continue;
                if (!p.TryHit(-1000 - k)) continue;
                b.HitFlash = 0.1f;
                g.Barrels.Destroy(b, 0);
                g.Particles.Sparks(p.X, p.Y, 70f, 3, Color.FromArgb(255, 220, 120));
                if (--p.Pierce <= 0) { p.Alive = false; break; }
            }
            if (!p.Alive) continue;

            bool done = false;
            foreach (Enemy e in g.Enemies.Enemies)
            {
                if (!e.Hittable || !CircleRect(p.X, p.Y, p.Radius, e.Rect)) continue;
                if (!p.TryHit(e.Id)) continue;
                g.Enemies.Damage(e, p.Damage);
                g.Particles.Sparks(p.X, p.Y, 70f, 3, Color.FromArgb(255, 230, 140));
                if (--p.Pierce <= 0) p.Alive = false;
                done = true;
                break;
            }
            if (done) continue;

            if (g.Boss.Vulnerable && CircleRect(p.X, p.Y, p.Radius, g.Boss.Rect) && p.TryHit(-1))
            {
                g.Boss.Damage(p.Damage);
                g.Particles.Sparks(p.X, p.Y, 80f, 3, Color.FromArgb(255, 230, 140));
                if (--p.Pierce <= 0) p.Alive = false;
            }
        }
    }

    private static void EnemyShots(GameEngine g)
    {
        if (!g.Player.Vulnerable) return;
        RectangleF body = g.Player.Rect;
        List<Projectile> items = g.Shots.Items;
        for (int i = 0; i < items.Count; i++)
        {
            Projectile p = items[i];
            if (!p.Alive || p.FromPlayer) continue;
            if (CircleRect(p.X, p.Y, p.Radius, body))
            {
                p.Alive = false;
                g.PlayerHurt((int)Math.Max(1f, p.Damage), p.VX >= 0f ? 1f : -1f);
                if (!g.Player.Vulnerable) return;
            }
        }
    }

    private static void Contacts(GameEngine g)
    {
        if (!g.Player.Vulnerable) return;
        if (g.Boss.Vulnerable && g.Boss.Rect.IntersectsWith(g.Player.Rect)) g.PlayerHurt(1, g.Player.X < g.Boss.X ? -1f : 1f);
    }

    private static void PickupsVsPlayer(GameEngine g)
    {
        if (g.Player.Dead) return;
        RectangleF body = g.Player.Rect;
        List<Pickup> items = g.Pickups.Items;
        for (int i = 0; i < items.Count; i++)
        {
            Pickup p = items[i];
            if (!p.Alive) continue;
            RectangleF r = new RectangleF(p.X - Pickup.HalfW, p.Y - Pickup.Size, Pickup.HalfW * 2f, Pickup.Size);
            if (r.IntersectsWith(body)) g.CollectPickup(p);
        }
    }
}
