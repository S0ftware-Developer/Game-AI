namespace Contra;

/// <summary>Owns all bullets, moves them and removes them when they leave the playable area or hit solid structures.</summary>
public sealed class ProjectileManager
{
    public readonly List<Projectile> Items = new List<Projectile>(256);
    private readonly Stack<Projectile> pool = new Stack<Projectile>(256);

    public void Clear()
    {
        foreach (Projectile p in Items) pool.Push(p);
        Items.Clear();
    }

    public Projectile Spawn(ShotKind kind, float x, float y, float vx, float vy, float damage, float life, int pierce = 1)
    {
        Projectile p = pool.Count > 0 ? pool.Pop() : new Projectile();
        p.Kind = kind;
        p.X = x; p.Y = y; p.VX = vx; p.VY = vy;
        p.Damage = damage;
        p.Life = life;
        p.Age = 0f;
        p.Pierce = pierce;
        p.ResetHits();
        p.Alive = true;
        switch (kind)
        {
            case ShotKind.Machine: p.Radius = 2f; break;
            case ShotKind.Spread: p.Radius = 2.5f; break;
            case ShotKind.Laser: p.Radius = 3f; break;
            case ShotKind.Flame: p.Radius = 4f; break;
            case ShotKind.EBullet: p.Radius = 2.5f; break;
            default: p.Radius = 4f; break;
        }
        Items.Add(p);
        return p;
    }

    public void Update(float dt, Level level, float camLeft, float camRight)
    {
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Projectile p = Items[i];
            if (p.Alive)
            {
                p.Age += dt;
                p.X += p.VX * dt;
                p.Y += p.VY * dt;
                p.Life -= dt;
                if (p.Kind == ShotKind.Flame)
                {
                    p.VX *= 1f - 1.2f * dt;          // flames slow down and die out quickly
                    p.VY *= 1f - 1.2f * dt;
                    p.Y -= 12f * dt;                 // and rise a little
                }
                if (p.Life <= 0f) p.Alive = false;
                else if (p.X < camLeft - 40f || p.X > camRight + 40f || p.Y < -40f || p.Y > GameConfig.ViewH + 40f) p.Alive = false;
                else if (level.SolidAt(p.X, p.Y)) p.Alive = false;
            }
            if (!p.Alive)
            {
                Items[i] = Items[Items.Count - 1];
                Items.RemoveAt(Items.Count - 1);
                pool.Push(p);
            }
        }
    }
}
