namespace Contra;

/// <summary>An explosive barrel or military ammunition container. Shooting it (or a blast nearby) detonates it.</summary>
public sealed class Barrel
{
    public float X, Y;                    // centre and bottom
    public bool Ammo;                     // an ammunition container instead of a barrel
    public bool Alive = true;
    public float HitFlash;

    public RectangleF Rect
    {
        get { return Ammo ? new RectangleF(X - 8f, Y - 11f, 16f, 11f) : new RectangleF(X - 6f, Y - 16f, 12f, 16f); }
    }
}

public struct Blast
{
    public float X, Y;
    public int Chain;
}

public sealed class BarrelManager
{
    public readonly List<Barrel> Items = new List<Barrel>(32);
    public readonly List<Blast> Blasts = new List<Blast>(8);    // barrels destroyed since the engine last looked

    public void Reset(Level level)
    {
        Items.Clear();
        Blasts.Clear();
        foreach (BarrelSpawn s in level.Barrels)
        {
            Barrel b = new Barrel();
            b.X = s.X;
            b.Y = s.Y;
            b.Ammo = s.Ammo;
            Items.Add(b);
        }
    }

    public void Update(float dt)
    {
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Barrel b = Items[i];
            if (b.HitFlash > 0f) b.HitFlash = Math.Max(0f, b.HitFlash - dt);
            if (!b.Alive) Items.RemoveAt(i);
        }
    }

    /// <summary>Destroys a barrel and queues its explosion.</summary>
    public void Destroy(Barrel b, int chain)
    {
        if (!b.Alive) return;
        b.Alive = false;
        Blast bl = new Blast();
        bl.X = b.X;
        bl.Y = b.Y - 8f;
        bl.Chain = chain;
        Blasts.Add(bl);
    }
}
