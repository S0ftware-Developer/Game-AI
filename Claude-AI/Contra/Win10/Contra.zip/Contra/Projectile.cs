namespace Contra;

public enum ShotKind { Machine, Spread, Laser, Flame, EBullet, EBig }

/// <summary>A bullet, laser bolt, flame particle or enemy shot. Instances are pooled by <see cref="ProjectileManager"/>.</summary>
public sealed class Projectile
{
    public float X, Y, VX, VY;
    public float Life, Age;
    public float Damage;
    public float Radius;
    public int Pierce = 1;               // how many targets it can still pass through
    public ShotKind Kind;
    public bool Alive;
    private readonly int[] hitIds = new int[6];
    private int hitCount;

    public bool FromPlayer { get { return Kind <= ShotKind.Flame; } }

    /// <summary>Remembers the target; returns false when this shot already hit it (piercing shots).</summary>
    public bool TryHit(int id)
    {
        for (int i = 0; i < hitCount; i++)
        {
            if (hitIds[i] == id) return false;
        }
        if (hitCount < hitIds.Length) hitIds[hitCount++] = id;
        return true;
    }

    public void ResetHits()
    {
        hitCount = 0;
    }
}
