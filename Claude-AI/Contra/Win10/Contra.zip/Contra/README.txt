﻿CONTRA - RUN AND GUN
====================

© 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space

GAME
----
A compact side-scrolling run-and-gun in the style of an 8-bit arcade game. You are a commando fighting through a jungle
military outpost and an enemy base to a final boss. One level, three sections (jungle entrance, military outpost, enemy
base) and the boss arena; about 3-5 minutes. Run, jump, crouch, aim in five directions (forward, up, down and both
diagonals), shoot while running or jumping, throw grenades, collect weapon capsules, blow up explosive barrels and
destroy the armoured weapon platform at the end.

You start with 3 lives and 3 health points. Two checkpoints (the outpost entrance and the enemy base entrance) save your
respawn position. Water gaps cost a life. Extra lives and health pickups are placed at fixed positions.

WINDOWS REQUIREMENTS
--------------------
Windows 10 or 11, 64-bit. The built game is one standalone EXE; no runtime has to be installed to play it.
To BUILD it you need the .NET SDK 8 or newer (8, 9 and 10 all work). The game is not built for you: build it locally
with build.bat (see below).

CONTROLS
--------
A / Left Arrow       move left                 D / Right Arrow     move right
Space                jump (hold for higher)    W / Up Arrow        aim up (with A / D: diagonally up)
S / Down Arrow       crouch when standing; aim down in the air; with A / D: aim diagonally down
J / Ctrl             shoot                     K / X               throw a grenade
1  2  3  4           machine gun, spread gun, laser gun, fire gun (only if it has ammunition)
Escape               pause (Resume, Restart, Sound on/off, Main menu)
F11 or Alt+Enter     full screen
Menus: W / S or the arrow keys and Enter, or the mouse.

WEAPONS
-------
1 Machine gun - rapid straight fire, unlimited ammunition, moderate damage. Always available.
2 Spread gun  - three bullets in a fan (limited ammunition).
3 Laser gun   - a fast, powerful bolt that pierces several enemies (limited ammunition).
4 Fire gun    - short-range flame particles that burn everything close (limited ammunition).
Capsules marked S, L and F equip that weapon and refill its ammunition (picking up the weapon you hold refills it).
An empty weapon returns to the machine gun. G capsules give 2 grenades, + restores health, 1UP gives a life.
Grenades (start with 3, cooldown between throws) fly in an arc in the direction you face, bounce and explode after about
a second with a visible blast ring; they damage enemies, the boss and explosive barrels.

ENEMIES
-------
Infantry (green) walk toward you and fire now and then. Rifle soldiers (blue, kneeling) hold a position and fire bursts.
Grenadiers (brown) throw grenades in an arc. Heavy soldiers (large, red) are slow, tough and fire powerful shots. Elite
soldiers (black, red beret) appear in the enemy base and fire fast bursts. Gun turrets are destructible emplacements.
Enemy bullets are red; yours are yellow, pink, cyan and orange. Explosive barrels and ammunition containers blow up
neighbouring objects and enemies (and you, if you stand too close).

BOSS
----
A big armoured mobile weapon platform. Phase 1: horizontal bursts from three gun ports - jump over them or crouch under
the lowest. Below half health: faster bursts and a big aimed missile, and the machine burns. It can be beaten with the
starting machine gun alone. The health bar is shown at the bottom of the screen.

HOW TO BUILD AND LAUNCH
-----------------------
1. Unzip Contra.zip to any folder (a path with spaces or parentheses is fine).
2. Double-click build.bat. It shows the installed SDK version, checks that it is 8 or newer, publishes a self-contained
   single-file Windows x64 build and keeps the window open. The first build needs an internet connection for NuGet.
3. The game is created at:   bin\Release\net8.0-windows\win-x64\publish\Contra.exe
   Double-click it to play. The publish folder contains only this one file.
The best score is saved in %APPDATA%\Contra\best.txt.

PROJECT FILES
-------------
Contra.csproj, Program.cs, GameForm.cs (window, loop, mouse), InputManager.cs (keyboard state), GameEngine.cs (rules,
states, menus, explosions, checkpoints), GameConfig.cs, Player.cs, WeaponSystem.cs, Grenade.cs, Enemy.cs, EnemyManager.cs,
Boss.cs, Projectile.cs, ProjectileManager.cs, Barrel.cs (explosive objects), Pickup.cs, Explosion.cs, ParticleSystem.cs,
Level.cs (the hand-made level), Camera.cs, CollisionManager.cs, BackgroundRenderer.cs (pixel-art background and terrain),
Sprites.cs (pixel-art characters, boss, effects), GameRenderer.cs (pixel canvas, HUD, menus), ScoreManager.cs, Sfx.cs
(generated sound effects), build.bat, README.txt.

TECHNICAL NOTES
---------------
C#, .NET 8, Windows Forms, GDI+. The game is drawn on a 480x270 pixel canvas with hard edges and scaled by two with
nearest-neighbour filtering. Fixed 1/120 s simulation step. Sounds are generated in memory (Windows plays one sound at a
time, so rapid gunfire is throttled); there is no music.

NOTE ON TESTING
---------------
This project was written without compiling or running it (the author's environment has no .NET SDK or Windows). Please
build it locally; if the compiler reports an error or something behaves wrongly, report it and it will be fixed.
