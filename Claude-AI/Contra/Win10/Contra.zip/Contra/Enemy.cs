namespace Contra;

public enum EnemyType { Infantry, Rifleman, Grenadier, Heavy, Elite, Turret }

/// <summary>
/// An enemy: basic infantry walk toward the player and fire now and then; rifle soldiers hold a position and fire bursts;
/// grenadiers lob grenades in an arc; heavy soldiers are big, slow and fire powerful shots; elites are fast and fire
/// quick bursts; turrets are destructible gun emplacements. They stay dormant until the camera approaches.
/// </summary>
public sealed class Enemy
{
    private static int nextId = 1;

    public int Id;
    public EnemyType Type;
    public float X, Y, VX, VY;             // X is the centre, Y the feet
    public int Facing = -1;
    public float HalfW, Height;
    public float Hp, MaxHp;
    public int Score;
    public bool Active, Dying, Grounded;
    public float DeathTimer, HitFlash, Age, Walk, ShootAnim, ThrowAnim, AimAngle;
    public float Min, Max;

    private int state, shotsLeft;
    private float stateTimer, shotTimer, throwWind;

    public RectangleF Rect
    {
        get { return new RectangleF(X - HalfW, Y - Height, HalfW * 2f, Height); }
    }

    public bool Hittable { get { return Active && !Dying; } }

    public float MuzzleX
    {
        get
        {
            if (Type == EnemyType.Turret) return X + MathF.Cos(AimAngle) * 12f;
            return X + Facing * 9f;
        }
    }

    public float MuzzleY
    {
        get
        {
            switch (Type)
            {
                case EnemyType.Turret: return Y - 9f + MathF.Sin(AimAngle) * 12f;
                case EnemyType.Heavy: return Y - 24f;
                case EnemyType.Rifleman: return Y - 17f;
                default: return Y - 20f;
            }
        }
    }

    public void Init(EnemySpawn s, Random rng)
    {
        Id = nextId++;
        Type = s.Type;
        X = s.X;
        Y = s.Y;
        Min = s.Min;
        Max = s.Max;
        Active = false;
        Dying = false;
        stateTimer = 0.5f + (float)rng.NextDouble() * 1.4f;
        switch (Type)
        {
            case EnemyType.Infantry: HalfW = 5f; Height = 28f; Hp = 2f; Score = GameConfig.ScoreInfantry; break;
            case EnemyType.Rifleman: HalfW = 5f; Height = 26f; Hp = 3f; Score = GameConfig.ScoreRifleman; break;
            case EnemyType.Grenadier: HalfW = 5f; Height = 28f; Hp = 3f; Score = GameConfig.ScoreGrenadier; break;
            case EnemyType.Heavy: HalfW = 8f; Height = 36f; Hp = 14f; Score = GameConfig.ScoreHeavy; break;
            case EnemyType.Elite: HalfW = 5f; Height = 28f; Hp = 7f; Score = GameConfig.ScoreElite; break;
            default: HalfW = 10f; Height = 14f; Hp = 7f; Score = GameConfig.ScoreTurret; break;
        }
        MaxHp = Hp;
        AimAngle = MathF.PI;
    }

    public void Damage(float amount)
    {
        Hp -= amount;
        HitFlash = 0.1f;
    }

    public void StartDying()
    {
        Dying = true;
        DeathTimer = 0.55f;
        VX = -Facing * 50f;
        VY = -110f;
    }

    private void Fire(ProjectileManager shots, ShotKind kind, float speed, float tx, float ty, float spread, float dmg)
    {
        float mx = MuzzleX;
        float my = MuzzleY;
        float a = MathF.Atan2(ty - my, tx - mx) + spread;
        Projectile p = shots.Spawn(kind, mx, my, MathF.Cos(a) * speed, MathF.Sin(a) * speed, dmg, 4f);
        p.Pierce = 1;
        ShootAnim = 0.2f;
    }

    public void Update(float dt, float tx, float ty, bool canAct, Level lv, ProjectileManager shots, GrenadeManager grenades, Random rng, out bool fired, out bool threw)
    {
        fired = false;
        threw = false;
        Age += dt;
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        if (ShootAnim > 0f) ShootAnim = Math.Max(0f, ShootAnim - dt);
        if (ThrowAnim > 0f) ThrowAnim = Math.Max(0f, ThrowAnim - dt);

        if (Dying)
        {
            DeathTimer -= dt;
            VX *= 1f - 2f * dt;
            VY = Math.Min(500f, VY + GameConfig.Gravity * dt);
            float dx = X, dy = Y, dvx = VX, dvy = VY;
            CollisionManager.MoveBody(lv, ref dx, ref dy, ref dvx, ref dvy, 4f, 6f, dt);
            X = dx; Y = dy; VX = dvx; VY = dvy;
            return;
        }

        float distX = Math.Abs(tx - X);
        int dirToPlayer = tx >= X ? 1 : -1;
        float walk = 0f;
        stateTimer -= dt;
        Facing = dirToPlayer;

        switch (Type)
        {
            case EnemyType.Infantry:
                if (canAct && distX > 50f) walk = dirToPlayer * 30f;
                if (canAct && distX < 330f && stateTimer <= 0f)
                {
                    Fire(shots, ShotKind.EBullet, 120f, tx, ty, ((float)rng.NextDouble() - 0.5f) * 0.12f, 1f);
                    fired = true;
                    stateTimer = 1.8f + (float)rng.NextDouble() * 1.4f;
                }
                break;

            case EnemyType.Rifleman:
                if (state == 0)
                {
                    if (canAct && distX < 340f && stateTimer <= 0f)
                    {
                        state = 1;
                        shotsLeft = 3;
                        shotTimer = 0.1f;
                    }
                }
                else
                {
                    shotTimer -= dt;
                    if (shotTimer <= 0f)
                    {
                        Fire(shots, ShotKind.EBullet, 140f, tx, ty, ((float)rng.NextDouble() - 0.5f) * 0.1f, 1f);
                        fired = true;
                        shotsLeft--;
                        shotTimer = 0.16f;
                        if (shotsLeft <= 0)
                        {
                            state = 0;
                            stateTimer = 1.5f + (float)rng.NextDouble();
                        }
                    }
                }
                break;

            case EnemyType.Grenadier:
                if (throwWind > 0f)
                {
                    throwWind -= dt;
                    if (throwWind <= 0f)
                    {
                        float dx = tx - X;
                        float dyT = ty - (Y - 22f);
                        float t = Math.Max(0.6f, Math.Min(1.3f, Math.Abs(dx) / 90f));
                        float gvx = dx / t;
                        float gvy = Math.Max(-260f, (dyT - 0.5f * 520f * t * t) / t);
                        grenades.Throw(X + Facing * 6f, Y - 24f, gvx, gvy, false);
                        threw = true;
                        stateTimer = 2.6f + (float)rng.NextDouble() * 1.2f;
                    }
                }
                else if (canAct && stateTimer <= 0f && distX < 320f && distX > 50f)
                {
                    throwWind = 0.35f;
                    ThrowAnim = 0.5f;
                }
                break;

            case EnemyType.Heavy:
                if (canAct && distX > 110f && distX < 400f) walk = dirToPlayer * 14f;
                if (canAct && distX < 380f && stateTimer <= 0f)
                {
                    Fire(shots, ShotKind.EBig, 105f, tx, ty, -0.07f, 2f);
                    Fire(shots, ShotKind.EBig, 105f, tx, ty, 0.07f, 2f);
                    fired = true;
                    stateTimer = 2.3f + (float)rng.NextDouble() * 0.8f;
                }
                break;

            case EnemyType.Elite:
                if (canAct)
                {
                    if (distX > 120f) walk = dirToPlayer * 50f;
                    else if (distX < 70f) walk = -dirToPlayer * 36f;
                }
                if (state == 0)
                {
                    if (canAct && distX < 340f && stateTimer <= 0f)
                    {
                        state = 1;
                        shotsLeft = 4;
                        shotTimer = 0.06f;
                    }
                }
                else
                {
                    shotTimer -= dt;
                    if (shotTimer <= 0f)
                    {
                        Fire(shots, ShotKind.EBullet, 185f, tx, ty, ((float)rng.NextDouble() - 0.5f) * 0.08f, 1f);
                        fired = true;
                        shotsLeft--;
                        shotTimer = 0.1f;
                        if (shotsLeft <= 0)
                        {
                            state = 0;
                            stateTimer = 0.9f + (float)rng.NextDouble() * 0.7f;
                        }
                    }
                }
                break;

            default:    // Turret
                {
                    float want = MathF.Atan2(ty - (Y - 9f), tx - X);
                    float diff = want - AimAngle;
                    while (diff > MathF.PI) diff -= MathF.PI * 2f;
                    while (diff < -MathF.PI) diff += MathF.PI * 2f;
                    AimAngle += Math.Max(-2.5f * dt, Math.Min(2.5f * dt, diff));
                    if (state == 0)
                    {
                        if (canAct && distX < 340f && stateTimer <= 0f)
                        {
                            state = 1;
                            shotsLeft = 2;
                            shotTimer = 0.05f;
                        }
                    }
                    else
                    {
                        shotTimer -= dt;
                        if (shotTimer <= 0f)
                        {
                            Fire(shots, ShotKind.EBullet, 135f, tx, ty, 0f, 1f);
                            fired = true;
                            shotsLeft--;
                            shotTimer = 0.2f;
                            if (shotsLeft <= 0)
                            {
                                state = 0;
                                stateTimer = 2f + (float)rng.NextDouble() * 0.8f;
                            }
                        }
                    }
                    break;
                }
        }

        VX = walk;
        Walk += Math.Abs(walk) * dt * 0.18f;
        VY = Math.Min(500f, VY + GameConfig.Gravity * dt);
        float x = X, y = Y, vx = VX, vy = VY;
        Grounded = CollisionManager.MoveBody(lv, ref x, ref y, ref vx, ref vy, HalfW, Height, dt);
        X = x; Y = y; VY = vy;
        if (Type == EnemyType.Infantry && Max > Min + 1f) X = Math.Max(Min - 120f, Math.Min(Max + 120f, X));
    }
}
