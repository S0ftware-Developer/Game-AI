namespace Contra;

/// <summary>A smooth horizontal follow camera that keeps the player near the centre and stops at the level boundaries.</summary>
public sealed class Camera
{
    public float X;
    public float Shake;

    public void Reset(float x)
    {
        X = x;
        Shake = 0f;
    }

    public void Update(float dt, float targetX, float maxX)
    {
        float want = targetX - GameConfig.ViewW * 0.5f;
        want = Math.Max(0f, Math.Min(maxX, want));
        X += (want - X) * (1f - MathF.Exp(-8f * dt));
        X = Math.Max(0f, Math.Min(maxX, X));
        if (Shake > 0f) Shake = Math.Max(0f, Shake - dt);
    }
}
