using System.Drawing.Drawing2D;

namespace Contra;

/// <summary>
/// All character, enemy, boss, pickup, barrel, projectile and effect drawing, in the style of an 8-bit arcade game: every
/// sprite is built from hard-edged pixel blocks on the small canvas. Soldiers share one pixel-humanoid routine (run cycle,
/// crouch, jump tuck, rolling jump, eight-direction aiming arm and weapon, grenade throw, death) with a palette per type.
/// </summary>
public sealed class Sprites : IDisposable
{
    private sealed class Pal
    {
        public Color Skin, SkinDark, Shirt, ShirtDark, Pants, PantsDark, Boots, Hat, HatDark, Accent, Pack;
    }

    private static readonly Pal PlayerPal = new Pal
    {
        Skin = Color.FromArgb(240, 194, 142), SkinDark = Color.FromArgb(200, 144, 98), Shirt = Color.FromArgb(240, 194, 142), ShirtDark = Color.FromArgb(200, 144, 98),
        Pants = Color.FromArgb(48, 92, 214), PantsDark = Color.FromArgb(30, 60, 160), Boots = Color.FromArgb(52, 34, 22),
        Hat = Color.FromArgb(66, 40, 22), HatDark = Color.FromArgb(40, 24, 14), Accent = Color.FromArgb(226, 44, 48), Pack = Color.FromArgb(70, 100, 60)
    };
    private static readonly Pal InfantryPal = new Pal
    {
        Skin = Color.FromArgb(224, 178, 136), SkinDark = Color.FromArgb(184, 134, 96), Shirt = Color.FromArgb(92, 156, 76), ShirtDark = Color.FromArgb(60, 112, 56),
        Pants = Color.FromArgb(76, 124, 62), PantsDark = Color.FromArgb(50, 88, 44), Boots = Color.FromArgb(40, 30, 22),
        Hat = Color.FromArgb(70, 130, 64), HatDark = Color.FromArgb(40, 84, 40), Accent = Color.FromArgb(40, 30, 22), Pack = Color.FromArgb(60, 96, 50)
    };
    private static readonly Pal RiflemanPal = new Pal
    {
        Skin = Color.FromArgb(224, 178, 136), SkinDark = Color.FromArgb(184, 134, 96), Shirt = Color.FromArgb(104, 126, 176), ShirtDark = Color.FromArgb(70, 88, 130),
        Pants = Color.FromArgb(78, 90, 124), PantsDark = Color.FromArgb(52, 62, 92), Boots = Color.FromArgb(34, 30, 34),
        Hat = Color.FromArgb(86, 104, 150), HatDark = Color.FromArgb(54, 66, 100), Accent = Color.FromArgb(220, 220, 120), Pack = Color.FromArgb(60, 70, 100)
    };
    private static readonly Pal GrenadierPal = new Pal
    {
        Skin = Color.FromArgb(224, 178, 136), SkinDark = Color.FromArgb(184, 134, 96), Shirt = Color.FromArgb(176, 128, 78), ShirtDark = Color.FromArgb(126, 88, 52),
        Pants = Color.FromArgb(112, 90, 60), PantsDark = Color.FromArgb(80, 62, 40), Boots = Color.FromArgb(44, 32, 24),
        Hat = Color.FromArgb(150, 112, 68), HatDark = Color.FromArgb(96, 70, 40), Accent = Color.FromArgb(84, 120, 60), Pack = Color.FromArgb(100, 80, 52)
    };
    private static readonly Pal HeavyPal = new Pal
    {
        Skin = Color.FromArgb(214, 168, 128), SkinDark = Color.FromArgb(170, 126, 92), Shirt = Color.FromArgb(172, 70, 58), ShirtDark = Color.FromArgb(120, 44, 38),
        Pants = Color.FromArgb(80, 80, 94), PantsDark = Color.FromArgb(54, 54, 66), Boots = Color.FromArgb(30, 28, 30),
        Hat = Color.FromArgb(132, 138, 152), HatDark = Color.FromArgb(84, 90, 104), Accent = Color.FromArgb(232, 196, 60), Pack = Color.FromArgb(90, 60, 56)
    };
    private static readonly Pal ElitePal = new Pal
    {
        Skin = Color.FromArgb(222, 176, 134), SkinDark = Color.FromArgb(182, 132, 94), Shirt = Color.FromArgb(54, 52, 76), ShirtDark = Color.FromArgb(32, 30, 50),
        Pants = Color.FromArgb(44, 42, 62), PantsDark = Color.FromArgb(28, 26, 44), Boots = Color.FromArgb(20, 18, 22),
        Hat = Color.FromArgb(206, 40, 52), HatDark = Color.FromArgb(140, 26, 34), Accent = Color.FromArgb(230, 60, 70), Pack = Color.FromArgb(40, 38, 56)
    };

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fText = new Font("Consolas", 8f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly StringFormat sfCenter = new StringFormat();
    private Graphics gg = null!;
    private int ox, oy, fac, lift;

    private static readonly string[][] Glyphs =
    {
        new[] { "111", "100", "111", "001", "111" },   // S
        new[] { "100", "100", "100", "100", "111" },   // L
        new[] { "111", "100", "111", "100", "100" },   // F
        new[] { "111", "100", "101", "101", "111" },   // G
        new[] { "111", "101", "111", "100", "100" },   // P
        new[] { "010", "110", "010", "010", "111" },   // 1
        new[] { "101", "101", "101", "101", "111" },   // U
        new[] { "000", "010", "111", "010", "000" },   // +
        new[] { "101", "101", "111", "101", "101" }    // H
    };
    private const string GlyphChars = "SLFGP1U+H";

    public Sprites()
    {
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fText.Dispose();
        sfCenter.Dispose();
    }

    // ------------------------------------------------------------------ pixel helpers

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private static Color Tint(Color c, float flash)
    {
        if (flash <= 0f) return c;
        return Color.FromArgb(c.A, (int)(c.R + (255 - c.R) * flash), (int)(c.G + (255 - c.G) * flash), (int)(c.B + (255 - c.B) * flash));
    }

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private void Begin(Graphics g, float x, float y, int facing)
    {
        gg = g;
        ox = (int)Math.Round(x);
        oy = (int)Math.Round(y);
        fac = facing >= 0 ? 1 : -1;
        lift = 0;
    }

    /// <summary>A pixel block relative to the feet, mirrored by the facing direction.</summary>
    private void M(Color c, int rx, int ry, int w, int h)
    {
        int x = fac > 0 ? ox + rx : ox - rx - w;
        gg.FillRectangle(B(c), x, oy + ry - lift, w, h);
    }

    private void Px(Graphics g, Color c, float x, float y, int w, int h)
    {
        g.FillRectangle(B(c), (int)Math.Round(x), (int)Math.Round(y), w, h);
    }

    private void Glyph(Graphics g, char ch, int x, int y, Color c)
    {
        int i = GlyphChars.IndexOf(ch);
        if (i < 0) return;
        string[] rows = Glyphs[i];
        for (int r = 0; r < 5; r++)
        {
            for (int k = 0; k < 3; k++)
            {
                if (rows[r][k] == '1') g.FillRectangle(B(c), x + k, y + r, 1, 1);
            }
        }
    }

    private static void AimVec(int aim, out float dx, out float dy)
    {
        switch (aim)
        {
            case 1: dx = 0f; dy = -1f; break;
            case 2: dx = 0f; dy = 1f; break;
            case 3: dx = 0.7071f; dy = -0.7071f; break;
            case 4: dx = 0.7071f; dy = 0.7071f; break;
            default: dx = 1f; dy = 0f; break;
        }
    }

    // ------------------------------------------------------------------ the commando

    public void DrawPlayer(Graphics g, Player p, float time)
    {
        float flash = 0f;
        if (p.HurtTimer > 0f && ((int)(time * 30f) & 1) == 0) flash = 0.7f;
        if (p.Dead)
        {
            DrawDeath(g, PlayerPal, p.X, p.Y, p.Facing, GameConfig.DeathTime - p.DeathTimer, time, false);
            return;
        }
        if (p.Invuln > 0f && p.HurtTimer <= 0f && ((int)(time * 18f) & 1) == 0) return;

        bool airborne = !p.Grounded;
        bool busy = p.ShootAnim > 0f || p.ThrowAnim > 0f || p.Aim != 0;
        if (airborne && !busy)
        {
            DrawRoll(g, PlayerPal, p.X, p.Y, p.Facing, time, flash);
            return;
        }
        int gun = (int)p.Weapon.Current;
        bool moving = p.Grounded && Math.Abs(p.VX) > 8f;
        DrawSoldier(g, PlayerPal, p.X, p.Y, p.Facing, (int)p.RunPhase & 3, moving, p.Crouching, airborne, p.Aim, gun, p.ShootAnim > 0.08f,
            p.ThrowAnim > 0f ? 1f - p.ThrowAnim / 0.3f : -1f, flash, false, 4, false);
        if (p.HurtTimer > 0.15f)
        {
            // damage burst
            Px(g, Color.FromArgb(255, 255, 255, 255), p.X - 8, p.Y - 26, 2, 2);
            Px(g, Color.FromArgb(255, 255, 90, 70), p.X + 6, p.Y - 20, 2, 2);
        }
    }

    /// <summary>The classic somersault: a rolling ball of skin and clothes.</summary>
    private void DrawRoll(Graphics g, Pal pal, float x, float y, int facing, float time, float flash)
    {
        Begin(g, x, y, facing);
        lift = 2;
        int f = ((int)(time * 16f)) & 3;
        Color skin = Tint(pal.Skin, flash);
        M(skin, -3, -17, 6, 10);
        M(skin, -5, -15, 10, 6);
        M(Tint(pal.SkinDark, flash), -3, -9, 6, 2);
        int[,] spots = { { -1, -18 }, { 3, -13 }, { -1, -8 }, { -5, -13 } };
        M(Tint(pal.Pants, flash), spots[f, 0], spots[f, 1], 3, 3);
        M(Tint(pal.Accent, flash), spots[(f + 2) & 3, 0], spots[(f + 2) & 3, 1], 3, 3);
        M(Tint(pal.Boots, flash), spots[(f + 1) & 3, 0], spots[(f + 1) & 3, 1], 2, 3);
    }

    private void DrawDeath(Graphics g, Pal pal, float x, float y, int facing, float t, float time, bool enemy)
    {
        if (t > 0.9f && ((int)(time * 14f) & 1) == 0) return;
        Begin(g, x, y, facing);
        if (t < 0.5f)
        {
            // thrown backward and tumbling
            lift = 4;
            int f = ((int)(t * 18f)) & 3;
            M(pal.Skin, -4, -16, 8, 8);
            M(pal.Shirt, -3, -14, 6, 4);
            int[,] spots = { { -4, -16 }, { 2, -16 }, { 2, -10 }, { -4, -10 } };
            M(pal.Pants, spots[f, 0], spots[f, 1], 3, 3);
            M(pal.Accent, spots[(f + 2) & 3, 0], spots[(f + 2) & 3, 1], 3, 3);
            return;
        }
        // lying on the ground
        M(pal.Boots, -12, -3, 3, 3);
        M(pal.Pants, -10, -5, 8, 5);
        M(pal.Shirt, -2, -6, 8, 6);
        M(pal.Skin, 6, -6, 6, 6);
        M(pal.Accent, 6, -5, 6, 2);
        M(pal.ShirtDark, -2, -2, 8, 2);
    }

    // ------------------------------------------------------------------ one soldier

    private void DrawSoldier(Graphics g, Pal pal, float x, float y, int facing, int frame, bool moving, bool crouch, bool air, int aim, int gun,
        bool shooting, float throwT, float flash, bool heavy, int hat, bool kneel)
    {
        Begin(g, x, y, facing);
        Color skin = Tint(pal.Skin, flash);
        Color skinD = Tint(pal.SkinDark, flash);
        Color shirt = Tint(pal.Shirt, flash);
        Color shirtD = Tint(pal.ShirtDark, flash);
        Color pants = Tint(pal.Pants, flash);
        Color pantsD = Tint(pal.PantsDark, flash);
        Color boots = Tint(pal.Boots, flash);

        int legW = heavy ? 5 : 3;
        int legH = heavy ? 14 : 11;
        int hw = heavy ? 6 : 4;
        int torsoH = heavy ? 13 : 11;
        int headW = heavy ? 8 : 6;
        int headH = heavy ? 8 : 7;
        if (crouch || kneel)
        {
            legH = 5;
            torsoH = heavy ? 9 : 8;
            headH = heavy ? 7 : 6;
        }
        else if (air)
        {
            legH = heavy ? 9 : 7;
            lift = 3;
        }
        int beltY = -legH - 2;
        int torsoTop = beltY - torsoH;
        int headTop = torsoTop - headH;

        // legs
        if (crouch || kneel)
        {
            M(pantsD, -hw - 2, -5, hw * 2 + 4, 5);
            M(pants, -hw - 2, -5, hw + 2, 3);
            M(boots, -hw - 2, -2, 4, 2);
            M(boots, hw - 1, -2, 4, 2);
        }
        else if (air)
        {
            M(pantsD, -legW - 1, -legH, legW, legH - 2);
            M(pants, 1, -legH + 2, legW + 2, legH - 4);
            M(boots, -legW - 1, -3, legW + 1, 2);
            M(boots, 2, -legH + 1, legW + 2, 2);
        }
        else
        {
            int[] l1 = { -5, -2, 3, 0 };
            int[] l2 = { 3, 0, -5, -2 };
            int[] u1 = { 0, 0, 3, 0 };
            int[] u2 = { 3, 0, 0, 0 };
            int f = moving ? frame & 3 : 1;
            int a = moving ? l1[f] : -hw + 1;
            int b = moving ? l2[f] : 1;
            int ua = moving ? u1[f] : 0;
            int ub = moving ? u2[f] : 0;
            M(pantsD, a - (heavy ? 1 : 0), -legH + ua, legW, legH - 3 - ua);
            M(boots, a - (heavy ? 1 : 0), -3 - ua, legW + 1, 3);
            M(pants, b, -legH + ub, legW, legH - 3 - ub);
            M(boots, b, -3 - ub, legW + 1, 3);
        }

        // belt, backpack, torso
        M(Tint(Color.FromArgb(255, 70, 50, 30), flash), -hw, beltY, hw * 2, 2);
        M(Tint(pal.Pack, flash), -hw - 3, torsoTop + 1, 3, torsoH - 3);
        M(shirt, -hw, torsoTop, hw * 2, torsoH);
        M(shirtD, -hw, torsoTop, 1, torsoH);
        M(shirtD, -hw, torsoTop + torsoH - 3, hw * 2, 3);
        if (pal == PlayerPal)
        {
            M(skinD, -1, torsoTop + 3, 3, 1);
            M(skinD, -1, torsoTop + 6, 3, 1);
            M(Tint(Color.FromArgb(255, 70, 50, 30), flash), -hw, torsoTop + 1, hw * 2, 1);        // a bandolier strap
        }
        else if (pal == ElitePal)
        {
            for (int i = 0; i < hw * 2; i++) M(Tint(pal.Accent, flash), -hw + i, torsoTop + i / 2, 1, 1);
        }
        else if (pal == GrenadierPal)
        {
            for (int i = 0; i < 3; i++) M(Tint(pal.Accent, flash), -hw + 1 + i * 3, torsoTop + torsoH - 6, 2, 3);
        }

        // head and head gear
        M(skin, -headW / 2, headTop, headW, headH);
        M(skinD, -headW / 2, headTop + headH - 2, headW, 2);
        M(Color.FromArgb(255, 30, 24, 20), headW / 2 - 2, headTop + 3, 1, 1);
        Color hatC = Tint(pal.Hat, flash);
        Color hatD = Tint(pal.HatDark, flash);
        switch (hat)
        {
            case 0:
                M(hatC, -headW / 2 - 1, headTop - 3, headW + 3, 4);
                M(hatD, -headW / 2 - 1, headTop + 1, headW + 4, 1);
                break;
            case 1:
                M(hatC, -headW / 2, headTop - 2, headW + 1, 3);
                M(hatD, 1, headTop + 1, 6, 1);
                break;
            case 2:
                M(hatC, -5, headTop - 4, 11, 6);
                M(hatD, -5, headTop - 4, 11, 1);
                M(Color.FromArgb(255, 30, 30, 36), 0, headTop + 2, 6, 2);
                break;
            case 3:
                M(hatC, -headW / 2 - 1, headTop - 2, headW + 2, 3);
                M(hatD, -headW / 2 - 2, headTop - 1, 3, 3);
                M(Tint(pal.Accent, flash), 1, headTop + 3, 5, 2);
                break;
            default:
                {
                    Color band = Tint(pal.Accent, flash);
                    M(hatC, -headW / 2, headTop - 1, headW + 1, 3);
                    M(hatC, -1, headTop - 3, 3, 2);
                    M(hatC, 2, headTop - 2, 3, 2);
                    M(band, -headW / 2 - 1, headTop + 2, headW + 3, 2);
                    M(band, -headW / 2 - 4, headTop + 2 + (frame & 1), 3, 1);
                    M(band, -headW / 2 - 3, headTop + 3 - (frame & 1), 3, 1);
                    break;
                }
        }

        // the arm and the weapon along the aim direction, or the raised throwing arm
        int sx = 1;
        int sy = torsoTop + 3;
        if (throwT >= 0f)
        {
            int up = (int)(throwT * 4f);
            M(skin, sx, sy - 6 - up, 3, 6);
            M(Tint(Color.FromArgb(255, 70, 92, 50), flash), sx - 1, sy - 10 - up, 4, 4);
            return;
        }
        if (gun >= 0)
        {
            float dx, dy;
            AimVec(aim, out dx, out dy);
            int gx = sx + 2;
            int gy = sy + 1;
            DrawGun(gun, gx, gy, dx, dy);
            M(skin, sx, sy, 3, 3);
            if (shooting)
            {
                int len = GunLength(gun) + 3;
                int fx = (int)Math.Round(gx + dx * len);
                int fy = (int)Math.Round(gy + dy * len);
                M(Color.FromArgb(255, 255, 210, 70), fx - 2, fy - 2, 5, 5);
                M(Color.FromArgb(255, 255, 255, 230), fx - 1, fy - 1, 3, 3);
            }
        }
    }

    private static int GunLength(int gun)
    {
        switch (gun)
        {
            case (int)WeaponType.Spread: return 11;
            case (int)WeaponType.Laser: return 13;
            case (int)WeaponType.Fire: return 10;
            case 10: return 11;      // heavy soldiers' machine gun
            case 11: return 10;      // sub-machine gun
            default: return 12;
        }
    }

    private void DrawGun(int gun, int gx, int gy, float dx, float dy)
    {
        Color body = Color.FromArgb(255, 54, 58, 66);
        Color tip = Color.FromArgb(255, 150, 156, 166);
        int thick = 2;
        int len = GunLength(gun);
        switch (gun)
        {
            case (int)WeaponType.Spread: body = Color.FromArgb(255, 70, 110, 70); tip = Color.FromArgb(255, 220, 90, 120); thick = 3; break;
            case (int)WeaponType.Laser: body = Color.FromArgb(255, 60, 70, 110); tip = Color.FromArgb(255, 110, 240, 255); thick = 3; break;
            case (int)WeaponType.Fire: body = Color.FromArgb(255, 120, 60, 40); tip = Color.FromArgb(255, 255, 150, 40); thick = 3; break;
            case 10: body = Color.FromArgb(255, 44, 46, 52); tip = Color.FromArgb(255, 120, 124, 134); thick = 3; break;
            default: break;
        }
        for (int i = 0; i < len; i++)
        {
            int px = (int)Math.Round(gx + dx * i) - thick / 2;
            int py = (int)Math.Round(gy + dy * i) - thick / 2;
            M(i >= len - 3 ? tip : body, px, py, thick, thick);
        }
        // a magazine under the gun
        M(body, (int)Math.Round(gx + dx * 4), (int)Math.Round(gy + dy * 4) + 1, 2, 3);
    }

    // ------------------------------------------------------------------ enemies

    public void DrawEnemy(Graphics g, Enemy e, float time)
    {
        if (!e.Active) return;
        float flash = e.HitFlash > 0f ? 0.7f : 0f;
        if (e.Type == EnemyType.Turret)
        {
            DrawTurret(g, e, flash);
            return;
        }
        Pal pal;
        int gun;
        int hat;
        bool heavy = false;
        bool kneel = false;
        switch (e.Type)
        {
            case EnemyType.Rifleman: pal = RiflemanPal; gun = 12; hat = 0; kneel = false; break;
            case EnemyType.Grenadier: pal = GrenadierPal; gun = -1; hat = 1; break;
            case EnemyType.Heavy: pal = HeavyPal; gun = 10; hat = 2; heavy = true; break;
            case EnemyType.Elite: pal = ElitePal; gun = 11; hat = 3; break;
            default: pal = InfantryPal; gun = 12; hat = 0; break;
        }
        if (e.Dying)
        {
            DrawDeath(g, pal, e.X, e.Y, e.Facing, 0.55f - e.DeathTimer, time, true);
            return;
        }
        bool moving = Math.Abs(e.VX) > 5f;
        float throwT = e.ThrowAnim > 0f ? 1f - e.ThrowAnim / 0.5f : -1f;
        DrawSoldier(g, pal, e.X, e.Y, e.Facing, (int)e.Walk & 3, moving, false, !e.Grounded, 0, gun, e.ShootAnim > 0.08f, throwT, flash, heavy, hat, e.Type == EnemyType.Rifleman);
    }

    private void DrawTurret(Graphics g, Enemy e, float flash)
    {
        if (e.Dying)
        {
            float t = 0.55f - e.DeathTimer;
            Px(g, Color.FromArgb(255, 60, 62, 70), e.X - 10, e.Y - 5, 20, 5);
            if (((int)(t * 20f) & 1) == 0) Px(g, Color.FromArgb(255, 255, 150, 40), e.X - 4, e.Y - 9, 8, 5);
            return;
        }
        Color baseC = Tint(Color.FromArgb(255, 104, 110, 124), flash);
        Color dark = Tint(Color.FromArgb(255, 60, 64, 76), flash);
        Px(g, baseC, e.X - 10, e.Y - 6, 20, 6);
        Px(g, dark, e.X - 10, e.Y - 2, 20, 2);
        Px(g, Tint(Color.FromArgb(255, 150, 156, 170), flash), e.X - 10, e.Y - 6, 20, 1);
        Px(g, baseC, e.X - 6, e.Y - 11, 12, 6);
        Px(g, Tint(Color.FromArgb(255, 220, 50, 50), flash), e.X - 2, e.Y - 9, 4, 2);
        // the barrel follows the aim angle
        for (int i = 0; i < 12; i++)
        {
            float bx = e.X + MathF.Cos(e.AimAngle) * i;
            float by = e.Y - 9f + MathF.Sin(e.AimAngle) * i;
            Px(g, i > 9 ? Color.FromArgb(255, 200, 204, 214) : dark, bx - 1, by - 1, 3, 3);
        }
        if (e.ShootAnim > 0.1f)
            Px(g, Color.FromArgb(255, 255, 220, 90), e.MuzzleX - 2, e.MuzzleY - 2, 5, 5);
    }

    // ------------------------------------------------------------------ the boss

    public void DrawBoss(Graphics g, Boss b, float time)
    {
        float flash = b.HitFlash > 0f ? 0.6f : 0f;
        int shake = b.Dying ? (((int)(time * 40f) & 1) == 0 ? 1 : -1) : 0;
        Begin(g, b.X + shake, GameConfig.GroundY, -1);
        bool p2 = b.Phase >= 2;
        Color steel = Tint(p2 ? Color.FromArgb(255, 122, 88, 100) : Color.FromArgb(255, 100, 110, 128), flash);
        Color steelL = Tint(p2 ? Color.FromArgb(255, 164, 118, 130) : Color.FromArgb(255, 146, 158, 178), flash);
        Color steelD = Tint(p2 ? Color.FromArgb(255, 76, 52, 66) : Color.FromArgb(255, 66, 72, 88), flash);
        Color dark = Color.FromArgb(255, 30, 32, 38);

        // tracks with road wheels
        M(dark, -48, -14, 96, 14);
        for (int i = 0; i < 12; i++)
        {
            int tx = -46 + ((i * 8 + (int)b.TrackPhase) % 92 + 92) % 92;
            M(Color.FromArgb(255, 84, 86, 94), tx, -14, 4, 2);
            M(Color.FromArgb(255, 84, 86, 94), tx, -2, 4, 2);
        }
        for (int i = 0; i < 6; i++)
        {
            M(Color.FromArgb(255, 92, 96, 106), -42 + i * 16, -12, 10, 10);
            M(Color.FromArgb(255, 150, 154, 164), -39 + i * 16, -9, 4, 4);
        }

        // hull and deck
        M(steel, -46, -42, 92, 30);
        M(steelL, -46, -42, 92, 2);
        M(steelD, -46, -14, 92, 2);
        for (int i = 0; i < 9; i++) M(steelD, -42 + i * 10, -36, 2, 2);
        for (int i = 0; i < 6; i++)
        {
            M(Color.FromArgb(255, 230, 190, 40), -44 + i * 16, -20, 8, 4);
            M(dark, -36 + i * 16, -20, 8, 4);
        }
        M(steel, -34, -60, 68, 18);
        M(steelL, -34, -60, 68, 2);
        M(steelD, -34, -44, 68, 2);
        M(Color.FromArgb(255, 238, 238, 228), 14, -56, 14, 10);                       // the enemy emblem
        M(Color.FromArgb(255, 200, 40, 40), 18, -54, 6, 6);
        // the dome and the spinning radar
        M(steel, -18, -70, 36, 10);
        M(steelL, -14, -72, 28, 2);
        int radar = (int)(time * 8f) & 3;
        M(Color.FromArgb(255, 70, 74, 84), 0, -80, 2, 8);
        M(Color.FromArgb(255, 200, 204, 214), -6 + radar * 3, -82, 8, 2);
        // smoke stacks
        for (int s = 0; s < 2; s++)
        {
            M(steelD, 22 + s * 10, -80, 6, 20);
            for (int k = 0; k < 3; k++)
            {
                float u = (time * 0.6f + k * 0.33f + s * 0.2f) % 1f;
                M(Color.FromArgb(255, 70 + k * 12, 70 + k * 12, 76 + k * 12), 22 + s * 10 + (int)(u * 8f), -84 - (int)(u * 22f), 4 + (int)(u * 4f), 4 + (int)(u * 4f));
            }
        }
        // the three machine-gun ports and the missile tube
        int rc = (int)(b.Recoil * 4f);
        for (int i = 0; i < 3; i++)
        {
            int py = (int)(b.PortY(i) - GameConfig.GroundY);
            M(dark, -62 + rc, py - 2, 20, 5);
            M(Color.FromArgb(255, 130, 136, 148), -62 + rc, py - 2, 20, 1);
            M(Color.FromArgb(255, 220, 60, 50), -44, py - 1, 3, 3);
        }
        M(dark, -34, -78, 10, 4);
        M(Color.FromArgb(255, 200, 60, 50), -36, -79, 3, 6);
        if (b.Recoil > 0.4f) M(Color.FromArgb(255, 255, 220, 90), -68, (int)(b.PortY(1) - GameConfig.GroundY) - 3, 6, 6);

        // phase two: glowing vents and flames
        if (p2)
        {
            bool blink = ((int)(time * 10f) & 1) == 0;
            M(blink ? Color.FromArgb(255, 255, 140, 40) : Color.FromArgb(255, 255, 70, 40), -40, -58, 8, 4);
            M(blink ? Color.FromArgb(255, 255, 140, 40) : Color.FromArgb(255, 255, 70, 40), 28, -42, 10, 4);
            int fl = (int)(time * 14f) & 3;
            M(Color.FromArgb(255, 255, 200, 60), -26 + fl, -66 - fl, 4, 4 + fl);
            M(Color.FromArgb(255, 255, 110, 30), -26 + fl, -62, 5, 3);
        }
        if (b.Dying) M(Color.FromArgb(120, 20, 10, 0), -46, -42, 92, 30);
    }

    // ------------------------------------------------------------------ pickups, barrels, shots

    public void DrawPickup(Graphics g, Pickup p, float time)
    {
        int bob = (int)Math.Round(Math.Sin(p.Age * 4f) * 2f);
        int x = (int)Math.Round(p.X);
        int y = (int)Math.Round(p.Y) - 2 + bob;
        Color face;
        char letter;
        switch (p.Type)
        {
            case PickupType.Spread: face = Color.FromArgb(255, 220, 60, 60); letter = 'S'; break;
            case PickupType.Laser: face = Color.FromArgb(255, 60, 150, 240); letter = 'L'; break;
            case PickupType.Fire: face = Color.FromArgb(255, 240, 150, 40); letter = 'F'; break;
            case PickupType.Grenades: face = Color.FromArgb(255, 110, 130, 70); letter = 'G'; break;
            case PickupType.Life: face = Color.FromArgb(255, 60, 180, 90); letter = '1'; break;
            default: face = Color.FromArgb(255, 236, 236, 232); letter = '+'; break;
        }
        // the winged capsule
        int flap = ((int)(p.Age * 10f) & 1);
        Px(g, Color.FromArgb(255, 238, 240, 246), x - 12, y - 11 + flap, 5, 3);
        Px(g, Color.FromArgb(255, 238, 240, 246), x + 7, y - 11 + flap, 5, 3);
        Px(g, Color.FromArgb(255, 170, 176, 190), x - 12, y - 8 + flap, 5, 1);
        Px(g, Color.FromArgb(255, 170, 176, 190), x + 7, y - 8 + flap, 5, 1);
        Px(g, Color.FromArgb(255, 40, 44, 54), x - 8, y - 14, 16, 12);
        Px(g, face, x - 7, y - 13, 14, 10);
        Px(g, Color.FromArgb(255, 255, 255, 255), x - 7, y - 13, 14, 1);
        Px(g, Color.FromArgb(120, 0, 0, 0), x - 7, y - 4, 14, 1);
        if (p.Type == PickupType.Health)
        {
            Px(g, Color.FromArgb(255, 210, 40, 40), x - 1, y - 12, 3, 8);
            Px(g, Color.FromArgb(255, 210, 40, 40), x - 4, y - 9, 9, 3);
        }
        else if (p.Type == PickupType.Life)
        {
            Glyph(g, '1', x - 6, y - 11, Color.White);
            Glyph(g, 'U', x - 2, y - 11, Color.White);
            Glyph(g, 'P', x + 2, y - 11, Color.White);
        }
        else
        {
            Glyph(g, letter, x - 1, y - 11, Color.White);
        }
        if (((int)(p.Age * 6f) & 1) == 0) Px(g, Color.FromArgb(255, 255, 255, 220), x + 8, y - 16, 2, 2);
    }

    public void DrawBarrel(Graphics g, Barrel b, float time)
    {
        float fl = b.HitFlash > 0f ? 0.7f : 0f;
        int x = (int)Math.Round(b.X);
        int y = (int)Math.Round(b.Y);
        if (b.Ammo)
        {
            Px(g, Tint(Color.FromArgb(255, 96, 112, 64), fl), x - 8, y - 11, 16, 11);
            Px(g, Tint(Color.FromArgb(255, 130, 150, 90), fl), x - 8, y - 11, 16, 2);
            Px(g, Tint(Color.FromArgb(255, 62, 74, 40), fl), x - 8, y - 2, 16, 2);
            Px(g, Tint(Color.FromArgb(255, 240, 210, 70), fl), x - 5, y - 8, 10, 2);
            Px(g, Tint(Color.FromArgb(255, 240, 210, 70), fl), x - 1, y - 8, 2, 6);
            Px(g, Color.FromArgb(255, 40, 44, 30), x - 8, y - 11, 1, 11);
            Px(g, Color.FromArgb(255, 40, 44, 30), x + 7, y - 11, 1, 11);
            return;
        }
        Px(g, Tint(Color.FromArgb(255, 200, 52, 42), fl), x - 6, y - 16, 12, 16);
        Px(g, Tint(Color.FromArgb(255, 236, 110, 90), fl), x - 6, y - 16, 3, 16);
        Px(g, Tint(Color.FromArgb(255, 132, 30, 28), fl), x + 3, y - 16, 3, 16);
        Px(g, Tint(Color.FromArgb(255, 70, 20, 20), fl), x - 6, y - 12, 12, 1);
        Px(g, Tint(Color.FromArgb(255, 70, 20, 20), fl), x - 6, y - 4, 12, 1);
        Px(g, Tint(Color.FromArgb(255, 250, 220, 60), fl), x - 2, y - 10, 4, 4);          // the hazard mark
        Px(g, Color.FromArgb(255, 60, 20, 16), x - 1, y - 9, 2, 2);
        Px(g, Tint(Color.FromArgb(255, 150, 154, 160), fl), x - 6, y - 17, 12, 1);
    }

    public void DrawProjectile(Graphics g, Projectile p)
    {
        float sp = MathF.Sqrt(p.VX * p.VX + p.VY * p.VY);
        float nx = sp > 0.01f ? p.VX / sp : 1f;
        float ny = sp > 0.01f ? p.VY / sp : 0f;
        int x = (int)Math.Round(p.X);
        int y = (int)Math.Round(p.Y);
        switch (p.Kind)
        {
            case ShotKind.Machine:
                Px(g, Color.FromArgb(255, 255, 160, 40), x - 1 - (int)Math.Round(nx * 3f), y - 1 - (int)Math.Round(ny * 3f), 2, 2);
                Px(g, Color.FromArgb(255, 255, 250, 150), x - 1, y - 1, 3, 2);
                break;
            case ShotKind.Spread:
                Px(g, Color.FromArgb(255, 240, 70, 120), x - 2, y - 2, 4, 4);
                Px(g, Color.FromArgb(255, 255, 220, 240), x - 1, y - 1, 2, 2);
                break;
            case ShotKind.Laser:
                for (int i = 0; i < 4; i++)
                {
                    int lx = x - (int)Math.Round(nx * i * 2.5f);
                    int ly = y - (int)Math.Round(ny * i * 2.5f);
                    Px(g, i == 0 ? Color.FromArgb(255, 255, 255, 255) : Color.FromArgb(255, 90 + i * 20, 240, 255), lx - 2, ly - 2, 4, 4);
                }
                break;
            case ShotKind.Flame:
                {
                    float k = Math.Max(0f, p.Life) / 0.42f;
                    int size = 2 + (int)((1f - k) * 4f);
                    Color c = k > 0.66f ? Color.FromArgb(255, 255, 240, 120) : (k > 0.33f ? Color.FromArgb(255, 255, 160, 40) : Color.FromArgb(255, 220, 60, 30));
                    Px(g, c, x - size / 2, y - size / 2, size, size);
                    if (size > 3) Px(g, Color.FromArgb(255, 255, 220, 100), x - 1, y - 1, 2, 2);
                    break;
                }
            case ShotKind.EBullet:
                Px(g, Color.FromArgb(255, 255, 60, 50), x - 2, y - 2, 4, 4);
                Px(g, Color.FromArgb(255, 255, 220, 120), x - 1, y - 1, 2, 2);
                break;
            default:
                Px(g, Color.FromArgb(255, 200, 40, 130), x - 4, y - 3, 8, 6);
                Px(g, Color.FromArgb(255, 200, 40, 130), x - 3, y - 4, 6, 8);
                Px(g, Color.FromArgb(255, 255, 140, 200), x - 2, y - 2, 4, 4);
                Px(g, Color.FromArgb(255, 255, 255, 255), x - 1, y - 1, 2, 2);
                break;
        }
    }

    public void DrawGrenade(Graphics g, Grenade gr, float time)
    {
        int x = (int)Math.Round(gr.X);
        int y = (int)Math.Round(gr.Y);
        bool soon = gr.Fuse < 0.3f && ((int)(time * 24f) & 1) == 0;
        Px(g, gr.FromPlayer ? Color.FromArgb(255, 70, 100, 56) : Color.FromArgb(255, 120, 70, 50), x - 2, y - 2, 5, 5);
        Px(g, Color.FromArgb(255, 150, 180, 120), x - 2 + ((int)(gr.Rot * 3f) & 1), y - 2, 2, 2);
        Px(g, Color.FromArgb(255, 190, 194, 200), x - 1, y - 4, 2, 2);
        if (soon) Px(g, Color.FromArgb(255, 255, 80, 50), x - 4, y - 4, 8, 8);
    }

    // ------------------------------------------------------------------ explosions and particles

    public void DrawExplosion(Graphics g, Explosion e)
    {
        if (e.Age < 0f) return;
        float t = e.Progress;
        float ease = 1f - (1f - t) * (1f - t);
        int r = (int)(e.Size * (0.3f + 0.7f * ease));
        int cx = (int)Math.Round(e.X);
        int cy = (int)Math.Round(e.Y);
        Color c1 = t < 0.25f ? Color.FromArgb(255, 255, 255, 220) : (t < 0.55f ? Color.FromArgb(255, 255, 190, 50) : Color.FromArgb(255, 220, 70, 30));
        Color c2 = t < 0.4f ? Color.FromArgb(255, 255, 230, 120) : Color.FromArgb(255, 170, 50, 30);
        if (t > 0.5f) Px(g, Color.FromArgb(255, 60, 52, 52), cx - r, cy - r - (int)(6f * t), r * 2, r * 2);
        g.FillEllipse(B(c1), cx - r, cy - r, r * 2, r * 2);
        int r2 = r * 2 / 3;
        g.FillEllipse(B(c2), cx - r2, cy - r2, r2 * 2, r2 * 2);
        int r3 = r / 3;
        if (t < 0.6f) g.FillEllipse(B(Color.FromArgb(255, 255, 255, 240)), cx - r3, cy - r3, r3 * 2, r3 * 2);
        // a few flying sparks for the bigger blasts
        if (e.Kind != ExplosionKind.Small && t < 0.7f)
        {
            for (int i = 0; i < 6; i++)
            {
                double a = i * 1.047 + e.X;
                int px = cx + (int)(Math.Cos(a) * (r + 6 + t * 10f));
                int py = cy + (int)(Math.Sin(a) * (r + 6 + t * 10f));
                Px(g, Color.FromArgb(255, 255, 220, 100), px, py, 2, 2);
            }
        }
    }

    public void DrawParticles(Graphics g, ParticleSystem ps)
    {
        for (int i = 0; i < ps.Count; i++)
        {
            Particle p = ps.Items[i];
            float k = p.Life / p.MaxLife;
            int x = (int)Math.Round(p.X);
            int y = (int)Math.Round(p.Y);
            switch (p.Kind)
            {
                case 0:
                    {
                        int s = (int)(p.Size * (1f + (1f - k)));
                        Px(g, Color.FromArgb(255, p.R, p.G, p.B), x - s / 2, y - s / 2, Math.Max(1, s), Math.Max(1, s));
                        break;
                    }
                case 1:
                    Px(g, Color.FromArgb(255, p.R, p.G, p.B), x, y, 2, 2);
                    break;
                case 2:
                    Px(g, Color.FromArgb(255, p.R, p.G, p.B), x, y, (int)Math.Max(2f, p.Size * 0.7f), 2);
                    break;
                case 3:
                    {
                        // the visible blast radius: a ring of pixels
                        float r = p.Size * (1f - k * 0.6f);
                        int dots = 20;
                        for (int d = 0; d < dots; d++)
                        {
                            double a = d * 6.2832 / dots;
                            Px(g, Color.FromArgb(255, p.R, p.G, p.B), x + (int)(Math.Cos(a) * r), y + (int)(Math.Sin(a) * r), 2, 2);
                        }
                        break;
                    }
                default:
                    {
                        int s = Math.Max(1, (int)(p.Size * k));
                        Px(g, Color.FromArgb(255, p.R, p.G, p.B), x - s / 2, y - s / 2, s, s);
                        break;
                    }
            }
        }
        foreach (FloatText t in ps.Texts)
        {
            float a = Math.Min(1f, t.Life * 2f);
            if (a < 0.2f) continue;
            g.DrawString(t.Text, fText, B(Color.Black), (int)t.X + 1, (int)t.Y + 1, sfCenter);
            g.DrawString(t.Text, fText, B(Color.FromArgb(255, t.Color.R, t.Color.G, t.Color.B)), (int)t.X, (int)t.Y, sfCenter);
        }
    }

    // ------------------------------------------------------------------ a helicopter for the title screen

    public void DrawHelicopter(Graphics g, int x, int y, float time)
    {
        Color body = Color.FromArgb(255, 84, 104, 76);
        Color dark = Color.FromArgb(255, 48, 62, 46);
        Px(g, body, x, y + 6, 26, 10);
        Px(g, dark, x, y + 14, 26, 2);
        Px(g, Color.FromArgb(255, 120, 190, 230), x + 2, y + 7, 9, 6);
        Px(g, body, x + 24, y + 8, 18, 4);
        Px(g, dark, x + 38, y + 4, 4, 8);
        Px(g, dark, x + 12, y + 1, 4, 5);
        int phase = (int)(time * 40f) & 3;
        Px(g, Color.FromArgb(255, 180, 190, 200), x - 8 + phase * 2, y, 44 - phase * 4, 1);
        Px(g, Color.FromArgb(255, 180, 190, 200), x + 38, y + 4 + (phase & 1) * 4, 1, 5);
        Px(g, dark, x + 3, y + 17, 20, 1);
        Px(g, dark, x + 5, y + 15, 1, 3);
        Px(g, dark, x + 19, y + 15, 1, 3);
    }
}
