namespace Contra;

/// <summary>
/// The final boss: a big armoured mobile weapon platform. Phase one fires horizontal bursts from three gun ports (the
/// player can jump them or crouch under the lowest); below half health phase two fires faster bursts and adds a big
/// aimed missile, and the machine glows and burns.
/// </summary>
public sealed class Boss
{
    public const float HalfW = 48f;
    public const float Height = 80f;

    public bool Active, Entering, Dying;
    public float X, Hp, MaxHp = GameConfig.BossMaxHp;
    public int Phase = 1;
    public float Age, HitFlash, DeathTimer, TrackPhase, Recoil;
    public bool EvFired, EvPhaseChanged, EvDeathBlast, EvDefeated;

    private float burstTimer, shotTimer, missileTimer, baseX;
    private int shotsLeft, port;
    private float lastX;
    private readonly Random rng = new Random();

    public float Y { get { return GameConfig.GroundY; } }

    public RectangleF Rect
    {
        get { return new RectangleF(X - HalfW, GameConfig.GroundY - Height, HalfW * 2f, Height); }
    }

    public bool Vulnerable { get { return Active && !Entering && !Dying; } }
    public float HealthFraction { get { return Math.Max(0f, Hp) / MaxHp; } }

    public float PortX { get { return X - 50f; } }

    public float PortY(int index)
    {
        return GameConfig.GroundY - 62f + index * 20f;
    }

    public void Reset()
    {
        Active = false;
        Entering = false;
        Dying = false;
        Phase = 1;
        HitFlash = 0f;
    }

    public void Spawn()
    {
        Active = true;
        Entering = true;
        Dying = false;
        Hp = MaxHp;
        baseX = GameConfig.LevelWidth - 92f;
        X = GameConfig.LevelWidth + 120f;
        lastX = X;
        Age = 0f;
        Phase = 1;
        burstTimer = 1.4f;
        shotsLeft = 0;
        missileTimer = 2f;
        DeathTimer = 0f;
    }

    public void Damage(float amount)
    {
        if (!Vulnerable) return;
        Hp -= amount;
        HitFlash = 0.06f;
        if (Hp <= 0f)
        {
            Hp = 0f;
            Dying = true;
            DeathTimer = 0f;
        }
    }

    public void Update(float dt, float tx, float ty, ProjectileManager shots, ExplosionManager expl, ParticleSystem parts)
    {
        EvFired = false;
        EvPhaseChanged = false;
        EvDeathBlast = false;
        EvDefeated = false;
        if (!Active) return;

        Age += dt;
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        if (Recoil > 0f) Recoil = Math.Max(0f, Recoil - dt * 5f);
        TrackPhase += (X - lastX) * 0.3f;
        lastX = X;

        if (Dying)
        {
            DeathTimer += dt;
            if (((int)(DeathTimer * 9f)) != ((int)((DeathTimer - dt) * 9f)))
            {
                float ex = X + (float)(rng.NextDouble() * 96.0 - 48.0);
                float ey = GameConfig.GroundY - (float)(rng.NextDouble() * 80.0);
                bool large = rng.Next(3) == 0;
                expl.Add(ex, ey, large ? ExplosionKind.Large : ExplosionKind.Small);
                parts.Flames(ex, ey, 6f, 3);
                parts.Smoke(ex, ey, 0f, -24f, 8f, 1.2f, 50);
                if (large) EvDeathBlast = true;
            }
            if (DeathTimer >= 3.2f)
            {
                expl.Add(X, GameConfig.GroundY - 40f, ExplosionKind.Boss);
                expl.Add(X - 30f, GameConfig.GroundY - 20f, ExplosionKind.Large, 0.15f);
                expl.Add(X + 30f, GameConfig.GroundY - 60f, ExplosionKind.Large, 0.25f);
                parts.Debris(X, GameConfig.GroundY - 40f, 40, Color.FromArgb(90, 96, 80));
                Active = false;
                EvDefeated = true;
            }
            return;
        }

        if (Entering)
        {
            X -= 42f * dt;
            if (X <= baseX)
            {
                X = baseX;
                Entering = false;
            }
            return;
        }

        // it hovers slowly back and forth in front of the arena wall
        X = baseX + MathF.Sin(Age * 0.6f) * (Phase == 1 ? 14f : 24f);

        if (Phase == 1 && HealthFraction <= 0.5f)
        {
            Phase = 2;
            EvPhaseChanged = true;
            burstTimer = 1.2f;
            shotsLeft = 0;
        }

        // the burst of horizontal shots from the three gun ports
        if (shotsLeft > 0)
        {
            shotTimer -= dt;
            if (shotTimer <= 0f)
            {
                float py = PortY(port % 3);
                float vy = Phase == 1 ? 0f : ((float)rng.NextDouble() - 0.5f) * 30f;
                shots.Spawn(ShotKind.EBullet, PortX, py, Phase == 1 ? -150f : -175f, vy, 1f, 4f);
                port++;
                shotsLeft--;
                shotTimer = Phase == 1 ? 0.16f : 0.1f;
                Recoil = 0.6f;
                EvFired = true;
            }
        }
        else
        {
            burstTimer -= dt;
            if (burstTimer <= 0f)
            {
                shotsLeft = Phase == 1 ? 6 : 9;
                shotTimer = 0.05f;
                burstTimer = Phase == 1 ? 1.9f : 1.15f;
            }
        }

        // phase two adds a big aimed missile
        if (Phase == 2)
        {
            missileTimer -= dt;
            if (missileTimer <= 0f)
            {
                float mx = X - 30f;
                float my = GameConfig.GroundY - 78f;
                float a = MathF.Atan2(ty - my, tx - mx);
                shots.Spawn(ShotKind.EBig, mx, my, MathF.Cos(a) * 100f, MathF.Sin(a) * 100f, 2f, 5f);
                missileTimer = 2.3f;
                Recoil = 1f;
                EvFired = true;
            }
        }
    }
}
