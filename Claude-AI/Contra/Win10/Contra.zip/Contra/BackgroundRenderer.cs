using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace Contra;

/// <summary>
/// The pixel-art battlefield drawn on the small canvas: a banded sky with pixel clouds, three parallax layers (mountains,
/// jungle hills with a distant fortress, palm silhouettes), the grass-topped rocky ground with water gaps, platforms,
/// sandbags, barricades, concrete, the bunker and all scenery. Layers are pre-rendered once with hard edges.
/// </summary>
public sealed class BackgroundRenderer : IDisposable
{
    private const int W = GameConfig.ViewW;
    private const int H = GameConfig.ViewH;
    private const int TileW = 960;

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Bitmap sky;
    private readonly Bitmap[] clouds = new Bitmap[3];
    private readonly Bitmap mountains;
    private readonly Bitmap hills;
    private readonly Bitmap palms;
    private readonly Bitmap rockTile;
    private readonly PointF[] poly = new PointF[8];

    public BackgroundRenderer()
    {
        sky = MakeSky();
        for (int i = 0; i < clouds.Length; i++) clouds[i] = MakeCloud(i);
        mountains = MakeMountains();
        hills = MakeHills();
        palms = MakePalms();
        rockTile = MakeRockTile();
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        sky.Dispose();
        foreach (Bitmap b in clouds) b.Dispose();
        mountains.Dispose();
        hills.Dispose();
        palms.Dispose();
        rockTile.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private void R(Graphics g, Color c, float x, float y, float w, float h)
    {
        g.FillRectangle(B(c), (int)Math.Round(x), (int)Math.Round(y), (int)Math.Round(w), (int)Math.Round(h));
    }

    private static int Hash(int c)
    {
        unchecked
        {
            int h = c * 374761393;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    private void DrawTile(Graphics g, Bitmap bmp, float offset, int y)
    {
        int x = -(int)(((offset % TileW) + TileW) % TileW);
        while (x < W)
        {
            g.DrawImageUnscaled(bmp, x, y);
            x += TileW;
        }
    }

    // ------------------------------------------------------------------ sky and parallax

    public void DrawSky(Graphics g, float camX, float time)
    {
        g.DrawImageUnscaled(sky, 0, 0);
        float cs = camX * 0.04f + time * 3f;
        const int cell = 220;
        int i0 = (int)Math.Floor((cs - 80f) / cell);
        int i1 = (int)Math.Floor((cs + W + 80f) / cell);
        for (int i = i0; i <= i1; i++)
        {
            int h = Hash(i * 29 + 7);
            if (h % 100 > 70) continue;
            Bitmap c = clouds[h % clouds.Length];
            g.DrawImageUnscaled(c, (int)(i * cell + (h >> 6) % 90 - cs), 10 + (h >> 12) % 70);
        }
        DrawTile(g, mountains, camX * 0.08f, 60);
        DrawTile(g, hills, camX * 0.2f, 112);
        DrawTile(g, palms, camX * 0.42f, 142);
    }

    // ------------------------------------------------------------------ the world

    public void DrawWorld(Graphics g, Level lv, float camX, float time)
    {
        GraphicsState st = g.Save();
        int cx = (int)Math.Round(camX);
        g.TranslateTransform(-cx, 0f);
        float x0 = cx - 120f;
        float x1 = cx + W + 120f;

        foreach (Decor d in lv.Decors)
        {
            if (d.X + d.W < x0 || d.X > x1) continue;
            if (d.Type == DecorType.BaseWall || d.Type == DecorType.Tower) DrawDecor(g, d, time);
        }
        DrawGround(g, lv, x0, x1, time);
        foreach (Solid s in lv.Solids)
        {
            if (s.Style == SolidStyle.Ground) continue;
            if (s.Rect.Right < x0 || s.Rect.Left > x1) continue;
            DrawSolid(g, s);
        }
        foreach (Decor d in lv.Decors)
        {
            if (d.X + d.W < x0 || d.X > x1) continue;
            if (d.Type == DecorType.BaseWall || d.Type == DecorType.Tower) continue;
            DrawDecor(g, d, time);
        }
        g.Restore(st);
    }

    private void DrawGround(Graphics g, Level lv, float x0, float x1, float time)
    {
        float gy = GameConfig.GroundY;
        foreach (Solid s in lv.Solids)
        {
            if (s.Style != SolidStyle.Ground) continue;
            float a = Math.Max(s.Rect.Left, x0);
            float b = Math.Min(s.Rect.Right, x1);
            if (b <= a) continue;
            // the rocky cliff face, tiled
            int tx = (int)Math.Floor(a / 32f) * 32;
            for (int x = tx; x < b; x += 32)
            {
                for (int y = (int)gy + 6; y < H; y += 24) g.DrawImageUnscaled(rockTile, x, y);
            }
            R(g, Color.FromArgb(255, 74, 52, 28), a, gy + 5f, b - a, 2f);
            // grass on top with pixel blades
            R(g, Color.FromArgb(255, 44, 120, 36), a, gy - 1f, b - a, 6f);
            R(g, Color.FromArgb(255, 84, 176, 48), a, gy - 1f, b - a, 2f);
            for (int x = (int)Math.Floor(a / 4f) * 4; x < b; x += 4)
            {
                int h = Hash(x * 3 + 11);
                if (h % 3 == 0) R(g, Color.FromArgb(255, 112, 200, 60), x, gy - 3f, 2f, 2f);
                if (h % 5 == 0) R(g, Color.FromArgb(255, 30, 92, 30), x + 1f, gy + 4f, 2f, 4f + h % 4);
                if (h % 41 == 0) R(g, Color.FromArgb(255, 255, 224, 80), x, gy - 4f, 2f, 2f);
            }
        }
        // the water gaps with moving ripples
        foreach (Gap gp in lv.Gaps)
        {
            if (gp.X1 < x0 || gp.X0 > x1) continue;
            R(g, Color.FromArgb(255, 20, 60, 130), gp.X0, gy + 8f, gp.X1 - gp.X0, H - gy);
            R(g, Color.FromArgb(255, 40, 110, 190), gp.X0, gy + 8f, gp.X1 - gp.X0, 10f);
            for (float x = gp.X0; x < gp.X1; x += 8f)
            {
                float yy = gy + 9f + (float)Math.Round(Math.Sin(time * 3f + x * 0.4f) * 1.5f);
                R(g, Color.FromArgb(255, 200, 232, 255), x, yy, 4f, 1f);
            }
            R(g, Color.FromArgb(255, 72, 52, 28), gp.X0 - 2f, gy + 6f, 2f, H - gy);
            R(g, Color.FromArgb(255, 72, 52, 28), gp.X1, gy + 6f, 2f, H - gy);
        }
    }

    private void DrawSolid(Graphics g, Solid s)
    {
        RectangleF r = s.Rect;
        switch (s.Style)
        {
            case SolidStyle.Platform: DrawPlatform(g, r); break;
            case SolidStyle.Sandbag: DrawSandbags(g, r); break;
            case SolidStyle.Barricade: DrawBarricade(g, r); break;
            case SolidStyle.Concrete: DrawConcrete(g, r); break;
            case SolidStyle.Rock: DrawRock(g, r); break;
            default: DrawBunker(g, r); break;
        }
    }

    private void DrawPlatform(Graphics g, RectangleF r)
    {
        if (r.X < 3900f)
        {
            // a jungle ledge: grass on top, earth below and hanging roots
            R(g, Color.FromArgb(255, 110, 78, 40), r.X, r.Y, r.Width, r.Height);
            R(g, Color.FromArgb(255, 60, 150, 44), r.X - 2f, r.Y - 3f, r.Width + 4f, 4f);
            R(g, Color.FromArgb(255, 110, 200, 60), r.X - 2f, r.Y - 3f, r.Width + 4f, 1f);
            for (float x = r.X + 4f; x < r.Right - 2f; x += 8f) R(g, Color.FromArgb(255, 74, 52, 28), x, r.Bottom, 1f, 3f + Hash((int)x) % 4);
        }
        else
        {
            // a steel catwalk with hazard stripes
            R(g, Color.FromArgb(255, 98, 106, 118), r.X, r.Y, r.Width, r.Height);
            R(g, Color.FromArgb(255, 160, 170, 184), r.X, r.Y, r.Width, 1f);
            for (float x = r.X; x < r.Right - 4f; x += 8f)
            {
                R(g, Color.FromArgb(255, 230, 190, 40), x, r.Y + 2f, 4f, 3f);
                R(g, Color.FromArgb(255, 40, 40, 44), x + 4f, r.Y + 2f, 4f, 3f);
            }
            for (float x = r.X + 6f; x < r.Right; x += 28f) R(g, Color.FromArgb(255, 70, 76, 86), x, r.Bottom, 2f, 8f);
        }
    }

    private void DrawSandbags(Graphics g, RectangleF r)
    {
        int rows = Math.Max(1, (int)(r.Height / 10f));
        for (int row = 0; row < rows; row++)
        {
            float y = r.Bottom - (row + 1) * 10f;
            float off = (row % 2) * 8f;
            for (float x = r.Left - off; x < r.Right; x += 16f)
            {
                float bx = Math.Max(x, r.Left);
                float bw = Math.Min(x + 16f, r.Right) - bx;
                if (bw < 4f) continue;
                int h = Hash((int)x * 3 + row);
                R(g, (h & 1) == 0 ? Color.FromArgb(255, 200, 172, 108) : Color.FromArgb(255, 184, 154, 94), bx, y + 1f, bw, 9f);
                R(g, Color.FromArgb(255, 226, 202, 140), bx + 1f, y + 1f, bw - 2f, 2f);
                R(g, Color.FromArgb(255, 110, 84, 46), bx, y + 9f, bw, 1f);
                R(g, Color.FromArgb(255, 110, 84, 46), bx, y + 1f, 1f, 9f);
            }
        }
    }

    private void DrawBarricade(Graphics g, RectangleF r)
    {
        R(g, Color.FromArgb(255, 126, 86, 44), r.X, r.Y, r.Width, r.Height);
        for (float y = r.Y + 4f; y < r.Bottom; y += 6f) R(g, Color.FromArgb(255, 74, 48, 22), r.X, y, r.Width, 1f);
        R(g, Color.FromArgb(255, 170, 124, 70), r.X, r.Y, 2f, r.Height);
        R(g, Color.FromArgb(255, 60, 38, 18), r.Right - 1f, r.Y, 1f, r.Height);
        R(g, Color.FromArgb(255, 150, 154, 160), r.X + r.Width / 2f - 1f, r.Y + 1f, 2f, 2f);
    }

    private void DrawConcrete(Graphics g, RectangleF r)
    {
        R(g, Color.FromArgb(255, 132, 136, 144), r.X, r.Y, r.Width, r.Height);
        R(g, Color.FromArgb(255, 176, 180, 188), r.X, r.Y, r.Width, 2f);
        R(g, Color.FromArgb(255, 88, 92, 100), r.X, r.Bottom - 3f, r.Width, 3f);
        R(g, Color.FromArgb(255, 70, 74, 82), r.Right - 2f, r.Y, 2f, r.Height);
        for (float x = r.X + 4f; x < r.Right - 3f; x += 10f)
        {
            R(g, Color.FromArgb(255, 80, 84, 92), x, r.Y + 3f, 2f, 2f);
            if (r.Height > 30f) R(g, Color.FromArgb(255, 80, 84, 92), x, r.Bottom - 8f, 2f, 2f);
        }
        if (r.Height > 30f)
        {
            R(g, Color.FromArgb(255, 30, 32, 38), r.X + r.Width / 2f - 8f, r.Y + 12f, 16f, 5f);       // a firing slit
            R(g, Color.FromArgb(255, 230, 190, 40), r.X, r.Y + r.Height / 2f, r.Width, 2f);
        }
    }

    private void DrawRock(Graphics g, RectangleF r)
    {
        R(g, Color.FromArgb(255, 112, 88, 64), r.X, r.Y, r.Width, r.Height);
        R(g, Color.FromArgb(255, 150, 124, 94), r.X, r.Y, r.Width, 2f);
        R(g, Color.FromArgb(255, 74, 54, 36), r.X, r.Bottom - 2f, r.Width, 2f);
        R(g, Color.FromArgb(255, 74, 54, 36), r.X + r.Width * 0.4f, r.Y + 3f, 1f, r.Height - 5f);
        R(g, Color.FromArgb(255, 60, 140, 40), r.X, r.Y - 1f, r.Width, 2f);
    }

    private void DrawBunker(Graphics g, RectangleF r)
    {
        R(g, Color.FromArgb(255, 112, 118, 106), r.X, r.Y, r.Width, r.Height);
        R(g, Color.FromArgb(255, 150, 156, 142), r.X, r.Y, r.Width, 3f);
        R(g, Color.FromArgb(255, 74, 80, 70), r.X, r.Bottom - 4f, r.Width, 4f);
        for (float x = r.X + 4f; x < r.Right - 3f; x += 12f) R(g, Color.FromArgb(255, 74, 80, 70), x, r.Y + 3f, 1f, r.Height - 7f);
        R(g, Color.FromArgb(255, 26, 28, 30), r.X + 14f, r.Y + 14f, 28f, 8f);                    // gun slits
        R(g, Color.FromArgb(255, 26, 28, 30), r.Right - 42f, r.Y + 14f, 28f, 8f);
        R(g, Color.FromArgb(255, 60, 100, 52), r.X, r.Y - 2f, r.Width, 3f);                      // camouflage on the roof
        for (float x = r.X + 2f; x < r.Right - 4f; x += 12f) R(g, Color.FromArgb(255, 90, 130, 64), x, r.Y - 2f, 5f, 2f);
        R(g, Color.FromArgb(255, 200, 40, 40), r.X + r.Width / 2f - 2f, r.Y + 24f, 4f, 8f);
    }

    // ------------------------------------------------------------------ scenery

    private void DrawDecor(Graphics g, Decor d, float time)
    {
        switch (d.Type)
        {
            case DecorType.Palm: DrawPalm(g, d, time); break;
            case DecorType.Bush: DrawBush(g, d); break;
            case DecorType.Wreck: DrawWreck(g, d); break;
            case DecorType.Fence: DrawFence(g, d); break;
            case DecorType.Tower: DrawTower(g, d, time); break;
            case DecorType.BaseWall: DrawBaseWall(g, d); break;
            case DecorType.Sign: DrawSign(g, d); break;
            default: DrawCrates(g, d); break;
        }
    }

    private void DrawPalm(Graphics g, Decor d, float time)
    {
        float sway = (float)Math.Round(Math.Sin(time * 1.1f + d.X) * 1.5f);
        float tx = d.X + 8f + sway;
        float ty = d.Y - d.H;
        // trunk in short segments leaning to one side
        for (int i = 0; i < (int)(d.H / 4f); i++)
        {
            float t = i * 4f / d.H;
            float x = d.X + 6f + (tx - d.X - 6f) * t * t;
            R(g, (i % 2 == 0) ? Color.FromArgb(255, 126, 88, 48) : Color.FromArgb(255, 96, 66, 34), x, d.Y - i * 4f - 4f, 4f, 4f);
        }
        Color l1 = Color.FromArgb(255, 36, 140, 52);
        Color l2 = Color.FromArgb(255, 84, 190, 70);
        Color l3 = Color.FromArgb(255, 24, 96, 40);
        for (int k = 0; k < 7; k++)
        {
            float a = -3.2f + k * 0.55f;
            float len = 16f + (k % 2) * 4f;
            float lx = tx + 2f;
            float ly = ty;
            for (int s = 0; s < 8; s++)
            {
                float t = s / 7f;
                float px = lx + (float)Math.Cos(a) * len * t;
                float py = ly + (float)Math.Sin(a) * len * t + t * t * 10f;
                R(g, s < 5 ? ((k & 1) == 0 ? l1 : l2) : l3, px, py, 3f, 3f);
                if (s > 1 && s < 7) R(g, l3, px, py + 3f, 2f, 1f);
            }
        }
        R(g, Color.FromArgb(255, 110, 70, 30), tx, ty, 4f, 4f);
    }

    private void DrawBush(Graphics g, Decor d)
    {
        for (int i = 0; i < 4; i++)
        {
            int h = Hash((int)d.X + i * 17);
            float w = 12f + h % 8;
            float x = d.X + i * 7f;
            R(g, Color.FromArgb(255, 30, 100, 40), x, d.Y - 12f - h % 4, w, 12f + h % 4);
            R(g, Color.FromArgb(255, 60, 156, 56), x + 1f, d.Y - 12f - h % 4, w - 3f, 3f);
        }
    }

    private void DrawWreck(Graphics g, Decor d)
    {
        R(g, Color.FromArgb(255, 54, 48, 44), d.X, d.Y - 14f, d.W, 8f);
        R(g, Color.FromArgb(255, 74, 64, 56), d.X + 6f, d.Y - 24f, 20f, 10f);
        R(g, Color.FromArgb(255, 120, 64, 36), d.X + 2f, d.Y - 12f, 14f, 3f);
        R(g, Color.FromArgb(255, 24, 24, 26), d.X + 4f, d.Y - 8f, 10f, 8f);
        R(g, Color.FromArgb(255, 24, 24, 26), d.X + d.W - 16f, d.Y - 8f, 10f, 8f);
        R(g, Color.FromArgb(255, 120, 120, 124), d.X + 7f, d.Y - 5f, 4f, 4f);
    }

    private void DrawFence(Graphics g, Decor d)
    {
        for (float x = d.X; x <= d.X + d.W; x += 25f) R(g, Color.FromArgb(255, 110, 78, 44), x, d.Y - 18f, 2f, 18f);
        for (int row = 0; row < 3; row++)
        {
            float y = d.Y - 4f - row * 6f;
            for (float x = d.X; x < d.X + d.W; x += 4f)
            {
                float yy = y + (((int)(x / 4f)) % 2 == 0 ? -1f : 1f);
                R(g, Color.FromArgb(255, 150, 154, 160), x, yy, 3f, 1f);
            }
        }
    }

    private void DrawTower(Graphics g, Decor d, float time)
    {
        float top = d.Y - d.H;
        R(g, Color.FromArgb(255, 94, 100, 112), d.X, top, d.W, d.H);
        R(g, Color.FromArgb(255, 132, 140, 154), d.X, top, 4f, d.H);
        R(g, Color.FromArgb(255, 60, 64, 74), d.X + d.W - 4f, top, 4f, d.H);
        for (float y = top + 14f; y < d.Y - 10f; y += 24f)
        {
            R(g, Color.FromArgb(255, 30, 32, 40), d.X + 10f, y, d.W - 20f, 8f);
            R(g, Color.FromArgb(255, 255, 214, 90), d.X + 12f, y + 2f, 6f, 4f);
        }
        R(g, Color.FromArgb(255, 70, 74, 84), d.X - 4f, top - 6f, d.W + 8f, 6f);
        bool blink = ((int)(time * 3f) & 1) == 0;
        R(g, blink ? Color.FromArgb(255, 255, 60, 60) : Color.FromArgb(255, 110, 24, 24), d.X + d.W / 2f - 2f, top - 12f, 4f, 6f);
        R(g, Color.FromArgb(255, 70, 74, 84), d.X + d.W / 2f - 1f, top - 24f, 2f, 12f);
    }

    private void DrawBaseWall(Graphics g, Decor d)
    {
        float top = d.Y - d.H;
        Color[] pal = { Color.FromArgb(255, 108, 114, 128), Color.FromArgb(255, 96, 104, 118), Color.FromArgb(255, 118, 124, 136) };
        R(g, pal[d.Variant % 3], d.X, top, d.W, d.H);
        R(g, Color.FromArgb(255, 150, 158, 172), d.X, top, d.W, 3f);
        R(g, Color.FromArgb(255, 70, 76, 88), d.X + d.W - 3f, top, 3f, d.H);
        for (float x = d.X + 8f; x < d.X + d.W - 12f; x += 28f)
        {
            for (float y = top + 12f; y < d.Y - 24f; y += 24f)
            {
                R(g, Color.FromArgb(255, 34, 36, 44), x, y, 16f, 10f);
                R(g, Color.FromArgb(255, 90, 160, 220), x + 1f, y + 1f, 14f, 3f);
            }
        }
        for (float x = d.X; x < d.X + d.W; x += 14f) R(g, Color.FromArgb(255, 108, 114, 128), x, top - 4f, 8f, 4f);
        R(g, Color.FromArgb(255, 230, 190, 40), d.X, d.Y - 8f, d.W, 3f);
    }

    private void DrawSign(Graphics g, Decor d)
    {
        R(g, Color.FromArgb(255, 110, 76, 40), d.X + d.W / 2f - 1f, d.Y - d.H, 3f, d.H);
        R(g, Color.FromArgb(255, 190, 150, 90), d.X, d.Y - d.H + 2f, d.W, 12f);
        R(g, Color.FromArgb(255, 74, 48, 22), d.X, d.Y - d.H + 2f, d.W, 1f);
        R(g, Color.FromArgb(255, 74, 48, 22), d.X, d.Y - d.H + 13f, d.W, 1f);
        R(g, Color.FromArgb(255, 200, 40, 40), d.X + 3f, d.Y - d.H + 6f, d.W - 9f, 3f);
        R(g, Color.FromArgb(255, 200, 40, 40), d.X + d.W - 7f, d.Y - d.H + 4f, 3f, 7f);
    }

    private void DrawCrates(Graphics g, Decor d)
    {
        R(g, Color.FromArgb(255, 150, 106, 56), d.X, d.Y - 12f, 14f, 12f);
        R(g, Color.FromArgb(255, 150, 106, 56), d.X + 14f, d.Y - 12f, 14f, 12f);
        R(g, Color.FromArgb(255, 150, 106, 56), d.X + 6f, d.Y - 22f, 14f, 10f);
        for (int i = 0; i < 3; i++)
        {
            float x = i == 0 ? d.X : (i == 1 ? d.X + 14f : d.X + 6f);
            float y = i == 2 ? d.Y - 22f : d.Y - 12f;
            float h = i == 2 ? 10f : 12f;
            R(g, Color.FromArgb(255, 74, 48, 22), x, y, 14f, 1f);
            R(g, Color.FromArgb(255, 74, 48, 22), x, y + h - 1f, 14f, 1f);
            R(g, Color.FromArgb(255, 74, 48, 22), x, y, 1f, h);
            R(g, Color.FromArgb(255, 74, 48, 22), x + 13f, y, 1f, h);
        }
    }

    // ------------------------------------------------------------------ pre-rendered layers

    private static Graphics Pixel(Bitmap bmp)
    {
        Graphics g = Graphics.FromImage(bmp);
        g.SmoothingMode = SmoothingMode.None;
        g.PixelOffsetMode = PixelOffsetMode.Half;
        g.InterpolationMode = InterpolationMode.NearestNeighbor;
        return g;
    }

    private static Bitmap MakeSky()
    {
        Bitmap bmp = new Bitmap(W, H, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            int bands = 18;
            for (int i = 0; i < bands; i++)
            {
                float t = i / (float)(bands - 1);
                Color c = Color.FromArgb(255, (int)(26 + 124 * t), (int)(70 + 134 * t), (int)(170 + 70 * t));
                using (SolidBrush b = new SolidBrush(c))
                {
                    g.FillRectangle(b, 0, i * H / bands, W, H / bands + 2);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeCloud(int variant)
    {
        Bitmap bmp = new Bitmap(80, 26, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            Random rnd = new Random(40 + variant * 7);
            using (SolidBrush shade = new SolidBrush(Color.FromArgb(255, 170, 200, 236)))
            using (SolidBrush body = new SolidBrush(Color.FromArgb(255, 244, 250, 255)))
            {
                for (int i = 0; i < 6; i++)
                {
                    int x = 8 + rnd.Next(48);
                    int w = 14 + rnd.Next(14);
                    int h = 8 + rnd.Next(6);
                    g.FillRectangle(shade, x, 12 + rnd.Next(3) + 2, w, h - 2);
                }
                for (int i = 0; i < 6; i++)
                {
                    int x = 8 + rnd.Next(48);
                    int w = 14 + rnd.Next(14);
                    int h = 8 + rnd.Next(6);
                    g.FillRectangle(body, x, 8 + rnd.Next(5), w, h);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeMountains()
    {
        Bitmap bmp = new Bitmap(TileW, 140, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            Random rnd = new Random(12);
            int step = 40;
            int count = TileW / step;
            for (int layer = 0; layer < 2; layer++)
            {
                PointF[] pts = new PointF[count + 3];
                pts[0] = new PointF(0, 140);
                for (int i = 0; i <= count; i++)
                {
                    float peak = (i % 2 == 0) ? 20 + rnd.Next(60) : 60 + rnd.Next(40);
                    if (i == 0 || i == count) peak = 70;
                    pts[i + 1] = new PointF(i * step, peak + layer * 16);
                }
                pts[count + 2] = new PointF(TileW, 140);
                Color c = layer == 0 ? Color.FromArgb(255, 96, 124, 186) : Color.FromArgb(255, 70, 100, 160);
                using (SolidBrush b = new SolidBrush(c))
                {
                    g.FillPolygon(b, pts);
                }
                if (layer == 0)
                {
                    using (SolidBrush snow = new SolidBrush(Color.FromArgb(255, 226, 238, 255)))
                    {
                        for (int i = 1; i <= count; i += 2)
                        {
                            PointF p = pts[i + 1];
                            g.FillPolygon(snow, new[] { new PointF(p.X, p.Y), new PointF(p.X - 8, p.Y + 14), new PointF(p.X, p.Y + 9), new PointF(p.X + 8, p.Y + 15) });
                        }
                    }
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeHills()
    {
        Bitmap bmp = new Bitmap(TileW, 110, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            Random rnd = new Random(33);
            using (SolidBrush hill = new SolidBrush(Color.FromArgb(255, 34, 108, 90)))
            using (SolidBrush hill2 = new SolidBrush(Color.FromArgb(255, 26, 84, 72)))
            using (SolidBrush stone = new SolidBrush(Color.FromArgb(255, 112, 122, 148)))
            using (SolidBrush dark = new SolidBrush(Color.FromArgb(255, 60, 70, 96)))
            {
                for (int i = 0; i < 14; i++)
                {
                    int cx = i * 70 + rnd.Next(30);
                    int w = 90 + rnd.Next(60);
                    int h = 36 + rnd.Next(34);
                    g.FillEllipse(i % 2 == 0 ? hill : hill2, cx - w / 2, 110 - h, w, h * 2);
                }
                // the distant fortress on a cliff
                for (int k = 0; k < 3; k++)
                {
                    int fx = 120 + k * 320 + rnd.Next(40);
                    g.FillRectangle(stone, fx, 46, 22, 50);
                    for (int c = 0; c < 3; c++) g.FillRectangle(stone, fx + c * 8, 41, 5, 6);
                    g.FillRectangle(stone, fx + 22, 62, 46, 34);
                    for (int c = 0; c < 4; c++) g.FillRectangle(stone, fx + 22 + c * 12, 57, 6, 6);
                    g.FillRectangle(dark, fx + 8, 58, 6, 12);
                    g.FillRectangle(dark, fx + 36, 72, 8, 10);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakePalms()
    {
        Bitmap bmp = new Bitmap(TileW, 90, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            Random rnd = new Random(55);
            using (SolidBrush trunk = new SolidBrush(Color.FromArgb(255, 24, 70, 44)))
            using (SolidBrush leaf = new SolidBrush(Color.FromArgb(255, 20, 92, 48)))
            using (SolidBrush bush = new SolidBrush(Color.FromArgb(255, 18, 80, 44)))
            {
                for (int i = 0; i < 40; i++)
                {
                    int x = rnd.Next(TileW);
                    int h = 34 + rnd.Next(30);
                    g.FillRectangle(trunk, x, 88 - h, 3, h);
                    for (int k = 0; k < 6; k++)
                    {
                        double a = -3.0 + k * 0.55;
                        for (int s = 0; s < 6; s++)
                        {
                            double t = s / 5.0;
                            int px = x + 1 + (int)(Math.Cos(a) * 14 * t);
                            int py = 88 - h + (int)(Math.Sin(a) * 14 * t + t * t * 8);
                            g.FillRectangle(leaf, px, py, 3, 3);
                        }
                    }
                }
                for (int i = 0; i < 40; i++)
                {
                    int x = rnd.Next(TileW);
                    int w = 16 + rnd.Next(18);
                    g.FillRectangle(bush, x, 78 - rnd.Next(8), w, 14);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeRockTile()
    {
        Bitmap bmp = new Bitmap(32, 24, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            Random rnd = new Random(8);
            using (SolidBrush mortar = new SolidBrush(Color.FromArgb(255, 64, 44, 26)))
            {
                g.FillRectangle(mortar, 0, 0, 32, 24);
            }
            for (int row = 0; row < 2; row++)
            {
                int y = row * 12;
                int x = row * 10 - 6;
                while (x < 32)
                {
                    int w = 14 + rnd.Next(8);
                    int shade = rnd.Next(3);
                    Color c = shade == 0 ? Color.FromArgb(255, 150, 112, 70) : (shade == 1 ? Color.FromArgb(255, 128, 94, 58) : Color.FromArgb(255, 168, 128, 82));
                    using (SolidBrush b = new SolidBrush(c))
                    using (SolidBrush hi = new SolidBrush(Color.FromArgb(255, 196, 158, 108)))
                    using (SolidBrush lo = new SolidBrush(Color.FromArgb(255, 96, 68, 40)))
                    {
                        g.FillRectangle(b, x + 1, y + 1, w - 2, 10);
                        g.FillRectangle(hi, x + 1, y + 1, w - 2, 2);
                        g.FillRectangle(lo, x + 1, y + 9, w - 2, 2);
                    }
                    x += w;
                }
            }
        }
        return bmp;
    }
}
