namespace Contra;

public enum SolidStyle { Ground, Platform, Sandbag, Barricade, Concrete, Rock, Bunker }

/// <summary>A solid block (ground, sandbags, concrete) or a one-way platform that can be jumped through from below.</summary>
public sealed class Solid
{
    public RectangleF Rect;
    public bool OneWay;
    public SolidStyle Style;
}

public enum DecorType { Palm, Bush, Wreck, Fence, Tower, BaseWall, Sign, Crates }

public sealed class Decor
{
    public DecorType Type;
    public float X, Y, W, H;              // Y is the bottom
    public int Variant;
}

public struct EnemySpawn
{
    public EnemyType Type;
    public float X, Y, Min, Max;           // Y is where the feet stand
}

public struct BarrelSpawn
{
    public float X, Y;
    public bool Ammo;
}

public struct PickupSpawn
{
    public PickupType Type;
    public float X, Y;
}

public struct Gap
{
    public float X0, X1;
}

/// <summary>
/// The one hand-made battlefield: a jungle entrance, a military outpost with sandbags and a bunker, an enemy base with
/// concrete structures and defensive platforms, and the boss arena at the end. Every raised platform is 32 px above the
/// next level (a jump reaches about 57 px), every obstacle is 40 px or lower and every water gap is at most 50 px wide
/// (a jump at running speed covers about 58 px), so nothing can block the way.
/// </summary>
public sealed class Level
{
    public readonly List<Solid> Solids = new List<Solid>(64);
    public readonly List<Decor> Decors = new List<Decor>(128);
    public readonly List<EnemySpawn> Enemies = new List<EnemySpawn>(64);
    public readonly List<BarrelSpawn> Barrels = new List<BarrelSpawn>(24);
    public readonly List<PickupSpawn> Pickups = new List<PickupSpawn>(24);
    public readonly List<float> Checkpoints = new List<float>(2);
    public readonly List<Gap> Gaps = new List<Gap>(4);

    public bool SolidAt(float x, float y)
    {
        foreach (Solid s in Solids)
        {
            if (!s.OneWay && s.Rect.Contains(x, y)) return true;
        }
        return false;
    }

    private void Block(float x, float top, float w, float h, SolidStyle style, bool oneWay = false)
    {
        Solid s = new Solid();
        s.Rect = new RectangleF(x, top, w, h);
        s.Style = style;
        s.OneWay = oneWay;
        Solids.Add(s);
    }

    private void Dec(DecorType type, float x, float bottom, float w, float h, int variant = 0)
    {
        Decor d = new Decor();
        d.Type = type; d.X = x; d.Y = bottom; d.W = w; d.H = h; d.Variant = variant;
        Decors.Add(d);
    }

    private void En(EnemyType type, float x, float y, float min = 0f, float max = 0f)
    {
        EnemySpawn s = new EnemySpawn();
        s.Type = type; s.X = x; s.Y = y; s.Min = min == 0f ? x : min; s.Max = max == 0f ? x : max;
        Enemies.Add(s);
    }

    private void Bar(float x, float y = GameConfig.GroundY, bool ammo = false)
    {
        BarrelSpawn b = new BarrelSpawn();
        b.X = x; b.Y = y; b.Ammo = ammo;
        Barrels.Add(b);
    }

    private void Pick(PickupType type, float x, float y = GameConfig.GroundY)
    {
        PickupSpawn p = new PickupSpawn();
        p.Type = type; p.X = x; p.Y = y;
        Pickups.Add(p);
    }

    public static Level Build()
    {
        Level lv = new Level();
        float g = GameConfig.GroundY;
        float[,] gaps = { { 1180f, 1220f }, { 3000f, 3040f }, { 4600f, 4650f } };

        // ---- ground in segments with water gaps between them
        float start = 0f;
        for (int i = 0; i < gaps.GetLength(0); i++)
        {
            lv.Block(start, g, gaps[i, 0] - start, 60f, SolidStyle.Ground);
            Gap gp = new Gap();
            gp.X0 = gaps[i, 0];
            gp.X1 = gaps[i, 1];
            lv.Gaps.Add(gp);
            start = gaps[i, 1];
        }
        lv.Block(start, g, GameConfig.LevelWidth - start, 60f, SolidStyle.Ground);

        lv.Checkpoints.Add(1900f);
        lv.Checkpoints.Add(3900f);

        // ---- section 1: the jungle entrance (0 - 1900)
        lv.Block(240f, 188f, 72f, 6f, SolidStyle.Platform, true);
        lv.Block(520f, 188f, 80f, 6f, SolidStyle.Platform, true);
        lv.Block(640f, 156f, 56f, 6f, SolidStyle.Platform, true);
        lv.Block(800f, 208f, 40f, 12f, SolidStyle.Rock);
        lv.Block(846f, 200f, 34f, 20f, SolidStyle.Rock);
        lv.Block(1000f, 196f, 10f, 24f, SolidStyle.Barricade);
        lv.Block(1300f, 188f, 64f, 6f, SolidStyle.Platform, true);
        lv.Block(1520f, 200f, 32f, 20f, SolidStyle.Sandbag);
        lv.Block(1700f, 196f, 10f, 24f, SolidStyle.Barricade);

        // ---- section 2: the military outpost (1900 - 3900)
        lv.Block(1960f, 200f, 32f, 20f, SolidStyle.Sandbag);
        lv.Block(2100f, 196f, 10f, 24f, SolidStyle.Barricade);
        lv.Block(2200f, 200f, 32f, 20f, SolidStyle.Sandbag);
        lv.Block(2300f, 180f, 96f, 40f, SolidStyle.Bunker);
        lv.Block(2520f, 200f, 44f, 20f, SolidStyle.Sandbag);
        lv.Block(2640f, 188f, 64f, 6f, SolidStyle.Platform, true);
        lv.Block(2900f, 200f, 32f, 20f, SolidStyle.Sandbag);
        lv.Block(3100f, 188f, 80f, 6f, SolidStyle.Platform, true);
        lv.Block(3400f, 200f, 32f, 20f, SolidStyle.Sandbag);
        lv.Block(3700f, 200f, 32f, 20f, SolidStyle.Sandbag);

        // ---- section 3: the enemy base (3900 - 5600)
        lv.Block(3960f, 196f, 24f, 24f, SolidStyle.Concrete);
        lv.Block(4020f, 188f, 80f, 6f, SolidStyle.Platform, true);
        lv.Block(4120f, 156f, 64f, 6f, SolidStyle.Platform, true);
        lv.Block(4200f, 180f, 40f, 40f, SolidStyle.Concrete);
        lv.Block(4300f, 188f, 96f, 6f, SolidStyle.Platform, true);
        lv.Block(4420f, 156f, 64f, 6f, SolidStyle.Platform, true);
        lv.Block(4500f, 196f, 24f, 24f, SolidStyle.Concrete);
        lv.Block(4760f, 196f, 24f, 24f, SolidStyle.Concrete);
        lv.Block(4900f, 180f, 40f, 40f, SolidStyle.Concrete);
        lv.Block(5050f, 200f, 32f, 20f, SolidStyle.Sandbag);
        lv.Block(5120f, 188f, 80f, 6f, SolidStyle.Platform, true);
        lv.Block(5400f, 196f, 24f, 24f, SolidStyle.Concrete);

        // ---- scenery
        foreach (float px in new[] { 30f, 140f, 360f, 590f, 760f, 930f, 1090f, 1260f, 1420f, 1640f, 1820f, 2000f, 2260f, 2480f, 2760f, 3060f, 3300f, 3560f })
            lv.Dec(DecorType.Palm, px, g, 40f, 70f + (px % 30f), (int)(px / 10f) % 3);
        foreach (float px in new[] { 90f, 330f, 700f, 880f, 1120f, 1380f, 1580f, 1760f, 2160f, 2420f, 2640f, 2980f, 3220f, 3500f })
            lv.Dec(DecorType.Bush, px, g, 30f, 16f, (int)(px / 10f) % 3);
        lv.Dec(DecorType.Fence, 1780f, g, 100f, 20f);
        lv.Dec(DecorType.Fence, 2800f, g, 90f, 20f);
        lv.Dec(DecorType.Fence, 3600f, g, 90f, 20f);
        lv.Dec(DecorType.Wreck, 1400f, g, 56f, 26f);
        lv.Dec(DecorType.Wreck, 3250f, g, 56f, 26f);
        lv.Dec(DecorType.Crates, 2440f, g, 28f, 20f);
        lv.Dec(DecorType.Sign, 60f, g, 28f, 34f);
        lv.Dec(DecorType.Sign, 1880f, g, 28f, 34f);
        lv.Dec(DecorType.Sign, 3880f, g, 28f, 34f);
        for (float bx = 3900f; bx < 5700f; bx += 150f)
            lv.Dec(DecorType.BaseWall, bx, g, 140f, 120f + ((int)(bx / 150f) % 3) * 24f, (int)(bx / 150f) % 3);
        lv.Dec(DecorType.Tower, 4700f, g, 60f, 170f);
        lv.Dec(DecorType.Tower, 5500f, g, 60f, 190f);

        // ---- section 1 enemies
        lv.En(EnemyType.Infantry, 380f, g, 300f, 540f);
        lv.En(EnemyType.Infantry, 640f, g, 560f, 780f);
        lv.En(EnemyType.Rifleman, 560f, 188f);
        lv.En(EnemyType.Infantry, 920f, g, 860f, 1100f);
        lv.En(EnemyType.Infantry, 1010f, g, 940f, 1160f);
        lv.En(EnemyType.Rifleman, 1330f, 188f);
        lv.En(EnemyType.Infantry, 1450f, g, 1250f, 1650f);
        lv.En(EnemyType.Rifleman, 1530f, 200f);
        lv.En(EnemyType.Infantry, 1700f, g, 1600f, 1850f);
        // ---- section 2 enemies
        lv.En(EnemyType.Rifleman, 1975f, 200f);
        lv.En(EnemyType.Grenadier, 2130f, g);
        lv.En(EnemyType.Infantry, 2060f, g, 2000f, 2190f);
        lv.En(EnemyType.Rifleman, 2215f, 200f);
        lv.En(EnemyType.Rifleman, 2330f, 180f);
        lv.En(EnemyType.Turret, 2375f, 180f);
        lv.En(EnemyType.Heavy, 2600f, g, 2560f, 2800f);
        lv.En(EnemyType.Grenadier, 2670f, 188f);
        lv.En(EnemyType.Infantry, 2780f, g, 2700f, 2950f);
        lv.En(EnemyType.Rifleman, 2916f, 200f);
        lv.En(EnemyType.Grenadier, 3150f, 188f);
        lv.En(EnemyType.Infantry, 3300f, g, 3200f, 3450f);
        lv.En(EnemyType.Infantry, 3480f, g, 3300f, 3600f);
        lv.En(EnemyType.Heavy, 3650f, g, 3600f, 3860f);
        lv.En(EnemyType.Rifleman, 3716f, 200f);
        // ---- section 3 enemies
        lv.En(EnemyType.Elite, 3990f, g, 3960f, 4150f);
        lv.En(EnemyType.Rifleman, 4040f, 188f);
        lv.En(EnemyType.Turret, 4150f, 156f);
        lv.En(EnemyType.Heavy, 4180f, g, 4130f, 4290f);
        lv.En(EnemyType.Elite, 4340f, g, 4250f, 4470f);
        lv.En(EnemyType.Grenadier, 4330f, 188f);
        lv.En(EnemyType.Rifleman, 4450f, 156f);
        lv.En(EnemyType.Heavy, 4500f, 196f);
        lv.En(EnemyType.Elite, 4560f, g, 4500f, 4590f);
        lv.En(EnemyType.Elite, 4720f, g, 4660f, 4850f);
        lv.En(EnemyType.Heavy, 4830f, g, 4790f, 4890f);
        lv.En(EnemyType.Turret, 4920f, 180f);
        lv.En(EnemyType.Elite, 5000f, g, 4950f, 5120f);
        lv.En(EnemyType.Grenadier, 5150f, 188f);
        lv.En(EnemyType.Heavy, 5230f, g, 5200f, 5350f);
        lv.En(EnemyType.Elite, 5330f, g, 5250f, 5450f);
        lv.En(EnemyType.Rifleman, 5412f, 196f);
        lv.En(EnemyType.Turret, 5490f, g);

        // ---- explosive barrels and ammunition containers
        foreach (float bx in new[] { 460f, 960f, 2050f, 2066f, 2150f, 2260f, 2700f, 3300f, 3560f, 4620f, 4860f, 5300f })
            lv.Bar(bx);
        lv.Bar(4160f, g, true);
        lv.Bar(1600f, g, true);
        lv.Bar(5100f, g, true);
        lv.Bar(5560f, g, true);

        // ---- pickups
        lv.Pick(PickupType.Fire, 700f);
        lv.Pick(PickupType.Grenades, 340f);
        lv.Pick(PickupType.Life, 1332f, 188f);
        lv.Pick(PickupType.Health, 1450f);
        lv.Pick(PickupType.Spread, 2060f);
        lv.Pick(PickupType.Health, 2420f);
        lv.Pick(PickupType.Grenades, 2672f, 188f);
        lv.Pick(PickupType.Health, 3400f);
        lv.Pick(PickupType.Laser, 4000f);
        lv.Pick(PickupType.Life, 4452f, 156f);
        lv.Pick(PickupType.Grenades, 4800f);
        lv.Pick(PickupType.Spread, 4900f, 180f);
        lv.Pick(PickupType.Health, 5000f);
        lv.Pick(PickupType.Fire, 5210f);
        lv.Pick(PickupType.Health, 5560f);
        return lv;
    }
}
