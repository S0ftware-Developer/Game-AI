namespace Contra;

public enum WeaponType { Machine, Spread, Laser, Fire }

/// <summary>
/// The four weapons: the machine gun (unlimited ammunition) and the spread, laser and fire guns (limited ammunition,
/// refilled by pickups). Any weapon with ammunition can be selected at any time with the number keys.
/// </summary>
public sealed class WeaponSystem
{
    public WeaponType Current = WeaponType.Machine;
    public readonly int[] Ammo = new int[4];
    public float Cooldown;
    public float MuzzleTimer;
    public bool EvShot;
    public WeaponType EvType;
    private readonly Random rng = new Random();

    public string Name
    {
        get
        {
            switch (Current)
            {
                case WeaponType.Spread: return "SPREAD GUN";
                case WeaponType.Laser: return "LASER GUN";
                case WeaponType.Fire: return "FIRE GUN";
                default: return "MACHINE GUN";
            }
        }
    }

    public int CurrentAmmo { get { return Current == WeaponType.Machine ? -1 : Ammo[(int)Current]; } }

    public static int FullAmmo(WeaponType t)
    {
        switch (t)
        {
            case WeaponType.Spread: return 50;
            case WeaponType.Laser: return 30;
            case WeaponType.Fire: return 90;
            default: return 0;
        }
    }

    public void Reset()
    {
        Current = WeaponType.Machine;
        for (int i = 0; i < Ammo.Length; i++) Ammo[i] = 0;
        Cooldown = 0f;
        MuzzleTimer = 0f;
    }

    /// <summary>A pickup: equips the weapon and refills its ammunition.</summary>
    public void Give(WeaponType t)
    {
        if (t == WeaponType.Machine)
        {
            Current = t;
            return;
        }
        Ammo[(int)t] = FullAmmo(t);
        Current = t;
    }

    /// <summary>Selecting a weapon with the number keys; returns false when it has no ammunition.</summary>
    public bool Select(WeaponType t)
    {
        if (t != WeaponType.Machine && Ammo[(int)t] <= 0) return false;
        Current = t;
        return true;
    }

    public void Update(float dt, Player p, bool fire, ProjectileManager shots)
    {
        if (Cooldown > 0f) Cooldown -= dt;
        if (MuzzleTimer > 0f) MuzzleTimer = Math.Max(0f, MuzzleTimer - dt);
        if (!fire || Cooldown > 0f || p.Dead || p.HurtTimer > 0.25f) return;

        float x = p.MuzzleX;
        float y = p.MuzzleY;
        float baseAngle = MathF.Atan2(p.AimY, p.AimX);
        WeaponType fired = Current;
        switch (Current)
        {
            case WeaponType.Machine:
                {
                    float a = baseAngle + ((float)rng.NextDouble() - 0.5f) * 0.03f;
                    shots.Spawn(ShotKind.Machine, x, y, MathF.Cos(a) * 290f, MathF.Sin(a) * 290f, 1f, 1.1f);
                    Cooldown = 0.11f;
                    break;
                }
            case WeaponType.Spread:
                for (int i = -1; i <= 1; i++)
                {
                    float a = baseAngle + i * 0.3f;
                    shots.Spawn(ShotKind.Spread, x, y, MathF.Cos(a) * 250f, MathF.Sin(a) * 250f, 1f, 1.0f);
                }
                Cooldown = 0.26f;
                Ammo[(int)WeaponType.Spread]--;
                break;
            case WeaponType.Laser:
                {
                    shots.Spawn(ShotKind.Laser, x, y, MathF.Cos(baseAngle) * 400f, MathF.Sin(baseAngle) * 400f, 4f, 1.0f, 3);
                    Cooldown = 0.32f;
                    Ammo[(int)WeaponType.Laser]--;
                    break;
                }
            default:
                {
                    float a = baseAngle + ((float)rng.NextDouble() - 0.5f) * 0.45f;
                    float sp = 120f + (float)rng.NextDouble() * 50f;
                    shots.Spawn(ShotKind.Flame, x, y, MathF.Cos(a) * sp, MathF.Sin(a) * sp, 1f, 0.42f, 3);
                    Cooldown = 0.06f;
                    Ammo[(int)WeaponType.Fire]--;
                    break;
                }
        }
        if (Current != WeaponType.Machine && Ammo[(int)Current] <= 0)
        {
            Ammo[(int)Current] = 0;
            Current = WeaponType.Machine;           // an empty weapon returns to the machine gun
        }
        MuzzleTimer = 0.05f;
        p.ShootAnim = 0.18f;
        EvShot = true;
        EvType = fired;
    }
}
