namespace Contra;

public enum GameState { Menu, Controls, Playing, Paused, GameOver, Victory }

/// <summary>Game rules and the fixed-step simulation (1/120 s): the battlefield, the commando, enemies, boss and all menus.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;

    public GameState State = GameState.Menu;
    public Level Level;
    public readonly InputManager Input = new InputManager();
    public readonly Player Player = new Player();
    public readonly ProjectileManager Shots = new ProjectileManager();
    public readonly GrenadeManager Grenades = new GrenadeManager();
    public readonly EnemyManager Enemies = new EnemyManager();
    public readonly Boss Boss = new Boss();
    public readonly PickupManager Pickups = new PickupManager();
    public readonly BarrelManager Barrels = new BarrelManager();
    public readonly ExplosionManager Explosions = new ExplosionManager();
    public readonly ParticleSystem Particles = new ParticleSystem();
    public readonly Camera Camera = new Camera();
    public readonly ScoreManager Scores = new ScoreManager();
    public Action? ExitRequested;

    public float Clock;                  // keeps running for menu animations
    public float PlayTime;
    public int Score;
    public int Kills;
    public bool NewRecord;
    public float Flash;
    public string Banner = "";
    public float BannerTimer;
    public string Note = "";
    public float NoteTimer;
    public int MenuIndex, PauseIndex, EndIndex;

    private bool bossSpawned;
    private int checkpoint = -1;
    private float respawnX = 40f;
    private float endTimer;
    private readonly Random rng = new Random();

    public GameEngine()
    {
        Scores.Load();
        Level = Level.Build();
        Enemies.Killed = OnEnemyKilled;
        ResetWorld();
    }

    private void ResetWorld()
    {
        Level = Level.Build();
        Enemies.Reset(Level);
        Pickups.Reset(Level);
        Barrels.Reset(Level);
        Shots.Clear();
        Grenades.Clear();
        Explosions.Clear();
        Particles.Clear();
        Boss.Reset();
        Player.Reset(40f, GameConfig.GroundY - 20f);
        Camera.Reset(0f);
        Score = 0;
        Kills = 0;
        PlayTime = 0f;
        NewRecord = false;
        Flash = 0f;
        Note = "";
        NoteTimer = 0f;
        Banner = "";
        BannerTimer = 0f;
        bossSpawned = false;
        checkpoint = -1;
        respawnX = 40f;
        endTimer = 0f;
    }

    // ------------------------------------------------------------------ menus

    public void StartGame()
    {
        ResetWorld();
        State = GameState.Playing;
        Sfx.Play(SfxId.Click);
        Banner = "MISSION START";
        BannerTimer = 2f;
        Input.Clear();
    }

    public int ItemCount(GameState s)
    {
        switch (s)
        {
            case GameState.Menu: return 3;
            case GameState.Paused: return 4;
            case GameState.GameOver:
            case GameState.Victory: return 2;
            default: return 1;
        }
    }

    public void Hover(GameState s, int index)
    {
        if (index < 0 || index >= ItemCount(s)) return;
        if (s == GameState.Menu) MenuIndex = index;
        else if (s == GameState.Paused) PauseIndex = index;
        else if (s == GameState.GameOver || s == GameState.Victory) EndIndex = index;
    }

    public void Activate(GameState s, int index)
    {
        Sfx.Play(SfxId.Click);
        switch (s)
        {
            case GameState.Menu:
                if (index == 0) StartGame();
                else if (index == 1) State = GameState.Controls;
                else ExitRequested?.Invoke();
                break;
            case GameState.Controls:
                State = GameState.Menu;
                break;
            case GameState.Paused:
                if (index == 0) State = GameState.Playing;
                else if (index == 1) StartGame();
                else if (index == 2) Sfx.SetMuted(!Sfx.Muted);
                else State = GameState.Menu;
                break;
            case GameState.GameOver:
            case GameState.Victory:
                if (index == 0) StartGame();
                else State = GameState.Menu;
                break;
        }
    }

    public void AutoPause()
    {
        Input.Clear();
        if (State == GameState.Playing)
        {
            PauseIndex = 0;
            State = GameState.Paused;
        }
    }

    private void MenuNavigation(ref int index, int count)
    {
        if (Input.AnyPressed(Keys.Up, Keys.W))
        {
            index = (index + count - 1) % count;
            Sfx.Play(SfxId.Select);
        }
        if (Input.AnyPressed(Keys.Down, Keys.S))
        {
            index = (index + 1) % count;
            Sfx.Play(SfxId.Select);
        }
    }

    // ------------------------------------------------------------------ simulation

    public void Update()
    {
        Clock += Dt;
        switch (State)
        {
            case GameState.Menu:
                MenuNavigation(ref MenuIndex, 3);
                if (Input.AnyPressed(Keys.Enter, Keys.Space)) Activate(GameState.Menu, MenuIndex);
                break;
            case GameState.Controls:
                if (Input.AnyPressed(Keys.Enter, Keys.Escape) | Input.Pressed(Keys.Space)) Activate(GameState.Controls, 0);
                break;
            case GameState.Paused:
                MenuNavigation(ref PauseIndex, 4);
                if (Input.AnyPressed(Keys.Escape, Keys.P)) State = GameState.Playing;
                else if (Input.AnyPressed(Keys.Enter, Keys.Space)) Activate(GameState.Paused, PauseIndex);
                break;
            case GameState.GameOver:
            case GameState.Victory:
                MenuNavigation(ref EndIndex, 2);
                if (Input.Pressed(Keys.R)) StartGame();
                else if (Input.AnyPressed(Keys.M, Keys.Escape)) State = GameState.Menu;
                else if (Input.AnyPressed(Keys.Enter, Keys.Space)) Activate(State, EndIndex);
                Shots.Update(Dt, Level, Camera.X, Camera.X + GameConfig.ViewW);
                UpdateEffects();
                break;
            default:
                UpdatePlaying();
                break;
        }
        Input.ClearPressed();
    }

    private void UpdatePlaying()
    {
        if (Input.AnyPressed(Keys.Escape, Keys.P))
        {
            PauseIndex = 0;
            State = GameState.Paused;
            Sfx.Play(SfxId.Click);
            return;
        }
        PlayTime += Dt;

        if (Input.AnyPressed(Keys.D1, Keys.NumPad1)) SelectWeapon(WeaponType.Machine);
        if (Input.AnyPressed(Keys.D2, Keys.NumPad2)) SelectWeapon(WeaponType.Spread);
        if (Input.AnyPressed(Keys.D3, Keys.NumPad3)) SelectWeapon(WeaponType.Laser);
        if (Input.AnyPressed(Keys.D4, Keys.NumPad4)) SelectWeapon(WeaponType.Fire);

        PlayerInput inp = new PlayerInput();
        inp.Left = Input.AnyHeld(Keys.A, Keys.Left);
        inp.Right = Input.AnyHeld(Keys.D, Keys.Right);
        inp.Up = Input.AnyHeld(Keys.W, Keys.Up);
        inp.Down = Input.AnyHeld(Keys.S, Keys.Down);
        inp.Fire = Input.AnyHeld(Keys.J, Keys.ControlKey, Keys.LControlKey);
        inp.JumpHeld = Input.Held(Keys.Space);
        inp.JumpPressed = Input.Pressed(Keys.Space);
        inp.GrenadePressed = Input.AnyPressed(Keys.K, Keys.X);

        float camLeft = Camera.X;
        float camRight = Camera.X + GameConfig.ViewW;

        Player.Update(Dt, inp, Level, Shots, camLeft, GameConfig.LevelWidth);
        HandlePlayerEvents();

        // checkpoints
        for (int i = checkpoint + 1; i < Level.Checkpoints.Count; i++)
        {
            if (Player.X >= Level.Checkpoints[i] && !Player.Dead)
            {
                checkpoint = i;
                respawnX = Level.Checkpoints[i];
                Note = i == 0 ? "CHECKPOINT - MILITARY OUTPOST" : "CHECKPOINT - ENEMY BASE";
                NoteTimer = 2.4f;
                Sfx.Play(SfxId.Checkpoint);
                Particles.Ring(Player.X, Player.Y - 14f, 28f, Color.FromArgb(255, 120, 240, 255));
            }
        }

        // falling into the water costs a life
        if (!Player.Dead && Player.Y > GameConfig.ViewH + 6f)
        {
            Splash(Player.X);
            KillPlayer(0f);
        }

        float tx = Player.X;
        float ty = Player.Y - 16f;
        bool fired, threw;
        Enemies.Update(Dt, camLeft, camRight, tx, ty, Level, Shots, Grenades, out fired, out threw);
        if (fired) Sfx.Play(SfxId.EnemyShoot);
        if (threw) Sfx.Play(SfxId.GrenadeThrow);

        UpdateBoss(tx, ty);

        Shots.Update(Dt, Level, camLeft, camRight);
        Grenades.Update(Dt, Level);
        Pickups.Update(Dt);
        Barrels.Update(Dt);

        CollisionManager.Resolve(this);
        ProcessExplosions();

        // death, respawn at the latest checkpoint and the end of the game
        if (Player.Dead && Player.DeathTimer <= 0f)
        {
            if (Player.Lives > 0)
            {
                Player.Respawn(respawnX, GameConfig.GroundY - 30f);
                Camera.Reset(Math.Max(0f, Math.Min(GameConfig.ArenaStartX, respawnX - GameConfig.ViewW * 0.5f)));
                Particles.Ring(Player.X, Player.Y - 14f, 30f, Color.White);
            }
            else
            {
                endTimer += Dt;
                if (endTimer >= 0.5f) EndGame(false);
            }
        }

        Camera.Update(Dt, Player.X, GameConfig.ArenaStartX);
        UpdateEffects();
    }

    private void SelectWeapon(WeaponType t)
    {
        if (Player.Weapon.Select(t)) Sfx.Play(SfxId.Select);
    }

    private void UpdateEffects()
    {
        Particles.Update(Dt);
        Explosions.Update(Dt);
        if (Flash > 0f) Flash = Math.Max(0f, Flash - Dt);
        if (BannerTimer > 0f) BannerTimer -= Dt;
        if (NoteTimer > 0f) NoteTimer -= Dt;
    }

    private void HandlePlayerEvents()
    {
        if (Player.EvJump) Sfx.Play(SfxId.Jump);
        if (Player.EvLand) Dust(Player.X, Player.Y);
        if (Player.EvThrow)
        {
            Grenades.Throw(Player.ThrowX, Player.ThrowY, Player.ThrowVX, Player.ThrowVY, true);
            Sfx.Play(SfxId.GrenadeThrow);
        }
        WeaponSystem w = Player.Weapon;
        if (w.EvShot)
        {
            w.EvShot = false;
            switch (w.EvType)
            {
                case WeaponType.Spread: Sfx.Play(SfxId.Spread); break;
                case WeaponType.Laser: Sfx.Play(SfxId.Laser); break;
                case WeaponType.Fire: Sfx.Play(SfxId.Fire); break;
                default: Sfx.Play(SfxId.MachineGun); break;
            }
            Particles.Sparks(Player.MuzzleX, Player.MuzzleY, 50f, 1, Color.FromArgb(255, 235, 150));
        }
    }

    private void Dust(float x, float y)
    {
        for (int i = 0; i < 3; i++)
            Particles.Smoke(x + (float)(rng.NextDouble() * 8.0 - 4.0), y - 1f, (float)(rng.NextDouble() * 40.0 - 20.0), -10f, 2.5f, 0.35f, 190);
    }

    private void Splash(float x)
    {
        Particles.Sparks(x, GameConfig.ViewH - 20f, 90f, 12, Color.FromArgb(160, 220, 255));
        Particles.Ring(x, GameConfig.ViewH - 20f, 22f, Color.FromArgb(160, 220, 255));
    }

    private void UpdateBoss(float tx, float ty)
    {
        if (!bossSpawned && tx > GameConfig.BossTriggerX)
        {
            bossSpawned = true;
            Boss.Spawn();
            Banner = "WARNING! BOSS";
            BannerTimer = 3.2f;
            Note = "BOSS ENCOUNTER";
            NoteTimer = 3f;
            Sfx.Play(SfxId.BossArrive);
        }

        Boss.Update(Dt, tx, ty, Shots, Explosions, Particles);
        if (Boss.EvFired) Sfx.Play(SfxId.EnemyShoot);
        if (Boss.EvPhaseChanged)
        {
            Banner = "PHASE 2";
            BannerTimer = 1.8f;
            Sfx.Play(SfxId.GrenadeBoom);
            Camera.Shake = 0.35f;
            Flash = 0.2f;
            Explosions.Add(Boss.X - 20f, GameConfig.GroundY - 56f, ExplosionKind.Large);
            Explosions.Add(Boss.X + 24f, GameConfig.GroundY - 40f, ExplosionKind.Large, 0.12f);
        }
        if (Boss.Dying)
        {
            if (Boss.DeathTimer < 0.05f)
            {
                foreach (Projectile p in Shots.Items)
                {
                    if (!p.FromPlayer) p.Alive = false;       // the boss stops attacking
                }
                Sfx.Play(SfxId.BossDie);
            }
            Camera.Shake = Math.Max(Camera.Shake, 0.1f);
        }
        if (Boss.EvDeathBlast) Sfx.Play(SfxId.GrenadeBoom);
        if (Boss.EvDefeated)
        {
            Score += GameConfig.ScoreBoss;
            Camera.Shake = 0.7f;
            Flash = 0.5f;
            Sfx.Play(SfxId.BossDie);
            EndGame(true);
        }
    }

    private void EndGame(bool victory)
    {
        NewRecord = Scores.Submit(Score);
        EndIndex = 0;
        State = victory ? GameState.Victory : GameState.GameOver;
        if (victory) Sfx.Play(SfxId.Victory);
    }

    // ------------------------------------------------------------------ explosions

    private void ProcessExplosions()
    {
        for (int i = 0; i < Grenades.Exploded.Count; i++)
        {
            Grenade gr = Grenades.Exploded[i];
            Explode(gr.X, gr.Y, GameConfig.GrenadeRadius, GameConfig.GrenadeDamage, !gr.FromPlayer, 0);
        }
        Grenades.Exploded.Clear();

        int guard = 0;
        while (Barrels.Blasts.Count > 0 && guard++ < 64)
        {
            Blast bl = Barrels.Blasts[0];
            Barrels.Blasts.RemoveAt(0);
            Score += GameConfig.ScoreBarrel;
            Particles.Text(bl.X, bl.Y - 14f, GameConfig.ScoreBarrel.ToString(), Color.FromArgb(255, 255, 230, 120));
            Explode(bl.X, bl.Y, GameConfig.BarrelRadius, GameConfig.BarrelDamage, true, bl.Chain);
        }
    }

    /// <summary>An explosion with a visible radius ring that damages everything inside it (and chains into other barrels).</summary>
    private void Explode(float x, float y, float radius, float dmg, bool hurtsPlayer, int chain)
    {
        float delay = Math.Min(0.5f, chain * 0.08f);
        Explosions.Add(x, y, radius >= 36f ? ExplosionKind.Large : ExplosionKind.Small, delay);
        Particles.Ring(x, y, radius * 1.15f, Color.FromArgb(255, 235, 150));
        Particles.Debris(x, y, 6, Color.FromArgb(120, 100, 80));
        Particles.Smoke(x, y - 4f, 0f, -20f, radius * 0.18f, 0.8f, 80);
        Sfx.Play(SfxId.GrenadeBoom);
        Camera.Shake = Math.Max(Camera.Shake, 0.12f);

        foreach (Enemy e in Enemies.Enemies)
        {
            if (e.Hittable && CollisionManager.CircleRect(x, y, radius, e.Rect)) Enemies.Damage(e, dmg);
        }
        foreach (Barrel b in Barrels.Items)
        {
            if (b.Alive && CollisionManager.CircleRect(x, y, radius, b.Rect)) Barrels.Destroy(b, chain + 1);
        }
        if (Boss.Vulnerable && CollisionManager.CircleRect(x, y, radius, Boss.Rect)) Boss.Damage(dmg);
        if (hurtsPlayer && Player.Vulnerable && CollisionManager.CircleRect(x, y, radius, Player.Rect)) PlayerHurt(1, Player.X < x ? -1f : 1f);
    }

    // ------------------------------------------------------------------ damage and events

    public void PlayerHurt(int dmg, float dirX)
    {
        if (!Player.Vulnerable) return;
        Player.Hp -= dmg;
        Player.Invuln = GameConfig.HitInvulnerability;
        Camera.Shake = Math.Max(Camera.Shake, 0.12f);
        if (Player.Hp > 0)
        {
            Player.Knock(dirX);
            Sfx.Play(SfxId.Hurt);
            Particles.Sparks(Player.X, Player.Y - 14f, 80f, 6, Color.FromArgb(255, 90, 70));
            return;
        }
        KillPlayer(dirX);
    }

    private void KillPlayer(float dirX)
    {
        Player.Hp = 0;
        Player.Dead = true;
        Player.DeathTimer = GameConfig.DeathTime;
        Player.Lives--;
        Player.VY = -150f;
        Player.VX = dirX * 50f;
        Player.Grounded = false;
        Sfx.Play(SfxId.Hurt);
        Sfx.Play(SfxId.EnemyDie);
        Particles.Debris(Player.X, Player.Y - 14f, 8, Color.FromArgb(220, 60, 50));
        Particles.Sparks(Player.X, Player.Y - 14f, 100f, 8, Color.FromArgb(255, 100, 70));
    }

    private void OnEnemyKilled(Enemy e)
    {
        Score += e.Score;
        Kills++;
        Sfx.Play(SfxId.EnemyDie);
        bool structure = e.Type == EnemyType.Turret;
        if (structure)
        {
            Explosions.Add(e.X, e.Y - 8f, ExplosionKind.Large);
            Particles.Debris(e.X, e.Y - 8f, 8, Color.FromArgb(110, 112, 120));
        }
        else
        {
            Particles.Debris(e.X, e.Y - 14f, 5, e.Type == EnemyType.Elite ? Color.FromArgb(120, 30, 60) : Color.FromArgb(90, 130, 70));
            Particles.Sparks(e.X, e.Y - 14f, 80f, 4, Color.FromArgb(255, 200, 120));
        }
        Particles.Text(e.X, e.Y - e.Height - 8f, e.Score.ToString(), Color.FromArgb(255, 255, 230, 120));
    }

    public void CollectPickup(Pickup p)
    {
        p.Alive = false;
        Score += GameConfig.ScorePickup;
        switch (p.Type)
        {
            case PickupType.Spread: Player.Weapon.Give(WeaponType.Spread); Sfx.Play(SfxId.Pickup); break;
            case PickupType.Laser: Player.Weapon.Give(WeaponType.Laser); Sfx.Play(SfxId.Pickup); break;
            case PickupType.Fire: Player.Weapon.Give(WeaponType.Fire); Sfx.Play(SfxId.Pickup); break;
            case PickupType.Grenades:
                Player.Grenades = Math.Min(GameConfig.MaxGrenades, Player.Grenades + 2);
                Sfx.Play(SfxId.Pickup);
                break;
            case PickupType.Life:
                Player.Lives = Math.Min(GameConfig.MaxLives, Player.Lives + 1);
                Sfx.Play(SfxId.OneUp);
                break;
            default:
                Player.Hp = Math.Min(GameConfig.StartHealth, Player.Hp + 1);
                Sfx.Play(SfxId.Pickup);
                break;
        }
        Note = Pickup.Label(p.Type);
        NoteTimer = 2.2f;
        Particles.Ring(p.X, p.Y - 7f, 20f, Color.FromArgb(255, 240, 150));
        Particles.Sparks(p.X, p.Y - 7f, 80f, 6, Color.FromArgb(255, 240, 150));
    }
}
