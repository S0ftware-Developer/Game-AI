namespace Contra;

/// <summary>
/// All tunable numbers of the game. The game is drawn on a small pixel canvas (480 x 270) that is scaled up by two with
/// nearest-neighbour filtering; every gameplay coordinate below is in canvas pixels.
/// </summary>
public static class GameConfig
{
    // ---- canvas and window layout
    public const int ViewW = 480;
    public const int ViewH = 270;
    public const int PixelScale = 2;
    public const int LogicalW = ViewW * PixelScale;                 // 960
    public const int FooterH = 32;
    public const int LogicalH = ViewH * PixelScale + FooterH;       // 572

    // ---- world
    public const float GroundY = 220f;
    public const float LevelWidth = 6080f;
    public const float ArenaStartX = LevelWidth - ViewW;            // the camera stops here for the boss
    public const float BossTriggerX = 5660f;
    public const float Gravity = 900f;

    // ---- the commando
    public const float PlayerHalfW = 5f;
    public const float PlayerH = 30f;
    public const float PlayerCrouchH = 18f;
    public const float PlayerSpeed = 82f;
    public const float JumpSpeed = 320f;
    public const float JumpCutSpeed = 120f;
    public const int StartHealth = 3;
    public const int StartLives = 3;
    public const int MaxLives = 9;
    public const int StartGrenades = 3;
    public const int MaxGrenades = 9;
    public const float HitInvulnerability = 1.6f;
    public const float RespawnInvulnerability = 2.5f;
    public const float DeathTime = 1.2f;
    public const float GrenadeCooldown = 0.6f;

    // ---- grenades and explosions
    public const float GrenadeFuse = 1.1f;
    public const float GrenadeRadius = 38f;
    public const float GrenadeDamage = 8f;
    public const float BarrelRadius = 42f;
    public const float BarrelDamage = 10f;

    // ---- score
    public const int ScoreInfantry = 100;
    public const int ScoreRifleman = 150;
    public const int ScoreGrenadier = 200;
    public const int ScoreHeavy = 400;
    public const int ScoreElite = 500;
    public const int ScoreTurret = 300;
    public const int ScoreBarrel = 50;
    public const int ScoreBoss = 10000;
    public const int ScorePickup = 100;

    // ---- boss
    public const float BossMaxHp = 150f;
}
