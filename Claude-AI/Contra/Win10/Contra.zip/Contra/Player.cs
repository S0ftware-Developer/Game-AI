namespace Contra;

public struct PlayerInput
{
    public bool Left, Right, Up, Down, Fire, JumpPressed, JumpHeld, GrenadePressed;
}

/// <summary>
/// The commando: responsive running, variable-height jumps, crouching, five aiming directions (forward, up, down and the
/// two diagonals), shooting while running or jumping, grenades, damage with knockback, death and respawn.
/// </summary>
public sealed class Player
{
    public float X, Y, VX, VY;             // X is the centre, Y the feet
    public int Facing = 1;
    public bool Grounded, Crouching, Dead;
    public int Hp = GameConfig.StartHealth;
    public int Lives = GameConfig.StartLives;
    public int Grenades = GameConfig.StartGrenades;
    public float Invuln, HurtTimer, DeathTimer, ShootAnim, ThrowAnim, RunPhase, Age, ThrowCooldown;
    public int Aim;                        // 0 forward, 1 up, 2 down, 3 diagonal up, 4 diagonal down
    public float MuzzleX, MuzzleY, AimX = 1f, AimY;
    public readonly WeaponSystem Weapon = new WeaponSystem();

    public bool EvJump, EvLand, EvThrow;
    public float ThrowX, ThrowY, ThrowVX, ThrowVY;

    private float coyote, buffer;

    public float Height { get { return Crouching ? GameConfig.PlayerCrouchH : GameConfig.PlayerH; } }

    public RectangleF Rect
    {
        get { return new RectangleF(X - GameConfig.PlayerHalfW, Y - Height, GameConfig.PlayerHalfW * 2f, Height); }
    }

    public bool Vulnerable { get { return !Dead && Invuln <= 0f; } }

    public void Reset(float x, float y)
    {
        Lives = GameConfig.StartLives;
        Grenades = GameConfig.StartGrenades;
        Respawn(x, y);
        Invuln = 1.5f;
    }

    public void Respawn(float x, float y)
    {
        X = x;
        Y = y;
        VX = 0f;
        VY = 0f;
        Dead = false;
        Hp = GameConfig.StartHealth;
        Invuln = GameConfig.RespawnInvulnerability;
        Crouching = false;
        Grounded = false;
        HurtTimer = 0f;
        ThrowAnim = 0f;
        ShootAnim = 0f;
        Grenades = Math.Max(Grenades, GameConfig.StartGrenades);
        Weapon.Reset();
    }

    private static float Approach(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    /// <summary>The player takes a hit: knockback away from the source and a short damage animation.</summary>
    public void Knock(float dirX)
    {
        HurtTimer = 0.4f;
        VX = dirX * 70f;
        VY = -110f;
        Grounded = false;
    }

    public void Update(float dt, PlayerInput inp, Level lv, ProjectileManager shots, float minX, float maxX)
    {
        EvJump = false;
        EvLand = false;
        EvThrow = false;
        Age += dt;
        if (Invuln > 0f) Invuln = Math.Max(0f, Invuln - dt);
        if (HurtTimer > 0f) HurtTimer = Math.Max(0f, HurtTimer - dt);
        if (ShootAnim > 0f) ShootAnim = Math.Max(0f, ShootAnim - dt);
        if (ThrowAnim > 0f) ThrowAnim = Math.Max(0f, ThrowAnim - dt);
        if (ThrowCooldown > 0f) ThrowCooldown -= dt;

        if (Dead)
        {
            DeathTimer -= dt;
            VX = Approach(VX, 0f, 160f * dt);
            VY = Math.Min(500f, VY + GameConfig.Gravity * dt);
            float dx = X, dy = Y, dvx = VX, dvy = VY;
            CollisionManager.MoveBody(lv, ref dx, ref dy, ref dvx, ref dvy, 4f, 6f, dt);
            X = dx; Y = dy; VX = dvx; VY = dvy;
            return;
        }

        int dir = (inp.Right ? 1 : 0) - (inp.Left ? 1 : 0);
        bool hurt = HurtTimer > 0f;
        if (dir != 0 && !hurt) Facing = dir;

        // crouching and aiming: W aims up, S crouches (standing still) or aims down (in the air) or diagonally (moving)
        Crouching = inp.Down && !inp.Up && Grounded && dir == 0 && !hurt;
        if (inp.Up) Aim = dir != 0 ? 3 : 1;
        else if (inp.Down && dir != 0) Aim = 4;
        else if (inp.Down && !Grounded) Aim = 2;
        else Aim = 0;

        // horizontal movement
        if (!hurt)
        {
            float target = Crouching ? 0f : dir * GameConfig.PlayerSpeed;
            float accel = dir != 0 ? 900f : 1100f;
            if (!Grounded) accel *= 0.8f;
            VX = Approach(VX, target, accel * dt);
        }
        else
        {
            VX = Approach(VX, 0f, 120f * dt);
        }

        // jumping with a short grace time and input buffering; releasing the key cuts the jump
        coyote = Grounded ? 0.09f : Math.Max(0f, coyote - dt);
        buffer = inp.JumpPressed ? 0.11f : Math.Max(0f, buffer - dt);
        if (buffer > 0f && coyote > 0f && !hurt)
        {
            VY = -GameConfig.JumpSpeed;
            Grounded = false;
            Crouching = false;
            coyote = 0f;
            buffer = 0f;
            EvJump = true;
        }
        if (!inp.JumpHeld && VY < -GameConfig.JumpCutSpeed) VY = -GameConfig.JumpCutSpeed;
        VY = Math.Min(520f, VY + GameConfig.Gravity * dt);

        bool wasGrounded = Grounded;
        float fall = VY;
        float x = X, y = Y, vx = VX, vy = VY;
        Grounded = CollisionManager.MoveBody(lv, ref x, ref y, ref vx, ref vy, GameConfig.PlayerHalfW, Height, dt);
        X = x; Y = y; VX = vx; VY = vy;
        if (Grounded && !wasGrounded && fall > 160f) EvLand = true;
        if (X < minX + 8f) { X = minX + 8f; if (VX < 0f) VX = 0f; }
        if (X > maxX - 8f) { X = maxX - 8f; if (VX > 0f) VX = 0f; }
        if (Grounded) RunPhase += Math.Abs(VX) * dt * 0.16f;

        UpdateAim();
        Weapon.Update(dt, this, inp.Fire, shots);

        if (inp.GrenadePressed && Grenades > 0 && ThrowCooldown <= 0f && !hurt)
        {
            Grenades--;
            ThrowAnim = 0.3f;
            ThrowCooldown = GameConfig.GrenadeCooldown;
            EvThrow = true;
            ThrowX = X + Facing * 6f;
            ThrowY = Y - Height + 6f;
            ThrowVX = Facing * 88f + VX * 0.5f;
            ThrowVY = -160f;
        }
    }

    /// <summary>The aim direction (a unit vector) and the muzzle position from the pose.</summary>
    private void UpdateAim()
    {
        float f = Facing;
        const float s = 0.7071f;
        switch (Aim)
        {
            case 1: AimX = 0f; AimY = -1f; break;
            case 2: AimX = 0f; AimY = 1f; break;
            case 3: AimX = f * s; AimY = -s; break;
            case 4: AimX = f * s; AimY = s; break;
            default: AimX = f; AimY = 0f; break;
        }
        float bx = X + f * 2f;
        float by = Y - (Crouching ? 10f : 20f);
        float barrel = 13f;
        MuzzleX = bx + AimX * barrel;
        MuzzleY = by + AimY * barrel;
    }
}
