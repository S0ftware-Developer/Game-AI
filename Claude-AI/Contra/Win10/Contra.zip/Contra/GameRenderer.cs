using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace Contra;

/// <summary>
/// Draws everything on a small 480 x 270 pixel canvas with hard edges (the 8-bit look) and presents it scaled up by two with
/// nearest-neighbour filtering; the copyright footer is drawn afterwards at full resolution below the canvas.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    private const int VW = GameConfig.ViewW;
    private const int VH = GameConfig.ViewH;
    private const int S = GameConfig.PixelScale;

    // the keyboard- and mouse-selectable items, in canvas coordinates (the form scales them)
    private static Rectangle ItemRect(int baseY, int i)
    {
        return new Rectangle(150, baseY + i * 24, 180, 20);
    }

    public static Rectangle[] RectsFor(GameState state)
    {
        Rectangle[] r;
        switch (state)
        {
            case GameState.Menu:
                r = new Rectangle[3];
                for (int i = 0; i < 3; i++) r[i] = ItemRect(166, i);
                break;
            case GameState.Paused:
                r = new Rectangle[4];
                for (int i = 0; i < 4; i++) r[i] = ItemRect(104, i);
                break;
            case GameState.GameOver:
            case GameState.Victory:
                r = new Rectangle[2];
                for (int i = 0; i < 2; i++) r[i] = ItemRect(168, i);
                break;
            case GameState.Controls:
                r = new Rectangle[1];
                r[0] = ItemRect(232, 0);
                break;
            default:
                return new Rectangle[0];
        }
        for (int i = 0; i < r.Length; i++) r[i] = new Rectangle(r[i].X * S, r[i].Y * S, r[i].Width * S, r[i].Height * S);
        return r;
    }

    private readonly Bitmap canvas = new Bitmap(VW, VH, PixelFormat.Format32bppPArgb);
    private readonly Graphics gc;
    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly BackgroundRenderer bg = new BackgroundRenderer();
    private readonly Sprites sprites = new Sprites();
    private readonly Font fSmall;
    private readonly Font fMid;
    private readonly Font fBig;
    private readonly Font fTitleC;
    private readonly Font fTitle;
    private readonly Font fSub;
    private readonly Font fFooter;
    private readonly StringFormat sfTight = new StringFormat(StringFormat.GenericTypographic);
    private readonly StringFormat sfCenter = new StringFormat();
    private readonly StringFormat sfRight = new StringFormat();
    private readonly StringFormat sfLeft = new StringFormat();
    private readonly StringFormat sfFooter = new StringFormat();

    // the animated title scene
    private readonly Level menuLevel = Level.Build();
    private readonly Player menuHero = new Player();
    private readonly Player menuHero2 = new Player();
    private readonly Enemy[] menuEnemies = new Enemy[3];
    private readonly Barrel[] menuBarrels = new Barrel[2];
    private readonly Projectile[] menuShots = new Projectile[10];
    private readonly Explosion menuExp = new Explosion();

    public GameRenderer()
    {
        gc = Graphics.FromImage(canvas);
        gc.SmoothingMode = SmoothingMode.None;
        gc.InterpolationMode = InterpolationMode.NearestNeighbor;
        gc.PixelOffsetMode = PixelOffsetMode.Half;
        gc.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
        gc.CompositingQuality = CompositingQuality.HighSpeed;

        fSmall = new Font("Consolas", 9f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Consolas", 12f, FontStyle.Bold, GraphicsUnit.Pixel);
        fBig = new Font("Consolas", 22f, FontStyle.Bold, GraphicsUnit.Pixel);
        fTitleC = new Font("Impact", 78f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitle = new Font("Impact", 54f, FontStyle.Regular, GraphicsUnit.Pixel);
        fSub = new Font("Consolas", 16f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfTight.FormatFlags |= StringFormatFlags.NoWrap;
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfFooter.Alignment = StringAlignment.Center;
        sfFooter.LineAlignment = StringAlignment.Center;

        Random rnd = new Random(5);
        menuHero.Facing = 1;
        menuHero.Grounded = true;
        menuHero2.Facing = 1;
        menuHero2.Grounded = true;
        menuHero.Weapon.Current = WeaponType.Spread;
        EnemyType[] types = { EnemyType.Infantry, EnemyType.Heavy, EnemyType.Rifleman };
        for (int i = 0; i < menuEnemies.Length; i++)
        {
            Enemy e = new Enemy();
            EnemySpawn s = new EnemySpawn();
            s.Type = types[i]; s.X = 0f; s.Y = GameConfig.GroundY; s.Min = 0f; s.Max = 0f;
            e.Init(s, rnd);
            e.Active = true;
            e.Facing = -1;
            e.Grounded = true;
            menuEnemies[i] = e;
        }
        for (int i = 0; i < menuBarrels.Length; i++)
        {
            Barrel b = new Barrel();
            b.Y = GameConfig.GroundY;
            b.Ammo = i == 1;
            menuBarrels[i] = b;
        }
        for (int i = 0; i < menuShots.Length; i++)
        {
            Projectile p = new Projectile();
            p.Kind = i % 2 == 0 ? ShotKind.Machine : ShotKind.Spread;
            p.VX = 280f;
            menuShots[i] = p;
        }
        menuExp.Kind = ExplosionKind.Large;
        menuExp.Size = 28f;
        menuExp.Duration = 0.9f;
    }

    public void Dispose()
    {
        gc.Dispose();
        canvas.Dispose();
        tmp.Dispose();
        bg.Dispose();
        sprites.Dispose();
        fSmall.Dispose();
        fMid.Dispose();
        fBig.Dispose();
        fTitleC.Dispose();
        fTitle.Dispose();
        fSub.Dispose();
        fFooter.Dispose();
        sfTight.Dispose();
        sfCenter.Dispose();
        sfRight.Dispose();
        sfLeft.Dispose();
        sfFooter.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private void Rect(Color c, int x, int y, int w, int h)
    {
        gc.FillRectangle(B(c), x, y, w, h);
    }

    /// <summary>Pixel text with a one-pixel shadow; align 0 left, 1 centre, 2 right.</summary>
    private void Txt(string s, Font f, Color c, int x, int y, int align, bool shadow = true)
    {
        StringFormat sf = align == 0 ? sfLeft : (align == 1 ? sfCenter : sfRight);
        if (shadow) gc.DrawString(s, f, B(Color.FromArgb(255, 16, 10, 24)), x + 1, y + 1, sf);
        gc.DrawString(s, f, B(c), x, y, sf);
    }

    private void Panel(int x, int y, int w, int h, int alpha)
    {
        Rect(Color.FromArgb(alpha, 12, 12, 24), x, y, w, h);
        Rect(Color.FromArgb(255, 230, 180, 60), x, y, w, 1);
        Rect(Color.FromArgb(255, 230, 180, 60), x, y + h - 1, w, 1);
        Rect(Color.FromArgb(255, 230, 180, 60), x, y, 1, h);
        Rect(Color.FromArgb(255, 230, 180, 60), x + w - 1, y, 1, h);
    }

    private static string FormatTime(float seconds)
    {
        int total = (int)seconds;
        return (total / 60).ToString("D2") + ":" + (total % 60).ToString("D2");
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        // 1. the pixel canvas
        gc.Clear(Color.Black);
        switch (e.State)
        {
            case GameState.Menu: DrawMenu(e); break;
            case GameState.Controls: DrawControls(e); break;
            default:
                DrawGame(e);
                if (e.State == GameState.Paused) DrawPause(e);
                else if (e.State == GameState.GameOver) DrawEnd(e, false);
                else if (e.State == GameState.Victory) DrawEnd(e, true);
                break;
        }

        // 2. present it scaled with nearest-neighbour filtering, then the footer at full resolution
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;
        float scale = Math.Min(clientW / (float)GameConfig.LogicalW, clientH / (float)GameConfig.LogicalH);
        float offX = (clientW - GameConfig.LogicalW * scale) / 2f;
        float offY = (clientH - GameConfig.LogicalH * scale) / 2f;
        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.SmoothingMode = SmoothingMode.None;
            g.DrawImage(canvas, new Rectangle(0, 0, VW * S, VH * S), 0, 0, VW, VH, GraphicsUnit.Pixel);

            Rectangle foot = new Rectangle(0, VH * S, GameConfig.LogicalW, GameConfig.FooterH);
            using (SolidBrush b = new SolidBrush(Color.FromArgb(255, 14, 12, 22)))
            using (SolidBrush y = new SolidBrush(Color.FromArgb(255, 230, 180, 60)))
            using (SolidBrush t = new SolidBrush(Color.FromArgb(255, 240, 236, 220)))
            {
                g.FillRectangle(b, foot);
                g.FillRectangle(y, 0, foot.Y, GameConfig.LogicalW, 2);
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                g.DrawString(FooterText, fFooter, t, new RectangleF(0f, foot.Y + 3f, GameConfig.LogicalW, foot.Height - 3f), sfFooter);
            }
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ the battlefield

    private void DrawGame(GameEngine e)
    {
        int camX = (int)Math.Round(e.Camera.X);
        int shx = 0;
        int shy = 0;
        if (e.Camera.Shake > 0f)
        {
            shx = (int)Math.Round(Math.Sin(e.Clock * 140f) * e.Camera.Shake * 8f);
            shy = (int)Math.Round(Math.Cos(e.Clock * 120f) * e.Camera.Shake * 6f);
        }
        bg.DrawSky(gc, camX, e.Clock);
        GraphicsState outer = gc.Save();
        gc.TranslateTransform(shx, shy);
        bg.DrawWorld(gc, e.Level, camX, e.Clock);

        GraphicsState actors = gc.Save();
        gc.TranslateTransform(-camX, 0);
        float x0 = camX - 60f;
        float x1 = camX + VW + 60f;
        foreach (Barrel b in e.Barrels.Items)
        {
            if (b.X > x0 && b.X < x1) sprites.DrawBarrel(gc, b, e.Clock);
        }
        foreach (Pickup p in e.Pickups.Items)
        {
            if (p.X > x0 && p.X < x1) sprites.DrawPickup(gc, p, e.Clock);
        }
        foreach (Enemy en in e.Enemies.Enemies)
        {
            if (en.Active && en.X > x0 && en.X < x1) sprites.DrawEnemy(gc, en, e.Clock);
        }
        if (e.Boss.Active) sprites.DrawBoss(gc, e.Boss, e.Clock);
        sprites.DrawPlayer(gc, e.Player, e.Clock);
        foreach (Projectile pr in e.Shots.Items) sprites.DrawProjectile(gc, pr);
        foreach (Grenade gr in e.Grenades.Items) sprites.DrawGrenade(gc, gr, e.Clock);
        foreach (Explosion ex in e.Explosions.Items) sprites.DrawExplosion(gc, ex);
        sprites.DrawParticles(gc, e.Particles);
        gc.Restore(actors);
        gc.Restore(outer);

        if (e.Flash > 0f) Rect(Color.FromArgb((int)Math.Min(120f, 240f * e.Flash), 255, 240, 200), 0, 0, VW, VH);
        DrawHud(e);
    }

    private void DrawHud(GameEngine e)
    {
        Player pl = e.Player;
        Rect(Color.FromArgb(140, 8, 8, 20), 0, 0, VW, 26);
        Rect(Color.FromArgb(255, 230, 180, 60), 0, 26, VW, 1);

        // score, lives and health
        Txt("1P", fSmall, Color.FromArgb(255, 255, 210, 80), 6, 7, 0);
        Txt(e.Score.ToString("D7"), fMid, Color.White, 22, 7, 0);
        for (int i = 0; i < Math.Min(pl.Lives, 6); i++)
        {
            Rect(Color.FromArgb(255, 238, 190, 140), 6 + i * 9, 15, 6, 6);
            Rect(Color.FromArgb(255, 226, 44, 48), 6 + i * 9, 17, 6, 2);
        }
        if (pl.Lives > 6) Txt("+" + (pl.Lives - 6), fSmall, Color.White, 6 + 6 * 9, 18, 0);
        for (int i = 0; i < GameConfig.StartHealth; i++)
        {
            bool full = i < pl.Hp;
            Rect(full ? Color.FromArgb(255, 240, 60, 60) : Color.FromArgb(255, 90, 40, 40), 84 + i * 9, 17, 7, 5);
            Rect(full ? Color.FromArgb(255, 255, 160, 150) : Color.FromArgb(255, 60, 30, 30), 84 + i * 9, 17, 7, 1);
        }

        // the weapon box
        WeaponSystem w = pl.Weapon;
        Color wc;
        switch (w.Current)
        {
            case WeaponType.Spread: wc = Color.FromArgb(255, 240, 80, 110); break;
            case WeaponType.Laser: wc = Color.FromArgb(255, 90, 220, 255); break;
            case WeaponType.Fire: wc = Color.FromArgb(255, 255, 160, 50); break;
            default: wc = Color.FromArgb(255, 255, 230, 120); break;
        }
        Rect(Color.FromArgb(255, 20, 20, 36), 150, 3, 150, 20);
        Rect(wc, 150, 3, 150, 1);
        Rect(wc, 150, 22, 150, 1);
        Rect(wc, 154, 8, 8, 8);
        Rect(Color.FromArgb(255, 20, 20, 36), 156, 10, 4, 4);
        Txt(((int)w.Current + 1) + " " + w.Name, fSmall, wc, 168, 8, 0);
        Txt(w.CurrentAmmo < 0 ? "AMMO  INF" : "AMMO  " + w.CurrentAmmo.ToString("D2"), fSmall, Color.White, 168, 17, 0);
        // grenades
        Rect(Color.FromArgb(255, 84, 120, 60), 238, 14, 5, 6);
        Rect(Color.FromArgb(255, 190, 194, 200), 239, 12, 3, 2);
        Txt("x" + pl.Grenades, fMid, Color.White, 247, 14, 0);
        Txt("BEST " + e.Scores.Best.ToString("D7"), fSmall, Color.FromArgb(255, 255, 224, 100), VW - 6, 8, 2);
        Txt("TIME " + FormatTime(e.PlayTime), fSmall, Color.White, VW - 6, 18, 2);

        // the boss health bar
        if (e.Boss.Active)
        {
            Txt("BOSS", fSmall, Color.FromArgb(255, 255, 160, 120), VW / 2 - 94, VH - 12, 0);
            Rect(Color.FromArgb(255, 20, 12, 12), VW / 2 - 70, VH - 16, 160, 8);
            Rect(e.Boss.HitFlash > 0f ? Color.White : Color.FromArgb(255, 226, 44, 40), VW / 2 - 69, VH - 15, (int)(158f * e.Boss.HealthFraction), 6);
            Rect(Color.FromArgb(255, 230, 180, 60), VW / 2 - 70, VH - 16, 160, 1);
            Rect(Color.FromArgb(255, 230, 180, 60), VW / 2 - 70, VH - 9, 160, 1);
            Rect(Color.White, VW / 2 + 10, VH - 16, 1, 8);
        }

        // notifications and banners
        if (e.NoteTimer > 0f && e.Note.Length > 0)
        {
            int a = (int)Math.Min(255f, e.NoteTimer * 380f);
            Txt(e.Note, fMid, Color.FromArgb(a, 255, 244, 150), VW / 2, 40, 1);
        }
        if (e.BannerTimer > 0f && e.Banner.Length > 0)
        {
            bool warn = e.Banner.StartsWith("WARNING");
            bool blink = !warn || ((int)(e.Clock * 6f) & 1) == 0;
            Txt(e.Banner, fBig, warn ? (blink ? Color.FromArgb(255, 255, 70, 60) : Color.White) : Color.White, VW / 2, 90, 1);
        }
        if (pl.Dead && pl.Lives > 0) Txt("GET READY", fMid, Color.White, VW / 2, 110, 1);
    }

    // ------------------------------------------------------------------ the title screen

    private void DrawMenu(GameEngine e)
    {
        float clock = e.Clock;
        int camX = (int)Math.Round(1900f + (clock * 24f) % 700f);
        bg.DrawSky(gc, camX, clock);
        GraphicsState outer = gc.Save();
        bg.DrawWorld(gc, menuLevel, camX, clock);

        GraphicsState actors = gc.Save();
        gc.TranslateTransform(-camX, 0);
        // enemies on the right, barrels and an explosion between
        for (int i = 0; i < menuEnemies.Length; i++)
        {
            Enemy en = menuEnemies[i];
            en.X = camX + 380f + i * 34f;
            en.Y = GameConfig.GroundY;
            en.ShootAnim = ((int)(clock * 4f + i) & 3) == 0 ? 0.2f : 0f;
            en.Walk = clock * 3f;
            sprites.DrawEnemy(gc, en, clock);
        }
        for (int i = 0; i < menuBarrels.Length; i++)
        {
            menuBarrels[i].X = camX + 300f + i * 22f;
            sprites.DrawBarrel(gc, menuBarrels[i], clock);
        }
        float ea = clock % 2.8f;
        if (ea < menuExp.Duration)
        {
            menuExp.X = camX + 330f;
            menuExp.Y = GameConfig.GroundY - 10f;
            menuExp.Age = ea;
            sprites.DrawExplosion(gc, menuExp);
        }

        // two commandos running and firing
        Player[] heroes = { menuHero, menuHero2 };
        for (int i = 0; i < 2; i++)
        {
            Player h = heroes[i];
            h.X = camX + 70f + i * 56f;
            h.Y = GameConfig.GroundY;
            h.VX = 70f;
            h.RunPhase = clock * 8f + i * 2f;
            h.Invuln = 0f;
            h.ShootAnim = 0.1f;
            h.Aim = 0;
            sprites.DrawPlayer(gc, h, clock);
        }
        for (int i = 0; i < menuShots.Length; i++)
        {
            Projectile p = menuShots[i];
            p.X = camX + 130f + ((clock * 210f + i * 24f) % 230f);
            p.Y = GameConfig.GroundY - 21f + (i % 2 == 0 ? 0f : 0f);
            sprites.DrawProjectile(gc, p);
        }
        gc.Restore(actors);
        gc.Restore(outer);
        sprites.DrawHelicopter(gc, 30 + (int)((clock * 14f) % 420f), 36 + (int)(Math.Sin(clock * 1.2) * 4), clock);

        DrawTitle(clock);

        string[] items = { "START GAME", "CONTROLS", "EXIT" };
        for (int i = 0; i < 3; i++)
        {
            Rectangle r = ItemRect(166, i);
            bool sel = e.MenuIndex == i;
            if (sel) Rect(Color.FromArgb(170, 12, 12, 24), r.X - 4, r.Y - 1, r.Width + 8, r.Height + 2);
            Txt(items[i], fMid, sel ? Color.FromArgb(255, 255, 230, 90) : Color.White, VW / 2, r.Y + 10, 1);
            if (sel && ((int)(clock * 4f) & 1) == 0)
            {
                Rect(Color.FromArgb(255, 255, 230, 90), r.X + 8, r.Y + 6, 6, 8);
                Rect(Color.FromArgb(255, 255, 230, 90), r.Right - 14, r.Y + 6, 6, 8);
            }
        }
        Txt("W / S + ENTER", fSmall, Color.FromArgb(255, 220, 230, 250), VW / 2, 240, 1);
        Txt("BEST SCORE  " + e.Scores.Best.ToString("D7"), fSmall, Color.FromArgb(255, 255, 224, 100), VW / 2, 252, 1);
    }

    private void DrawTitle(float clock)
    {
        // the flaming C and the chrome ONTRA with a red outline
        SizeF sc = gc.MeasureString("C", fTitleC, 400, sfTight);
        SizeF so = gc.MeasureString("ONTRA", fTitle, 800, sfTight);
        float total = sc.Width + so.Width + 4f;
        float x0 = (VW - total) / 2f;
        float yC = 18f;
        float yO = 34f;

        // flames licking around the C
        for (int i = 0; i < 14; i++)
        {
            float a = -2.6f + i * 0.42f;
            float fl = 5f + (float)Math.Sin(clock * 9f + i * 1.7) * 3f;
            float cx = x0 + sc.Width * 0.5f + (float)Math.Cos(a) * (sc.Width * 0.62f + fl);
            float cy = yC + sc.Height * 0.5f + (float)Math.Sin(a) * (sc.Height * 0.46f + fl);
            Rect(Color.FromArgb(255, 255, 120, 30), (int)cx - 3, (int)cy - 3, 6, 6);
            Rect(Color.FromArgb(255, 255, 220, 80), (int)cx - 1, (int)cy - 1, 3, 3);
        }

        using (LinearGradientBrush fire = new LinearGradientBrush(new RectangleF(x0, yC, sc.Width, sc.Height), Color.FromArgb(255, 255, 240, 100), Color.FromArgb(255, 230, 50, 20), 90f))
        {
            for (int dx = -2; dx <= 2; dx++)
            {
                for (int dy = -2; dy <= 2; dy++)
                {
                    if (dx == 0 && dy == 0) continue;
                    gc.DrawString("C", fTitleC, B(Color.FromArgb(255, 110, 20, 10)), x0 + dx, yC + dy, sfTight);
                }
            }
            gc.DrawString("C", fTitleC, fire, x0, yC, sfTight);
        }

        float ox = x0 + sc.Width + 4f;
        gc.DrawString("ONTRA", fTitle, B(Color.FromArgb(255, 20, 10, 50)), ox + 3, yO + 3, sfTight);
        for (int dx = -2; dx <= 2; dx++)
        {
            for (int dy = -2; dy <= 2; dy++)
            {
                if (dx == 0 && dy == 0) continue;
                gc.DrawString("ONTRA", fTitle, B(Color.FromArgb(255, 200, 30, 30)), ox + dx, yO + dy, sfTight);
            }
        }
        using (LinearGradientBrush chrome = new LinearGradientBrush(new RectangleF(ox, yO, so.Width, so.Height), Color.White, Color.FromArgb(255, 80, 90, 120), 90f))
        {
            ColorBlend cb = new ColorBlend(5);
            cb.Positions = new[] { 0f, 0.35f, 0.5f, 0.52f, 1f };
            cb.Colors = new[] { Color.FromArgb(255, 250, 252, 255), Color.FromArgb(255, 170, 180, 205), Color.FromArgb(255, 70, 80, 110), Color.FromArgb(255, 150, 162, 190), Color.FromArgb(255, 230, 236, 250) };
            chrome.InterpolationColors = cb;
            gc.DrawString("ONTRA", fTitle, chrome, ox, yO, sfTight);
        }
        Txt("RUN AND GUN", fSub, Color.White, VW / 2, 126, 1);
        Rect(Color.FromArgb(255, 90, 170, 255), VW / 2 - 150, 128, 50, 2);
        Rect(Color.FromArgb(255, 90, 170, 255), VW / 2 + 100, 128, 50, 2);
    }

    private void DrawControls(GameEngine e)
    {
        bg.DrawSky(gc, 2000f + e.Clock * 10f, e.Clock);
        Rect(Color.FromArgb(150, 8, 8, 20), 0, 0, VW, VH);
        Panel(40, 20, VW - 80, 224, 235);
        Txt("CONTROLS", fBig, Color.FromArgb(255, 255, 220, 80), VW / 2, 38, 1);
        string[,] rows =
        {
            { "A / LEFT ARROW", "MOVE LEFT" },
            { "D / RIGHT ARROW", "MOVE RIGHT" },
            { "SPACE", "JUMP (HOLD FOR HIGHER)" },
            { "W / UP ARROW", "AIM UP (WITH A / D: DIAGONAL)" },
            { "S / DOWN ARROW", "CROUCH / AIM DOWN (WITH A / D: DIAGONAL)" },
            { "J / CTRL", "SHOOT" },
            { "K / X", "THROW GRENADE" },
            { "1  2  3  4", "MACHINE / SPREAD / LASER / FIRE" },
            { "ESC", "PAUSE" }
        };
        for (int i = 0; i < rows.GetLength(0); i++)
        {
            Txt(rows[i, 0], fSmall, Color.FromArgb(255, 255, 230, 120), 64, 66 + i * 16, 0);
            Txt(rows[i, 1], fSmall, Color.White, 190, 66 + i * 16, 0);
        }
        Txt("Weapon capsules refill ammunition. The machine gun never runs out.", fSmall, Color.FromArgb(255, 200, 220, 255), VW / 2, 218, 1);
        Rectangle r = ItemRect(232, 0);
        Rect(Color.FromArgb(170, 12, 12, 24), r.X - 4, r.Y - 1, r.Width + 8, r.Height + 2);
        Txt("BACK  [ENTER]", fMid, Color.FromArgb(255, 255, 230, 90), VW / 2, r.Y + 10, 1);
    }

    // ------------------------------------------------------------------ overlays

    private void MenuItems(string[] labels, int baseY, int selected, float clock)
    {
        for (int i = 0; i < labels.Length; i++)
        {
            Rectangle r = ItemRect(baseY, i);
            bool sel = selected == i;
            if (sel) Rect(Color.FromArgb(200, 12, 12, 24), r.X - 4, r.Y - 1, r.Width + 8, r.Height + 2);
            Txt(labels[i], fMid, sel ? Color.FromArgb(255, 255, 230, 90) : Color.White, VW / 2, r.Y + 10, 1);
            if (sel && ((int)(clock * 4f) & 1) == 0)
            {
                Rect(Color.FromArgb(255, 255, 230, 90), r.X + 8, r.Y + 6, 6, 8);
                Rect(Color.FromArgb(255, 255, 230, 90), r.Right - 14, r.Y + 6, 6, 8);
            }
        }
    }

    private void DrawPause(GameEngine e)
    {
        Rect(Color.FromArgb(170, 6, 6, 16), 0, 0, VW, VH);
        Panel(130, 54, 220, 150, 235);
        Txt("PAUSED", fBig, Color.White, VW / 2, 78, 1);
        string[] labels = { "RESUME", "RESTART", "SOUND: " + (Sfx.Muted ? "OFF" : "ON"), "MAIN MENU" };
        MenuItems(labels, 104, e.PauseIndex, e.Clock);
    }

    private void DrawEnd(GameEngine e, bool victory)
    {
        Rect(Color.FromArgb(180, 6, 6, 16), 0, 0, VW, VH);
        Panel(110, 30, 260, 200, 240);
        if (victory)
        {
            Txt("MISSION COMPLETE", fBig, Color.FromArgb(255, 255, 224, 80), VW / 2, 54, 1);
            Txt("BOSS DESTROYED", fMid, Color.FromArgb(255, 120, 255, 160), VW / 2, 78, 1);
        }
        else
        {
            Txt("GAME OVER", fBig, Color.FromArgb(255, 255, 80, 70), VW / 2, 60, 1);
        }
        int y = victory ? 100 : 92;
        Txt("SCORE  " + e.Score.ToString("D7"), fMid, Color.White, VW / 2, y, 1);
        Txt("BEST   " + e.Scores.Best.ToString("D7"), fMid, Color.FromArgb(255, 255, 224, 100), VW / 2, y + 16, 1);
        if (e.NewRecord) Txt("NEW RECORD!", fSmall, Color.FromArgb(255, 255, 230, 90), VW / 2, y + 32, 1);
        if (victory) Txt("TIME " + FormatTime(e.PlayTime) + "   ENEMIES " + e.Kills, fSmall, Color.White, VW / 2, y + 44, 1);
        MenuItems(new[] { "RESTART", "MAIN MENU" }, 168, e.EndIndex, e.Clock);
    }
}
