namespace Contra;

/// <summary>A thrown grenade following a ballistic arc; it bounces and explodes when its fuse runs out.</summary>
public sealed class Grenade
{
    public float X, Y, VX, VY, Fuse, Rot;
    public bool FromPlayer;
}

public sealed class GrenadeManager
{
    public readonly List<Grenade> Items = new List<Grenade>(16);
    public readonly List<Grenade> Exploded = new List<Grenade>(8);     // grenades that blew up this step

    public void Clear()
    {
        Items.Clear();
        Exploded.Clear();
    }

    public void Throw(float x, float y, float vx, float vy, bool fromPlayer)
    {
        Grenade g = new Grenade();
        g.X = x; g.Y = y; g.VX = vx; g.VY = vy;
        g.FromPlayer = fromPlayer;
        g.Fuse = fromPlayer ? GameConfig.GrenadeFuse : 1.25f;
        Items.Add(g);
    }

    public void Update(float dt, Level level)
    {
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Grenade g = Items[i];
            g.VY += 520f * dt;
            float vxBefore = g.VX;
            float vyBefore = g.VY;
            float x = g.X;
            float y = g.Y + 2f;               // the bottom of the little body
            float vx = g.VX;
            float vy = g.VY;
            CollisionManager.MoveBody(level, ref x, ref y, ref vx, ref vy, 2f, 4f, dt);
            g.X = x;
            g.Y = y - 2f;
            g.VX = vx;
            g.VY = vy;
            if (vyBefore > 40f && vy == 0f)
            {
                g.VY = -vyBefore * 0.4f;      // bounce off the ground
                g.VX = vxBefore * 0.65f;
                if (Math.Abs(g.VY) < 25f) g.VY = 0f;
            }
            else if (Math.Abs(vxBefore) > 1f && vx == 0f)
            {
                g.VX = -vxBefore * 0.5f;      // bounce off a wall
            }
            g.Rot += (g.VX > 0f ? 1f : -1f) * 8f * dt;
            g.Fuse -= dt;
            if (g.Fuse <= 0f || g.Y > GameConfig.ViewH + 30f)
            {
                Exploded.Add(g);
                Items.RemoveAt(i);
            }
        }
    }
}
