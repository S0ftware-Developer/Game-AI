namespace Contra;

/// <summary>Owns all enemies: creates them from the level once (there is no endless spawning) and wakes them up when the camera nears.</summary>
public sealed class EnemyManager
{
    public readonly List<Enemy> Enemies = new List<Enemy>(64);
    public Action<Enemy>? Killed;
    private readonly Random rng = new Random();

    public void Reset(Level level)
    {
        Enemies.Clear();
        foreach (EnemySpawn s in level.Enemies)
        {
            Enemy e = new Enemy();
            e.Init(s, rng);
            Enemies.Add(e);
        }
    }

    public void Update(float dt, float camLeft, float camRight, float tx, float ty, Level level, ProjectileManager shots, GrenadeManager grenades, out bool fired, out bool threw)
    {
        fired = false;
        threw = false;
        for (int i = Enemies.Count - 1; i >= 0; i--)
        {
            Enemy e = Enemies[i];
            if (!e.Active && e.X < camRight + 40f && e.X > camLeft - 140f) e.Active = true;
            if (!e.Active) continue;
            bool visible = e.X > camLeft - 10f && e.X < camRight + 10f;
            bool f, t;
            e.Update(dt, tx, ty, visible, level, shots, grenades, rng, out f, out t);
            if (f) fired = true;
            if (t) threw = true;
            if ((e.Dying && e.DeathTimer <= 0f) || e.Y > GameConfig.ViewH + 60f || (e.X < camLeft - 200f && e.Type != EnemyType.Turret)) Enemies.RemoveAt(i);
        }
    }

    public void Damage(Enemy e, float amount)
    {
        if (!e.Hittable) return;
        e.Damage(amount);
        if (e.Hp <= 0f)
        {
            e.StartDying();
            Killed?.Invoke(e);
        }
    }
}
