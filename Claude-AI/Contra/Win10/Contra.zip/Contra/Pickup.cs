namespace Contra;

public enum PickupType { Spread, Laser, Fire, Grenades, Life, Health }

/// <summary>A weapon capsule or supply item lying on the battlefield.</summary>
public sealed class Pickup
{
    public float X, Y;                    // Y is the bottom of the item
    public float Age;
    public PickupType Type;
    public bool Alive = true;

    public const float HalfW = 8f;
    public const float Size = 14f;

    public static string Label(PickupType t)
    {
        switch (t)
        {
            case PickupType.Spread: return "SPREAD GUN!";
            case PickupType.Laser: return "LASER GUN!";
            case PickupType.Fire: return "FIRE GUN!";
            case PickupType.Grenades: return "GRENADES +2";
            case PickupType.Life: return "EXTRA LIFE!";
            default: return "HEALTH +1";
        }
    }
}

public sealed class PickupManager
{
    public readonly List<Pickup> Items = new List<Pickup>(32);

    public void Reset(Level level)
    {
        Items.Clear();
        foreach (PickupSpawn s in level.Pickups)
        {
            Pickup p = new Pickup();
            p.X = s.X;
            p.Y = s.Y;
            p.Type = s.Type;
            Items.Add(p);
        }
    }

    public void Update(float dt)
    {
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Pickup p = Items[i];
            p.Age += dt;
            if (!p.Alive) Items.RemoveAt(i);
        }
    }
}
