namespace AirCombat;

public enum ShotKind { PlayerBullet, EnemySmall, EnemyHeavy, Missile, BossOrb }

/// <summary>A bullet or missile. Instances are pooled by <see cref="ProjectileManager"/>.</summary>
public sealed class Projectile
{
    public float X, Y, VX, VY, AX, AY;
    public float Radius;
    public float Damage;
    public float Age;
    public ShotKind Kind;
    public bool Alive;

    public float Angle
    {
        get { return MathF.Atan2(VX, -VY); }     // 0 = pointing up
    }
}
