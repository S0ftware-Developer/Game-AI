namespace AirCombat;

public enum BonusType { Weapon, Life, Score, Shield, Bomb }

/// <summary>A falling collectible.</summary>
public sealed class Bonus
{
    public float X, Y, Age, BaseX;
    public BonusType Type;
    public bool Alive;
    public const float Radius = 17f;

    public static string Label(BonusType t)
    {
        switch (t)
        {
            case BonusType.Weapon: return "WEAPON UP!";
            case BonusType.Life: return "EXTRA LIFE!";
            case BonusType.Score: return "+" + GameConfig.ScoreBonusItem;
            case BonusType.Shield: return "SHIELD!";
            default: return "BOMB!";
        }
    }
}
