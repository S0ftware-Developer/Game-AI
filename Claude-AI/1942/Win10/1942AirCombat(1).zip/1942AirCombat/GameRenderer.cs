using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace AirCombat;

/// <summary>
/// Draws the whole screen in logical 640x800 coordinates scaled to the window: the scrolling battlefield (through
/// <see cref="BackgroundRenderer"/>), all sprites (through <see cref="Sprites"/>), the HUD and the menu screens.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    public static readonly Rectangle PlayButton = new Rectangle(170, 556, 300, 54);
    public static readonly Rectangle ResumeButton = new Rectangle(200, 300, 240, 46);
    public static readonly Rectangle PauseRestartButton = new Rectangle(200, 356, 240, 46);
    public static readonly Rectangle PauseMenuButton = new Rectangle(200, 412, 240, 46);
    public static readonly Rectangle EndRestartButton = new Rectangle(70, 530, 230, 52);
    public static readonly Rectangle EndMenuButton = new Rectangle(340, 530, 230, 52);

    private const int W = GameConfig.LogicalW;
    private const int ViewH = GameConfig.ViewH;

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly BackgroundRenderer bg = new BackgroundRenderer();
    private readonly Sprites sprites = new Sprites();
    private readonly Font fHud;
    private readonly Font fLabel;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fBig;
    private readonly Font fFooter;
    private readonly Font fTitle;
    private readonly Font fSub;
    private readonly Font fBanner;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;
    private readonly StringFormat sfRight;
    private readonly GraphicsPath titlePath;
    private readonly LinearGradientBrush titleFill;
    private readonly Projectile[] menuShots = new Projectile[8];
    private readonly PointF[] poly = new PointF[4];
    private readonly PointF[] tri3 = new PointF[3];

    public GameRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;

        fHud = new Font("Segoe UI", 22f, FontStyle.Bold, GraphicsUnit.Pixel);
        fLabel = new Font("Segoe UI", 11f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Segoe UI", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Segoe UI", 17f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBig = new Font("Segoe UI", 44f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitle = new Font("Impact", 190f, FontStyle.Regular, GraphicsUnit.Pixel);
        fSub = new Font("Impact", 44f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBanner = new Font("Impact", 58f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;
        sfRight = new StringFormat();
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfRight.FormatFlags = StringFormatFlags.NoWrap;

        titlePath = new GraphicsPath();
        titlePath.AddString("1942", fTitle.FontFamily, (int)FontStyle.Regular, 190f, new PointF(0f, 0f), StringFormat.GenericTypographic);
        RectangleF b = titlePath.GetBounds();
        using (Matrix m = new Matrix())
        {
            m.Translate(W / 2f - (b.X + b.Width / 2f), 128f - (b.Y + b.Height / 2f));
            titlePath.Transform(m);
        }
        RectangleF tb = titlePath.GetBounds();
        titleFill = new LinearGradientBrush(new RectangleF(tb.X, tb.Y, tb.Width, tb.Height), Color.FromArgb(255, 255, 170, 50), Color.FromArgb(255, 205, 20, 24), 90f);

        for (int i = 0; i < menuShots.Length; i++)
        {
            Projectile p = new Projectile();
            p.Kind = ShotKind.PlayerBullet;
            p.VX = 0f;
            p.VY = -800f;
            menuShots[i] = p;
        }
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        bg.Dispose();
        sprites.Dispose();
        fHud.Dispose();
        fLabel.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fBig.Dispose();
        fFooter.Dispose();
        fTitle.Dispose();
        fSub.Dispose();
        fBanner.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        sfRight.Dispose();
        titlePath.Dispose();
        titleFill.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow) g.DrawString(s, f, B(Color.FromArgb(Math.Min((int)c.A, 200), 0, 0, 20)), x + 2f, y + 2f, sf);
        g.DrawString(s, f, B(c), x, y, sf);
    }

    private static GraphicsPath RoundRect(float x, float y, float w, float h, float r)
    {
        GraphicsPath p = new GraphicsPath();
        float d = r * 2f;
        p.AddArc(x, y, d, d, 180f, 90f);
        p.AddArc(x + w - d, y, d, d, 270f, 90f);
        p.AddArc(x + w - d, y + h - d, d, d, 0f, 90f);
        p.AddArc(x, y + h - d, d, d, 90f, 90f);
        p.CloseFigure();
        return p;
    }

    private void Panel(Graphics g, float x, float y, float w, float h, int alpha)
    {
        using (GraphicsPath p = RoundRect(x, y, w, h, 9f))
        {
            g.FillPath(B(Color.FromArgb(alpha, 8, 16, 40)), p);
            g.DrawPath(P(Color.FromArgb(255, 90, 140, 220), 2f), p);
        }
    }

    private void Button(Graphics g, Rectangle r, string text, bool primary, float clock)
    {
        using (GraphicsPath p = RoundRect(r.X, r.Y, r.Width, r.Height, 8f))
        {
            g.FillPath(B(primary ? Color.FromArgb(255, 12, 24, 58) : Color.FromArgb(255, 20, 30, 56)), p);
            float k = primary ? 0.5f + 0.5f * MathF.Sin(clock * 4f) : 1f;
            g.DrawPath(P(Color.FromArgb(A(170 + 85 * k), 220, 235, 255), 3f), p);
        }
        Txt(g, text, fText, Color.White, r.X + r.Width / 2f, r.Y + r.Height / 2f, sfCenter, true);
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)GameConfig.LogicalW, clientH / (float)GameConfig.LogicalH);
        float offX = (clientW - GameConfig.LogicalW * scale) / 2f;
        float offY = (clientH - GameConfig.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, GameConfig.LogicalW, GameConfig.LogicalH));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (e.State == GameState.Menu) DrawMenu(g, e);
            else
            {
                DrawGame(g, e);
                if (e.State == GameState.Paused) DrawPause(g, e);
                else if (e.State == GameState.GameOver) DrawEnd(g, e, false);
                else if (e.State == GameState.Victory) DrawEnd(g, e, true);
            }
            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ battlefield

    private void DrawGame(Graphics g, GameEngine e)
    {
        GraphicsState outer = g.Save();
        g.SetClip(new Rectangle(0, 0, W, ViewH));
        bg.Draw(g, e.Scroll, e.Clock);
        bg.DrawClouds(g, e.Scroll);

        if (e.Shake > 0f)
        {
            g.TranslateTransform(MathF.Sin(e.Clock * 150f) * e.Shake * 14f, MathF.Cos(e.Clock * 130f) * e.Shake * 12f);
        }

        foreach (Bonus b in e.Bonuses.Items) sprites.DrawBonus(g, b, e.Clock);

        foreach (EnemyAircraft en in e.Enemies.Enemies)
        {
            if (!en.Alive || en.Y < -90f || en.Y > ViewH + 90f) continue;
            sprites.DrawEnemy(g, en, e.Clock);
        }
        if (e.Boss.Active) sprites.DrawBoss(g, e.Boss, e.Clock);

        foreach (Projectile p in e.Shots.Player) sprites.DrawProjectile(g, p);
        sprites.DrawPlayer(g, e.Player, e.Clock);
        foreach (Projectile p in e.Shots.Enemy) sprites.DrawProjectile(g, p);
        foreach (Explosion x in e.Explosions.Items) sprites.DrawExplosion(g, x);
        sprites.DrawParticles(g, e.Particles);

        g.Restore(outer);

        if (e.Flash > 0f) g.FillRectangle(B(Color.FromArgb(A(140 * e.Flash / 0.5f), 255, 245, 210)), 0, 0, W, ViewH);
        DrawHud(g, e);
    }

    private void DrawBar(Graphics g, float x, float y, float w, float h, float fill, Color c)
    {
        g.FillRectangle(B(Color.FromArgb(200, 10, 14, 28)), x, y, w, h);
        if (fill > 0f) g.FillRectangle(B(c), x + 1f, y + 1f, (w - 2f) * Math.Min(1f, fill), h - 2f);
        g.DrawRectangle(P(Color.FromArgb(255, 150, 175, 215), 1.2f), x, y, w, h);
    }

    private void DrawHud(Graphics g, GameEngine e)
    {
        // top strip: score, best score, lives
        g.FillRectangle(B(Color.FromArgb(150, 6, 12, 30)), 0, 0, W, 46);
        g.FillRectangle(B(Color.FromArgb(255, 255, 200, 60)), 0, 46, W, 2);
        Txt(g, "SCORE", fLabel, Color.FromArgb(255, 150, 190, 255), 14f, 11f, sfLeft, false);
        Txt(g, e.Score.ToString("D7"), fHud, Color.White, 14f, 30f, sfLeft, true);
        Txt(g, "BEST", fLabel, Color.FromArgb(255, 150, 190, 255), W / 2f, 11f, sfCenter, false);
        Txt(g, Math.Max(e.Scores.Best, e.Score).ToString("D7"), fHud, Color.FromArgb(255, 255, 220, 90), W / 2f, 30f, sfCenter, true);
        Txt(g, "LIVES", fLabel, Color.FromArgb(255, 150, 190, 255), W - 14f, 11f, sfRight, false);
        int shown = Math.Min(e.Player.Lives, 6);
        for (int i = 0; i < shown; i++) sprites.DrawPlayerBody(g, W - 24f - i * 26f, 31f, 0f, 0f, e.Clock, false, 0.34f, 1f);
        if (e.Player.Lives <= 0) Txt(g, "0", fText, Color.FromArgb(255, 255, 110, 100), W - 24f, 31f, sfRight, true);
        else if (e.Player.Lives > 6) Txt(g, "+" + (e.Player.Lives - 6), fSmall, Color.White, W - 24f - 6 * 26f, 31f, sfRight, true);

        // stage progress
        float px = 14f;
        float pw = W - 28f;
        g.FillRectangle(B(Color.FromArgb(160, 6, 12, 30)), px, 54f, pw, 7f);
        g.FillRectangle(B(Color.FromArgb(230, 90, 200, 255)), px, 54f, pw * e.StageProgress, 7f);
        g.DrawRectangle(P(Color.FromArgb(200, 150, 175, 215), 1f), px, 54f, pw, 7f);
        float mx = px + pw * e.StageProgress;
        tri3[0] = new PointF(mx - 5f, 67f);
        tri3[1] = new PointF(mx + 5f, 67f);
        tri3[2] = new PointF(mx, 59f);
        g.FillPolygon(B(Color.White), tri3);
        g.FillEllipse(B(Color.FromArgb(255, 220, 50, 50)), px + pw - 5f, 52f, 11f, 11f);

        // boss health
        if (e.Boss.Active)
        {
            Txt(g, "THUNDER FORTRESS", fLabel, Color.FromArgb(255, 255, 140, 130), W / 2f, 76f, sfCenter, true);
            float bx = 90f;
            float bw = W - 180f;
            Color fc = e.Boss.HitFlash > 0f ? Color.FromArgb(255, 255, 255, 255) : Color.FromArgb(255, 226, 36, 36);
            DrawBar(g, bx, 86f, bw, 15f, e.Boss.HealthFraction, fc);
            g.DrawLine(P(Color.FromArgb(220, 255, 255, 255), 1.5f), bx + bw * 0.66f, 86f, bx + bw * 0.66f, 101f);
            g.DrawLine(P(Color.FromArgb(220, 255, 255, 255), 1.5f), bx + bw * 0.33f, 86f, bx + bw * 0.33f, 101f);
        }

        // bottom panel: weapon, roll, shield
        float py = ViewH - 52f;
        Panel(g, 8f, py, W - 16f, 44f, 150);
        Txt(g, "WEAPON", fLabel, Color.FromArgb(255, 150, 190, 255), 22f, py + 11f, sfLeft, false);
        for (int i = 0; i < 3; i++)
        {
            bool on = i < e.Player.WeaponLevel;
            g.FillRectangle(B(on ? Color.FromArgb(255, 255, 206, 60) : Color.FromArgb(150, 60, 70, 100)), 22f + i * 28f, py + 22f, 24f, 11f);
            g.DrawRectangle(P(Color.FromArgb(255, 20, 24, 40), 1f), 22f + i * 28f, py + 22f, 24f, 11f);
        }
        float ready = e.Player.RollReady;
        bool rollOk = ready >= 1f;
        Txt(g, rollOk ? "ROLL [X]  READY" : "ROLL [X]", fLabel, rollOk ? Color.FromArgb(255, 150, 255, 200) : Color.FromArgb(255, 150, 190, 255), 150f, py + 11f, sfLeft, false);
        DrawBar(g, 150f, py + 22f, 150f, 11f, ready, rollOk ? Color.FromArgb(255, 70, 220, 150) : Color.FromArgb(255, 240, 160, 50));
        float sh = e.Player.ShieldTimer / GameConfig.ShieldDuration;
        Txt(g, "SHIELD", fLabel, Color.FromArgb(255, 150, 190, 255), 330f, py + 11f, sfLeft, false);
        DrawBar(g, 330f, py + 22f, 120f, 11f, sh, Color.FromArgb(255, 80, 160, 255));
        Txt(g, "KILLS", fLabel, Color.FromArgb(255, 150, 190, 255), W - 24f, py + 11f, sfRight, false);
        Txt(g, e.Kills.ToString(), fText, Color.White, W - 24f, py + 28f, sfRight, true);

        // last collected bonus
        if (e.BonusTimer > 0f && e.BonusText.Length > 0)
        {
            float a = Math.Min(1f, e.BonusTimer * 1.5f);
            Txt(g, e.BonusText, fText, Color.FromArgb(A(255 * a), 255, 240, 160), W / 2f, py - 16f, sfCenter, true);
        }

        // banners
        if (e.BannerTimer > 0f && e.Banner.Length > 0)
        {
            float a = Math.Min(1f, e.BannerTimer * 1.5f);
            bool warn = e.Banner == "WARNING!";
            bool blink = !warn || ((int)(e.Clock * 6f) & 1) == 0;
            Color c = warn ? Color.FromArgb(A(255 * a), 255, blink ? 70 : 255, blink ? 60 : 255) : Color.FromArgb(A(255 * a), 255, 255, 255);
            Txt(g, e.Banner, fBanner, c, W / 2f, 300f, sfCenter, true);
            if (warn) Txt(g, "A HUGE ENEMY AIRCRAFT IS APPROACHING", fText, Color.FromArgb(A(255 * a), 255, 220, 200), W / 2f, 346f, sfCenter, true);
        }
    }

    // ------------------------------------------------------------------ menu

    private void DrawMenu(Graphics g, GameEngine e)
    {
        float clock = e.Clock;
        GraphicsState outer = g.Save();
        g.SetClip(new Rectangle(0, 0, W, ViewH));
        float menuScroll = 2200f + (clock * 80f) % 3300f;
        bg.Draw(g, menuScroll, clock);
        bg.DrawClouds(g, menuScroll);

        // enemy aircraft flying across the menu
        EnemyType[] types = { EnemyType.Fighter, EnemyType.Formation, EnemyType.Interceptor, EnemyType.Fighter, EnemyType.Bomber, EnemyType.Elite };
        for (int k = 0; k < types.Length; k++)
        {
            float x = (k * 131f + 70f + MathF.Sin(clock * 0.7f + k) * 60f) % W;
            float y = ((k * 150f + clock * (38f + k * 6f)) % (ViewH + 240f)) - 120f;
            float bank = MathF.Cos(clock * 0.7f + k) * 0.6f;
            sprites.DrawEnemyShape(g, types[k], x, y, bank, 0f, clock, 1f, true, 1f);
        }

        // the player's plane firing upward
        float bob = MathF.Sin(clock * 2f) * 8f;
        float py = 470f + bob;
        for (int i = 0; i < menuShots.Length; i++)
        {
            Projectile p = menuShots[i];
            float t = ((clock * 0.9f + i / (float)menuShots.Length) % 1f);
            p.X = W / 2f + ((i % 2 == 0) ? -10f : 10f);
            p.Y = py - 20f - t * 380f;
            sprites.DrawProjectile(g, p);
        }
        sprites.DrawPlayerBody(g, W / 2f, py, MathF.Sin(clock * 1.3f) * 0.3f, 0f, clock, ((int)(clock * 12f) & 1) == 0, 1.7f, 1f);
        g.Restore(outer);

        // title
        g.FillRectangle(B(Color.FromArgb(70, 4, 10, 40)), 0, 0, W, 370);
        DrawWings(g);
        g.DrawPath(P(Color.FromArgb(255, 10, 16, 56), 18f), titlePath);
        g.DrawPath(P(Color.FromArgb(255, 245, 248, 255), 8f), titlePath);
        g.FillPath(titleFill, titlePath);
        Txt(g, "AIR COMBAT", fSub, Color.FromArgb(255, 200, 232, 255), W / 2f, 330f, sfCenter, true);
        g.DrawLine(P(Color.FromArgb(255, 150, 220, 255), 4f), 70f, 330f, 190f, 330f);
        g.DrawLine(P(Color.FromArgb(255, 150, 220, 255), 4f), W - 70f, 330f, W - 190f, 330f);

        Button(g, PlayButton, "PLAY  [ENTER]", true, clock);
        Txt(g, "BEST SCORE  " + e.Scores.Best.ToString("D7"), fText, Color.FromArgb(255, 255, 224, 100), W / 2f, 636f, sfCenter, true);
        Txt(g, "W A S D / ARROWS - move        SPACE - fire (hold)        X / SHIFT - evasive roll", fSmall, Color.White, W / 2f, 668f, sfCenter, true);
        Txt(g, "ESC / P - pause        R - restart        N - sound        F11 - fullscreen", fSmall, Color.FromArgb(255, 210, 225, 250), W / 2f, 690f, sfCenter, true);
        Txt(g, "Collect bonuses: weapon, shield, bomb, extra life. Defeat the boss to win!", fSmall, Color.FromArgb(255, 210, 225, 250), W / 2f, 712f, sfCenter, true);
    }

    private void DrawWings(Graphics g)
    {
        float cx = W / 2f;
        for (int side = -1; side <= 1; side += 2)
        {
            for (int bar = 0; bar < 3; bar++)
            {
                float yo = 238f + bar * 20f;
                float reach = 252f - bar * 18f;
                poly[0] = new PointF(cx + side * 46f, yo + 14f);
                poly[1] = new PointF(cx + side * reach, yo - 12f);
                poly[2] = new PointF(cx + side * (reach - 4f), yo - 2f);
                poly[3] = new PointF(cx + side * 46f, yo + 26f);
                int shade = 205 - bar * 28;
                g.FillPolygon(B(Color.FromArgb(255, shade - 20, shade - 4, shade + 20)), poly);
                g.DrawPolygon(P(Color.FromArgb(255, 14, 22, 60), 2f), poly);
            }
        }
        g.FillEllipse(B(Color.FromArgb(255, 214, 224, 240)), cx - 32f, 242f, 64f, 64f);
        g.FillEllipse(B(Color.FromArgb(255, 24, 56, 150)), cx - 25f, 249f, 50f, 50f);
        g.DrawEllipse(P(Color.FromArgb(255, 14, 22, 60), 2f), cx - 32f, 242f, 64f, 64f);
        PointF[] star = new PointF[10];
        for (int i = 0; i < 10; i++)
        {
            float a = -MathF.PI / 2f + i * MathF.PI / 5f;
            float r = (i % 2 == 0) ? 21f : 9f;
            star[i] = new PointF(cx + MathF.Cos(a) * r, 274f + MathF.Sin(a) * r);
        }
        g.FillPolygon(B(Color.White), star);
    }

    // ------------------------------------------------------------------ overlays

    private void DrawPause(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(170, 4, 8, 24)), 0, 0, W, ViewH);
        Txt(g, "PAUSED", fBig, Color.White, W / 2f, 236f, sfCenter, true);
        Button(g, ResumeButton, "RESUME  [ESC]", true, e.Clock);
        Button(g, PauseRestartButton, "RESTART  [R]", false, e.Clock);
        Button(g, PauseMenuButton, "MAIN MENU  [M]", false, e.Clock);
    }

    private void DrawEnd(Graphics g, GameEngine e, bool victory)
    {
        g.FillRectangle(B(Color.FromArgb(180, 4, 8, 24)), 0, 0, W, ViewH);
        Panel(g, 50f, 120f, 540f, 480f, 242);
        if (victory)
        {
            Txt(g, "MISSION COMPLETED!", fBig, Color.FromArgb(255, 255, 220, 80), W / 2f, 180f, sfCenter, true);
            Txt(g, "BOSS DEFEATED", fMid, Color.FromArgb(255, 120, 255, 160), W / 2f, 236f, sfCenter, true);
        }
        else
        {
            Txt(g, "GAME OVER", fBig, Color.FromArgb(255, 255, 90, 80), W / 2f, 190f, sfCenter, true);
        }
        float y0 = victory ? 290f : 270f;
        Txt(g, "FINAL SCORE", fLabel, Color.FromArgb(255, 150, 190, 255), W / 2f, y0, sfCenter, false);
        Txt(g, e.Score.ToString("D7"), fBig, Color.White, W / 2f, y0 + 38f, sfCenter, true);
        if (e.NewRecord) Txt(g, "NEW RECORD!", fText, Color.FromArgb(255, 255, 230, 90), W / 2f, y0 + 82f, sfCenter, true);
        Txt(g, "BEST SCORE  " + e.Scores.Best.ToString("D7"), fText, Color.FromArgb(255, 255, 224, 100), W / 2f, y0 + 114f, sfCenter, true);
        Txt(g, "ENEMIES DESTROYED  " + e.Kills, fText, Color.White, W / 2f, y0 + 148f, sfCenter, true);
        if (victory) Txt(g, "Thunder Fortress destroyed - the skies are clear", fSmall, Color.FromArgb(255, 210, 225, 250), W / 2f, y0 + 182f, sfCenter, true);
        Button(g, EndRestartButton, "RESTART  [R]", true, e.Clock);
        Button(g, EndMenuButton, "MAIN MENU  [M]", false, e.Clock);
    }

    private void DrawFooter(Graphics g)
    {
        Rectangle r = new Rectangle(0, GameConfig.LogicalH - GameConfig.FooterH, W, GameConfig.FooterH);
        g.FillRectangle(B(Color.FromArgb(255, 6, 10, 26)), r);
        g.FillRectangle(B(Color.FromArgb(255, 255, 190, 40)), 0, r.Y, W, 2);
        g.DrawString(FooterText, fFooter, B(Color.FromArgb(255, 225, 234, 252)),
            new RectangleF(0f, r.Y + 3f, W, r.Height - 3f), sfCenter);
    }
}
