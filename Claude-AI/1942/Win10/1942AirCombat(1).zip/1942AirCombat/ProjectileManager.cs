namespace AirCombat;

/// <summary>Owns all player and enemy projectiles, creates the common firing patterns and moves everything.</summary>
public sealed class ProjectileManager
{
    public readonly List<Projectile> Player = new List<Projectile>(256);
    public readonly List<Projectile> Enemy = new List<Projectile>(512);
    private readonly Stack<Projectile> pool = new Stack<Projectile>(512);

    private Projectile Make()
    {
        Projectile p = pool.Count > 0 ? pool.Pop() : new Projectile();
        p.AX = 0f;
        p.AY = 0f;
        p.Age = 0f;
        p.Damage = 1f;
        p.Alive = true;
        return p;
    }

    public void Clear()
    {
        foreach (Projectile p in Player) pool.Push(p);
        foreach (Projectile p in Enemy) pool.Push(p);
        Player.Clear();
        Enemy.Clear();
    }

    public void ClearEnemy()
    {
        foreach (Projectile p in Enemy) pool.Push(p);
        Enemy.Clear();
    }

    public Projectile SpawnPlayer(float x, float y, float vx, float vy, float damage)
    {
        Projectile p = Make();
        p.Kind = ShotKind.PlayerBullet;
        p.X = x; p.Y = y; p.VX = vx; p.VY = vy;
        p.Radius = 4f;
        p.Damage = damage;
        Player.Add(p);
        return p;
    }

    public Projectile SpawnEnemy(ShotKind kind, float x, float y, float vx, float vy)
    {
        Projectile p = Make();
        p.Kind = kind;
        p.X = x; p.Y = y; p.VX = vx; p.VY = vy;
        switch (kind)
        {
            case ShotKind.EnemyHeavy: p.Radius = 7f; break;
            case ShotKind.Missile: p.Radius = 6f; break;
            case ShotKind.BossOrb: p.Radius = 10f; break;
            default: p.Radius = 5f; break;
        }
        Enemy.Add(p);
        return p;
    }

    /// <summary>One shot aimed at a target point, rotated by an extra angle (radians).</summary>
    public Projectile FireAimed(ShotKind kind, float x, float y, float tx, float ty, float speed, float angleOffset)
    {
        float a = MathF.Atan2(ty - y, tx - x) + angleOffset;
        return SpawnEnemy(kind, x, y, MathF.Cos(a) * speed, MathF.Sin(a) * speed);
    }

    /// <summary>A fan of shots centred on the target direction.</summary>
    public void FireFan(ShotKind kind, float x, float y, float tx, float ty, float speed, int count, float totalAngle)
    {
        for (int i = 0; i < count; i++)
        {
            float t = count == 1 ? 0f : (i / (float)(count - 1) - 0.5f);
            FireAimed(kind, x, y, tx, ty, speed, t * totalAngle);
        }
    }

    public void FireRing(ShotKind kind, float x, float y, int count, float speed, float phase)
    {
        for (int i = 0; i < count; i++)
        {
            float a = phase + i * MathF.PI * 2f / count;
            SpawnEnemy(kind, x, y, MathF.Cos(a) * speed, MathF.Sin(a) * speed);
        }
    }

    public void Update(float dt)
    {
        Step(Player, dt);
        Step(Enemy, dt);
    }

    private void Step(List<Projectile> list, float dt)
    {
        for (int i = list.Count - 1; i >= 0; i--)
        {
            Projectile p = list[i];
            p.Age += dt;
            p.VX += p.AX * dt;
            p.VY += p.AY * dt;
            if (p.Kind == ShotKind.Missile && p.VY > 430f) p.VY = 430f;
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            bool out_ = p.X < -50f || p.X > GameConfig.LogicalW + 50f || p.Y < -70f || p.Y > GameConfig.ViewH + 50f;
            if (!p.Alive || out_)
            {
                p.Alive = false;
                list[i] = list[list.Count - 1];
                list.RemoveAt(list.Count - 1);
                pool.Push(p);
            }
        }
    }
}
