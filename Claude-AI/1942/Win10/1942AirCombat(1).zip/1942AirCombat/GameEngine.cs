namespace AirCombat;

public enum GameState { Menu, Playing, Paused, GameOver, Victory }

/// <summary>Game rules and the fixed-step simulation (1/120 s): stage timeline, boss, scoring, bonuses, lives.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;

    public GameState State = GameState.Menu;
    public readonly PlayerAircraft Player = new PlayerAircraft();
    public readonly ProjectileManager Shots = new ProjectileManager();
    public readonly EnemyManager Enemies = new EnemyManager();
    public readonly Boss Boss = new Boss();
    public readonly BonusManager Bonuses = new BonusManager();
    public readonly ExplosionManager Explosions = new ExplosionManager();
    public readonly ParticleSystem Particles = new ParticleSystem();
    public readonly ScoreManager Scores = new ScoreManager();

    // input set by the window
    public bool Up, Down, Left, Right, Fire;

    public float Clock;                  // keeps running for menu animations
    public float StageTime;
    public float Scroll;                 // distance scrolled, in pixels
    public int Score;
    public int Kills;
    public bool NewRecord;
    public float Shake;
    public float Flash;
    public string Banner = "";
    public float BannerTimer;
    public string BonusText = "";
    public float BonusTimer;
    public BonusType LastBonus;

    private bool rollQueued;
    private bool bossWarned;
    private bool bossSpawned;
    private float endTimer;
    private readonly Random rng = new Random();

    public float Difficulty
    {
        get { return Math.Max(0f, Math.Min(1f, StageTime / GameConfig.StageLengthTime)); }
    }

    public float StageProgress
    {
        get { return Math.Max(0f, Math.Min(1f, StageTime / GameConfig.BossArrivalTime)); }
    }

    public GameEngine()
    {
        Scores.Load();
        Enemies.Killed = OnEnemyKilled;
        Enemies.GroupWiped = OnGroupWiped;
        Enemies.Reset();
        Player.Reset();
    }

    // ------------------------------------------------------------------ flow

    public void StartGame()
    {
        Player.Reset();
        Shots.Clear();
        Enemies.Reset();
        Boss.Reset();
        Bonuses.Clear();
        Explosions.Clear();
        Particles.Clear();
        Score = 0;
        Kills = 0;
        StageTime = 0f;
        Scroll = 0f;
        NewRecord = false;
        Shake = 0f;
        Flash = 0f;
        Banner = "";
        BannerTimer = 0f;
        BonusText = "";
        BonusTimer = 0f;
        bossWarned = false;
        bossSpawned = false;
        endTimer = 0f;
        rollQueued = false;
        State = GameState.Playing;
        Sfx.Play(SfxId.Click);
        Banner = "MISSION START";
        BannerTimer = 2.2f;
    }

    public void Resume()
    {
        if (State != GameState.Paused) return;
        Sfx.Play(SfxId.Click);
        State = GameState.Playing;
    }

    public void Pause()
    {
        if (State != GameState.Playing) return;
        ClearInput();
        Sfx.Play(SfxId.Click);
        State = GameState.Paused;
    }

    public void GoToMenu()
    {
        ClearInput();
        Sfx.Play(SfxId.Click);
        State = GameState.Menu;
    }

    public void AutoPause()
    {
        ClearInput();
        if (State == GameState.Playing) State = GameState.Paused;
    }

    private void ClearInput()
    {
        Up = false; Down = false; Left = false; Right = false; Fire = false;
        rollQueued = false;
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                if (State == GameState.Menu || State == GameState.GameOver || State == GameState.Victory) StartGame();
                else if (State == GameState.Paused) Resume();
                break;
            case Keys.Space:
                if (State == GameState.Menu) StartGame();
                break;
            case Keys.X:
            case Keys.ShiftKey:
            case Keys.LShiftKey:
            case Keys.RShiftKey:
                if (State == GameState.Playing) rollQueued = true;
                break;
            case Keys.Escape:
            case Keys.P:
                if (State == GameState.Playing) Pause();
                else if (State == GameState.Paused) Resume();
                else if ((State == GameState.GameOver || State == GameState.Victory) && key == Keys.Escape) GoToMenu();
                break;
            case Keys.R:
                if (State != GameState.Menu) StartGame();
                break;
            case Keys.M:
                if (State == GameState.Paused || State == GameState.GameOver || State == GameState.Victory) GoToMenu();
                break;
            case Keys.N:
                Sfx.SetMuted(!Sfx.Muted);
                break;
        }
    }

    // ------------------------------------------------------------------ simulation

    public void Update()
    {
        Clock += Dt;
        if (State == GameState.Menu || State == GameState.Paused) return;

        if (State == GameState.GameOver || State == GameState.Victory)
        {
            Scroll += GameConfig.ScrollSpeed * Dt;
            Shots.Update(Dt);
            UpdateEffects();
            return;
        }

        StageTime += Dt;
        Scroll += GameConfig.ScrollSpeed * Dt;
        float diff = Difficulty;

        PlayerInput inp = new PlayerInput();
        inp.Up = Up; inp.Down = Down; inp.Left = Left; inp.Right = Right; inp.Fire = Fire;
        inp.RollPressed = rollQueued;
        rollQueued = false;
        Player.Update(Dt, inp, Shots);
        HandlePlayerEvents();

        Shots.Update(Dt);
        Bonuses.Update(Dt);

        bool anyFired;
        Enemies.Update(Dt, StageTime, Player, diff, Shots, Particles, out anyFired);
        if (anyFired) Sfx.Play(SfxId.EnemyShoot);

        UpdateBoss();

        CollisionManager.Resolve(this);

        if (!Player.Alive && Player.Lives <= 0)
        {
            endTimer += Dt;
            if (endTimer >= 1.7f) EndGame(false);
        }
        UpdateEffects();
    }

    private void UpdateEffects()
    {
        Particles.Update(Dt);
        Explosions.Update(Dt);
        if (Shake > 0f) Shake = Math.Max(0f, Shake - Dt);
        if (Flash > 0f) Flash = Math.Max(0f, Flash - Dt);
        if (BannerTimer > 0f) BannerTimer -= Dt;
        if (BonusTimer > 0f) BonusTimer -= Dt;
    }

    private void HandlePlayerEvents()
    {
        if (Player.EvShot)
        {
            Player.EvShot = false;
            Sfx.Play(SfxId.Shoot);
            Particles.Sparks(Player.X - 14f, Player.Y - 12f, 60f, 1, Color.FromArgb(255, 240, 150));
            Particles.Sparks(Player.X + 14f, Player.Y - 12f, 60f, 1, Color.FromArgb(255, 240, 150));
        }
        if (Player.EvRoll)
        {
            Player.EvRoll = false;
            Sfx.Play(SfxId.Roll);
            Particles.Ring(Player.X, Player.Y, 46f, Color.FromArgb(150, 210, 255));
        }
        if (Player.EvShieldBreak)
        {
            Player.EvShieldBreak = false;
            Sfx.Play(SfxId.Hit);
            Particles.Ring(Player.X, Player.Y, 70f, Color.FromArgb(120, 190, 255));
            Particles.Sparks(Player.X, Player.Y, 220f, 12, Color.FromArgb(160, 220, 255));
            Shake = Math.Max(Shake, 0.12f);
        }
        if (Player.EvRespawned)
        {
            Player.EvRespawned = false;
            Particles.Ring(Player.X, Player.Y, 60f, Color.White);
        }
    }

    private void UpdateBoss()
    {
        if (!bossWarned && StageTime >= GameConfig.BossWarningTime)
        {
            bossWarned = true;
            Banner = "WARNING!";
            BannerTimer = 3.6f;
            Sfx.Play(SfxId.BossArrive);
        }
        if (!bossSpawned && StageTime >= GameConfig.BossArrivalTime)
        {
            bossSpawned = true;
            Boss.Spawn();
        }

        Boss.Update(Dt, Player.Alive ? Player.X : GameConfig.PlayerStartX, Player.Alive ? Player.Y : GameConfig.PlayerStartY, Shots, Explosions, Particles);
        if (Boss.EvFired) Sfx.Play(SfxId.EnemyShoot);
        if (Boss.EvPhaseChanged)
        {
            Shots.ClearEnemy();
            Banner = Boss.Phase == 2 ? "PHASE 2" : "FINAL PHASE";
            BannerTimer = 2f;
            Sfx.Play(SfxId.BigExplosion);
            Shake = 0.35f;
            Flash = 0.25f;
            Explosions.Add(Boss.X - 60f, Boss.Y, ExplosionKind.Large);
            Explosions.Add(Boss.X + 60f, Boss.Y, ExplosionKind.Large, 0.1f);
        }
        if (Boss.Dying)
        {
            if (Boss.DeathTimer < 0.05f)
            {
                Shots.ClearEnemy();
                Sfx.Play(SfxId.BossDie);
            }
            Shake = Math.Max(Shake, 0.1f);
        }
        if (Boss.EvDeathBlast) Sfx.Play(SfxId.BigExplosion);
        if (Boss.EvDefeated)
        {
            Score += GameConfig.ScoreBoss;
            Shake = 0.8f;
            Flash = 0.6f;
            Sfx.Play(SfxId.BossDie);
            EndGame(true);
        }
    }

    private void EndGame(bool victory)
    {
        NewRecord = Scores.Submit(Score);
        ClearInput();
        State = victory ? GameState.Victory : GameState.GameOver;
        if (victory) Sfx.Play(SfxId.Victory);
    }

    // ------------------------------------------------------------------ events from the collision and enemy code

    public void PlayerHit()
    {
        HitResult r = Player.Hit();
        if (r == HitResult.Died)
        {
            Explosions.Add(Player.X, Player.Y, ExplosionKind.Large);
            Particles.Debris(Player.X, Player.Y, 16, Color.FromArgb(40, 70, 150));
            Particles.Flames(Player.X, Player.Y, 8f, 8);
            Sfx.Play(SfxId.Hit);
            Shake = 0.35f;
            Shots.ClearEnemy();          // a fresh start after a death is fairer
            endTimer = 0f;
        }
        else if (r == HitResult.Shielded)
        {
            Player.EvShieldBreak = true;
        }
    }

    public void CollectBonus(Bonus b)
    {
        b.Alive = false;
        Score += GameConfig.ScoreBonusPickup;
        LastBonus = b.Type;
        switch (b.Type)
        {
            case BonusType.Weapon:
                if (Player.WeaponLevel < 3) Player.WeaponLevel++;
                else Score += 500;
                Sfx.Play(SfxId.WeaponUp);
                BonusText = Player.WeaponLevel >= 3 ? "WEAPON LEVEL 3 - MAXIMUM FIREPOWER" : "WEAPON LEVEL " + Player.WeaponLevel;
                break;
            case BonusType.Life:
                Player.Lives = Math.Min(GameConfig.MaxLives, Player.Lives + 1);
                Sfx.Play(SfxId.Bonus);
                BonusText = "EXTRA LIFE";
                break;
            case BonusType.Score:
                Score += GameConfig.ScoreBonusItem;
                Sfx.Play(SfxId.Bonus);
                BonusText = "BONUS +" + GameConfig.ScoreBonusItem;
                break;
            case BonusType.Shield:
                Player.ShieldTimer = GameConfig.ShieldDuration;
                Sfx.Play(SfxId.Bonus);
                BonusText = "SHIELD ACTIVE";
                break;
            default:
                ActivateBomb();
                BonusText = "BOMB - SCREEN CLEARED";
                break;
        }
        BonusTimer = 2.4f;
        Particles.Ring(b.X, b.Y, 54f, Color.FromArgb(255, 230, 120));
        Particles.Sparks(b.X, b.Y, 200f, 10, Color.FromArgb(255, 240, 150));
        Particles.Text(b.X, b.Y - 20f, Bonus.Label(b.Type), Color.White);
    }

    private void ActivateBomb()
    {
        Sfx.Play(SfxId.Bomb);
        Shake = 0.55f;
        Flash = 0.5f;
        Particles.Ring(Player.X, Player.Y, 420f, Color.FromArgb(255, 220, 120));
        Enemies.BombAll(GameConfig.BombEnemyDamage);
        if (Boss.Vulnerable) Boss.Damage(GameConfig.BombBossDamage);
        Shots.ClearEnemy();
    }

    private void OnEnemyKilled(EnemyAircraft e)
    {
        Score += e.Score;
        Kills++;
        bool big = e.Type == EnemyType.Bomber || e.Type == EnemyType.Elite;
        Explosions.Add(e.X, e.Y, big ? ExplosionKind.Large : ExplosionKind.Small);
        Particles.Debris(e.X, e.Y, big ? 14 : 6, Color.FromArgb(60, 70, 50));
        Particles.Flames(e.X, e.Y, big ? 14f : 6f, big ? 8 : 3);
        Particles.Smoke(e.X, e.Y, 0f, 20f, big ? 22f : 12f, 1.1f, 55);
        Particles.Text(e.X, e.Y - 14f, e.Score.ToString(), Color.FromArgb(255, 255, 220, 120));
        Sfx.Play(big ? SfxId.BigExplosion : SfxId.Explosion);
        if (big) Shake = Math.Max(Shake, 0.2f);

        switch (e.Type)
        {
            case EnemyType.Fighter:
                if (rng.NextDouble() < 0.07) Bonuses.Spawn(e.X, e.Y, Bonuses.Pick(Player.WeaponLevel, false));
                break;
            case EnemyType.Interceptor:
                if (rng.NextDouble() < 0.06) Bonuses.Spawn(e.X, e.Y, Bonuses.Pick(Player.WeaponLevel, false));
                break;
            case EnemyType.Bomber:
            case EnemyType.Elite:
                Bonuses.Spawn(e.X, e.Y, Bonuses.Pick(Player.WeaponLevel, true));
                break;
        }
    }

    private void OnGroupWiped(EnemyAircraft last)
    {
        Score += GameConfig.ScoreFormationBonus;
        Particles.Text(last.X, last.Y - 34f, "FORMATION +" + GameConfig.ScoreFormationBonus, Color.FromArgb(255, 160, 255, 160));
        BonusType t = Player.WeaponLevel < 3 ? BonusType.Weapon : Bonuses.Pick(Player.WeaponLevel, false);
        Bonuses.Spawn(last.X, last.Y, t);
    }
}
