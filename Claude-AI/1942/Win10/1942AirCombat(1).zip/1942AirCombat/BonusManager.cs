namespace AirCombat;

public sealed class BonusManager
{
    public readonly List<Bonus> Items = new List<Bonus>(16);
    private readonly Random rng = new Random();

    public void Clear()
    {
        Items.Clear();
    }

    public void Spawn(float x, float y, BonusType type)
    {
        Bonus b = new Bonus();
        b.X = x;
        b.BaseX = x;
        b.Y = y;
        b.Type = type;
        b.Alive = true;
        Items.Add(b);
    }

    /// <summary>Picks a random bonus. Weapon upgrades are favoured while the weapon is not maxed.</summary>
    public BonusType Pick(int weaponLevel, bool allowLife)
    {
        int wWeapon = weaponLevel < 3 ? 34 : 6;
        int wShield = 22;
        int wBomb = 16;
        int wScore = 22;
        int wLife = allowLife ? 8 : 0;
        int total = wWeapon + wShield + wBomb + wScore + wLife;
        int r = rng.Next(total);
        if ((r -= wWeapon) < 0) return BonusType.Weapon;
        if ((r -= wShield) < 0) return BonusType.Shield;
        if ((r -= wBomb) < 0) return BonusType.Bomb;
        if ((r -= wScore) < 0) return BonusType.Score;
        return BonusType.Life;
    }

    public void Update(float dt)
    {
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Bonus b = Items[i];
            b.Age += dt;
            b.Y += 85f * dt;
            b.X = b.BaseX + MathF.Sin(b.Age * 2.2f) * 26f;
            if (!b.Alive || b.Y > GameConfig.ViewH + 40f) Items.RemoveAt(i);
        }
    }
}
