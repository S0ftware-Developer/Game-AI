namespace AirCombat;

public struct PlayerInput
{
    public bool Up, Down, Left, Right, Fire, RollPressed;
}

public enum HitResult { None, Shielded, Died }

/// <summary>The player's fighter: smooth movement, weapon levels, evasive roll, shield, lives and respawn.</summary>
public sealed class PlayerAircraft
{
    public float X, Y, VX, VY;
    public float Bank;                // -1..1, for the banking animation
    public int Lives = GameConfig.StartLives;
    public int WeaponLevel = 1;
    public bool Alive = true;
    public float RespawnTimer;
    public float Invuln;
    public float ShieldTimer;
    public float RollTimer;           // time left in the current roll
    public float RollCooldown;        // time until the next roll is possible
    public int RollDir = 1;
    public float FireTimer;
    public float MuzzleTimer;
    public float Age;

    public readonly float[] TrailX = new float[8];
    public readonly float[] TrailY = new float[8];
    public readonly float[] TrailAge = new float[8];
    private int trailHead;
    private float trailTimer;

    // events read (and cleared) by the engine
    public bool EvShot, EvRoll, EvShieldBreak, EvRespawned;

    public bool IsInvulnerable { get { return !Alive || Invuln > 0f || RollTimer > 0f; } }
    public bool Rolling { get { return RollTimer > 0f; } }

    /// <summary>0..1 progress through the roll animation.</summary>
    public float RollProgress { get { return RollTimer > 0f ? 1f - RollTimer / GameConfig.RollDuration : 0f; } }

    /// <summary>0..1 how recharged the roll is (1 = ready).</summary>
    public float RollReady { get { return RollCooldown <= 0f ? 1f : 1f - RollCooldown / GameConfig.RollCooldown; } }

    public void Reset()
    {
        Lives = GameConfig.StartLives;
        WeaponLevel = 1;
        ShieldTimer = 0f;
        RollCooldown = 0f;
        RollTimer = 0f;
        Respawn();
        Invuln = 1.5f;
        EvRespawned = false;
    }

    public void Respawn()
    {
        X = GameConfig.PlayerStartX;
        Y = GameConfig.PlayerStartY;
        VX = 0f;
        VY = 0f;
        Bank = 0f;
        Alive = true;
        Invuln = GameConfig.RespawnInvulnerability;
        RollTimer = 0f;
        FireTimer = 0f;
        for (int i = 0; i < TrailAge.Length; i++) TrailAge[i] = 99f;
        EvRespawned = true;
    }

    private static float Approach(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    public void Update(float dt, PlayerInput inp, ProjectileManager shots)
    {
        Age += dt;
        if (!Alive)
        {
            if (Lives > 0)
            {
                RespawnTimer -= dt;
                if (RespawnTimer <= 0f) Respawn();
            }
            return;
        }

        if (Invuln > 0f) Invuln = Math.Max(0f, Invuln - dt);
        if (ShieldTimer > 0f) ShieldTimer = Math.Max(0f, ShieldTimer - dt);
        if (RollCooldown > 0f) RollCooldown = Math.Max(0f, RollCooldown - dt);
        if (RollTimer > 0f) RollTimer = Math.Max(0f, RollTimer - dt);
        if (MuzzleTimer > 0f) MuzzleTimer = Math.Max(0f, MuzzleTimer - dt);
        if (FireTimer > 0f) FireTimer -= dt;

        float dx = (inp.Right ? 1f : 0f) - (inp.Left ? 1f : 0f);
        float dy = (inp.Down ? 1f : 0f) - (inp.Up ? 1f : 0f);
        float len = MathF.Sqrt(dx * dx + dy * dy);
        if (len > 0f)
        {
            dx /= len;       // diagonals are not faster
            dy /= len;
        }

        if (inp.RollPressed && RollCooldown <= 0f && RollTimer <= 0f)
        {
            RollTimer = GameConfig.RollDuration;
            RollCooldown = GameConfig.RollCooldown;
            RollDir = dx != 0f ? (dx > 0f ? 1 : -1) : (X < GameConfig.LogicalW / 2f ? 1 : -1);
            VX += RollDir * 190f;
            EvRoll = true;
        }

        float boost = RollTimer > 0f ? 1.35f : 1f;
        float max = GameConfig.PlayerMaxSpeed;
        VX = Approach(VX, dx * max * boost, (dx != 0f ? GameConfig.PlayerAccel : GameConfig.PlayerDecel) * dt);
        VY = Approach(VY, dy * max * boost, (dy != 0f ? GameConfig.PlayerAccel : GameConfig.PlayerDecel) * dt);
        X += VX * dt;
        Y += VY * dt;
        if (X < 28f) { X = 28f; VX = 0f; }
        if (X > GameConfig.LogicalW - 28f) { X = GameConfig.LogicalW - 28f; VX = 0f; }
        if (Y < GameConfig.PlayerMinY) { Y = GameConfig.PlayerMinY; VY = 0f; }
        if (Y > GameConfig.ViewH - 36f) { Y = GameConfig.ViewH - 36f; VY = 0f; }
        Bank = Approach(Bank, Math.Max(-1f, Math.Min(1f, VX / max)), 7f * dt);

        // motion trail while rolling
        for (int i = 0; i < TrailAge.Length; i++) TrailAge[i] += dt;
        if (RollTimer > 0f)
        {
            trailTimer -= dt;
            if (trailTimer <= 0f)
            {
                trailTimer = 0.03f;
                trailHead = (trailHead + 1) % TrailX.Length;
                TrailX[trailHead] = X;
                TrailY[trailHead] = Y;
                TrailAge[trailHead] = 0f;
            }
        }

        if (inp.Fire && RollTimer <= 0f && FireTimer <= 0f)
        {
            Volley(shots);
            FireTimer = WeaponLevel >= 3 ? GameConfig.FireInterval3 : GameConfig.FireInterval1;
            MuzzleTimer = 0.055f;
            EvShot = true;
        }
    }

    private void Volley(ProjectileManager s)
    {
        float v = GameConfig.PlayerBulletSpeed;
        if (WeaponLevel <= 1)
        {
            s.SpawnPlayer(X - 10f, Y - 12f, 0f, -v, 1f);
            s.SpawnPlayer(X + 10f, Y - 12f, 0f, -v, 1f);
        }
        else if (WeaponLevel == 2)
        {
            s.SpawnPlayer(X, Y - 26f, 0f, -v, 1.2f);
            s.SpawnPlayer(X - 14f, Y - 10f, -150f, -v * 0.98f, 1f);
            s.SpawnPlayer(X + 14f, Y - 10f, 150f, -v * 0.98f, 1f);
        }
        else
        {
            s.SpawnPlayer(X - 5f, Y - 26f, 0f, -v * 1.02f, 1.2f);
            s.SpawnPlayer(X + 5f, Y - 26f, 0f, -v * 1.02f, 1.2f);
            s.SpawnPlayer(X - 14f, Y - 12f, -150f, -v * 0.99f, 1f);
            s.SpawnPlayer(X + 14f, Y - 12f, 150f, -v * 0.99f, 1f);
            s.SpawnPlayer(X - 22f, Y - 6f, -330f, -v * 0.93f, 1f);
            s.SpawnPlayer(X + 22f, Y - 6f, 330f, -v * 0.93f, 1f);
        }
    }

    /// <summary>Called when something dangerous touches the aircraft.</summary>
    public HitResult Hit()
    {
        if (IsInvulnerable) return HitResult.None;
        if (ShieldTimer > 0f)
        {
            ShieldTimer = 0f;
            Invuln = 1.2f;
            EvShieldBreak = true;
            return HitResult.Shielded;
        }
        Lives--;
        Alive = false;
        RespawnTimer = GameConfig.RespawnDelay;
        return HitResult.Died;
    }
}
