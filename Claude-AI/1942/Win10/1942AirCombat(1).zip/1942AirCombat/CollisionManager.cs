namespace AirCombat;

/// <summary>All collision tests: bullets vs enemies and boss, enemy shots vs player, rammings and bonus pickups.</summary>
public static class CollisionManager
{
    public static bool CircleRect(float cx, float cy, float r, RectangleF rc)
    {
        float nx = Math.Max(rc.Left, Math.Min(cx, rc.Right));
        float ny = Math.Max(rc.Top, Math.Min(cy, rc.Bottom));
        float dx = cx - nx;
        float dy = cy - ny;
        return dx * dx + dy * dy <= r * r;
    }

    public static void Resolve(GameEngine g)
    {
        PlayerBulletsVsEnemies(g);
        if (g.Player.Alive)
        {
            EnemyShotsVsPlayer(g);
            EnemiesVsPlayer(g);
            BonusesVsPlayer(g);
        }
    }

    private static void PlayerBulletsVsEnemies(GameEngine g)
    {
        List<Projectile> bullets = g.Shots.Player;
        for (int i = 0; i < bullets.Count; i++)
        {
            Projectile b = bullets[i];
            if (!b.Alive) continue;

            bool hit = false;
            foreach (EnemyAircraft e in g.Enemies.Enemies)
            {
                if (!e.Alive || e.Y < -10f) continue;
                if (CircleRect(b.X, b.Y, b.Radius, e.Hitbox))
                {
                    g.Enemies.DamageEnemy(e, b.Damage);
                    g.Particles.Sparks(b.X, b.Y, 150f, 3, Color.FromArgb(255, 230, 120));
                    b.Alive = false;
                    hit = true;
                    break;
                }
            }
            if (hit) continue;

            if (g.Boss.Vulnerable && g.Boss.Hits(b.X, b.Y, b.Radius))
            {
                g.Boss.Damage(b.Damage);
                g.Particles.Sparks(b.X, b.Y, 170f, 3, Color.FromArgb(255, 240, 160));
                b.Alive = false;
            }
        }
    }

    private static void EnemyShotsVsPlayer(GameEngine g)
    {
        PlayerAircraft p = g.Player;
        if (p.IsInvulnerable) return;
        List<Projectile> shots = g.Shots.Enemy;
        for (int i = 0; i < shots.Count; i++)
        {
            Projectile s = shots[i];
            if (!s.Alive) continue;
            float dx = s.X - p.X;
            float dy = s.Y - p.Y;
            float r = s.Radius * 0.85f + GameConfig.PlayerHitRadius;
            if (dx * dx + dy * dy <= r * r)
            {
                s.Alive = false;
                g.PlayerHit();
                if (p.IsInvulnerable) return;
            }
        }
    }

    private static void EnemiesVsPlayer(GameEngine g)
    {
        PlayerAircraft p = g.Player;
        if (p.IsInvulnerable) return;
        foreach (EnemyAircraft e in g.Enemies.Enemies)
        {
            if (!e.Alive) continue;
            if (CircleRect(p.X, p.Y, GameConfig.PlayerHitRadius, e.Hitbox))
            {
                g.Enemies.DamageEnemy(e, 6f);
                g.PlayerHit();
                return;
            }
        }
        if (g.Boss.Vulnerable && g.Boss.Hits(p.X, p.Y, GameConfig.PlayerHitRadius)) g.PlayerHit();
    }

    private static void BonusesVsPlayer(GameEngine g)
    {
        PlayerAircraft p = g.Player;
        // an index loop: collecting a bomb destroys enemies, which may drop new bonuses into this very list
        List<Bonus> items = g.Bonuses.Items;
        for (int i = 0; i < items.Count; i++)
        {
            Bonus b = items[i];
            if (!b.Alive) continue;
            float dx = b.X - p.X;
            float dy = b.Y - p.Y;
            float r = Bonus.Radius + 14f;
            if (dx * dx + dy * dy <= r * r) g.CollectBonus(b);
        }
    }
}
