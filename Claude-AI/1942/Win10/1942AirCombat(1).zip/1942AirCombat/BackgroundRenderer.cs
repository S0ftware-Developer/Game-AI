using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace AirCombat;

/// <summary>
/// The scrolling Pacific battlefield. Everything is drawn from a single "forward distance" f (screen y = ViewH + scroll - f):
/// open ocean, islands, a coastline growing into countryside, enemy installations and finally an airfield with a runway.
/// Textures and sprites are pre-rendered once; the coastline and the objects are placed from deterministic hashes.
/// </summary>
public sealed class BackgroundRenderer : IDisposable
{
    private const int W = GameConfig.LogicalW;
    private const int ViewH = GameConfig.ViewH;
    private const int PolyN = 51;       // points per coastline polygon (y from -16 to 784 step 16)

    private const float IslandsStart = 1500f;
    private const float CoastStart = 4000f;
    private const float CountryStart = 5600f;
    private const float InstallStart = 7000f;
    private const float AirfieldStart = 8200f;
    private const float RunwayStart = 8350f;
    private const float RunwayEnd = 11000f;

    // land widths along the stage: f, left width, right width
    private static readonly float[] KfF = { 0f, 4000f, 4900f, 5400f, 5800f, 7000f, 7400f, 100000f };
    private static readonly float[] KfL = { 0f, 0f, 150f, 170f, 330f, 330f, 430f, 430f };
    private static readonly float[] KfR = { 0f, 0f, 0f, 120f, 330f, 330f, 430f, 430f };

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly TextureBrush oceanBrush;
    private readonly TextureBrush waveBrush;
    private readonly TextureBrush grassBrush;
    private readonly Bitmap oceanTile;
    private readonly Bitmap waveTile;
    private readonly Bitmap grassTile;
    private readonly Bitmap[] islands = new Bitmap[6];
    private readonly Bitmap[] clouds = new Bitmap[5];
    private readonly PointF[] polyA = new PointF[PolyN + 2];
    private readonly PointF[] quad = new PointF[4];
    private readonly PointF[] tri = new PointF[3];

    public BackgroundRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        oceanTile = MakeOceanTile();
        waveTile = MakeWaveTile();
        grassTile = MakeGrassTile();
        oceanBrush = new TextureBrush(oceanTile, WrapMode.Tile);
        waveBrush = new TextureBrush(waveTile, WrapMode.Tile);
        grassBrush = new TextureBrush(grassTile, WrapMode.Tile);
        for (int i = 0; i < islands.Length; i++) islands[i] = MakeIsland(i);
        for (int i = 0; i < clouds.Length; i++) clouds[i] = MakeCloud(i);
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        oceanBrush.Dispose();
        waveBrush.Dispose();
        grassBrush.Dispose();
        oceanTile.Dispose();
        waveTile.Dispose();
        grassTile.Dispose();
        foreach (Bitmap b in islands) b.Dispose();
        foreach (Bitmap b in clouds) b.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static int Hash(int c)
    {
        unchecked
        {
            int h = c * 374761393;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    private static float Smooth(float t)
    {
        t = Math.Max(0f, Math.Min(1f, t));
        return t * t * (3f - 2f * t);
    }

    private static float Interp(float[] vals, float f)
    {
        for (int i = 0; i < KfF.Length - 1; i++)
        {
            if (f < KfF[i + 1])
            {
                float t = Smooth((f - KfF[i]) / (KfF[i + 1] - KfF[i]));
                return vals[i] + (vals[i + 1] - vals[i]) * t;
            }
        }
        return vals[vals.Length - 1];
    }

    private static float EdgeL(float f)
    {
        float w = Interp(KfL, f);
        if (w <= 0.5f) return 0f;
        float s = Math.Min(1f, w / 60f);
        float wob = 30f * MathF.Sin(f * 0.0125f + 0.5f) + 18f * MathF.Sin(f * 0.031f + 2.1f) + 7f * MathF.Sin(f * 0.073f);
        return w + s * wob;
    }

    private static float EdgeR(float f)
    {
        float w = Interp(KfR, f);
        if (w <= 0.5f) return W;
        float s = Math.Min(1f, w / 60f);
        float wob = 28f * MathF.Sin(f * 0.0105f + 1.9f) + 16f * MathF.Sin(f * 0.029f + 0.4f) + 7f * MathF.Sin(f * 0.067f + 3f);
        return W - (w + s * wob);
    }

    private static bool OnLand(float x, float f, float margin)
    {
        return x < EdgeL(f) - margin || x > EdgeR(f) + margin;
    }

    // ------------------------------------------------------------------ drawing

    public void Draw(Graphics g, float scroll, float time)
    {
        oceanBrush.ResetTransform();
        oceanBrush.TranslateTransform(0f, scroll % 256f);
        g.FillRectangle(oceanBrush, 0, 0, W, ViewH);
        waveBrush.ResetTransform();
        waveBrush.TranslateTransform((time * 9f) % 256f, (scroll * 1.15f) % 256f);
        g.FillRectangle(waveBrush, 0, 0, W, ViewH);

        DrawIslands(g, scroll);
        DrawShips(g, scroll, time);
        DrawLand(g, scroll);
        DrawRunway(g, scroll, time);
        DrawGroundObjects(g, scroll, time);
    }

    public void DrawClouds(Graphics g, float scroll)
    {
        float cs = scroll * 1.6f;
        const float cell = 380f;
        int i0 = (int)Math.Floor((cs - 200f) / cell);
        int i1 = (int)Math.Floor((cs + ViewH + 200f) / cell);
        for (int i = i0; i <= i1; i++)
        {
            int h = Hash(i * 53 + 11);
            if (h % 100 > 66) continue;
            Bitmap c = clouds[h % clouds.Length];
            float x = ((h >> 8) % (W + 120)) - 60f;
            float f = i * cell + (h >> 4) % 200;
            float y = ViewH + cs - f;
            g.DrawImageUnscaled(c, (int)(x - c.Width / 2f), (int)(y - c.Height / 2f));
        }
    }

    private void FillSide(Graphics g, bool left, float off, Brush brush, float scroll)
    {
        int n = 0;
        bool any = false;
        float y = -16f;
        for (int k = 0; k < PolyN; k++)
        {
            float f = ViewH + scroll - y;
            float x;
            if (left)
            {
                float e = EdgeL(f);
                x = e > 0.5f ? e + off * Math.Min(1f, e / 30f) : 0f;
                if (x > 0.5f) any = true;
            }
            else
            {
                float e = EdgeR(f);
                x = e < W - 0.5f ? e - off * Math.Min(1f, (W - e) / 30f) : W;
                if (x < W - 0.5f) any = true;
            }
            polyA[n++] = new PointF(x, y);
            y += 16f;
        }
        if (!any) return;
        float ex = left ? -10f : W + 10f;
        polyA[n++] = new PointF(ex, polyA[PolyN - 1].Y);
        polyA[n++] = new PointF(ex, polyA[0].Y);
        g.FillPolygon(brush, polyA);
    }

    private void DrawLand(Graphics g, float scroll)
    {
        if (scroll + ViewH < CoastStart - 200f) return;
        SolidBrush shallow = new SolidBrush(Color.FromArgb(110, 120, 220, 226));
        SolidBrush foam = new SolidBrush(Color.FromArgb(150, 255, 255, 255));
        SolidBrush sand = new SolidBrush(Color.FromArgb(255, 232, 214, 160));
        try
        {
            FillSide(g, true, 44f, shallow, scroll);
            FillSide(g, false, 44f, shallow, scroll);
            FillSide(g, true, 16f, foam, scroll);
            FillSide(g, false, 16f, foam, scroll);
            FillSide(g, true, 7f, sand, scroll);
            FillSide(g, false, 7f, sand, scroll);
        }
        finally
        {
            shallow.Dispose();
            foam.Dispose();
            sand.Dispose();
        }
        grassBrush.ResetTransform();
        grassBrush.TranslateTransform(0f, (ViewH + scroll) % 256f);
        FillSide(g, true, 0f, grassBrush, scroll);
        FillSide(g, false, 0f, grassBrush, scroll);
    }

    private void DrawIslands(Graphics g, float scroll)
    {
        const float cell = 380f;
        int i0 = (int)Math.Floor((scroll - 260f) / cell);
        int i1 = (int)Math.Floor((scroll + ViewH + 260f) / cell);
        for (int i = i0; i <= i1; i++)
        {
            if (i < 0) continue;
            int h = Hash(i * 977 + 3);
            float f = i * cell + (h >> 6) % 220;
            if (f < 700f || f > CoastStart + 300f) continue;
            bool small = f < IslandsStart;
            if (small && h % 100 > 35) continue;
            if (!small && h % 100 > 80) continue;
            Bitmap b = islands[small ? 4 + (h % 2) : h % 6];
            float x = 70f + (h >> 10) % (W - 140);
            if (f > CoastStart - 300f && OnLand(x, f, -120f)) continue;
            float y = ViewH + scroll - f;
            g.DrawImageUnscaled(b, (int)(x - b.Width / 2f), (int)(y - b.Height / 2f));
        }
    }

    private void DrawShips(Graphics g, float scroll, float time)
    {
        const float cell = 520f;
        int i0 = (int)Math.Floor((scroll - 300f) / cell);
        int i1 = (int)Math.Floor((scroll + ViewH + 300f) / cell);
        for (int i = i0; i <= i1; i++)
        {
            if (i < 0) continue;
            int h = Hash(i * 331 + 19);
            if (h % 100 > 55) continue;
            float f0 = i * cell + (h >> 5) % 300;
            if (f0 > CoastStart + 400f) continue;
            float f = f0 + time * 14f;                     // ships sail slowly forward
            float x = 90f + (h >> 11) % (W - 180);
            if (OnLand(x, f, -60f)) continue;
            float y = ViewH + scroll - f;
            if (y < -80f || y > ViewH + 80f) continue;
            DrawShip(g, x, y, (h >> 3) % 2 == 0);
        }
    }

    private void DrawShip(Graphics g, float x, float y, bool destroyer)
    {
        // wake
        tri[0] = new PointF(x, y + 28f);
        tri[1] = new PointF(x - 16f, y + 120f);
        tri[2] = new PointF(x + 16f, y + 120f);
        g.FillPolygon(B(Color.FromArgb(70, 255, 255, 255)), tri);
        GraphicsState st = g.Save();
        g.TranslateTransform(x, y);
        float len = destroyer ? 58f : 70f;
        float wid = destroyer ? 9f : 13f;
        PointF[] hull =
        {
            new PointF(0f, -len / 2f), new PointF(wid, -len / 4f), new PointF(wid, len / 2f - 4f),
            new PointF(wid - 3f, len / 2f), new PointF(-wid + 3f, len / 2f), new PointF(-wid, len / 2f - 4f), new PointF(-wid, -len / 4f)
        };
        g.FillPolygon(B(destroyer ? Color.FromArgb(255, 112, 120, 132) : Color.FromArgb(255, 104, 66, 56)), hull);
        g.DrawPolygon(P(Color.FromArgb(255, 40, 46, 56), 1.5f), hull);
        g.FillRectangle(B(Color.FromArgb(255, 176, 182, 192)), -wid + 3f, -len / 4f, wid * 2f - 6f, len * 0.5f);
        if (destroyer)
        {
            g.FillRectangle(B(Color.FromArgb(255, 70, 76, 88)), -4f, -6f, 8f, 14f);
            g.FillEllipse(B(Color.FromArgb(255, 60, 66, 76)), -4f, -len / 2f + 8f, 8f, 8f);
            g.FillEllipse(B(Color.FromArgb(255, 60, 66, 76)), -4f, len / 2f - 16f, 8f, 8f);
        }
        else
        {
            for (int k = 0; k < 3; k++) g.FillRectangle(B(Color.FromArgb(255, 188 - k * 30, 70 + k * 40, 52)), -wid + 4f, -len / 4f + 4f + k * 14f, wid * 2f - 8f, 10f);
            g.FillRectangle(B(Color.FromArgb(255, 236, 236, 236)), -wid + 3f, len / 2f - 18f, wid * 2f - 6f, 10f);
        }
        g.Restore(st);
    }

    // ------------------------------------------------------------------ ground objects

    private void DrawGroundObjects(Graphics g, float scroll, float time)
    {
        if (scroll + ViewH < CoastStart) return;
        const float cell = 110f;
        int i0 = (int)Math.Floor((scroll - 120f) / cell);
        int i1 = (int)Math.Floor((scroll + ViewH + 120f) / cell);
        for (int i = i0; i <= i1; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                int h = Hash(i * 97 + j * 13 + 7);
                float f = i * cell + 20f + (h >> 3) % 70;
                float x = j * cell + 20f + (h >> 9) % 70;
                if (f < CoastStart) continue;
                if (!OnLand(x, f, 22f)) continue;
                float y = ViewH + scroll - f;
                int roll = (h >> 14) % 100;

                if (f < CountryStart)
                {
                    if (roll < 14) DrawHouse(g, x, y, h);
                }
                else if (f < InstallStart)
                {
                    if (roll < 36) DrawField(g, x, y, h);
                    else if (roll < 48) DrawHouse(g, x, y, h);
                }
                else if (f < AirfieldStart)
                {
                    if (roll < 20) DrawBunker(g, x, y, h);
                    else if (roll < 30) DrawFuelTanks(g, x, y);
                    else if (roll < 40) DrawHangar(g, x, y, h);
                    else if (roll < 46) DrawRadar(g, x, y, time);
                    else if (roll < 56) DrawHouse(g, x, y, h);
                }
                else
                {
                    if (x > 225f && x < 415f && f > RunwayStart - 60f) continue;
                    if (roll < 22) DrawHangar(g, x, y, h);
                    else if (roll < 36) DrawBunker(g, x, y, h);
                    else if (roll < 44) DrawFuelTanks(g, x, y);
                }
            }
        }
    }

    private void DrawHouse(Graphics g, float x, float y, int h)
    {
        g.FillRectangle(B(Color.FromArgb(70, 20, 40, 20)), x - 9f, y - 5f, 24f, 18f);
        g.FillRectangle(B(Color.FromArgb(255, 236, 230, 214)), x - 11f, y - 8f, 22f, 16f);
        bool dark = (h & 1) == 0;
        quad[0] = new PointF(x - 13f, y - 8f);
        quad[1] = new PointF(x + 13f, y - 8f);
        quad[2] = new PointF(x + 9f, y - 1f);
        quad[3] = new PointF(x - 9f, y - 1f);
        g.FillPolygon(B(dark ? Color.FromArgb(255, 176, 62, 52) : Color.FromArgb(255, 150, 96, 62)), quad);
        g.FillRectangle(B(Color.FromArgb(255, 110, 40, 34)), x - 13f, y - 1f, 26f, 2f);
    }

    private void DrawField(Graphics g, float x, float y, int h)
    {
        Color[] pal =
        {
            Color.FromArgb(255, 150, 190, 84), Color.FromArgb(255, 214, 196, 96), Color.FromArgb(255, 118, 168, 76),
            Color.FromArgb(255, 176, 140, 88), Color.FromArgb(255, 196, 210, 110)
        };
        Color c = pal[(h >> 5) % pal.Length];
        float w = 66f + (h >> 8) % 34;
        float hh = 50f + (h >> 12) % 30;
        g.FillRectangle(B(c), x - w / 2f, y - hh / 2f, w, hh);
        Color line = Color.FromArgb(70, 60, 80, 30);
        for (float k = -w / 2f + 7f; k < w / 2f - 2f; k += 8f) g.DrawLine(P(line, 1.5f), x + k, y - hh / 2f, x + k, y + hh / 2f);
        g.DrawRectangle(P(Color.FromArgb(120, 70, 90, 40), 1.5f), x - w / 2f, y - hh / 2f, w, hh);
    }

    private void DrawBunker(Graphics g, float x, float y, int h)
    {
        g.FillEllipse(B(Color.FromArgb(70, 10, 20, 10)), x - 18f, y - 14f, 40f, 34f);
        g.FillEllipse(B(Color.FromArgb(255, 124, 128, 134)), x - 20f, y - 20f, 40f, 40f);
        g.FillEllipse(B(Color.FromArgb(255, 84, 88, 96)), x - 13f, y - 13f, 26f, 26f);
        g.FillEllipse(B(Color.FromArgb(255, 44, 48, 56)), x - 6f, y - 6f, 12f, 12f);
        float a = ((h >> 4) % 628) / 100f;
        g.DrawLine(P(Color.FromArgb(255, 30, 34, 40), 3.5f), x, y, x + MathF.Cos(a) * 17f, y + MathF.Sin(a) * 17f);
    }

    private void DrawFuelTanks(Graphics g, float x, float y)
    {
        for (int k = 0; k < 3; k++)
        {
            float cx = x - 20f + k * 20f;
            float cy = y + (k % 2) * 12f - 6f;
            g.FillEllipse(B(Color.FromArgb(70, 10, 20, 10)), cx - 9f, cy - 6f, 22f, 20f);
            g.FillEllipse(B(Color.FromArgb(255, 188, 190, 196)), cx - 11f, cy - 11f, 22f, 22f);
            g.FillEllipse(B(Color.FromArgb(255, 150, 152, 160)), cx - 7f, cy - 7f, 14f, 14f);
            g.DrawEllipse(P(Color.FromArgb(255, 80, 84, 92), 1.5f), cx - 11f, cy - 11f, 22f, 22f);
        }
    }

    private void DrawHangar(Graphics g, float x, float y, int h)
    {
        g.FillRectangle(B(Color.FromArgb(70, 10, 20, 10)), x - 29f, y - 15f, 66f, 44f);
        g.FillRectangle(B(Color.FromArgb(255, 112, 118, 126)), x - 32f, y - 20f, 64f, 40f);
        for (float k = -28f; k < 30f; k += 8f) g.DrawLine(P(Color.FromArgb(255, 78, 84, 92), 1.5f), x + k, y - 20f, x + k, y + 20f);
        g.FillRectangle(B(Color.FromArgb(255, 56, 60, 68)), x - 14f, y + 14f, 28f, 6f);
        g.DrawRectangle(P(Color.FromArgb(255, 60, 66, 74), 2f), x - 32f, y - 20f, 64f, 40f);
        if ((h & 3) == 0) g.FillEllipse(B(Color.FromArgb(255, 200, 40, 36)), x - 4f, y - 5f, 8f, 8f);
    }

    private void DrawRadar(Graphics g, float x, float y, float time)
    {
        g.FillEllipse(B(Color.FromArgb(255, 130, 134, 142)), x - 12f, y - 12f, 24f, 24f);
        g.FillEllipse(B(Color.FromArgb(255, 80, 86, 94)), x - 6f, y - 6f, 12f, 12f);
        float a = time * 2.2f + x;
        g.DrawLine(P(Color.FromArgb(255, 40, 44, 50), 3f), x - MathF.Cos(a) * 18f, y - MathF.Sin(a) * 18f, x + MathF.Cos(a) * 18f, y + MathF.Sin(a) * 18f);
    }

    private void DrawRunway(Graphics g, float scroll, float time)
    {
        if (scroll + ViewH < RunwayStart || scroll > RunwayEnd + 40f) return;
        float yTop = ViewH + scroll - RunwayEnd;
        float yBot = ViewH + scroll - RunwayStart;
        float top = Math.Max(-10f, yTop);
        float bot = Math.Min(ViewH + 10f, yBot);
        const float x0 = 250f;
        const float rw = 140f;
        // apron / shoulder and surface
        g.FillRectangle(B(Color.FromArgb(255, 150, 152, 144)), x0 - 18f, top, rw + 36f, bot - top);
        g.FillRectangle(B(Color.FromArgb(255, 86, 90, 98)), x0, top, rw, bot - top);
        g.DrawLine(P(Color.FromArgb(255, 240, 240, 240), 3f), x0 + 4f, top, x0 + 4f, bot);
        g.DrawLine(P(Color.FromArgb(255, 240, 240, 240), 3f), x0 + rw - 4f, top, x0 + rw - 4f, bot);
        // centre dashes, aligned to the world so they scroll with it
        float startF = (float)Math.Ceiling((ViewH + scroll - bot) / 70f) * 70f;
        for (float f = Math.Max(RunwayStart, startF); f < RunwayEnd; f += 70f)
        {
            float y = ViewH + scroll - f;
            if (y < -40f) break;
            if (y > ViewH + 40f) continue;
            g.FillRectangle(B(Color.FromArgb(255, 238, 238, 230)), x0 + rw / 2f - 3f, y - 18f, 6f, 36f);
        }
        // blinking edge lights
        bool on = ((int)(time * 2.5f)) % 2 == 0;
        for (float f = RunwayStart; f < RunwayEnd; f += 90f)
        {
            float y = ViewH + scroll - f;
            if (y < -10f || y > ViewH + 10f) continue;
            Color lc = on ? Color.FromArgb(255, 255, 220, 90) : Color.FromArgb(160, 120, 100, 40);
            g.FillEllipse(B(lc), x0 - 12f, y - 3f, 6f, 6f);
            g.FillEllipse(B(lc), x0 + rw + 6f, y - 3f, 6f, 6f);
        }
        // threshold bars at the near end
        float yb = ViewH + scroll - (RunwayStart + 30f);
        if (yb > -30f && yb < ViewH + 30f)
        {
            for (int k = 0; k < 8; k++) g.FillRectangle(B(Color.White), x0 + 12f + k * 15f, yb - 12f, 8f, 24f);
        }
        // taxiways and a few parked aircraft
        for (float f = RunwayStart + 220f; f < RunwayEnd; f += 520f)
        {
            float y = ViewH + scroll - f;
            if (y < -60f || y > ViewH + 60f) continue;
            g.FillRectangle(B(Color.FromArgb(255, 112, 114, 118)), x0 - 120f, y - 12f, 120f, 24f);
            g.FillRectangle(B(Color.FromArgb(255, 112, 114, 118)), x0 + rw, y - 12f, 120f, 24f);
            DrawParkedPlane(g, x0 - 100f, y - 34f);
            DrawParkedPlane(g, x0 + rw + 90f, y + 34f);
        }
    }

    private void DrawParkedPlane(Graphics g, float x, float y)
    {
        g.FillEllipse(B(Color.FromArgb(70, 10, 20, 10)), x - 14f, y - 8f, 32f, 30f);
        g.FillEllipse(B(Color.FromArgb(255, 82, 108, 70)), x - 3f, y - 14f, 6f, 28f);
        g.FillRectangle(B(Color.FromArgb(255, 70, 94, 60)), x - 15f, y - 4f, 30f, 7f);
        g.FillRectangle(B(Color.FromArgb(255, 70, 94, 60)), x - 7f, y + 9f, 14f, 4f);
        g.FillEllipse(B(Color.FromArgb(255, 210, 40, 36)), x - 11f, y - 3f, 5f, 5f);
        g.FillEllipse(B(Color.FromArgb(255, 210, 40, 36)), x + 6f, y - 3f, 5f, 5f);
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private static void Wrap(Action<int, int> draw)
    {
        for (int dy = -256; dy <= 256; dy += 256)
        {
            for (int dx = -256; dx <= 256; dx += 256) draw(dx, dy);
        }
    }

    private static Bitmap MakeOceanTile()
    {
        Bitmap bmp = new Bitmap(256, 256, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.FromArgb(255, 22, 94, 172));
            Random rnd = new Random(21);
            for (int i = 0; i < 70; i++)
            {
                float x = rnd.Next(256);
                float y = rnd.Next(256);
                float w = 40 + rnd.Next(90);
                float h = 18 + rnd.Next(50);
                int a = 18 + rnd.Next(26);
                Color c = rnd.Next(2) == 0 ? Color.FromArgb(a, 10, 60, 140) : Color.FromArgb(a, 60, 150, 220);
                using (SolidBrush b = new SolidBrush(c))
                {
                    Wrap((dx, dy) => g.FillEllipse(b, x + dx, y + dy, w, h));
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeWaveTile()
    {
        Bitmap bmp = new Bitmap(256, 256, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(33);
            using (Pen p = new Pen(Color.FromArgb(70, 220, 240, 255), 2f))
            {
                p.StartCap = LineCap.Round;
                p.EndCap = LineCap.Round;
                for (int i = 0; i < 46; i++)
                {
                    float x = rnd.Next(256);
                    float y = rnd.Next(256);
                    float w = 12 + rnd.Next(22);
                    Wrap((dx, dy) =>
                    {
                        g.DrawArc(p, x + dx, y + dy, w, 7f, 200f, 140f);
                    });
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeGrassTile()
    {
        Bitmap bmp = new Bitmap(256, 256, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.FromArgb(255, 92, 154, 64));
            Random rnd = new Random(45);
            for (int i = 0; i < 60; i++)
            {
                float x = rnd.Next(256);
                float y = rnd.Next(256);
                float w = 30 + rnd.Next(80);
                float h = 20 + rnd.Next(60);
                Color c = rnd.Next(2) == 0 ? Color.FromArgb(60, 64, 120, 46) : Color.FromArgb(60, 120, 176, 78);
                using (SolidBrush b = new SolidBrush(c))
                {
                    Wrap((dx, dy) => g.FillEllipse(b, x + dx, y + dy, w, h));
                }
            }
            using (SolidBrush shadow = new SolidBrush(Color.FromArgb(60, 10, 40, 10)))
            using (SolidBrush dark = new SolidBrush(Color.FromArgb(255, 44, 104, 48)))
            using (SolidBrush light = new SolidBrush(Color.FromArgb(255, 84, 152, 64)))
            {
                for (int i = 0; i < 52; i++)
                {
                    float x = rnd.Next(256);
                    float y = rnd.Next(256);
                    float r = 5 + rnd.Next(6);
                    Wrap((dx, dy) =>
                    {
                        g.FillEllipse(shadow, x + dx - r + 2f, y + dy - r + 3f, r * 2f, r * 2f);
                        g.FillEllipse(dark, x + dx - r, y + dy - r, r * 2f, r * 2f);
                        g.FillEllipse(light, x + dx - r * 0.7f, y + dy - r * 0.8f, r * 1.1f, r * 1.0f);
                    });
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeIsland(int variant)
    {
        int size = variant >= 4 ? 150 : (190 + variant * 22);
        Bitmap bmp = new Bitmap(size * 2, size * 2, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(100 + variant * 17);
            float cx = size;
            float cy = size;
            float baseR = size * (variant >= 4 ? 0.42f : 0.56f);
            float a1 = (float)rnd.NextDouble() * 6f;
            float a2 = (float)rnd.NextDouble() * 6f;
            float a3 = (float)rnd.NextDouble() * 6f;
            Func<float, float, PointF[]> blob = (scale, stretch) =>
            {
                PointF[] pts = new PointF[56];
                for (int i = 0; i < pts.Length; i++)
                {
                    float t = i * MathF.PI * 2f / pts.Length;
                    float r = baseR * scale * (1f + 0.2f * MathF.Sin(3f * t + a1) + 0.11f * MathF.Sin(5f * t + a2) + 0.06f * MathF.Sin(9f * t + a3));
                    pts[i] = new PointF(cx + MathF.Cos(t) * r * stretch, cy + MathF.Sin(t) * r);
                }
                return pts;
            };
            float st = 1.15f;
            using (SolidBrush halo = new SolidBrush(Color.FromArgb(95, 110, 215, 226)))
            using (SolidBrush foam = new SolidBrush(Color.FromArgb(170, 255, 255, 255)))
            using (SolidBrush sand = new SolidBrush(Color.FromArgb(255, 232, 214, 160)))
            using (SolidBrush grass = new SolidBrush(Color.FromArgb(255, 84, 150, 64)))
            using (SolidBrush deep = new SolidBrush(Color.FromArgb(255, 62, 124, 52)))
            {
                g.FillPolygon(halo, blob(1.45f, st));
                g.FillPolygon(halo, blob(1.25f, st));
                g.FillPolygon(foam, blob(1.1f, st));
                g.FillPolygon(sand, blob(1.0f, st));
                g.FillPolygon(grass, blob(0.82f, st));
                g.FillPolygon(deep, blob(0.52f, st));
            }
            using (SolidBrush shadow = new SolidBrush(Color.FromArgb(70, 10, 40, 10)))
            using (SolidBrush dark = new SolidBrush(Color.FromArgb(255, 40, 98, 44)))
            using (SolidBrush light = new SolidBrush(Color.FromArgb(255, 86, 154, 66)))
            {
                int trees = variant >= 4 ? 7 : 24;
                for (int i = 0; i < trees; i++)
                {
                    double a = rnd.NextDouble() * Math.PI * 2.0;
                    double d = Math.Sqrt(rnd.NextDouble()) * baseR * 0.62;
                    float x = cx + (float)(Math.Cos(a) * d * st);
                    float y = cy + (float)(Math.Sin(a) * d);
                    float r = 6f + (float)rnd.NextDouble() * 6f;
                    g.FillEllipse(shadow, x - r + 2f, y - r + 3f, r * 2f, r * 2f);
                    g.FillEllipse(dark, x - r, y - r, r * 2f, r * 2f);
                    g.FillEllipse(light, x - r * 0.7f, y - r * 0.8f, r * 1.1f, r);
                }
            }
            if (variant == 2 || variant == 3)
            {
                // a small enemy base: a pad, a bunker and a gun
                using (SolidBrush pad = new SolidBrush(Color.FromArgb(255, 150, 152, 150)))
                using (SolidBrush roof = new SolidBrush(Color.FromArgb(255, 112, 118, 126)))
                using (SolidBrush gun = new SolidBrush(Color.FromArgb(255, 60, 64, 72)))
                {
                    g.FillRectangle(pad, cx - 34f, cy - 16f, 68f, 34f);
                    g.FillRectangle(roof, cx - 28f, cy - 12f, 30f, 24f);
                    g.FillEllipse(gun, cx + 10f, cy - 8f, 16f, 16f);
                    using (Pen p = new Pen(Color.FromArgb(255, 30, 34, 40), 3f))
                    {
                        g.DrawLine(p, cx + 18f, cy, cx + 30f, cy - 8f);
                    }
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeCloud(int variant)
    {
        Bitmap bmp = new Bitmap(260, 150, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(300 + variant * 13);
            using (SolidBrush shade = new SolidBrush(Color.FromArgb(70, 150, 180, 220)))
            using (SolidBrush body = new SolidBrush(Color.FromArgb(205, 255, 255, 255)))
            using (SolidBrush top = new SolidBrush(Color.FromArgb(190, 255, 255, 255)))
            {
                int puffs = 6 + variant;
                for (int i = 0; i < puffs; i++)
                {
                    float x = 40 + rnd.Next(150);
                    float y = 46 + rnd.Next(40);
                    float r = 22 + rnd.Next(26);
                    g.FillEllipse(shade, x - r, y - r * 0.5f + 12f, r * 2f, r * 1.2f);
                }
                for (int i = 0; i < puffs; i++)
                {
                    float x = 40 + rnd.Next(150);
                    float y = 46 + rnd.Next(40);
                    float r = 22 + rnd.Next(26);
                    g.FillEllipse(body, x - r, y - r * 0.7f, r * 2f, r * 1.4f);
                    g.FillEllipse(top, x - r * 0.6f, y - r * 0.95f, r * 1.2f, r * 0.9f);
                }
            }
        }
        return bmp;
    }
}
