using System.Drawing.Drawing2D;

namespace AirCombat;

/// <summary>
/// All aircraft, projectile, bonus, explosion and particle drawing. The aircraft polygons are static arrays in local
/// coordinates (nose up); enemies are drawn mirrored vertically so they face down. Nothing here allocates per frame
/// except the small GDI+ state objects used for transforms.
/// </summary>
public sealed class Sprites : IDisposable
{
    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fBonus = new Font("Segoe UI", 17f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly Font fText = new Font("Segoe UI", 13f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly StringFormat sfCenter = new StringFormat();
    private readonly PointF[] starPts = new PointF[10];
    private readonly PointF[] quad = new PointF[4];

    private static PointF[] Mirror(PointF[] a)
    {
        PointF[] r = new PointF[a.Length];
        for (int i = 0; i < a.Length; i++) r[i] = new PointF(-a[i].X, a[i].Y);
        return r;
    }

    private static PointF[] Pts(params float[] v)
    {
        PointF[] r = new PointF[v.Length / 2];
        for (int i = 0; i < r.Length; i++) r[i] = new PointF(v[i * 2], v[i * 2 + 1]);
        return r;
    }

    // ---- player (US Navy style fighter)
    private static readonly PointF[] PlFuse = Pts(0, -30, 5, -24, 7, -10, 6, 8, 3, 22, 0, 26, -3, 22, -6, 8, -7, -10, -5, -24);
    private static readonly PointF[] PlWingL = Pts(-6, -8, -34, -3, -35, 5, -6, 13);
    private static readonly PointF[] PlWingR = Mirror(PlWingL);
    private static readonly PointF[] PlTipL = Pts(-30, -3.6f, -34, -3, -35, 5, -31, 5.6f);
    private static readonly PointF[] PlTipR = Mirror(PlTipL);
    private static readonly PointF[] PlTailL = Pts(-3, 17, -15, 22, -15, 26, -3, 25);
    private static readonly PointF[] PlTailR = Mirror(PlTailL);
    private static readonly PointF[] PlFin = Pts(0, 12, 1.6f, 22, 0, 27, -1.6f, 22);

    // ---- fighter (olive, round wings)
    private static readonly PointF[] FiFuse = Pts(0, -22, 4.5f, -16, 6, -4, 5, 10, 2.5f, 20, 0, 22, -2.5f, 20, -5, 10, -6, -4, -4.5f, -16);
    private static readonly PointF[] FiWingL = Pts(-5, -6, -18, -8, -23, -3, -23, 3, -18, 7, -5, 9);
    private static readonly PointF[] FiWingR = Mirror(FiWingL);
    private static readonly PointF[] FiTailL = Pts(-2.5f, 14, -10, 17, -10, 21, -2.5f, 20);
    private static readonly PointF[] FiTailR = Mirror(FiTailL);

    // ---- interceptor (small, swept wings)
    private static readonly PointF[] InFuse = Pts(0, -20, 3, -12, 3.5f, 6, 1.5f, 18, 0, 19, -1.5f, 18, -3.5f, 6, -3, -12);
    private static readonly PointF[] InWingL = Pts(-3, -4, -20, 6, -21, 11, -3, 9);
    private static readonly PointF[] InWingR = Mirror(InWingL);
    private static readonly PointF[] InNose = Pts(0, -20, 3, -12, -3, -12);
    private static readonly PointF[] InTailL = Pts(-1.5f, 13, -8, 19, -1.5f, 19);
    private static readonly PointF[] InTailR = Mirror(InTailL);

    // ---- bomber (twin engine)
    private static readonly PointF[] BoFuse = Pts(0, -44, 8, -34, 11, -10, 10, 24, 6, 42, 0, 46, -6, 42, -10, 24, -11, -10, -8, -34);
    private static readonly PointF[] BoWingL = Pts(-10, -12, -70, -8, -72, -2, -72, 6, -10, 12);
    private static readonly PointF[] BoWingR = Mirror(BoWingL);
    private static readonly PointF[] BoTailL = Pts(-8, 32, -32, 38, -32, 45, -8, 44);
    private static readonly PointF[] BoTailR = Mirror(BoTailL);

    // ---- formation plane (tan dive bomber)
    private static readonly PointF[] FoFuse = Pts(0, -19, 4, -12, 5, 0, 4, 12, 0, 19, -4, 12, -5, 0, -4, -12);
    private static readonly PointF[] FoWingL = Pts(-5, -3, -21, -7, -22, -1, -5, 7);
    private static readonly PointF[] FoWingR = Mirror(FoWingL);
    private static readonly PointF[] FoTailL = Pts(-2, 12, -11, 15, -11, 19, -2, 18);
    private static readonly PointF[] FoTailR = Mirror(FoTailL);

    // ---- elite (dark twin boom)
    private static readonly PointF[] ElPod = Pts(0, -26, 7, -16, 8, 6, 5, 22, 0, 26, -5, 22, -8, 6, -7, -16);
    private static readonly PointF[] ElWingL = Pts(-26, -10, -46, -4, -46, 4, -26, 8);
    private static readonly PointF[] ElWingR = Mirror(ElWingL);
    private static readonly PointF[] ElCenterWing = Pts(-26, -6, 26, -6, 26, 6, -26, 6);
    private static readonly PointF[] ElBoomL = Pts(-27, -22, -20, -22, -20, 31, -27, 31);
    private static readonly PointF[] ElBoomR = Mirror(ElBoomL);
    private static readonly PointF[] ElTail = Pts(-27, 22, 27, 22, 27, 29, -27, 29);

    // ---- boss (faces down, +y is the nose)
    private static readonly PointF[] BossBody = Pts(0, 82, 30, 62, 52, 12, 52, -50, 40, -72, -40, -72, -52, -50, -52, 12, -30, 62);
    private static readonly PointF[] BossWingL = Pts(-50, -32, -138, -6, -140, 24, -50, 36);
    private static readonly PointF[] BossWingR = Mirror(BossWingL);

    public Sprites()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fBonus.Dispose();
        fText.Dispose();
        sfCenter.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    /// <summary>Colour tinted toward white by the hit flash, with an alpha multiplier.</summary>
    private static Color C(int r, int g, int b, float flash, float alpha)
    {
        int rr = (int)(r + (255 - r) * flash);
        int gg = (int)(g + (255 - g) * flash);
        int bb = (int)(b + (255 - b) * flash);
        return Color.FromArgb(A(255f * alpha), rr, gg, bb);
    }

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private void Poly(Graphics g, PointF[] pts, Color fill, Color line, float lw)
    {
        g.FillPolygon(B(fill), pts);
        if (lw > 0f) g.DrawPolygon(P(line, lw), pts);
    }

    private void Star(Graphics g, float cx, float cy, float r, Color c)
    {
        for (int i = 0; i < 10; i++)
        {
            float a = -MathF.PI / 2f + i * MathF.PI / 5f;
            float rr = (i % 2 == 0) ? r : r * 0.42f;
            starPts[i] = new PointF(cx + MathF.Cos(a) * rr, cy + MathF.Sin(a) * rr);
        }
        g.FillPolygon(B(c), starPts);
    }

    private void Prop(Graphics g, float x, float y, float r, float time, float speed, float alpha)
    {
        g.FillEllipse(B(Color.FromArgb(A(55 * alpha), 255, 255, 255)), x - r, y - r, r * 2f, r * 2f);
        float a = time * speed;
        g.DrawLine(P(Color.FromArgb(A(190 * alpha), 30, 30, 36), 2f), x + MathF.Cos(a) * r, y + MathF.Sin(a) * r, x - MathF.Cos(a) * r, y - MathF.Sin(a) * r);
        g.DrawLine(P(Color.FromArgb(A(150 * alpha), 30, 30, 36), 2f), x + MathF.Cos(a + 2.1f) * r, y + MathF.Sin(a + 2.1f) * r, x - MathF.Cos(a + 2.1f) * r, y - MathF.Sin(a + 2.1f) * r);
        g.FillEllipse(B(Color.FromArgb(A(255 * alpha), 214, 176, 60)), x - 2.5f, y - 2.5f, 5f, 5f);
    }

    private void Roundel(Graphics g, float x, float y, float r, float flash, float alpha)
    {
        g.FillEllipse(B(C(245, 245, 240, flash, alpha)), x - r - 1f, y - r - 1f, (r + 1f) * 2f, (r + 1f) * 2f);
        g.FillEllipse(B(C(206, 30, 36, flash, alpha)), x - r, y - r, r * 2f, r * 2f);
    }

    // ------------------------------------------------------------------ the player

    public void DrawPlayer(Graphics g, PlayerAircraft p, float time)
    {
        if (!p.Alive) return;
        for (int i = 0; i < p.TrailAge.Length; i++)
        {
            float age = p.TrailAge[i];
            if (age < 0.25f)
            {
                float a = 0.5f * (1f - age / 0.25f);
                g.FillEllipse(B(Color.FromArgb(A(110 * a), 140, 205, 255)), p.TrailX[i] - 30f, p.TrailY[i] - 24f, 60f, 48f);
            }
        }
        bool flicker = p.Invuln > 0f && !p.Rolling && ((int)(time * 18f) & 1) == 0;
        if (!flicker) DrawPlayerBody(g, p.X, p.Y, p.Bank, p.RollProgress, time, p.MuzzleTimer > 0f, 1f, 1f);

        if (p.ShieldTimer > 0f)
        {
            bool fading = p.ShieldTimer < 2f && ((int)(time * 10f) & 1) == 0;
            if (!fading)
            {
                float pulse = 0.7f + 0.3f * MathF.Sin(time * 8f);
                g.FillEllipse(B(Color.FromArgb(A(40 * pulse), 120, 190, 255)), p.X - 36f, p.Y - 36f, 72f, 72f);
                g.DrawEllipse(P(Color.FromArgb(A(220 * pulse), 150, 215, 255), 2.5f), p.X - 36f, p.Y - 36f, 72f, 72f);
            }
        }
    }

    public void DrawPlayerBody(Graphics g, float x, float y, float bank, float rollProgress, float time, bool muzzle, float scale, float alpha)
    {
        // soft shadow on the ground below
        g.FillEllipse(B(Color.FromArgb(A(55 * alpha), 0, 20, 50)), x - 26f * scale + 16f, y - 12f * scale + 24f, 52f * scale, 30f * scale);

        GraphicsState st = g.Save();
        g.TranslateTransform(x, y);
        g.RotateTransform(bank * 7f);
        float sx = 1f - 0.1f * Math.Abs(bank);
        bool flipped = false;
        if (rollProgress > 0f)
        {
            float c = MathF.Cos(rollProgress * MathF.PI * 2f);
            flipped = c < 0f;
            float m = Math.Max(0.07f, Math.Abs(c));
            sx *= m;
        }
        g.ScaleTransform(sx * scale, scale);

        Color wing = flipped ? C(150, 190, 235, 0f, alpha) : C(30, 66, 156, 0f, alpha);
        Color wing2 = flipped ? C(200, 225, 250, 0f, alpha) : C(70, 118, 214, 0f, alpha);
        Color body = flipped ? C(120, 160, 220, 0f, alpha) : C(38, 80, 178, 0f, alpha);
        Color line = C(10, 20, 64, 0f, alpha);

        Poly(g, PlTailL, wing, line, 1.2f);
        Poly(g, PlTailR, wing, line, 1.2f);
        g.FillRectangle(B(C(220, 40, 44, 0f, alpha)), -13.5f, 23f, 8f, 1.8f);
        g.FillRectangle(B(C(220, 40, 44, 0f, alpha)), 5.5f, 23f, 8f, 1.8f);
        Poly(g, PlWingL, wing, line, 1.4f);
        Poly(g, PlWingR, wing, line, 1.4f);
        Poly(g, PlTipL, C(255, 208, 60, 0f, alpha), line, 0.8f);
        Poly(g, PlTipR, C(255, 208, 60, 0f, alpha), line, 0.8f);
        g.DrawLine(P(wing2, 2f), -8f, -6f, -32f, -2f);
        g.DrawLine(P(wing2, 2f), 8f, -6f, 32f, -2f);
        Poly(g, PlFuse, body, line, 1.5f);
        g.DrawLine(P(wing2, 2f), 0f, -26f, 0f, 22f);
        Poly(g, PlFin, C(230, 230, 236, 0f, alpha), line, 0.8f);

        if (!flipped)
        {
            Roundel(g, -20f, 3f, 5f, 0f, alpha);
            Roundel(g, 20f, 3f, 5f, 0f, alpha);
            g.FillEllipse(B(C(36, 80, 178, 0f, alpha)), -17.6f, 0.6f, 4.8f, 4.8f);
            g.FillEllipse(B(C(36, 80, 178, 0f, alpha)), 22.8f - 5f, 0.6f, 4.8f, 4.8f);
            Star(g, -20f, 3f, 3.2f, Color.FromArgb(A(255 * alpha), 255, 255, 255));
            Star(g, 20f, 3f, 3.2f, Color.FromArgb(A(255 * alpha), 255, 255, 255));
            g.FillEllipse(B(C(170, 230, 255, 0f, alpha)), -3f, -15f, 6f, 12f);
            g.DrawEllipse(P(line, 1f), -3f, -15f, 6f, 12f);
            g.FillEllipse(B(Color.FromArgb(A(150 * alpha), 255, 255, 255)), -1.8f, -13.5f, 2f, 5f);
        }
        g.FillEllipse(B(C(46, 50, 68, 0f, alpha)), -5.5f, -32f, 11f, 9f);
        Prop(g, 0f, -28f, 16f, time, 44f, alpha);

        if (muzzle)
        {
            g.FillEllipse(B(Color.FromArgb(A(210 * alpha), 255, 236, 140)), -18f, -16f, 8f, 12f);
            g.FillEllipse(B(Color.FromArgb(A(210 * alpha), 255, 236, 140)), 10f, -16f, 8f, 12f);
            g.FillEllipse(B(Color.FromArgb(A(255 * alpha), 255, 255, 255)), -16f, -13f, 4f, 6f);
            g.FillEllipse(B(Color.FromArgb(A(255 * alpha), 255, 255, 255)), 12f, -13f, 4f, 6f);
        }
        g.Restore(st);
    }

    // ------------------------------------------------------------------ enemies

    public void DrawEnemy(Graphics g, EnemyAircraft e, float time)
    {
        DrawEnemyShape(g, e.Type, e.X, e.Y, e.Bank, e.HitFlash > 0f ? 0.8f : 0f, time, 1f, true, 1f);
    }

    /// <summary>Draws one enemy type; facingDown mirrors it vertically (used in the game), the menu can turn it any way.</summary>
    public void DrawEnemyShape(Graphics g, EnemyType type, float x, float y, float bank, float fl, float time, float scale, bool facingDown, float alpha)
    {
        float hw = type == EnemyType.Bomber ? 72f : (type == EnemyType.Elite ? 46f : 23f);
        g.FillEllipse(B(Color.FromArgb(A(50 * alpha), 0, 20, 50)), x - hw * scale + 14f, y - 8f * scale + 22f, hw * 2f * scale, 26f * scale);

        GraphicsState st = g.Save();
        g.TranslateTransform(x, y);
        g.RotateTransform(facingDown ? -bank * 12f : bank * 12f);
        g.ScaleTransform(scale * (1f - 0.08f * Math.Abs(bank)), facingDown ? -scale : scale);
        switch (type)
        {
            case EnemyType.Fighter: DrawFighter(g, fl, time, alpha); break;
            case EnemyType.Interceptor: DrawInterceptor(g, fl, time, alpha); break;
            case EnemyType.Bomber: DrawBomber(g, fl, time, alpha); break;
            case EnemyType.Formation: DrawFormationPlane(g, fl, time, alpha); break;
            default: DrawElite(g, fl, time, alpha); break;
        }
        g.Restore(st);
    }

    private void DrawFighter(Graphics g, float fl, float time, float al)
    {
        Color line = C(24, 34, 20, 0f, al);
        Poly(g, FiTailL, C(74, 98, 54, fl, al), line, 1f);
        Poly(g, FiTailR, C(74, 98, 54, fl, al), line, 1f);
        Poly(g, FiWingL, C(78, 104, 56, fl, al), line, 1.2f);
        Poly(g, FiWingR, C(78, 104, 56, fl, al), line, 1.2f);
        g.DrawLine(P(C(120, 150, 84, fl, al), 1.4f), -6f, 0f, -21f, -1f);
        g.DrawLine(P(C(120, 150, 84, fl, al), 1.4f), 6f, 0f, 21f, -1f);
        Poly(g, FiFuse, C(92, 118, 64, fl, al), line, 1.3f);
        Roundel(g, -15f, 0.5f, 3.8f, fl, al);
        Roundel(g, 15f, 0.5f, 3.8f, fl, al);
        g.FillEllipse(B(C(36, 56, 66, fl, al)), -2.6f, -10f, 5.2f, 8f);
        g.FillEllipse(B(C(214, 120, 40, fl, al)), -4f, -24f, 8f, 5f);
        Prop(g, 0f, -22f, 10f, time, 40f, al);
    }

    private void DrawInterceptor(Graphics g, float fl, float time, float al)
    {
        Color line = C(30, 36, 30, 0f, al);
        Poly(g, InTailL, C(120, 140, 112, fl, al), line, 1f);
        Poly(g, InTailR, C(120, 140, 112, fl, al), line, 1f);
        Poly(g, InWingL, C(134, 156, 126, fl, al), line, 1.2f);
        Poly(g, InWingR, C(134, 156, 126, fl, al), line, 1.2f);
        g.DrawLine(P(C(240, 200, 60, fl, al), 2f), -5f, 0f, -18f, 7.5f);
        g.DrawLine(P(C(240, 200, 60, fl, al), 2f), 5f, 0f, 18f, 7.5f);
        Poly(g, InFuse, C(158, 176, 148, fl, al), line, 1.2f);
        Poly(g, InNose, C(232, 124, 32, fl, al), line, 0.8f);
        Roundel(g, -12f, 7.5f, 2.8f, fl, al);
        Roundel(g, 12f, 7.5f, 2.8f, fl, al);
        g.FillEllipse(B(C(30, 46, 56, fl, al)), -1.8f, -6f, 3.6f, 7f);
        Prop(g, 0f, -20f, 8f, time, 52f, al);
    }

    private void DrawBomber(Graphics g, float fl, float time, float al)
    {
        Color line = C(26, 34, 26, 0f, al);
        Poly(g, BoTailL, C(84, 100, 80, fl, al), line, 1.2f);
        Poly(g, BoTailR, C(84, 100, 80, fl, al), line, 1.2f);
        Poly(g, BoWingL, C(88, 104, 84, fl, al), line, 1.6f);
        Poly(g, BoWingR, C(88, 104, 84, fl, al), line, 1.6f);
        for (int k = -1; k <= 1; k += 2)
        {
            g.DrawLine(P(C(60, 74, 58, fl, al), 1.3f), k * 14f, -6f, k * 68f, -2f);
            g.DrawLine(P(C(60, 74, 58, fl, al), 1.3f), k * 14f, 5f, k * 68f, 3f);
            // engine nacelles
            g.FillEllipse(B(C(70, 84, 68, fl, al)), k * 34f - 7f, -26f, 14f, 44f);
            g.DrawEllipse(P(line, 1.3f), k * 34f - 7f, -26f, 14f, 44f);
            g.FillEllipse(B(C(46, 54, 46, fl, al)), k * 34f - 4.5f, -29f, 9f, 8f);
            Roundel(g, k * 54f, 1f, 6.5f, fl, al);
        }
        Poly(g, BoFuse, C(104, 120, 98, fl, al), line, 1.6f);
        g.FillEllipse(B(C(168, 214, 236, fl, al)), -6f, -42f, 12f, 17f);
        g.DrawEllipse(P(line, 1.2f), -6f, -42f, 12f, 17f);
        g.FillEllipse(B(C(52, 60, 52, fl, al)), -4.5f, -8f, 9f, 9f);
        g.FillEllipse(B(C(52, 60, 52, fl, al)), -4.5f, 26f, 9f, 9f);
        g.DrawLine(P(C(70, 82, 66, fl, al), 1.2f), -10f, 12f, 10f, 12f);
        Prop(g, -34f, -28f, 17f, time, 34f, al);
        Prop(g, 34f, -28f, 17f, time, 36f, al);
    }

    private void DrawFormationPlane(Graphics g, float fl, float time, float al)
    {
        Color line = C(70, 44, 20, 0f, al);
        Poly(g, FoTailL, C(214, 90, 42, fl, al), line, 1f);
        Poly(g, FoTailR, C(214, 90, 42, fl, al), line, 1f);
        Poly(g, FoWingL, C(196, 156, 88, fl, al), line, 1.2f);
        Poly(g, FoWingR, C(196, 156, 88, fl, al), line, 1.2f);
        g.DrawLine(P(C(236, 214, 150, fl, al), 1.5f), -6f, -1f, -20f, -4f);
        g.DrawLine(P(C(236, 214, 150, fl, al), 1.5f), 6f, -1f, 20f, -4f);
        Poly(g, FoFuse, C(212, 176, 100, fl, al), line, 1.3f);
        g.FillEllipse(B(C(70, 60, 50, fl, al)), -7.8f, 1f, 4f, 7f);
        g.FillEllipse(B(C(70, 60, 50, fl, al)), 3.8f, 1f, 4f, 7f);
        Roundel(g, -14f, -2.2f, 3.3f, fl, al);
        Roundel(g, 14f, -2.2f, 3.3f, fl, al);
        g.FillEllipse(B(C(40, 52, 60, fl, al)), -2.4f, -9f, 4.8f, 7f);
        g.FillRectangle(B(C(214, 90, 42, fl, al)), -4f, -17f, 8f, 3f);
        Prop(g, 0f, -19f, 9.5f, time, 42f, al);
    }

    private void DrawElite(Graphics g, float fl, float time, float al)
    {
        Color line = C(14, 16, 24, 0f, al);
        Color gold = C(232, 192, 62, fl, al);
        Poly(g, ElTail, C(58, 64, 82, fl, al), line, 1.3f);
        Poly(g, ElWingL, C(70, 76, 96, fl, al), line, 1.4f);
        Poly(g, ElWingR, C(70, 76, 96, fl, al), line, 1.4f);
        Poly(g, ElCenterWing, C(62, 68, 88, fl, al), line, 1.3f);
        g.DrawLine(P(gold, 1.8f), -26f, -6f, -45f, -3.5f);
        g.DrawLine(P(gold, 1.8f), 26f, -6f, 45f, -3.5f);
        Poly(g, ElBoomL, C(52, 58, 74, fl, al), line, 1.3f);
        Poly(g, ElBoomR, C(52, 58, 74, fl, al), line, 1.3f);
        g.FillRectangle(B(C(196, 34, 42, fl, al)), -27f, 6f, 7f, 4f);
        g.FillRectangle(B(C(196, 34, 42, fl, al)), 20f, 6f, 7f, 4f);
        g.FillRectangle(B(C(196, 34, 42, fl, al)), -27f, 14f, 7f, 4f);
        g.FillRectangle(B(C(196, 34, 42, fl, al)), 20f, 14f, 7f, 4f);
        Poly(g, ElPod, C(76, 84, 106, fl, al), line, 1.5f);
        g.DrawLine(P(gold, 2f), 0f, -22f, 0f, 20f);
        g.FillEllipse(B(C(120, 230, 255, fl, al)), -3.5f, -14f, 7f, 13f);
        g.DrawEllipse(P(line, 1f), -3.5f, -14f, 7f, 13f);
        Roundel(g, -38f, 0f, 4.5f, fl, al);
        Roundel(g, 38f, 0f, 4.5f, fl, al);
        float glow = 0.55f + 0.45f * MathF.Sin(time * 9f);
        g.FillEllipse(B(Color.FromArgb(A(200 * glow * al), 255, 90, 40)), -26.5f, 28f, 6f, 6f);
        g.FillEllipse(B(Color.FromArgb(A(200 * glow * al), 255, 90, 40)), 20.5f, 28f, 6f, 6f);
        Prop(g, -23.5f, -22f, 11f, time, 38f, al);
        Prop(g, 23.5f, -22f, 11f, time, 40f, al);
    }

    // ------------------------------------------------------------------ boss

    public void DrawBoss(Graphics g, Boss b, float time)
    {
        float fl = b.HitFlash > 0f ? 0.7f : 0f;
        float alpha = 1f;
        g.FillEllipse(B(Color.FromArgb(55, 0, 20, 50)), b.X - 130f + 26f, b.Y - 30f + 40f, 260f, 80f);

        GraphicsState st = g.Save();
        g.TranslateTransform(b.X, b.Y);
        float wobble = b.Dying ? MathF.Sin(time * 40f) * 2f : 0f;
        g.TranslateTransform(wobble, 0f);
        Color line = C(18, 24, 20, 0f, alpha);
        Color hull = C(70, 84, 74, fl, alpha);
        Color hull2 = C(92, 110, 86, fl, alpha);

        // exhaust flames at the rear (up, because the boss faces down)
        float flick = 0.7f + 0.3f * MathF.Sin(time * 30f);
        float[] ex = { -92f, -24f, 24f, 92f };
        float[] ey = { -34f, -70f, -70f, -34f };
        for (int i = 0; i < 4; i++)
        {
            g.FillEllipse(B(Color.FromArgb(A(230 * flick), 255, 150, 40)), ex[i] - 7f, ey[i] - 36f * flick - 14f, 14f, 38f * flick);
            g.FillEllipse(B(Color.FromArgb(A(240 * flick), 255, 240, 160)), ex[i] - 3.5f, ey[i] - 22f * flick - 12f, 7f, 22f * flick);
        }

        Poly(g, BossWingL, hull, line, 2f);
        Poly(g, BossWingR, hull, line, 2f);
        for (int k = -1; k <= 1; k += 2)
        {
            g.DrawLine(P(C(50, 62, 54, fl, alpha), 1.6f), k * 56f, -18f, k * 132f, -2f);
            g.DrawLine(P(C(50, 62, 54, fl, alpha), 1.6f), k * 56f, 6f, k * 134f, 14f);
            // engines
            g.FillEllipse(B(C(50, 58, 54, fl, alpha)), k * 92f - 10f, -34f, 20f, 52f);
            g.DrawEllipse(P(line, 1.6f), k * 92f - 10f, -34f, 20f, 52f);
            g.FillEllipse(B(C(50, 58, 54, fl, alpha)), k * 24f - 10f, -70f, 20f, 52f);
            // wing pods and side cannons
            bool launching = b.Current == BossPattern.Missiles;
            g.FillRectangle(B(C(40, 46, 44, fl, alpha)), k * 120f - 6f, 8f, 12f, 26f);
            g.FillEllipse(B(launching ? Color.FromArgb(255, 255, 80, 40) : C(190, 40, 40, fl, alpha)), k * 120f - 4f, 28f, 8f, 8f);
            g.FillEllipse(B(C(40, 46, 44, fl, alpha)), k * 95f - 7f, 28f, 14f, 14f);
            g.FillRectangle(B(C(24, 28, 28, fl, alpha)), k * 95f - 2f, 38f, 4f, 12f);
            Roundel(g, k * 78f, 10f, 12f, fl, alpha);
            g.FillRectangle(B(C(240, 240, 236, fl, alpha)), k * 60f - 3f, -10f, 6f, 30f);
        }
        Poly(g, BossBody, hull2, line, 2.4f);
        g.DrawLine(P(C(56, 68, 58, fl, alpha), 2f), -40f, -40f, 40f, -40f);
        g.DrawLine(P(C(56, 68, 58, fl, alpha), 2f), -44f, -8f, 44f, -8f);
        g.DrawLine(P(C(56, 68, 58, fl, alpha), 2f), -34f, 30f, 34f, 30f);
        g.DrawLine(P(C(56, 68, 58, fl, alpha), 2f), 0f, -70f, 0f, 78f);

        // central turret dome, glowing while the boss is attacking
        bool attacking = b.Current != BossPattern.Rest && !b.Entering;
        float pulse = 0.6f + 0.4f * MathF.Sin(time * (attacking ? 12f : 4f));
        g.FillEllipse(B(C(40, 46, 44, fl, alpha)), -26f, -16f, 52f, 52f);
        g.FillEllipse(B(Color.FromArgb(A(120 + 130 * pulse), 255, 80, 50)), -19f, -9f, 38f, 38f);
        g.FillEllipse(B(Color.FromArgb(A(180 + 70 * pulse), 255, 200, 130)), -10f, 0f, 20f, 20f);
        g.DrawEllipse(P(line, 2f), -26f, -16f, 52f, 52f);
        g.FillRectangle(B(C(26, 30, 30, fl, alpha)), -4f, 28f, 8f, 22f);

        // blinking warning lights; later phases show damage
        bool blink = ((int)(time * 4f) & 1) == 0;
        for (int k = -1; k <= 1; k += 2)
        {
            g.FillEllipse(B(blink ? Color.FromArgb(255, 255, 60, 50) : Color.FromArgb(255, 110, 24, 24)), k * 40f - 3f, 52f, 6f, 6f);
        }
        if (b.Phase >= 2)
        {
            g.FillEllipse(B(Color.FromArgb(150, 20, 20, 20)), -70f, -20f, 30f, 22f);
            g.FillEllipse(B(Color.FromArgb(120, 255, 120, 30)), -62f, -14f, 12f, 9f);
        }
        if (b.Phase >= 3)
        {
            g.FillEllipse(B(Color.FromArgb(150, 20, 20, 20)), 44f, 14f, 36f, 24f);
            g.FillEllipse(B(Color.FromArgb(130, 255, 120, 30)), 55f, 21f, 14f, 10f);
        }
        g.Restore(st);
    }

    // ------------------------------------------------------------------ bonuses

    public void DrawBonus(Graphics g, Bonus b, float time)
    {
        float spin = MathF.Cos(b.Age * 3.2f);
        float sx = 0.62f + 0.38f * Math.Abs(spin);
        float pulse = 0.6f + 0.4f * MathF.Sin(b.Age * 6f);
        Color baseC, rim;
        switch (b.Type)
        {
            case BonusType.Weapon: baseC = Color.FromArgb(214, 36, 36); rim = Color.FromArgb(255, 120, 100); break;
            case BonusType.Life: baseC = Color.FromArgb(40, 160, 76); rim = Color.FromArgb(150, 255, 170); break;
            case BonusType.Score: baseC = Color.FromArgb(226, 150, 24); rim = Color.FromArgb(255, 230, 120); break;
            case BonusType.Shield: baseC = Color.FromArgb(30, 84, 200); rim = Color.FromArgb(140, 200, 255); break;
            default: baseC = Color.FromArgb(190, 140, 20); rim = Color.FromArgb(255, 226, 110); break;
        }
        g.FillEllipse(B(Color.FromArgb(A(55 * pulse), rim.R, rim.G, rim.B)), b.X - 28f, b.Y - 28f, 56f, 56f);
        g.FillEllipse(B(Color.FromArgb(A(40 * pulse), rim.R, rim.G, rim.B)), b.X - 36f, b.Y - 36f, 72f, 72f);

        GraphicsState st = g.Save();
        g.TranslateTransform(b.X, b.Y);
        g.ScaleTransform(sx, 1f);
        const float r = Bonus.Radius;
        g.FillEllipse(B(baseC), -r, -r, r * 2f, r * 2f);
        g.FillEllipse(B(Color.FromArgb(70, 255, 255, 255)), -r * 0.7f, -r * 0.9f, r * 1.2f, r * 0.8f);
        g.DrawEllipse(P(rim, 3f), -r, -r, r * 2f, r * 2f);
        g.DrawEllipse(P(Color.FromArgb(255, 20, 20, 30), 1.2f), -r - 1.5f, -r - 1.5f, r * 2f + 3f, r * 2f + 3f);
        switch (b.Type)
        {
            case BonusType.Weapon:
                for (int k = 0; k < 2; k++)
                {
                    float yy = -2f + k * 8f;
                    quad[0] = new PointF(-9f, yy + 2f);
                    quad[1] = new PointF(0f, yy - 7f);
                    quad[2] = new PointF(9f, yy + 2f);
                    quad[3] = new PointF(0f, yy - 2f);
                    g.FillPolygon(B(Color.FromArgb(255, 255, 214, 60)), quad);
                }
                break;
            case BonusType.Life:
                g.FillEllipse(B(Color.White), -2f, -11f, 4f, 22f);
                g.FillRectangle(B(Color.White), -11f, -3f, 22f, 4.5f);
                g.FillRectangle(B(Color.White), -5f, 7f, 10f, 3f);
                break;
            case BonusType.Score:
                g.DrawString("$", fBonus, B(Color.White), 0f, 1f, sfCenter);
                break;
            case BonusType.Shield:
                Star(g, 0f, 1f, 11f, Color.White);
                break;
            default:
                g.DrawString("B", fBonus, B(Color.FromArgb(255, 255, 250, 200)), 0f, 1f, sfCenter);
                break;
        }
        g.Restore(st);
    }

    // ------------------------------------------------------------------ projectiles

    public void DrawProjectile(Graphics g, Projectile p)
    {
        float sp = MathF.Sqrt(p.VX * p.VX + p.VY * p.VY);
        float nx = sp > 0.01f ? p.VX / sp : 0f;
        float ny = sp > 0.01f ? p.VY / sp : 1f;
        switch (p.Kind)
        {
            case ShotKind.PlayerBullet:
                g.DrawLine(P(Color.FromArgb(110, 90, 190, 255), 8f), p.X - nx * 9f, p.Y - ny * 9f, p.X + nx * 9f, p.Y + ny * 9f);
                g.DrawLine(P(Color.FromArgb(255, 150, 220, 255), 4.5f), p.X - nx * 8f, p.Y - ny * 8f, p.X + nx * 8f, p.Y + ny * 8f);
                g.DrawLine(P(Color.White, 2f), p.X - nx * 6f, p.Y - ny * 6f, p.X + nx * 6f, p.Y + ny * 6f);
                break;
            case ShotKind.EnemySmall:
                g.DrawLine(P(Color.FromArgb(120, 255, 80, 30), 9f), p.X - nx * 8f, p.Y - ny * 8f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.FromArgb(255, 255, 110, 40), 6f), p.X - nx * 7f, p.Y - ny * 7f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.FromArgb(255, 255, 230, 120), 3f), p.X - nx * 4f, p.Y - ny * 4f, p.X + nx * 4f, p.Y + ny * 4f);
                break;
            case ShotKind.EnemyHeavy:
                g.FillEllipse(B(Color.FromArgb(110, 255, 70, 30)), p.X - 11f, p.Y - 11f, 22f, 22f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 100, 40)), p.X - 7.5f, p.Y - 7.5f, 15f, 15f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 220, 110)), p.X - 4f, p.Y - 4f, 8f, 8f);
                break;
            case ShotKind.Missile:
                g.FillEllipse(B(Color.FromArgb(200, 255, 170, 50)), p.X - 4.5f, p.Y - 16f, 9f, 16f);
                g.FillEllipse(B(Color.FromArgb(230, 255, 240, 160)), p.X - 2.5f, p.Y - 12f, 5f, 10f);
                g.DrawLine(P(Color.FromArgb(255, 150, 156, 166), 5f), p.X - nx * 2f, p.Y - ny * 2f, p.X + nx * 9f, p.Y + ny * 9f);
                g.FillEllipse(B(Color.FromArgb(255, 220, 40, 40)), p.X + nx * 9f - 3f, p.Y + ny * 9f - 3f, 6f, 6f);
                break;
            default:    // boss orb
                g.FillEllipse(B(Color.FromArgb(90, 255, 70, 140)), p.X - 17f, p.Y - 17f, 34f, 34f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 70, 130)), p.X - 11f, p.Y - 11f, 22f, 22f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 170, 200)), p.X - 6.5f, p.Y - 6.5f, 13f, 13f);
                g.FillEllipse(B(Color.White), p.X - 3f, p.Y - 3f, 6f, 6f);
                break;
        }
    }

    // ------------------------------------------------------------------ explosions and particles

    public void DrawExplosion(Graphics g, Explosion e)
    {
        if (e.Age < 0f) return;
        float t = e.Progress;
        float ease = 1f - (1f - t) * (1f - t);
        float r = e.Size * (0.3f + 0.7f * ease);
        float fade = 1f - t;
        if (t > 0.45f)
        {
            float s = (t - 0.45f) / 0.55f;
            g.FillEllipse(B(Color.FromArgb(A(120 * (1f - s)), 50, 50, 56)), e.X - r * 1.15f, e.Y - r * 1.15f, r * 2.3f, r * 2.3f);
        }
        g.FillEllipse(B(Color.FromArgb(A(230 * fade), 255, 100, 30)), e.X - r, e.Y - r, r * 2f, r * 2f);
        g.FillEllipse(B(Color.FromArgb(A(240 * fade), 255, 180, 50)), e.X - r * 0.72f, e.Y - r * 0.72f, r * 1.44f, r * 1.44f);
        float core = r * 0.5f * fade;
        g.FillEllipse(B(Color.FromArgb(A(255 * fade * fade + 20), 255, 250, 210)), e.X - core, e.Y - core, core * 2f, core * 2f);
        if (e.Kind != ExplosionKind.Small)
        {
            float rr = e.Size * (0.4f + 1.3f * t);
            g.DrawEllipse(P(Color.FromArgb(A(200 * fade), 255, 230, 170), 3f), e.X - rr, e.Y - rr, rr * 2f, rr * 2f);
        }
    }

    public void DrawParticles(Graphics g, ParticleSystem ps)
    {
        for (int i = 0; i < ps.Count; i++)
        {
            Particle p = ps.Items[i];
            float k = p.Life / p.MaxLife;
            switch (p.Kind)
            {
                case 0:
                    {
                        float r = p.Size * (1f + (1f - k) * 1.4f);
                        g.FillEllipse(B(Color.FromArgb(A(130 * k), p.R, p.G, p.B)), p.X - r, p.Y - r, r * 2f, r * 2f);
                        break;
                    }
                case 1:
                    {
                        float vx = p.VX * 0.03f;
                        float vy = p.VY * 0.03f;
                        g.DrawLine(P(Color.FromArgb(A(255 * k), p.R, p.G, p.B), p.Size), p.X, p.Y, p.X - vx, p.Y - vy);
                        break;
                    }
                case 2:
                    {
                        float c = MathF.Cos(p.Rot) * p.Size;
                        float s = MathF.Sin(p.Rot) * p.Size;
                        quad[0] = new PointF(p.X - c - s * 0.5f, p.Y - s + c * 0.5f);
                        quad[1] = new PointF(p.X + c - s * 0.5f, p.Y + s + c * 0.5f);
                        quad[2] = new PointF(p.X + c + s * 0.5f, p.Y + s - c * 0.5f);
                        quad[3] = new PointF(p.X - c + s * 0.5f, p.Y - s - c * 0.5f);
                        g.FillPolygon(B(Color.FromArgb(A(255 * Math.Min(1f, k * 2f)), p.R, p.G, p.B)), quad);
                        break;
                    }
                case 3:
                    {
                        float r = p.Size * (1f - k);
                        g.DrawEllipse(P(Color.FromArgb(A(220 * k), p.R, p.G, p.B), 3f), p.X - r, p.Y - r, r * 2f, r * 2f);
                        break;
                    }
                default:
                    {
                        float r = p.Size * k;
                        g.FillEllipse(B(Color.FromArgb(A(220 * k), p.R, p.G, p.B)), p.X - r, p.Y - r, r * 2f, r * 2f);
                        break;
                    }
            }
        }
        foreach (FloatText t in ps.Texts)
        {
            float a = Math.Min(1f, t.Life * 2f);
            g.DrawString(t.Text, fText, B(Color.FromArgb(A(200 * a), 0, 0, 0)), t.X + 1f, t.Y + 1f, sfCenter);
            g.DrawString(t.Text, fText, B(Color.FromArgb(A(255 * a), t.Color.R, t.Color.G, t.Color.B)), t.X, t.Y, sfCenter);
        }
    }
}
