namespace AirCombat;

/// <summary>All tunable numbers of the game in one place (pixels and seconds).</summary>
public static class GameConfig
{
    // ---- layout (logical pixels, portrait)
    public const int LogicalW = 640;
    public const int LogicalH = 800;
    public const int FooterH = 32;
    public const int ViewH = LogicalH - FooterH;     // height of the battlefield: 768

    // ---- player
    public const float PlayerStartX = 320f;
    public const float PlayerStartY = 650f;
    public const float PlayerHitRadius = 9f;
    public const float PlayerMaxSpeed = 300f;
    public const float PlayerAccel = 2600f;
    public const float PlayerDecel = 2200f;
    public const float PlayerMinY = 250f;
    public const int StartLives = 3;
    public const int MaxLives = 9;
    public const float FireInterval1 = 0.115f;
    public const float FireInterval3 = 0.100f;
    public const float PlayerBulletSpeed = 840f;
    public const float RollDuration = 0.45f;
    public const float RollCooldown = 2.2f;
    public const float RespawnDelay = 1.2f;
    public const float RespawnInvulnerability = 2.5f;
    public const float ShieldDuration = 10f;

    // ---- stage
    public const float ScrollSpeed = 60f;
    public const float BossWarningTime = 133f;
    public const float BossArrivalTime = 137f;
    public const float StageLengthTime = 137f;       // used for the progress bar

    // ---- score
    public const int ScoreFighter = 100;
    public const int ScoreInterceptor = 150;
    public const int ScoreBomber = 500;
    public const int ScoreFormation = 200;
    public const int ScoreFormationBonus = 1000;
    public const int ScoreElite = 800;
    public const int ScoreBoss = 10000;
    public const int ScoreBonusPickup = 250;
    public const int ScoreBonusItem = 1000;

    public const int BossMaxHp = 520;
    public const float BombEnemyDamage = 30f;
    public const float BombBossDamage = 40f;
}
