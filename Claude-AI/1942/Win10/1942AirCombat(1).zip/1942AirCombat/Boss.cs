namespace AirCombat;

public enum BossPattern { Fan, Streams, Ring, Missiles, Spiral, Rest }

/// <summary>
/// The final boss, a huge experimental flying wing. Three phases (by remaining health) with their own attack
/// sequences: aimed fans, twin streams, expanding rings, missile pods and rotating spirals. Every sequence ends in
/// a short rest so the player always has time to reposition.
/// </summary>
public sealed class Boss
{
    public bool Active;
    public bool Entering;
    public bool Dying;
    public float X, Y, Hp, MaxHp, Age, HitFlash, DeathTimer;
    public int Phase = 1;
    public BossPattern Current = BossPattern.Rest;

    // events read by the engine every step
    public bool EvFired, EvPhaseChanged, EvDeathBlast, EvDefeated;

    private float patternAge, patternDur, attackTimer, spiralAngle, spiralTimer, ringPhase, blastTimer;
    private int seqIndex;
    private readonly Random rng = new Random();

    private static readonly RectangleF Body = new RectangleF(-52f, -70f, 104f, 150f);
    private static readonly RectangleF Wings = new RectangleF(-135f, -22f, 270f, 50f);

    private static readonly BossPattern[][] Sequences =
    {
        new[] { BossPattern.Fan, BossPattern.Streams, BossPattern.Fan, BossPattern.Rest },
        new[] { BossPattern.Ring, BossPattern.Missiles, BossPattern.Streams, BossPattern.Fan, BossPattern.Rest },
        new[] { BossPattern.Spiral, BossPattern.Fan, BossPattern.Ring, BossPattern.Missiles, BossPattern.Rest }
    };

    public float HealthFraction { get { return MaxHp <= 0f ? 0f : Math.Max(0f, Hp) / MaxHp; } }
    public bool Vulnerable { get { return Active && !Entering && !Dying; } }

    public void Reset()
    {
        Active = false;
        Entering = false;
        Dying = false;
        Phase = 1;
        HitFlash = 0f;
    }

    public void Spawn()
    {
        Active = true;
        Entering = true;
        Dying = false;
        MaxHp = GameConfig.BossMaxHp;
        Hp = MaxHp;
        X = GameConfig.LogicalW / 2f;
        Y = -150f;
        Age = 0f;
        Phase = 1;
        seqIndex = -1;
        Current = BossPattern.Rest;
        patternAge = 0f;
        patternDur = 0.8f;
        HitFlash = 0f;
        DeathTimer = 0f;
        spiralAngle = 0f;
        ringPhase = 0f;
    }

    public bool Hits(float cx, float cy, float r)
    {
        float lx = cx - X;
        float ly = cy - Y;
        return CircleRect(lx, ly, r, Body) || CircleRect(lx, ly, r, Wings);
    }

    private static bool CircleRect(float cx, float cy, float r, RectangleF rc)
    {
        float nx = Math.Max(rc.Left, Math.Min(cx, rc.Right));
        float ny = Math.Max(rc.Top, Math.Min(cy, rc.Bottom));
        float dx = cx - nx;
        float dy = cy - ny;
        return dx * dx + dy * dy <= r * r;
    }

    public void Damage(float amount)
    {
        if (!Vulnerable) return;
        Hp -= amount;
        HitFlash = 0.08f;
        if (Hp <= 0f)
        {
            Hp = 0f;
            Dying = true;
            DeathTimer = 0f;
            blastTimer = 0f;
        }
    }

    private void NextPattern()
    {
        BossPattern[] seq = Sequences[Phase - 1];
        seqIndex = (seqIndex + 1) % seq.Length;
        Current = seq[seqIndex];
        patternAge = 0f;
        attackTimer = 0.3f;
        spiralTimer = 0f;
        switch (Current)
        {
            case BossPattern.Fan: patternDur = 2.6f; break;
            case BossPattern.Streams: patternDur = 2.4f; break;
            case BossPattern.Ring: patternDur = 3.0f; break;
            case BossPattern.Missiles: patternDur = 2.4f; break;
            case BossPattern.Spiral: patternDur = 3.2f; break;
            default: patternDur = 1.0f; break;
        }
    }

    public void Update(float dt, float px, float py, ProjectileManager shots, ExplosionManager expl, ParticleSystem parts)
    {
        EvFired = false;
        EvPhaseChanged = false;
        EvDeathBlast = false;
        EvDefeated = false;
        if (!Active) return;

        Age += dt;
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);

        if (Dying)
        {
            DeathTimer += dt;
            blastTimer -= dt;
            if (blastTimer <= 0f)
            {
                blastTimer = 0.11f;
                float ex = X + (float)(rng.NextDouble() * 240.0 - 120.0);
                float ey = Y + (float)(rng.NextDouble() * 120.0 - 60.0);
                bool large = rng.Next(4) == 0;
                expl.Add(ex, ey, large ? ExplosionKind.Large : ExplosionKind.Small);
                parts.Flames(ex, ey, 10f, 3);
                parts.Smoke(ex, ey, 0f, -30f, 14f, 1.2f, 50);
                if (large) EvDeathBlast = true;
            }
            if (DeathTimer >= 3.4f)
            {
                expl.Add(X, Y, ExplosionKind.Boss);
                expl.Add(X - 70f, Y + 10f, ExplosionKind.Large, 0.15f);
                expl.Add(X + 70f, Y - 10f, ExplosionKind.Large, 0.25f);
                parts.Debris(X, Y, 40, Color.FromArgb(70, 80, 70));
                Active = false;
                EvDefeated = true;
            }
            return;
        }

        if (Entering)
        {
            float k = Math.Min(1f, Age / 3.2f);
            float e = k * k * (3f - 2f * k);
            X = GameConfig.LogicalW / 2f;
            Y = -150f + 300f * e;
            if (k >= 1f)
            {
                Entering = false;
                Age = 0f;
                NextPattern();
            }
            return;
        }

        // movement: a wide slow sweep, faster in later phases
        float amp = 150f + 20f * Phase;
        float speed = 0.45f + 0.15f * Phase;
        X = GameConfig.LogicalW / 2f + amp * MathF.Sin(Age * speed);
        Y = 150f + 14f * MathF.Sin(Age * 1.1f);

        // phase changes by remaining health
        float frac = HealthFraction;
        int newPhase = frac > 0.66f ? 1 : (frac > 0.33f ? 2 : 3);
        if (newPhase > Phase)
        {
            Phase = newPhase;
            EvPhaseChanged = true;
            seqIndex = -1;
            Current = BossPattern.Rest;
            patternAge = 0f;
            patternDur = 1.6f;
            attackTimer = 1f;
            return;
        }

        patternAge += dt;
        if (patternAge >= patternDur) NextPattern();

        switch (Current)
        {
            case BossPattern.Fan:
                attackTimer -= dt;
                if (attackTimer <= 0f)
                {
                    shots.FireFan(ShotKind.BossOrb, X, Y + 50f, px, py, 240f, Phase == 1 ? 5 : 7, Phase == 1 ? 0.9f : 1.25f);
                    attackTimer = 0.85f;
                    EvFired = true;
                }
                break;
            case BossPattern.Streams:
                attackTimer -= dt;
                if (attackTimer <= 0f)
                {
                    shots.SpawnEnemy(ShotKind.EnemySmall, X - 95f, Y + 36f, 0f, 300f);
                    shots.SpawnEnemy(ShotKind.EnemySmall, X + 95f, Y + 36f, 0f, 300f);
                    attackTimer = Phase == 3 ? 0.13f : 0.17f;
                    EvFired = true;
                }
                break;
            case BossPattern.Ring:
                attackTimer -= dt;
                if (attackTimer <= 0f)
                {
                    shots.FireRing(ShotKind.EnemyHeavy, X, Y + 30f, Phase == 2 ? 16 : 20, 150f, ringPhase);
                    ringPhase += 0.17f;
                    attackTimer = 1.5f;
                    EvFired = true;
                }
                break;
            case BossPattern.Missiles:
                attackTimer -= dt;
                if (attackTimer <= 0f)
                {
                    Projectile a = shots.SpawnEnemy(ShotKind.Missile, X - 120f, Y + 20f, -30f, 100f);
                    Projectile b = shots.SpawnEnemy(ShotKind.Missile, X + 120f, Y + 20f, 30f, 100f);
                    a.AY = 280f;
                    b.AY = 280f;
                    attackTimer = 0.9f;
                    EvFired = true;
                }
                break;
            case BossPattern.Spiral:
                spiralTimer -= dt;
                if (spiralTimer <= 0f)
                {
                    shots.SpawnEnemy(ShotKind.EnemyHeavy, X, Y + 40f, MathF.Cos(spiralAngle) * 185f, MathF.Sin(spiralAngle) * 185f);
                    shots.SpawnEnemy(ShotKind.EnemyHeavy, X, Y + 40f, MathF.Cos(spiralAngle + MathF.PI) * 185f, MathF.Sin(spiralAngle + MathF.PI) * 185f);
                    spiralAngle += 0.33f;
                    spiralTimer = 0.085f;
                    EvFired = true;
                }
                break;
        }
    }
}
