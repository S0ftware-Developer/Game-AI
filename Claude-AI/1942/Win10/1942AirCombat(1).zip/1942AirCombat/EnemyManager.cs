namespace AirCombat;

public struct SpawnEvent
{
    public float T;
    public EnemyType Type;
    public float X, Amp, Freq, Phase, OffX, OffY;
    public int Group;
}

/// <summary>The scripted wave timeline of the stage, plus ownership and updating of all enemy aircraft.</summary>
public sealed class EnemyManager
{
    public readonly List<EnemyAircraft> Enemies = new List<EnemyAircraft>(48);
    public Action<EnemyAircraft>? Killed;        // an enemy was shot down
    public Action<EnemyAircraft>? GroupWiped;    // the last plane of a formation was shot down

    private readonly List<SpawnEvent> script = new List<SpawnEvent>(128);
    private readonly Stack<EnemyAircraft> pool = new Stack<EnemyAircraft>();
    private readonly Dictionary<int, int> groupTotal = new Dictionary<int, int>();
    private readonly Dictionary<int, int> groupKilled = new Dictionary<int, int>();
    private readonly Random rng = new Random();
    private int next;

    public bool ScriptDone { get { return next >= script.Count; } }

    public int ActiveCount
    {
        get
        {
            int n = 0;
            foreach (EnemyAircraft e in Enemies)
            {
                if (e.Alive) n++;
            }
            return n;
        }
    }

    public void Reset()
    {
        foreach (EnemyAircraft e in Enemies) pool.Push(e);
        Enemies.Clear();
        script.Clear();
        groupTotal.Clear();
        groupKilled.Clear();
        next = 0;
        BuildScript();
    }

    // ------------------------------------------------------------------ the stage script

    private void Add(float t, EnemyType type, float x, float amp = 0f, float freq = 0f, float phase = 0f, int group = -1, float offX = 0f, float offY = 0f)
    {
        SpawnEvent s = new SpawnEvent();
        s.T = t; s.Type = type; s.X = x; s.Amp = amp; s.Freq = freq; s.Phase = phase; s.Group = group; s.OffX = offX; s.OffY = offY;
        script.Add(s);
        if (group >= 0)
        {
            int n;
            groupTotal.TryGetValue(group, out n);
            groupTotal[group] = n + 1;
        }
    }

    private void Vee(float t, float x, float amp, float freq, float phase, int group)
    {
        Add(t, EnemyType.Formation, x, amp, freq, phase, group, 0f, 0f);
        Add(t, EnemyType.Formation, x, amp, freq, phase, group, -42f, -34f);
        Add(t, EnemyType.Formation, x, amp, freq, phase, group, 42f, -34f);
        Add(t, EnemyType.Formation, x, amp, freq, phase, group, -84f, -68f);
        Add(t, EnemyType.Formation, x, amp, freq, phase, group, 84f, -68f);
    }

    private void Fighters(float t, float step, params float[] xs)
    {
        for (int i = 0; i < xs.Length; i++) Add(t + i * step, EnemyType.Fighter, xs[i]);
    }

    private void Wavy(float t, float step, float amp, params float[] xs)
    {
        for (int i = 0; i < xs.Length; i++) Add(t + i * step, EnemyType.Fighter, xs[i], amp, 2f, 0f);
    }

    private void BuildScript()
    {
        // phase 1: open ocean - easy fighters, the first interceptors, the first formation
        Fighters(2f, 0.6f, 160f, 320f, 480f);
        Wavy(8f, 0.5f, 90f, 200f, 260f, 320f, 380f);
        Add(14f, EnemyType.Interceptor, 60f);
        Add(15f, EnemyType.Interceptor, 580f);
        Vee(20f, 320f, 120f, 0.8f, 0f, 1);
        Fighters(27f, 0.4f, 100f, 540f);
        Fighters(28.5f, 0f, 320f);

        // phase 2: islands - a bomber, interceptor runs, two formations
        Add(33f, EnemyType.Bomber, 320f);
        Fighters(35f, 0.5f, 150f, 320f, 490f);
        Add(40f, EnemyType.Interceptor, 100f);
        Add(40.6f, EnemyType.Interceptor, 320f);
        Add(41.2f, EnemyType.Interceptor, 540f);
        Vee(46f, 190f, 60f, 0.9f, 0f, 2);
        Vee(49f, 450f, 60f, 0.9f, 3.14f, 3);
        Add(56f, EnemyType.Bomber, 180f);
        Wavy(58f, 0.5f, 100f, 420f, 360f, 300f, 240f);

        // phase 3: coast and countryside - the first elites
        Add(64f, EnemyType.Elite, 320f);
        Fighters(70f, 0.5f, 120f, 250f, 390f, 520f);
        Add(73f, EnemyType.Interceptor, 80f);
        Add(73.5f, EnemyType.Interceptor, 560f);
        Vee(78f, 320f, 150f, 0.7f, 0f, 4);
        Add(84f, EnemyType.Bomber, 170f);
        Add(86f, EnemyType.Bomber, 470f);
        Add(92f, EnemyType.Elite, 200f);
        Fighters(94f, 0.5f, 400f, 300f, 200f);

        // phase 4: enemy installations and the airfield - everything together
        Vee(98f, 190f, 60f, 0.9f, 0f, 5);
        Vee(100f, 450f, 60f, 0.9f, 3.14f, 6);
        Add(106f, EnemyType.Elite, 420f);
        Add(110f, EnemyType.Elite, 220f);
        for (int i = 0; i < 5; i++) Add(114f + i * 0.6f, EnemyType.Interceptor, (i % 2 == 0) ? 70f : 570f);
        Add(120f, EnemyType.Bomber, 320f);
        Wavy(122f, 0.5f, 100f, 200f, 280f, 360f, 440f);
        Vee(128f, 320f, 160f, 0.7f, 0f, 7);
        Add(130f, EnemyType.Elite, 320f);
    }

    // ------------------------------------------------------------------ simulation

    public void Update(float dt, float stageTime, PlayerAircraft player, float diff, ProjectileManager shots, ParticleSystem parts, out bool anyFired)
    {
        anyFired = false;
        while (next < script.Count && script[next].T <= stageTime)
        {
            SpawnEvent s = script[next++];
            EnemyAircraft e = pool.Count > 0 ? pool.Pop() : new EnemyAircraft();
            e.Init(s.Type, s.X, s.Amp, s.Freq, s.Phase, s.Group, s.OffX, s.OffY, diff, rng);
            Enemies.Add(e);
        }

        float px = player.Alive ? player.X : GameConfig.PlayerStartX;
        float py = player.Alive ? player.Y : GameConfig.PlayerStartY;
        for (int i = Enemies.Count - 1; i >= 0; i--)
        {
            EnemyAircraft e = Enemies[i];
            if (e.Alive)
            {
                bool fired;
                e.Update(dt, px, py, diff, shots, rng, out fired);
                if (fired) anyFired = true;
                if (e.Smoking)
                {
                    e.SmokeTimer -= dt;
                    if (e.SmokeTimer <= 0f)
                    {
                        e.SmokeTimer = 0.07f;
                        parts.Smoke(e.X + (float)(rng.NextDouble() * 6.0 - 3.0), e.Y - 8f, 0f, -20f, 7f, 0.8f, 40);
                    }
                }
                if (e.Y > GameConfig.ViewH + 110f || e.Y < -300f) e.Alive = false;
            }
            if (!e.Alive)
            {
                Enemies[i] = Enemies[Enemies.Count - 1];
                Enemies.RemoveAt(Enemies.Count - 1);
                pool.Push(e);
            }
        }
    }

    /// <summary>Applies damage; destroys the enemy and reports it when its durability is used up.</summary>
    public void DamageEnemy(EnemyAircraft e, float amount)
    {
        if (!e.Alive) return;
        e.Damage(amount);
        if (e.Hp > 0f) return;
        e.Alive = false;
        if (e.Group >= 0)
        {
            int k;
            groupKilled.TryGetValue(e.Group, out k);
            k++;
            groupKilled[e.Group] = k;
            int total;
            if (groupTotal.TryGetValue(e.Group, out total) && k >= total) GroupWiped?.Invoke(e);
        }
        Killed?.Invoke(e);
    }

    /// <summary>The bomb bonus: damages every enemy that is currently on the screen.</summary>
    public void BombAll(float damage)
    {
        foreach (EnemyAircraft e in Enemies)
        {
            if (e.Alive && e.Y > -20f && e.Y < GameConfig.ViewH + 20f) DamageEnemy(e, damage);
        }
    }
}
