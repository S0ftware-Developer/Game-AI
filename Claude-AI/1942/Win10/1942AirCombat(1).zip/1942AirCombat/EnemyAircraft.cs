namespace AirCombat;

public enum EnemyType { Fighter, Interceptor, Bomber, Formation, Elite }

/// <summary>
/// One enemy aircraft. Each type has its own movement path, durability and attack pattern; the numbers grow a little
/// with the difficulty value (0..1 over the stage).
/// </summary>
public sealed class EnemyAircraft
{
    public EnemyType Type;
    public float X, Y, VX, VY;
    public float Hp, MaxHp;
    public float HitW, HitH;
    public float Age;
    public float HitFlash;
    public float SmokeTimer;
    public float Bank;               // -1..1 for drawing
    public bool Alive;
    public int Score;
    public int Group = -1;

    private float startX, amp, freq, phase, offX, offY, dir;
    private float shootTimer, burstTimer, stateTimer;
    private int burstLeft, pattern, leg;

    public bool Smoking { get { return Hp < MaxHp * 0.5f; } }

    public RectangleF Hitbox
    {
        get { return new RectangleF(X - HitW, Y - HitH, HitW * 2f, HitH * 2f); }
    }

    public void Init(EnemyType type, float x, float amp, float freq, float phase, int group, float offX, float offY, float diff, Random rng)
    {
        Type = type;
        startX = x;
        this.amp = amp;
        this.freq = freq;
        this.phase = phase;
        this.offX = offX;
        this.offY = offY;
        Group = group;
        Alive = true;
        Age = 0f;
        HitFlash = 0f;
        SmokeTimer = 0f;
        Bank = 0f;
        VX = 0f;
        VY = 0f;
        burstLeft = 0;
        pattern = 0;
        leg = 0;
        dir = x < GameConfig.LogicalW / 2f ? 1f : -1f;
        switch (type)
        {
            case EnemyType.Fighter:
                HitW = 19f; HitH = 17f; Hp = MathF.Round(3f + 3f * diff); Score = GameConfig.ScoreFighter;
                X = x + amp * MathF.Sin(phase); Y = -40f;
                shootTimer = 0.9f + (float)rng.NextDouble() * 1.1f;
                break;
            case EnemyType.Interceptor:
                HitW = 14f; HitH = 15f; Hp = MathF.Round(2f + 1.5f * diff); Score = GameConfig.ScoreInterceptor;
                X = x; Y = -30f; VY = 170f; stateTimer = 0.45f;
                shootTimer = 1.5f + (float)rng.NextDouble() * 2f;
                break;
            case EnemyType.Bomber:
                HitW = 60f; HitH = 32f; Hp = MathF.Round(22f + 14f * diff); Score = GameConfig.ScoreBomber;
                if (this.amp == 0f) { this.amp = 90f; this.freq = 0.55f; }
                X = x; Y = -90f;
                shootTimer = 1.4f;
                break;
            case EnemyType.Formation:
                HitW = 18f; HitH = 16f; Hp = MathF.Round(3f + 2f * diff); Score = GameConfig.ScoreFormation;
                X = x + offX; Y = -40f + offY;
                shootTimer = 1.8f;
                break;
            default:
                HitW = 28f; HitH = 24f; Hp = MathF.Round(16f + 10f * diff); Score = GameConfig.ScoreElite;
                startX = Math.Max(200f, Math.Min(440f, x));
                X = startX; Y = -60f;
                shootTimer = 1.6f;
                break;
        }
        MaxHp = Hp;
    }

    public void Damage(float amount)
    {
        Hp -= amount;
        HitFlash = 0.1f;
    }

    private static float Approach(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    private static float Clamp(float v, float lo, float hi)
    {
        return Math.Max(lo, Math.Min(hi, v));
    }

    public void Update(float dt, float px, float py, float diff, ProjectileManager shots, Random rng, out bool fired)
    {
        fired = false;
        Age += dt;
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        shootTimer -= dt;
        float oldX = X;
        float limitY = GameConfig.ViewH - 250f;

        switch (Type)
        {
            case EnemyType.Fighter:
                startX += (px - startX) * 0.22f * dt;
                X = Clamp(startX + amp * MathF.Sin(phase + Age * freq), 20f, GameConfig.LogicalW - 20f);
                Y = -40f + Age * (135f + 25f * diff);
                if (shootTimer <= 0f && Y > 20f && Y < limitY)
                {
                    float sp = 230f + 70f * diff;
                    shots.FireAimed(ShotKind.EnemySmall, X, Y + 16f, px, py, sp, 0f);
                    if (diff > 0.55f)
                    {
                        shots.FireAimed(ShotKind.EnemySmall, X, Y + 16f, px, py, sp, 0.14f);
                        shots.FireAimed(ShotKind.EnemySmall, X, Y + 16f, px, py, sp, -0.14f);
                    }
                    fired = true;
                    shootTimer = 2.2f - 0.7f * diff + (float)rng.NextDouble() * 0.8f;
                }
                break;

            case EnemyType.Interceptor:
                stateTimer -= dt;
                if (stateTimer <= 0f)
                {
                    leg++;
                    stateTimer = 0.85f;
                    if (leg == 1) dir = px >= X ? 1f : -1f;
                    else dir = -dir;
                }
                float tvx = leg >= 4 ? 0f : dir * 230f;
                float tvy = leg >= 4 ? 340f : 190f;
                VX = Approach(VX, tvx, 900f * dt);
                VY = Approach(VY, tvy, 400f * dt);
                X += VX * dt;
                Y += VY * dt;
                if (X < 24f) { X = 24f; dir = 1f; }
                if (X > GameConfig.LogicalW - 24f) { X = GameConfig.LogicalW - 24f; dir = -1f; }
                if (diff > 0.25f && shootTimer <= 0f && Y > 20f && Y < limitY)
                {
                    shots.SpawnEnemy(ShotKind.EnemySmall, X, Y + 14f, 0f, 280f);
                    fired = true;
                    shootTimer = 2.6f + (float)rng.NextDouble() * 1.4f;
                }
                break;

            case EnemyType.Bomber:
                X = Clamp(startX + amp * MathF.Sin(phase + Age * freq), 70f, GameConfig.LogicalW - 70f);
                Y = -90f + Age * 52f;
                if (burstLeft > 0)
                {
                    burstTimer -= dt;
                    if (burstTimer <= 0f)
                    {
                        shots.SpawnEnemy(ShotKind.EnemySmall, X - 44f, Y + 20f, 0f, 270f);
                        shots.SpawnEnemy(ShotKind.EnemySmall, X + 44f, Y + 20f, 0f, 270f);
                        burstLeft--;
                        burstTimer = 0.16f;
                        fired = true;
                    }
                }
                else if (shootTimer <= 0f && Y > 10f && Y < GameConfig.ViewH - 200f)
                {
                    if (pattern % 2 == 0)
                    {
                        burstLeft = 3;
                        burstTimer = 0f;
                    }
                    else
                    {
                        shots.FireFan(ShotKind.EnemyHeavy, X, Y + 24f, px, py, 190f, 5, 0.9f);
                        fired = true;
                    }
                    pattern++;
                    shootTimer = 2.6f - 0.8f * diff;
                }
                break;

            case EnemyType.Formation:
                {
                    float gx = startX + amp * MathF.Sin(phase + Age * freq);
                    X = Clamp(gx + offX, 20f, GameConfig.LogicalW - 20f);
                    Y = -40f + Age * 110f + offY;
                    if (shootTimer <= 0f && Y > 20f && Y < limitY)
                    {
                        shots.FireAimed(ShotKind.EnemySmall, X, Y + 14f, px, py, 220f + 50f * diff, offX * 0.0016f);
                        fired = true;
                        shootTimer = 2.8f - 0.6f * diff;
                    }
                }
                break;

            default:    // Elite
                {
                    if (Age < 2.2f)
                    {
                        float k = Age / 2.2f;
                        float e = k * k * (3f - 2f * k);
                        X = startX;
                        Y = -60f + 220f * e;
                    }
                    else if (Age < 12.2f)
                    {
                        float t = Age - 2.2f;
                        X = Clamp(startX + 180f * MathF.Sin(t * 0.85f), 30f, GameConfig.LogicalW - 30f);
                        Y = 160f + 55f * MathF.Sin(t * 1.7f);
                    }
                    else
                    {
                        VY = Approach(VY, 260f, 160f * dt);
                        Y += VY * dt;
                    }

                    if (burstLeft > 0)
                    {
                        burstTimer -= dt;
                        if (burstTimer <= 0f)
                        {
                            shots.FireFan(ShotKind.EnemySmall, X, Y + 22f, px, py, 250f, 3, 0.5f);
                            burstLeft--;
                            burstTimer = 0.4f;
                            fired = true;
                        }
                    }
                    else if (shootTimer <= 0f && Y > 20f && Y < limitY)
                    {
                        int p = pattern % 3;
                        if (p == 0)
                        {
                            burstLeft = 2;
                            burstTimer = 0f;
                        }
                        else if (p == 1)
                        {
                            shots.FireRing(ShotKind.EnemyHeavy, X, Y + 10f, 10, 130f, (float)rng.NextDouble() * 6.28f);
                            fired = true;
                        }
                        else
                        {
                            Projectile a = shots.SpawnEnemy(ShotKind.Missile, X - 22f, Y + 10f, (px - X) * 0.25f - 20f, 110f);
                            Projectile b = shots.SpawnEnemy(ShotKind.Missile, X + 22f, Y + 10f, (px - X) * 0.25f + 20f, 110f);
                            a.AY = 300f;
                            b.AY = 300f;
                            fired = true;
                        }
                        pattern++;
                        shootTimer = 2.4f - 0.6f * diff;
                    }
                }
                break;
        }

        Bank = Clamp((X - oldX) / (dt * 200f), -1f, 1f);
    }
}
