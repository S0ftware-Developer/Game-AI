using System.Diagnostics;

namespace AirCombat;

public sealed class GameForm : Form
{
    private const double StepSeconds = 1.0 / 120.0;

    private readonly GameEngine engine;
    private readonly GameRenderer renderer;
    private readonly System.Windows.Forms.Timer timer;
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private readonly HashSet<Keys> held = new HashSet<Keys>();
    private double lastTime;
    private double accumulator;
    private bool fullscreen;
    private FormBorderStyle savedBorder = FormBorderStyle.Sizable;
    private FormWindowState savedState = FormWindowState.Normal;
    private bool failed;

    public GameForm()
    {
        Text = "1942 — Air Combat";
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.Black;
        DoubleBuffered = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        KeyPreview = true;
        StartPosition = FormStartPosition.CenterScreen;

        Rectangle area = Screen.PrimaryScreen != null ? Screen.PrimaryScreen.WorkingArea : new Rectangle(0, 0, 1280, 900);
        double scale = Math.Max(1.0, DeviceDpi / 96.0);
        double maxScale = Math.Min((area.Width - 40) / (double)GameConfig.LogicalW, (area.Height - 90) / (double)GameConfig.LogicalH);
        scale = Math.Max(0.5, Math.Min(scale, maxScale));
        ClientSize = new Size((int)(GameConfig.LogicalW * scale), (int)(GameConfig.LogicalH * scale));
        MinimumSize = new Size(360, 460);

        Sfx.Init();
        engine = new GameEngine();
        renderer = new GameRenderer();

        timer = new System.Windows.Forms.Timer();
        timer.Interval = 8;
        timer.Tick += OnTick;
        lastTime = clock.Elapsed.TotalSeconds;
        timer.Start();
    }

    private void OnTick(object? sender, EventArgs e)
    {
        if (failed) return;
        try
        {
            double now = clock.Elapsed.TotalSeconds;
            double dt = now - lastTime;
            lastTime = now;
            if (dt > 0.1) dt = 0.1;
            accumulator += dt;

            int steps = 0;
            while (accumulator >= StepSeconds && steps < 12)
            {
                engine.Up = held.Contains(Keys.W) || held.Contains(Keys.Up);
                engine.Down = held.Contains(Keys.S) || held.Contains(Keys.Down);
                engine.Left = held.Contains(Keys.A) || held.Contains(Keys.Left);
                engine.Right = held.Contains(Keys.D) || held.Contains(Keys.Right);
                engine.Fire = held.Contains(Keys.Space);
                engine.Update();
                accumulator -= StepSeconds;
                steps++;
            }
            if (steps >= 12) accumulator = 0.0;
            Invalidate();
        }
        catch (Exception ex)
        {
            Fatal(ex);
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        if (failed) return;
        try
        {
            renderer.Render(e.Graphics, engine, ClientSize.Width, ClientSize.Height);
        }
        catch (Exception ex)
        {
            Fatal(ex);
        }
    }

    protected override bool IsInputKey(Keys keyData)
    {
        return true;
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        bool first = held.Add(e.KeyCode);      // auto-repeat is not a new press
        if (first)
        {
            if (e.KeyCode == Keys.F11 || (e.KeyCode == Keys.Enter && e.Alt)) ToggleFullscreen();
            else
            {
                try
                {
                    engine.HandleKey(e.KeyCode);
                }
                catch (Exception ex)
                {
                    Fatal(ex);
                }
            }
        }
        e.Handled = true;
        e.SuppressKeyPress = true;
    }

    protected override void OnKeyUp(KeyEventArgs e)
    {
        held.Remove(e.KeyCode);
        e.Handled = true;
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            float scale = Math.Min(ClientSize.Width / (float)GameConfig.LogicalW, ClientSize.Height / (float)GameConfig.LogicalH);
            if (scale > 0f)
            {
                float offX = (ClientSize.Width - GameConfig.LogicalW * scale) / 2f;
                float offY = (ClientSize.Height - GameConfig.LogicalH * scale) / 2f;
                HandleClick((int)((e.X - offX) / scale), (int)((e.Y - offY) / scale));
            }
        }
        base.OnMouseDown(e);
    }

    private void HandleClick(int lx, int ly)
    {
        switch (engine.State)
        {
            case GameState.Menu:
                if (GameRenderer.PlayButton.Contains(lx, ly)) engine.StartGame();
                break;
            case GameState.Paused:
                if (GameRenderer.ResumeButton.Contains(lx, ly)) engine.Resume();
                else if (GameRenderer.PauseRestartButton.Contains(lx, ly)) engine.StartGame();
                else if (GameRenderer.PauseMenuButton.Contains(lx, ly)) engine.GoToMenu();
                break;
            case GameState.GameOver:
            case GameState.Victory:
                if (GameRenderer.EndRestartButton.Contains(lx, ly)) engine.StartGame();
                else if (GameRenderer.EndMenuButton.Contains(lx, ly)) engine.GoToMenu();
                break;
        }
    }

    protected override void OnDeactivate(EventArgs e)
    {
        held.Clear();
        engine.AutoPause();
        base.OnDeactivate(e);
    }

    private void ToggleFullscreen()
    {
        if (!fullscreen)
        {
            savedBorder = FormBorderStyle;
            savedState = WindowState;
            if (WindowState == FormWindowState.Maximized) WindowState = FormWindowState.Normal;
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            fullscreen = true;
        }
        else
        {
            FormBorderStyle = savedBorder;
            WindowState = savedState;
            fullscreen = false;
        }
        Invalidate();
    }

    private void Fatal(Exception ex)
    {
        if (failed) return;
        failed = true;
        timer.Stop();
        MessageBox.Show(ex.ToString(), "1942 Air Combat - непредвиденная ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        Close();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Dispose();
            renderer.Dispose();
        }
        base.Dispose(disposing);
    }
}
