namespace Bomberman;

public enum TileType { Empty, Wall, Brick }

/// <summary>One cell of the maze. A brick may hide a power-up or the exit.</summary>
public struct Cell
{
    public TileType Type;
    public bool HasExit;
    public PowerUpType Hidden;
    public byte Variant;         // visual variation of floors, walls and bricks
}
