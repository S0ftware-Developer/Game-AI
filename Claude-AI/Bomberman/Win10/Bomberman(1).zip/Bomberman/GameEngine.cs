namespace Bomberman;

public enum GameState { Title, Controls, Playing, Paused, LevelComplete, GameOver, Victory }

/// <summary>
/// Game rules and the fixed-step simulation (1/120 s): bombs with chain reactions, explosions on the grid, bricks, power-ups,
/// enemies, the exit, levels, lives, scoring and all menu states.
/// </summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;

    public GameState State = GameState.Title;
    public readonly InputManager Input = new InputManager();
    public readonly Player Player = new Player();
    public Maze Maze;
    public readonly List<Bomb> Bombs = new List<Bomb>(16);
    public readonly List<Explosion> Explosions = new List<Explosion>(16);
    public readonly List<PowerUp> PowerUps = new List<PowerUp>(16);
    public readonly List<Enemy> Enemies = new List<Enemy>(16);
    public readonly ParticleSystem Particles = new ParticleSystem();
    public readonly ScoreManager Scores = new ScoreManager();
    public Action? ExitRequested;

    public float Clock;                 // always running (menus)
    public float GameTime;              // runs only while the game is being played (animations stop in pause)
    public int Level = 1;
    public float LevelTime;
    public float ReadyTimer;
    public float CompleteTimer;
    public int ClearBonus, TimeBonus;
    public int Kills, Blocks;
    public bool NewRecord;
    public string Banner = "";
    public float BannerTimer;
    public string Note = "";
    public float NoteTimer;
    public float Shake;
    public float Flash;
    public int TitleIndex, PauseIndex, EndIndex;

    private readonly Random rng = new Random();
    private readonly List<Keys> dirOrder = new List<Keys>(4);
    private readonly List<BlastCell> scratch = new List<BlastCell>(32);
    private bool exitAnnounced;

    private static readonly Color[] BrickColors =
    {
        Color.FromArgb(200, 110, 60), Color.FromArgb(214, 176, 104), Color.FromArgb(170, 214, 238), Color.FromArgb(126, 84, 160), Color.FromArgb(156, 56, 44)
    };

    public LevelDef Def { get { return GameSettings.Levels[Level - 1]; } }
    public int AliveEnemies { get { int n = 0; foreach (Enemy e in Enemies) if (!e.Dying) n++; return n; } }
    public bool ExitActive { get { return Maze.ExitRevealed && AliveEnemies == 0; } }

    public GameEngine()
    {
        Scores.Load();
        Maze = Maze.Build(1, rng);
        Player.KickRequest = OnKick;
    }

    // ------------------------------------------------------------------ states and menus

    public void StartGame()
    {
        Player.ResetStats();
        Kills = 0;
        Blocks = 0;
        NewRecord = false;
        Level = 1;
        LoadLevel(1);
        State = GameState.Playing;
        SoundManager.Play(SfxId.Confirm);
        Input.Clear();
        dirOrder.Clear();
    }

    private void LoadLevel(int n)
    {
        Level = n;
        Maze = Maze.Build(n, rng);
        Bombs.Clear();
        Explosions.Clear();
        PowerUps.Clear();
        Enemies.Clear();
        Particles.Clear();
        foreach (EnemySpawn s in Maze.Spawns)
        {
            Enemy e = new Enemy();
            e.Init(s.Type, s.X, s.Y, n, rng);
            Enemies.Add(e);
        }
        Player.Respawn(GameSettings.PlayerInvulnerability);
        LevelTime = Def.Time;
        ReadyTimer = 2.2f;
        exitAnnounced = false;
        Banner = "STAGE " + n;
        BannerTimer = 2.2f;
        Note = Def.Name;
        NoteTimer = 2.2f;
        Shake = 0f;
        Flash = 0f;
        SoundManager.Play(SfxId.Ready);
    }

    public int ItemCount(GameState s)
    {
        switch (s)
        {
            case GameState.Title: return 2;
            case GameState.Paused: return 4;
            case GameState.GameOver:
            case GameState.Victory: return 2;
            default: return 1;
        }
    }

    public void Hover(GameState s, int index)
    {
        if (index < 0 || index >= ItemCount(s)) return;
        if (s == GameState.Title) TitleIndex = index;
        else if (s == GameState.Paused) PauseIndex = index;
        else if (s == GameState.GameOver || s == GameState.Victory) EndIndex = index;
    }

    public void Activate(GameState s, int index)
    {
        SoundManager.Play(SfxId.Confirm);
        switch (s)
        {
            case GameState.Title:
                if (index == 0) StartGame();
                else State = GameState.Controls;
                break;
            case GameState.Controls:
                State = GameState.Title;
                break;
            case GameState.Paused:
                if (index == 0) State = GameState.Playing;
                else if (index == 1) StartGame();
                else if (index == 2) SoundManager.SetMuted(!SoundManager.Muted);
                else State = GameState.Title;
                break;
            case GameState.GameOver:
            case GameState.Victory:
                if (index == 0) StartGame();
                else State = GameState.Title;
                break;
        }
    }

    public void AutoPause()
    {
        Input.Clear();
        dirOrder.Clear();
        if (State == GameState.Playing)
        {
            PauseIndex = 0;
            State = GameState.Paused;
        }
    }

    private void Navigate(ref int index, int count)
    {
        if (Input.AnyPressed(Keys.Up, Keys.W))
        {
            index = (index + count - 1) % count;
            SoundManager.Play(SfxId.Menu);
        }
        if (Input.AnyPressed(Keys.Down, Keys.S))
        {
            index = (index + 1) % count;
            SoundManager.Play(SfxId.Menu);
        }
    }

    // ------------------------------------------------------------------ the fixed step

    public void Update()
    {
        Clock += Dt;
        switch (State)
        {
            case GameState.Title:
                Navigate(ref TitleIndex, 2);
                if (Input.AnyPressed(Keys.Enter, Keys.Space)) Activate(GameState.Title, TitleIndex);
                break;
            case GameState.Controls:
                if (Input.AnyPressed(Keys.Enter, Keys.Escape) | Input.Pressed(Keys.Space)) Activate(GameState.Controls, 0);
                break;
            case GameState.Paused:
                Navigate(ref PauseIndex, 4);
                if (Input.Pressed(Keys.Escape)) State = GameState.Playing;
                else if (Input.AnyPressed(Keys.Enter, Keys.Space)) Activate(GameState.Paused, PauseIndex);
                else if (Input.Pressed(Keys.R)) StartGame();
                else if (Input.Pressed(Keys.M)) SoundManager.SetMuted(!SoundManager.Muted);
                break;
            case GameState.GameOver:
            case GameState.Victory:
                Navigate(ref EndIndex, 2);
                if (Input.Pressed(Keys.Enter) | Input.Pressed(Keys.Space)) Activate(State, EndIndex == 0 ? 0 : 1);
                else if (Input.Pressed(Keys.R)) StartGame();
                else if (Input.Pressed(Keys.Escape)) State = GameState.Title;
                GameTime += Dt;
                Player.CelebrateTime += Dt;
                if (State == GameState.Victory && ((int)(Clock * 12f)) != ((int)((Clock - Dt) * 12f)))
                {
                    Color[] cs = { Color.FromArgb(255, 80, 80), Color.FromArgb(255, 220, 60), Color.FromArgb(80, 220, 120), Color.FromArgb(90, 170, 255) };
                    Particles.Sparks(GameSettings.BoardX + (float)(rng.NextDouble() * Maze.Cols * GameSettings.TileSize), GameSettings.BoardY + 10f, 70f, 3, cs[rng.Next(cs.Length)]);
                }
                UpdateEffects();
                break;
            case GameState.LevelComplete:
                UpdateLevelComplete();
                break;
            default:
                UpdatePlaying();
                break;
        }
        Input.ClearPressed();
    }

    private void UpdateEffects()
    {
        Particles.Update(Dt);
        if (Shake > 0f) Shake = Math.Max(0f, Shake - Dt);
        if (Flash > 0f) Flash = Math.Max(0f, Flash - Dt);
        if (BannerTimer > 0f) BannerTimer -= Dt;
        if (NoteTimer > 0f) NoteTimer -= Dt;
    }

    private void UpdateLevelComplete()
    {
        GameTime += Dt;
        CompleteTimer += Dt;
        Player.Age += Dt;
        Player.CelebrateTime += Dt;
        // confetti
        if (((int)(CompleteTimer * 14f)) != ((int)((CompleteTimer - Dt) * 14f)))
        {
            Color[] cs = { Color.FromArgb(255, 80, 80), Color.FromArgb(255, 220, 60), Color.FromArgb(80, 220, 120), Color.FromArgb(90, 170, 255) };
            Particles.Sparks(GameSettings.BoardX + (float)(rng.NextDouble() * Maze.Cols * GameSettings.TileSize), GameSettings.BoardY + 20f, 60f, 2, cs[rng.Next(cs.Length)]);
        }
        UpdateEffects();
        if (CompleteTimer > 1.2f && Input.AnyPressed(Keys.Enter, Keys.Space) || CompleteTimer > 5f) NextLevel();
    }

    private void NextLevel()
    {
        if (Level >= GameSettings.LevelCount)
        {
            NewRecord = Scores.Submit(Player.Score);
            EndIndex = 0;
            State = GameState.Victory;
            SoundManager.Play(SfxId.Victory);
            return;
        }
        LoadLevel(Level + 1);
        State = GameState.Playing;
    }

    private void UpdatePlaying()
    {
        if (Input.Pressed(Keys.Escape))
        {
            PauseIndex = 0;
            State = GameState.Paused;
            SoundManager.Play(SfxId.Menu);
            return;
        }

        GameTime += Dt;
        if (ReadyTimer > 0f)
        {
            ReadyTimer -= Dt;
            Player.Age += Dt;
            UpdateEffects();
            return;
        }
        LevelTime -= Dt;

        // movement: the most recently pressed arrow key wins (only one axis at a time)
        int dx, dy;
        ReadDirection(out dx, out dy);

        if (Player.State == PlayerState.Alive)
        {
            if (Input.Pressed(Keys.Space)) TryPlaceBomb();
            if (Input.AnyPressed(Keys.Z, Keys.ControlKey)) DetonateRemote();
        }

        Player.Update(Dt, dx, dy, Maze, Bombs);
        foreach (Bomb b in Bombs)
        {
            if (b.OwnerInside && !Player.Overlaps(b.X, b.Y)) b.OwnerInside = false;
        }

        UpdateBombs();
        UpdateExplosions();
        Maze.UpdateFlames(Dt);
        Maze.UpdateDanger(Bombs);

        foreach (Enemy e in Enemies) e.Update(Dt, Maze, Bombs, Player, rng);
        for (int i = Enemies.Count - 1; i >= 0; i--)
        {
            if (Enemies[i].Dying && Enemies[i].DeathTimer <= 0f) Enemies.RemoveAt(i);
        }

        UpdatePowerUps();
        CheckDamage();
        CheckExit();
        CheckTime();
        HandleDeathState();
        UpdateEffects();
    }

    private void ReadDirection(out int dx, out int dy)
    {
        Keys[] keys = { Keys.Up, Keys.Down, Keys.Left, Keys.Right };
        Keys[] alt = { Keys.W, Keys.S, Keys.A, Keys.D };
        for (int i = 0; i < 4; i++)
        {
            bool held = Input.AnyHeld(keys[i], alt[i]);
            if (held && !dirOrder.Contains(keys[i])) dirOrder.Add(keys[i]);
            if (!held) dirOrder.Remove(keys[i]);
        }
        dx = 0;
        dy = 0;
        if (dirOrder.Count == 0) return;
        Keys last = dirOrder[dirOrder.Count - 1];
        if (last == Keys.Up) dy = -1;
        else if (last == Keys.Down) dy = 1;
        else if (last == Keys.Left) dx = -1;
        else dx = 1;
    }

    // ------------------------------------------------------------------ bombs

    private static float PxX(float tileX)
    {
        return GameSettings.BoardX + tileX * GameSettings.TileSize;
    }

    private static float PxY(float tileY)
    {
        return GameSettings.BoardY + tileY * GameSettings.TileSize;
    }

    private void TryPlaceBomb()
    {
        int cx = Player.CellX;
        int cy = Player.CellY;
        int active = 0;
        foreach (Bomb b in Bombs)
        {
            if (!b.Exploded) active++;
            if (!b.Exploded && b.Occupies(cx, cy)) return;
        }
        if (active >= Player.MaxBombs) return;
        if (Maze.IsBlocking(cx, cy)) return;

        Bomb bomb = new Bomb();
        bomb.X = cx;
        bomb.Y = cy;
        bomb.Range = Player.Range;
        bomb.Remote = Player.CanRemote;
        bomb.Timer = bomb.Remote ? Bomb.RemoteFuse : Bomb.Fuse;
        bomb.OwnerInside = true;
        Bombs.Add(bomb);
        Player.PlaceAnim = 0.28f;
        SoundManager.Play(SfxId.PlaceBomb);
    }

    private void DetonateRemote()
    {
        if (!Player.CanRemote) return;
        bool any = false;
        foreach (Bomb b in new List<Bomb>(Bombs))
        {
            if (b.Remote && !b.Exploded)
            {
                any = true;
                Detonate(b);
            }
        }
        if (any) SoundManager.Play(SfxId.Detonate);
    }

    private void OnKick(Bomb b, int dx, int dy)
    {
        if (!CanSlideInto(b.X + dx, b.Y + dy, b)) return;
        b.Sliding = true;
        b.SlideX = dx;
        b.SlideY = dy;
        b.Prog = 0.001f;
        SoundManager.Play(SfxId.Kick);
    }

    private bool CanSlideInto(int x, int y, Bomb self)
    {
        if (Maze.IsBlocking(x, y)) return false;
        foreach (Bomb o in Bombs)
        {
            if (o != self && !o.Exploded && o.Occupies(x, y)) return false;
        }
        foreach (Enemy e in Enemies)
        {
            if (!e.Dying && e.CellX == x && e.CellY == y) return false;
        }
        if (Player.State == PlayerState.Alive && Player.CellX == x && Player.CellY == y) return false;
        return true;
    }

    private void UpdateBombs()
    {
        List<Bomb> due = new List<Bomb>(4);
        foreach (Bomb b in Bombs)
        {
            if (b.Exploded) continue;
            float before = b.Timer;
            b.Age += Dt;
            b.Timer -= Dt;
            if (!b.Remote && (int)(b.Timer * 3f) != (int)(before * 3f) && b.Timer > 0f) SoundManager.Play(SfxId.Tick);
            if (b.Sliding)
            {
                b.Prog += Bomb.SlideSpeed * Dt;
                if (b.Prog >= 1f)
                {
                    b.X += b.SlideX;
                    b.Y += b.SlideY;
                    b.Prog -= 1f;
                    if (!CanSlideInto(b.X + b.SlideX, b.Y + b.SlideY, b))
                    {
                        b.Sliding = false;
                        b.Prog = 0f;
                    }
                }
            }
            if (b.Timer <= 0f) due.Add(b);
        }
        foreach (Bomb b in due)
        {
            if (!b.Exploded) Detonate(b);
        }
    }

    /// <summary>
    /// Detonates a bomb and, through the flames it spreads, every other bomb they touch. All blasts of the chain are worked
    /// out before any brick is removed, so a blast never continues through a brick that the same chain destroys.
    /// </summary>
    private void Detonate(Bomb first)
    {
        Queue<Bomb> queue = new Queue<Bomb>();
        first.Exploded = true;
        queue.Enqueue(first);
        List<BlastCell> bricks = new List<BlastCell>();
        int chain = 0;
        while (queue.Count > 0)
        {
            Bomb b = queue.Dequeue();
            Explosion ex = new Explosion();
            Maze.CollectBlast(b.CellX, b.CellY, b.Range, ex.Cells);
            foreach (BlastCell c in ex.Cells)
            {
                Maze.Flame[c.X, c.Y] = Math.Max(Maze.Flame[c.X, c.Y], Explosion.Duration);
                if (c.Brick) bricks.Add(c);
                foreach (Bomb o in Bombs)
                {
                    if (!o.Exploded && o.Occupies(c.X, c.Y))
                    {
                        o.Exploded = true;
                        queue.Enqueue(o);
                    }
                }
                Particles.Sparks(PxX(c.X + 0.5f), PxY(c.Y + 0.5f), 70f, 2, Color.FromArgb(255, 190, 60));
            }
            Explosions.Add(ex);
            chain++;
        }

        // now the bricks burn away
        HashSet<int> done = new HashSet<int>();
        foreach (BlastCell c in bricks)
        {
            if (!done.Add(c.Y * Maze.Cols + c.X)) continue;
            if (!Maze.IsBrick(c.X, c.Y)) continue;
            PowerUpType hidden = Maze.DestroyBrick(c.X, c.Y);
            Blocks++;
            Player.Score += GameSettings.ScoreBrick;
            Particles.Debris(PxX(c.X + 0.5f), PxY(c.Y + 0.5f), 9, BrickColors[Maze.Theme]);
            Particles.Debris(PxX(c.X + 0.5f), PxY(c.Y + 0.5f), 4, Color.FromArgb(120, 70, 40));
            if (hidden != PowerUpType.None)
            {
                PowerUp p = new PowerUp();
                p.X = c.X;
                p.Y = c.Y;
                p.Type = hidden;
                p.Grace = 0.8f;
                PowerUps.Add(p);
            }
            if (Maze.Cells[c.X, c.Y].HasExit && !exitAnnounced)
            {
                exitAnnounced = true;
                Note = AliveEnemiesText();
                NoteTimer = 2.6f;
            }
        }
        if (bricks.Count > 0) SoundManager.Play(SfxId.BlockBreak);
        SoundManager.Play(SfxId.Explosion);
        Shake = Math.Max(Shake, 0.12f + 0.03f * Math.Min(chain, 4));
        Bombs.RemoveAll(b => b.Exploded);
    }

    private string AliveEnemiesText()
    {
        return AliveEnemies == 0 ? "EXIT FOUND - GO!" : "EXIT FOUND - DEFEAT ALL ENEMIES";
    }

    private void UpdateExplosions()
    {
        for (int i = Explosions.Count - 1; i >= 0; i--)
        {
            Explosions[i].Age += Dt;
            if (Explosions[i].Done) Explosions.RemoveAt(i);
        }
    }

    // ------------------------------------------------------------------ power-ups, damage, exit

    private void UpdatePowerUps()
    {
        for (int i = PowerUps.Count - 1; i >= 0; i--)
        {
            PowerUp p = PowerUps[i];
            p.Age += Dt;
            if (p.Grace > 0f) p.Grace -= Dt;
            if (p.Grace <= 0f && Maze.Flame[p.X, p.Y] > 0f)
            {
                // a power-up is burnt by a later explosion
                Particles.Sparks(PxX(p.X + 0.5f), PxY(p.Y + 0.5f), 80f, 6, Color.FromArgb(255, 160, 60));
                PowerUps.RemoveAt(i);
                continue;
            }
            if (Player.State == PlayerState.Alive && Player.CellX == p.X && Player.CellY == p.Y)
            {
                Collect(p);
                PowerUps.RemoveAt(i);
            }
        }
    }

    private void Collect(PowerUp p)
    {
        switch (p.Type)
        {
            case PowerUpType.BombUp: Player.MaxBombs = Math.Min(GameSettings.MaxBombsLimit, Player.MaxBombs + 1); break;
            case PowerUpType.FireUp: Player.Range = Math.Min(GameSettings.MaxRangeLimit, Player.Range + 1); break;
            case PowerUpType.SpeedUp: Player.SpeedLevel = Math.Min(GameSettings.MaxSpeedLevel, Player.SpeedLevel + 1); break;
            case PowerUpType.Kick: Player.CanKick = true; break;
            case PowerUpType.Remote: Player.CanRemote = true; break;
        }
        Player.Score += GameSettings.ScorePowerUp;
        SoundManager.Play(SfxId.PowerUp);
        Note = PowerUp.Name(p.Type) + " - " + PowerUp.Description(p.Type);
        NoteTimer = 2.6f;
        float px = PxX(p.X + 0.5f);
        float py = PxY(p.Y + 0.5f);
        Particles.Ring(px, py, 22f, Color.FromArgb(255, 240, 120));
        Particles.Sparks(px, py, 90f, 10, Color.FromArgb(255, 240, 120));
        Particles.Text(px, py - 14f, "+" + GameSettings.ScorePowerUp, Color.FromArgb(255, 255, 240, 140));
    }

    private void CheckDamage()
    {
        // flames burn enemies
        foreach (Enemy e in Enemies)
        {
            if (e.Dying) continue;
            if (Maze.Flame[e.CellX, e.CellY] > 0f) KillEnemy(e);
        }
        // flames burn the player; enemies touching the player hurt him
        if (Player.Vulnerable)
        {
            if (Maze.Flame[Player.CellX, Player.CellY] > 0f) KillPlayer();
            else
            {
                foreach (Enemy e in Enemies)
                {
                    if (e.Dying) continue;
                    if (Math.Abs(e.X - Player.X) < 0.6f && Math.Abs(e.Y - Player.Y) < 0.6f)
                    {
                        KillPlayer();
                        break;
                    }
                }
            }
        }
    }

    private void KillEnemy(Enemy e)
    {
        e.Kill();
        Kills++;
        Player.Score += e.Score;
        SoundManager.Play(SfxId.EnemyDie);
        float px = PxX(e.X);
        float py = PxY(e.Y);
        Particles.Sparks(px, py, 100f, 10, Color.FromArgb(255, 250, 200, 90));
        Particles.Ring(px, py, 20f, Color.White);
        Particles.Text(px, py - 12f, e.Score.ToString(), Color.FromArgb(255, 255, 240, 140));
        if (AliveEnemies == 0)
        {
            Banner = Maze.ExitRevealed ? "EXIT IS OPEN!" : "FIND THE EXIT!";
            BannerTimer = 2.2f;
            if (Maze.ExitRevealed) SoundManager.Play(SfxId.Ready);
        }
    }

    private void KillPlayer()
    {
        if (Player.State != PlayerState.Alive) return;
        Player.Kill();
        Player.Lives--;
        SoundManager.Play(SfxId.PlayerDie);
        Shake = 0.3f;
        float px = PxX(Player.X);
        float py = PxY(Player.Y);
        Particles.Sparks(px, py, 110f, 12, Color.FromArgb(255, 240, 240, 255));
    }

    private void CheckExit()
    {
        if (Player.State != PlayerState.Alive || !ExitActive) return;
        if (Player.CellX != Maze.ExitX || Player.CellY != Maze.ExitY) return;
        // level complete
        ClearBonus = GameSettings.ScoreLevel;
        TimeBonus = Math.Max(0, (int)LevelTime) * GameSettings.ScoreTimeBonusPerSecond;
        Player.Score += ClearBonus + TimeBonus;
        CompleteTimer = 0f;
        Player.CelebrateTime = 0f;
        State = GameState.LevelComplete;
        SoundManager.Play(SfxId.LevelComplete);
        Flash = 0.25f;
    }

    private void CheckTime()
    {
        if (LevelTime > 0f) return;
        if (Player.State == PlayerState.Alive)
        {
            Banner = "TIME UP!";
            BannerTimer = 2f;
            KillPlayer();
        }
        LevelTime = 60f;     // extra time for the next attempt
    }

    private void HandleDeathState()
    {
        if (Player.State != PlayerState.Waiting) return;
        if (Player.Lives > 0)
        {
            Player.Respawn(GameSettings.PlayerInvulnerability);
            Note = "LIVES LEFT: " + Player.Lives;
            NoteTimer = 2f;
        }
        else
        {
            NewRecord = Scores.Submit(Player.Score);
            EndIndex = 0;
            State = GameState.GameOver;
            SoundManager.Play(SfxId.GameOver);
        }
    }
}
