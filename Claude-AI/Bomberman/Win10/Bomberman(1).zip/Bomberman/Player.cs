namespace Bomberman;

public enum PlayerState { Alive, Dying, Waiting }

/// <summary>
/// The Bomberman: smooth movement on the grid with a small hit box, corner assistance so turning into a corridor never
/// snags, bombs that can be walked off, bomb kicking, power-ups, lives, invulnerability and the death animation.
/// Positions are in tile units; tile (i, j) covers [i, i + 1) and its centre is (i + 0.5, j + 0.5).
/// </summary>
public sealed class Player
{
    public const float Half = 0.34f;

    public float X = 1.5f, Y = 1.5f;
    public int Facing;                    // 0 down, 1 up, 2 left, 3 right
    public PlayerState State = PlayerState.Alive;
    public bool Moving;
    public float DeathTimer, Invuln, PlaceAnim, WalkPhase, Age, CelebrateTime;

    public int Lives = GameSettings.StartLives;
    public int Score;
    public int MaxBombs = 1;
    public int Range = 2;
    public int SpeedLevel;
    public bool CanKick;
    public bool CanRemote;

    public Action<Bomb, int, int>? KickRequest;

    public float Speed { get { return 3.7f + 0.55f * SpeedLevel; } }
    public int CellX { get { return (int)Math.Floor(X); } }
    public int CellY { get { return (int)Math.Floor(Y); } }
    public bool Vulnerable { get { return State == PlayerState.Alive && Invuln <= 0f; } }

    public void ResetStats()
    {
        Lives = GameSettings.StartLives;
        Score = 0;
        MaxBombs = 1;
        Range = 2;
        SpeedLevel = 0;
        CanKick = false;
        CanRemote = false;
    }

    public void Respawn(float invulnerability)
    {
        X = Maze.StartX + 0.5f;
        Y = Maze.StartY + 0.5f;
        Facing = 0;
        State = PlayerState.Alive;
        Moving = false;
        Invuln = invulnerability;
        DeathTimer = 0f;
        CelebrateTime = 0f;
    }

    public void Kill()
    {
        if (State != PlayerState.Alive) return;
        State = PlayerState.Dying;
        DeathTimer = 1.5f;
        Moving = false;
    }

    private static bool Blocked(int cx, int cy, Maze maze, List<Bomb> bombs)
    {
        if (maze.IsBlocking(cx, cy)) return true;
        foreach (Bomb b in bombs)
        {
            if (b.Exploded || b.OwnerInside) continue;
            if (b.Occupies(cx, cy)) return true;
        }
        return false;
    }

    private static bool Collides(float x, float y, Maze maze, List<Bomb> bombs)
    {
        int x0 = (int)Math.Floor(x - Half);
        int x1 = (int)Math.Floor(x + Half);
        int y0 = (int)Math.Floor(y - Half);
        int y1 = (int)Math.Floor(y + Half);
        for (int cy = y0; cy <= y1; cy++)
        {
            for (int cx = x0; cx <= x1; cx++)
            {
                if (Blocked(cx, cy, maze, bombs)) return true;
            }
        }
        return false;
    }

    /// <summary>True when the hit box still touches the tile (used so a freshly placed bomb can be walked off).</summary>
    public bool Overlaps(int cx, int cy)
    {
        return Math.Abs(X - (cx + 0.5f)) < 0.5f + Half && Math.Abs(Y - (cy + 0.5f)) < 0.5f + Half;
    }

    public void Update(float dt, int dx, int dy, Maze maze, List<Bomb> bombs)
    {
        Age += dt;
        if (Invuln > 0f) Invuln = Math.Max(0f, Invuln - dt);
        if (PlaceAnim > 0f) PlaceAnim = Math.Max(0f, PlaceAnim - dt);
        if (State == PlayerState.Dying)
        {
            DeathTimer -= dt;
            if (DeathTimer <= 0f) State = PlayerState.Waiting;
            return;
        }
        if (State != PlayerState.Alive) return;

        Moving = false;
        if (dx != 0 || dy != 0)
        {
            Facing = dy < 0 ? 1 : (dy > 0 ? 0 : (dx < 0 ? 2 : 3));
            Moving = Step(dx, dy, Speed * dt, maze, bombs);
        }
        if (Moving) WalkPhase += dt * 11f;
    }

    private bool Step(int dx, int dy, float step, Maze maze, List<Bomb> bombs)
    {
        float nx = X + dx * step;
        float ny = Y + dy * step;
        if (!Collides(nx, ny, maze, bombs))
        {
            X = nx;
            Y = ny;
            return true;
        }

        // blocked: look at the tile straight ahead in the lane we are mostly in
        if (dx != 0)
        {
            int row = (int)Math.Floor(Y);
            int col = (int)Math.Floor(nx + dx * Half);
            float laneCenter = row + 0.5f;
            if (!Blocked(col, row, maze, bombs))
            {
                // the lane ahead is free: slide into its centre (corner assistance)
                float diff = laneCenter - Y;
                float adj = Math.Sign(diff) * Math.Min(Math.Abs(diff), step);
                if (adj != 0f && !Collides(X, Y + adj, maze, bombs))
                {
                    Y += adj;
                    return true;
                }
                return false;
            }
            TryKick(col, row, dx, 0, bombs, maze);
            float edge = dx > 0 ? col - Half - 0.001f : col + 1 + Half + 0.001f;
            if (((dx > 0 && edge > X) || (dx < 0 && edge < X)) && !Collides(edge, Y, maze, bombs)) X = edge;
            return false;
        }
        else
        {
            int col = (int)Math.Floor(X);
            int row = (int)Math.Floor(ny + dy * Half);
            float laneCenter = col + 0.5f;
            if (!Blocked(col, row, maze, bombs))
            {
                float diff = laneCenter - X;
                float adj = Math.Sign(diff) * Math.Min(Math.Abs(diff), step);
                if (adj != 0f && !Collides(X + adj, Y, maze, bombs))
                {
                    X += adj;
                    return true;
                }
                return false;
            }
            TryKick(col, row, 0, dy, bombs, maze);
            float edge = dy > 0 ? row - Half - 0.001f : row + 1 + Half + 0.001f;
            if (((dy > 0 && edge > Y) || (dy < 0 && edge < Y)) && !Collides(X, edge, maze, bombs)) Y = edge;
            return false;
        }
    }

    private void TryKick(int cx, int cy, int dx, int dy, List<Bomb> bombs, Maze maze)
    {
        if (!CanKick || KickRequest == null) return;
        foreach (Bomb b in bombs)
        {
            if (b.Exploded || b.Sliding || b.OwnerInside) continue;
            if (b.X == cx && b.Y == cy)
            {
                KickRequest(b, dx, dy);
                return;
            }
        }
    }
}
