namespace Bomberman;

public struct Particle
{
    public float X, Y, VX, VY, Size, Life, MaxLife, Drag, Rot, Spin;
    public byte Kind;             // 0 smoke, 1 spark, 2 debris, 3 ring, 4 flame
    public byte R, G, B;
}

public sealed class FloatText
{
    public float X, Y, Life;
    public string Text = "";
    public Color Color;
}

/// <summary>A fixed-size pool of lightweight particles plus a few floating texts. No allocation while playing.</summary>
public sealed class ParticleSystem
{
    public const int Capacity = 2500;
    public readonly Particle[] Items = new Particle[Capacity];
    public int Count;
    public readonly List<FloatText> Texts = new List<FloatText>(24);
    private readonly Random rng = new Random();

    public void Clear()
    {
        Count = 0;
        Texts.Clear();
    }

    private float R(float a, float b)
    {
        return a + (float)rng.NextDouble() * (b - a);
    }

    private void Add(byte kind, float x, float y, float vx, float vy, float size, float life, float drag, Color c)
    {
        if (Count >= Capacity) return;
        Particle p = new Particle();
        p.Kind = kind;
        p.X = x; p.Y = y; p.VX = vx; p.VY = vy;
        p.Size = size;
        p.Life = life;
        p.MaxLife = life;
        p.Drag = drag;
        p.Rot = R(0f, 6.28f);
        p.Spin = R(-8f, 8f);
        p.R = c.R; p.G = c.G; p.B = c.B;
        Items[Count++] = p;
    }

    public void Smoke(float x, float y, float vx, float vy, float size, float life, int shade = 70)
    {
        Add(0, x, y, vx, vy, size, life, 1.2f, Color.FromArgb(shade, shade, shade + 6));
    }

    public void Sparks(float x, float y, float speed, int count, Color c)
    {
        for (int i = 0; i < count; i++)
        {
            double a = rng.NextDouble() * Math.PI * 2.0;
            float sp = R(0.3f, 1f) * speed;
            Add(1, x, y, (float)Math.Cos(a) * sp, (float)Math.Sin(a) * sp, R(1.5f, 3f), R(0.2f, 0.5f), 2.5f, c);
        }
    }

    public void Debris(float x, float y, int count, Color c)
    {
        for (int i = 0; i < count; i++)
        {
            double a = rng.NextDouble() * Math.PI * 2.0;
            float sp = R(40f, 220f);
            Add(2, x, y, (float)Math.Cos(a) * sp, (float)Math.Sin(a) * sp + 20f, R(2.5f, 5f), R(0.6f, 1.2f), 0.8f, c);
        }
    }

    public void Flames(float x, float y, float spread, int count)
    {
        for (int i = 0; i < count; i++)
        {
            Add(4, x + R(-spread, spread), y + R(-spread, spread), R(-40f, 40f), R(-30f, 50f), R(6f, 14f), R(0.25f, 0.5f), 2f,
                (i % 2 == 0) ? Color.FromArgb(255, 170, 40) : Color.FromArgb(255, 90, 30));
        }
    }

    public void Ring(float x, float y, float maxSize, Color c)
    {
        Add(3, x, y, 0f, 0f, maxSize, 0.45f, 0f, c);
    }

    public void Text(float x, float y, string text, Color color)
    {
        if (Texts.Count >= 24) Texts.RemoveAt(0);
        FloatText t = new FloatText();
        t.X = x; t.Y = y; t.Text = text; t.Color = color; t.Life = 1.1f;
        Texts.Add(t);
    }

    public void Update(float dt)
    {
        for (int i = Count - 1; i >= 0; i--)
        {
            ref Particle p = ref Items[i];
            p.Life -= dt;
            if (p.Life <= 0f)
            {
                Items[i] = Items[Count - 1];
                Count--;
                continue;
            }
            float k = Math.Max(0f, 1f - p.Drag * dt);
            p.VX *= k;
            p.VY *= k;
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            p.Rot += p.Spin * dt;
            if (p.Kind == 2) p.VY += 160f * dt;
        }
        for (int i = Texts.Count - 1; i >= 0; i--)
        {
            FloatText t = Texts[i];
            t.Life -= dt;
            t.Y -= 28f * dt;
            if (t.Life <= 0f) Texts.RemoveAt(i);
        }
    }
}
