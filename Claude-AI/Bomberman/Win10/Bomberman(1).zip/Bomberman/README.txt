﻿BOMBERMAN
=========

© 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space

GAME
----
A classic top-down Bomberman-style arcade game. Walk through a maze, place bombs, escape before they explode, blow up
bricks, find the power-ups and the hidden exit, defeat every enemy and clear all five levels. Explosions spread up, down,
left and right, are stopped by walls and by the first brick they burn, and set off other bombs in a chain reaction.

WINDOWS REQUIREMENTS
--------------------
Windows 10 or 11, 64-bit. The built game is one standalone EXE and needs nothing installed.
To BUILD it you need the .NET SDK 8 or newer (8, 9 and 10 all work). The game is not pre-built: build it locally with
build.bat (see below).

CONTROLS
--------
Arrow keys      move (W A S D work too)
Space           place a bomb (you can keep walking; you can walk off a bomb you just placed)
Z or Ctrl       detonate your remote bombs (only after picking up the Remote Bomb power-up)
Esc             pause / resume (the pause menu: Resume, Restart, Sound on/off, Title screen)
Enter           restart after Game Over; confirm in menus
M               sound on/off (in the pause menu)
F11 / Alt+Enter full screen
Menus: Up / Down and Enter, or the mouse.

HOW TO PLAY
-----------
- Start with 3 lives, 1 bomb and an explosion range of 2 tiles. A bomb explodes after about 2.8 seconds.
- Some bricks hide power-ups and exactly one hides the EXIT. The exit opens only when every enemy is defeated.
- Walk into the open exit to finish the level. You get a clear bonus and a time bonus for the seconds left.
- Touching an enemy or standing in fire costs a life. After dying you respawn at the start with a few seconds of
  invulnerability (the character blinks). Running out of time also costs a life.
- Score: bricks 10, enemies 100 - 400, power-ups 50, level clear 1000 plus 10 points per second left.
- The best score is saved in %APPDATA%\Bomberman\best.txt.

POWER-UPS (permanent, kept between levels)
------------------------------------------
Bomb Up       one more bomb at a time (blue icon)
Fire Up       explosion range +1 (orange icon)
Speed Up      faster movement, up to 4 times (cyan icon)
Bomb Kick     walk into a bomb to kick it; it slides until something blocks it (green icon)
Remote Bomb   your bombs wait for Z (or explode on their own after 7 seconds) (red icon)
A later explosion burns a power-up lying on the floor, so be careful.

ENEMIES
-------
Red balloon: slow wanderer.  Blue wisp: fast.  Green chaser: turns often and heads for you when you are near.
Purple one-eye: smart, keeps out of the tiles that bombs are about to burn and also hunts you.
Enemies die in explosions, can be blocked by bombs and walk only along the grid.

LEVELS
------
1 Green Field, 2 Sunny Desert, 3 Frozen Halls, 4 Midnight Ruins, 5 Volcano Core. Each has its own layout, theme,
number of bricks, enemy mix, hidden power-ups and time limit. After level 5 the victory screen appears.

HOW TO BUILD AND LAUNCH
-----------------------
1. Unzip Bomberman.zip to any folder (a path with spaces or parentheses is fine).
2. Double-click build.bat. It shows the installed SDK version, checks that it is 8 or newer, publishes a self-contained
   single-file Windows x64 build and keeps the window open. The first build needs an internet connection (NuGet).
3. The game is created at:   bin\Release\net8.0-windows\win-x64\publish\Bomberman.exe
   Double-click it to play. The publish folder contains only this one file.

PROJECT FILES
-------------
Bomberman.csproj, Program.cs, GameForm.cs (window, loop, mouse), InputManager.cs (keyboard), GameEngine.cs (rules, states,
bombs, chain reactions, levels), GameRenderer.cs (pixel canvas, HUD, menus), Sprites.cs (all pixel-art drawing),
GameSettings.cs (constants and the five level definitions), Maze.cs and Tile.cs (grid, blast calculation, level
building), Player.cs, Enemy.cs, Bomb.cs, Explosion.cs, PowerUp.cs, ParticleSystem.cs, SoundManager.cs (generated sound
effects), ScoreManager.cs, build.bat, README.txt.

TECHNICAL NOTES
---------------
C#, .NET 8, Windows Forms, GDI+. The game is drawn on a 480x360 pixel canvas with hard edges and scaled by two with
nearest-neighbour filtering (the aspect ratio is kept when the window is resized). Fixed 1/120 s simulation step. All
graphics are drawn by code and all sounds are generated in memory; Windows plays one sound at a time, so the quiet fuse
ticks are throttled. There is no music.

NOTE ON TESTING
---------------
This project was written without compiling or running it (the author's environment has no .NET SDK or Windows). Please
build it locally; if the compiler reports an error or something behaves wrongly, report it and it will be fixed.
