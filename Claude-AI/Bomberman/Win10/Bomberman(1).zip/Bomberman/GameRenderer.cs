using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace Bomberman;

/// <summary>
/// Draws everything on a 480 x 360 pixel canvas with hard edges and presents it scaled by two with nearest-neighbour
/// filtering. The copyright footer is drawn below the canvas at full resolution.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    private const int VW = GameSettings.ViewW;
    private const int VH = GameSettings.ViewH;
    private const int S = GameSettings.PixelScale;
    private const int T = GameSettings.TileSize;

    private static Rectangle ItemRect(int baseY, int i)
    {
        return new Rectangle(160, baseY + i * 26, 160, 22);
    }

    /// <summary>The clickable menu items of a screen, in window-logical coordinates.</summary>
    public static Rectangle[] RectsFor(GameState state)
    {
        Rectangle[] r;
        switch (state)
        {
            case GameState.Title:
                r = new Rectangle[2];
                for (int i = 0; i < 2; i++) r[i] = ItemRect(250, i);
                break;
            case GameState.Paused:
                r = new Rectangle[4];
                for (int i = 0; i < 4; i++) r[i] = ItemRect(128, i);
                break;
            case GameState.GameOver:
            case GameState.Victory:
                r = new Rectangle[2];
                for (int i = 0; i < 2; i++) r[i] = ItemRect(252, i);
                break;
            case GameState.Controls:
                r = new Rectangle[1];
                r[0] = ItemRect(324, 0);
                break;
            default:
                return new Rectangle[0];
        }
        for (int i = 0; i < r.Length; i++) r[i] = new Rectangle(r[i].X * S, r[i].Y * S, r[i].Width * S, r[i].Height * S);
        return r;
    }

    private readonly Bitmap canvas = new Bitmap(VW, VH, PixelFormat.Format32bppPArgb);
    private readonly Graphics gc;
    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Sprites sprites = new Sprites();
    private readonly Font fSmall;
    private readonly Font fMid;
    private readonly Font fBig;
    private readonly Font fTitle;
    private readonly Font fHead;
    private readonly Font fFooter;
    private readonly StringFormat sfTight = new StringFormat(StringFormat.GenericTypographic);
    private readonly StringFormat sfCenter = new StringFormat();
    private readonly StringFormat sfRight = new StringFormat();
    private readonly StringFormat sfLeft = new StringFormat();
    private readonly StringFormat sfFooter = new StringFormat();
    private readonly List<(float y, int kind, int index)> drawOrder = new List<(float, int, int)>(32);
    private readonly PointF[] star = new PointF[36];

    public GameRenderer()
    {
        gc = Graphics.FromImage(canvas);
        gc.SmoothingMode = SmoothingMode.None;
        gc.InterpolationMode = InterpolationMode.NearestNeighbor;
        gc.PixelOffsetMode = PixelOffsetMode.Half;
        gc.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
        gc.CompositingQuality = CompositingQuality.HighSpeed;

        fSmall = new Font("Consolas", 10f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Consolas", 13f, FontStyle.Bold, GraphicsUnit.Pixel);
        fBig = new Font("Consolas", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fTitle = new Font("Impact", 62f, FontStyle.Regular, GraphicsUnit.Pixel);
        fHead = new Font("Impact", 30f, FontStyle.Regular, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfTight.FormatFlags |= StringFormatFlags.NoWrap;
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfFooter.Alignment = StringAlignment.Center;
        sfFooter.LineAlignment = StringAlignment.Center;
    }

    public void Dispose()
    {
        gc.Dispose();
        canvas.Dispose();
        tmp.Dispose();
        sprites.Dispose();
        fSmall.Dispose();
        fMid.Dispose();
        fBig.Dispose();
        fTitle.Dispose();
        fHead.Dispose();
        fFooter.Dispose();
        sfTight.Dispose();
        sfCenter.Dispose();
        sfRight.Dispose();
        sfLeft.Dispose();
        sfFooter.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private void Rect(Color c, int x, int y, int w, int h)
    {
        gc.FillRectangle(B(c), x, y, w, h);
    }

    private void Txt(string s, Font f, Color c, int x, int y, int align, bool shadow = true)
    {
        StringFormat sf = align == 0 ? sfLeft : (align == 1 ? sfCenter : sfRight);
        if (shadow) gc.DrawString(s, f, B(Color.FromArgb(Math.Min((int)c.A, 255), 10, 8, 24)), x + 1, y + 1, sf);
        gc.DrawString(s, f, B(c), x, y, sf);
    }

    private void Panel(int x, int y, int w, int h, int alpha)
    {
        Rect(Color.FromArgb(alpha, 12, 14, 40), x, y, w, h);
        Color edge = Color.FromArgb(255, 250, 200, 60);
        Rect(edge, x, y, w, 2);
        Rect(edge, x, y + h - 2, w, 2);
        Rect(edge, x, y, 2, h);
        Rect(edge, x + w - 2, y, 2, h);
        Rect(Color.FromArgb(255, 20, 40, 120), x + 2, y + 2, w - 4, 1);
    }

    private static string FormatTime(float seconds)
    {
        int total = Math.Max(0, (int)Math.Ceiling(seconds));
        return (total / 60) + ":" + (total % 60).ToString("D2");
    }

    private void MiniHead(int x, int y)
    {
        Rect(Color.FromArgb(255, 20, 20, 44), x, y + 2, 14, 12);
        Rect(Color.FromArgb(255, 250, 250, 255), x + 1, y + 3, 12, 10);
        Rect(Color.FromArgb(255, 253, 216, 166), x + 3, y + 6, 8, 5);
        Rect(Color.FromArgb(255, 16, 16, 28), x + 5, y + 7, 1, 3);
        Rect(Color.FromArgb(255, 16, 16, 28), x + 8, y + 7, 1, 3);
        Rect(Color.FromArgb(255, 240, 64, 116), x + 6, y, 3, 3);
        Rect(Color.FromArgb(255, 52, 104, 236), x + 1, y + 11, 12, 3);
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        gc.ResetClip();
        gc.ResetTransform();
        gc.Clear(Color.Black);
        switch (e.State)
        {
            case GameState.Title: DrawTitle(e); break;
            case GameState.Controls: DrawControls(e); break;
            default:
                DrawGame(e);
                if (e.State == GameState.Paused) DrawPause(e);
                else if (e.State == GameState.LevelComplete) DrawLevelComplete(e);
                else if (e.State == GameState.GameOver) DrawEnd(e, false);
                else if (e.State == GameState.Victory) DrawEnd(e, true);
                break;
        }

        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;
        float scale = Math.Min(clientW / (float)GameSettings.LogicalW, clientH / (float)GameSettings.LogicalH);
        float offX = (clientW - GameSettings.LogicalW * scale) / 2f;
        float offY = (clientH - GameSettings.LogicalH * scale) / 2f;
        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.SmoothingMode = SmoothingMode.None;
            g.DrawImage(canvas, new Rectangle(0, 0, VW * S, VH * S), 0, 0, VW, VH, GraphicsUnit.Pixel);

            Rectangle foot = new Rectangle(0, VH * S, GameSettings.LogicalW, GameSettings.FooterH);
            using (SolidBrush bg = new SolidBrush(Color.FromArgb(255, 14, 16, 40)))
            using (SolidBrush line = new SolidBrush(Color.FromArgb(255, 250, 200, 60)))
            using (SolidBrush text = new SolidBrush(Color.FromArgb(255, 240, 240, 250)))
            {
                g.FillRectangle(bg, foot);
                g.FillRectangle(line, 0, foot.Y, GameSettings.LogicalW, 2);
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                g.DrawString(FooterText, fFooter, text, new RectangleF(0f, foot.Y + 3f, GameSettings.LogicalW, foot.Height - 3f), sfFooter);
            }
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ the game screen

    private void DrawGame(GameEngine e)
    {
        Maze m = e.Maze;
        // the frame around the board, in the colours of the level theme
        Color[] frame = { Color.FromArgb(255, 30, 70, 120), Color.FromArgb(255, 110, 70, 40), Color.FromArgb(255, 40, 60, 120), Color.FromArgb(255, 40, 30, 80), Color.FromArgb(255, 80, 30, 30) };
        Rect(frame[m.Theme], 0, 0, VW, VH);
        for (int y = 0; y < VH; y += 12)
            for (int x = ((y / 12) & 1) * 12; x < VW; x += 24)
                Rect(Color.FromArgb(40, 255, 255, 255), x, y, 12, 12);

        int shx = 0, shy = 0;
        if (e.Shake > 0f)
        {
            shx = (int)Math.Round(Math.Sin(e.GameTime * 140f) * e.Shake * 8f);
            shy = (int)Math.Round(Math.Cos(e.GameTime * 120f) * e.Shake * 8f);
        }
        GraphicsState st = gc.Save();
        gc.SetClip(new Rectangle(GameSettings.BoardX, GameSettings.BoardY, GameSettings.Cols * T, GameSettings.Rows * T));
        gc.TranslateTransform(shx, shy);
        DrawBoard(e);
        gc.Restore(st);
        gc.ResetClip();

        DrawSidePanels(e);
        DrawHud(e);

        // the "get ready" banner
        if (e.State == GameState.Playing && e.ReadyTimer > 0f)
        {
            Panel(110, 130, 260, 90, 225);
            Txt("STAGE " + e.Level, fHead, Color.FromArgb(255, 255, 220, 70), VW / 2, 156, 1);
            Txt(e.Def.Name, fMid, Color.White, VW / 2, 184, 1);
            Txt(((int)(e.GameTime * 3f) & 1) == 0 ? "GET READY!" : "", fMid, Color.FromArgb(255, 255, 120, 100), VW / 2, 204, 1);
        }
        else if (e.State == GameState.Playing && e.BannerTimer > 0f && e.Banner.Length > 0 && !e.Banner.StartsWith("STAGE"))
        {
            Txt(e.Banner, fHead, Color.FromArgb(255, 255, 240, 120), VW / 2 + 0, 190, 1);
        }
        if (e.NoteTimer > 0f && e.Note.Length > 0 && e.State != GameState.LevelComplete)
        {
            Rect(Color.FromArgb(190, 10, 12, 36), 70, 52, 340, 16);
            Txt(e.Note, fSmall, Color.FromArgb(255, 255, 244, 160), VW / 2, 60, 1);
        }
        if (e.Flash > 0f) Rect(Color.FromArgb((int)Math.Min(120f, 400f * e.Flash), 255, 250, 220), 0, 0, VW, VH);
    }

    private void DrawBoard(GameEngine e)
    {
        Maze m = e.Maze;
        float time = e.GameTime;
        for (int y = 0; y < Maze.Rows; y++)
        {
            for (int x = 0; x < Maze.Cols; x++)
            {
                int px = GameSettings.BoardX + x * T;
                int py = GameSettings.BoardY + y * T;
                TileType type = m.Cells[x, y].Type;
                bool open = type == TileType.Empty;
                bool sTop = open && y > 0 && m.Cells[x, y - 1].Type != TileType.Empty;
                bool sLeft = open && x > 0 && m.Cells[x - 1, y].Type != TileType.Empty;
                sprites.DrawFloor(gc, px, py, x, y, m.Theme, sTop, sLeft, time);
                if (type == TileType.Wall) sprites.DrawWall(gc, px, py, x, y, m.Theme, x == 0 || y == 0 || x == Maze.Cols - 1 || y == Maze.Rows - 1);
                else if (type == TileType.Brick) sprites.DrawBrick(gc, px, py, x, y, m.Theme, false);
                else if (m.ExitRevealed && x == m.ExitX && y == m.ExitY) sprites.DrawExit(gc, px, py, e.ExitActive, time);
            }
        }
        foreach (PowerUp p in e.PowerUps) sprites.DrawPowerUp(gc, p, time);
        foreach (Bomb b in e.Bombs) sprites.DrawBomb(gc, b, time);
        foreach (Explosion ex in e.Explosions)
        {
            float prog = ex.Progress;
            foreach (BlastCell c in ex.Cells) sprites.DrawFlame(gc, c, prog, time);
        }

        // characters, sorted by depth so those lower on the screen are in front
        drawOrder.Clear();
        for (int i = 0; i < e.Enemies.Count; i++) drawOrder.Add((e.Enemies[i].Y, 0, i));
        drawOrder.Add((e.Player.Y + 0.01f, 1, 0));
        drawOrder.Sort((a, b) => a.y.CompareTo(b.y));
        foreach (var d in drawOrder)
        {
            if (d.kind == 0) sprites.DrawEnemy(gc, e.Enemies[d.index], time);
            else sprites.DrawPlayer(gc, e.Player, time);
        }
        sprites.DrawParticles(gc, e.Particles);
    }

    private void DrawSidePanels(GameEngine e)
    {
        Color dark = Color.FromArgb(220, 10, 12, 34);
        Rect(dark, 0, GameSettings.BoardY, GameSettings.BoardX, VH - GameSettings.BoardY);
        Rect(dark, GameSettings.BoardX + GameSettings.Cols * T, GameSettings.BoardY, GameSettings.BoardX, VH - GameSettings.BoardY);
        Color edge = Color.FromArgb(255, 250, 200, 60);
        Rect(edge, GameSettings.BoardX - 1, GameSettings.BoardY, 1, VH - GameSettings.BoardY);
        Rect(edge, GameSettings.BoardX + GameSettings.Cols * T, GameSettings.BoardY, 1, VH - GameSettings.BoardY);

        // left: the stage and the enemies that remain
        Txt("STAGE", fSmall, Color.FromArgb(255, 250, 200, 60), 30, 66, 1);
        Txt(e.Level.ToString(), fBig, Color.White, 30, 88, 1);
        Txt("ENEMIES", fSmall, Color.FromArgb(255, 250, 200, 60), 30, 126, 1);
        sprites.DrawEnemyAt(gc, EnemyType.Balloon, 30, 164, 0, 1, e.GameTime, 1, 0f);
        Txt("x" + e.AliveEnemies, fMid, Color.White, 30, 176, 1);
        Txt("BLOCKS", fSmall, Color.FromArgb(255, 250, 200, 60), 30, 210, 1);
        Txt(e.Blocks.ToString(), fMid, Color.White, 30, 226, 1);

        // right: the exit and the controls reminder
        int rx = GameSettings.BoardX + GameSettings.Cols * T + 30;
        Txt("EXIT", fSmall, Color.FromArgb(255, 250, 200, 60), rx, 66, 1);
        string exitText = !e.Maze.ExitRevealed ? "HIDDEN" : (e.ExitActive ? "OPEN!" : "LOCKED");
        Color exitColor = e.ExitActive ? Color.FromArgb(255, 120, 255, 160) : (e.Maze.ExitRevealed ? Color.FromArgb(255, 255, 190, 80) : Color.FromArgb(255, 200, 200, 220));
        Txt(exitText, fSmall, exitColor, rx, 82, 1);
        Txt("SPACE", fSmall, Color.White, rx, 270, 1);
        Txt("BOMB", fSmall, Color.FromArgb(255, 200, 210, 240), rx, 282, 1);
        if (e.Player.CanRemote)
        {
            Txt("Z", fSmall, Color.White, rx, 304, 1);
            Txt("DETONATE", fSmall, Color.FromArgb(255, 200, 210, 240), rx, 316, 1);
        }
        Txt("ESC", fSmall, Color.White, rx, 338, 1);
        Txt("PAUSE", fSmall, Color.FromArgb(255, 200, 210, 240), rx, 348 - 0, 1);
    }

    private void DrawHud(GameEngine e)
    {
        Player p = e.Player;
        for (int i = 0; i < 6; i++) Rect(Color.FromArgb(255, 14 + i * 2, 18 + i * 3, 52 + i * 5), 0, i * 8, VW, 8);
        Rect(Color.FromArgb(255, 250, 200, 60), 0, 47, VW, 1);
        Rect(Color.FromArgb(255, 250, 200, 60), 0, 25, VW, 1);

        // top row: lives, score, stage, time, high score
        MiniHead(8, 5);
        Txt("x" + Math.Max(0, p.Lives), fMid, Color.White, 26, 13, 0);
        Txt("SCORE", fSmall, Color.FromArgb(255, 250, 200, 60), 64, 6, 0);
        Txt(p.Score.ToString("D7"), fMid, Color.White, 64, 17, 0);
        Txt("STAGE " + e.Level + " - " + e.Def.Name, fSmall, Color.FromArgb(255, 250, 240, 180), 240, 13, 1);
        bool low = e.LevelTime < 30f;
        Rect(Color.FromArgb(255, 250, 250, 255), 332, 6, 12, 12);
        Rect(Color.FromArgb(255, 220, 50, 60), 333, 7, 10, 10);
        Rect(Color.FromArgb(255, 250, 250, 255), 337, 8, 1, 5);
        Rect(Color.FromArgb(255, 250, 250, 255), 337, 12, 4, 1);
        Txt(FormatTime(e.LevelTime), fMid, low && ((int)(e.Clock * 4f) & 1) == 0 ? Color.FromArgb(255, 255, 90, 80) : Color.White, 350, 13, 0);
        Txt("HI " + Math.Max(e.Scores.Best, p.Score).ToString("D7"), fSmall, Color.FromArgb(255, 255, 224, 100), VW - 6, 13, 2);

        // second row: bomb capacity, explosion range, speed and the special upgrades
        float t = e.Clock;
        sprites.DrawPowerIcon(gc, PowerUpType.BombUp, 8, 29, 16, t);
        Txt("x" + p.MaxBombs, fMid, Color.White, 27, 38, 0);
        sprites.DrawPowerIcon(gc, PowerUpType.FireUp, 62, 29, 16, t);
        Txt("x" + p.Range, fMid, Color.White, 81, 38, 0);
        sprites.DrawPowerIcon(gc, PowerUpType.SpeedUp, 116, 29, 16, t);
        for (int i = 0; i < GameSettings.MaxSpeedLevel; i++)
            Rect(i < p.SpeedLevel ? Color.FromArgb(255, 100, 230, 240) : Color.FromArgb(255, 50, 60, 100), 136 + i * 7, 33, 5, 9);
        sprites.DrawPowerIcon(gc, PowerUpType.Kick, 176, 29, 16, t);
        if (!p.CanKick) Rect(Color.FromArgb(170, 14, 16, 40), 176, 29, 16, 16);
        sprites.DrawPowerIcon(gc, PowerUpType.Remote, 198, 29, 16, t);
        if (!p.CanRemote) Rect(Color.FromArgb(170, 14, 16, 40), 198, 29, 16, 16);
        Txt("KICK", fSmall, p.CanKick ? Color.FromArgb(255, 150, 255, 160) : Color.FromArgb(255, 110, 116, 150), 232, 38, 0);
        Txt("REMOTE", fSmall, p.CanRemote ? Color.FromArgb(255, 255, 150, 140) : Color.FromArgb(255, 110, 116, 150), 272, 38, 0);
        Txt("BOMBS " + Math.Max(0, p.MaxBombs - e.Bombs.Count) + "/" + p.MaxBombs, fSmall, Color.FromArgb(255, 220, 230, 255), VW - 6, 38, 2);
    }

    // ------------------------------------------------------------------ title and controls

    private void DrawTitleBackground(float clock, int alpha)
    {
        sprites.DrawFloor(gc, 0, 0, 0, 0, 0, false, false, clock);
        for (int ty = 0; ty < 15; ty++)
        {
            for (int tx = 0; tx < 20; tx++)
            {
                int px = tx * T;
                int py = ty * T;
                sprites.DrawFloor(gc, px, py, tx, ty, 0, false, false, clock);
                bool border = tx == 0 || ty == 0 || tx == 19 || ty == 14;
                int h = (tx * 7 + ty * 13 + tx * ty) % 9;
                if (border || (tx % 2 == 0 && ty % 2 == 0)) sprites.DrawWall(gc, px, py, tx, ty, 0, border);
                else if (h < 2) sprites.DrawBrick(gc, px, py, tx, ty, 0, false);
            }
        }
        Rect(Color.FromArgb(alpha, 10, 20, 50), 0, 0, VW, VH);
    }

    private void DrawTitle(GameEngine e)
    {
        float clock = e.Clock;
        DrawTitleBackground(clock, 40);

        // flowers of fire: an explosion cross that repeats
        float cyc = clock % 2.8f;
        if (cyc < Explosion.Duration)
        {
            float pr = cyc / Explosion.Duration;
            int cx = 360, cy = 270;
            sprites.DrawFlameAt(gc, cx, cy, FlameKind.Center, 1, 1, pr, clock);
            sprites.DrawFlameAt(gc, cx - T, cy, FlameKind.Horizontal, 2, 1, pr, clock);
            sprites.DrawFlameAt(gc, cx - 2 * T, cy, FlameKind.EndLeft, 3, 1, pr, clock);
            sprites.DrawFlameAt(gc, cx + T, cy, FlameKind.Horizontal, 4, 1, pr, clock);
            sprites.DrawFlameAt(gc, cx + 2 * T, cy, FlameKind.EndRight, 5, 1, pr, clock);
            sprites.DrawFlameAt(gc, cx, cy - T, FlameKind.Vertical, 6, 1, pr, clock);
            sprites.DrawFlameAt(gc, cx, cy - 2 * T, FlameKind.EndUp, 7, 1, pr, clock);
            sprites.DrawFlameAt(gc, cx, cy + T, FlameKind.Vertical, 8, 1, pr, clock);
            sprites.DrawFlameAt(gc, cx, cy + 2 * T, FlameKind.EndDown, 9, 1, pr, clock);
        }

        // the characters
        sprites.DrawEnemyAt(gc, EnemyType.Balloon, 40 + (int)(Math.Sin(clock * 1.1) * 8), 184, 1, 0, clock, 2, 0f);
        sprites.DrawEnemyAt(gc, EnemyType.Wisp, 440 + (int)(Math.Sin(clock * 1.3) * 8), 184, -1, 0, clock, 2, 0f);
        sprites.DrawEnemyAt(gc, EnemyType.Chaser, 430, 340 + (int)(Math.Sin(clock * 2) * 2), -1, 0, clock, 2, 0f);
        sprites.DrawEnemyAt(gc, EnemyType.Smart, 280, 350, -1, 0, clock + 1f, 2, 0f);
        sprites.DrawPowerIcon(gc, PowerUpType.FireUp, 14, 224 + (int)(Math.Sin(clock * 3) * 3), 20, clock);
        sprites.DrawPowerIcon(gc, PowerUpType.SpeedUp, 446, 232 + (int)(Math.Cos(clock * 3) * 3), 20, clock);
        sprites.DrawBomberman(gc, 74, 340 + (int)(Math.Round(Math.Sin(clock * 3) * 2)), 0, 0f, clock, 3, 0, 0f);
        sprites.DrawBigBomb(gc, 138, 300, 2, clock, 0f);

        // the title on a blue burst
        int bx = VW / 2;
        int by = 62;
        int pts = 36;
        for (int i = 0; i < pts; i++)
        {
            double a = i * Math.PI * 2 / pts;
            double r = (i % 2 == 0) ? 1.0 : 0.72;
            double wob = 1.0 + 0.04 * Math.Sin(clock * 6 + i);
            star[i] = new PointF((float)(bx + Math.Cos(a) * 225 * r * wob), (float)(by + Math.Sin(a) * 66 * r * wob));
        }
        gc.FillPolygon(B(Color.FromArgb(255, 14, 90, 200)), star);
        for (int i = 0; i < pts; i++)
        {
            double a = i * Math.PI * 2 / pts;
            double r = (i % 2 == 0) ? 0.93 : 0.66;
            star[i] = new PointF((float)(bx + Math.Cos(a) * 225 * r), (float)(by + Math.Sin(a) * 66 * r));
        }
        gc.FillPolygon(B(Color.FromArgb(255, 40, 160, 255)), star);

        SizeF sB = gc.MeasureString("B", fTitle, 400, sfTight);
        SizeF sR = gc.MeasureString("MBERMAN", fTitle, 800, sfTight);
        float bombW = 46f;
        float total = sB.Width + bombW + sR.Width;
        float x0 = (VW - total) / 2f;
        float y0 = 22f;
        string[] parts = { "B", "MBERMAN" };
        float[] xs = { x0, x0 + sB.Width + bombW };
        float[] ws = { sB.Width, sR.Width };
        for (int k = 0; k < 2; k++)
        {
            for (int dx = -3; dx <= 3; dx++)
            {
                for (int dy = -3; dy <= 3; dy++)
                {
                    if (Math.Abs(dx) + Math.Abs(dy) > 4 || (dx == 0 && dy == 0)) continue;
                    gc.DrawString(parts[k], fTitle, B(Color.FromArgb(255, 70, 24, 6)), xs[k] + dx, y0 + dy + 2, sfTight);
                }
            }
            using (LinearGradientBrush fill = new LinearGradientBrush(new RectangleF(xs[k], y0, ws[k] + 1, sB.Height), Color.FromArgb(255, 255, 238, 80), Color.FromArgb(255, 250, 120, 10), 90f))
            {
                gc.DrawString(parts[k], fTitle, fill, xs[k], y0, sfTight);
            }
        }
        sprites.DrawBigBomb(gc, x0 + sB.Width + bombW / 2f + 2f, y0 + 46f, 2, clock, 0f);

        // the menu
        string[] items = { "PLAY", "CONTROLS" };
        for (int i = 0; i < 2; i++) MenuItem(items[i], ItemRect(250, i), e.TitleIndex == i, clock);
        Txt("HIGH SCORE  " + e.Scores.Best.ToString("D7"), fMid, Color.FromArgb(255, 255, 230, 100), VW / 2, 316, 1);
        Txt("UP / DOWN + ENTER", fSmall, Color.FromArgb(255, 220, 232, 255), VW / 2, 334, 1);
    }

    private void MenuItem(string text, Rectangle r, bool selected, float clock)
    {
        if (selected)
        {
            Rect(Color.FromArgb(220, 12, 14, 44), r.X, r.Y, r.Width, r.Height);
            Rect(Color.FromArgb(255, 250, 200, 60), r.X, r.Y, r.Width, 2);
            Rect(Color.FromArgb(255, 250, 200, 60), r.X, r.Y + r.Height - 2, r.Width, 2);
            if (((int)(clock * 4f) & 1) == 0)
            {
                Rect(Color.FromArgb(255, 255, 230, 90), r.X + 10, r.Y + 6, 6, 10);
                Rect(Color.FromArgb(255, 255, 230, 90), r.Right - 16, r.Y + 6, 6, 10);
            }
        }
        else
        {
            Rect(Color.FromArgb(130, 12, 14, 44), r.X, r.Y, r.Width, r.Height);
        }
        Txt(text, fMid, selected ? Color.FromArgb(255, 255, 230, 90) : Color.White, r.X + r.Width / 2, r.Y + 11, 1);
    }

    private void DrawControls(GameEngine e)
    {
        DrawTitleBackground(e.Clock, 130);
        Panel(14, 12, VW - 28, 346 - 14, 240);
        Txt("CONTROLS", fHead, Color.FromArgb(255, 255, 220, 70), VW / 2, 34, 1);
        string[,] keys =
        {
            { "ARROWS", "MOVE" },
            { "SPACE", "PLACE BOMB" },
            { "Z / CTRL", "DETONATE REMOTE BOMBS" },
            { "ESC", "PAUSE / RESUME" },
            { "ENTER", "RESTART AFTER GAME OVER" },
            { "M", "SOUND ON / OFF (PAUSE)" }
        };
        for (int i = 0; i < keys.GetLength(0); i++)
        {
            int y = 68 + i * 20;
            Rect(Color.FromArgb(255, 60, 70, 130), 30, y - 7, 86, 15);
            Rect(Color.FromArgb(255, 110, 124, 200), 30, y - 7, 86, 1);
            Txt(keys[i, 0], fSmall, Color.White, 73, y, 1);
            Txt(keys[i, 1], fSmall, Color.FromArgb(255, 230, 236, 255), 124, y, 0);
        }
        Txt("POWER-UPS (hidden in bricks)", fSmall, Color.FromArgb(255, 250, 200, 60), 30, 198, 0);
        PowerUpType[] types = { PowerUpType.BombUp, PowerUpType.FireUp, PowerUpType.SpeedUp, PowerUpType.Kick, PowerUpType.Remote };
        for (int i = 0; i < types.Length; i++)
        {
            int y = 210 + i * 21;
            sprites.DrawPowerIcon(gc, types[i], 30, y, 16, e.Clock);
            Txt(PowerUp.Name(types[i]), fSmall, Color.White, 54, y + 8, 0);
            Txt(PowerUp.Description(types[i]), fSmall, Color.FromArgb(255, 190, 204, 240), 160, y + 8, 0);
        }
        Txt("Defeat every enemy, find the exit under a brick and walk in.", fSmall, Color.FromArgb(255, 200, 255, 200), VW / 2, 318, 1);
        MenuItem("BACK  [ENTER]", ItemRect(324, 0), true, e.Clock);
    }

    // ------------------------------------------------------------------ overlays

    private void DrawPause(GameEngine e)
    {
        Rect(Color.FromArgb(170, 6, 8, 24), 0, 0, VW, VH);
        Panel(130, 70, 220, 168, 240);
        Txt("PAUSED", fHead, Color.White, VW / 2, 96, 1);
        string[] labels = { "RESUME", "RESTART", "SOUND: " + (SoundManager.Muted ? "OFF" : "ON"), "TITLE SCREEN" };
        for (int i = 0; i < 4; i++) MenuItem(labels[i], ItemRect(128, i), e.PauseIndex == i, e.Clock);
    }

    private void DrawLevelComplete(GameEngine e)
    {
        Panel(100, 70, 280, 210, 235);
        Txt("STAGE CLEAR!", fHead, Color.FromArgb(255, 255, 220, 70), VW / 2, 96, 1);
        Txt("CLEAR BONUS   " + e.ClearBonus, fMid, Color.White, VW / 2 + 20, 138, 1);
        Txt("TIME BONUS    " + e.TimeBonus, fMid, Color.White, VW / 2 + 20, 160, 1);
        Txt("SCORE  " + e.Player.Score.ToString("D7"), fMid, Color.FromArgb(255, 255, 230, 100), VW / 2 + 20, 190, 1);
        sprites.DrawBomberman(gc, 150, 236, 0, 0f, e.GameTime, 2, 3, 0f);
        if (e.CompleteTimer > 1.2f && ((int)(e.Clock * 3f) & 1) == 0)
            Txt("PRESS ENTER", fSmall, Color.White, VW / 2 + 20, 250, 1);
        sprites.DrawParticles(gc, e.Particles);
    }

    private void DrawEnd(GameEngine e, bool victory)
    {
        Rect(Color.FromArgb(185, 6, 8, 24), 0, 0, VW, VH);
        Panel(90, 40, 300, 262, 240);
        if (victory)
        {
            Txt("CONGRATULATIONS!", fHead, Color.FromArgb(255, 255, 220, 70), VW / 2, 66, 1);
            Txt("ALL " + GameSettings.LevelCount + " STAGES CLEARED", fMid, Color.FromArgb(255, 130, 255, 170), VW / 2, 94, 1);
            sprites.DrawBomberman(gc, 130, 214, 0, 0f, e.GameTime, 2, 3, 0f);
        }
        else
        {
            Txt("GAME OVER", fHead, Color.FromArgb(255, 255, 90, 80), VW / 2, 70, 1);
            Txt("STAGE " + e.Level + " - " + e.Def.Name, fSmall, Color.FromArgb(255, 220, 230, 255), VW / 2, 96, 1);
        }
        int x = victory ? VW / 2 + 30 : VW / 2;
        Txt("FINAL SCORE", fSmall, Color.FromArgb(255, 250, 200, 60), x, 126, 1);
        Txt(e.Player.Score.ToString("D7"), fBig, Color.White, x, 148, 1);
        Txt("HIGH SCORE  " + e.Scores.Best.ToString("D7"), fMid, Color.FromArgb(255, 255, 230, 100), x, 180, 1);
        if (e.NewRecord && ((int)(e.Clock * 3f) & 1) == 0) Txt("NEW HIGH SCORE!", fMid, Color.FromArgb(255, 255, 120, 100), x, 202, 1);
        Txt("ENEMIES " + e.Kills + "   BLOCKS " + e.Blocks, fSmall, Color.FromArgb(255, 220, 230, 255), x, 226, 1);
        string[] labels = { "RESTART  [ENTER]", "TITLE SCREEN" };
        for (int i = 0; i < 2; i++) MenuItem(labels[i], ItemRect(252, i), e.EndIndex == i, e.Clock);
        sprites.DrawParticles(gc, e.Particles);
    }
}
