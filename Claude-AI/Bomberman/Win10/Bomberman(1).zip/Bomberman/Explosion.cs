namespace Bomberman;

public enum FlameKind { Center, Horizontal, Vertical, EndUp, EndDown, EndLeft, EndRight }

/// <summary>One tile of an explosion. The visuals use exactly these tiles, and so does the damage.</summary>
public struct BlastCell
{
    public int X, Y;
    public FlameKind Kind;
    public bool Brick;           // this tile held a brick, which the blast destroys
}

public sealed class Explosion
{
    public const float Duration = 0.65f;

    public readonly List<BlastCell> Cells = new List<BlastCell>(16);
    public float Age;

    public float Progress { get { return Math.Min(1f, Age / Duration); } }
    public bool Done { get { return Age >= Duration; } }
}
