namespace Bomberman;

/// <summary>Definition of one level: the wall layout, how many bricks, which enemies and which hidden power-ups.</summary>
public sealed class LevelDef
{
    public string Name = "";
    public string[] Layout = Array.Empty<string>();
    public float BrickDensity;
    public int Theme;
    public int Balloons, Wisps, Chasers, Smarts;
    public int Time;
    public PowerUpType[] PowerUps = Array.Empty<PowerUpType>();
}

/// <summary>All fixed numbers of the game and the five level definitions.</summary>
public static class GameSettings
{
    // the pixel canvas is scaled up by two with nearest-neighbour filtering; the footer is drawn below it at full size
    public const int TileSize = 24;
    public const int Cols = 15;
    public const int Rows = 13;
    public const int BoardX = 60;
    public const int BoardY = 48;
    public const int ViewW = 480;
    public const int ViewH = 360;
    public const int PixelScale = 2;
    public const int LogicalW = ViewW * PixelScale;                 // 960
    public const int FooterH = 32;
    public const int LogicalH = ViewH * PixelScale + FooterH;       // 752

    public const int StartLives = 3;
    public const int MaxBombsLimit = 6;
    public const int MaxRangeLimit = 8;
    public const int MaxSpeedLevel = 4;
    public const float PlayerInvulnerability = 3f;
    public const float ExplosionFuse = 2.8f;

    public const int ScoreBrick = 10;
    public const int ScorePowerUp = 50;
    public const int ScoreLevel = 1000;
    public const int ScoreTimeBonusPerSecond = 10;
    public static readonly int[] ScoreEnemy = { 100, 200, 300, 400 };

    public const int LevelCount = 5;

    private static string[] Classic()
    {
        string open = "#.............#";
        string pillars = "#.#.#.#.#.#.#.#";
        string border = "###############";
        return new[] { border, open, pillars, open, pillars, open, pillars, open, pillars, open, pillars, open, border };
    }

    public static readonly LevelDef[] Levels =
    {
        new LevelDef
        {
            Name = "GREEN FIELD", Theme = 0, BrickDensity = 0.55f, Time = 180, Balloons = 3,
            Layout = Classic(),
            PowerUps = new[] { PowerUpType.BombUp, PowerUpType.FireUp, PowerUpType.SpeedUp }
        },
        new LevelDef
        {
            Name = "SUNNY DESERT", Theme = 1, BrickDensity = 0.6f, Time = 180, Balloons = 3, Wisps = 2,
            Layout = new[]
            {
                "###############",
                "#.............#",
                "#.#.#.#.#.#.#.#",
                "#.............#",
                "#.#.#.....#.#.#",
                "#.............#",
                "#.#.#.###.#.#.#",
                "#.............#",
                "#.#.#.....#.#.#",
                "#.............#",
                "#.#.#.#.#.#.#.#",
                "#.............#",
                "###############"
            },
            PowerUps = new[] { PowerUpType.BombUp, PowerUpType.FireUp, PowerUpType.SpeedUp, PowerUpType.Kick }
        },
        new LevelDef
        {
            Name = "FROZEN HALLS", Theme = 2, BrickDensity = 0.62f, Time = 190, Balloons = 2, Wisps = 2, Chasers = 2,
            Layout = new[]
            {
                "###############",
                "#.............#",
                "#.##.#...#.##.#",
                "#.............#",
                "#.#.#.#.#.#.#.#",
                "#...#.....#...#",
                "#.#...#.#...#.#",
                "#...#.....#...#",
                "#.#.#.#.#.#.#.#",
                "#.............#",
                "#.##.#...#.##.#",
                "#.............#",
                "###############"
            },
            PowerUps = new[] { PowerUpType.BombUp, PowerUpType.BombUp, PowerUpType.FireUp, PowerUpType.SpeedUp, PowerUpType.Remote }
        },
        new LevelDef
        {
            Name = "MIDNIGHT RUINS", Theme = 3, BrickDensity = 0.66f, Time = 200, Balloons = 2, Wisps = 2, Chasers = 2, Smarts = 1,
            Layout = new[]
            {
                "###############",
                "#.............#",
                "#.###.#.#.###.#",
                "#.............#",
                "#.#.#.#.#.#.#.#",
                "#.............#",
                "#.#.###.###.#.#",
                "#.............#",
                "#.#.#.#.#.#.#.#",
                "#.............#",
                "#.###.#.#.###.#",
                "#.............#",
                "###############"
            },
            PowerUps = new[] { PowerUpType.BombUp, PowerUpType.FireUp, PowerUpType.FireUp, PowerUpType.SpeedUp, PowerUpType.Kick }
        },
        new LevelDef
        {
            Name = "VOLCANO CORE", Theme = 4, BrickDensity = 0.7f, Time = 220, Balloons = 2, Wisps = 3, Chasers = 2, Smarts = 2,
            Layout = new[]
            {
                "###############",
                "#.............#",
                "#.#.#.#.#.#.#.#",
                "#..#.......#..#",
                "#.#.#.#.#.#.#.#",
                "#.....#.#.....#",
                "#.#.#.....#.#.#",
                "#.....#.#.....#",
                "#.#.#.#.#.#.#.#",
                "#..#.......#..#",
                "#.#.#.#.#.#.#.#",
                "#.............#",
                "###############"
            },
            PowerUps = new[] { PowerUpType.BombUp, PowerUpType.BombUp, PowerUpType.FireUp, PowerUpType.SpeedUp, PowerUpType.Remote }
        }
    };
}
