namespace Bomberman;

public struct EnemySpawn
{
    public EnemyType Type;
    public int X, Y;
}

/// <summary>
/// The tile grid of one level: indestructible walls, destructible bricks hiding power-ups and the exit, the safe start
/// area and the enemy spawns. Also holds the live flame and danger maps used by the explosions and the enemy AI.
/// </summary>
public sealed class Maze
{
    public const int Cols = GameSettings.Cols;
    public const int Rows = GameSettings.Rows;

    public readonly Cell[,] Cells = new Cell[Cols, Rows];
    public readonly float[,] Flame = new float[Cols, Rows];     // seconds of fire left on each tile
    public readonly bool[,] Danger = new bool[Cols, Rows];      // tiles a bomb is about to burn
    public readonly List<EnemySpawn> Spawns = new List<EnemySpawn>(12);
    public int Theme;
    public int ExitX, ExitY;
    public bool ExitRevealed;
    public int BrickCount;

    public const int StartX = 1;
    public const int StartY = 1;

    public bool InBounds(int x, int y)
    {
        return x >= 0 && y >= 0 && x < Cols && y < Rows;
    }

    public bool IsWall(int x, int y)
    {
        return !InBounds(x, y) || Cells[x, y].Type == TileType.Wall;
    }

    public bool IsBrick(int x, int y)
    {
        return InBounds(x, y) && Cells[x, y].Type == TileType.Brick;
    }

    public bool IsBlocking(int x, int y)
    {
        return !InBounds(x, y) || Cells[x, y].Type != TileType.Empty;
    }

    private static int Hash(int a, int b)
    {
        unchecked
        {
            int h = a * 73856093 ^ b * 19349663;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    // ------------------------------------------------------------------ building

    public static Maze Build(int level, Random rng)
    {
        LevelDef def = GameSettings.Levels[Math.Max(0, Math.Min(GameSettings.LevelCount - 1, level - 1))];
        Maze m = new Maze();
        m.Theme = def.Theme;
        for (int y = 0; y < Rows; y++)
        {
            for (int x = 0; x < Cols; x++)
            {
                m.Cells[x, y].Type = def.Layout[y][x] == '#' ? TileType.Wall : TileType.Empty;
                m.Cells[x, y].Variant = (byte)(Hash(x, y + level * 31) % 4);
            }
        }
        m.EnsureConnected();

        // the safe start area stays clear of bricks so the player can always place a bomb and get away
        HashSet<int> safe = new HashSet<int>();
        int[,] keep = { { 1, 1 }, { 2, 1 }, { 3, 1 }, { 4, 1 }, { 1, 2 }, { 1, 3 }, { 1, 4 } };
        for (int i = 0; i < keep.GetLength(0); i++) safe.Add(keep[i, 1] * Cols + keep[i, 0]);

        for (int y = 1; y < Rows - 1; y++)
        {
            for (int x = 1; x < Cols - 1; x++)
            {
                if (m.Cells[x, y].Type != TileType.Empty || safe.Contains(y * Cols + x)) continue;
                if (rng.NextDouble() < def.BrickDensity) m.Cells[x, y].Type = TileType.Brick;
            }
        }

        // enemy spawns far from the start, each with room to move
        List<Point> candidates = new List<Point>();
        for (int y = 1; y < Rows - 1; y++)
        {
            for (int x = 1; x < Cols - 1; x++)
            {
                if (m.Cells[x, y].Type == TileType.Wall) continue;
                if (Math.Abs(x - StartX) + Math.Abs(y - StartY) >= 8) candidates.Add(new Point(x, y));
            }
        }
        Shuffle(candidates, rng);
        List<EnemyType> types = new List<EnemyType>();
        for (int i = 0; i < def.Balloons; i++) types.Add(EnemyType.Balloon);
        for (int i = 0; i < def.Wisps; i++) types.Add(EnemyType.Wisp);
        for (int i = 0; i < def.Chasers; i++) types.Add(EnemyType.Chaser);
        for (int i = 0; i < def.Smarts; i++) types.Add(EnemyType.Smart);
        List<Point> used = new List<Point>();
        foreach (EnemyType t in types)
        {
            Point? pick = null;
            foreach (Point c in candidates)
            {
                bool near = false;
                foreach (Point u in used)
                {
                    if (Math.Abs(u.X - c.X) + Math.Abs(u.Y - c.Y) < 4) near = true;
                }
                if (!near) { pick = c; break; }
            }
            if (pick == null && candidates.Count > 0) pick = candidates[0];
            if (pick == null) break;
            Point p = pick.Value;
            candidates.Remove(p);
            used.Add(p);
            m.Cells[p.X, p.Y].Type = TileType.Empty;
            m.ClearNeighbours(p.X, p.Y, 2, rng);
            EnemySpawn s = new EnemySpawn();
            s.Type = t; s.X = p.X; s.Y = p.Y;
            m.Spawns.Add(s);
        }

        // the exit and the power-ups hide inside bricks
        List<Point> bricks = new List<Point>();
        for (int y = 1; y < Rows - 1; y++)
        {
            for (int x = 1; x < Cols - 1; x++)
            {
                if (m.Cells[x, y].Type == TileType.Brick) bricks.Add(new Point(x, y));
            }
        }
        m.BrickCount = bricks.Count;
        Shuffle(bricks, rng);
        int exitIndex = bricks.FindIndex(b => Math.Abs(b.X - StartX) + Math.Abs(b.Y - StartY) >= 9);
        if (exitIndex < 0) exitIndex = 0;
        Point ex = bricks[exitIndex];
        bricks.RemoveAt(exitIndex);
        m.Cells[ex.X, ex.Y].HasExit = true;
        m.ExitX = ex.X;
        m.ExitY = ex.Y;
        for (int i = 0; i < def.PowerUps.Length && i < bricks.Count; i++)
        {
            Point b = bricks[i];
            m.Cells[b.X, b.Y].Hidden = def.PowerUps[i];
        }
        return m;
    }

    private static void Shuffle<T>(List<T> list, Random rng)
    {
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = rng.Next(i + 1);
            T tmp = list[i];
            list[i] = list[j];
            list[j] = tmp;
        }
    }

    private void ClearNeighbours(int x, int y, int count, Random rng)
    {
        int[] dx = { 0, 0, -1, 1 };
        int[] dy = { -1, 1, 0, 0 };
        List<int> order = new List<int> { 0, 1, 2, 3 };
        Shuffle(order, rng);
        int cleared = 0;
        foreach (int d in order)
        {
            int nx = x + dx[d];
            int ny = y + dy[d];
            if (!InBounds(nx, ny) || Cells[nx, ny].Type == TileType.Wall) continue;
            Cells[nx, ny].Type = TileType.Empty;
            if (++cleared >= count) break;
        }
    }

    /// <summary>Guarantees that every non-wall tile can be reached from the start (opening a wall if a layout needs it).</summary>
    private void EnsureConnected()
    {
        int[] dx = { 0, 0, -1, 1 };
        int[] dy = { -1, 1, 0, 0 };
        for (int pass = 0; pass < 20; pass++)
        {
            bool[,] seen = new bool[Cols, Rows];
            Queue<Point> q = new Queue<Point>();
            q.Enqueue(new Point(StartX, StartY));
            seen[StartX, StartY] = true;
            while (q.Count > 0)
            {
                Point p = q.Dequeue();
                for (int d = 0; d < 4; d++)
                {
                    int nx = p.X + dx[d];
                    int ny = p.Y + dy[d];
                    if (!InBounds(nx, ny) || seen[nx, ny] || Cells[nx, ny].Type == TileType.Wall) continue;
                    seen[nx, ny] = true;
                    q.Enqueue(new Point(nx, ny));
                }
            }
            bool fixedAny = false;
            for (int y = 1; y < Rows - 1; y++)
            {
                for (int x = 1; x < Cols - 1; x++)
                {
                    if (Cells[x, y].Type == TileType.Wall || seen[x, y]) continue;
                    // open an interior wall that touches both this isolated area and the reachable area
                    for (int d = 0; d < 4 && !fixedAny; d++)
                    {
                        int wx = x + dx[d];
                        int wy = y + dy[d];
                        if (wx < 1 || wy < 1 || wx >= Cols - 1 || wy >= Rows - 1 || Cells[wx, wy].Type != TileType.Wall) continue;
                        for (int e = 0; e < 4; e++)
                        {
                            int ax = wx + dx[e];
                            int ay = wy + dy[e];
                            if (InBounds(ax, ay) && seen[ax, ay])
                            {
                                Cells[wx, wy].Type = TileType.Empty;
                                fixedAny = true;
                                break;
                            }
                        }
                    }
                }
            }
            if (!fixedAny) return;
        }
    }

    // ------------------------------------------------------------------ blasts and bricks

    /// <summary>The tiles a bomb at (bx, by) burns: walls stop the blast, a brick is burnt and stops it.</summary>
    public void CollectBlast(int bx, int by, int range, List<BlastCell> output)
    {
        BlastCell c = new BlastCell();
        c.X = bx; c.Y = by; c.Kind = FlameKind.Center;
        output.Add(c);
        int[] dx = { 0, 0, -1, 1 };
        int[] dy = { -1, 1, 0, 0 };
        for (int d = 0; d < 4; d++)
        {
            for (int i = 1; i <= range; i++)
            {
                int x = bx + dx[d] * i;
                int y = by + dy[d] * i;
                if (!InBounds(x, y) || Cells[x, y].Type == TileType.Wall) break;
                bool brick = Cells[x, y].Type == TileType.Brick;
                bool end = brick || i == range;
                BlastCell cell = new BlastCell();
                cell.X = x; cell.Y = y; cell.Brick = brick;
                if (end)
                {
                    switch (d)
                    {
                        case 0: cell.Kind = FlameKind.EndUp; break;
                        case 1: cell.Kind = FlameKind.EndDown; break;
                        case 2: cell.Kind = FlameKind.EndLeft; break;
                        default: cell.Kind = FlameKind.EndRight; break;
                    }
                }
                else
                {
                    cell.Kind = d < 2 ? FlameKind.Vertical : FlameKind.Horizontal;
                }
                output.Add(cell);
                if (brick) break;
            }
        }
    }

    /// <summary>Removes a brick; returns the power-up it hid (if any). The exit is revealed when the brick covered it.</summary>
    public PowerUpType DestroyBrick(int x, int y)
    {
        PowerUpType hidden = Cells[x, y].Hidden;
        Cells[x, y].Type = TileType.Empty;
        Cells[x, y].Hidden = PowerUpType.None;
        if (Cells[x, y].HasExit) ExitRevealed = true;
        return hidden;
    }

    private readonly List<BlastCell> scratch = new List<BlastCell>(32);

    /// <summary>Recomputes which tiles are about to burn (used by the smart enemies) from the bombs on the board.</summary>
    public void UpdateDanger(List<Bomb> bombs)
    {
        Array.Clear(Danger, 0, Danger.Length);
        foreach (Bomb b in bombs)
        {
            if (b.Exploded) continue;
            scratch.Clear();
            CollectBlast(b.CellX, b.CellY, b.Range, scratch);
            foreach (BlastCell c in scratch) Danger[c.X, c.Y] = true;
        }
    }

    public void UpdateFlames(float dt)
    {
        for (int y = 0; y < Rows; y++)
        {
            for (int x = 0; x < Cols; x++)
            {
                if (Flame[x, y] > 0f) Flame[x, y] = Math.Max(0f, Flame[x, y] - dt);
            }
        }
    }
}
