namespace Bomberman;

public enum PowerUpType { None, BombUp, FireUp, SpeedUp, Kick, Remote }

/// <summary>A collectible upgrade lying on a cleared tile (it was hidden inside a brick).</summary>
public sealed class PowerUp
{
    public int X, Y;
    public PowerUpType Type;
    public float Age;
    public float Grace;          // the blast that revealed it cannot destroy it
    public bool Alive = true;

    public static string Name(PowerUpType t)
    {
        switch (t)
        {
            case PowerUpType.BombUp: return "BOMB UP";
            case PowerUpType.FireUp: return "FIRE UP";
            case PowerUpType.SpeedUp: return "SPEED UP";
            case PowerUpType.Kick: return "BOMB KICK";
            case PowerUpType.Remote: return "REMOTE BOMB";
            default: return "";
        }
    }

    public static string Description(PowerUpType t)
    {
        switch (t)
        {
            case PowerUpType.BombUp: return "one more bomb at a time";
            case PowerUpType.FireUp: return "longer explosions";
            case PowerUpType.SpeedUp: return "faster movement";
            case PowerUpType.Kick: return "walk into a bomb to kick it";
            case PowerUpType.Remote: return "press Z to detonate";
            default: return "";
        }
    }
}
