using System.Diagnostics;

namespace Bomberman;

public sealed class GameForm : Form
{
    private const double StepSeconds = 1.0 / 120.0;

    private readonly GameEngine engine;
    private readonly GameRenderer renderer;
    private readonly System.Windows.Forms.Timer timer;
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private double lastTime;
    private double accumulator;
    private bool fullscreen;
    private FormBorderStyle savedBorder = FormBorderStyle.Sizable;
    private FormWindowState savedState = FormWindowState.Normal;
    private bool failed;

    public GameForm()
    {
        Text = "BOMBERMAN";
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.Black;
        DoubleBuffered = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        KeyPreview = true;
        StartPosition = FormStartPosition.CenterScreen;

        Rectangle area = Screen.PrimaryScreen != null ? Screen.PrimaryScreen.WorkingArea : new Rectangle(0, 0, 1280, 900);
        double scale = Math.Max(1.0, DeviceDpi / 96.0);
        double maxScale = Math.Min((area.Width - 40) / (double)GameSettings.LogicalW, (area.Height - 90) / (double)GameSettings.LogicalH);
        scale = Math.Max(0.5, Math.Min(scale, maxScale));
        ClientSize = new Size((int)(GameSettings.LogicalW * scale), (int)(GameSettings.LogicalH * scale));
        MinimumSize = new Size(480, 400);

        SoundManager.Init();
        engine = new GameEngine();
        engine.ExitRequested = Close;
        renderer = new GameRenderer();

        timer = new System.Windows.Forms.Timer();
        timer.Interval = 8;
        timer.Tick += OnTick;
        lastTime = clock.Elapsed.TotalSeconds;
        timer.Start();
    }

    private void OnTick(object? sender, EventArgs e)
    {
        if (failed) return;
        try
        {
            double now = clock.Elapsed.TotalSeconds;
            double dt = now - lastTime;
            lastTime = now;
            if (dt > 0.1) dt = 0.1;
            accumulator += dt;

            int steps = 0;
            while (accumulator >= StepSeconds && steps < 12)
            {
                engine.Update();
                accumulator -= StepSeconds;
                steps++;
            }
            if (steps >= 12) accumulator = 0.0;
            Invalidate();
        }
        catch (Exception ex)
        {
            Fatal(ex);
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        if (failed) return;
        try
        {
            renderer.Render(e.Graphics, engine, ClientSize.Width, ClientSize.Height);
        }
        catch (Exception ex)
        {
            Fatal(ex);
        }
    }

    protected override bool IsInputKey(Keys keyData)
    {
        return true;
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        if (e.KeyCode == Keys.F11 || (e.KeyCode == Keys.Enter && e.Alt))
        {
            if (!engine.Input.Held(e.KeyCode)) ToggleFullscreen();
        }
        engine.Input.KeyDown(e.KeyCode);
        e.Handled = true;
        e.SuppressKeyPress = true;
    }

    protected override void OnKeyUp(KeyEventArgs e)
    {
        engine.Input.KeyUp(e.KeyCode);
        e.Handled = true;
    }

    private bool ToLogical(int mx, int my, out int lx, out int ly)
    {
        lx = 0;
        ly = 0;
        float scale = Math.Min(ClientSize.Width / (float)GameSettings.LogicalW, ClientSize.Height / (float)GameSettings.LogicalH);
        if (scale <= 0f) return false;
        float offX = (ClientSize.Width - GameSettings.LogicalW * scale) / 2f;
        float offY = (ClientSize.Height - GameSettings.LogicalH * scale) / 2f;
        lx = (int)((mx - offX) / scale);
        ly = (int)((my - offY) / scale);
        return true;
    }

    private int HitItem(int lx, int ly)
    {
        Rectangle[] rects = GameRenderer.RectsFor(engine.State);
        for (int i = 0; i < rects.Length; i++)
        {
            if (rects[i].Contains(lx, ly)) return i;
        }
        return -1;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        int lx, ly;
        if (ToLogical(e.X, e.Y, out lx, out ly))
        {
            int i = HitItem(lx, ly);
            if (i >= 0) engine.Hover(engine.State, i);
        }
        base.OnMouseMove(e);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            int lx, ly;
            if (ToLogical(e.X, e.Y, out lx, out ly))
            {
                int i = HitItem(lx, ly);
                if (i >= 0) engine.Activate(engine.State, i);
            }
        }
        base.OnMouseDown(e);
    }

    protected override void OnDeactivate(EventArgs e)
    {
        engine.AutoPause();
        base.OnDeactivate(e);
    }

    private void ToggleFullscreen()
    {
        if (!fullscreen)
        {
            savedBorder = FormBorderStyle;
            savedState = WindowState;
            if (WindowState == FormWindowState.Maximized) WindowState = FormWindowState.Normal;
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            fullscreen = true;
        }
        else
        {
            FormBorderStyle = savedBorder;
            WindowState = savedState;
            fullscreen = false;
        }
        Invalidate();
    }

    private void Fatal(Exception ex)
    {
        if (failed) return;
        failed = true;
        timer.Stop();
        MessageBox.Show(ex.ToString(), "Bomberman - unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        Close();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Dispose();
            renderer.Dispose();
        }
        base.Dispose(disposing);
    }
}
