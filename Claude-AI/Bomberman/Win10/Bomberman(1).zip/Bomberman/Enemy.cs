namespace Bomberman;

public enum EnemyType { Balloon, Wisp, Chaser, Smart }

/// <summary>
/// An enemy that walks the grid from tile centre to tile centre. Balloons wander slowly, wisps are fast, chasers turn often and
/// head for the player when near, and the smart ones also keep out of the tiles that bombs are about to burn.
/// </summary>
public sealed class Enemy
{
    public EnemyType Type;
    public float X, Y;                    // centre in tile units
    public int DX, DY = 1;                // the direction it moves in (and faces)
    public float Speed;
    public bool Dying;
    public float DeathTimer, Age;
    public int Score;

    private int fromX, fromY, toX, toY;
    private bool moving;
    private float prog, idle;

    public const float DeathTime = 0.7f;
    public int CellX { get { return (int)Math.Floor(X); } }
    public int CellY { get { return (int)Math.Floor(Y); } }

    public void Init(EnemyType type, int cx, int cy, int level, Random rng)
    {
        Type = type;
        fromX = cx; fromY = cy; toX = cx; toY = cy;
        X = cx + 0.5f;
        Y = cy + 0.5f;
        float scale = 1f + 0.04f * (level - 1);
        switch (type)
        {
            case EnemyType.Balloon: Speed = 1.6f * scale; break;
            case EnemyType.Wisp: Speed = 2.6f * scale; break;
            case EnemyType.Chaser: Speed = 2.0f * scale; break;
            default: Speed = 2.3f * scale; break;
        }
        Score = GameSettings.ScoreEnemy[(int)type];
        idle = (float)rng.NextDouble() * 0.6f;
        int d = rng.Next(4);
        DX = d == 0 ? 1 : (d == 1 ? -1 : 0);
        DY = d == 2 ? 1 : (d == 3 ? -1 : 0);
    }

    public void Kill()
    {
        if (Dying) return;
        Dying = true;
        DeathTimer = DeathTime;
        moving = false;
    }

    private static bool Passable(int x, int y, Maze maze, List<Bomb> bombs)
    {
        if (maze.IsBlocking(x, y)) return false;
        foreach (Bomb b in bombs)
        {
            if (!b.Exploded && b.Occupies(x, y)) return false;
        }
        return true;
    }

    private bool IsDangerous(Maze maze, int x, int y)
    {
        return maze.Danger[x, y] || maze.Flame[x, y] > 0f;
    }

    public void Update(float dt, Maze maze, List<Bomb> bombs, Player player, Random rng)
    {
        Age += dt;
        if (Dying)
        {
            DeathTimer -= dt;
            return;
        }

        if (!moving)
        {
            idle -= dt;
            if (idle <= 0f)
            {
                Choose(maze, bombs, player, rng);
                if (!moving) idle = 0.2f;
            }
            return;
        }

        // a bomb placed in the tile we are walking into: turn back
        if (!Passable(toX, toY, maze, bombs))
        {
            int tx = toX, ty = toY;
            toX = fromX; toY = fromY;
            fromX = tx; fromY = ty;
            prog = 1f - prog;
            DX = -DX;
            DY = -DY;
        }
        prog += Speed * dt;
        if (prog >= 1f)
        {
            fromX = toX;
            fromY = toY;
            prog = 0f;
            moving = false;
            X = fromX + 0.5f;
            Y = fromY + 0.5f;
            Choose(maze, bombs, player, rng);
            return;
        }
        X = fromX + 0.5f + (toX - fromX) * prog;
        Y = fromY + 0.5f + (toY - fromY) * prog;
    }

    private void Choose(Maze maze, List<Bomb> bombs, Player player, Random rng)
    {
        int[] dxs = { 0, 0, -1, 1 };
        int[] dys = { -1, 1, 0, 0 };
        int cx = fromX;
        int cy = fromY;
        List<int> options = new List<int>(4);
        for (int d = 0; d < 4; d++)
        {
            if (Passable(cx + dxs[d], cy + dys[d], maze, bombs)) options.Add(d);
        }
        if (options.Count == 0) return;

        // do not turn straight back unless there is no other way
        int back = -1;
        for (int d = 0; d < 4; d++)
        {
            if (dxs[d] == -DX && dys[d] == -DY && (DX != 0 || DY != 0)) back = d;
        }
        if (options.Count > 1 && back >= 0) options.Remove(back);

        // the smart ones keep out of tiles about to burn (and leave one they are standing in)
        if (Type == EnemyType.Smart)
        {
            List<int> safe = options.FindAll(d => !IsDangerous(maze, cx + dxs[d], cy + dys[d]));
            if (safe.Count > 0) options = safe;
        }

        int pick = -1;
        float turn = Type == EnemyType.Balloon ? 0.18f : (Type == EnemyType.Wisp ? 0.3f : (Type == EnemyType.Chaser ? 0.5f : 0.35f));
        int dist = Math.Abs(player.CellX - cx) + Math.Abs(player.CellY - cy);
        bool chase = player.State == PlayerState.Alive && ((Type == EnemyType.Chaser && dist <= 6) || (Type == EnemyType.Smart && dist <= 7));
        if (chase && rng.NextDouble() < 0.65)
        {
            int best = int.MaxValue;
            foreach (int d in options)
            {
                int dd = Math.Abs(player.CellX - (cx + dxs[d])) + Math.Abs(player.CellY - (cy + dys[d]));
                if (dd < best) { best = dd; pick = d; }
            }
        }
        if (pick < 0)
        {
            // keep going straight most of the time, turning at random junctions
            int straight = -1;
            foreach (int d in options)
            {
                if (dxs[d] == DX && dys[d] == DY) straight = d;
            }
            if (straight >= 0 && rng.NextDouble() > turn) pick = straight;
            else pick = options[rng.Next(options.Count)];
        }

        DX = dxs[pick];
        DY = dys[pick];
        toX = cx + DX;
        toY = cy + DY;
        fromX = cx;
        fromY = cy;
        prog = 0f;
        moving = true;
    }
}
