using System.Drawing.Drawing2D;

namespace Bomberman;

/// <summary>
/// All pixel-art drawing for the game: themed floor, wall and brick tiles, the exit, bombs, flames, power-up icons, the
/// Bomberman, the four enemy types and the particles. Everything is built from hard-edged blocks on the small canvas;
/// characters are drawn in a design grid and can be enlarged by an integer scale for the title screen.
/// </summary>
public sealed class Sprites : IDisposable
{
    private sealed class Theme
    {
        public Color FloorA, FloorB, Detail, DetailLight;
        public Color WallLight, WallMid, WallDark;
        public Color BrickMain, BrickLight, BrickDark;
    }

    private static readonly Theme[] Themes =
    {
        new Theme { FloorA = Color.FromArgb(90, 182, 62), FloorB = Color.FromArgb(76, 164, 54), Detail = Color.FromArgb(44, 124, 42), DetailLight = Color.FromArgb(140, 214, 90),
            WallLight = Color.FromArgb(206, 210, 222), WallMid = Color.FromArgb(160, 164, 180), WallDark = Color.FromArgb(100, 104, 124),
            BrickMain = Color.FromArgb(214, 112, 58), BrickLight = Color.FromArgb(242, 164, 96), BrickDark = Color.FromArgb(118, 54, 30) },
        new Theme { FloorA = Color.FromArgb(232, 202, 134), FloorB = Color.FromArgb(220, 188, 118), Detail = Color.FromArgb(190, 152, 90), DetailLight = Color.FromArgb(246, 226, 170),
            WallLight = Color.FromArgb(226, 196, 150), WallMid = Color.FromArgb(188, 154, 112), WallDark = Color.FromArgb(132, 102, 70),
            BrickMain = Color.FromArgb(186, 104, 66), BrickLight = Color.FromArgb(222, 150, 100), BrickDark = Color.FromArgb(102, 52, 34) },
        new Theme { FloorA = Color.FromArgb(196, 228, 244), FloorB = Color.FromArgb(178, 216, 238), Detail = Color.FromArgb(140, 186, 220), DetailLight = Color.FromArgb(246, 252, 255),
            WallLight = Color.FromArgb(166, 184, 224), WallMid = Color.FromArgb(120, 140, 188), WallDark = Color.FromArgb(76, 90, 138),
            BrickMain = Color.FromArgb(138, 198, 238), BrickLight = Color.FromArgb(214, 242, 255), BrickDark = Color.FromArgb(66, 116, 170) },
        new Theme { FloorA = Color.FromArgb(66, 58, 100), FloorB = Color.FromArgb(56, 48, 88), Detail = Color.FromArgb(40, 34, 68), DetailLight = Color.FromArgb(104, 94, 150),
            WallLight = Color.FromArgb(130, 130, 162), WallMid = Color.FromArgb(92, 92, 122), WallDark = Color.FromArgb(54, 54, 80),
            BrickMain = Color.FromArgb(134, 86, 156), BrickLight = Color.FromArgb(184, 134, 206), BrickDark = Color.FromArgb(62, 38, 80) },
        new Theme { FloorA = Color.FromArgb(92, 56, 50), FloorB = Color.FromArgb(78, 46, 42), Detail = Color.FromArgb(244, 100, 30), DetailLight = Color.FromArgb(255, 190, 70),
            WallLight = Color.FromArgb(124, 108, 108), WallMid = Color.FromArgb(86, 74, 76), WallDark = Color.FromArgb(48, 40, 44),
            BrickMain = Color.FromArgb(176, 62, 42), BrickLight = Color.FromArgb(230, 116, 66), BrickDark = Color.FromArgb(84, 26, 22) }
    };

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fText = new Font("Consolas", 10f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly StringFormat sfCenter = new StringFormat();
    private Graphics gg = null!;
    private float ox, oy;
    private int sc = 1;
    private readonly PointF[]?[] polyCache = new PointF[17][];

    public Sprites()
    {
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fText.Dispose();
        sfCenter.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private static int Hash(int a, int b, int c = 0)
    {
        unchecked
        {
            int h = a * 73856093 ^ b * 19349663 ^ c * 83492791;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private static Color Mix(Color a, Color b, float t)
    {
        t = Math.Max(0f, Math.Min(1f, t));
        return Color.FromArgb(a.A, (int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }

    /// <summary>A block in the current design grid (origin ox, oy, scale sc).</summary>
    private void R(Color c, float x, float y, float w, float h)
    {
        int ix = (int)Math.Round(ox + x * sc);
        int iy = (int)Math.Round(oy + y * sc);
        int iw = Math.Max(1, (int)Math.Round((ox + (x + w) * sc)) - ix);
        int ih = Math.Max(1, (int)Math.Round((oy + (y + h) * sc)) - iy);
        gg.FillRectangle(B(c), ix, iy, iw, ih);
    }

    private void E(Color c, float x, float y, float w, float h)
    {
        int ix = (int)Math.Round(ox + x * sc);
        int iy = (int)Math.Round(oy + y * sc);
        int iw = Math.Max(1, (int)Math.Round((ox + (x + w) * sc)) - ix);
        int ih = Math.Max(1, (int)Math.Round((oy + (y + h) * sc)) - iy);
        gg.FillEllipse(B(c), ix, iy, iw, ih);
    }

    private void Poly(Color c, params float[] pts)
    {
        int n = pts.Length / 2;
        PointF[] arr = polyCache[n] ??= new PointF[n];
        for (int i = 0; i < n; i++) arr[i] = new PointF((float)Math.Round(ox + pts[i * 2] * sc), (float)Math.Round(oy + pts[i * 2 + 1] * sc));
        gg.FillPolygon(B(c), arr);
    }

    private void Begin(Graphics g, float x, float y, int scale)
    {
        gg = g;
        ox = x;
        oy = y;
        sc = scale;
    }

    // ------------------------------------------------------------------ board tiles (24 x 24)

    public void DrawFloor(Graphics g, int px, int py, int tx, int ty, int theme, bool shadowTop, bool shadowLeft, float time)
    {
        Theme t = Themes[theme];
        Begin(g, px, py, 1);
        R(((tx + ty) & 1) == 0 ? t.FloorA : t.FloorB, 0, 0, 24, 24);
        int h = Hash(tx, ty, theme);
        switch (theme)
        {
            case 0:
                if (h % 3 == 0) { R(t.Detail, 5 + h % 9, 12 + (h >> 4) % 8, 1, 3); R(t.Detail, 7 + h % 9, 11 + (h >> 4) % 8, 1, 4); R(t.DetailLight, 6 + h % 9, 12 + (h >> 4) % 8, 1, 3); }
                if (h % 11 == 0) { R(Color.FromArgb(255, 250, 240, 120), 15, 6, 2, 2); R(Color.FromArgb(255, 255, 255, 255), 15, 6, 1, 1); }
                break;
            case 1:
                if (h % 2 == 0) { R(t.Detail, 3 + h % 7, 14, 8, 1); R(t.DetailLight, 5 + h % 7, 13, 5, 1); }
                break;
            case 2:
                if (h % 3 == 0) { R(t.DetailLight, 4 + h % 12, 4 + (h >> 3) % 12, 2, 2); R(t.Detail, 10, 16, 6, 1); }
                break;
            case 3:
                if (h % 2 == 0) { R(t.Detail, 3 + h % 14, 3 + (h >> 4) % 14, 3, 3); }
                if (h % 9 == 0) R(t.DetailLight, 16, 16, 2, 2);
                break;
            default:
                if (h % 3 == 0)
                {
                    float glow = 0.6f + 0.4f * (float)Math.Sin(time * 3f + h);
                    R(Mix(t.FloorB, t.Detail, glow), 4 + h % 8, 8, 8, 1);
                    R(Mix(t.FloorB, t.DetailLight, glow * 0.8f), 7 + h % 8, 9, 4, 1);
                }
                break;
        }
        if (shadowTop) R(Color.FromArgb(70, 0, 0, 0), 0, 0, 24, 5);
        if (shadowLeft) R(Color.FromArgb(50, 0, 0, 0), 0, 0, 3, 24);
    }

    public void DrawWall(Graphics g, int px, int py, int tx, int ty, int theme, bool border)
    {
        Theme t = Themes[theme];
        Begin(g, px, py, 1);
        Color mid = border ? Mix(t.WallMid, t.WallDark, 0.45f) : t.WallMid;
        Color light = border ? Mix(t.WallLight, t.WallDark, 0.35f) : t.WallLight;
        Color dark = border ? Mix(t.WallDark, Color.Black, 0.25f) : t.WallDark;
        R(dark, 0, 0, 24, 24);
        R(mid, 1, 1, 22, 21);
        R(light, 1, 1, 22, 3);
        R(light, 1, 1, 3, 21);
        R(dark, 4, 19, 19, 3);
        R(dark, 20, 4, 3, 18);
        // the stone face: a raised block with cracks and chips
        R(Mix(mid, light, 0.4f), 5, 5, 14, 11);
        R(Mix(mid, dark, 0.3f), 5, 14, 14, 2);
        int h = Hash(tx, ty, 7);
        R(dark, 7 + h % 5, 7, 1, 4);
        R(dark, 8 + h % 5, 10, 3, 1);
        R(dark, 12 + (h >> 3) % 4, 11, 1, 4);
        R(light, 6 + (h >> 5) % 8, 6, 2, 1);
        if (border)
        {
            R(dark, 3, 3, 2, 2); R(dark, 19, 3, 2, 2); R(dark, 3, 17, 2, 2); R(dark, 19, 17, 2, 2);
        }
    }

    public void DrawBrick(Graphics g, int px, int py, int tx, int ty, int theme, bool crumbling)
    {
        Theme t = Themes[theme];
        Begin(g, px, py, 1);
        R(t.BrickDark, 0, 0, 24, 24);
        for (int row = 0; row < 3; row++)
        {
            int y = 1 + row * 7;
            int off = (row % 2 == 0) ? 0 : 6;
            for (int x = -off; x < 24; x += 12)
            {
                int bx = Math.Max(1, x + 1);
                int bw = Math.Min(23, x + 11) - bx;
                if (bw <= 1) continue;
                int shade = Hash(tx + x, ty + row, 3) % 3;
                Color c = shade == 0 ? t.BrickMain : (shade == 1 ? Mix(t.BrickMain, t.BrickLight, 0.25f) : Mix(t.BrickMain, t.BrickDark, 0.2f));
                R(c, bx, y, bw, 6);
                R(t.BrickLight, bx, y, bw, 1);
                R(Mix(c, t.BrickDark, 0.5f), bx, y + 5, bw, 1);
            }
        }
        R(Color.FromArgb(80, 255, 255, 255), 0, 0, 24, 1);
        R(Color.FromArgb(70, 0, 0, 0), 0, 22, 24, 2);
        if (crumbling) R(Color.FromArgb(120, 255, 240, 200), 0, 0, 24, 24);
    }

    public void DrawExit(Graphics g, int px, int py, bool active, float time)
    {
        Begin(g, px, py, 1);
        R(Color.FromArgb(255, 40, 44, 70), 2, 2, 20, 20);
        if (!active)
        {
            // a locked metal hatch
            R(Color.FromArgb(255, 110, 116, 140), 3, 3, 18, 18);
            R(Color.FromArgb(255, 150, 156, 178), 3, 3, 18, 2);
            R(Color.FromArgb(255, 70, 74, 96), 3, 19, 18, 2);
            R(Color.FromArgb(255, 70, 74, 96), 11, 5, 2, 14);
            R(Color.FromArgb(255, 230, 190, 60), 9, 9, 6, 6);
            R(Color.FromArgb(255, 80, 60, 20), 11, 11, 2, 3);
            return;
        }
        // an open glowing portal
        for (int i = 0; i < 4; i++)
        {
            float k = (time * 1.5f + i * 0.25f) % 1f;
            int r = 10 - (int)(k * 9f);
            Color c = i % 2 == 0 ? Color.FromArgb(255, 120, 230, 255) : Color.FromArgb(255, 200, 255, 255);
            E(Color.FromArgb(A(255 * (0.4f + 0.6f * k)), c.R, c.G, c.B), 12 - r, 12 - r, r * 2, r * 2);
        }
        E(Color.FromArgb(255, 255, 255, 255), 9, 9, 6, 6);
        R(Color.FromArgb(255, 255, 240, 120), 11 + (int)Math.Round(Math.Sin(time * 8f) * 6f), 4, 2, 2);
        R(Color.FromArgb(255, 255, 240, 120), 11 + (int)Math.Round(Math.Cos(time * 7f) * 6f), 18, 2, 2);
    }

    // ------------------------------------------------------------------ bombs and flames

    public void DrawBomb(Graphics g, Bomb b, float time)
    {
        float px = GameSettings.BoardX + b.DrawX * GameSettings.TileSize;
        float py = GameSettings.BoardY + b.DrawY * GameSettings.TileSize;
        float urg = b.Urgency;
        // the pulse gets faster and stronger as the fuse burns down
        float freq = 5f + urg * 22f;
        float pulse = (float)Math.Sin(b.Age * freq);
        int grow = (int)Math.Round(pulse * (0.6f + urg * 1.6f));
        bool hot = urg > 0.62f && ((int)(b.Age * (10f + urg * 18f)) & 1) == 0;
        Begin(g, px, py, 1);
        // shadow
        E(Color.FromArgb(70, 0, 0, 0), 4, 18, 17, 5);
        Color body = hot ? Color.FromArgb(255, 150, 30, 30) : Color.FromArgb(255, 30, 30, 48);
        Color body2 = hot ? Color.FromArgb(255, 220, 60, 50) : Color.FromArgb(255, 60, 62, 92);
        float r = 8.5f + grow * 0.5f;
        float cx = 12f, cy = 14f - grow * 0.2f;
        E(Color.FromArgb(255, 10, 10, 20), cx - r - 1, cy - r - 1, r * 2 + 2, r * 2 + 2);
        E(body, cx - r, cy - r, r * 2, r * 2);
        E(body2, cx - r + 2, cy - r + 1, r * 2 - 5, r * 2 - 6);
        R(Color.FromArgb(255, 255, 255, 255), cx - r + 3, cy - r + 2, 3, 2);
        R(Color.FromArgb(200, 255, 255, 255), cx - r + 2, cy - r + 4, 1, 2);
        if (b.Remote) R(Color.FromArgb(255, 80, 160, 255), cx - 5, cy + 1, 10, 2);
        // the fuse and its spark
        R(Color.FromArgb(255, 150, 110, 60), 15, 3 - grow / 2, 2, 4);
        R(Color.FromArgb(255, 110, 80, 40), 16, 2 - grow / 2, 3, 2);
        int sp = (int)(b.Age * 20f) & 3;
        int sx = 17 + (sp == 1 ? 1 : 0);
        int sy = 0 - grow / 2;
        R(Color.FromArgb(255, 255, 220, 60), sx, sy, 3, 3);
        R(Color.FromArgb(255, 255, 255, 255), sx + 1, sy + 1, 1, 1);
        if (sp == 0 || sp == 2) { R(Color.FromArgb(255, 255, 140, 30), sx - 1, sy + 1, 1, 1); R(Color.FromArgb(255, 255, 140, 30), sx + 3, sy + 1, 1, 1); R(Color.FromArgb(255, 255, 140, 30), sx + 1, sy - 1, 1, 1); }
    }

    public void DrawFlame(Graphics g, BlastCell c, float progress, float time)
    {
        DrawFlameAt(g, GameSettings.BoardX + c.X * GameSettings.TileSize, GameSettings.BoardY + c.Y * GameSettings.TileSize, c.Kind, c.X, c.Y, progress, time);
    }

    /// <summary>One fire tile at pixel position (px, py); the seed makes neighbouring tiles flicker differently.</summary>
    public void DrawFlameAt(Graphics g, int px, int py, FlameKind kind, int seedX, int seedY, float progress, float time)
    {
        float f = progress < 0.12f ? progress / 0.12f : (progress > 0.7f ? (1f - progress) / 0.3f : 1f);
        f = Math.Max(0.18f, Math.Min(1f, f));
        Begin(g, px, py, 1);
        float wob = 0.5f + 0.5f * (float)Math.Sin(time * 30f + seedX * 1.7f + seedY * 2.3f);
        float h = 11f * f;
        Color outer = Color.FromArgb(255, 255, 104, 20);
        Color mid = Color.FromArgb(255, 255, 186, 40);
        Color inner = Color.FromArgb(255, 255, 244, 170);
        Color core = Color.FromArgb(255, 255, 255, 240);
        float flick = 1f + wob * 0.12f;

        switch (kind)
        {
            case FlameKind.Horizontal:
                Bar(true, 0, 24, h, flick, outer, mid, inner);
                break;
            case FlameKind.Vertical:
                Bar(false, 0, 24, h, flick, outer, mid, inner);
                break;
            case FlameKind.EndLeft:
                Bar(true, 2, 24, h, flick, outer, mid, inner);
                R(outer, 0, 12 - h * 0.6f, 3, h * 1.2f);
                break;
            case FlameKind.EndRight:
                Bar(true, 0, 22, h, flick, outer, mid, inner);
                R(outer, 21, 12 - h * 0.6f, 3, h * 1.2f);
                break;
            case FlameKind.EndUp:
                Bar(false, 2, 24, h, flick, outer, mid, inner);
                R(outer, 12 - h * 0.6f, 0, h * 1.2f, 3);
                break;
            case FlameKind.EndDown:
                Bar(false, 0, 22, h, flick, outer, mid, inner);
                R(outer, 12 - h * 0.6f, 21, h * 1.2f, 3);
                break;
            default:
                {
                    float q = h * 1.05f;
                    R(outer, 12 - q, 12 - q, q * 2, q * 2);
                    R(outer, 12 - q - 1, 12 - q + 3, q * 2 + 2, q * 2 - 6);
                    R(outer, 12 - q + 3, 12 - q - 1, q * 2 - 6, q * 2 + 2);
                    R(mid, 12 - q * 0.75f, 12 - q * 0.75f, q * 1.5f, q * 1.5f);
                    R(inner, 12 - q * 0.5f, 12 - q * 0.5f, q, q);
                    R(core, 12 - q * 0.25f, 12 - q * 0.25f, q * 0.5f, q * 0.5f);
                    break;
                }
        }
        // licking tongues of fire
        int hh = Hash(seedX, seedY, (int)(time * 14f));
        if (f > 0.5f)
        {
            R(mid, 4 + hh % 14, 12 - h - 2 + (hh >> 3) % 2, 2, 3);
            R(mid, 6 + (hh >> 4) % 12, 12 + h - 1, 2, 3);
            R(inner, 10 + (hh >> 6) % 6, 12 - 3 + (hh >> 2) % 3, 2, 2);
        }
    }

    private void Bar(bool horizontal, float start, float end, float h, float flick, Color outer, Color mid, Color inner)
    {
        float len = end - start;
        float hh = h * flick;
        if (horizontal)
        {
            R(outer, start, 12 - hh, len, hh * 2);
            R(mid, start, 12 - hh * 0.68f, len, hh * 1.36f);
            R(inner, start, 12 - hh * 0.38f, len, hh * 0.76f);
        }
        else
        {
            R(outer, 12 - hh, start, hh * 2, len);
            R(mid, 12 - hh * 0.68f, start, hh * 1.36f, len);
            R(inner, 12 - hh * 0.38f, start, hh * 0.76f, len);
        }
    }

    // ------------------------------------------------------------------ power-ups

    public void DrawPowerUp(Graphics g, PowerUp p, float time)
    {
        int px = GameSettings.BoardX + p.X * GameSettings.TileSize;
        int py = GameSettings.BoardY + p.Y * GameSettings.TileSize;
        int bob = (int)Math.Round(Math.Sin(p.Age * 5f) * 1.5f);
        Begin(g, px, py, 1);
        float pulse = 0.5f + 0.5f * (float)Math.Sin(p.Age * 6f);
        E(Color.FromArgb(A(50 + 50 * pulse), 255, 255, 180), 0, 0 + bob, 24, 24);
        Begin(g, px + 2, py + 2 + bob, 1);
        PowerIconBox(p.Type, 20, time);
        if (((int)(p.Age * 6f) & 1) == 0) R(Color.FromArgb(255, 255, 255, 255), 17, 1, 2, 2);
    }

    /// <summary>The framed icon of a power-up (also used by the HUD), drawn into a box of the given size at the current origin.</summary>
    public void PowerIconBox(PowerUpType type, int size, float time)
    {
        Color frame, back;
        switch (type)
        {
            case PowerUpType.BombUp: frame = Color.FromArgb(255, 70, 140, 250); back = Color.FromArgb(255, 30, 50, 110); break;
            case PowerUpType.FireUp: frame = Color.FromArgb(255, 250, 160, 30); back = Color.FromArgb(255, 120, 50, 20); break;
            case PowerUpType.SpeedUp: frame = Color.FromArgb(255, 70, 210, 220); back = Color.FromArgb(255, 20, 70, 90); break;
            case PowerUpType.Kick: frame = Color.FromArgb(255, 80, 210, 80); back = Color.FromArgb(255, 20, 80, 30); break;
            default: frame = Color.FromArgb(255, 240, 70, 70); back = Color.FromArgb(255, 100, 24, 30); break;
        }
        float s = size / 20f;
        int old = sc;
        float oox = ox, ooy = oy;
        R(Color.FromArgb(255, 14, 14, 30), 0, 0, size, size);
        R(frame, 1 * s, 1 * s, size - 2 * s, size - 2 * s);
        R(back, 3 * s, 3 * s, size - 6 * s, size - 6 * s);
        R(Mix(frame, Color.White, 0.5f), 1 * s, 1 * s, size - 2 * s, 1);
        // the icon in a 14x14 design grid centred in the box
        float cx = size / 2f - 7f * s;
        ox = oox + cx * old;
        oy = ooy + cx * old;
        float u = s;
        switch (type)
        {
            case PowerUpType.BombUp:
                E(Color.FromArgb(255, 10, 10, 20), 1 * u, 3 * u, 11 * u, 11 * u);
                E(Color.FromArgb(255, 54, 56, 84), 2 * u, 4 * u, 8 * u, 8 * u);
                R(Color.White, 3 * u, 5 * u, 2 * u, 1 * u);
                R(Color.FromArgb(255, 160, 120, 70), 8 * u, 1 * u, 2 * u, 3 * u);
                R(Color.FromArgb(255, 255, 220, 60), 9 * u, 0, 3 * u, 2 * u);
                R(Color.White, 9 * u, 8 * u, 5 * u, 1 * u);
                R(Color.White, 11 * u, 6 * u, 1 * u, 5 * u);
                break;
            case PowerUpType.FireUp:
                Poly(Color.FromArgb(255, 255, 120, 20), 7 * u, 0, 10 * u, 5 * u, 12 * u, 8 * u, 11 * u, 12 * u, 7 * u, 14 * u, 3 * u, 12 * u, 2 * u, 8 * u, 4 * u, 5 * u, 5 * u, 7 * u);
                Poly(Color.FromArgb(255, 255, 210, 60), 7 * u, 5 * u, 9 * u, 8 * u, 9 * u, 11 * u, 7 * u, 13 * u, 5 * u, 11 * u, 5 * u, 8 * u);
                Poly(Color.FromArgb(255, 255, 250, 200), 7 * u, 9 * u, 8 * u, 11 * u, 7 * u, 13 * u, 6 * u, 11 * u);
                break;
            case PowerUpType.SpeedUp:
                Poly(Color.FromArgb(255, 255, 230, 60), 8 * u, 0, 2 * u, 8 * u, 6 * u, 8 * u, 4 * u, 14 * u, 12 * u, 5 * u, 7 * u, 5 * u);
                Poly(Color.FromArgb(255, 255, 255, 200), 8 * u, 2 * u, 5 * u, 7 * u, 8 * u, 7 * u);
                break;
            case PowerUpType.Kick:
                Poly(Color.FromArgb(255, 245, 245, 250), 3 * u, 1 * u, 8 * u, 1 * u, 8 * u, 6 * u, 13 * u, 9 * u, 13 * u, 12 * u, 3 * u, 12 * u);
                R(Color.FromArgb(255, 150, 154, 170), 3 * u, 11 * u, 10 * u, 2 * u);
                R(Color.FromArgb(255, 200, 70, 70), 4 * u, 4 * u, 3 * u, 1 * u);
                R(Color.FromArgb(255, 255, 255, 255), 0, 3 * u, 2 * u, 1 * u);
                R(Color.FromArgb(255, 255, 255, 255), 0, 6 * u, 3 * u, 1 * u);
                R(Color.FromArgb(255, 255, 255, 255), 0, 9 * u, 2 * u, 1 * u);
                break;
            default:
                R(Color.FromArgb(255, 80, 84, 110), 1 * u, 6 * u, 12 * u, 7 * u);
                R(Color.FromArgb(255, 130, 134, 160), 1 * u, 6 * u, 12 * u, 1 * u);
                E(Color.FromArgb(255, 255, 70, 60), 4 * u, 2 * u, 6 * u, 6 * u);
                R(Color.FromArgb(255, 255, 170, 160), 5 * u, 3 * u, 2 * u, 1 * u);
                R(Color.FromArgb(255, 60, 220, 90), 2 * u, 9 * u, 2 * u, 2 * u);
                R(Color.FromArgb(255, 255, 220, 60), 10 * u, 9 * u, 2 * u, 2 * u);
                break;
        }
        ox = oox;
        oy = ooy;
    }

    public void DrawPowerIcon(Graphics g, PowerUpType type, int x, int y, int size, float time)
    {
        Begin(g, x, y, 1);
        PowerIconBox(type, size, time);
    }

    // ------------------------------------------------------------------ the Bomberman

    private static readonly Color Outline = Color.FromArgb(255, 20, 20, 44);
    private static readonly Color White = Color.FromArgb(255, 250, 250, 255);
    private static readonly Color WhiteShade = Color.FromArgb(255, 196, 206, 232);
    private static readonly Color Blue = Color.FromArgb(255, 52, 104, 236);
    private static readonly Color BlueDark = Color.FromArgb(255, 30, 60, 172);
    private static readonly Color Pink = Color.FromArgb(255, 240, 64, 116);
    private static readonly Color PinkDark = Color.FromArgb(255, 170, 30, 84);
    private static readonly Color Skin = Color.FromArgb(255, 253, 216, 166);

    public void DrawPlayer(Graphics g, Player p, float time)
    {
        float cx = GameSettings.BoardX + p.X * GameSettings.TileSize;
        float fy = GameSettings.BoardY + p.Y * GameSettings.TileSize + 10f;
        if (p.State == PlayerState.Waiting) return;
        if (p.State == PlayerState.Dying)
        {
            DrawPlayerDeath(g, cx, fy, 1.5f - p.DeathTimer, time, 1);
            return;
        }
        if (p.Invuln > 0f && ((int)(time * 16f) & 1) == 0) return;
        int pose = p.CelebrateTime > 0f ? 3 : (p.PlaceAnim > 0f ? 2 : (p.Moving ? 1 : 0));
        DrawBomberman(g, cx, fy, p.Facing, p.WalkPhase, time, 1, pose, 0f);
    }

    /// <summary>Poses: 0 idle, 1 walking, 2 placing a bomb, 3 celebrating.</summary>
    public void DrawBomberman(Graphics g, float cx, float fy, int facing, float walk, float time, int scale, int pose, float flash)
    {
        Begin(g, cx, fy, scale);
        Color white = flash > 0f ? Color.White : White;
        float bob = pose == 1 ? (float)Math.Round(Math.Abs(Math.Sin(walk)) * 1.5) : (float)Math.Round(Math.Sin(time * 3.2f) * 0.6);
        if (pose == 3) bob = -(float)Math.Round(Math.Abs(Math.Sin(time * 8f)) * 3f);
        float swing = pose == 1 ? (float)Math.Round(Math.Sin(walk) * 2f) : 0f;
        float legL = pose == 1 && Math.Sin(walk) > 0 ? 2f : 0f;
        float legR = pose == 1 && Math.Sin(walk) < 0 ? 2f : 0f;
        float lift = pose == 3 ? bob : 0f;

        // shadow
        E(Color.FromArgb(70, 0, 0, 0), -8, -3, 16, 5);
        // feet
        R(Outline, -8, -5 - legL + lift, 8, 6);
        R(Outline, 0, -5 - legR + lift, 8, 6);
        R(Pink, -7, -4 - legL + lift, 6, 4);
        R(Pink, 1, -4 - legR + lift, 6, 4);
        R(PinkDark, -7, -2 - legL + lift, 6, 2);
        R(PinkDark, 1, -2 - legR + lift, 6, 2);
        R(Color.FromArgb(255, 255, 160, 190), -6, -4 - legL + lift, 2, 1);
        R(Color.FromArgb(255, 255, 160, 190), 2, -4 - legR + lift, 2, 1);
        // body
        R(Outline, -7, -14 + lift, 14, 11);
        R(Blue, -6, -13 + lift, 12, 9);
        R(BlueDark, 2, -13 + lift, 4, 9);
        R(Color.FromArgb(255, 120, 160, 255), -5, -13 + lift, 4, 1);
        R(Color.FromArgb(255, 24, 24, 40), -6, -8 + lift, 12, 2);
        R(Color.FromArgb(255, 252, 200, 60), -1, -8 + lift, 3, 2);
        // gloves
        if (pose == 2)
        {
            R(Outline, -6, -15 + lift, 6, 6); R(Outline, 0, -15 + lift, 6, 6);
            R(Pink, -5, -14 + lift, 4, 4); R(Pink, 1, -14 + lift, 4, 4);
        }
        else if (pose == 3)
        {
            R(Outline, -11, -31, 6, 6); R(Outline, 5, -31, 6, 6);
            R(Pink, -10, -30, 4, 4); R(Pink, 6, -30, 4, 4);
            R(Blue, -9, -26, 2, 5); R(Blue, 7, -26, 2, 5);
        }
        else
        {
            R(Outline, -11, -13 + swing + lift, 6, 6); R(Outline, 5, -13 - swing + lift, 6, 6);
            R(Pink, -10, -12 + swing + lift, 4, 4); R(Pink, 6, -12 - swing + lift, 4, 4);
            R(PinkDark, -10, -9 + swing + lift, 4, 1); R(PinkDark, 6, -9 - swing + lift, 4, 1);
        }
        // helmet
        float hy = -26 + bob + lift;
        R(Outline, -10, hy, 20, 15);
        R(Outline, -9, hy - 1, 18, 1);
        R(white, -9, hy + 1, 18, 12);
        R(white, -8, hy, 16, 1);
        R(WhiteShade, -9, hy + 10, 18, 3);
        R(WhiteShade, 5, hy + 1, 4, 9);
        R(Color.FromArgb(255, 255, 255, 255), -7, hy + 1, 6, 2);
        // antenna with the pink ball
        float wob = (float)Math.Round(Math.Sin(time * 5f + walk) * 1f);
        R(Color.FromArgb(255, 150, 154, 176), -1 + wob * 0.5f, hy - 4, 2, 4);
        R(Outline, -3 + wob, hy - 9, 6, 6);
        R(Pink, -2 + wob, hy - 8, 4, 4);
        R(Color.FromArgb(255, 255, 190, 210), -2 + wob, hy - 8, 2, 2);
        // the face
        if (facing == 1)
        {
            R(WhiteShade, -6, hy + 4, 12, 3);
            R(Color.FromArgb(255, 150, 160, 190), -2, hy + 9, 4, 2);
        }
        else
        {
            float wx = facing == 2 ? -9f : (facing == 3 ? -1f : -6f);
            float ww = facing == 0 ? 12f : 10f;
            R(Outline, wx - 1, hy + 3, ww + 2, 9);
            R(Skin, wx, hy + 4, ww, 7);
            R(Color.FromArgb(255, 225, 180, 130), wx, hy + 9, ww, 2);
            float e1 = facing == 0 ? -4f : (facing == 2 ? wx + 1f : wx + 2f);
            float e2 = facing == 0 ? 2f : (facing == 2 ? wx + 5f : wx + 6f);
            R(Color.FromArgb(255, 16, 16, 28), e1, hy + 5, 2, 5);
            R(Color.FromArgb(255, 16, 16, 28), e2, hy + 5, 2, 5);
        }
    }

    private void DrawPlayerDeath(Graphics g, float cx, float fy, float t, float time, int scale)
    {
        Begin(g, cx, fy, scale);
        if (t < 0.4f)
        {
            DrawBomberman(g, cx + (((int)(t * 40f) & 1) == 0 ? -1 : 1), fy, 0, 0f, time, scale, 0, ((int)(t * 20f) & 1) == 0 ? 1f : 0f);
            return;
        }
        Begin(g, cx, fy, scale);
        float k = Math.Min(1f, (t - 0.4f) / 0.5f);
        float spin = (float)Math.Abs(Math.Cos(t * 14f));
        float w = 6f + 12f * spin;
        float rise = (float)Math.Sin(k * Math.PI) * 6f;
        E(Color.FromArgb(70, 0, 0, 0), -8, -3, 16, 5);
        if (t < 1.0f)
        {
            // dizzy spin with stars circling
            R(Outline, -w / 2 - 1, -18 - rise, w + 2, 16);
            R(White, -w / 2, -17 - rise, w, 14);
            R(Blue, -4, -6 - rise, 8, 5);
        }
        else
        {
            // lying flat, eyes crossed out
            R(Outline, -11, -9, 22, 10);
            R(White, -10, -8, 12, 8);
            R(Skin, -6, -7, 6, 5);
            R(Color.FromArgb(255, 16, 16, 28), -5, -6, 1, 1); R(Color.FromArgb(255, 16, 16, 28), -3, -4, 1, 1);
            R(Color.FromArgb(255, 16, 16, 28), -3, -6, 1, 1); R(Color.FromArgb(255, 16, 16, 28), -5, -4, 1, 1);
            R(Blue, 2, -8, 8, 7);
            R(Pink, 10, -7, 3, 5);
        }
        for (int i = 0; i < 3; i++)
        {
            float a = time * 6f + i * 2.1f;
            R(Color.FromArgb(255, 255, 230, 70), (float)Math.Cos(a) * 9f - 1, (t < 1.0f ? -24f : -16f) + (float)Math.Sin(a) * 3f, 3, 3);
        }
        if (t > 1.2f) R(Color.FromArgb(255, 255, 240, 160), -5, -26 - (t - 1.2f) * 14f, 10, 2);
    }

    // ------------------------------------------------------------------ enemies

    public void DrawEnemy(Graphics g, Enemy e, float time)
    {
        float cx = GameSettings.BoardX + e.X * GameSettings.TileSize;
        float cy = GameSettings.BoardY + e.Y * GameSettings.TileSize;
        float death = e.Dying ? 1f - e.DeathTimer / Enemy.DeathTime : 0f;
        DrawEnemyAt(g, e.Type, cx, cy + 9f, e.DX, e.DY, time + e.Age, 1, death);
    }

    public void DrawEnemyAt(Graphics g, EnemyType type, float cx, float fy, int dx, int dy, float time, int scale, float death)
    {
        Begin(g, cx, fy, scale);
        if (death > 0f && ((int)(death * 16f) & 1) == 1 && death > 0.5f) return;
        float squash = death > 0f ? Math.Min(1f, death * 1.6f) : 0f;
        float wob = (float)Math.Sin(time * 8f);
        // shadow
        E(Color.FromArgb(70, 0, 0, 0), -9, -3, 18, 5);
        float eyeX = dx * 2f;
        float eyeY = dy * 1f;

        switch (type)
        {
            case EnemyType.Balloon:
                {
                    float h = 17f - squash * 11f + wob * 0.8f;
                    float top = -h - 2f;
                    R(Color.FromArgb(255, 230, 130, 40), -7, -3 + (wob > 0 ? -1 : 0), 5, 3);
                    R(Color.FromArgb(255, 230, 130, 40), 2, -3 + (wob < 0 ? -1 : 0), 5, 3);
                    E(Outline, -10, top - 1, 20, h + 2);
                    E(Color.FromArgb(255, 232, 58, 62), -9, top, 18, h);
                    E(Color.FromArgb(255, 150, 22, 40), -9, top + h * 0.55f, 18, h * 0.45f);
                    E(Color.FromArgb(255, 232, 58, 62), -8, top, 16, h * 0.78f);
                    E(Color.FromArgb(255, 255, 140, 140), -6, top + 2, 6, 4);
                    if (squash < 0.6f) Eyes(top + h * 0.35f, eyeX, eyeY, Color.FromArgb(255, 20, 20, 30));
                    break;
                }
            case EnemyType.Wisp:
                {
                    float fl = -3f + wob * 1.5f;
                    float h = 18f - squash * 12f;
                    float top = -h - 4f + fl;
                    E(Outline, -10, top - 1, 20, 14);
                    R(Outline, -10, top + 6, 20, h - 5);
                    E(Color.FromArgb(255, 72, 132, 248), -9, top, 18, 13);
                    R(Color.FromArgb(255, 72, 132, 248), -9, top + 6, 18, h - 6);
                    R(Color.FromArgb(255, 44, 88, 200), -9, top + h - 8, 18, 4);
                    E(Color.FromArgb(255, 170, 205, 255), -6, top + 2, 6, 4);
                    for (int i = 0; i < 4; i++)
                    {
                        float dyb = ((i + (int)(time * 6f)) & 1) == 0 ? 3f : 0f;
                        R(Outline, -10 + i * 5, top + h - 4, 5, 4 + dyb);
                        R(Color.FromArgb(255, 72, 132, 248), -9 + i * 5, top + h - 4, 4, 3 + dyb);
                    }
                    if (squash < 0.6f) Eyes(top + 6f, eyeX, eyeY, Color.FromArgb(255, 220, 30, 30));
                    break;
                }
            case EnemyType.Chaser:
                {
                    float hop = (float)Math.Abs(Math.Sin(time * 9f)) * 3f;
                    float h = 17f - squash * 11f;
                    float top = -h - 2f - hop;
                    R(Color.FromArgb(255, 250, 240, 200), -8, top - 4, 3, 5);
                    R(Color.FromArgb(255, 250, 240, 200), 5, top - 4, 3, 5);
                    R(Outline, -9, top - 5, 5, 3); R(Outline, 4, top - 5, 5, 3);
                    E(Outline, -10, top - 1, 20, h + 2);
                    E(Color.FromArgb(255, 72, 196, 84), -9, top, 18, h);
                    E(Color.FromArgb(255, 36, 130, 56), -9, top + h * 0.55f, 18, h * 0.45f);
                    E(Color.FromArgb(255, 72, 196, 84), -8, top, 16, h * 0.78f);
                    E(Color.FromArgb(255, 160, 235, 150), -6, top + 2, 6, 3);
                    if (squash < 0.6f)
                    {
                        Eyes(top + h * 0.3f, eyeX, eyeY, Color.FromArgb(255, 200, 30, 30));
                        R(Color.FromArgb(255, 30, 20, 30), -5, top + h * 0.68f, 10, 3);
                        R(White, -4, top + h * 0.68f, 2, 2); R(White, 0, top + h * 0.68f, 2, 2); R(White, 3, top + h * 0.68f, 2, 2);
                    }
                    R(Color.FromArgb(255, 230, 130, 40), -6, -3 - (wob > 0 ? 1 : 0) - hop * 0.3f, 5, 3);
                    R(Color.FromArgb(255, 230, 130, 40), 1, -3 - (wob < 0 ? 1 : 0) - hop * 0.3f, 5, 3);
                    break;
                }
            default:
                {
                    float fl = -2f + wob;
                    float h = 20f - squash * 13f;
                    float top = -h - 3f + fl;
                    E(Outline, -12, top - 1, 24, h + 2);
                    E(Color.FromArgb(255, 156, 76, 214), -11, top, 22, h);
                    E(Color.FromArgb(255, 100, 40, 160), -11, top + h * 0.55f, 22, h * 0.45f);
                    E(Color.FromArgb(255, 156, 76, 214), -10, top, 20, h * 0.78f);
                    E(Color.FromArgb(255, 210, 160, 250), -7, top + 2, 7, 4);
                    R(Color.FromArgb(255, 250, 220, 80), -4, top - 4, 8, 4);
                    R(Color.FromArgb(255, 250, 220, 80), -4, top - 6, 2, 3); R(Color.FromArgb(255, 250, 220, 80), -1, top - 7, 2, 4); R(Color.FromArgb(255, 250, 220, 80), 2, top - 6, 2, 3);
                    if (squash < 0.6f)
                    {
                        // one big eye that follows the target
                        E(Outline, -7, top + h * 0.22f - 1, 14, 12);
                        E(White, -6, top + h * 0.22f, 12, 10);
                        E(Color.FromArgb(255, 220, 30, 40), -3 + eyeX, top + h * 0.22f + 2 + eyeY, 6, 6);
                        R(Color.FromArgb(255, 20, 10, 20), -1 + eyeX, top + h * 0.22f + 4 + eyeY, 2, 2);
                        R(Outline, -7, top + h * 0.22f - 2, 14, 2);
                    }
                    R(Color.FromArgb(255, 70, 30, 110), -8, -3, 5, 3);
                    R(Color.FromArgb(255, 70, 30, 110), 3, -3, 5, 3);
                    break;
                }
        }
        if (death > 0.2f)
        {
            for (int i = 0; i < 3; i++)
            {
                float a = time * 7f + i * 2.1f;
                R(Color.FromArgb(255, 255, 230, 70), (float)Math.Cos(a) * 9f - 1, -22f + (float)Math.Sin(a) * 3f, 3, 3);
            }
        }
    }

    private void Eyes(float y, float ex, float ey, Color pupil)
    {
        R(Outline, -7, y - 1, 6, 7); R(Outline, 1, y - 1, 6, 7);
        R(White, -6, y, 4, 5); R(White, 2, y, 4, 5);
        R(pupil, -5 + ex * 0.5f, y + 1 + ey * 0.5f + 1, 2, 3); R(pupil, 3 + ex * 0.5f, y + 1 + ey * 0.5f + 1, 2, 3);
        // angry brows
        R(Outline, -8, y - 3, 5, 2); R(Outline, 3, y - 3, 5, 2);
        R(Outline, -4, y - 2, 2, 2); R(Outline, 2, y - 2, 2, 2);
    }

    // ------------------------------------------------------------------ particles

    public void DrawParticles(Graphics g, ParticleSystem ps)
    {
        for (int i = 0; i < ps.Count; i++)
        {
            Particle p = ps.Items[i];
            float k = p.Life / p.MaxLife;
            int x = (int)Math.Round(p.X);
            int y = (int)Math.Round(p.Y);
            Color c = Color.FromArgb(255, p.R, p.G, p.B);
            switch (p.Kind)
            {
                case 0:
                    {
                        int s = Math.Max(1, (int)(p.Size * (1f + (1f - k))));
                        g.FillRectangle(B(Color.FromArgb(A(150 * k), p.R, p.G, p.B)), x - s / 2, y - s / 2, s, s);
                        break;
                    }
                case 1:
                    g.FillRectangle(B(c), x, y, 2, 2);
                    break;
                case 2:
                    {
                        int s = Math.Max(2, (int)(p.Size * 0.8f));
                        g.FillRectangle(B(c), x, y, s, s);
                        g.FillRectangle(B(Mix(c, Color.White, 0.4f)), x, y, s, 1);
                        break;
                    }
                case 3:
                    {
                        float r = p.Size * (1f - k * 0.6f) * 0.9f;
                        int dots = 18;
                        for (int d = 0; d < dots; d++)
                        {
                            double a = d * 6.2832 / dots;
                            g.FillRectangle(B(c), x + (int)(Math.Cos(a) * r), y + (int)(Math.Sin(a) * r), 2, 2);
                        }
                        break;
                    }
                default:
                    {
                        int s = Math.Max(1, (int)(p.Size * k));
                        g.FillRectangle(B(c), x - s / 2, y - s / 2, s, s);
                        break;
                    }
            }
        }
        foreach (FloatText t in ps.Texts)
        {
            float a = Math.Min(1f, t.Life * 2f);
            if (a < 0.2f) continue;
            g.DrawString(t.Text, fText, B(Color.Black), (int)t.X + 1, (int)t.Y + 1, sfCenter);
            g.DrawString(t.Text, fText, B(Color.FromArgb(255, t.Color.R, t.Color.G, t.Color.B)), (int)t.X, (int)t.Y, sfCenter);
        }
    }

    // ------------------------------------------------------------------ the title bomb

    public void DrawBigBomb(Graphics g, float x, float y, int scale, float time, float urgency)
    {
        Begin(g, x, y, scale);
        float pulse = (float)Math.Sin(time * 8f) * 0.5f;
        E(Color.FromArgb(70, 0, 0, 0), -10, 8, 22, 6);
        E(Color.FromArgb(255, 10, 10, 20), -11 - pulse, -12 - pulse, 22 + pulse * 2, 22 + pulse * 2);
        E(Color.FromArgb(255, 34, 34, 54), -10 - pulse, -11 - pulse, 20 + pulse * 2, 20 + pulse * 2);
        E(Color.FromArgb(255, 70, 74, 106), -8, -9, 14, 14);
        R(Color.White, -7, -8, 4, 2);
        R(Color.FromArgb(255, 160, 120, 70), 5, -17, 3, 6);
        R(Color.FromArgb(255, 110, 80, 40), 7, -19, 4, 3);
        int sp = (int)(time * 20f) & 3;
        R(Color.FromArgb(255, 255, 220, 60), 9 + (sp == 1 ? 1 : 0), -22, 5, 5);
        R(Color.White, 11, -20, 1, 1);
        if (sp == 0 || sp == 2) { R(Color.FromArgb(255, 255, 140, 30), 8, -20, 1, 1); R(Color.FromArgb(255, 255, 140, 30), 14, -20, 1, 1); R(Color.FromArgb(255, 255, 140, 30), 11, -23, 1, 1); }
    }
}
