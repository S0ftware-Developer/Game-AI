using System.Diagnostics;
using System.Media;
using System.Text;

namespace Bomberman;

public enum SfxId { Menu, Confirm, PlaceBomb, Tick, Explosion, BlockBreak, PowerUp, EnemyDie, PlayerDie, LevelComplete, GameOver, Victory, Kick, Detonate, Ready }

/// <summary>
/// Sounds synthesised at start-up into in-memory WAV data. Windows plays only one SoundPlayer sound at a time, so quiet
/// frequent sounds (gunfire) are throttled and never cut off a more important sound that has just started.
/// </summary>
public static class SoundManager
{
    private const int Rate = 22050;
    private static readonly Dictionary<SfxId, SoundPlayer> Players = new Dictionary<SfxId, SoundPlayer>();
    private static readonly Dictionary<SfxId, double> LastPlayed = new Dictionary<SfxId, double>();
    private static readonly Random Rng = new Random(5);
    private static readonly Stopwatch Clock = Stopwatch.StartNew();
    private static double lastImportant = -10.0;
    private static bool inited;
    public static bool Muted;

    public static void Init()
    {
        if (inited) return;
        inited = true;
        try
        {
            Add(SfxId.Menu, Tone(520, 520, 35, 0.16, true));
            Add(SfxId.Confirm, Cat(Tone(660, 660, 40, 0.2, true), Tone(880, 880, 70, 0.2, true)));
            Add(SfxId.PlaceBomb, Cat(Tone(240, 160, 50, 0.22, true), Tone(180, 120, 50, 0.18, true)));
            Add(SfxId.Tick, Tone(900, 900, 18, 0.07, true));
            Add(SfxId.Explosion, Cat(Noise(420, 0.38, 0.7), Tone(110, 40, 300, 0.3, true)));
            Add(SfxId.BlockBreak, Cat(Noise(90, 0.22, 0.4), Tone(300, 120, 80, 0.12, true)));
            Add(SfxId.PowerUp, Cat(Tone(660, 660, 50, 0.2, true), Tone(880, 880, 50, 0.2, true), Tone(1320, 1320, 110, 0.2, true)));
            Add(SfxId.EnemyDie, Cat(Tone(560, 160, 180, 0.2, true), Noise(50, 0.1, 0.5)));
            Add(SfxId.PlayerDie, Cat(Tone(700, 700, 70, 0.24, true), Tone(520, 520, 70, 0.24, true), Tone(380, 380, 70, 0.24, true), Tone(240, 110, 300, 0.24, true)));
            Add(SfxId.LevelComplete, Cat(Tone(523, 523, 100, 0.25, true), Tone(659, 659, 100, 0.25, true), Tone(784, 784, 100, 0.25, true), Tone(1047, 1047, 100, 0.25, true), Tone(784, 784, 100, 0.25, true), Tone(1047, 1047, 300, 0.25, true)));
            Add(SfxId.GameOver, Cat(Tone(392, 392, 160, 0.26, true), Tone(330, 330, 160, 0.26, true), Tone(262, 262, 160, 0.26, true), Tone(196, 196, 500, 0.26, true)));
            Add(SfxId.Victory, Cat(Tone(523, 523, 120, 0.28, true), Tone(659, 659, 120, 0.28, true), Tone(784, 784, 120, 0.28, true), Tone(1047, 1047, 120, 0.28, true), Tone(1319, 1319, 120, 0.28, true), Tone(1568, 1568, 420, 0.28, true)));
            Add(SfxId.Kick, Cat(Noise(30, 0.2, 0.4), Tone(200, 400, 60, 0.18, true)));
            Add(SfxId.Detonate, Cat(Tone(1200, 1200, 40, 0.18, true), Tone(900, 900, 40, 0.18, true)));
            Add(SfxId.Ready, Cat(Tone(440, 440, 90, 0.2, true), Tone(660, 660, 140, 0.2, true)));
        }
        catch (Exception)
        {
            // audio is optional: the game stays fully playable without it
        }
    }

    public static void Play(SfxId id)
    {
        if (Muted) return;
        try
        {
            double now = Clock.Elapsed.TotalSeconds;
            bool quiet = id == SfxId.Tick;
            double last;
            if (LastPlayed.TryGetValue(id, out last) && now - last < 0.04) return;
            if (quiet && now - lastImportant < 0.25) return;
            SoundPlayer? sp;
            if (!Players.TryGetValue(id, out sp) || sp == null) return;
            sp.Play();
            LastPlayed[id] = now;
            if (!quiet) lastImportant = now;
        }
        catch (Exception)
        {
        }
    }

    public static void SetMuted(bool muted)
    {
        Muted = muted;
    }

    private static void Add(SfxId id, short[] samples)
    {
        SoundPlayer sp = new SoundPlayer(new MemoryStream(ToWav(samples)));
        sp.Load();
        Players[id] = sp;
    }

    private static short[] Tone(double f0, double f1, int ms, double vol, bool square)
    {
        int n = Rate * ms / 1000;
        short[] d = new short[n];
        double phase = 0.0;
        for (int i = 0; i < n; i++)
        {
            double t = (double)i / n;
            double f = f0 + (f1 - f0) * t;
            phase += 2.0 * Math.PI * f / Rate;
            double v = square ? (Math.Sin(phase) >= 0.0 ? 0.6 : -0.6) : Math.Sin(phase);
            double env = Math.Min(1.0, i / 100.0) * (1.0 - t);
            d[i] = (short)(v * env * vol * 32000.0);
        }
        return d;
    }

    /// <summary>Low-passed noise that fades out; a smaller smoothing value gives a rumblier sound.</summary>
    private static short[] Noise(int ms, double vol, double smooth)
    {
        int n = Rate * ms / 1000;
        short[] d = new short[n];
        double last = 0.0;
        for (int i = 0; i < n; i++)
        {
            double t = (double)i / n;
            double raw = Rng.NextDouble() * 2.0 - 1.0;
            last = last * smooth + raw * (1.0 - smooth);
            d[i] = (short)(last * (1.0 - t) * (1.0 - t * 0.3) * vol * 32000.0 * 1.6);
        }
        return d;
    }

    private static short[] Cat(params short[][] parts)
    {
        int total = 0;
        foreach (short[] p in parts) total += p.Length;
        short[] all = new short[total];
        int pos = 0;
        foreach (short[] p in parts)
        {
            Array.Copy(p, 0, all, pos, p.Length);
            pos += p.Length;
        }
        return all;
    }

    private static byte[] ToWav(short[] samples)
    {
        int dataLen = samples.Length * 2;
        using MemoryStream ms = new MemoryStream();
        using BinaryWriter bw = new BinaryWriter(ms);
        bw.Write(Encoding.ASCII.GetBytes("RIFF"));
        bw.Write(36 + dataLen);
        bw.Write(Encoding.ASCII.GetBytes("WAVE"));
        bw.Write(Encoding.ASCII.GetBytes("fmt "));
        bw.Write(16);
        bw.Write((short)1);
        bw.Write((short)1);
        bw.Write(Rate);
        bw.Write(Rate * 2);
        bw.Write((short)2);
        bw.Write((short)16);
        bw.Write(Encoding.ASCII.GetBytes("data"));
        bw.Write(dataLen);
        foreach (short s in samples) bw.Write(s);
        bw.Flush();
        return ms.ToArray();
    }
}
