namespace Bomberman;

/// <summary>A bomb on the grid: a fuse, a blast range, optionally remote-controlled, and able to slide when kicked.</summary>
public sealed class Bomb
{
    public const float Fuse = 2.8f;
    public const float RemoteFuse = 7f;
    public const float SlideSpeed = 8f;           // tiles per second

    public int X, Y;                 // the cell it stands in (or is leaving, while sliding)
    public float Timer = Fuse;
    public float Age;
    public int Range = 2;
    public bool Remote;
    public bool OwnerInside = true;  // the player who placed it may still walk off it
    public bool Exploded;
    public bool Sliding;
    public int SlideX, SlideY;
    public float Prog;               // progress toward the next cell while sliding

    public float DrawX { get { return X + (Sliding ? SlideX * Prog : 0f); } }
    public float DrawY { get { return Y + (Sliding ? SlideY * Prog : 0f); } }

    /// <summary>The cell the bomb is mostly in; the blast starts here.</summary>
    public int CellX { get { return Sliding && Prog >= 0.5f ? X + SlideX : X; } }
    public int CellY { get { return Sliding && Prog >= 0.5f ? Y + SlideY : Y; } }

    public bool Occupies(int cx, int cy)
    {
        if (X == cx && Y == cy) return true;
        return Sliding && X + SlideX == cx && Y + SlideY == cy;
    }

    /// <summary>0..1 how close to detonation it is (used for the animation).</summary>
    public float Urgency
    {
        get
        {
            if (Remote) return 0.35f + 0.25f * (float)Math.Sin(Age * 4f);
            return 1f - Math.Max(0f, Timer) / Fuse;
        }
    }
}
