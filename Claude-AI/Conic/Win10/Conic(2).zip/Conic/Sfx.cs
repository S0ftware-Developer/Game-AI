using System.Media;

namespace Conic;

/// <summary>Procedurally generated sound effects (no asset files).</summary>
public static class Sfx
{
    public static bool Muted;
    public static readonly Snd Jump  = new((280, 640, 0.14, 1, 0.22));
    public static readonly Snd Ring  = new((1318, 1318, 0.05, 0, 0.25), (1760, 1760, 0.10, 0, 0.25));
    public static readonly Snd Bounce = new((180, 900, 0.28, 1, 0.25));
    public static readonly Snd Stomp = new((500, 150, 0.12, 1, 0.30));
    public static readonly Snd Hurt  = new((500, 120, 0.30, 1, 0.30));
    public static readonly Snd Die   = new((400, 60, 0.60, 1, 0.30));
    public static readonly Snd Check = new((880, 880, 0.08, 0, 0.25), (1175, 1175, 0.14, 0, 0.25));
    public static readonly Snd Win   = new((523, 523, 0.14, 0, 0.3), (659, 659, 0.14, 0, 0.3), (784, 784, 0.14, 0, 0.3),
                                           (1047, 1047, 0.14, 0, 0.3), (1047, 1047, 0.35, 0, 0.3));
}

public sealed class Snd
{
    readonly SoundPlayer? sp;

    public Snd(params (double f0, double f1, double dur, int wave, double vol)[] segs)
    {
        try { sp = new SoundPlayer(new MemoryStream(Wav(segs))); sp.Load(); }
        catch { sp = null; }
    }

    public void Play()
    {
        if (Sfx.Muted || sp == null) return;
        try { sp.Play(); } catch { }
    }

    static byte[] Wav((double f0, double f1, double dur, int wave, double vol)[] segs)
    {
        const int sr = 22050;
        var data = new List<short>();
        double phase = 0;
        foreach (var s in segs)
        {
            int n = (int)(s.dur * sr);
            for (int i = 0; i < n; i++)
            {
                double u = (double)i / n;
                phase += 2 * Math.PI * (s.f0 + (s.f1 - s.f0) * u) / sr;
                double v = s.wave == 0 ? Math.Sin(phase) : (Math.Sin(phase) >= 0 ? 0.55 : -0.55);
                double env = Math.Min(1.0, u * 20) * (1 - u);
                data.Add((short)(v * env * s.vol * 32767));
            }
        }
        var ms = new MemoryStream();
        var bw = new BinaryWriter(ms);
        int bytes = data.Count * 2;
        bw.Write(new[] { 'R', 'I', 'F', 'F' }); bw.Write(36 + bytes);
        bw.Write(new[] { 'W', 'A', 'V', 'E', 'f', 'm', 't', ' ' });
        bw.Write(16); bw.Write((short)1); bw.Write((short)1); bw.Write(sr); bw.Write(sr * 2); bw.Write((short)2); bw.Write((short)16);
        bw.Write(new[] { 'd', 'a', 't', 'a' }); bw.Write(bytes);
        foreach (var d in data) bw.Write(d);
        bw.Flush();
        return ms.ToArray();
    }
}
