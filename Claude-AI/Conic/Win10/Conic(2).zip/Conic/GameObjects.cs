using System.Drawing;

namespace Conic;

public class Ring { public float X, Y, Phase; public bool Taken; }
public class Spring { public float X, Y, Comp, Cool; }                 // Y = ground level
public class Hazard { public RectangleF R; public int Kind; }          // 0 spikes, 1 rock, 2 hanging bar
public class Platform { public float X, Y, W; }                        // one-way, Y = top surface
public class Checkpoint { public float X, Y; public bool On; }
public class Sign { public float X, Y; public string Text = ""; }
public class Decor { public float X, Y, S; public int Kind; }          // 0 palm, 1 flower, 2 bush
public class LoopDef { public float Cx, Cy, R; }

public class Enemy
{
    public float X, Y, MinX, MaxX, Speed = 70f, T, DeadT, BaseY;
    public float Dir = 1f;
    public bool Flying, Dead;
    public RectangleF Box => Flying
        ? new RectangleF(X - 15, Y - 14, 30, 28)
        : new RectangleF(X - 15, Y - 26, 30, 26);
}

public class Particle
{
    public float X, Y, VX, VY, Life, Max, Size;
    public Color Col;
    public int Kind;   // 0 spark, 1 dust, 2 gold dot
}
