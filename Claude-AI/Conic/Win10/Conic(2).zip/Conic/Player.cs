using System.Drawing;

namespace Conic;

public enum PState { Idle, Run, Fast, Jump, Roll, Land, Hurt, Dead }

public class Player
{
    public float X, Y, VX, VY;                 // X,Y = feet position
    public int Facing = 1;
    public bool Grounded = true, Rolling, AirBall, JumpedUp, InLoop, Dead;
    public float Invuln, HurtLock, LandT, StretchT, Coyote, JumpBuf, Anim, BallAngle, DeadT, Phi, LoopU;
    public int LoopDir = 1;
    public Action? OnJump, OnLand, OnLoopEnter;
    readonly Level lv;

    public Player(Level l) { lv = l; Reset(l.Start.X, l.Start.Y); }

    public float CenterY => Y - (Rolling || InLoop || AirBall ? 14f : 20f);
    public bool IsBall => Rolling || InLoop || (!Grounded && AirBall);

    public RectangleF Box()
    {
        float h = (Rolling || InLoop || AirBall) ? 28f : 40f;
        return new RectangleF(X - 9, Y - h + 2, 18, h - 2);
    }

    public PState State
    {
        get
        {
            if (Dead) return PState.Dead;
            if (HurtLock > 0) return PState.Hurt;
            if (InLoop || Rolling || (!Grounded && AirBall)) return PState.Roll;
            if (!Grounded) return PState.Jump;
            if (LandT > 0) return PState.Land;
            float a = MathF.Abs(VX);
            if (a > 520) return PState.Fast;
            if (a > 40) return PState.Run;
            return PState.Idle;
        }
    }

    public void Reset(float x, float y)
    {
        X = x; Y = y; VX = VY = 0; Facing = 1;
        Grounded = true; Rolling = AirBall = JumpedUp = InLoop = Dead = false;
        Invuln = 1.5f; HurtLock = LandT = StretchT = Coyote = JumpBuf = DeadT = 0;
        Anim = BallAngle = 0;
    }

    public void Hurt(float fromX)
    {
        if (Invuln > 0 || Dead) return;
        Invuln = Cfg.Invulnerable; HurtLock = 0.4f;
        VY = -420f; VX = (X >= fromX ? 1 : -1) * 260f;
        Grounded = false; Rolling = false; AirBall = false; JumpedUp = false;
    }

    public void Die() { Dead = true; VY = -700f; VX = 0; DeadT = 0; InLoop = false; }

    static float Approach(float v, float target, float d) =>
        v < target ? MathF.Min(v + d, target) : MathF.Max(v - d, target);

    public void Update(float dt, bool left, bool right, bool down, bool jumpHeld, bool jumpPressed)
    {
        if (Dead) { VY += Cfg.Gravity * dt; Y += VY * dt; X += VX * dt; DeadT += dt; return; }

        Invuln = MathF.Max(0, Invuln - dt);
        HurtLock = MathF.Max(0, HurtLock - dt);
        LandT = MathF.Max(0, LandT - dt);
        StretchT = MathF.Max(0, StretchT - dt);

        int dir = (right ? 1 : 0) - (left ? 1 : 0);
        if (HurtLock > 0) { dir = 0; down = false; jumpPressed = false; }
        JumpBuf = jumpPressed ? Cfg.JumpBuffer : MathF.Max(0, JumpBuf - dt);

        if (InLoop) { UpdateLoop(dt); return; }

        Coyote = Grounded ? Cfg.CoyoteTime : MathF.Max(0, Coyote - dt);
        if (Grounded) GroundPhysics(dt, dir, down); else AirPhysics(dt, dir, down, jumpHeld);
        if (JumpBuf > 0 && Coyote > 0 && HurtLock <= 0) Jump();

        // substeps so fast movement cannot tunnel through terrain
        float dist = MathF.Max(MathF.Abs(VX), MathF.Abs(VY)) * dt;
        int n = Math.Max(1, (int)MathF.Ceiling(dist / 5f));
        float h = dt / n;
        for (int i = 0; i < n && !InLoop; i++) Move(h, down);

        if (Grounded && !Rolling) Anim += MathF.Abs(VX) * dt / 24f;
        if (Grounded && Rolling) BallAngle += VX * dt / 14f;
        else if (!Grounded && AirBall) BallAngle += Facing * 14f * dt;
    }

    void GroundPhysics(float dt, int dir, bool down)
    {
        float slope = lv.SlopeAt(X, Y);
        bool blocked = lv.BlockedAbove(X, Y);
        AirBall = false;

        if (!Rolling && down && MathF.Abs(VX) > 80f) Rolling = true;
        else if (Rolling && !down && !blocked) Rolling = false;

        if (Rolling)
        {
            VX += slope * Cfg.SlopeRoll * dt;
            VX = Approach(VX, 0, Cfg.RollFriction * dt);
            if (dir != 0 && MathF.Sign(VX) == -dir) VX = Approach(VX, 0, Cfg.RollBrake * dt);
            else if (dir != 0 && MathF.Abs(VX) < 120f) VX += dir * Cfg.RunAccel * dt;   // crawl under bars
        }
        else
        {
            VX += slope * Cfg.SlopeRun * dt;
            float ax = MathF.Abs(VX);
            if (dir == 0) VX = Approach(VX, 0, Cfg.GroundFriction * dt);
            else if (VX == 0 || MathF.Sign(VX) == dir)
            {
                if (ax < Cfg.RunMax)
                {
                    float k = 1f - 0.55f * (ax / Cfg.RunMax);
                    VX += dir * Cfg.RunAccel * k * dt;
                    if (MathF.Abs(VX) > Cfg.RunMax) VX = dir * Cfg.RunMax;
                }
                else VX = Approach(VX, dir * Cfg.RunMax, 260f * dt);
            }
            else VX += dir * Cfg.TurnBrake * dt;   // reversing takes time at speed
        }
        VX = Math.Clamp(VX, -Cfg.MaxSpeed, Cfg.MaxSpeed);

        if (dir != 0) Facing = dir; else if (MathF.Abs(VX) > 40f) Facing = MathF.Sign(VX);
    }

    void AirPhysics(float dt, int dir, bool down, bool jumpHeld)
    {
        AirBall = down;
        if (dir != 0)
        {
            Facing = dir;
            if (VX == 0 || MathF.Sign(VX) == dir)
            {
                if (MathF.Abs(VX) < Cfg.RunMax) { VX += dir * Cfg.AirAccel * dt; if (MathF.Abs(VX) > Cfg.RunMax) VX = dir * Cfg.RunMax; }
            }
            else VX += dir * Cfg.AirAccel * dt;
        }
        VX -= VX * Cfg.AirDrag * dt;
        VY = MathF.Min(VY + Cfg.Gravity * dt, Cfg.MaxFall);
        if (JumpedUp && !jumpHeld && VY < Cfg.JumpCutVel) VY = Cfg.JumpCutVel;   // variable jump height
    }

    void Jump()
    {
        float bonus = MathF.Max(MathF.Min(0f, lv.SlopeAt(X, Y) * VX), -450f);   // jumping uphill adds lift
        VY = Cfg.JumpVel + bonus;
        Grounded = false; Rolling = false; JumpedUp = true; JumpBuf = 0; Coyote = 0; StretchT = 0.18f;
        OnJump?.Invoke();
    }

    void Move(float h, bool down)
    {
        float ox = X, oy = Y;
        if (Grounded)
        {
            float nx = X + VX * h;
            if (nx < 24) { nx = 24; if (VX < 0) VX = 0; }
            if (nx > lv.Width - 24) { nx = lv.Width - 24; if (VX > 0) VX = 0; }
            float dx = MathF.Abs(nx - X);
            float ng = lv.GroundAt(nx, Y);
            if (ng >= Level.INF || ng - Y > dx + 6f)
            {   // ground falls away: take off keeping slope momentum (ramp launch)
                VY = lv.SlopeAt(X, Y) * VX;
                Grounded = false; Rolling = false;
                X = nx;
                return;
            }
            if (Y - ng > dx * 1.2f + 8f) { VX = 0; return; }   // wall
            X = nx; Y = ng;
            CheckLoop(ox);
        }
        else
        {
            X += VX * h; Y += VY * h;
            if (X < 24) { X = 24; if (VX < 0) VX = 0; }
            if (X > lv.Width - 24) { X = lv.Width - 24; if (VX > 0) VX = 0; }
            float ng = lv.GroundAt(X, oy);
            if (VY >= 0 && Y >= ng && ng < Level.INF)
            {
                bool wasAbove = oy <= lv.GroundAt(ox, oy) + 3f;
                if (wasAbove && ng < oy - 14f - MathF.Abs(VX * h) * 1.2f) { X = ox; VX = 0; }   // side of a cliff
                else
                {
                    float impact = VY;
                    Y = ng; VY = 0; Grounded = true; JumpedUp = false; AirBall = false;
                    Rolling = down;
                    if (impact > 450f) { LandT = 0.16f; OnLand?.Invoke(); }
                }
            }
        }
    }

    // ---------- loop ----------
    void CheckLoop(float ox)
    {
        if (!lv.HasLoop || HurtLock > 0) return;
        var L = lv.Loop;
        if (MathF.Abs(Y - (L.Cy + L.R)) > 8f) return;
        bool crossed = (ox < L.Cx && X >= L.Cx && VX > 0) || (ox > L.Cx && X <= L.Cx && VX < 0);
        if (!crossed || MathF.Abs(VX) < Cfg.LoopMinEntry) return;
        InLoop = true; Grounded = false; Rolling = true; AirBall = false;
        LoopDir = VX > 0 ? 1 : -1; LoopU = MathF.Abs(VX); Phi = 0; X = L.Cx;
        OnLoopEnter?.Invoke();
    }

    void UpdateLoop(float dt)
    {
        var L = lv.Loop; float rp = L.R - 14f;
        const int n = 4; float h = dt / n;
        for (int i = 0; i < n; i++)
        {
            LoopU -= Cfg.LoopGravity * MathF.Sin(Phi) * h;      // gravity along the track
            Phi += LoopU / rp * h;
            if (Phi >= MathF.Tau) { ExitLoop(); return; }
            if (Phi <= 0f) { Phi = 0f; ExitLoop(); return; }
            // too slow at the top: lose contact and fall back down
            if (Phi > MathF.PI * 0.5f && Phi < MathF.PI * 1.5f && LoopU * LoopU < -Cfg.LoopGravity * rp * MathF.Cos(Phi))
            { PoseOnLoop(rp); InLoop = false; AirBall = true; JumpedUp = false; return; }
        }
        PoseOnLoop(rp);
        Facing = LoopDir; BallAngle += LoopU * dt / 14f * LoopDir;
    }

    void PoseOnLoop(float rp)
    {
        var L = lv.Loop; float ang = LoopDir * Phi;
        X = L.Cx + rp * MathF.Sin(ang);
        Y = L.Cy + rp * MathF.Cos(ang) + 14f;
        VX = LoopU * LoopDir * MathF.Cos(ang);
        VY = -LoopU * LoopDir * MathF.Sin(ang);
    }

    void ExitLoop()
    {
        var L = lv.Loop;
        InLoop = false; Grounded = true; Rolling = true;
        X = L.Cx; Y = L.Cy + L.R; VX = LoopDir * LoopU; VY = 0;
        Facing = VX >= 0 ? 1 : -1;
    }
}
