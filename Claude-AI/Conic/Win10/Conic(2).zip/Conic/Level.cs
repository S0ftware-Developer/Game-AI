using System.Drawing;

namespace Conic;

/// <summary>Handcrafted level "Green Hills": heightmap terrain + object placement.</summary>
public class Level
{
    public const int Step = 4;            // terrain sample width in px
    public const float INF = 1e9f;        // marks a gap (pit)

    public float[] H = Array.Empty<float>();
    public float Width, FinishX, FinishY, KillY = 1150f;
    public PointF Start, Respawn;
    public LoopDef Loop = new();
    public bool HasLoop => Loop.R > 0;
    public float LoopNeedSpeed => HasLoop ? MathF.Sqrt(5f * Cfg.LoopGravity * (Loop.R - 14f)) : 0f;

    public readonly List<Ring> Rings = new();
    public readonly List<Spring> Springs = new();
    public readonly List<Hazard> Hazards = new();
    public readonly List<Platform> Platforms = new();
    public readonly List<Enemy> Enemies = new();
    public readonly List<Checkpoint> Checkpoints = new();
    public readonly List<Sign> Signs = new();
    public readonly List<Decor> Decors = new();

    readonly List<float> hs = new();
    readonly Random rnd = new(11);
    float cur = 640f, lastGy = 640f;
    float X => hs.Count * Step;

    // ---------- terrain builders ----------
    void Flat(float len) { int n = (int)(len / Step); for (int i = 0; i < n; i++) hs.Add(cur); }
    void Gap(float len) { int n = (int)(len / Step); for (int i = 0; i < n; i++) hs.Add(INF); }
    void Slope(float len, float dy, bool linear = false)
    {
        int n = (int)(len / Step); float y0 = cur;
        for (int i = 1; i <= n; i++)
        {
            float t = (float)i / n;
            float k = linear ? t : (1f - MathF.Cos(MathF.PI * t)) * 0.5f;
            hs.Add(y0 + dy * k);
        }
        cur = y0 + dy;
    }

    // ---------- queries ----------
    public float TerrainY(float x)
    {
        if (x < 0) x = 0;
        float f = x / Step; int i = (int)f;
        if (i >= H.Length - 1) return H[^1];
        float a = H[i], b = H[i + 1];
        if (a >= INF || b >= INF) return INF;
        return a + (b - a) * (f - i);
    }

    /// <summary>Highest solid surface at x. Platforms only count if feet are at/above their top.</summary>
    public float GroundAt(float x, float feetY)
    {
        float g = TerrainY(x);
        foreach (var p in Platforms)
            if (x >= p.X - 4 && x <= p.X + p.W + 4 && feetY <= p.Y + 10 && p.Y < g) g = p.Y;
        return g;
    }

    public float SlopeAt(float x, float feetY)
    {
        float a = GroundAt(x - 6, feetY), b = GroundAt(x + 6, feetY);
        if (a >= INF || b >= INF) return 0f;
        return Math.Clamp((b - a) / 12f, -1.2f, 1.2f);
    }

    public bool BlockedAbove(float x, float y)
    {
        var stand = new RectangleF(x - 9, y - 40, 18, 40);
        foreach (var hz in Hazards) if (hz.Kind == 2 && stand.IntersectsWith(hz.R)) return true;
        return false;
    }

    // ---------- object helpers ----------
    float G(float x) { float v = TerrainY(x); return v >= INF ? lastGy : v; }
    void RingsGround(float x0, int n, float sp, float hgt = 34f)
    {
        for (int i = 0; i < n; i++)
        {
            float x = x0 + i * sp, gy = TerrainY(x);
            if (gy >= INF) gy = lastGy;
            lastGy = gy;
            Rings.Add(new Ring { X = x, Y = gy - hgt, Phase = i * 0.5f });
        }
    }
    void RingsLine(float x0, float y0, int n, float dx, float dy = 0)
    {
        for (int i = 0; i < n; i++) Rings.Add(new Ring { X = x0 + i * dx, Y = y0 + i * dy, Phase = i * 0.5f });
    }
    void RingsArc(float x0, float x1, float baseY, float height, int n)
    {
        for (int i = 0; i < n; i++)
        {
            float t = (i + 0.5f) / n;
            Rings.Add(new Ring { X = x0 + (x1 - x0) * t, Y = baseY - 34f - height * MathF.Sin(MathF.PI * t), Phase = i * 0.5f });
        }
    }
    void Spikes(float x, float w) => Hazards.Add(new Hazard { R = new RectangleF(x, G(x + w / 2) - 22, w, 22), Kind = 0 });
    void Rock(float x) => Hazards.Add(new Hazard { R = new RectangleF(x, G(x + 20) - 38, 40, 38), Kind = 1 });
    void Bar(float x) => Hazards.Add(new Hazard { R = new RectangleF(x, G(x + 60) - 34 - 50, 120, 50), Kind = 2 });
    void Walker(float x, float mn, float mx) => Enemies.Add(new Enemy { X = x, Y = G(x), MinX = mn, MaxX = mx });
    void Flyer(float x, float mn, float mx, float y) => Enemies.Add(new Enemy { X = x, Y = y, BaseY = y, MinX = mn, MaxX = mx, Flying = true, Speed = 90f });
    void SignAt(float x, string text) => Signs.Add(new Sign { X = x, Y = G(x), Text = text });

    public Level()
    {
        // ===== geometry =====
        Flat(1000);                                            // safe start
        float gap1 = X; Gap(120);
        Flat(520);
        float gap2 = X; Gap(150);
        Flat(600);
        float down1 = X; Slope(700, 100);                      // downhill: build speed
        float straight = X; Flat(1700);                        // long straight
        float rampA = X; Slope(420, -150, true);               // ramp
        float rampGap = X; Gap(320);
        float land = X; Flat(500);
        float down2 = X; Slope(500, 150);
        float spr1 = X; Flat(1000);                            // spring + high platform
        float cp1 = X + 120; Flat(400);
        var hills = new float[3];
        for (int i = 0; i < 3; i++) { hills[i] = X; Slope(500, -120); Flat(300); Slope(600, 120); Flat(500); }
        var hops = new List<(float x, float w)>();
        for (int i = 0; i < 4; i++) { Flat(420); float w = 130 + i * 15; hops.Add((X, w)); Gap(w); }
        Flat(400);
        float tower = X; Flat(1000);                           // spring tower
        float cp2 = X + 150; Flat(400);
        float rollA = X; Slope(450, -100); Slope(550, 100);    // valley: roll downhill for speed
        float roll = X; Flat(1100);                            // rolling obstacles
        float loopA = X; Flat(1540);                           // approach + loop
        float fin = X; Slope(600, 60);
        float f2 = X; Flat(700);
        float gapEnd = X; Gap(220);
        float f3 = X; Flat(1500);

        H = hs.ToArray(); Width = H.Length * Step;

        // ===== objects =====
        Start = new PointF(200, G(200)); Respawn = Start;
        SignAt(380, "GO!");
        RingsGround(480, 8, 60);
        Rock(820); RingsArc(780, 900, G(800), 80, 5);

        RingsArc(gap1 - 40, gap1 + 160, 640, 110, 6);
        Spikes(gap1 + 380, 44); RingsArc(gap1 + 330, gap1 + 470, 640, 90, 5);
        RingsArc(gap2 - 40, gap2 + 190, 640, 110, 7);
        Walker(gap2 + 450, gap2 + 300, gap2 + 650);

        RingsGround(down1 + 80, 12, 52);
        RingsGround(straight + 60, 12, 60);
        Walker(straight + 700, straight + 560, straight + 900);
        Rock(straight + 1250); RingsArc(straight + 1200, straight + 1340, G(straight + 1250), 80, 5);
        RingsGround(straight + 1450, 4, 60);

        SignAt(rampA - 120, "JUMP!");
        RingsGround(rampA + 60, 6, 55);
        RingsArc(rampGap - 30, rampGap + 350, 590, 180, 9);
        RingsLine(rampGap + 130, 590 - 330, 3, 55);            // bonus rings
        RingsGround(land + 100, 6, 60);
        RingsGround(down2 + 60, 8, 52);

        float sx = spr1 + 250;
        Springs.Add(new Spring { X = sx, Y = G(sx) });
        RingsArc(sx - 90, sx + 90, G(sx), 60, 5);
        var pA = new Platform { X = spr1 + 520, W = 360, Y = G(spr1 + 520) - 230 };
        Platforms.Add(pA); RingsLine(pA.X + 40, pA.Y - 34, 6, 55);
        RingsLine(spr1 + 440, G(sx) - 300, 4, 55);             // bonus line near the apex
        Checkpoints.Add(new Checkpoint { X = cp1, Y = G(cp1) });

        for (int i = 0; i < 3; i++)
        {
            float a = hills[i];
            RingsGround(a + 60, 8, 55);
            var hp = new Platform { X = a + 540, W = 240, Y = G(a + 650) - 140 };
            Platforms.Add(hp); RingsLine(hp.X + 30, hp.Y - 34, 4, 55);
            Walker(a + 650, a + 520, a + 780);
            Flyer(a + 1000, a + 900, a + 1250, G(a + 1000) - 60);
            RingsGround(a + 1500, 5, 60);
        }

        foreach (var (hx, hw) in hops)
        {
            RingsArc(hx - 40, hx + hw + 40, G(hx - 10), 100, 5);
        }
        Spikes(hops[1].x - 220, 44); Spikes(hops[3].x - 220, 44);

        float tx = tower + 200;
        Springs.Add(new Spring { X = tx, Y = G(tx) });
        var tA = new Platform { X = tower + 420, W = 300, Y = G(tower + 420) - 200 };
        var tB = new Platform { X = tower + 760, W = 240, Y = G(tower + 760) - 340 };
        Platforms.Add(tA); Platforms.Add(tB);
        RingsLine(tA.X + 40, tA.Y - 34, 5, 50); RingsLine(tB.X + 30, tB.Y - 34, 4, 50);
        RingsArc(tower + 300, tower + 440, G(tx), 250, 5);
        Checkpoints.Add(new Checkpoint { X = cp2, Y = G(cp2) });

        SignAt(roll + 60, "ROLL!");
        Bar(roll + 200); Bar(roll + 620); Bar(roll + 950);
        foreach (var bx in new[] { roll + 200, roll + 620, roll + 950 }) RingsGround(bx + 10, 4, 32, 20);
        Walker(roll + 450, roll + 350, roll + 560);
        Rock(roll + 780);
        RingsGround(rollA + 100, 8, 55);

        float cx = loopA + 970;
        Loop = new LoopDef { Cx = cx, R = 170, Cy = G(cx) - 170 };
        SignAt(loopA + 330, "SPEED UP!");
        RingsGround(loopA + 400, 8, 60);
        float rp = Loop.R - 14f;
        for (int k = 1; k <= 7; k++)
        {
            float ang = k * MathF.PI / 4f;
            Rings.Add(new Ring { X = cx + rp * MathF.Sin(ang), Y = Loop.Cy + rp * MathF.Cos(ang), Phase = k });
        }
        RingsGround(cx + 260, 6, 60);

        RingsGround(fin + 60, 10, 55);
        Walker(f2 + 350, f2 + 150, f2 + 550);
        Spikes(f2 + 600, 44);
        RingsArc(gapEnd - 40, gapEnd + 260, G(gapEnd - 10), 110, 7);
        Walker(f3 + 450, f3 + 300, f3 + 650);
        Flyer(f3 + 800, f3 + 700, f3 + 1000, G(f3 + 800) - 65);
        Rock(f3 + 900);
        RingsGround(f3 + 100, 18, 60);
        FinishX = f3 + 1200; FinishY = G(FinishX);

        // decorations
        float dx = 150;
        while (dx < Width - 100)
        {
            float gy = TerrainY(dx);
            bool nearLoop = MathF.Abs(dx - Loop.Cx) < 260;
            if (gy < INF && !nearLoop && MathF.Abs(SlopeAt(dx, gy)) < 0.25f)
            {
                double r = rnd.NextDouble();
                Decors.Add(new Decor { X = dx, Y = gy, Kind = r < 0.14 ? 0 : r < 0.55 ? 1 : 2, S = 0.85f + (float)rnd.NextDouble() * 0.4f });
            }
            dx += 110 + (float)rnd.NextDouble() * 170;
        }
    }
}
