CONIC - 2D platformer (C# / .NET 8 / Windows Forms / GDI+)
=========================================================

Level "Green Hills": momentum-based running, rolling, springs, ramps, a speed-dependent
loop, enemies, checkpoints and a finish line. All graphics are drawn in code and all
sounds are generated at runtime. No external files are needed to play.

BUILD (Windows 10/11 x64, .NET 8 SDK required)
----------------------------------------------
1. Extract the whole archive into a folder.
2. Double-click build.bat (it opens its own console window and keeps it open).
   Equivalent manual command, run from the project folder:

   dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishTrimmed=false

3. The finished game is:

   bin\Release\net8.0-windows\win-x64\publish\Conic.exe

   build.bat removes every other file from that folder, so only Conic.exe remains.
   The exe is self-contained: the .NET Runtime does not need to be installed.

CONTROLS
--------
Left/A, Right/D  run          Space/Up/W  jump (hold = higher)
Down/S           roll         Esc         pause / resume
R                restart      F11         fullscreen      M  mute

TUNING
------
Physics values: Config.cs.  Level layout and objects: Level.cs.

TROUBLESHOOTING
---------------
- "dotnet" not found: install the .NET 8 SDK (not only the Runtime) and run build.bat again.
- Do not run build.bat from inside the ZIP viewer; extract first.
- The footer line at the bottom of the window is part of the game.
