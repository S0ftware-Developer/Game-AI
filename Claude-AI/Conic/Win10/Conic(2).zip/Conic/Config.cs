namespace Conic;

/// <summary>All tunable physics / gameplay values live here (pixels and seconds).</summary>
public static class Cfg
{
    public const int ViewW = 1280, ViewH = 720;   // virtual resolution, scaled to the window
    public const float Step = 1f / 120f;          // fixed simulation step

    // Horizontal movement
    public const float RunAccel = 640f;           // base acceleration (tapers off near RunMax)
    public const float RunMax = 800f;             // top speed from running alone
    public const float MaxSpeed = 1500f;          // absolute cap (downhill rolling etc.)
    public const float GroundFriction = 420f;     // deceleration with no input
    public const float TurnBrake = 1700f;         // deceleration when pushing against motion
    public const float RollFriction = 120f;       // rolling keeps momentum far longer
    public const float RollBrake = 380f;
    public const float AirAccel = 480f;
    public const float AirDrag = 0.12f;           // proportional air resistance per second

    // Slopes (applied as slope * value, slope = dy/dx)
    public const float SlopeRun = 1100f;
    public const float SlopeRoll = 2300f;

    // Vertical
    public const float Gravity = 1900f;
    public const float MaxFall = 1500f;
    public const float JumpVel = -770f;
    public const float JumpCutVel = -280f;        // releasing jump early caps upward speed here
    public const float SpringVel = -1100f;
    public const float CoyoteTime = 0.09f;
    public const float JumpBuffer = 0.12f;

    // Loop: tangential "gravity" along the circular track. Entry speed needed
    // to complete it is sqrt(5 * LoopGravity * (R-14)) (see Level.LoopNeedSpeed).
    public const float LoopGravity = 430f;
    public const float LoopMinEntry = 120f;       // below this the player just walks past

    public const float Invulnerable = 2.0f;
}
