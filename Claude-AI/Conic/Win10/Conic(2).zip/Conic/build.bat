@echo off
rem --- Re-launch inside a persistent console so the window never closes by itself ---
if /i "%~1"=="run" goto :main
start "Conic build" cmd /k ""%~f0" run"
exit /b 0

:main
title Conic build
cd /d "%~dp0"
set "PUB=%~dp0bin\Release\net8.0-windows\win-x64\publish"
echo ============================================
echo  Conic - Release build (win-x64, single file)
echo  Folder: %CD%
echo ============================================
echo.

if not exist "Conic.csproj" goto :nocsproj

where dotnet >nul 2>nul
if errorlevel 1 goto :nodotnet

echo Using .NET SDK:
dotnet --version
echo.

if exist "%PUB%" rmdir /s /q "%PUB%"

dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishTrimmed=false
if errorlevel 1 goto :failed

if not exist "%PUB%\Conic.exe" goto :noexe

rem --- keep only the finished game executable in the publish folder ---
for %%F in ("%PUB%\*") do if /i not "%%~nxF"=="Conic.exe" del /q "%%F"
for /d %%D in ("%PUB%\*") do rmdir /s /q "%%D"

echo.
echo Contents of the publish folder:
dir /b "%PUB%"
echo.
echo ============================================
echo  BUILD SUCCEEDED
echo  Output: %PUB%\Conic.exe
echo ============================================
goto :end

:nocsproj
echo [ERROR] Conic.csproj not found next to build.bat.
echo         Make sure the ZIP was fully extracted and build.bat is in the project folder.
goto :end

:nodotnet
echo [ERROR] The .NET 8 SDK was not found in PATH.
echo         Install it from https://dotnet.microsoft.com/download/dotnet/8.0
echo         (the "SDK" download, not only the Runtime), then run build.bat again.
goto :end

:noexe
echo [ERROR] Publish finished but Conic.exe was not found in:
echo         %PUB%
goto :end

:failed
echo.
echo [ERROR] Build failed. See the messages above.
goto :end

:end
echo.
echo You can close this window.
