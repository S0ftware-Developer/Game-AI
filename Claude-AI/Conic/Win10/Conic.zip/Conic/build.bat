@echo off
cd /d "%~dp0"
title Conic - build
set "OUT=%~dp0bin\Release\net8.0-windows\win-x64"
set "PUB=%~dp0bin\Release\net8.0-windows\win-x64\publish"
echo ======================================================
echo  Conic - Release build (win-x64, single file)
echo  Folder: %CD%
echo ======================================================
echo.

if not exist "Conic.csproj" goto nocsproj

where dotnet >nul 2>nul
if errorlevel 1 goto nodotnet

echo .NET SDK version:
dotnet --version
echo.

if exist "%PUB%" rmdir /s /q "%PUB%"

dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishTrimmed=false
if errorlevel 1 goto failed

if not exist "%PUB%\Conic.exe" goto noexe

rem keep only the finished game executable in the publish folder
for %%F in ("%PUB%\*") do if /i not "%%~nxF"=="Conic.exe" del /q "%%F"
for /d %%D in ("%PUB%\*") do rmdir /s /q "%%D"

rem also clear intermediate build output (runtime DLLs) next to publish\
for %%F in ("%OUT%\*") do del /q "%%F"
for /d %%D in ("%OUT%\*") do if /i not "%%~nxD"=="publish" rmdir /s /q "%%D"

rem verify: exactly one file must remain in the publish folder
set "CNT=0"
for %%F in ("%PUB%\*") do set /a CNT+=1
if not "%CNT%"=="1" goto extra

echo.
echo Contents of the publish folder:
dir /b "%PUB%"
echo.
echo ======================================================
echo  BUILD SUCCEEDED
echo  Output: %PUB%\Conic.exe
echo ======================================================
goto end

:nocsproj
echo [ERROR] Conic.csproj not found next to build.bat.
echo         Extract the whole ZIP first and run build.bat from the extracted folder.
goto end

:nodotnet
echo [ERROR] The .NET 8 SDK was not found in PATH.
echo         Install the SDK from https://dotnet.microsoft.com/download/dotnet/8.0
echo         (the "SDK" download, not only the Runtime), then run build.bat again.
goto end

:noexe
echo [ERROR] Publish finished but Conic.exe was not found in:
echo         %PUB%
goto end

:extra
echo [ERROR] The publish folder must contain exactly one file, found %CNT%:
dir /b "%PUB%"
goto end

:failed
echo.
echo [ERROR] Build failed. See the messages above.
goto end

:end
echo.
pause
