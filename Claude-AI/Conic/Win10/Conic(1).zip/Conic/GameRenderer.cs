using System.Drawing;
using System.Drawing.Drawing2D;

namespace Conic;

public static class GameRenderer
{
    // ---------- palette helpers ----------
    static Color C(int r, int g, int b, int a = 255) => Color.FromArgb(a, r, g, b);
    static SolidBrush B(int r, int g, int b, int a = 255) => new(C(r, g, b, a));
    static Pen P(int r, int g, int b, float w, int a = 255)
    {
        var p = new Pen(C(r, g, b, a), w) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round };
        return p;
    }
    static float Mod(float a, float m) => ((a % m) + m) % m;

    // hero palette (original: violet / cream / orange)
    static readonly SolidBrush Violet = B(112, 66, 246), SpineB = B(84, 46, 206), Cream = B(255, 228, 190),
        GloveB = B(255, 212, 60), ShoeB = B(255, 84, 28), WhiteB = B(255, 255, 255), BlackB = B(24, 14, 46),
        BandB = B(255, 222, 70), IrisB = B(40, 200, 235);
    static readonly Pen Ol = P(30, 14, 70, 2f), LegOl = P(30, 14, 70, 9f), LegIn = P(112, 66, 246, 6f),
        ArmOl = P(30, 14, 70, 8f), ArmIn = P(112, 66, 246, 5f);

    static readonly TextureBrush Checker = MakeChecker();
    static TextureBrush MakeChecker()
    {
        var bmp = new Bitmap(64, 64);
        using (var gg = Graphics.FromImage(bmp))
        using (var a = B(184, 100, 38))
        using (var b2 = B(150, 76, 26))
        {
            gg.FillRectangle(a, 0, 0, 64, 64);
            gg.FillRectangle(b2, 0, 0, 32, 32);
            gg.FillRectangle(b2, 32, 32, 32, 32);
        }
        return new TextureBrush(bmp, WrapMode.Tile);
    }

    public static readonly Font Label = new("Consolas", 16f, FontStyle.Bold, GraphicsUnit.Pixel);
    public static readonly Font Value = new("Consolas", 30f, FontStyle.Bold, GraphicsUnit.Pixel);
    public static readonly Font Mid = new("Consolas", 28f, FontStyle.Bold, GraphicsUnit.Pixel);
    public static readonly Font Small = new("Consolas", 16f, FontStyle.Bold, GraphicsUnit.Pixel);
    static readonly Font OverlayFont = new("Arial Black", 54f, FontStyle.Regular, GraphicsUnit.Pixel);
    public static readonly Font Huge = new("Arial Black", 72f, FontStyle.Regular, GraphicsUnit.Pixel);

    public static void Text(Graphics g, string s, Font f, Color c, float x, float y, StringAlignment al = StringAlignment.Near, int shadow = 2)
    {
        using var sf = new StringFormat { Alignment = al, LineAlignment = StringAlignment.Near };
        if (shadow > 0) { using var sb = new SolidBrush(C(0, 0, 0, Math.Min(200, (int)c.A))); g.DrawString(s, f, sb, x + shadow, y + shadow, sf); }
        using var br = new SolidBrush(c);
        g.DrawString(s, f, br, x, y, sf);
    }

    static GraphicsPath RoundRect(RectangleF r, float rad)
    {
        var p = new GraphicsPath(); float d = rad * 2;
        p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure(); return p;
    }

    // ================= BACKGROUND =================
    public static void Background(Graphics g, float camX, float camY, float t)
    {
        var rect = new Rectangle(0, 0, Cfg.ViewW, Cfg.ViewH);
        using (var br = new LinearGradientBrush(rect, C(24, 102, 224), C(150, 214, 255), 90f)) g.FillRectangle(br, rect);
        for (int i = 0; i < 8; i++)
        {
            float cx = Mod(i * 420f - camX * 0.12f - t * 9f, 3360f) - 300f;
            Cloud(g, cx, 50 + (i * 53) % 190, 0.8f + (i % 3) * 0.3f);
        }
        Hills(g, camX, camY, 0.15f, 440, 120, 0.004f, 0.011f, C(112, 160, 222));
        Hills(g, camX, camY, 0.30f, 500, 80, 0.006f, 0.017f, C(70, 168, 150));
        Hills(g, camX, camY, 0.50f, 560, 55, 0.008f, 0.021f, C(52, 170, 72));
    }

    static void Hills(Graphics g, float camX, float camY, float par, float baseY, float amp, float f1, float f2, Color c)
    {
        float ox = camX * par, oy = -(camY - 290f) * par * 0.6f;
        var pts = new List<PointF>();
        for (int x = -20; x <= Cfg.ViewW + 20; x += 20)
        {
            float wx = x + ox;
            pts.Add(new PointF(x, baseY + oy - amp * (0.55f * MathF.Sin(wx * f1) + 0.45f * MathF.Sin(wx * f2 + 1.7f))));
        }
        pts.Add(new PointF(Cfg.ViewW + 20, Cfg.ViewH + 40)); pts.Add(new PointF(-20, Cfg.ViewH + 40));
        using var br = new SolidBrush(c);
        g.FillPolygon(br, pts.ToArray());
    }

    static void Cloud(Graphics g, float x, float y, float s)
    {
        using var sh = B(196, 222, 250); using var wh = B(255, 255, 255);
        var puffs = new (float dx, float dy, float r)[] { (0, 0, 22), (26, -10, 28), (56, 0, 24), (82, 6, 18), (-20, 8, 16) };
        foreach (var p in puffs) g.FillEllipse(sh, x + (p.dx - p.r) * s, y + (p.dy - p.r + 5) * s, p.r * 2 * s, p.r * 2 * s);
        foreach (var p in puffs) g.FillEllipse(wh, x + (p.dx - p.r) * s, y + (p.dy - p.r) * s, p.r * 2 * s, p.r * 2 * s);
        g.FillEllipse(wh, x - 30 * s, y, 125 * s, 24 * s);
    }

    // ================= TERRAIN =================
    static void DrawSolid(Graphics g, List<PointF> top, float bottom)
    {
        var pts = new List<PointF>(top) { new PointF(top[^1].X, bottom), new PointF(top[0].X, bottom) };
        g.FillPolygon(Checker, pts.ToArray());
        using (var pen = P(90, 45, 12, 3f)) g.DrawPolygon(pen, pts.ToArray());

        var gr = new List<PointF>(top);
        for (int k = top.Count - 1; k >= 0; k--) gr.Add(new PointF(top[k].X, top[k].Y + ((k & 1) == 0 ? 16 : 26)));
        using (var br = B(58, 200, 60)) g.FillPolygon(br, gr.ToArray());
        using (var pen = P(20, 100, 30, 2f)) g.DrawPolygon(pen, gr.ToArray());
        using (var hi = P(150, 240, 90, 4f)) { var line = top.Select(p => new PointF(p.X, p.Y + 3)).ToArray(); g.DrawLines(hi, line); }
    }

    static void DrawTerrain(Graphics g, Level lv, float camX, float camY)
    {
        int c0 = Math.Max(0, (int)(camX / Level.Step) - 4);
        int c1 = Math.Min(lv.H.Length - 1, (int)((camX + Cfg.ViewW) / Level.Step) + 4);
        float bottom = camY + Cfg.ViewH + 60;
        int i = c0;
        while (i <= c1)
        {
            if (lv.H[i] >= Level.INF) { i++; continue; }
            int s = i;
            while (i <= c1 && lv.H[i] < Level.INF) i++;
            int e = i - 1;
            if (e - s < 1) continue;
            var top = new List<PointF>();
            for (int k = s; k <= e; k += 2) top.Add(new PointF(k * Level.Step, lv.H[k]));
            if ((e - s) % 2 != 0) top.Add(new PointF(e * Level.Step, lv.H[e]));
            DrawSolid(g, top, bottom);
        }
    }

    static void DrawPlatform(Graphics g, Platform p)
    {
        var top = new List<PointF>();
        for (float x = p.X; x < p.X + p.W; x += 8) top.Add(new PointF(x, p.Y));
        top.Add(new PointF(p.X + p.W, p.Y));
        DrawSolid(g, top, p.Y + 44);
    }

    static void LoopRing(Graphics g, LoopDef L)
    {
        var st = g.Save();
        g.SetClip(new RectangleF(L.Cx - L.R - 60, L.Cy - L.R - 60, 2 * L.R + 120, 2 * L.R + 60), CombineMode.Intersect);
        float o = L.R + 34;
        using var gp = new GraphicsPath(FillMode.Alternate);
        gp.AddEllipse(L.Cx - o, L.Cy - o, 2 * o, 2 * o);
        gp.AddEllipse(L.Cx - L.R, L.Cy - L.R, 2 * L.R, 2 * L.R);
        g.FillPath(Checker, gp);
        using (var pen = P(90, 45, 12, 3f)) { g.DrawEllipse(pen, L.Cx - o, L.Cy - o, 2 * o, 2 * o); g.DrawEllipse(pen, L.Cx - L.R, L.Cy - L.R, 2 * L.R, 2 * L.R); }
        float gr = L.R + 4;
        using (var pen = P(58, 200, 60, 12f)) g.DrawEllipse(pen, L.Cx - gr, L.Cy - gr, 2 * gr, 2 * gr);
        using (var pen = P(150, 240, 90, 3f)) g.DrawEllipse(pen, L.Cx - L.R + 1, L.Cy - L.R + 1, 2 * L.R - 2, 2 * L.R - 2);
        g.Restore(st);
    }

    // ================= DECOR =================
    static void DrawDecor(Graphics g, Decor d, float t)
    {
        var st = g.Save();
        g.TranslateTransform(d.X, d.Y + 6); g.ScaleTransform(d.S, d.S);
        if (d.Kind == 0) Palm(g, t);
        else if (d.Kind == 1)
        {
            using (var pen = P(40, 150, 50, 3f)) g.DrawLine(pen, 0, 0, 0, -24);
            Color[] cols = { C(255, 120, 170), C(255, 255, 255), C(255, 200, 50) };
            using var pb = new SolidBrush(cols[(int)(d.X / 7) % 3]); using var cb = B(255, 140, 0);
            for (int k = 0; k < 6; k++) { float a = k * MathF.Tau / 6; g.FillEllipse(pb, 5 * MathF.Cos(a) - 4, -25 + 5 * MathF.Sin(a) - 4, 8, 8); }
            g.FillEllipse(cb, -3.5f, -28.5f, 7, 7);
        }
        else
        {
            using var dk = B(30, 130, 50); using var lt = B(60, 180, 70);
            g.FillEllipse(dk, -26, -18, 30, 22); g.FillEllipse(dk, -2, -22, 32, 26); g.FillEllipse(lt, -14, -26, 28, 22);
        }
        g.Restore(st);
    }

    static void Palm(Graphics g, float t)
    {
        using (var pen = P(150, 90, 30, 12f)) g.DrawBezier(pen, 0, 0, 10, -60, -6, -110, 6, -150);
        using (var pen = P(200, 140, 60, 3f)) g.DrawBezier(pen, -3, 0, 7, -60, -9, -110, 3, -150);
        using var lb = B(48, 170, 60); using var ld = B(30, 120, 44);
        float[] angs = { -170, -140, -105, -75, -40, -10 };
        foreach (float a in angs)
        {
            float r = a * MathF.PI / 180f, sway = MathF.Sin(t * 2 + a) * 3;
            float tx = 6 + 62 * MathF.Cos(r), ty = -150 + 62 * MathF.Sin(r) + 28 + sway;
            float nx = -MathF.Sin(r) * 9, ny = MathF.Cos(r) * 9;
            var pts = new[] { new PointF(6, -150), new PointF(6 + 30 * MathF.Cos(r) + nx, -150 + 30 * MathF.Sin(r) - 8 + ny), new PointF(tx, ty), new PointF(6 + 30 * MathF.Cos(r) - nx, -150 + 30 * MathF.Sin(r) - 8 - ny) };
            g.FillPolygon(lb, pts); g.DrawPolygon(Ol, pts);
        }
        g.FillEllipse(ld, 1, -150, 9, 9);
    }

    static void DrawSign(Graphics g, Sign s)
    {
        using (var pen = P(110, 70, 30, 6f)) g.DrawLine(pen, s.X, s.Y, s.X, s.Y - 52);
        var r = new RectangleF(s.X - 62, s.Y - 92, 124, 44);
        using var path = RoundRect(r, 8);
        using (var br = B(214, 160, 80)) g.FillPath(br, path);
        using (var pen = P(90, 50, 20, 3f)) g.DrawPath(pen, path);
        Text(g, s.Text, Small, C(60, 30, 10), s.X, s.Y - 80, StringAlignment.Center, 0);
    }

    static void DrawCheckpoint(Graphics g, Checkpoint c, float t)
    {
        using (var pen = P(150, 160, 175, 6f)) g.DrawLine(pen, c.X, c.Y, c.X, c.Y - 70);
        using var br = c.On ? B(255, 90, 140) : B(70, 120, 255);
        g.FillEllipse(br, c.X - 11, c.Y - 92, 22, 22);
        g.DrawEllipse(Ol, c.X - 11, c.Y - 92, 22, 22);
        g.FillEllipse(WhiteB, c.X - 6, c.Y - 88, 6, 6);
        if (c.On) { using var gl = B(255, 90, 140, 70); float k = 16 + 4 * MathF.Sin(t * 8); g.FillEllipse(gl, c.X - k, c.Y - 81 - k, 2 * k, 2 * k); }
    }

    static void DrawFinish(Graphics g, Level lv)
    {
        float x = lv.FinishX, y = lv.FinishY;
        using (var pen = P(210, 215, 225, 10f)) { g.DrawLine(pen, x - 60, y, x - 60, y - 170); g.DrawLine(pen, x + 60, y, x + 60, y - 170); }
        using var wh = B(255, 255, 255); using var bk = B(30, 30, 40);
        for (int i = 0; i < 8; i++) for (int j = 0; j < 3; j++)
                g.FillRectangle(((i + j) & 1) == 0 ? wh : bk, x - 60 + i * 15, y - 170 + j * 15, 15, 15);
        Text(g, "GOAL", Mid, C(255, 230, 60), x, y - 130, StringAlignment.Center);
    }

    // ================= OBJECTS =================
    static void DrawHazard(Graphics g, Hazard h)
    {
        var r = h.R;
        if (h.Kind == 0)
        {
            using var br = B(205, 210, 222);
            for (float x = r.X; x + 11 <= r.Right + 0.5f; x += 11)
            {
                var tri = new[] { new PointF(x, r.Bottom), new PointF(x + 5.5f, r.Top), new PointF(x + 11, r.Bottom) };
                g.FillPolygon(br, tri); g.DrawPolygon(Ol, tri);
            }
        }
        else if (h.Kind == 1)
        {
            using var br = B(124, 128, 146); using var hi = B(170, 175, 195);
            g.FillEllipse(br, r.X, r.Y, r.Width, r.Height + 6); g.DrawEllipse(Ol, r.X, r.Y, r.Width, r.Height + 6);
            g.FillEllipse(hi, r.X + 8, r.Y + 6, 12, 8);
        }
        else
        {
            using (var pen = P(110, 115, 130, 4f)) { g.DrawLine(pen, r.X + 14, r.Top, r.X + 14, r.Top - 500); g.DrawLine(pen, r.Right - 14, r.Top, r.Right - 14, r.Top - 500); }
            using var y = B(255, 210, 40); using var k = B(30, 30, 40);
            g.FillRectangle(y, r);
            var st = g.Save(); g.SetClip(r, CombineMode.Intersect);
            for (float x = r.X - 40; x < r.Right; x += 28) g.FillPolygon(k, new[] { new PointF(x, r.Bottom), new PointF(x + 14, r.Bottom), new PointF(x + 34, r.Top), new PointF(x + 20, r.Top) });
            g.Restore(st);
            g.DrawRectangle(Ol, r.X, r.Y, r.Width, r.Height);
        }
    }

    static void DrawSpring(Graphics g, Spring s)
    {
        float f = s.Comp > 0 ? MathF.Sin(s.Comp / 0.3f * MathF.PI) : 0f;
        float h = 24f - 12f * f, by = s.Y - 6;
        using var gray = B(120, 125, 140);
        g.FillRectangle(gray, s.X - 18, s.Y - 6, 36, 6); g.DrawRectangle(Ol, s.X - 18, s.Y - 6, 36, 6);
        using (var pen = P(215, 220, 232, 4f))
            for (int k = 0; k < 4; k++) { float yy = by - k * h / 4f; g.DrawLine(pen, s.X - 12, yy, s.X + 12, yy - h / 8f); }
        float top = by - h;
        using var red = B(235, 40, 50); using var hi = B(255, 130, 130);
        g.FillEllipse(red, s.X - 22, top - 7, 44, 12); g.DrawEllipse(Ol, s.X - 22, top - 7, 44, 12);
        g.FillEllipse(hi, s.X - 12, top - 5, 14, 4);
    }

    public static void DrawRing(Graphics g, float x, float y, float t, float scale = 1f)
    {
        var st = g.Save(); g.TranslateTransform(x, y); g.ScaleTransform(scale, scale);
        float w = 5f + 8f * MathF.Abs(MathF.Cos(t * 4f));
        using (var gl = B(255, 220, 60, 50)) g.FillEllipse(gl, -w - 6, -18, 2 * w + 12, 36);
        using (var p1 = P(200, 110, 0, 7f)) g.DrawEllipse(p1, -w, -12, 2 * w, 24);
        using (var p2 = P(255, 208, 40, 4.5f)) g.DrawEllipse(p2, -w, -12, 2 * w, 24);
        using (var p3 = P(255, 255, 200, 2f)) g.DrawArc(p3, -w + 1, -11, 2 * w - 2, 22, 200, 60);
        g.Restore(st);
    }

    public static void DrawEnemy(Graphics g, Enemy e, float t, float scale = 1f)
    {
        var st = g.Save();
        g.TranslateTransform(e.X, e.Y); g.ScaleTransform(e.Dir * scale, scale);
        if (e.Dead) g.ScaleTransform(1.2f, MathF.Max(0.1f, 0.35f * (1 - e.DeadT / 0.4f)));
        if (!e.Flying)
        {   // ladybug-like beetle bot
            using var red = B(225, 40, 40); using var dk = B(50, 50, 64); using var sp = B(40, 10, 10);
            g.FillEllipse(dk, -15, -16, 30, 12);
            for (int s = -1; s <= 1; s += 2)
            {
                var ws = g.Save(); g.TranslateTransform(9 * s, -6); g.RotateTransform(t * 300f * e.Dir);
                g.FillEllipse(dk, -6, -6, 12, 12); g.DrawEllipse(Ol, -6, -6, 12, 12);
                g.DrawLine(Ol, -5, 0, 5, 0); g.Restore(ws);
            }
            g.FillPie(red, -17, -30, 34, 34, 180, 180); g.DrawArc(Ol, -17, -30, 34, 34, 180, 180);
            g.FillEllipse(sp, -9, -25, 6, 6); g.FillEllipse(sp, -1, -28, 5, 5);
            g.FillEllipse(WhiteB, 5, -23, 9, 10); g.FillEllipse(BlackB, 9, -20, 4, 5);
            g.DrawLine(Ol, 10, -29, 16, -39); g.FillEllipse(red, 14, -42, 6, 6);
        }
        else
        {   // buzzing bee bot
            float flap = MathF.Sin(t * 35f);
            using var wing = B(255, 255, 255, 170); using var ye = B(255, 205, 40);
            var ws = g.Save(); g.TranslateTransform(-2, -10); g.RotateTransform(flap * 25f);
            g.FillEllipse(wing, -8, -14, 16, 14); g.Restore(ws);
            g.FillEllipse(ye, -14, -9, 28, 18); g.DrawEllipse(Ol, -14, -9, 28, 18);
            g.FillRectangle(BlackB, -5, -8, 5, 16); g.FillRectangle(BlackB, 4, -7, 4, 14);
            g.FillPolygon(BlackB, new[] { new PointF(-14, -3), new PointF(-23, 0), new PointF(-14, 3) });
            g.FillEllipse(WhiteB, 7, -6, 8, 8); g.FillEllipse(BlackB, 10, -4, 3, 4);
        }
        g.Restore(st);
    }

    static void DrawParticle(Graphics g, Particle p)
    {
        float k = p.Life / p.Max; int a = (int)(255 * Math.Clamp(k * 1.5f, 0f, 1f));
        using var br = new SolidBrush(Color.FromArgb(a, p.Col));
        if (p.Kind == 0)
        {
            float s = p.Size * (0.4f + k);
            g.FillPolygon(br, new[] { new PointF(p.X, p.Y - s), new PointF(p.X + s * 0.3f, p.Y - s * 0.3f), new PointF(p.X + s, p.Y), new PointF(p.X + s * 0.3f, p.Y + s * 0.3f),
                new PointF(p.X, p.Y + s), new PointF(p.X - s * 0.3f, p.Y + s * 0.3f), new PointF(p.X - s, p.Y), new PointF(p.X - s * 0.3f, p.Y - s * 0.3f) });
        }
        else { float s = p.Size * (p.Kind == 1 ? (1.6f - k) : 1f); g.FillEllipse(br, p.X - s, p.Y - s, 2 * s, 2 * s); }
    }

    // ================= WORLD =================
    public static void World(Graphics g, Level lv, Player pl, float camX, float camY, float t, List<Particle> parts)
    {
        float x0 = camX - 150, x1 = camX + Cfg.ViewW + 150;
        DrawTerrain(g, lv, camX, camY);
        foreach (var p in lv.Platforms) if (p.X + p.W > x0 && p.X < x1) DrawPlatform(g, p);
        foreach (var d in lv.Decors) if (d.X > x0 && d.X < x1) DrawDecor(g, d, t);
        foreach (var s in lv.Signs) if (s.X > x0 && s.X < x1) DrawSign(g, s);
        if (lv.HasLoop && lv.Loop.Cx + 260 > x0 && lv.Loop.Cx - 260 < x1) LoopRing(g, lv.Loop);
        foreach (var h in lv.Hazards) if (h.R.Right > x0 && h.R.X < x1) DrawHazard(g, h);
        foreach (var s in lv.Springs) if (s.X > x0 && s.X < x1) DrawSpring(g, s);
        foreach (var c in lv.Checkpoints) if (c.X > x0 && c.X < x1) DrawCheckpoint(g, c, t);
        if (lv.FinishX > x0 && lv.FinishX < x1) DrawFinish(g, lv);
        foreach (var r in lv.Rings) if (!r.Taken && r.X > x0 && r.X < x1) DrawRing(g, r.X, r.Y, t + r.Phase);
        foreach (var e in lv.Enemies) if (e.X > x0 && e.X < x1 && !(e.Dead && e.DeadT > 0.4f)) DrawEnemy(g, e, t);

        bool flicker = pl.Invuln > 0 && !pl.Dead && ((int)(t * 20f) & 1) == 0;
        if (!flicker) DrawConic(g, pl.X, pl.Y, pl.Facing, pl.State, pl.Anim, pl.BallAngle, MathF.Abs(pl.VX), pl.LandT, pl.StretchT, 1f, pl.DeadT);
        foreach (var p in parts) DrawParticle(g, p);
    }

    public static void SpeedLines(Graphics g, float vx, float t)
    {
        float sp = MathF.Abs(vx);
        if (sp < 600f) return;
        float a = Math.Clamp((sp - 600f) / 500f, 0f, 1f), sign = MathF.Sign(vx);
        using var pen = P(255, 255, 255, 3f, (int)(110 * a));
        for (int i = 0; i < 9; i++)
        {
            float yy = (i * 83 + 40) % 600 + 60, len = 120 + (i * 37) % 140;
            float xx = Mod(i * 191f - t * sp * 2.2f * sign, 1500f) - 100;
            g.DrawLine(pen, xx, yy, xx + len, yy);
        }
    }

    // ================= HERO =================
    public static void DrawConic(Graphics g, float x, float y, int facing, PState st, float anim, float ballAngle, float speed, float landT, float stretchT, float scale, float deadT = 0f)
    {
        var gs = g.Save();
        g.TranslateTransform(x, y);
        g.ScaleTransform(facing * scale, scale);
        if (st == PState.Roll) { Ball(g, ballAngle); g.Restore(gs); return; }

        float lean = Math.Clamp(speed / 900f, 0f, 1f);
        if (st == PState.Idle || st == PState.Land) lean = 0;
        float sx = 1f, sy = 1f;
        if (st == PState.Land) { sx = 1.15f; sy = 0.82f; } else if (stretchT > 0) { sx = 0.9f; sy = 1.14f; }
        g.ScaleTransform(sx, sy);
        if (st == PState.Dead) { g.TranslateTransform(0, -20); g.RotateTransform(deadT * 540f); g.TranslateTransform(0, 20); }
        else g.RotateTransform(st == PState.Hurt ? -16f : st == PState.Jump ? -4f : lean * 20f);

        bool running = st == PState.Run || st == PState.Fast;
        float by = running ? -MathF.Abs(MathF.Sin(anim)) * 2.5f : 0f;
        float stride = running ? 7 + lean * 14 : 0, lift = 5 + lean * 9;
        PointF f1, f2;
        if (st == PState.Jump || st == PState.Hurt || st == PState.Dead) { f1 = new PointF(9, -9); f2 = new PointF(-7, -4); }
        else if (!running) { f1 = new PointF(5, 0); f2 = new PointF(-3, 0); }
        else
        {
            f1 = new PointF(MathF.Sin(anim) * stride + 1, -MathF.Max(0, MathF.Cos(anim)) * lift);
            f2 = new PointF(MathF.Sin(anim + MathF.PI) * stride + 1, -MathF.Max(0, MathF.Cos(anim + MathF.PI)) * lift);
        }
        var hip = new PointF(1, -14 + by);
        var hc = new PointF(3, -33 + by);

        // spines (swept back by speed)
        float[] baseA = { 118f, 150f, 178f, 206f, 232f }, len = { 17, 24, 27, 24, 17 };
        var sp = new List<PointF> { new PointF(hc.X + 1, hc.Y - 9) };
        for (int k = 0; k < baseA.Length; k++)
        {
            float a = baseA[k] + (180f - baseA[k]) * 0.35f * lean;
            float L = len[k] + lean * 10f + (running ? MathF.Sin(anim * 2 + k) * 1.5f : 0f);
            float va = (a - 14f) * MathF.PI / 180f, ta = a * MathF.PI / 180f;
            sp.Add(new PointF(hc.X + 10 * MathF.Cos(va), hc.Y - 10 * MathF.Sin(va)));
            sp.Add(new PointF(hc.X + L * MathF.Cos(ta), hc.Y - L * MathF.Sin(ta)));
        }
        sp.Add(new PointF(hc.X - 6, hc.Y + 8));
        g.FillPolygon(SpineB, sp.ToArray()); g.DrawPolygon(Ol, sp.ToArray());

        // back leg + back arm
        Leg(g, hip, f2);
        Arm(g, new PointF(0, -24 + by), st, anim + MathF.PI, lean, running);
        // torso
        g.FillEllipse(Violet, -9, -32 + by, 19, 20); g.DrawEllipse(Ol, -9, -32 + by, 19, 20);
        g.FillEllipse(Cream, 1, -29 + by, 10, 13);
        // front leg
        Leg(g, hip, f1);
        // head
        g.FillEllipse(Violet, hc.X - 11.5f, hc.Y - 11.5f, 23, 23); g.DrawEllipse(Ol, hc.X - 11.5f, hc.Y - 11.5f, 23, 23);
        g.FillEllipse(Violet, hc.X - 5, hc.Y - 17, 7, 9); g.DrawEllipse(Ol, hc.X - 5, hc.Y - 17, 7, 9);   // ear
        g.FillEllipse(Cream, hc.X + 1, hc.Y - 1, 12, 10);
        g.FillEllipse(BlackB, hc.X + 10, hc.Y, 5, 4);
        if (st == PState.Hurt || st == PState.Dead)
        {
            using var pen = P(24, 14, 46, 2f);
            g.DrawLine(pen, hc.X + 1, hc.Y - 9, hc.X + 8, hc.Y - 2); g.DrawLine(pen, hc.X + 8, hc.Y - 9, hc.X + 1, hc.Y - 2);
        }
        else
        {
            g.FillEllipse(WhiteB, hc.X, hc.Y - 11, 11, 14); g.DrawEllipse(Ol, hc.X, hc.Y - 11, 11, 14);
            g.FillEllipse(IrisB, hc.X + 4, hc.Y - 9, 7, 10);
            g.FillEllipse(BlackB, hc.X + 6, hc.Y - 7, 4, 6);
            g.FillEllipse(WhiteB, hc.X + 8, hc.Y - 7, 2, 2);
        }
        using (var pen = P(24, 14, 46, 1.5f)) g.DrawArc(pen, hc.X + 4, hc.Y + 2, 8, 5, 20, 140);
        // front arm
        Arm(g, new PointF(2, -24 + by), st, anim, lean, running);
        g.Restore(gs);
    }

    static void Leg(Graphics g, PointF hip, PointF foot)
    {
        g.DrawLine(LegOl, hip, foot); g.DrawLine(LegIn, hip, foot);
        using var sole = B(255, 255, 255);
        g.FillEllipse(sole, foot.X - 6, foot.Y - 6, 19, 6);
        g.FillEllipse(ShoeB, foot.X - 6, foot.Y - 10, 19, 8); g.DrawEllipse(Ol, foot.X - 6, foot.Y - 10, 19, 8);
        g.FillRectangle(BandB, foot.X - 1, foot.Y - 9, 4, 6);
    }

    static void Arm(Graphics g, PointF sh, PState st, float ph, float lean, bool running)
    {
        PointF hand;
        if (st == PState.Jump) hand = new PointF(sh.X + 7, sh.Y - 12);
        else if (st == PState.Hurt || st == PState.Dead) hand = new PointF(sh.X - 6, sh.Y - 8);
        else if (running) hand = new PointF(sh.X + 4 + MathF.Sin(ph) * (6 + lean * 8), sh.Y + 8 - MathF.Max(0, MathF.Cos(ph)) * 5);
        else hand = new PointF(sh.X + 4, sh.Y + 12);
        g.DrawLine(ArmOl, sh, hand); g.DrawLine(ArmIn, sh, hand);
        g.FillEllipse(GloveB, hand.X - 5.5f, hand.Y - 5.5f, 11, 11); g.DrawEllipse(Ol, hand.X - 5.5f, hand.Y - 5.5f, 11, 11);
    }

    static void Ball(Graphics g, float ang)
    {
        var s = g.Save();
        g.TranslateTransform(0, -14); g.RotateTransform(ang * 180f / MathF.PI);
        var pts = new PointF[3];
        for (int k = 0; k < 8; k++)
        {
            float a = k * MathF.Tau / 8f;
            pts[0] = new PointF(MathF.Cos(a - 0.32f) * 12, MathF.Sin(a - 0.32f) * 12);
            pts[1] = new PointF(MathF.Cos(a) * 22, MathF.Sin(a) * 22);
            pts[2] = new PointF(MathF.Cos(a + 0.32f) * 12, MathF.Sin(a + 0.32f) * 12);
            g.FillPolygon(SpineB, pts); g.DrawPolygon(Ol, pts);
        }
        g.FillEllipse(Violet, -13.5f, -13.5f, 27, 27); g.DrawEllipse(Ol, -13.5f, -13.5f, 27, 27);
        using (var pen = P(255, 228, 190, 4f)) g.DrawArc(pen, -8f, -8f, 16f, 16f, 30f, 130f);
        g.FillEllipse(WhiteB, -9f, -10f, 5f, 4f);
        g.Restore(s);
    }

    // ================= HUD & SCREENS =================
    static void Item(Graphics g, string label, string value, float x, Color vc)
    {
        Text(g, label, Label, C(255, 220, 60), x, 8);
        Text(g, value, Value, vc, x, 26);
    }

    public static void Hud(Graphics g, int score, int rings, int lives, float time, float speed, float loopNeed, string msg, float msgAlpha)
    {
        using (var strip = new LinearGradientBrush(new RectangleF(0, 0, Cfg.ViewW, 72), C(0, 0, 0, 170), C(0, 0, 0, 30), 90f))
            g.FillRectangle(strip, 0f, 0f, Cfg.ViewW, 72f);
        Item(g, "SCORE", score.ToString("D6"), 24, Color.White);
        Item(g, "RINGS", rings.ToString("D3"), 230, C(255, 215, 60));
        Item(g, "LIVES", "x" + lives, 400, Color.White);
        Item(g, "TIME", $"{(int)time / 60}:{(int)time % 60:D2}", 540, Color.White);

        // speedometer bar
        float bx = 800, bw = 330, by = 40, bh = 18;
        Text(g, "SPEED", Label, C(255, 220, 60), bx, 8);
        Text(g, ((int)(speed / 8f)).ToString("D3"), Value, Color.White, bx + bw + 50, 26, StringAlignment.Near);
        using (var back = B(20, 20, 40, 220)) g.FillRectangle(back, bx, by, bw, bh);
        float f = Math.Clamp(speed / 1400f, 0f, 1f);
        Color col = f < 0.5f ? Color.FromArgb(255, (int)(80 + 350 * f), 220, 60) : Color.FromArgb(255, 255, (int)(220 - 360 * (f - 0.5f)), 40);
        if (f > 0.01f) using (var fill = B(col.R, col.G, col.B)) g.FillRectangle(fill, bx, by, bw * f, bh);
        using (var tick = P(255, 255, 255, 1f, 120)) for (int i = 1; i < 10; i++) g.DrawLine(tick, bx + bw * i / 10f, by + 10, bx + bw * i / 10f, by + bh);
        using (var pen = P(255, 255, 255, 2f)) g.DrawRectangle(pen, bx, by, bw, bh);
        if (loopNeed > 0)
        {
            float mx = bx + bw * Math.Clamp(loopNeed / 1400f, 0f, 1f);
            g.FillPolygon(WhiteB, new[] { new PointF(mx - 5, by - 2), new PointF(mx + 5, by - 2), new PointF(mx, by + 6) });
            Text(g, "LOOP", Small, Color.White, mx, by + bh + 2, StringAlignment.Center, 1);
        }
        if (msgAlpha > 0) Text(g, msg, Mid, Color.FromArgb((int)(255 * Math.Clamp(msgAlpha, 0f, 1f)), 255, 240, 120), Cfg.ViewW / 2f, 110, StringAlignment.Center);
    }

    public static void Overlay(Graphics g, string title, Color tc, string[] lines, int sel, string footer, float t, int dim = 160)
    {
        using (var br = B(0, 0, 20, dim)) g.FillRectangle(br, 0f, 0f, Cfg.ViewW, Cfg.ViewH);
        var panel = new RectangleF(Cfg.ViewW / 2f - 360, 150, 720, 420);
        using (var path = RoundRect(panel, 18)) { using (var br = B(14, 24, 80, 225)) g.FillPath(br, path); using (var pen = P(120, 170, 255, 4f)) g.DrawPath(pen, path); }
        Text(g, title, OverlayFont, tc, Cfg.ViewW / 2f, 180, StringAlignment.Center, 4);
        float y = 290;
        for (int i = 0; i < lines.Length; i++)
        {
            bool s = i == sel;
            Text(g, (s ? "> " : "") + lines[i], Mid, s ? C(255, 230, 60) : Color.White, Cfg.ViewW / 2f, y, StringAlignment.Center);
            y += 46;
        }
        if (footer.Length > 0 && ((int)(t * 2) & 1) == 0)
            Text(g, footer, Small, C(200, 220, 255), Cfg.ViewW / 2f, 520, StringAlignment.Center);
    }

    // ================= TITLE SCREEN =================
    public static void Title(Graphics g, float t)
    {
        Background(g, t * 120f, 290f, t);
        var ground = new List<PointF>();
        for (float x = -100; x <= 1450; x += 8) ground.Add(new PointF(x, 590));
        var st = g.Save(); g.TranslateTransform(-((t * 300f) % 64f), 0); DrawSolid(g, ground, 780); g.Restore(st);

        Palm2(g, 70, 590, 1.7f, t);
        LoopRing(g, new LoopDef { Cx = 1000, Cy = 440, R = 150 });
        var sp = new Spring { X = 1150, Y = 590 };
        var s2 = g.Save(); g.TranslateTransform(1150, 590); g.ScaleTransform(2f, 2f); g.TranslateTransform(-1150, -590); DrawSpring(g, sp); g.Restore(s2);
        DrawRing(g, 560, 520 + 8 * MathF.Sin(t * 3), t, 2.2f); DrawRing(g, 650, 495 + 8 * MathF.Sin(t * 3 + 1), t + 1, 2.2f); DrawRing(g, 740, 520 + 8 * MathF.Sin(t * 3 + 2), t + 2, 2.2f);
        var bee = new Enemy { X = 150, Y = 270 + 12 * MathF.Sin(t * 2.5f), Flying = true, Dir = 1 };
        DrawEnemy(g, bee, t, 2.2f);

        using (var pen = P(255, 255, 255, 4f, 150)) for (int i = 0; i < 5; i++) g.DrawLine(pen, 40 + i * 20, 470 + i * 22, 230 + i * 10, 470 + i * 22);
        DrawConic(g, 330, 590, 1, PState.Fast, t * 18f, 0, 900f, 0, 0, 4f);

        // logo
        FontFamily fam; try { fam = new FontFamily("Arial Black"); } catch { fam = FontFamily.GenericSansSerif; }
        var ls = g.Save();
        g.TranslateTransform(Cfg.ViewW / 2f, 135);
        g.MultiplyTransform(new Matrix(1, 0, -0.2f, 1, 0, 0));
        using (var gp = new GraphicsPath())
        {
            using var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            gp.AddString("CONIC", fam, (int)FontStyle.Regular, 170f, new PointF(0, 0), sf);
            using (var p1 = P(255, 255, 255, 20f)) g.DrawPath(p1, gp);
            using (var p2 = P(20, 40, 150, 12f)) g.DrawPath(p2, gp);
            var bb = gp.GetBounds();
            using var fill = new LinearGradientBrush(bb, C(255, 240, 70), C(255, 140, 0), 90f);
            g.FillPath(fill, gp);
        }
        g.Restore(ls);

        // prompt panel
        var r = new RectangleF(Cfg.ViewW / 2f - 190, 612, 380, 50);
        using (var path = RoundRect(r, 12)) { using (var br = B(14, 30, 120, 235)) g.FillPath(br, path); using (var pen = P(150, 190, 255, 3f)) g.DrawPath(pen, path); }
        if (((int)(t * 2) & 1) == 0) Text(g, "START GAME", Mid, Color.White, Cfg.ViewW / 2f, 620, StringAlignment.Center);
        Text(g, "PRESS ANY KEY", Small, C(200, 220, 255), Cfg.ViewW / 2f, 664, StringAlignment.Center, 1);
        Text(g, "A/D or LEFT/RIGHT: run    SPACE/UP: jump    S/DOWN: roll    ESC: pause    R: restart", Small, Color.White, Cfg.ViewW / 2f, 686, StringAlignment.Center, 1);
        Text(g, "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space", Small, Color.White, Cfg.ViewW / 2f, 700, StringAlignment.Center, 1);
    }

    static void Palm2(Graphics g, float x, float y, float s, float t)
    {
        var st = g.Save(); g.TranslateTransform(x, y); g.ScaleTransform(s, s); Palm(g, t); g.Restore(st);
    }
}
