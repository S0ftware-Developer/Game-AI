using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace Conic;

public enum GameState { Title, Playing, Paused, GameOver, Victory }

public class GameForm : Form
{
    Level lv = null!;
    Player pl = null!;
    GameState state = GameState.Title;
    readonly HashSet<Keys> held = new();
    bool jumpPressed, fullscreen;
    int score, rings, ringsTotal, lives, pauseSel;
    float time, finishTime, camX, camY, look, t, deathTimer, msgT;
    string msg = "";
    readonly List<Particle> parts = new();
    readonly System.Windows.Forms.Timer timer = new() { Interval = 8 };
    readonly Stopwatch sw = Stopwatch.StartNew();
    double last, acc;
    readonly Random rng = new(5);

    public GameForm()
    {
        Text = "CONIC";
        ClientSize = new Size(1280, 720);
        MinimumSize = new Size(640, 400);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.Black;
        DoubleBuffered = true;
        KeyPreview = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        NewGame();
        timer.Tick += Tick;
        timer.Start();
        Deactivate += (s, e) => { held.Clear(); if (state == GameState.Playing) { state = GameState.Paused; pauseSel = 0; } };
        FormClosed += (s, e) => timer.Stop();
    }

    // ---------------- game setup ----------------
    void NewGame()
    {
        lv = new Level();
        pl = new Player(lv);
        pl.OnJump = () => Sfx.Jump.Play();
        pl.OnLand = () => Dust(pl.X, pl.Y - 2, 6);
        pl.OnLoopEnter = () => Sfx.Bounce.Play();
        score = rings = ringsTotal = 0; lives = 3; time = 0; deathTimer = 0;
        parts.Clear(); jumpPressed = false;
        Say("GREEN HILLS");
        SnapCamera();
    }

    void StartGame() { NewGame(); state = GameState.Playing; held.Clear(); }
    void Say(string m) { msg = m; msgT = 2.2f; }
    void SnapCamera() { camX = Math.Clamp(pl.X - Cfg.ViewW * 0.42f, 0, lv.Width - Cfg.ViewW); camY = Math.Clamp(pl.Y - 450f, -300f, 400f); look = 0; }

    // ---------------- input ----------------
    static bool IsJump(Keys k) => k == Keys.Space || k == Keys.Up || k == Keys.W;

    protected override void OnKeyDown(KeyEventArgs e)
    {
        var k = e.KeyCode;
        e.Handled = true; e.SuppressKeyPress = true;
        if (k == Keys.F11 || (e.Alt && k == Keys.Enter)) { ToggleFullscreen(); return; }
        if (k == Keys.M) { Sfx.Muted = !Sfx.Muted; return; }
        if (k == Keys.ShiftKey || k == Keys.ControlKey || k == Keys.Menu) return;

        switch (state)
        {
            case GameState.Title:
                if (k != Keys.Escape) StartGame();
                break;
            case GameState.Playing:
                if (k == Keys.Escape) { state = GameState.Paused; pauseSel = 0; held.Clear(); }
                else if (k == Keys.R) StartGame();
                else { bool first = held.Add(k); if (first && IsJump(k)) jumpPressed = true; }
                break;
            case GameState.Paused:
                if (k == Keys.Escape) state = GameState.Playing;
                else if (k == Keys.R) StartGame();
                else if (k == Keys.Up || k == Keys.W || k == Keys.Down || k == Keys.S) pauseSel = 1 - pauseSel;
                else if (k == Keys.Enter || k == Keys.Space) { if (pauseSel == 0) state = GameState.Playing; else StartGame(); }
                break;
            default:
                if (k == Keys.Enter || k == Keys.Space || k == Keys.R) StartGame();
                break;
        }
    }

    protected override void OnKeyUp(KeyEventArgs e) { held.Remove(e.KeyCode); e.Handled = true; }

    void ToggleFullscreen()
    {
        fullscreen = !fullscreen;
        if (fullscreen) { FormBorderStyle = FormBorderStyle.None; WindowState = FormWindowState.Maximized; }
        else { WindowState = FormWindowState.Normal; FormBorderStyle = FormBorderStyle.Sizable; }
    }

    // ---------------- main loop ----------------
    void Tick(object? s, EventArgs e)
    {
        double now = sw.Elapsed.TotalSeconds;
        double frame = Math.Min(now - last, 0.1);
        last = now;
        acc += frame;
        while (acc >= Cfg.Step) { Update(Cfg.Step); acc -= Cfg.Step; }
        Invalidate();
    }

    void Update(float dt)
    {
        t += dt;
        if (state != GameState.Playing) return;
        time += dt;
        msgT = MathF.Max(0, msgT - dt);

        bool left = held.Contains(Keys.Left) || held.Contains(Keys.A);
        bool right = held.Contains(Keys.Right) || held.Contains(Keys.D);
        bool down = held.Contains(Keys.Down) || held.Contains(Keys.S);
        bool jumpHeld = held.Contains(Keys.Space) || held.Contains(Keys.Up) || held.Contains(Keys.W);
        bool jp = jumpPressed; jumpPressed = false;

        pl.Update(dt, left, right, down, jumpHeld, jp);
        World(dt, jumpHeld);
        UpdateCamera(dt);
        UpdateParticles(dt);
    }

    void World(float dt, bool jumpHeld)
    {
        foreach (var s in lv.Springs) { s.Comp = MathF.Max(0, s.Comp - dt); s.Cool = MathF.Max(0, s.Cool - dt); }
        foreach (var en in lv.Enemies)
        {
            if (en.Dead) { en.DeadT += dt; continue; }
            en.T += dt;
            en.X += en.Dir * en.Speed * dt;
            if (en.X > en.MaxX) { en.X = en.MaxX; en.Dir = -1; }
            if (en.X < en.MinX) { en.X = en.MinX; en.Dir = 1; }
            if (en.Flying) en.Y = en.BaseY + MathF.Sin(en.T * 3f) * 18f;
            else { float gy = lv.TerrainY(en.X); if (gy < Level.INF) en.Y = gy; }
        }

        if (!pl.Dead)
        {
            var box = pl.Box();

            foreach (var r in lv.Rings)
            {
                if (r.Taken) continue;
                float dx = r.X - pl.X, dy = r.Y - pl.CenterY;
                if (dx * dx + dy * dy < 30f * 30f)
                {
                    r.Taken = true; rings++; ringsTotal++; score += 10;
                    Spark(r.X, r.Y, 6, Color.Gold, 140f);
                    Sfx.Ring.Play();
                    if (rings % 100 == 0) { lives++; Say("1UP!"); }
                }
            }

            foreach (var s in lv.Springs)
            {
                if (s.Cool > 0 || pl.InLoop) continue;
                if (MathF.Abs(pl.X - s.X) < 26f && pl.Y > s.Y - 34f && pl.Y < s.Y + 12f)
                {
                    pl.VY = Cfg.SpringVel; pl.Grounded = false; pl.Rolling = false; pl.JumpedUp = false;
                    pl.Y = s.Y - 6f; pl.StretchT = 0.3f;
                    s.Comp = 0.3f; s.Cool = 0.3f;
                    Spark(s.X, s.Y - 20, 8, Color.White, 200f);
                    Sfx.Bounce.Play();
                }
            }

            foreach (var en in lv.Enemies)
            {
                if (en.Dead) continue;
                var eb = RectangleF.Inflate(en.Box, -2, -2);
                if (!box.IntersectsWith(eb)) continue;
                bool stomp = pl.VY > 60f && !pl.Grounded && pl.Y - 8f < en.Box.Top + en.Box.Height * 0.6f;
                bool attack = pl.Rolling || pl.InLoop || pl.AirBall || stomp;
                if (attack)
                {
                    en.Dead = true; en.DeadT = 0; score += 100;
                    Spark(en.X, en.Y - 14, 12, Color.OrangeRed, 220f);
                    Sfx.Stomp.Play();
                    if (!pl.Grounded && !pl.InLoop) { pl.VY = jumpHeld ? -640f : -420f; pl.JumpedUp = false; }
                }
                else Damage(en.X);
            }

            foreach (var hz in lv.Hazards)
            {
                var r = RectangleF.Inflate(hz.R, -3, -3);
                if (box.IntersectsWith(r)) Damage(hz.R.X + hz.R.Width / 2f);
            }

            foreach (var cp in lv.Checkpoints)
                if (!cp.On && pl.X >= cp.X)
                {
                    cp.On = true; lv.Respawn = new PointF(cp.X, cp.Y);
                    Say("CHECKPOINT!"); Sfx.Check.Play();
                    Spark(cp.X, cp.Y - 80, 10, Color.HotPink, 160f);
                }

            if (pl.Y > lv.KillY) Kill();
            if (pl.X >= lv.FinishX) Win();
        }
        else
        {
            deathTimer += dt;
            if (deathTimer > 1.5f)
            {
                lives--;
                if (lives <= 0) state = GameState.GameOver;
                else { pl.Reset(lv.Respawn.X, lv.Respawn.Y); rings = 0; deathTimer = 0; SnapCamera(); }
            }
        }

        if (pl.Grounded && !pl.Rolling && MathF.Abs(pl.VX) > 520f && rng.NextSingle() < dt * 25f)
            Dust(pl.X - pl.Facing * 8f, pl.Y - 2f, 1);
    }

    void Damage(float fromX)
    {
        if (pl.Invuln > 0 || pl.Dead) return;
        if (rings > 0)
        {
            for (int i = 0; i < Math.Min(rings, 14); i++)
                parts.Add(new Particle { X = pl.X, Y = pl.CenterY, VX = (rng.NextSingle() - 0.5f) * 500f, VY = -rng.NextSingle() * 450f - 100f, Life = 1.2f, Max = 1.2f, Size = 5, Col = Color.Gold, Kind = 2 });
            rings = 0;
            pl.Hurt(fromX);
            Sfx.Hurt.Play();
        }
        else Kill();
    }

    void Kill() { if (pl.Dead) return; pl.Die(); deathTimer = 0; Sfx.Die.Play(); }

    void Win()
    {
        if (state != GameState.Playing) return;
        finishTime = time;
        score += Math.Max(0, 150 - (int)time) * 20;
        state = GameState.Victory;
        Sfx.Win.Play();
    }

    void UpdateCamera(float dt)
    {
        float targetLook = pl.InLoop ? pl.LoopDir * 120f : Math.Clamp(pl.VX * 0.32f, -260f, 360f);
        look += (targetLook - look) * MathF.Min(1f, dt * 2.5f);
        float tx = pl.X - Cfg.ViewW * 0.42f + look;
        camX += (tx - camX) * MathF.Min(1f, dt * 7f);
        camX = Math.Clamp(camX, 0, lv.Width - Cfg.ViewW);
        if (!pl.Dead)
        {
            float ty = (pl.InLoop ? lv.Loop.Cy + lv.Loop.R : pl.Y) - (pl.InLoop ? 470f : 450f);
            camY += (ty - camY) * MathF.Min(1f, dt * 4f);
        }
        camY = Math.Clamp(camY, -300f, 400f);
    }

    // ---------------- particles ----------------
    void Spark(float x, float y, int n, Color c, float speed)
    {
        for (int i = 0; i < n; i++)
        {
            float a = rng.NextSingle() * MathF.Tau, v = speed * (0.3f + rng.NextSingle() * 0.7f);
            parts.Add(new Particle { X = x, Y = y, VX = MathF.Cos(a) * v, VY = MathF.Sin(a) * v, Life = 0.5f, Max = 0.5f, Size = 5 + rng.NextSingle() * 4, Col = c, Kind = 0 });
        }
    }

    void Dust(float x, float y, int n)
    {
        for (int i = 0; i < n; i++)
            parts.Add(new Particle { X = x, Y = y, VX = (rng.NextSingle() - 0.5f) * 120f, VY = -20f - rng.NextSingle() * 60f, Life = 0.4f, Max = 0.4f, Size = 4, Col = Color.FromArgb(230, 220, 190), Kind = 1 });
    }

    void UpdateParticles(float dt)
    {
        if (parts.Count > 400) parts.RemoveRange(0, parts.Count - 400);
        for (int i = parts.Count - 1; i >= 0; i--)
        {
            var p = parts[i];
            p.Life -= dt;
            if (p.Life <= 0) { parts.RemoveAt(i); continue; }
            p.X += p.VX * dt; p.Y += p.VY * dt;
            p.VY += (p.Kind == 1 ? -10f : p.Kind == 2 ? 900f : 600f) * dt;
        }
    }

    // ---------------- rendering ----------------
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Color.Black);
        float s = MathF.Min(ClientSize.Width / (float)Cfg.ViewW, ClientSize.Height / (float)Cfg.ViewH);
        if (s <= 0.01f) return;
        g.TranslateTransform((ClientSize.Width - Cfg.ViewW * s) / 2f, (ClientSize.Height - Cfg.ViewH * s) / 2f);
        g.ScaleTransform(s, s);
        g.SetClip(new RectangleF(0, 0, Cfg.ViewW, Cfg.ViewH));
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.AntiAlias;

        if (state == GameState.Title) { GameRenderer.Title(g, t); return; }

        GameRenderer.Background(g, camX, camY, t);
        var st = g.Save();
        g.TranslateTransform(-MathF.Round(camX), -MathF.Round(camY));
        GameRenderer.World(g, lv, pl, camX, camY, t, parts);
        g.Restore(st);
        GameRenderer.SpeedLines(g, pl.VX, t);
        GameRenderer.Hud(g, score, rings, lives, state == GameState.Victory ? finishTime : time, MathF.Abs(pl.VX), lv.LoopNeedSpeed, msg, msgT > 0.4f ? 1f : msgT / 0.4f);

        switch (state)
        {
            case GameState.Paused:
                GameRenderer.Overlay(g, "PAUSED", Color.White, new[] { "RESUME", "RESTART LEVEL" }, pauseSel, "UP/DOWN + ENTER   (ESC: resume, R: restart)", t);
                break;
            case GameState.GameOver:
                GameRenderer.Overlay(g, "GAME OVER", Color.OrangeRed,
                    new[] { $"SCORE   {score:D6}", $"RINGS   {ringsTotal}" }, -1, "PRESS ENTER TO RESTART", t, 190);
                break;
            case GameState.Victory:
                GameRenderer.Overlay(g, "LEVEL COMPLETE", Color.Gold,
                    new[] { $"SCORE   {score:D6}", $"RINGS   {ringsTotal}", $"TIME    {(int)finishTime / 60}:{finishTime % 60:00.0}" }, -1, "PRESS ENTER TO RESTART", t, 120);
                break;
        }
    }
}
