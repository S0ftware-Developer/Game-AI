# CONIC — 2D platformer (C# / .NET 8 / WinForms / GDI+)

Single level "Green Hills" with momentum-based movement, rolling, springs, ramps,
a speed-dependent loop, enemies, checkpoints and a finish line.
All graphics are drawn in code and all sounds are generated at runtime (no assets).

## Build
Requires the .NET 8 SDK on Windows 10/11 x64.

    build.bat

Result: `publish\Conic.exe` (self-contained, single file, no runtime needed).
For development you can also open `Conic.csproj` in Visual Studio 2022 and press F5.

## Controls
| Key | Action |
|---|---|
| Left / A, Right / D | accelerate / run |
| Space / Up / W | jump (hold for higher) |
| Down / S | roll (while moving) |
| Esc | pause / resume |
| R | restart level |
| F11 | fullscreen, M mute |

## Tuning
All physics values are in `Config.cs` (acceleration, max speed, friction, gravity,
jump, slopes, spring power, loop gravity).
The level layout is in `Level.cs` (constructor: terrain sections first, objects after).

## Loop
Entry speed needed is shown on the SPEED bar ("LOOP" marker). Slower entries climb part-way
and slide back or fall off the track; very slow entries just walk past.

## Troubleshooting the build
* `build.bat` opens its own console window and keeps it open, printing the .NET SDK version and any errors.
* If nothing happens at all, open **Command Prompt** in the project folder and run the command manually:

      dotnet publish Conic.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishTrimmed=false -o publish

* Make sure the ZIP is fully extracted (do not run `build.bat` from inside the ZIP viewer).
* `dotnet --version` must print 8.x (install the .NET 8 **SDK**, not only the Runtime).
