using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace NewBreakoutReborn
{
    public partial class GameForm
    {
        // ==========================================================
        //  Полный запуск / перезапуск игры (клавиша R — "новая игра")
        // ==========================================================
        private void StartNewGame()
        {
            score = 0;
            lives = 3;
            level = 1;

            BuildBrickGrid();
            ResetBallAndPaddleForNewLife();
            state = GameState.WaitingToLaunch;
        }

        // --- Создание полного набора кирпичей для текущего уровня ---
        private void BuildBrickGrid()
        {
            bricks.Clear();

            for (int row = 0; row < BrickRows; row++)
            {
                BrickColorType colorType = GetColorForRow(row);
                float y = BrickAreaTop + row * (BrickHeightConst + BrickGapY);

                for (int col = 0; col < BrickCols; col++)
                {
                    float x = PlayAreaLeft + col * (BrickWidth + BrickGapX);

                    bricks.Add(new Brick
                    {
                        X = x,
                        Y = y,
                        Width = BrickWidth,
                        Height = BrickHeightConst,
                        ColorType = colorType,
                        IsAlive = true
                    });
                }
            }
        }

        // --- Верхний ряд — красный, далее оранжевый, жёлтый, зелёный, голубой, фиолетовый ---
        private static BrickColorType GetColorForRow(int row)
        {
            switch (row)
            {
                case 0: return BrickColorType.Red;
                case 1: return BrickColorType.Orange;
                case 2: return BrickColorType.Yellow;
                case 3: return BrickColorType.Green;
                case 4: return BrickColorType.Cyan;
                default: return BrickColorType.Purple;
            }
        }

        private static int GetPointsForColor(BrickColorType colorType)
        {
            switch (colorType)
            {
                case BrickColorType.Red: return 60;
                case BrickColorType.Orange: return 50;
                case BrickColorType.Yellow: return 40;
                case BrickColorType.Green: return 30;
                case BrickColorType.Cyan: return 20;
                default: return 10; // Purple
            }
        }

        private static Color GetBrickBaseColor(BrickColorType colorType)
        {
            switch (colorType)
            {
                case BrickColorType.Red: return Color.FromArgb(235, 55, 55);
                case BrickColorType.Orange: return Color.FromArgb(240, 140, 30);
                case BrickColorType.Yellow: return Color.FromArgb(245, 205, 40);
                case BrickColorType.Green: return Color.FromArgb(70, 200, 80);
                case BrickColorType.Cyan: return Color.FromArgb(50, 180, 240);
                default: return Color.FromArgb(170, 90, 230); // Purple
            }
        }

        // --- Подготовка нового мяча: после потери жизни или начала уровня ---
        private void ResetBallAndPaddleForNewLife()
        {
            paddleX = PlayAreaLeft + ((PlayAreaRight - PlayAreaLeft) - PaddleWidth) / 2f;

            currentBallSpeed = Math.Min(BaseBallSpeed + (level - 1) * LevelSpeedIncrement, MaxBallSpeed);

            PlaceBallOnPaddle();

            ballTrail.Clear();
            leftPressed = false;
            rightPressed = false;
        }

        // --- Мяч "сидит" на ракетке, пока не нажат Space ---
        private void PlaceBallOnPaddle()
        {
            ballX = paddleX + PaddleWidth / 2f - BallSize / 2f;
            ballY = PaddleY - BallSize - 2f;
            prevBallX = ballX;
            prevBallY = ballY;
            ballVX = 0f;
            ballVY = 0f;
        }

        private void LaunchBall()
        {
            // Лёгкий случайный угол при старте, чтобы траектория не была всегда одинаковой
            float launchAngleOffset = ((float)rng.NextDouble() - 0.5f) * 0.6f; // -0.3..0.3
            ballVX = currentBallSpeed * launchAngleOffset;
            float vySquared = currentBallSpeed * currentBallSpeed - ballVX * ballVX;
            ballVY = -(float)Math.Sqrt(Math.Max(vySquared, currentBallSpeed * currentBallSpeed * 0.6f));
        }

        // ==========================================================
        //  Ввод с клавиатуры
        // ==========================================================
        private void GameForm_KeyDown(object? sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    leftPressed = true;
                    break;

                case Keys.Right:
                    rightPressed = true;
                    break;

                case Keys.Space:
                    HandleSpacePressed();
                    break;

                case Keys.R:
                    StartNewGame();
                    break;

                case Keys.Escape:
                    this.Close();
                    break;
            }

            e.Handled = true;
            e.SuppressKeyPress = true;
        }

        private void GameForm_KeyUp(object? sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    leftPressed = false;
                    break;

                case Keys.Right:
                    rightPressed = false;
                    break;
            }
        }

        // --- Space: запуск мяча / пауза / продолжение / переход на новый уровень ---
        private void HandleSpacePressed()
        {
            switch (state)
            {
                case GameState.WaitingToLaunch:
                    LaunchBall();
                    state = GameState.Playing;
                    break;

                case GameState.Playing:
                    state = GameState.Paused;
                    break;

                case GameState.Paused:
                    state = GameState.Playing;
                    break;

                case GameState.LevelComplete:
                    level++;
                    BuildBrickGrid();
                    ResetBallAndPaddleForNewLife();
                    state = GameState.WaitingToLaunch;
                    break;

                case GameState.GameOver:
                    // Из экрана поражения мяч не запускается пробелом — для этого есть R.
                    break;
            }
        }

        // ==========================================================
        //  Главный игровой цикл
        // ==========================================================
        private void GameTimer_Tick(object? sender, EventArgs e)
        {
            tickCounter++;

            if (state == GameState.Playing || state == GameState.WaitingToLaunch)
            {
                HandlePaddleInput();
            }

            if (state == GameState.Playing)
            {
                MoveBall();
                CheckWallCollisions();
                CheckBrickCollisions();
                CheckPaddleCollision();
                CheckBallLost();
                UpdateBallTrail();
            }
            else if (state == GameState.WaitingToLaunch)
            {
                PlaceBallOnPaddle();
            }

            UpdateExplosions();

            this.Invalidate();
        }

        private void HandlePaddleInput()
        {
            if (leftPressed) paddleX -= PaddleSpeed;
            if (rightPressed) paddleX += PaddleSpeed;

            if (paddleX < PlayAreaLeft) paddleX = PlayAreaLeft;
            if (paddleX + PaddleWidth > PlayAreaRight) paddleX = PlayAreaRight - PaddleWidth;
        }

        private void MoveBall()
        {
            prevBallX = ballX;
            prevBallY = ballY;
            ballX += ballVX;
            ballY += ballVY;
        }

        private void UpdateBallTrail()
        {
            ballTrail.Enqueue(new PointF(ballX + BallSize / 2f, ballY + BallSize / 2f));
            while (ballTrail.Count > MaxTrailPoints)
            {
                ballTrail.Dequeue();
            }
        }

        // --- Столкновения с левой, правой и верхней стенками ---
        private void CheckWallCollisions()
        {
            if (ballX <= PlayAreaLeft)
            {
                ballX = PlayAreaLeft;
                ballVX = -ballVX;
            }
            if (ballX + BallSize >= PlayAreaRight)
            {
                ballX = PlayAreaRight - BallSize;
                ballVX = -ballVX;
            }
            if (ballY <= PlayAreaTop)
            {
                ballY = PlayAreaTop;
                ballVY = -ballVY;
            }
        }

        // --- Столкновения мяча с кирпичами ---
        private void CheckBrickCollisions()
        {
            for (int i = 0; i < bricks.Count; i++)
            {
                Brick brick = bricks[i];
                if (!brick.IsAlive) continue;

                bool overlapsX = ballX + BallSize > brick.X && ballX < brick.X + brick.Width;
                bool overlapsY = ballY + BallSize > brick.Y && ballY < brick.Y + brick.Height;

                if (!(overlapsX && overlapsY)) continue;

                bool cameFromAbove = prevBallY + BallSize <= brick.Y;
                bool cameFromBelow = prevBallY >= brick.Y + brick.Height;

                if (cameFromAbove || cameFromBelow)
                {
                    ballVY = -ballVY;
                }
                else
                {
                    ballVX = -ballVX;
                }

                brick.IsAlive = false;
                score += GetPointsForColor(brick.ColorType);

                SpawnExplosion(brick);
                GrowBallSpeed();

                // За один кадр разрушаем только один кирпич — этого достаточно
                // для простой и надёжной физики при обычных скоростях мяча.
                break;
            }

            if (AllBricksDestroyed())
            {
                state = GameState.LevelComplete;
            }
        }

        private void GrowBallSpeed()
        {
            currentBallSpeed = Math.Min(currentBallSpeed * PerHitSpeedGrowth, MaxBallSpeed);

            float magnitude = (float)Math.Sqrt(ballVX * ballVX + ballVY * ballVY);
            if (magnitude < 0.0001f) return;

            float scale = currentBallSpeed / magnitude;
            ballVX *= scale;
            ballVY *= scale;
        }

        private void SpawnExplosion(Brick brick)
        {
            float cx = brick.X + brick.Width / 2f;
            float cy = brick.Y + brick.Height / 2f;
            explosions.Add(new Explosion(cx, cy, GetBrickBaseColor(brick.ColorType), rng));
        }

        private void UpdateExplosions()
        {
            for (int i = explosions.Count - 1; i >= 0; i--)
            {
                explosions[i].AgeTicks++;
                if (explosions[i].AgeTicks >= Explosion.MaxAgeTicks)
                {
                    explosions.RemoveAt(i);
                }
            }
        }

        private bool AllBricksDestroyed()
        {
            for (int i = 0; i < bricks.Count; i++)
            {
                if (bricks[i].IsAlive) return false;
            }
            return true;
        }

        // --- Столкновение мяча с ракеткой ---
        private void CheckPaddleCollision()
        {
            float ballBottomPrev = prevBallY + BallSize;
            float ballBottomNow = ballY + BallSize;

            bool horizontallyOverPaddle =
                (ballX + BallSize >= paddleX) &&
                (ballX <= paddleX + PaddleWidth);

            bool crossedPaddleTop =
                ballVY > 0f &&
                ballBottomPrev <= PaddleY &&
                ballBottomNow >= PaddleY;

            if (crossedPaddleTop && horizontallyOverPaddle)
            {
                ballY = PaddleY - BallSize;

                float paddleCenter = paddleX + PaddleWidth / 2f;
                float ballCenter = ballX + BallSize / 2f;
                float hitOffset = (ballCenter - paddleCenter) / (PaddleWidth / 2f);

                if (hitOffset < -1f) hitOffset = -1f;
                if (hitOffset > 1f) hitOffset = 1f;

                const float maxHorizontalRatio = 0.8f;

                float newVX = currentBallSpeed * maxHorizontalRatio * hitOffset;
                float newVYSquared = currentBallSpeed * currentBallSpeed - newVX * newVX;
                float minVYSquared = currentBallSpeed * currentBallSpeed * 0.2f;
                float newVY = -(float)Math.Sqrt(Math.Max(newVYSquared, minVYSquared));

                ballVX = newVX;
                ballVY = newVY;
            }
        }

        // --- Проверка потери мяча (улетел ниже нижней границы игрового поля) ---
        private void CheckBallLost()
        {
            if (ballY > PlayAreaBottom)
            {
                lives--;

                if (lives > 0)
                {
                    ResetBallAndPaddleForNewLife();
                    state = GameState.WaitingToLaunch;
                }
                else
                {
                    state = GameState.GameOver;
                }
            }
        }
    }
}
