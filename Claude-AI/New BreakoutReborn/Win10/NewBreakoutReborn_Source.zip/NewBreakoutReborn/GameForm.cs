using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace NewBreakoutReborn
{
    // Цвет ряда кирпичей (сверху вниз, как на референсе)
    public enum BrickColorType
    {
        Red,
        Orange,
        Yellow,
        Green,
        Cyan,
        Purple
    }

    // Один кирпич игрового поля
    public class Brick
    {
        public float X;
        public float Y;
        public float Width;
        public float Height;
        public BrickColorType ColorType;
        public bool IsAlive;
    }

    // Короткая вспышка-искра при разрушении кирпича
    public class Explosion
    {
        public float X;
        public float Y;
        public Color BaseColor;
        public int AgeTicks;
        public readonly PointF[] SparkDirections;

        public const int MaxAgeTicks = 14;

        public Explosion(float x, float y, Color baseColor, Random rng)
        {
            X = x;
            Y = y;
            BaseColor = baseColor;
            AgeTicks = 0;

            // Шесть искр, разлетающихся в случайно повёрнутых, но равномерно
            // распределённых направлениях — создаёт аккуратную симметричную вспышку.
            SparkDirections = new PointF[6];
            double startAngle = rng.NextDouble() * Math.PI * 2;
            for (int i = 0; i < SparkDirections.Length; i++)
            {
                double angle = startAngle + i * (Math.PI * 2 / SparkDirections.Length);
                SparkDirections[i] = new PointF((float)Math.Cos(angle), (float)Math.Sin(angle));
            }
        }
    }

    // Текущее состояние игры
    public enum GameState
    {
        WaitingToLaunch,
        Playing,
        Paused,
        LevelComplete,
        GameOver
    }

    // Главное окно игры "New Breakout Reborn"
    public partial class GameForm : Form
    {
        // ==========================================================
        //  Геометрия окна и игровой зоны
        // ==========================================================
        private const int WindowWidth = 900;
        private const int WindowHeight = 900;

        private const int HudTop = 12;
        private const int HudHeight = 100;

        private const float PlayAreaLeft = 30f;
        private const float PlayAreaRight = 870f;
        private const float PlayAreaTop = 125f;
        private const float PlayAreaBottom = 820f;

        private const int FooterTop = 835;
        private const int FooterBottom = 890;

        // Рамка вокруг игровой зоны (чисто декоративная геометрия)
        private static readonly RectangleF NeonFrameRect = new RectangleF(
            PlayAreaLeft - 10f,
            PlayAreaTop - 10f,
            (PlayAreaRight - PlayAreaLeft) + 20f,
            (PlayAreaBottom - PlayAreaTop) + 20f);

        // ==========================================================
        //  Сетка кирпичей
        // ==========================================================
        private const int BrickRows = 6;
        private const int BrickCols = 10;
        private const float BrickGapX = 6f;
        private const float BrickGapY = 5f;
        private const float BrickHeightConst = 30f;
        private static readonly float BrickAreaTop = PlayAreaTop + 10f;
        private static readonly float BrickWidth =
            ((PlayAreaRight - PlayAreaLeft) - (BrickCols - 1) * BrickGapX) / BrickCols;

        private readonly List<Brick> bricks = new List<Brick>();

        // ==========================================================
        //  Ракетка
        // ==========================================================
        private const float PaddleWidth = 110f;
        private const float PaddleHeight = 16f;
        private const float PaddleSpeed = 7.5f; // пикселей за тик
        private static readonly float PaddleY = PlayAreaBottom - 90f;

        private float paddleX;
        private bool leftPressed;
        private bool rightPressed;

        // ==========================================================
        //  Декоративные панели (Power-Up / Bonus) — визуальные, без игровой логики
        // ==========================================================
        private const float IconPanelSize = 70f;
        private static readonly float IconPanelY = PaddleY + 15f; // PaddleY=730 → Y=745, низ=815 (с запасом до FooterTop=835)
        private static readonly float LeftIconPanelX = PlayAreaLeft + 10f;
        private static readonly float RightIconPanelX = PlayAreaRight - 10f - IconPanelSize;

        // ==========================================================
        //  Мяч
        // ==========================================================
        private const float BallSize = 16f;
        private const float BaseBallSpeed = 5.0f;
        private const float LevelSpeedIncrement = 0.6f;
        private const float MaxBallSpeed = 11.5f;
        private const float PerHitSpeedGrowth = 1.015f; // +1.5% за каждый разбитый кирпич

        private float ballX;
        private float ballY;
        private float prevBallX;
        private float prevBallY;
        private float ballVX;
        private float ballVY;
        private float currentBallSpeed;

        private readonly Queue<PointF> ballTrail = new Queue<PointF>();
        private const int MaxTrailPoints = 10;

        // ==========================================================
        //  Общее состояние игры
        // ==========================================================
        private GameState state;
        private int score;
        private int lives;
        private int level;

        private readonly List<Explosion> explosions = new List<Explosion>();
        private readonly Random rng = new Random();

        // Звёздное поле фона (считается один раз и не меняется)
        private readonly List<PointF> stars = new List<PointF>();
        private readonly List<float> starRadii = new List<float>();
        private readonly List<int> starBaseAlphas = new List<int>();

        private readonly System.Windows.Forms.Timer gameTimer;
        private int tickCounter; // для лёгкого мерцания звёзд

        // ==========================================================
        //  Шрифты
        // ==========================================================
        private readonly Font hudLabelFont;
        private readonly Font hudValueFont;
        private readonly Font titleFontBig;
        private readonly Font titleFontSmall;
        private readonly Font overlayTitleFont;
        private readonly Font overlaySubFont;
        private readonly Font footerFont;
        private readonly Font iconLabelFont;

        private const string CopyrightText = "© 2026 Орлов Андрей. Сайт: orlovandrei.space.";

        public GameForm()
        {
            this.Text = "New Breakout Reborn";
            this.ClientSize = new Size(WindowWidth, WindowHeight);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Black;
            this.KeyPreview = true;

            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer,
                true);

            hudLabelFont = new Font("Consolas", 11f, FontStyle.Bold);
            hudValueFont = new Font("Consolas", 20f, FontStyle.Bold);
            titleFontBig = new Font("Arial", 30f, FontStyle.Bold);
            titleFontSmall = new Font("Arial", 16f, FontStyle.Bold);
            overlayTitleFont = new Font("Consolas", 32f, FontStyle.Bold);
            overlaySubFont = new Font("Consolas", 16f, FontStyle.Regular);
            footerFont = new Font("Consolas", 11f, FontStyle.Regular);
            iconLabelFont = new Font("Consolas", 8f, FontStyle.Bold);

            this.KeyDown += GameForm_KeyDown;
            this.KeyUp += GameForm_KeyUp;
            this.Paint += GameForm_Paint;

            BuildStarField();

            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 16; // ~60 кадров в секунду
            gameTimer.Tick += GameTimer_Tick;

            StartNewGame();

            gameTimer.Start();
        }

        // --- Звёздный фон генерируется один раз при запуске ---
        private void BuildStarField()
        {
            int starCount = 90;
            for (int i = 0; i < starCount; i++)
            {
                float x = PlayAreaLeft + (float)rng.NextDouble() * (PlayAreaRight - PlayAreaLeft);
                float y = BrickAreaTop + 220f + (float)rng.NextDouble() * (PlayAreaBottom - (BrickAreaTop + 220f));
                stars.Add(new PointF(x, y));
                starRadii.Add(0.6f + (float)rng.NextDouble() * 1.8f);
                starBaseAlphas.Add(60 + rng.Next(140));
            }
        }

        // ==========================================================
        //  Освобождение ресурсов при закрытии окна
        // ==========================================================
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                gameTimer?.Stop();
                gameTimer?.Dispose();

                hudLabelFont?.Dispose();
                hudValueFont?.Dispose();
                titleFontBig?.Dispose();
                titleFontSmall?.Dispose();
                overlayTitleFont?.Dispose();
                overlaySubFont?.Dispose();
                footerFont?.Dispose();
                iconLabelFont?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
