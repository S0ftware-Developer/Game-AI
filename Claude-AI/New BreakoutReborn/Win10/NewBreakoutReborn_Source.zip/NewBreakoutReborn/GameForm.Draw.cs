using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace NewBreakoutReborn
{
    public partial class GameForm
    {
        private static readonly Color NeonBlue = Color.FromArgb(70, 170, 255);
        private static readonly Color PanelFill = Color.FromArgb(230, 10, 18, 40);
        private static readonly Color PanelBorder = Color.FromArgb(90, 190, 255);

        // ==========================================================
        //  Главный обработчик отрисовки
        // ==========================================================
        private void GameForm_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            g.Clear(Color.Black);

            DrawPlayfieldBackground(g);
            DrawBricks(g);
            DrawDecorativeIcons(g);
            DrawExplosions(g);
            DrawPaddle(g);
            DrawBallWithTrail(g);
            DrawNeonFrame(g);
            DrawHud(g);
            DrawFooter(g);

            switch (state)
            {
                case GameState.WaitingToLaunch:
                    DrawCenteredHint(g, "НАЖМИТЕ SPACE ДЛЯ ЗАПУСКА МЯЧА");
                    break;
                case GameState.Paused:
                    DrawOverlay(g, "ПАУЗА", "Нажмите Space, чтобы продолжить", Color.FromArgb(220, 255, 255, 255));
                    break;
                case GameState.LevelComplete:
                    DrawOverlay(g, $"УРОВЕНЬ {level} ПРОЙДЕН!", "Нажмите Space для следующего уровня", Color.FromArgb(230, 255, 215, 80));
                    break;
                case GameState.GameOver:
                    DrawOverlay(g, "GAME OVER", $"Счёт: {score}   •   Нажмите R для новой игры", Color.FromArgb(235, 255, 90, 90));
                    break;
            }
        }

        // ==========================================================
        //  Вспомогательное: скруглённый прямоугольник
        // ==========================================================
        private static GraphicsPath RoundedRect(RectangleF rect, float radius)
        {
            GraphicsPath path = new GraphicsPath();
            float d = radius * 2f;

            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        // ==========================================================
        //  Космический фон игрового поля
        // ==========================================================
        private void DrawPlayfieldBackground(Graphics g)
        {
            RectangleF area = new RectangleF(PlayAreaLeft, PlayAreaTop, PlayAreaRight - PlayAreaLeft, PlayAreaBottom - PlayAreaTop);

            using (var bgBrush = new LinearGradientBrush(
                       area, Color.FromArgb(10, 12, 30), Color.FromArgb(5, 4, 16), LinearGradientMode.Vertical))
            {
                g.FillRectangle(bgBrush, area);
            }

            // Несколько мягких туманностей для атмосферы
            DrawNebulaBlob(g, PlayAreaLeft + 140f, PlayAreaTop + 420f, 180f, Color.FromArgb(18, 60, 90, 200));
            DrawNebulaBlob(g, PlayAreaRight - 150f, PlayAreaTop + 560f, 150f, Color.FromArgb(16, 120, 60, 200));

            // Звёзды с лёгким мерцанием
            for (int i = 0; i < stars.Count; i++)
            {
                int twinkle = (int)(20 * Math.Sin((tickCounter + i * 13) * 0.03));
                int alpha = Math.Max(30, Math.Min(255, starBaseAlphas[i] + twinkle));

                using (Brush starBrush = new SolidBrush(Color.FromArgb(alpha, 220, 230, 255)))
                {
                    float r = starRadii[i];
                    g.FillEllipse(starBrush, stars[i].X - r, stars[i].Y - r, r * 2f, r * 2f);
                }
            }
        }

        private void DrawNebulaBlob(Graphics g, float cx, float cy, float radius, Color color)
        {
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(cx - radius, cy - radius, radius * 2f, radius * 2f);
                using (var brush = new PathGradientBrush(path))
                {
                    brush.CenterColor = color;
                    brush.SurroundColors = new[] { Color.FromArgb(0, color) };
                    g.FillPath(brush, path);
                }
            }
        }

        // ==========================================================
        //  Неоновая рамка вокруг игровой зоны
        // ==========================================================
        private void DrawNeonFrame(Graphics g)
        {
            // Внешнее свечение — несколько полупрозрачных обводок по убыванию
            for (int i = 4; i >= 1; i--)
            {
                int alpha = 50 - i * 8;
                using (var glowPen = new Pen(Color.FromArgb(Math.Max(alpha, 10), NeonBlue), i * 2.2f))
                {
                    g.DrawPath(glowPen, RoundedRect(
                        RectangleF.Inflate(NeonFrameRect, i, i), 16f));
                }
            }

            using (var mainPen = new Pen(NeonBlue, 3f))
            {
                g.DrawPath(mainPen, RoundedRect(NeonFrameRect, 16f));
            }
        }

        // ==========================================================
        //  Кирпичи
        // ==========================================================
        private void DrawBricks(Graphics g)
        {
            foreach (Brick brick in bricks)
            {
                if (!brick.IsAlive) continue;

                RectangleF rect = new RectangleF(brick.X, brick.Y, brick.Width, brick.Height);
                Color baseColor = GetBrickBaseColor(brick.ColorType);
                Color lightColor = ControlPaint.Light(baseColor, 0.35f);
                Color darkColor = ControlPaint.Dark(baseColor, 0.15f);

                using (var path = RoundedRect(rect, 4f))
                using (var brush = new LinearGradientBrush(rect, lightColor, darkColor, LinearGradientMode.Vertical))
                {
                    g.FillPath(brush, path);
                }

                using (var borderPen = new Pen(Color.FromArgb(90, 0, 0, 0), 1f))
                {
                    g.DrawPath(borderPen, RoundedRect(rect, 4f));
                }

                // Небольшой блик сверху-слева, как на референсе
                using (var glintBrush = new SolidBrush(Color.FromArgb(70, 255, 255, 255)))
                {
                    g.FillEllipse(glintBrush, rect.X + 3f, rect.Y + 2f, rect.Width * 0.3f, rect.Height * 0.35f);
                }
            }
        }

        // ==========================================================
        //  Декоративные панели Power-Up / Bonus (визуал, без логики)
        // ==========================================================
        private void DrawDecorativeIcons(Graphics g)
        {
            DrawIconPanel(g, LeftIconPanelX, "POWER-UP", DrawShieldGlyph);
            DrawIconPanel(g, RightIconPanelX, "BONUS", DrawStarGlyph);
        }

        private void DrawIconPanel(Graphics g, float x, string label, Action<Graphics, RectangleF> glyphDrawer)
        {
            RectangleF panelRect = new RectangleF(x, IconPanelY, IconPanelSize, IconPanelSize);

            using (var path = RoundedRect(panelRect, 10f))
            {
                using (var fillBrush = new SolidBrush(PanelFill))
                {
                    g.FillPath(fillBrush, path);
                }
                using (var borderPen = new Pen(PanelBorder, 1.5f))
                {
                    g.DrawPath(borderPen, path);
                }
            }

            RectangleF glyphRect = RectangleF.Inflate(panelRect, -18f, -22f);
            glyphRect.Y -= 2f;
            glyphDrawer(g, glyphRect);

            using (Brush labelBrush = new SolidBrush(Color.FromArgb(200, 160, 210, 255)))
            {
                SizeF labelSize = g.MeasureString(label, iconLabelFont);
                g.DrawString(label, iconLabelFont, labelBrush,
                    panelRect.X + (panelRect.Width - labelSize.Width) / 2f,
                    panelRect.Bottom - labelSize.Height - 4f);
            }
        }

        private void DrawShieldGlyph(Graphics g, RectangleF bounds)
        {
            using (var path = new GraphicsPath())
            {
                float w = bounds.Width;
                float h = bounds.Height;
                PointF top = new PointF(bounds.X + w / 2f, bounds.Y);
                PointF left = new PointF(bounds.X, bounds.Y + h * 0.25f);
                PointF right = new PointF(bounds.X + w, bounds.Y + h * 0.25f);
                PointF bottomLeft = new PointF(bounds.X + w * 0.15f, bounds.Y + h * 0.65f);
                PointF bottomRight = new PointF(bounds.X + w * 0.85f, bounds.Y + h * 0.65f);
                PointF bottom = new PointF(bounds.X + w / 2f, bounds.Y + h);

                path.AddLine(top, right);
                path.AddLine(right, bottomRight);
                path.AddLine(bottomRight, bottom);
                path.AddLine(bottom, bottomLeft);
                path.AddLine(bottomLeft, left);
                path.CloseFigure();

                using (var brush = new SolidBrush(Color.FromArgb(200, 70, 170, 255)))
                {
                    g.FillPath(brush, path);
                }
                using (var pen = new Pen(Color.FromArgb(230, 150, 210, 255), 1.5f))
                {
                    g.DrawPath(pen, path);
                }
            }
        }

        private void DrawStarGlyph(Graphics g, RectangleF bounds)
        {
            PointF center = new PointF(bounds.X + bounds.Width / 2f, bounds.Y + bounds.Height / 2f);
            float outerR = bounds.Width / 2f;
            float innerR = outerR * 0.45f;

            PointF[] points = new PointF[10];
            for (int i = 0; i < 10; i++)
            {
                double angle = -Math.PI / 2 + i * Math.PI / 5;
                float r = (i % 2 == 0) ? outerR : innerR;
                points[i] = new PointF(
                    center.X + (float)Math.Cos(angle) * r,
                    center.Y + (float)Math.Sin(angle) * r);
            }

            using (var brush = new SolidBrush(Color.FromArgb(220, 255, 205, 60)))
            {
                g.FillPolygon(brush, points);
            }
            using (var pen = new Pen(Color.FromArgb(230, 255, 230, 140), 1.2f))
            {
                g.DrawPolygon(pen, points);
            }
        }

        // ==========================================================
        //  Ракетка — яркая "капсула" с металлическими торцами
        // ==========================================================
        private void DrawPaddle(Graphics g)
        {
            RectangleF rect = new RectangleF(paddleX, PaddleY, PaddleWidth, PaddleHeight);
            float radius = PaddleHeight / 2f;

            using (var path = RoundedRect(rect, radius))
            {
                using (var bodyBrush = new LinearGradientBrush(
                           rect, Color.FromArgb(150, 230, 255), Color.FromArgb(20, 140, 220), LinearGradientMode.Vertical))
                {
                    g.FillPath(bodyBrush, path);
                }
                using (var borderPen = new Pen(Color.FromArgb(220, 255, 255), 1.5f))
                {
                    g.DrawPath(borderPen, path);
                }
            }

            // Тонкая светящаяся полоса по центру
            using (var stripeBrush = new SolidBrush(Color.FromArgb(160, 255, 255, 255)))
            {
                g.FillRectangle(stripeBrush, rect.X + radius, rect.Y + rect.Height * 0.4f,
                    rect.Width - radius * 2f, rect.Height * 0.2f);
            }

            // Металлические торцы
            using (var capBrush = new SolidBrush(Color.FromArgb(230, 90, 100, 110)))
            {
                g.FillEllipse(capBrush, rect.X - 2f, rect.Y - 1f, PaddleHeight + 2f, PaddleHeight + 2f);
                g.FillEllipse(capBrush, rect.Right - PaddleHeight, rect.Y - 1f, PaddleHeight + 2f, PaddleHeight + 2f);
            }
        }

        // ==========================================================
        //  Мяч со светящимся следом
        // ==========================================================
        private void DrawBallWithTrail(Graphics g)
        {
            int index = 0;
            int count = ballTrail.Count;
            foreach (PointF point in ballTrail)
            {
                float t = count <= 1 ? 1f : (float)index / (count - 1);
                int alpha = (int)(90 * t);
                float r = 2f + 3f * t;

                using (Brush trailBrush = new SolidBrush(Color.FromArgb(alpha, 120, 180, 255)))
                {
                    g.FillEllipse(trailBrush, point.X - r, point.Y - r, r * 2f, r * 2f);
                }
                index++;
            }

            RectangleF ballRect = new RectangleF(ballX, ballY, BallSize, BallSize);

            using (var glowPath = new GraphicsPath())
            {
                glowPath.AddEllipse(RectangleF.Inflate(ballRect, 6f, 6f));
                using (var glowBrush = new PathGradientBrush(glowPath))
                {
                    glowBrush.CenterColor = Color.FromArgb(120, 170, 210, 255);
                    glowBrush.SurroundColors = new[] { Color.FromArgb(0, 170, 210, 255) };
                    g.FillPath(glowBrush, glowPath);
                }
            }

            using (var ballBrush = new LinearGradientBrush(
                       ballRect, Color.White, Color.FromArgb(160, 200, 255), LinearGradientMode.ForwardDiagonal))
            {
                g.FillEllipse(ballBrush, ballRect);
            }
            using (var ballPen = new Pen(Color.FromArgb(200, 220, 235, 255), 1f))
            {
                g.DrawEllipse(ballPen, ballRect);
            }
        }

        // ==========================================================
        //  Эффекты разрушения кирпичей
        // ==========================================================
        private void DrawExplosions(Graphics g)
        {
            foreach (Explosion ex in explosions)
            {
                float t = (float)ex.AgeTicks / Explosion.MaxAgeTicks;
                int alpha = (int)(255 * (1f - t));
                if (alpha <= 0) continue;

                // Центральная вспышка
                float flashRadius = 4f + 22f * t;
                using (var flashPath = new GraphicsPath())
                {
                    flashPath.AddEllipse(ex.X - flashRadius, ex.Y - flashRadius, flashRadius * 2f, flashRadius * 2f);
                    using (var flashBrush = new PathGradientBrush(flashPath))
                    {
                        flashBrush.CenterColor = Color.FromArgb(alpha, 255, 240, 200);
                        flashBrush.SurroundColors = new[] { Color.FromArgb(0, ex.BaseColor) };
                        g.FillPath(flashBrush, flashPath);
                    }
                }

                // Разлетающиеся искры
                float sparkDistance = 6f + 34f * t;
                float sparkSize = Math.Max(1f, 4f * (1f - t));

                using (Brush sparkBrush = new SolidBrush(Color.FromArgb(alpha, ex.BaseColor)))
                {
                    foreach (PointF dir in ex.SparkDirections)
                    {
                        float sx = ex.X + dir.X * sparkDistance;
                        float sy = ex.Y + dir.Y * sparkDistance;
                        g.FillRectangle(sparkBrush, sx - sparkSize / 2f, sy - sparkSize / 2f, sparkSize, sparkSize);
                    }
                }
            }
        }

        // ==========================================================
        //  HUD: счёт, заголовок, уровень, жизни
        // ==========================================================
        private void DrawHud(Graphics g)
        {
            // --- Панель очков (слева) ---
            RectangleF scorePanel = new RectangleF(10, HudTop, 230, HudHeight);
            DrawHudPanel(g, scorePanel);

            using (Brush labelBrush = new SolidBrush(Color.FromArgb(200, 150, 200, 255)))
            using (Brush valueBrush = new SolidBrush(Color.FromArgb(255, 255, 205, 60)))
            {
                g.DrawString("SCORE", hudLabelFont, labelBrush, scorePanel.X + 18f, scorePanel.Y + 12f);
                g.DrawString(score.ToString("000000"), hudValueFont, valueBrush, scorePanel.X + 16f, scorePanel.Y + 34f);
            }

            // --- Заголовок по центру ---
            RectangleF titlePanel = new RectangleF(250, HudTop, 400, HudHeight);
            DrawHudPanel(g, titlePanel);
            DrawTitleLogo(g, titlePanel);

            // --- Панель уровня ---
            RectangleF levelPanel = new RectangleF(660, HudTop, 110, HudHeight);
            DrawHudPanel(g, levelPanel);
            using (Brush labelBrush = new SolidBrush(Color.FromArgb(200, 150, 200, 255)))
            using (Brush valueBrush = new SolidBrush(Color.White))
            {
                SizeF labelSize = g.MeasureString("LEVEL", hudLabelFont);
                g.DrawString("LEVEL", hudLabelFont, labelBrush,
                    levelPanel.X + (levelPanel.Width - labelSize.Width) / 2f, levelPanel.Y + 14f);

                string levelText = level.ToString();
                SizeF valueSize = g.MeasureString(levelText, hudValueFont);
                g.DrawString(levelText, hudValueFont, valueBrush,
                    levelPanel.X + (levelPanel.Width - valueSize.Width) / 2f, levelPanel.Y + 38f);
            }

            // --- Панель жизней ---
            RectangleF livesPanel = new RectangleF(780, HudTop, 110, HudHeight);
            DrawHudPanel(g, livesPanel);
            using (Brush labelBrush = new SolidBrush(Color.FromArgb(200, 150, 200, 255)))
            {
                SizeF labelSize = g.MeasureString("LIVES", hudLabelFont);
                g.DrawString("LIVES", hudLabelFont, labelBrush,
                    livesPanel.X + (livesPanel.Width - labelSize.Width) / 2f, livesPanel.Y + 12f);
            }
            DrawLivesHearts(g, livesPanel);
        }

        private void DrawHudPanel(Graphics g, RectangleF rect)
        {
            using (var path = RoundedRect(rect, 10f))
            {
                using (var fillBrush = new SolidBrush(PanelFill))
                {
                    g.FillPath(fillBrush, path);
                }
                using (var borderPen = new Pen(PanelBorder, 2f))
                {
                    g.DrawPath(borderPen, path);
                }
            }
        }

        private void DrawTitleLogo(Graphics g, RectangleF panel)
        {
            string line1 = "BREAKOUT";
            string line2 = "REBORN";

            using (var path1 = new GraphicsPath())
            {
                SizeF size1 = g.MeasureString(line1, titleFontBig);
                float x1 = panel.X + (panel.Width - size1.Width) / 2f;
                float y1 = panel.Y + 6f;

                path1.AddString(line1, titleFontBig.FontFamily, (int)FontStyle.Bold, titleFontBig.Size,
                    new PointF(x1, y1), StringFormat.GenericDefault);

                using (var fillBrush = new LinearGradientBrush(
                           panel, Color.FromArgb(255, 235, 60), Color.FromArgb(255, 110, 20), LinearGradientMode.Vertical))
                {
                    g.FillPath(fillBrush, path1);
                }
                using (var outlinePen = new Pen(Color.FromArgb(140, 60, 10), 1.3f))
                {
                    g.DrawPath(outlinePen, path1);
                }
            }

            using (var path2 = new GraphicsPath())
            {
                SizeF size2 = g.MeasureString(line2, titleFontSmall);
                float x2 = panel.X + (panel.Width - size2.Width) / 2f;
                float y2 = panel.Y + 50f;

                path2.AddString(line2, titleFontSmall.FontFamily, (int)FontStyle.Bold, titleFontSmall.Size,
                    new PointF(x2, y2), StringFormat.GenericDefault);

                using (var fillBrush = new SolidBrush(Color.FromArgb(255, 110, 210, 255)))
                {
                    g.FillPath(fillBrush, path2);
                }
            }

            // Короткие декоративные "усики" по бокам от REBORN, как на референсе
            using (var pen = new Pen(Color.FromArgb(180, 80, 180, 255), 2f))
            {
                float midY = panel.Y + 58f;
                g.DrawLine(pen, panel.X + panel.Width * 0.22f, midY, panel.X + panel.Width * 0.32f, midY);
                g.DrawLine(pen, panel.X + panel.Width * 0.68f, midY, panel.X + panel.Width * 0.78f, midY);
            }
        }

        private void DrawLivesHearts(Graphics g, RectangleF panel)
        {
            float heartSize = 20f;
            float gap = 4f;
            float totalWidth = lives * heartSize + Math.Max(0, lives - 1) * gap;
            float startX = panel.X + (panel.Width - totalWidth) / 2f;
            float y = panel.Y + 38f;

            using (Brush heartBrush = new SolidBrush(Color.FromArgb(230, 235, 60, 90)))
            {
                for (int i = 0; i < lives; i++)
                {
                    RectangleF bounds = new RectangleF(startX + i * (heartSize + gap), y, heartSize, heartSize);
                    DrawHeart(g, heartBrush, bounds);
                }
            }
        }

        private void DrawHeart(Graphics g, Brush brush, RectangleF bounds)
        {
            float w = bounds.Width;
            float h = bounds.Height;

            using (var path = new GraphicsPath())
            {
                path.AddEllipse(bounds.X, bounds.Y, w / 2f, h / 2f);
                path.AddEllipse(bounds.X + w / 2f, bounds.Y, w / 2f, h / 2f);

                PointF[] triangle =
                {
                    new PointF(bounds.X, bounds.Y + h / 4f),
                    new PointF(bounds.X + w, bounds.Y + h / 4f),
                    new PointF(bounds.X + w / 2f, bounds.Y + h)
                };
                path.AddPolygon(triangle);

                g.FillPath(brush, path);
            }
        }

        // ==========================================================
        //  Нижняя панель с копирайтом
        // ==========================================================
        private void DrawFooter(Graphics g)
        {
            RectangleF footerRect = new RectangleF(10, FooterTop, WindowWidth - 20, FooterBottom - FooterTop);
            DrawHudPanel(g, footerRect);

            using (Brush textBrush = new SolidBrush(Color.FromArgb(210, 200, 215, 235)))
            {
                SizeF textSize = g.MeasureString(CopyrightText, footerFont);
                g.DrawString(CopyrightText, footerFont, textBrush,
                    footerRect.X + (footerRect.Width - textSize.Width) / 2f,
                    footerRect.Y + (footerRect.Height - textSize.Height) / 2f);
            }
        }

        // ==========================================================
        //  Текстовые подсказки и оверлеи состояний
        // ==========================================================
        private void DrawCenteredHint(Graphics g, string text)
        {
            using (Brush brush = new SolidBrush(Color.FromArgb(220, 255, 255, 255)))
            {
                SizeF size = g.MeasureString(text, overlaySubFont);
                float x = PlayAreaLeft + (PlayAreaRight - PlayAreaLeft - size.Width) / 2f;
                float y = PaddleY - 40f;
                g.DrawString(text, overlaySubFont, brush, x, y);
            }
        }

        private void DrawOverlay(Graphics g, string title, string subtitle, Color titleColor)
        {
            RectangleF area = new RectangleF(PlayAreaLeft, PlayAreaTop, PlayAreaRight - PlayAreaLeft, PlayAreaBottom - PlayAreaTop);

            using (Brush dimBrush = new SolidBrush(Color.FromArgb(150, 0, 0, 0)))
            {
                g.FillRectangle(dimBrush, area);
            }

            using (Brush titleBrush = new SolidBrush(titleColor))
            using (Brush subBrush = new SolidBrush(Color.White))
            {
                SizeF titleSize = g.MeasureString(title, overlayTitleFont);
                SizeF subSize = g.MeasureString(subtitle, overlaySubFont);

                float centerX = area.X + area.Width / 2f;
                float centerY = area.Y + area.Height / 2f;

                g.DrawString(title, overlayTitleFont, titleBrush,
                    centerX - titleSize.Width / 2f, centerY - titleSize.Height);
                g.DrawString(subtitle, overlaySubFont, subBrush,
                    centerX - subSize.Width / 2f, centerY + 12f);
            }
        }
    }
}
