using System;
using System.Windows.Forms;

namespace NewBreakoutReborn
{
    // Точка входа в приложение
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new GameForm());
        }
    }
}
