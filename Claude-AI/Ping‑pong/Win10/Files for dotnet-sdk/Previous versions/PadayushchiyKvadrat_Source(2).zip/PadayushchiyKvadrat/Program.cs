using System;
using System.Windows.Forms;

namespace PadayushchiyKvadrat
{
    // Точка входа в приложение
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            // Настройка отображения для современных экранов (High DPI)
            Application.SetHighDpiMode(HighDpiMode.SystemAware);

            // Стандартные визуальные стили Windows и корректный рендеринг текста
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Запуск главного (и единственного) окна игры
            Application.Run(new GameForm());
        }
    }
}
