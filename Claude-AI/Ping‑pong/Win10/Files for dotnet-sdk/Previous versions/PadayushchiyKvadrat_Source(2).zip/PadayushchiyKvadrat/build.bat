@echo off
chcp 65001 >nul
echo ============================================
echo   Сборка игры "Падающий квадрат" (win-x64)
echo ============================================
echo.

dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true

echo.
if %ERRORLEVEL% EQU 0 (
    echo Сборка завершена успешно.
    echo Готовый файл ищите здесь:
    echo bin\Release\net8.0-windows\win-x64\publish\PadayushchiyKvadrat.exe
) else (
    echo Сборка завершилась с ошибкой. Проверьте, установлен ли .NET SDK.
)

echo.
pause
