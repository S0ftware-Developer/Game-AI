using System;
using System.Drawing;
using System.Windows.Forms;

namespace PadayushchiyKvadrat
{
    // Главное и единственное окно игры "Падающий квадрат"
    public class GameForm : Form
    {
        // ==========================================================
        //  Константы игрового поля
        // ==========================================================
        private const int FieldWidth = 900;
        private const int FieldHeight = 650;

        // ==========================================================
        //  Параметры ракетки
        // ==========================================================
        private const int PaddleWidth = 90;
        private const int PaddleHeight = 12;
        private const int PaddleBottomMargin = 30; // отступ ракетки от нижнего края
        private const float PaddleSpeed = 8.0f;    // пикселей за один тик таймера

        private float paddleX;
        private int paddleY;

        // ==========================================================
        //  Параметры мяча (рисуется как круг; хитбокс — квадратная область)
        // ==========================================================
        private const int BallWidth = 14;
        private const int BallHeight = 14;
        private const float BallBaseSpeed = 5.0f;   // начальная скорость по вертикали
        private const float BallMaxSpeed = 11.0f;   // предельная скорость мяча
        private const float BallSpeedGrowth = 1.03f; // рост скорости за удачный удар

        private float ballX;
        private float ballY;
        private float prevBallY; // положение мяча в предыдущем кадре (защита от "проваливания")
        private float ballVX;
        private float ballVY;

        // ==========================================================
        //  Состояние игры
        // ==========================================================
        private int score;
        private bool isGameOver;

        // Флаги нажатых клавиш управления
        private bool leftPressed;
        private bool rightPressed;

        // Игровой таймер (~60 кадров в секунду)
        // Указан полный путь к типу, т.к. ImplicitUsings подключает и System.Threading,
        // где тоже есть класс Timer — без уточнения компилятор не может выбрать нужный.
        private readonly System.Windows.Forms.Timer gameTimer;

        // Шрифты для отрисовки текста
        private readonly Font scoreFont;
        private readonly Font titleFont;
        private readonly Font subtitleFont;
        private readonly Font copyrightFont;

        // Текст авторства, отображаемый внизу игрового окна
        private const string CopyrightText = "© 2026 [Орлов Андрей (совместно с Claude AI)]. Сайт: orlovandrei.space. Все права защищены.";

        public GameForm()
        {
            // --- Настройка окна ---
            this.Text = "Падающий квадрат";
            this.ClientSize = new Size(FieldWidth, FieldHeight);
            this.FormBorderStyle = FormBorderStyle.FixedSingle; // окно не изменяет размер
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Black;
            this.KeyPreview = true; // форма получает события клавиатуры раньше дочерних элементов

            // Включаем двойную буферизацию, чтобы отрисовка не мерцала
            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer,
                true);

            // --- Шрифты ---
            scoreFont = new Font("Consolas", 16f, FontStyle.Bold);
            titleFont = new Font("Consolas", 28f, FontStyle.Bold);
            subtitleFont = new Font("Consolas", 16f, FontStyle.Regular);
            copyrightFont = new Font("Consolas", 10f, FontStyle.Regular);

            // --- Подписка на события ---
            this.KeyDown += GameForm_KeyDown;
            this.KeyUp += GameForm_KeyUp;
            this.Paint += GameForm_Paint;

            // --- Игровой таймер ---
            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 16; // примерно 60 кадров в секунду
            gameTimer.Tick += GameTimer_Tick;

            // --- Инициализация состояния игры ---
            InitializeGame();

            gameTimer.Start();
        }

        // ==========================================================
        //  Запуск / перезапуск игры
        // ==========================================================
        private void InitializeGame()
        {
            // Ракетка по центру снизу
            paddleX = (FieldWidth - PaddleWidth) / 2f;
            paddleY = FieldHeight - PaddleHeight - PaddleBottomMargin;

            // Мяч над ракеткой, по центру, летит вниз
            ballX = (FieldWidth - BallWidth) / 2f;
            ballY = paddleY - 200f;
            if (ballY < 0f)
            {
                ballY = 10f;
            }
            prevBallY = ballY;

            ballVX = 0f;
            ballVY = BallBaseSpeed;

            score = 0;
            isGameOver = false;

            leftPressed = false;
            rightPressed = false;
        }

        private void RestartGame()
        {
            InitializeGame();
        }

        // ==========================================================
        //  Обработка нажатия и отпускания клавиш
        // ==========================================================
        private void GameForm_KeyDown(object? sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.A:
                    leftPressed = true;
                    break;

                case Keys.Right:
                case Keys.D:
                    rightPressed = true;
                    break;

                case Keys.R:
                    if (isGameOver)
                    {
                        RestartGame();
                    }
                    break;

                case Keys.Escape:
                    this.Close();
                    break;
            }

            // Отключаем стандартную обработку стрелок (перемещение фокуса и т.п.)
            e.Handled = true;
            e.SuppressKeyPress = true;
        }

        private void GameForm_KeyUp(object? sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.A:
                    leftPressed = false;
                    break;

                case Keys.Right:
                case Keys.D:
                    rightPressed = false;
                    break;
            }
        }

        // ==========================================================
        //  Главный игровой цикл (тик таймера)
        // ==========================================================
        private void GameTimer_Tick(object? sender, EventArgs e)
        {
            if (!isGameOver)
            {
                UpdateGame();
            }

            // Перерисовываем окно на каждом тике
            this.Invalidate();
        }

        // ==========================================================
        //  Обновление игровой логики за один кадр
        // ==========================================================
        private void UpdateGame()
        {
            HandleInput();
            MoveBall();
            CheckCollisions();
        }

        // --- Обработка ввода: перемещение ракетки ---
        private void HandleInput()
        {
            if (leftPressed)
            {
                paddleX -= PaddleSpeed;
            }
            if (rightPressed)
            {
                paddleX += PaddleSpeed;
            }

            // Ограничение ракетки границами окна
            if (paddleX < 0f)
            {
                paddleX = 0f;
            }
            if (paddleX + PaddleWidth > FieldWidth)
            {
                paddleX = FieldWidth - PaddleWidth;
            }
        }

        // --- Перемещение мяча ---
        private void MoveBall()
        {
            prevBallY = ballY;
            ballX += ballVX;
            ballY += ballVY;
        }

        // ==========================================================
        //  Обработка столкновений мяча со стенами и ракеткой
        // ==========================================================
        private void CheckCollisions()
        {
            // --- Столкновение с левой стенкой ---
            if (ballX <= 0f)
            {
                ballX = 0f;
                ballVX = -ballVX;
            }

            // --- Столкновение с правой стенкой ---
            if (ballX + BallWidth >= FieldWidth)
            {
                ballX = FieldWidth - BallWidth;
                ballVX = -ballVX;
            }

            // --- Столкновение с верхней стенкой ---
            if (ballY <= 0f)
            {
                ballY = 0f;
                ballVY = -ballVY;
            }

            // --- Столкновение с ракеткой ---
            float ballBottomPrev = prevBallY + BallHeight;
            float ballBottomNow = ballY + BallHeight;

            bool horizontallyOverPaddle =
                (ballX + BallWidth >= paddleX) &&
                (ballX <= paddleX + PaddleWidth);

            // Проверяем пересечение верхней грани ракетки за этот кадр
            // (защита от "проваливания" мяча сквозь ракетку при большой скорости)
            bool crossedPaddleTop =
                ballVY > 0f &&
                ballBottomPrev <= paddleY &&
                ballBottomNow >= paddleY;

            if (crossedPaddleTop && horizontallyOverPaddle)
            {
                // Прижимаем мяч точно к верхней грани ракетки, чтобы он не залипал внутри
                ballY = paddleY - BallHeight;

                // Точка попадания относительно центра ракетки: от -1 (левый край) до 1 (правый край)
                float paddleCenter = paddleX + PaddleWidth / 2f;
                float ballCenter = ballX + BallWidth / 2f;
                float hitOffset = (ballCenter - paddleCenter) / (PaddleWidth / 2f);

                if (hitOffset < -1f) hitOffset = -1f;
                if (hitOffset > 1f) hitOffset = 1f;

                // Увеличиваем скорость мяча после удачного отражения, но не выше предела
                float currentSpeed = (float)Math.Sqrt(ballVX * ballVX + ballVY * ballVY);
                float newSpeed = Math.Min(currentSpeed * BallSpeedGrowth, BallMaxSpeed);

                // Максимальная доля скорости, уходящая в горизонтальную составляющую
                const float maxHorizontalRatio = 0.8f;

                float newVX = newSpeed * maxHorizontalRatio * hitOffset;
                float newVYSquared = newSpeed * newSpeed - newVX * newVX;
                float minVYSquared = newSpeed * newSpeed * 0.2f;
                float newVY = -(float)Math.Sqrt(Math.Max(newVYSquared, minVYSquared));

                ballVX = newVX;
                ballVY = newVY; // отрицательное значение — мяч летит вверх

                score++;
            }

            // --- Мяч улетел ниже нижней границы окна — проигрыш ---
            if (ballY > FieldHeight)
            {
                isGameOver = true;
            }
        }

        // ==========================================================
        //  Отрисовка игры
        // ==========================================================
        private void GameForm_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // Чёрный фон (на случай перерисовки отдельных областей)
            g.Clear(Color.Black);

            using (Brush whiteBrush = new SolidBrush(Color.White))
            {
                // Ракетка
                g.FillRectangle(whiteBrush, paddleX, paddleY, PaddleWidth, PaddleHeight);

                // Мяч (круг)
                g.FillEllipse(whiteBrush, ballX, ballY, BallWidth, BallHeight);

                // Счёт в верхней части окна
                g.DrawString($"Очки: {score}", scoreFont, whiteBrush, 15f, 15f);

                // Строка авторства внизу окна
                SizeF copyrightSize = g.MeasureString(CopyrightText, copyrightFont);
                g.DrawString(
                    CopyrightText,
                    copyrightFont,
                    whiteBrush,
                    (FieldWidth - copyrightSize.Width) / 2f,
                    FieldHeight - copyrightSize.Height - 8f);

                // Экран окончания игры
                if (isGameOver)
                {
                    DrawCenteredGameOverText(g, whiteBrush);
                }
            }
        }

        // --- Отрисовка текста экрана "Игра окончена" ---
        private void DrawCenteredGameOverText(Graphics g, Brush brush)
        {
            string title = "Игра окончена";
            string scoreLine = $"Счёт: {score}";
            string restartLine = "Нажмите R для новой игры";

            SizeF titleSize = g.MeasureString(title, titleFont);
            SizeF scoreSize = g.MeasureString(scoreLine, subtitleFont);
            SizeF restartSize = g.MeasureString(restartLine, subtitleFont);

            float centerX = FieldWidth / 2f;
            float centerY = FieldHeight / 2f;

            float titleY = centerY - titleSize.Height - 10f;
            float scoreY = centerY + 10f;
            float restartY = scoreY + scoreSize.Height + 10f;

            g.DrawString(title, titleFont, brush, centerX - titleSize.Width / 2f, titleY);
            g.DrawString(scoreLine, subtitleFont, brush, centerX - scoreSize.Width / 2f, scoreY);
            g.DrawString(restartLine, subtitleFont, brush, centerX - restartSize.Width / 2f, restartY);
        }

        // ==========================================================
        //  Освобождение ресурсов при закрытии формы
        // ==========================================================
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                gameTimer?.Stop();
                gameTimer?.Dispose();
                scoreFont?.Dispose();
                titleFont?.Dispose();
                subtitleFont?.Dispose();
                copyrightFont?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
