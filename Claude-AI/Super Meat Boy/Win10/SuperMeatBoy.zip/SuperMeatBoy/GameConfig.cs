namespace SuperMeatBoy;

/// <summary>All tunable numbers of the game in one place (pixels and seconds).</summary>
public static class GameConfig
{
    // ---- layout
    public const int LogicalW = 960;
    public const int LogicalH = 640;
    public const int FooterH = 32;
    public const int ViewH = LogicalH - FooterH;     // height of the game view: 608
    public const int Tile = 32;

    // ---- player body
    public const float PlayerW = 22f;
    public const float PlayerH = 26f;

    // ---- horizontal movement
    public const float RunSpeed = 260f;
    public const float GroundAccel = 2400f;
    public const float GroundDecel = 2800f;
    public const float AirAccel = 1600f;
    public const float AirDecel = 450f;

    // ---- vertical movement
    public const float GravityRise = 2000f;
    public const float GravityFall = 2600f;
    public const float MaxFall = 900f;
    public const float WallSlideSpeed = 140f;
    public const float JumpSpeed = 700f;             // about 3.8 tiles when Space is held
    public const float JumpCutSpeed = 300f;          // releasing Space early caps the upward speed

    // ---- wall jump
    public const float WallJumpSpeedX = 300f;
    public const float WallJumpSpeedY = 660f;
    public const float WallJumpLock = 0.10f;         // short time with no steering back into the wall

    // ---- input forgiveness
    public const float CoyoteTime = 0.10f;
    public const float WallCoyoteTime = 0.08f;
    public const float JumpBufferTime = 0.12f;

    // ---- death and respawn
    public const float DeathDelay = 0.28f;
    public const float SpawnPopTime = 0.22f;

    public const string LevelName = "THE MEAT GRINDER";
}
