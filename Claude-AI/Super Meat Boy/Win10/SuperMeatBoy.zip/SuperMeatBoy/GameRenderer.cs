using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace SuperMeatBoy;

/// <summary>
/// GDI+ renderer. Backgrounds, brick textures and the vignette are pre-rendered once; the level, hazards, flags,
/// the meat boy and the effects are drawn live through a camera transform. All coordinates are logical 960x640.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    public static readonly Rectangle PlayButton = new Rectangle(330, 472, 300, 54);
    public static readonly Rectangle ResumeButton = new Rectangle(360, 250, 240, 46);
    public static readonly Rectangle PauseRestartButton = new Rectangle(360, 306, 240, 46);
    public static readonly Rectangle PauseMenuButton = new Rectangle(360, 362, 240, 46);
    public static readonly Rectangle CompleteRestartButton = new Rectangle(255, 440, 210, 52);
    public static readonly Rectangle CompleteMenuButton = new Rectangle(495, 440, 210, 52);

    private const int W = GameConfig.LogicalW;
    private const int ViewH = GameConfig.ViewH;
    private const int T = GameConfig.Tile;

    private static readonly Color Red = Color.FromArgb(255, 204, 26, 28);
    private static readonly Color RedDark = Color.FromArgb(255, 120, 12, 16);
    private static readonly Color Ink = Color.FromArgb(255, 14, 12, 18);

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fHud;
    private readonly Font fLabel;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fBig;
    private readonly Font fFooter;
    private readonly Font fTitle;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;
    private readonly StringFormat sfRight;
    private readonly Bitmap bgGame;
    private readonly Bitmap farBmp;
    private readonly Bitmap nearBmp;
    private readonly Bitmap vignette;
    private readonly Bitmap menuBg;
    private readonly Bitmap[] bricks = new Bitmap[4];
    private readonly LinearGradientBrush bodyBrush;
    private readonly GraphicsPath titleSuper;
    private readonly GraphicsPath titleMeat;
    private readonly PointF[] tri = new PointF[3];
    private readonly PointF[] teeth = new PointF[32];

    public GameRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;

        fHud = new Font("Segoe UI", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fLabel = new Font("Segoe UI", 12f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Segoe UI", 26f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Segoe UI", 18f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBig = new Font("Segoe UI", 50f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitle = new Font("Impact", 100f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;
        sfRight = new StringFormat();
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfRight.FormatFlags = StringFormatFlags.NoWrap;

        bgGame = MakeGameBackground();
        farBmp = MakeSkyline(1920, Color.FromArgb(255, 32, 38, 54), 330, 240, 11, true);
        nearBmp = MakeSkyline(1920, Color.FromArgb(255, 22, 26, 38), 470, 190, 29, false);
        vignette = MakeVignette();
        menuBg = MakeMenuBackground();
        for (int i = 0; i < bricks.Length; i++) bricks[i] = MakeBrick(i);
        bodyBrush = new LinearGradientBrush(new RectangleF(-13f, -27f, 26f, 26f), Color.FromArgb(255, 238, 70, 60), Color.FromArgb(255, 164, 14, 20), 90f);

        titleSuper = MakeTitlePath("SUPER", 74f, 380f, 92f, 0.22f);
        titleMeat = MakeTitlePath("MEAT BOY", 118f, 480f, 198f, 0.0f);
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fHud.Dispose();
        fLabel.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fBig.Dispose();
        fFooter.Dispose();
        fTitle.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        sfRight.Dispose();
        bgGame.Dispose();
        farBmp.Dispose();
        nearBmp.Dispose();
        vignette.Dispose();
        menuBg.Dispose();
        foreach (Bitmap b in bricks) b.Dispose();
        bodyBrush.Dispose();
        titleSuper.Dispose();
        titleMeat.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private static int Hash(int c)
    {
        unchecked
        {
            int h = c * 374761393;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow) g.DrawString(s, f, B(Color.FromArgb(Math.Min((int)c.A, 210), 0, 0, 0)), x + 2f, y + 2f, sf);
        g.DrawString(s, f, B(c), x, y, sf);
    }

    private static GraphicsPath RoundRect(float x, float y, float w, float h, float r)
    {
        GraphicsPath p = new GraphicsPath();
        float d = r * 2f;
        p.AddArc(x, y, d, d, 180f, 90f);
        p.AddArc(x + w - d, y, d, d, 270f, 90f);
        p.AddArc(x + w - d, y + h - d, d, d, 0f, 90f);
        p.AddArc(x, y + h - d, d, d, 90f, 90f);
        p.CloseFigure();
        return p;
    }

    private void Button(Graphics g, Rectangle r, string text, bool primary, float clock)
    {
        using (GraphicsPath p = RoundRect(r.X, r.Y, r.Width, r.Height, 8f))
        {
            g.FillPath(B(primary ? Color.FromArgb(255, 16, 12, 16) : Color.FromArgb(255, 34, 30, 40)), p);
            float k = primary ? 0.5f + 0.5f * MathF.Sin(clock * 4f) : 1f;
            g.DrawPath(P(Color.FromArgb(A(170 + 85 * k), 230, 36, 36), 3.5f), p);
        }
        Txt(g, text, fText, Color.White, r.X + r.Width / 2f, r.Y + r.Height / 2f, sfCenter, true);
    }

    private void DrawLayer(Graphics g, Bitmap bmp, double offset)
    {
        int w = bmp.Width;
        float x = -(float)(((offset % w) + w) % w);
        while (x < W)
        {
            g.DrawImageUnscaled(bmp, (int)x, 0);
            x += w;
        }
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)GameConfig.LogicalW, clientH / (float)GameConfig.LogicalH);
        float offX = (clientW - GameConfig.LogicalW * scale) / 2f;
        float offY = (clientH - GameConfig.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, GameConfig.LogicalW, GameConfig.LogicalH));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (e.State == GameState.Menu) DrawMenu(g, e);
            else
            {
                DrawGame(g, e);
                if (e.State == GameState.Paused) DrawPause(g, e);
                else if (e.State == GameState.Complete) DrawComplete(g, e);
            }
            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ game

    private void DrawGame(Graphics g, GameEngine e)
    {
        Level lv = e.Level;
        float shx = 0f;
        float shy = 0f;
        if (e.Camera.Shake > 0f)
        {
            shx = MathF.Sin(e.Clock * 140f) * e.Camera.Shake * 40f;
            shy = MathF.Cos(e.Clock * 120f) * e.Camera.Shake * 30f;
        }
        int camX = (int)Math.Round(e.Camera.X + shx);
        int camY = (int)Math.Round(e.Camera.Y + shy);

        GraphicsState outer = g.Save();
        g.SetClip(new Rectangle(0, 0, W, ViewH));
        g.DrawImageUnscaled(bgGame, 0, 0);
        DrawLayer(g, farBmp, e.Camera.X * 0.10);
        DrawLayer(g, nearBmp, e.Camera.X * 0.24);

        g.TranslateTransform(-camX, -camY);

        int c0 = Math.Max(0, camX / T - 1);
        int c1 = Math.Min(lv.Cols - 1, (camX + W) / T + 1);
        int r0 = Math.Max(0, camY / T - 1);
        int r1 = Math.Min(lv.Rows - 1, (camY + ViewH) / T + 1);

        for (int r = r0; r <= r1; r++)
        {
            for (int c = c0; c <= c1; c++)
            {
                if (lv.Solid[c, r]) DrawSolidTile(g, lv, c, r);
            }
        }

        foreach (Decal d in e.Decals)
        {
            if (d.X < camX - 10 || d.X > camX + W + 10 || d.Y < camY - 10 || d.Y > camY + ViewH + 10) continue;
            g.FillEllipse(B(Color.FromArgb(235, 176, 18, 22)), d.X - d.R, d.Y - d.R, d.R * 2f, d.R * 2f);
        }

        foreach (SpikeTile s in lv.Spikes)
        {
            if (s.Col < c0 - 1 || s.Col > c1 + 1 || s.Row < r0 - 1 || s.Row > r1 + 1) continue;
            DrawSpikeTile(g, s);
        }
        foreach (Saw s in lv.Saws)
        {
            if (s.X2 < camX - 60 && s.X1 < camX - 60) continue;
            if (s.X1 > camX + W + 60 && s.X2 > camX + W + 60) continue;
            DrawSaw(g, s);
        }
        foreach (SpikeBlock b in lv.Blocks)
        {
            if (b.X + b.W < camX - 40 || b.X - b.W > camX + W + 40) continue;
            DrawSpikeBlock(g, b);
        }
        foreach (Checkpoint cp in lv.Checkpoints) DrawCheckpoint(g, cp, e);
        DrawExit(g, lv, e);

        foreach (Particle p in e.Particles)
        {
            float k = p.Life / p.MaxLife;
            if (p.X < camX - 20 || p.X > camX + W + 20 || p.Y < camY - 20 || p.Y > camY + ViewH + 20) continue;
            if (p.Kind == 0)
            {
                g.FillEllipse(B(Color.FromArgb(A(255 * Math.Min(1f, k * 1.6f)), p.Color.R, p.Color.G, p.Color.B)), p.X - p.Size, p.Y - p.Size, p.Size * 2f, p.Size * 2f);
            }
            else if (p.Kind == 1)
            {
                float r = p.Size * (1.6f - k);
                g.FillEllipse(B(Color.FromArgb(A(150 * k), p.Color.R, p.Color.G, p.Color.B)), p.X - r, p.Y - r, r * 2f, r * 2f);
            }
            else
            {
                g.FillRectangle(B(Color.FromArgb(A(255 * k), p.Color.R, p.Color.G, p.Color.B)), p.X - p.Size / 2f, p.Y - p.Size / 2f, p.Size, p.Size);
            }
        }

        if (!e.Player.Dead) DrawMeat(g, e.Player, e.Clock);

        g.Restore(outer);

        g.DrawImageUnscaled(vignette, 0, 0);
        if (e.Flash > 0f) g.FillRectangle(B(Color.FromArgb(A(120 * e.Flash / 0.5f), 255, 255, 255)), 0, 0, W, ViewH);
        DrawHud(g, e);
    }

    private void DrawHud(Graphics g, GameEngine e)
    {
        using (GraphicsPath p = RoundRect(12f, 10f, 330f, 78f, 8f))
        {
            g.FillPath(B(Color.FromArgb(185, 10, 8, 12)), p);
            g.DrawPath(P(Color.FromArgb(255, 200, 28, 30), 2f), p);
        }
        Txt(g, e.Level.Name, fLabel, Color.FromArgb(255, 255, 120, 110), 26f, 24f, sfLeft, false);
        Txt(g, ScoreManager.FormatTime(e.PlayTime), fHud, Color.White, 26f, 52f, sfLeft, true);
        Txt(g, "СМЕРТЕЙ: " + e.Deaths, fText, Color.FromArgb(255, 255, 214, 210), 210f, 40f, sfLeft, true);
        Txt(g, "ФЛАГИ: " + e.ActiveCheckpoints + " / " + e.Level.Checkpoints.Count, fSmall, Color.FromArgb(255, 230, 230, 235), 210f, 68f, sfLeft, true);
        if (e.MessageTimer > 0f)
        {
            float a = Math.Min(1f, e.MessageTimer * 2f);
            Txt(g, e.Message, fMid, Color.FromArgb(A(255 * a), 255, 255, 255), W / 2f, 120f, sfCenter, true);
        }
    }

    private void DrawSolidTile(Graphics g, Level lv, int c, int r)
    {
        int x = c * T;
        int y = r * T;
        g.DrawImageUnscaled(bricks[Hash(c * 131 + r * 17) & 3], x, y);

        if (!lv.IsSolid(c, r - 1))
        {
            g.FillRectangle(B(Red), x, y, T, 5);
            g.FillRectangle(B(RedDark), x, y + 5, T, 1);
            for (int k = 0; k < 3; k++)
            {
                int h = Hash(c * 7 + k + r * 913);
                if (h % 3 != 0) continue;
                float dx = 3f + (h >> 4) % 22;
                float dh = 5f + (h >> 8) % 7;
                g.FillEllipse(B(Red), x + dx, y + 3f, 5f, dh);
            }
        }
        if (!lv.IsSolid(c - 1, r)) g.FillRectangle(B(Red), x, y, 4, T);
        if (!lv.IsSolid(c + 1, r)) g.FillRectangle(B(Red), x + T - 4, y, 4, T);
        if (!lv.IsSolid(c, r + 1)) g.FillRectangle(B(RedDark), x, y + T - 3, T, 3);
    }

    private void DrawSpikeTile(Graphics g, SpikeTile s)
    {
        float x = s.Col * T;
        float y = s.Row * T;
        GraphicsState st = g.Save();
        g.TranslateTransform(x + T / 2f, y + T / 2f);
        if (s.Dir == SpikeDir.Down) g.RotateTransform(180f);
        else if (s.Dir == SpikeDir.Left) g.RotateTransform(-90f);
        else if (s.Dir == SpikeDir.Right) g.RotateTransform(90f);
        g.TranslateTransform(-T / 2f, -T / 2f);
        for (int i = 0; i < 3; i++)
        {
            float x0 = i * 10.66f;
            tri[0] = new PointF(x0 + 0.8f, T);
            tri[1] = new PointF(x0 + 9.9f, T);
            tri[2] = new PointF(x0 + 5.35f, 6f);
            g.FillPolygon(B(Color.FromArgb(255, 150, 156, 172)), tri);
            tri[0] = new PointF(x0 + 0.8f, T);
            tri[1] = new PointF(x0 + 5.35f, T);
            tri[2] = new PointF(x0 + 5.35f, 6f);
            g.FillPolygon(B(Color.FromArgb(255, 238, 242, 250)), tri);
            tri[0] = new PointF(x0 + 0.8f, T);
            tri[1] = new PointF(x0 + 9.9f, T);
            tri[2] = new PointF(x0 + 5.35f, 6f);
            g.DrawPolygon(P(Ink, 1.6f), tri);
        }
        g.Restore(st);
    }

    private void DrawSaw(Graphics g, Saw s)
    {
        g.DrawLine(P(Color.FromArgb(255, 20, 18, 24), 7f), s.X1, s.Y1, s.X2, s.Y2);
        g.DrawLine(P(Color.FromArgb(255, 78, 80, 94), 2.5f), s.X1, s.Y1, s.X2, s.Y2);
        float r = Saw.Radius + 4f;
        int n = teeth.Length;
        for (int i = 0; i < n; i++)
        {
            float a = s.Angle + i * MathF.PI * 2f / n;
            float rad = (i % 2 == 0) ? r : r * 0.74f;
            teeth[i] = new PointF(s.X + MathF.Cos(a) * rad, s.Y + MathF.Sin(a) * rad);
        }
        g.FillPolygon(B(Color.FromArgb(255, 188, 194, 206)), teeth);
        g.DrawPolygon(P(Ink, 1.6f), teeth);
        g.FillEllipse(B(Color.FromArgb(255, 120, 126, 142)), s.X - r * 0.6f, s.Y - r * 0.6f, r * 1.2f, r * 1.2f);
        g.FillEllipse(B(Color.FromArgb(235, 176, 18, 22)), s.X - r * 0.35f, s.Y - r * 0.5f, r * 0.55f, r * 0.4f);
        g.FillEllipse(B(Ink), s.X - 3.5f, s.Y - 3.5f, 7f, 7f);
    }

    private void DrawSpikeBlock(Graphics g, SpikeBlock b)
    {
        RectangleF r = b.Rect;
        // spikes on all four sides
        for (float x = r.Left + 4f; x + 12f <= r.Right - 2f; x += 14f)
        {
            tri[0] = new PointF(x, r.Top);
            tri[1] = new PointF(x + 12f, r.Top);
            tri[2] = new PointF(x + 6f, r.Top - 8f);
            g.FillPolygon(B(Color.FromArgb(255, 214, 220, 232)), tri);
            tri[0] = new PointF(x, r.Bottom);
            tri[1] = new PointF(x + 12f, r.Bottom);
            tri[2] = new PointF(x + 6f, r.Bottom + 8f);
            g.FillPolygon(B(Color.FromArgb(255, 214, 220, 232)), tri);
        }
        for (float y = r.Top + 4f; y + 12f <= r.Bottom - 2f; y += 14f)
        {
            tri[0] = new PointF(r.Left, y);
            tri[1] = new PointF(r.Left, y + 12f);
            tri[2] = new PointF(r.Left - 8f, y + 6f);
            g.FillPolygon(B(Color.FromArgb(255, 214, 220, 232)), tri);
            tri[0] = new PointF(r.Right, y);
            tri[1] = new PointF(r.Right, y + 12f);
            tri[2] = new PointF(r.Right + 8f, y + 6f);
            g.FillPolygon(B(Color.FromArgb(255, 214, 220, 232)), tri);
        }
        g.FillRectangle(B(Color.FromArgb(255, 70, 76, 94)), r);
        g.FillRectangle(B(Color.FromArgb(255, 104, 112, 134)), r.X, r.Y, r.Width, 4f);
        g.FillRectangle(B(Color.FromArgb(255, 40, 44, 58)), r.X, r.Bottom - 4f, r.Width, 4f);
        g.DrawRectangle(P(Ink, 2.5f), r.X, r.Y, r.Width, r.Height);
        float cy = r.Y + r.Height / 2f;
        g.FillRectangle(B(Red), r.X + 6f, cy - 3f, r.Width - 12f, 6f);
        g.FillEllipse(B(Color.FromArgb(255, 235, 60, 56)), r.X + r.Width / 2f - 5f, cy - 5f, 10f, 10f);
    }

    private void DrawCheckpoint(Graphics g, Checkpoint cp, GameEngine e)
    {
        float x = cp.Col * T + T / 2f;
        float floor = (cp.Row + 1) * T;
        float time = e.PlayTime;
        float wave = MathF.Sin(e.Clock * 6f) * 3f;

        if (cp.Active)
        {
            float pulse = 0.6f + 0.4f * MathF.Sin(e.Clock * 4f);
            g.FillEllipse(B(Color.FromArgb(A(55 * pulse), 255, 70, 60)), x - 50f, floor - 100f, 100f, 100f);
            float age = time - cp.ActivatedAt;
            if (age >= 0f && age < 0.7f)
            {
                float rr = 20f + age * 120f;
                g.DrawEllipse(P(Color.FromArgb(A(220 * (1f - age / 0.7f)), 255, 220, 210), 3f), x - rr, floor - 46f - rr, rr * 2f, rr * 2f);
            }
        }
        g.FillRectangle(B(Color.FromArgb(255, 96, 98, 110)), x - 3f, floor - 62f, 6f, 62f);
        g.FillRectangle(B(Color.FromArgb(255, 60, 62, 72)), x - 10f, floor - 10f, 20f, 10f);
        g.DrawRectangle(P(Ink, 2f), x - 10f, floor - 10f, 20f, 10f);
        g.FillEllipse(B(Color.FromArgb(255, 150, 154, 168)), x - 5f, floor - 68f, 10f, 10f);

        PointF[] flag =
        {
            new PointF(x + 3f, floor - 60f), new PointF(x + 32f, floor - 56f + (cp.Active ? wave : 0f)),
            new PointF(x + 34f, floor - 44f + (cp.Active ? wave : 0f)), new PointF(x + 3f, floor - 38f)
        };
        g.FillPolygon(B(cp.Active ? Color.FromArgb(255, 226, 34, 34) : Color.FromArgb(255, 112, 114, 124)), flag);
        g.DrawPolygon(P(Ink, 2f), flag);
        if (cp.Active)
        {
            g.FillEllipse(B(Color.White), x + 11f, floor - 54f + wave * 0.6f, 4f, 5f);
            g.FillEllipse(B(Color.White), x + 20f, floor - 53f + wave * 0.8f, 4f, 5f);
            g.DrawArc(P(Color.White, 1.8f), x + 11f, floor - 50f + wave * 0.7f, 13f, 7f, 10f, 160f);
        }
    }

    private void DrawExit(Graphics g, Level lv, GameEngine e)
    {
        float cx = lv.ExitCell.X * T + T / 2f;
        float floor = (lv.ExitCell.Y + 1) * T;
        float cy = floor - 32f;
        float clock = e.Clock;
        float pulse = 0.6f + 0.4f * MathF.Sin(clock * 3f);
        for (int i = 3; i >= 1; i--)
        {
            float rw = 16f + i * 12f;
            float rh = 26f + i * 18f;
            g.FillEllipse(B(Color.FromArgb(A(26 * pulse + 8), 120, 255, 220)), cx - rw, cy - rh, rw * 2f, rh * 2f);
        }
        g.FillEllipse(B(Color.FromArgb(255, 14, 40, 44)), cx - 18f, cy - 30f, 36f, 60f);
        g.FillEllipse(B(Color.FromArgb(255, 150, 255, 232)), cx - 12f, cy - 22f, 24f, 44f);
        g.FillEllipse(B(Color.White), cx - 6f, cy - 12f, 12f, 24f);
        for (int k = 0; k < 3; k++)
        {
            float start = clock * 170f + k * 120f;
            g.DrawArc(P(Color.FromArgb(255, 110, 255, 220), 3f), cx - 21f, cy - 33f, 42f, 66f, start, 75f);
        }
        g.FillRectangle(B(Color.FromArgb(255, 70, 74, 86)), cx - 22f, floor - 6f, 44f, 6f);
    }

    // ------------------------------------------------------------------ the meat boy

    private void DrawMeat(Graphics g, Player p, float clock)
    {
        float scaleIn = 1f;
        if (p.SpawnTimer > 0f)
        {
            float k = 1f - p.SpawnTimer / GameConfig.SpawnPopTime;
            scaleIn = 0.35f + 0.65f * k + 0.2f * MathF.Sin(k * MathF.PI);
        }
        DrawMeatBody(g, p.CenterX, p.Y + GameConfig.PlayerH, p.Facing, p.VX, p.VY, p.Grounded, p.WallDir, p.RunPhase, p.Squash, scaleIn, clock, false);
    }

    /// <summary>The meat boy drawn with the origin at the centre of his feet.</summary>
    private void DrawMeatBody(Graphics g, float fx, float fy, int facing, float vx, float vy, bool grounded, int wallDir,
        float runPhase, float squash, float scaleIn, float clock, bool grin)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(fx, fy + 1f);

        bool sliding = !grounded && wallDir != 0;
        float tilt = Math.Max(-1f, Math.Min(1f, vx / GameConfig.RunSpeed)) * 7f;
        if (sliding) tilt = wallDir * 10f;
        if (!grounded && !sliding) tilt += Math.Max(-1f, Math.Min(1f, vy / 700f)) * 4f * facing;
        g.RotateTransform(tilt);

        float sx = 1f + 0.22f * squash;
        float sy = 1f - 0.22f * squash;
        if (!grounded && !sliding)
        {
            if (vy < 0f) { sx = 0.93f; sy = 1.1f; }
            else { sx = 0.97f; sy = 1.05f; }
        }
        float bounce = grounded ? MathF.Abs(MathF.Sin(runPhase)) * Math.Min(1f, Math.Abs(vx) / GameConfig.RunSpeed) * 2.5f : 0f;
        g.TranslateTransform(0f, -bounce);
        g.ScaleTransform(facing * sx * scaleIn, sy * scaleIn);

        float s = MathF.Sin(runPhase);
        bool running = grounded && Math.Abs(vx) > 30f;

        // legs
        float l1 = running ? s * 3.5f : 0f;
        float l2 = running ? -s * 3.5f : 0f;
        if (!grounded && !sliding) { l1 = -2.5f; l2 = 2f; }
        g.FillEllipse(B(Color.FromArgb(255, 150, 14, 18)), -10f, -7f + Math.Max(0f, -l1), 8f, 8f);
        g.FillEllipse(B(Color.FromArgb(255, 150, 14, 18)), 2f, -7f + Math.Max(0f, -l2), 8f, 8f);

        // arms
        float armUp = sliding ? -9f : (!grounded ? -5f : (running ? s * 3f : 0f));
        g.FillEllipse(B(Color.FromArgb(255, 176, 18, 24)), -18f, -17f + armUp, 8f, 9f);
        g.FillEllipse(B(Color.FromArgb(255, 176, 18, 24)), 10f, -17f - armUp * 0.6f, 8f, 9f);

        // body
        using (GraphicsPath body = RoundRect(-13f, -27f, 26f, 26f, 8f))
        {
            g.FillPath(bodyBrush, body);
            g.DrawPath(P(Color.FromArgb(255, 70, 6, 10), 2.2f), body);
        }
        g.FillEllipse(B(Color.FromArgb(120, 255, 190, 170)), -9f, -24f, 8f, 5f);

        // face
        float look = Math.Max(-1f, Math.Min(1f, vx / GameConfig.RunSpeed)) * 1.5f + 1.5f;
        g.FillEllipse(B(Color.White), -10f, -22f, 8f, 10f);
        g.FillEllipse(B(Color.White), 2f, -22f, 8f, 10f);
        g.FillEllipse(B(Ink), -8f + look, -19f, 4.5f, 5.5f);
        g.FillEllipse(B(Ink), 4f + look, -19f, 4.5f, 5.5f);
        g.DrawLine(P(Color.FromArgb(255, 70, 6, 10), 2f), -12f, -25f, -3f, -22.5f);
        g.DrawLine(P(Color.FromArgb(255, 70, 6, 10), 2f), 12f, -25f, 3f, -22.5f);
        float mouthH = (!grounded || grin) ? 7f : 5f;
        using (GraphicsPath mouth = RoundRect(-7.5f, -10f, 15f, mouthH, 2.5f))
        {
            g.FillPath(B(Color.White), mouth);
            g.DrawPath(P(Ink, 1.6f), mouth);
        }
        g.DrawLine(P(Ink, 1f), -2.5f, -10f, -2.5f, -10f + mouthH);
        g.DrawLine(P(Ink, 1f), 2.5f, -10f, 2.5f, -10f + mouthH);

        g.Restore(st);
    }

    // ------------------------------------------------------------------ menu and overlays

    private void DrawMenu(Graphics g, GameEngine e)
    {
        float clock = e.Clock;
        g.DrawImageUnscaled(menuBg, 0, 0);

        // platforms with blood rims, spikes and a saw (like the title scene)
        using (SolidBrush rock = new SolidBrush(Color.FromArgb(255, 24, 24, 32)))
        {
            g.FillRectangle(rock, 0, 340, 270, 268);
            g.FillRectangle(rock, 690, 396, 270, 212);
            g.FillRectangle(rock, 270, 560, 420, 48);
        }
        g.FillRectangle(B(Red), 0, 336, 274, 8);
        g.FillRectangle(B(Red), 270, 336, 8, 224);
        g.FillRectangle(B(Red), 686, 392, 274, 8);
        g.FillRectangle(B(Red), 686, 392, 8, 168);
        g.FillRectangle(B(Red), 270, 556, 424, 8);
        for (int x = 280; x < 690; x += 32)
        {
            tri[0] = new PointF(x + 1f, 556f);
            tri[1] = new PointF(x + 31f, 556f);
            tri[2] = new PointF(x + 16f, 520f);
            g.FillPolygon(B(Color.FromArgb(255, 200, 206, 220)), tri);
            tri[0] = new PointF(x + 1f, 556f);
            tri[1] = new PointF(x + 16f, 556f);
            tri[2] = new PointF(x + 16f, 520f);
            g.FillPolygon(B(Color.FromArgb(255, 245, 248, 255)), tri);
            g.DrawPolygon(P(Ink, 1.6f), new PointF[] { new PointF(x + 1f, 556f), new PointF(x + 31f, 556f), new PointF(x + 16f, 520f) });
        }
        // spinning saw in the left wall
        float sawX = 270f;
        float sawY = 470f;
        int n = teeth.Length;
        for (int i = 0; i < n; i++)
        {
            float a = clock * 6f + i * MathF.PI * 2f / n;
            float rad = (i % 2 == 0) ? 40f : 30f;
            teeth[i] = new PointF(sawX + MathF.Cos(a) * rad, sawY + MathF.Sin(a) * rad);
        }
        g.FillPolygon(B(Color.FromArgb(255, 188, 194, 206)), teeth);
        g.DrawPolygon(P(Ink, 2f), teeth);
        g.FillEllipse(B(Color.FromArgb(255, 120, 126, 142)), sawX - 22f, sawY - 22f, 44f, 44f);
        g.FillEllipse(B(Ink), sawX - 6f, sawY - 6f, 12f, 12f);

        // flags
        DrawMenuFlag(g, 230f, 336f, clock, false);
        DrawMenuFlag(g, 730f, 392f, clock, true);

        // the hero
        float bob = MathF.Sin(clock * 2.6f) * 10f;
        for (int i = 0; i < 4; i++)
        {
            g.DrawLine(P(Color.FromArgb(A(200 - i * 45), 230, 36, 36), 3f), 372f - i * 8f, 392f + bob + i * 9f, 300f - i * 22f, 412f + bob + i * 11f);
        }
        GraphicsState hs = g.Save();
        g.TranslateTransform(470f, 430f + bob);
        g.ScaleTransform(2.6f, 2.6f);
        DrawMeatBody(g, 0f, 0f, 1, 220f, -120f, false, 0, clock * 9f, 0f, 1f, clock, true);
        g.Restore(hs);

        // title
        float splat = clock * 0.5f;
        for (int i = 0; i < 16; i++)
        {
            int h = Hash(i * 77);
            float sx = 250f + (h % 480);
            float sy = 50f + ((h >> 8) % 180);
            float rr = 4f + (h >> 4) % 9;
            g.FillEllipse(B(Color.FromArgb(220, 190, 20, 24)), sx, sy + MathF.Sin(splat + i) * 1.5f, rr, rr);
        }
        g.DrawPath(P(Ink, 16f), titleSuper);
        g.FillPath(B(Color.White), titleSuper);
        g.DrawPath(P(Ink, 18f), titleMeat);
        g.DrawPath(P(Color.FromArgb(255, 255, 80, 70), 4f), titleMeat);
        g.FillPath(B(Color.FromArgb(255, 222, 28, 28)), titleMeat);

        // subtitle on a brush stroke
        PointF[] stroke = { new PointF(250f, 286f), new PointF(718f, 276f), new PointF(730f, 314f), new PointF(262f, 322f) };
        g.FillPolygon(B(Color.FromArgb(240, 8, 6, 10)), stroke);
        Txt(g, "PRECISION CHALLENGE", fMid, Color.White, 490f, 300f, sfCenter, false);

        Button(g, PlayButton, "ИГРАТЬ  [ENTER]", true, clock);

        string best = e.Scores.HasResult
            ? "ЛУЧШЕЕ ВРЕМЯ: " + ScoreManager.FormatTime(e.Scores.BestTime) + "      ЛУЧШЕЕ ЧИСЛО СМЕРТЕЙ: " + e.Scores.BestDeaths
            : "Рекордов пока нет — пройдите уровень!";
        Txt(g, best, fText, Color.FromArgb(255, 255, 255, 255), W / 2f, 548f, sfCenter, true);
        Txt(g, "A / D или ← → — бег     ПРОБЕЛ — прыжок (держите — выше)     у стены ПРОБЕЛ — прыжок от стены", fSmall, Color.FromArgb(255, 240, 244, 255), W / 2f, 576f, sfCenter, true);
        Txt(g, "R — заново     Esc / P — пауза     N — звук     F11 — полный экран", fSmall, Color.FromArgb(255, 210, 220, 245), W / 2f, 596f, sfCenter, true);
    }

    private void DrawMenuFlag(Graphics g, float x, float floor, float clock, bool glow)
    {
        float wave = MathF.Sin(clock * 6f + x) * 3f;
        if (glow)
        {
            float pulse = 0.6f + 0.4f * MathF.Sin(clock * 4f);
            g.FillEllipse(B(Color.FromArgb(A(60 * pulse), 255, 255, 255)), x - 54f, floor - 120f, 108f, 108f);
        }
        g.FillRectangle(B(Color.FromArgb(255, 70, 72, 84)), x - 3f, floor - 70f, 6f, 70f);
        g.FillRectangle(B(Color.FromArgb(255, 50, 52, 62)), x - 11f, floor - 12f, 22f, 12f);
        PointF[] flag =
        {
            new PointF(x + 3f, floor - 68f), new PointF(x + 38f, floor - 62f + wave),
            new PointF(x + 40f, floor - 46f + wave), new PointF(x + 3f, floor - 40f)
        };
        g.FillPolygon(B(Color.FromArgb(255, 226, 34, 34)), flag);
        g.DrawPolygon(P(Ink, 2f), flag);
        g.FillEllipse(B(Color.White), x + 12f, floor - 58f + wave * 0.6f, 5f, 6f);
        g.FillEllipse(B(Color.White), x + 24f, floor - 57f + wave * 0.8f, 5f, 6f);
        g.DrawArc(P(Color.White, 2f), x + 12f, floor - 54f + wave * 0.7f, 16f, 8f, 10f, 160f);
    }

    private void DrawPause(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(175, 6, 4, 10)), 0, 0, W, ViewH);
        Txt(g, "ПАУЗА", fBig, Color.White, W / 2f, 196f, sfCenter, true);
        Button(g, ResumeButton, "ПРОДОЛЖИТЬ  [ESC]", true, e.Clock);
        Button(g, PauseRestartButton, "ЗАНОВО  [R]", false, e.Clock);
        Button(g, PauseMenuButton, "В МЕНЮ  [M]", false, e.Clock);
    }

    private void DrawComplete(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(185, 6, 4, 10)), 0, 0, W, ViewH);
        using (GraphicsPath p = RoundRect(200f, 90f, 560f, 420f, 12f))
        {
            g.FillPath(B(Color.FromArgb(245, 14, 12, 18)), p);
            g.DrawPath(P(Color.FromArgb(255, 220, 30, 30), 4f), p);
        }
        Txt(g, "LEVEL COMPLETED!", fBig, Color.FromArgb(255, 255, 70, 60), W / 2f, 150f, sfCenter, true);
        Txt(g, "ВРЕМЯ", fLabel, Color.FromArgb(255, 255, 150, 140), W / 2f, 212f, sfCenter, false);
        Txt(g, ScoreManager.FormatTime(e.FinalTime), fBig, Color.White, W / 2f, 250f, sfCenter, true);
        if (e.NewBestTime) Txt(g, "НОВЫЙ РЕКОРД ВРЕМЕНИ!", fText, Color.FromArgb(255, 255, 230, 90), W / 2f, 296f, sfCenter, true);
        Txt(g, "СМЕРТЕЙ: " + e.Deaths, fMid, Color.White, W / 2f, 336f, sfCenter, true);
        if (e.NewBestDeaths) Txt(g, "НОВЫЙ РЕКОРД ПО СМЕРТЯМ!", fText, Color.FromArgb(255, 255, 230, 90), W / 2f, 372f, sfCenter, true);
        Txt(g, "Лучшее время: " + ScoreManager.FormatTime(e.Scores.BestTime) + "     Меньше всего смертей: " + e.Scores.BestDeaths,
            fSmall, Color.FromArgb(255, 210, 220, 245), W / 2f, 408f, sfCenter, true);
        Button(g, CompleteRestartButton, "ЗАНОВО  [R]", true, e.Clock);
        Button(g, CompleteMenuButton, "В МЕНЮ  [M]", false, e.Clock);
    }

    private void DrawFooter(Graphics g)
    {
        Rectangle r = new Rectangle(0, GameConfig.LogicalH - GameConfig.FooterH, W, GameConfig.FooterH);
        g.FillRectangle(B(Color.FromArgb(255, 8, 6, 10)), r);
        g.FillRectangle(B(Red), 0, r.Y, W, 2);
        g.DrawString(FooterText, fFooter, B(Color.FromArgb(255, 230, 232, 240)),
            new RectangleF(0f, r.Y + 3f, W, r.Height - 3f), sfCenter);
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private GraphicsPath MakeTitlePath(string text, float size, float cx, float cy, float shear)
    {
        GraphicsPath path = new GraphicsPath();
        path.AddString(text, fTitle.FontFamily, (int)FontStyle.Regular, size, new PointF(0f, 0f), StringFormat.GenericTypographic);
        RectangleF b = path.GetBounds();
        using (Matrix m = new Matrix())
        {
            m.Translate(cx - (b.X + b.Width / 2f), cy - (b.Y + b.Height / 2f));
            path.Transform(m);
        }
        if (shear != 0f)
        {
            using (Matrix sh = new Matrix(1f, 0f, -shear, 1f, cy * shear, 0f))
            {
                path.Transform(sh);
            }
        }
        return path;
    }

    private static Bitmap MakeGameBackground()
    {
        Bitmap bmp = new Bitmap(W, ViewH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        using (LinearGradientBrush lg = new LinearGradientBrush(new Rectangle(0, 0, W, ViewH), Color.FromArgb(18, 20, 30), Color.FromArgb(58, 50, 62), 90f))
        {
            g.FillRectangle(lg, 0, 0, W, ViewH);
        }
        return bmp;
    }

    private static Bitmap MakeSkyline(int sw, Color color, int baseY, int maxH, int seed, bool lights)
    {
        Bitmap bmp = new Bitmap(sw, ViewH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        using (SolidBrush b = new SolidBrush(color))
        using (SolidBrush lit = new SolidBrush(Color.FromArgb(150, 255, 170, 70)))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(seed);
            int x = 0;
            while (x < sw)
            {
                int w = 50 + rnd.Next(90);
                int h = 60 + rnd.Next(maxH);
                g.FillRectangle(b, x, baseY - h, w, ViewH - (baseY - h));
                if (rnd.Next(3) == 0) g.FillRectangle(b, x + w / 2 - 6, baseY - h - 60 - rnd.Next(60), 12, 80);     // chimney
                if (lights)
                {
                    for (int wy = baseY - h + 12; wy < baseY - 10; wy += 22)
                    {
                        for (int wx = x + 8; wx < x + w - 12; wx += 18)
                        {
                            if (rnd.Next(7) == 0) g.FillRectangle(lit, wx, wy, 6, 9);
                        }
                    }
                }
                x += w - 4;
            }
        }
        return bmp;
    }

    private static Bitmap MakeVignette()
    {
        Bitmap bmp = new Bitmap(W, ViewH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            for (int i = 0; i < 14; i++)
            {
                int a = 7 + i * 3;
                using (SolidBrush b = new SolidBrush(Color.FromArgb(Math.Min(100, a), 4, 2, 8)))
                {
                    int e = (14 - i) * 7;
                    g.FillRectangle(b, 0, 0, e, ViewH);
                    g.FillRectangle(b, W - e, 0, e, ViewH);
                    g.FillRectangle(b, 0, 0, W, e / 2);
                    g.FillRectangle(b, 0, ViewH - e / 2, W, e / 2);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeMenuBackground()
    {
        Bitmap bmp = new Bitmap(W, GameConfig.LogicalH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush sky = new LinearGradientBrush(new Rectangle(0, 0, W, GameConfig.LogicalH), Color.FromArgb(104, 134, 204), Color.FromArgb(176, 196, 232), 90f))
            {
                g.FillRectangle(sky, 0, 0, W, GameConfig.LogicalH);
            }
            Random rnd = new Random(7);
            using (SolidBrush cloud = new SolidBrush(Color.FromArgb(120, 255, 255, 255)))
            using (SolidBrush ruin = new SolidBrush(Color.FromArgb(150, 96, 118, 168)))
            using (SolidBrush ruinNear = new SolidBrush(Color.FromArgb(190, 78, 98, 150)))
            {
                for (int i = 0; i < 8; i++)
                {
                    float x = rnd.Next(W);
                    float y = 60 + rnd.Next(220);
                    g.FillEllipse(cloud, x, y, 190, 36);
                    g.FillEllipse(cloud, x + 40, y - 14, 110, 40);
                }
                int px = 0;
                while (px < W)
                {
                    int w = 40 + rnd.Next(70);
                    int h = 80 + rnd.Next(210);
                    g.FillRectangle(ruin, px, 590 - h, w, h);
                    px += w - 6;
                }
                px = 20;
                while (px < W)
                {
                    int w = 50 + rnd.Next(80);
                    int h = 40 + rnd.Next(120);
                    g.FillRectangle(ruinNear, px, 600 - h, w, h);
                    px += w + 14;
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeBrick(int variant)
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color[] ramp =
        {
            Color.FromArgb(18, 18, 24), Color.FromArgb(34, 36, 46), Color.FromArgb(46, 48, 60), Color.FromArgb(62, 66, 80)
        };
        for (int y = 0; y < T; y++)
        {
            for (int x = 0; x < T; x++)
            {
                int row = y / 16;
                int ry = y % 16;
                int xx = x + ((row + variant) % 2) * 8;
                int bx = xx % 16;
                Color c;
                if (ry == 15 || bx == 15) c = ramp[0];
                else
                {
                    int lvl = ry == 0 ? 3 : (ry < 8 ? 2 : 1);
                    if (bx == 0) lvl = Math.Min(3, lvl + 1);
                    int n = Hash(x * 31 + y * 17 + variant * 1009) % 13;
                    if (n == 0) lvl = Math.Max(1, lvl - 1);
                    else if (n == 1) lvl = Math.Min(3, lvl + 1);
                    c = ramp[lvl];
                }
                bmp.SetPixel(x, y, c);
            }
        }
        return bmp;
    }
}
