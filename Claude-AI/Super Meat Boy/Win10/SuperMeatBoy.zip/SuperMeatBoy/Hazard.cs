namespace SuperMeatBoy;

public enum SpikeDir { Up, Down, Left, Right }

/// <summary>A spike tile. Up means the spikes point up (standing on a floor); Left/Right are wall-mounted.</summary>
public sealed class SpikeTile
{
    public readonly int Col;
    public readonly int Row;
    public readonly SpikeDir Dir;
    public readonly RectangleF Hitbox;

    public SpikeTile(int col, int row, SpikeDir dir)
    {
        Col = col;
        Row = row;
        Dir = dir;
        float x = col * GameConfig.Tile;
        float y = row * GameConfig.Tile;
        switch (dir)
        {
            case SpikeDir.Up: Hitbox = new RectangleF(x + 4f, y + 14f, 24f, 18f); break;
            case SpikeDir.Down: Hitbox = new RectangleF(x + 4f, y, 24f, 18f); break;
            case SpikeDir.Left: Hitbox = new RectangleF(x, y + 4f, 18f, 24f); break;
            default: Hitbox = new RectangleF(x + 14f, y + 4f, 18f, 24f); break;
        }
    }
}

/// <summary>A circular saw blade gliding back and forth along a straight rail at constant speed.</summary>
public sealed class Saw
{
    public const float Radius = 14f;

    public readonly float X1, Y1, X2, Y2;
    public float X;
    public float Y;
    public float Angle;
    private readonly float speed;
    private readonly float phase;
    private readonly float length;

    public Saw(float x1, float y1, float x2, float y2, float speed, float phase)
    {
        X1 = x1; Y1 = y1; X2 = x2; Y2 = y2;
        this.speed = speed;
        this.phase = phase;
        float dx = x2 - x1;
        float dy = y2 - y1;
        length = MathF.Sqrt(dx * dx + dy * dy);
        Update(0f);
    }

    public void Update(float time)
    {
        Angle = time * 12f;
        float u = (time * speed + phase * 2f * length) % (2f * length);
        float d = u < length ? u : 2f * length - u;
        float f = d / length;
        X = X1 + (X2 - X1) * f;
        Y = Y1 + (Y2 - Y1) * f;
    }

    public bool Hits(RectangleF box)
    {
        float nx = Math.Max(box.Left, Math.Min(X, box.Right));
        float ny = Math.Max(box.Top, Math.Min(Y, box.Bottom));
        float dx = X - nx;
        float dy = Y - ny;
        float r = Radius - 1f;
        return dx * dx + dy * dy <= r * r;
    }
}

/// <summary>A block covered in spikes that slides smoothly around a middle position (a crusher or a slider).</summary>
public sealed class SpikeBlock
{
    public readonly float W, H;
    public readonly float MidX, MidY, AmpX, AmpY, Period, Phase;
    public float X;      // current centre
    public float Y;

    public SpikeBlock(float w, float h, float midX, float midY, float ampX, float ampY, float period, float phase)
    {
        W = w; H = h; MidX = midX; MidY = midY; AmpX = ampX; AmpY = ampY; Period = period; Phase = phase;
        Update(0f);
    }

    public void Update(float time)
    {
        float s = MathF.Sin(2f * MathF.PI * (time / Period + Phase));
        X = MidX + AmpX * s;
        Y = MidY + AmpY * s;
    }

    public RectangleF Rect
    {
        get { return new RectangleF(X - W / 2f, Y - H / 2f, W, H); }
    }

    public bool Hits(RectangleF box)
    {
        RectangleF r = Rect;
        r.Inflate(-2f, -2f);
        return r.IntersectsWith(box);
    }
}
