namespace SuperMeatBoy;

/// <summary>A smooth follow camera clamped to the level. It keeps the player a little left of the centre.</summary>
public sealed class Camera
{
    public float X;
    public float Y;
    public float Shake;

    public void Snap(float targetCx, float targetCy, int facing, Level lv)
    {
        float tx, ty;
        Target(targetCx, targetCy, facing, lv, out tx, out ty);
        X = tx;
        Y = ty;
    }

    public void Update(float dt, float targetCx, float targetCy, int facing, Level lv)
    {
        float tx, ty;
        Target(targetCx, targetCy, facing, lv, out tx, out ty);
        float kx = 1f - MathF.Exp(-7f * dt);
        float ky = 1f - MathF.Exp(-5.5f * dt);
        X += (tx - X) * kx;
        Y += (ty - Y) * ky;
        if (Shake > 0f) Shake = Math.Max(0f, Shake - dt);
    }

    private static void Target(float cx, float cy, int facing, Level lv, out float tx, out float ty)
    {
        float x = cx - GameConfig.LogicalW * 0.42f + facing * 36f;
        float y = cy - GameConfig.ViewH * 0.55f;
        float maxX = Math.Max(0f, lv.PixelW - GameConfig.LogicalW);
        float maxY = Math.Max(0f, lv.PixelH - GameConfig.ViewH);
        tx = Math.Max(0f, Math.Min(maxX, x));
        ty = Math.Max(0f, Math.Min(maxY, y));
    }
}
