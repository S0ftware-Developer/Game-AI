namespace SuperMeatBoy;

/// <summary>Best completion time and best death count, saved in the user's application data folder.</summary>
public sealed class ScoreManager
{
    public float BestTime;       // seconds, 0 when there is no result yet
    public int BestDeaths = -1;  // -1 when there is no result yet

    private static string SavePath
    {
        get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SuperMeatBoy", "best.txt"); }
    }

    public bool HasResult { get { return BestTime > 0f; } }

    public void Load()
    {
        try
        {
            string path = SavePath;
            if (!File.Exists(path)) return;
            string[] parts = File.ReadAllText(path).Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length >= 2)
            {
                float t;
                int d;
                if (float.TryParse(parts[0], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out t) &&
                    int.TryParse(parts[1], out d))
                {
                    BestTime = Math.Max(0f, t);
                    BestDeaths = d;
                }
            }
        }
        catch (Exception)
        {
            // saving is optional
        }
    }

    public void Save()
    {
        try
        {
            string path = SavePath;
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            File.WriteAllText(path, BestTime.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) + " " + BestDeaths);
        }
        catch (Exception)
        {
        }
    }

    /// <summary>Stores a finished run. Returns which of the two records was beaten.</summary>
    public void Submit(float time, int deaths, out bool newTime, out bool newDeaths)
    {
        newTime = !HasResult || time < BestTime;
        newDeaths = BestDeaths < 0 || deaths < BestDeaths;
        if (newTime) BestTime = time;
        if (newDeaths) BestDeaths = deaths;
        Save();
    }

    public static string FormatTime(float seconds)
    {
        int total = (int)(seconds * 100f);
        int cs = total % 100;
        int s = (total / 100) % 60;
        int m = total / 6000;
        return m.ToString("D2") + ":" + s.ToString("D2") + "." + cs.ToString("D2");
    }
}
