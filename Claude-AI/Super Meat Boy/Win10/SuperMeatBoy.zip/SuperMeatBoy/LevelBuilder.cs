namespace SuperMeatBoy;

/// <summary>
/// Builds the one hand-designed level. All coordinates are tiles (32 px), x to the right, y downward.
/// The course has nine sections and four checkpoints; every jump keeps well inside what the movement allows
/// (a full jump is 3.8 tiles high and about 5 tiles long; the largest gap here is 4 tiles).
/// </summary>
public static class LevelBuilder
{
    public static Level Build()
    {
        Level lv = new Level(GameConfig.LevelName, 234, 53);
        int T = GameConfig.Tile;

        // ---- world boundaries
        lv.Block(0, 0, 233, 1);
        lv.Block(0, 0, 1, 52);
        lv.Block(231, 0, 233, 52);
        lv.Block(0, 50, 233, 52);

        // ---- section 1: first steps (a gap, a lone spike, a two-tile step) ------------------------------
        lv.Block(0, 40, 12, 49);                       // start platform
        lv.Block(13, 45, 15, 49);                      // spike pit, 3 tiles wide
        lv.SpikeRow(13, 15, 44, SpikeDir.Up);
        lv.Block(16, 40, 24, 49);
        lv.SpikeRow(20, 20, 39, SpikeDir.Up);          // single spike to hop over
        lv.Block(25, 38, 30, 49);                      // step up
        lv.Checkpoints.Add(new Checkpoint(28, 37));    // checkpoint 1

        // ---- section 2: narrow stepping stones over a spike pit ------------------------------------------
        lv.Block(31, 45, 51, 49);
        lv.SpikeRow(31, 51, 44, SpikeDir.Up);
        lv.Block(33, 38, 34, 39);
        lv.Block(38, 37, 39, 38);
        lv.Block(43, 36, 44, 37);
        lv.Block(48, 37, 49, 38);

        // ---- section 3: spike tunnel (floor spikes, ceiling spikes) --------------------------------------
        lv.Block(52, 38, 78, 49);
        lv.Block(56, 30, 76, 33);                      // ceiling, 4 tiles above the floor
        lv.SpikeRow(60, 60, 37, SpikeDir.Up);
        lv.SpikeRow(64, 65, 37, SpikeDir.Up);
        lv.SpikeRow(70, 73, 34, SpikeDir.Down);        // hanging spikes: walk under them, do not jump
        lv.SpikeRow(75, 75, 37, SpikeDir.Up);

        // ---- section 4: the first wall-jump shaft (3 tiles wide, 14 tiles high) --------------------------
        lv.Block(79, 10, 80, 36);                      // left wall (the entry is the one-tile gap at row 37)
        lv.Block(79, 38, 85, 49);                      // shaft floor
        lv.Block(84, 24, 85, 49);                      // right wall, its top is the exit platform
        lv.Block(86, 24, 128, 25);                     // thin platform leading on
        lv.Checkpoints.Add(new Checkpoint(89, 23));    // checkpoint 2

        // ---- section 5: the sawmill (three saws patrolling the platform) ---------------------------------
        lv.Block(86, 32, 128, 33);                     // pit floor under the platform
        lv.SpikeRow(86, 127, 31, SpikeDir.Up);
        float sawY = 24 * T - Saw.Radius;
        lv.Saws.Add(new Saw(98 * T, sawY, 104 * T, sawY, 90f, 0.0f));
        lv.Saws.Add(new Saw(108 * T, sawY, 114 * T, sawY, 100f, 0.3f));
        lv.Saws.Add(new Saw(118 * T, sawY, 124 * T, sawY, 110f, 0.6f));

        // ---- section 6: the narrow passage (a two-tile-high tunnel with spikes) --------------------------
        lv.Block(128, 24, 150, 25);
        lv.Block(128, 32, 150, 33);
        lv.SpikeRow(128, 149, 31, SpikeDir.Up);
        lv.Block(130, 16, 146, 21);                    // tunnel ceiling: free rows 22 and 23
        lv.SpikeRow(134, 134, 23, SpikeDir.Up);
        lv.SpikeRow(140, 140, 23, SpikeDir.Up);
        lv.SpikeRow(137, 137, 22, SpikeDir.Down);
        lv.SpikeRow(143, 143, 22, SpikeDir.Down);

        // ---- section 7: crushers (spike blocks that drop toward the floor and rise again) ----------------
        lv.Block(147, 24, 183, 25);
        lv.Block(147, 32, 183, 33);
        lv.SpikeRow(147, 175, 31, SpikeDir.Up);
        float crusherMid = 20.7f * T;
        float crusherAmp = 1.7f * T;
        lv.Blocks.Add(new SpikeBlock(2 * T, 2 * T, 154 * T, crusherMid, 0f, crusherAmp, 2.4f, 0.00f));
        lv.Blocks.Add(new SpikeBlock(2 * T, 2 * T, 161 * T, crusherMid, 0f, crusherAmp, 2.4f, 0.33f));
        lv.Blocks.Add(new SpikeBlock(2 * T, 2 * T, 168 * T, crusherMid, 0f, crusherAmp, 2.4f, 0.66f));
        lv.Checkpoints.Add(new Checkpoint(172, 23));   // checkpoint 3

        // ---- section 8: the second shaft, 4 tiles wide and 16 high, with wall-mounted spikes -------------
        lv.Block(176, 8, 177, 21);                     // left wall (rows 22 and 23 stay open as the doorway)
        lv.Block(182, 8, 183, 24);                     // right wall, its top is the next platform
        lv.WallSpike(182, 17, SpikeDir.Left);
        lv.WallSpike(182, 18, SpikeDir.Left);
        lv.WallSpike(182, 10, SpikeDir.Left);
        lv.WallSpike(182, 11, SpikeDir.Left);
        lv.WallSpike(177, 13, SpikeDir.Right);
        lv.WallSpike(177, 14, SpikeDir.Right);

        // ---- section 9: the high road (gaps, saws of spikes sliding on the last platform) ----------------
        lv.Block(182, 8, 192, 9);
        lv.Checkpoints.Add(new Checkpoint(187, 7));    // checkpoint 4
        lv.Block(184, 14, 229, 15);                    // spike floor under the whole stretch
        lv.SpikeRow(184, 229, 13, SpikeDir.Up);
        lv.Block(197, 8, 199, 9);
        lv.Block(203, 7, 205, 8);
        lv.Block(210, 6, 212, 7);
        lv.Block(214, 6, 230, 7);
        float slideY = 6 * T - T / 2f;
        lv.Blocks.Add(new SpikeBlock(2 * T, T, 219 * T, slideY, 2.5f * T, 0f, 3.0f, 0.0f));
        lv.Blocks.Add(new SpikeBlock(2 * T, T, 225 * T, slideY, 2.5f * T, 0f, 3.0f, 0.5f));

        // ---- start and exit -------------------------------------------------------------------------------
        lv.Spawn = new PointF(4 * T + (T - GameConfig.PlayerW) / 2f, 40 * T - GameConfig.PlayerH);
        lv.ExitCell = new Point(230, 5);

        lv.Validate();
        return lv;
    }
}
