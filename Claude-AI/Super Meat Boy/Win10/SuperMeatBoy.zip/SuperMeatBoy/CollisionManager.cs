namespace SuperMeatBoy;

/// <summary>Tile collisions for the player and the hazard tests (spikes, saws, spike blocks).</summary>
public static class CollisionManager
{
    private const float Eps = 0.01f;

    /// <summary>Moves the player by its velocity for one step, resolving collisions per axis. Returns true when it lands.</summary>
    public static bool Move(Player p, Level lv, float dt, out float impact)
    {
        float t = GameConfig.Tile;
        float w = GameConfig.PlayerW;
        float h = GameConfig.PlayerH;

        // horizontal
        p.X += p.VX * dt;
        int r0 = (int)Math.Floor(p.Y / t);
        int r1 = (int)Math.Floor((p.Y + h - Eps) / t);
        if (p.VX > 0f)
        {
            int c = (int)Math.Floor((p.X + w - Eps) / t);
            for (int r = r0; r <= r1; r++)
            {
                if (lv.IsSolid(c, r))
                {
                    p.X = c * t - w;
                    p.VX = 0f;
                    break;
                }
            }
        }
        else if (p.VX < 0f)
        {
            int c = (int)Math.Floor(p.X / t);
            for (int r = r0; r <= r1; r++)
            {
                if (lv.IsSolid(c, r))
                {
                    p.X = (c + 1) * t;
                    p.VX = 0f;
                    break;
                }
            }
        }

        // vertical
        impact = p.VY;
        bool landed = false;
        p.Y += p.VY * dt;
        int c0 = (int)Math.Floor(p.X / t);
        int c1 = (int)Math.Floor((p.X + w - Eps) / t);
        if (p.VY > 0f)
        {
            int r = (int)Math.Floor((p.Y + h - Eps) / t);
            for (int c = c0; c <= c1; c++)
            {
                if (lv.IsSolid(c, r))
                {
                    p.Y = r * t - h;
                    p.VY = 0f;
                    landed = true;
                    break;
                }
            }
        }
        else if (p.VY < 0f)
        {
            int r = (int)Math.Floor(p.Y / t);
            for (int c = c0; c <= c1; c++)
            {
                if (lv.IsSolid(c, r))
                {
                    p.Y = (r + 1) * t;
                    p.VY = 0f;
                    break;
                }
            }
        }
        return landed;
    }

    /// <summary>True when something solid is right under the feet.</summary>
    public static bool OnGround(Player p, Level lv)
    {
        float y = p.Y + GameConfig.PlayerH + 1f;
        return lv.IsSolidPx(p.X + 2f, y) || lv.IsSolidPx(p.X + GameConfig.PlayerW - 2f, y);
    }

    /// <summary>-1 when touching a wall on the left, +1 on the right, 0 otherwise.</summary>
    public static int WallContact(Player p, Level lv)
    {
        float yTop = p.Y + 4f;
        float yBottom = p.Y + GameConfig.PlayerH - 4f;
        bool left = lv.IsSolidPx(p.X - 1.5f, yTop) || lv.IsSolidPx(p.X - 1.5f, yBottom);
        bool right = lv.IsSolidPx(p.X + GameConfig.PlayerW + 1.5f, yTop) || lv.IsSolidPx(p.X + GameConfig.PlayerW + 1.5f, yBottom);
        if (left && right) return p.Facing;
        if (left) return -1;
        if (right) return 1;
        return 0;
    }

    /// <summary>True when the player touches any deadly thing.</summary>
    public static bool HitsHazard(Player p, Level lv)
    {
        RectangleF box = new RectangleF(p.X + 2f, p.Y + 2f, GameConfig.PlayerW - 4f, GameConfig.PlayerH - 4f);
        foreach (SpikeTile s in lv.Spikes)
        {
            if (s.Hitbox.Right < box.Left - 40f || s.Hitbox.Left > box.Right + 40f) continue;
            if (s.Hitbox.IntersectsWith(box)) return true;
        }
        foreach (Saw w in lv.Saws)
        {
            if (w.Hits(box)) return true;
        }
        foreach (SpikeBlock b in lv.Blocks)
        {
            if (b.Hits(box)) return true;
        }
        return false;
    }
}
