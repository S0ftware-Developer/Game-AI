namespace SuperMeatBoy;

/// <summary>The level: solid tiles, spikes, moving hazards, checkpoints, the start and the exit.</summary>
public sealed class Level
{
    public readonly string Name;
    public readonly int Cols;
    public readonly int Rows;
    public readonly bool[,] Solid;
    public readonly List<SpikeTile> Spikes = new List<SpikeTile>();
    public readonly List<Saw> Saws = new List<Saw>();
    public readonly List<SpikeBlock> Blocks = new List<SpikeBlock>();
    public readonly List<Checkpoint> Checkpoints = new List<Checkpoint>();
    public PointF Spawn;
    public Point ExitCell;

    public Level(string name, int cols, int rows)
    {
        Name = name;
        Cols = cols;
        Rows = rows;
        Solid = new bool[cols, rows];
    }

    public int PixelW { get { return Cols * GameConfig.Tile; } }
    public int PixelH { get { return Rows * GameConfig.Tile; } }

    public RectangleF ExitRect
    {
        get { return new RectangleF(ExitCell.X * GameConfig.Tile - 8f, (ExitCell.Y - 1) * GameConfig.Tile, GameConfig.Tile + 16f, GameConfig.Tile * 2f); }
    }

    public bool IsSolid(int c, int r)
    {
        if (c < 0 || c >= Cols || r < 0 || r >= Rows) return true;
        return Solid[c, r];
    }

    public bool IsSolidPx(float x, float y)
    {
        return IsSolid((int)Math.Floor(x / GameConfig.Tile), (int)Math.Floor(y / GameConfig.Tile));
    }

    // ---- construction helpers (used by LevelBuilder); all coordinates are in tiles and inclusive

    public void Block(int x0, int y0, int x1, int y1)
    {
        for (int r = y0; r <= y1; r++)
        {
            for (int c = x0; c <= x1; c++)
            {
                if (c >= 0 && c < Cols && r >= 0 && r < Rows) Solid[c, r] = true;
            }
        }
    }

    public void SpikeRow(int x0, int x1, int row, SpikeDir dir)
    {
        for (int c = x0; c <= x1; c++) Spikes.Add(new SpikeTile(c, row, dir));
    }

    /// <summary>A spike tile that replaces a wall tile (the spikes stick out of the wall).</summary>
    public void WallSpike(int col, int row, SpikeDir dir)
    {
        Solid[col, row] = false;
        Spikes.Add(new SpikeTile(col, row, dir));
    }

    public void UpdateHazards(float time)
    {
        foreach (Saw s in Saws) s.Update(time);
        foreach (SpikeBlock b in Blocks) b.Update(time);
    }

    /// <summary>Checks that the level is usable: a safe start with a floor, an exit and checkpoints on floors.</summary>
    public void Validate()
    {
        int sc = (int)Math.Floor((Spawn.X + GameConfig.PlayerW / 2f) / GameConfig.Tile);
        int sr = (int)Math.Floor((Spawn.Y + GameConfig.PlayerH - 1f) / GameConfig.Tile);
        if (IsSolid(sc, sr) || !IsSolid(sc, sr + 1))
            throw new InvalidDataException("The start position is blocked or has no floor.");
        if (IsSolid(ExitCell.X, ExitCell.Y) || !IsSolid(ExitCell.X, ExitCell.Y + 1))
            throw new InvalidDataException("The exit has no floor.");
        foreach (Checkpoint c in Checkpoints)
        {
            if (IsSolid(c.Col, c.Row) || !IsSolid(c.Col, c.Row + 1))
                throw new InvalidDataException("A checkpoint at " + c.Col + "," + c.Row + " has no floor.");
        }
    }
}
