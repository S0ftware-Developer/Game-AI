namespace SuperMeatBoy;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        try
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new GameForm());
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString(), "Super Meat Boy - критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
