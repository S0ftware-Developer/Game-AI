namespace SuperMeatBoy;

public struct PlayerInput
{
    public bool Left;
    public bool Right;
    public bool JumpHeld;
    public bool JumpPressed;     // true only on the step where a jump key went down
}

/// <summary>
/// The meat boy: acceleration and deceleration, variable-height jump, coyote time, jump buffering, air control,
/// wall slide and wall jump, all on a fixed time step.
/// </summary>
public sealed class Player
{
    public float X;          // top-left of the hitbox
    public float Y;
    public float VX;
    public float VY;
    public bool Grounded;
    public int WallDir;      // -1 wall on the left, +1 on the right
    public int Facing = 1;
    public bool Dead;
    public float DeadTime;
    public float SpawnTimer;
    public float RunPhase;
    public float AnimTime;
    public float Squash;

    public bool EvJump;
    public bool EvWallJump;
    public bool EvLand;
    public float EvLandSpeed;

    private float coyote;
    private float wallCoyote;
    private float buffer;
    private float lockTimer;
    private int lastWallDir;

    public float CenterX { get { return X + GameConfig.PlayerW / 2f; } }
    public float CenterY { get { return Y + GameConfig.PlayerH / 2f; } }

    public void Respawn(PointF pos)
    {
        X = pos.X;
        Y = pos.Y;
        VX = 0f;
        VY = 0f;
        Grounded = true;
        WallDir = 0;
        Dead = false;
        DeadTime = 0f;
        SpawnTimer = GameConfig.SpawnPopTime;
        coyote = 0f;
        wallCoyote = 0f;
        buffer = 0f;
        lockTimer = 0f;
        Squash = 0f;
    }

    private static float Approach(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    public void Update(float dt, PlayerInput inp, Level lv)
    {
        EvJump = false;
        EvWallJump = false;
        EvLand = false;
        AnimTime += dt;
        if (SpawnTimer > 0f) SpawnTimer = Math.Max(0f, SpawnTimer - dt);

        buffer = inp.JumpPressed ? GameConfig.JumpBufferTime : Math.Max(0f, buffer - dt);
        if (lockTimer > 0f) lockTimer = Math.Max(0f, lockTimer - dt);
        coyote = Grounded ? GameConfig.CoyoteTime : Math.Max(0f, coyote - dt);
        if (!Grounded && WallDir != 0)
        {
            wallCoyote = GameConfig.WallCoyoteTime;
            lastWallDir = WallDir;
        }
        else
        {
            wallCoyote = Math.Max(0f, wallCoyote - dt);
        }

        // ---- horizontal control
        int dir = (inp.Right ? 1 : 0) - (inp.Left ? 1 : 0);
        if (dir != 0 && lockTimer <= 0f) Facing = dir;
        if (lockTimer <= 0f)
        {
            float target = dir * GameConfig.RunSpeed;
            float accel;
            if (Grounded)
            {
                if (dir == 0) accel = GameConfig.GroundDecel;
                else if (VX != 0f && (VX > 0f) != (dir > 0)) accel = GameConfig.GroundDecel + GameConfig.GroundAccel;
                else accel = GameConfig.GroundAccel;
            }
            else
            {
                accel = dir == 0 ? GameConfig.AirDecel : GameConfig.AirAccel;
            }
            VX = Approach(VX, target, accel * dt);
        }

        // ---- jumping: a normal jump (with coyote time) or a wall jump
        if (buffer > 0f)
        {
            if (coyote > 0f)
            {
                VY = -GameConfig.JumpSpeed;
                Grounded = false;
                coyote = 0f;
                buffer = 0f;
                EvJump = true;
            }
            else if (wallCoyote > 0f)
            {
                VX = -lastWallDir * GameConfig.WallJumpSpeedX;
                VY = -GameConfig.WallJumpSpeedY;
                lockTimer = GameConfig.WallJumpLock;
                Facing = -lastWallDir;
                wallCoyote = 0f;
                buffer = 0f;
                EvWallJump = true;
            }
        }

        // variable jump height: letting go of the key cuts the rise
        if (VY < -GameConfig.JumpCutSpeed && !inp.JumpHeld) VY = -GameConfig.JumpCutSpeed;

        // ---- gravity and wall slide
        float g = VY < 0f ? GameConfig.GravityRise : GameConfig.GravityFall;
        VY += g * dt;
        if (VY > GameConfig.MaxFall) VY = GameConfig.MaxFall;
        bool pushingIntoWall = (WallDir < 0 && dir < 0) || (WallDir > 0 && dir > 0);
        if (!Grounded && pushingIntoWall && VY > GameConfig.WallSlideSpeed) VY = GameConfig.WallSlideSpeed;

        // ---- move and collide
        bool wasGrounded = Grounded;
        float impact;
        bool landed = CollisionManager.Move(this, lv, dt, out impact);
        Grounded = landed || (wasGrounded && VY >= 0f && CollisionManager.OnGround(this, lv));
        if (Grounded && VY > 0f) VY = 0f;
        WallDir = Grounded ? 0 : CollisionManager.WallContact(this, lv);

        if (landed && !wasGrounded && impact > 260f)
        {
            EvLand = true;
            EvLandSpeed = impact;
            Squash = Math.Min(1f, impact / 800f);
        }
        if (Grounded) RunPhase += Math.Abs(VX) * dt * 0.055f;
        Squash = Math.Max(0f, Squash - dt * 6f);
    }
}
