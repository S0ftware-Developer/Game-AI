namespace SuperMeatBoy;

public enum GameState { Menu, Playing, Paused, Complete }

public struct Particle
{
    public float X, Y, VX, VY, Gravity, Size;
    public float Life, MaxLife;
    public int Kind;                 // 0 blood, 1 dust, 2 spark
    public Color Color;
}

public struct Decal
{
    public float X, Y, R;
}

/// <summary>Game rules and the fixed-step simulation (1/120 s): movement, hazards, checkpoints, death and respawn.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;
    private const int MaxDecals = 900;

    public GameState State = GameState.Menu;
    public Level Level;
    public readonly Player Player = new Player();
    public readonly Camera Camera = new Camera();
    public readonly ScoreManager Scores = new ScoreManager();
    public readonly List<Particle> Particles = new List<Particle>();
    public readonly List<Decal> Decals = new List<Decal>();

    // input set by the window
    public bool Left;
    public bool Right;
    public bool JumpHeld;

    public float Clock;                  // keeps running for menu animations
    public float PlayTime;               // elapsed time of the run (stops while paused)
    public float HazardTime;             // drives the moving hazards
    public int Deaths;
    public int CheckpointIndex = -1;     // index of the last activated checkpoint, -1 for the start
    public float FinalTime;
    public bool NewBestTime;
    public bool NewBestDeaths;
    public string Message = "";
    public float MessageTimer;
    public float Flash;                  // short screen flash (checkpoint, exit)

    private readonly Random rng = new Random();
    private bool jumpPressed;
    private float deadTimer;
    private float dustTimer;

    public int ActiveCheckpoints
    {
        get
        {
            int n = 0;
            foreach (Checkpoint c in Level.Checkpoints)
            {
                if (c.Active) n++;
            }
            return n;
        }
    }

    public GameEngine()
    {
        Scores.Load();
        Level = LevelBuilder.Build();
        Player.Respawn(Level.Spawn);
        Camera.Snap(Player.CenterX, Player.CenterY, 1, Level);
    }

    // ------------------------------------------------------------------ flow

    /// <summary>Starts (or restarts) the run from the very beginning.</summary>
    public void StartRun()
    {
        Level = LevelBuilder.Build();
        Particles.Clear();
        Decals.Clear();
        PlayTime = 0f;
        HazardTime = 0f;
        Deaths = 0;
        CheckpointIndex = -1;
        NewBestTime = false;
        NewBestDeaths = false;
        Message = "";
        MessageTimer = 0f;
        Flash = 0f;
        deadTimer = 0f;
        jumpPressed = false;
        Level.UpdateHazards(0f);
        Player.Respawn(Level.Spawn);
        Camera.Snap(Player.CenterX, Player.CenterY, 1, Level);
        State = GameState.Playing;
        Sfx.Play(SfxId.Click);
    }

    public void Resume()
    {
        if (State != GameState.Paused) return;
        Sfx.Play(SfxId.Click);
        State = GameState.Playing;
    }

    public void Pause()
    {
        if (State != GameState.Playing) return;
        Left = false;
        Right = false;
        JumpHeld = false;
        Sfx.Play(SfxId.Click);
        State = GameState.Paused;
    }

    public void GoToMenu()
    {
        Left = false;
        Right = false;
        JumpHeld = false;
        Sfx.Play(SfxId.Click);
        State = GameState.Menu;
    }

    public void AutoPause()
    {
        Left = false;
        Right = false;
        JumpHeld = false;
        if (State == GameState.Playing) State = GameState.Paused;
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                if (State == GameState.Menu || State == GameState.Complete) StartRun();
                else if (State == GameState.Paused) Resume();
                break;
            case Keys.Space:
            case Keys.Up:
            case Keys.W:
                if (State == GameState.Playing) jumpPressed = true;
                else if (State == GameState.Menu && key == Keys.Space) StartRun();
                break;
            case Keys.Escape:
            case Keys.P:
                if (State == GameState.Playing) Pause();
                else if (State == GameState.Paused) Resume();
                else if (State == GameState.Complete && key == Keys.Escape) GoToMenu();
                break;
            case Keys.R:
                if (State == GameState.Playing || State == GameState.Paused || State == GameState.Complete) StartRun();
                break;
            case Keys.M:
                if (State == GameState.Paused || State == GameState.Complete) GoToMenu();
                break;
            case Keys.N:
                Sfx.SetMuted(!Sfx.Muted);
                break;
        }
    }

    // ------------------------------------------------------------------ simulation

    public void Update()
    {
        Clock += Dt;
        if (State == GameState.Menu || State == GameState.Paused) return;
        if (State == GameState.Complete)
        {
            UpdateParticles(Dt);
            if (Flash > 0f) Flash = Math.Max(0f, Flash - Dt);
            return;
        }

        PlayTime += Dt;
        HazardTime += Dt;
        if (MessageTimer > 0f) MessageTimer -= Dt;
        if (Flash > 0f) Flash = Math.Max(0f, Flash - Dt);
        Level.UpdateHazards(HazardTime);

        if (!Player.Dead) UpdatePlayer();
        else
        {
            deadTimer += Dt;
            Player.DeadTime += Dt;
            if (deadTimer >= GameConfig.DeathDelay) Respawn();
        }

        Camera.Update(Dt, Player.CenterX, Player.CenterY, Player.Facing, Level);
        UpdateParticles(Dt);
    }

    private void UpdatePlayer()
    {
        PlayerInput inp = new PlayerInput();
        inp.Left = Left;
        inp.Right = Right;
        inp.JumpHeld = JumpHeld;
        inp.JumpPressed = jumpPressed;
        jumpPressed = false;

        Player.Update(Dt, inp, Level);

        if (Player.EvJump)
        {
            Sfx.Play(SfxId.Jump);
            Dust(Player.CenterX, Player.Y + GameConfig.PlayerH, 5);
        }
        if (Player.EvWallJump)
        {
            Sfx.Play(SfxId.WallJump);
            float wx = Player.Facing > 0 ? Player.X : Player.X + GameConfig.PlayerW;
            for (int i = 0; i < 6; i++) Spark(wx, Player.CenterY, Color.FromArgb(255, 200, 190), 120f);
        }
        if (Player.EvLand)
        {
            Sfx.Play(SfxId.Land);
            Dust(Player.CenterX, Player.Y + GameConfig.PlayerH, Player.EvLandSpeed > 600f ? 10 : 6);
        }
        dustTimer -= Dt;
        if (Player.Grounded && Math.Abs(Player.VX) > 150f && dustTimer <= 0f)
        {
            dustTimer = 0.07f;
            Dust(Player.CenterX - Math.Sign(Player.VX) * 8f, Player.Y + GameConfig.PlayerH, 1);
        }

        // checkpoints
        RectangleF box = new RectangleF(Player.X, Player.Y, GameConfig.PlayerW, GameConfig.PlayerH);
        for (int i = 0; i < Level.Checkpoints.Count; i++)
        {
            Checkpoint c = Level.Checkpoints[i];
            if (c.Active || !c.Trigger.IntersectsWith(box)) continue;
            c.Active = true;
            c.ActivatedAt = PlayTime;
            CheckpointIndex = Math.Max(CheckpointIndex, i);
            Message = "КОНТРОЛЬНАЯ ТОЧКА " + (i + 1) + " / " + Level.Checkpoints.Count;
            MessageTimer = 2f;
            Flash = 0.25f;
            Sfx.Play(SfxId.Checkpoint);
            float fx = c.Col * GameConfig.Tile + GameConfig.Tile / 2f;
            float fy = (c.Row - 1) * GameConfig.Tile;
            for (int k = 0; k < 18; k++) Spark(fx, fy, (k % 2 == 0) ? Color.FromArgb(255, 80, 70) : Color.White, 220f);
        }

        // the exit
        if (Level.ExitRect.IntersectsWith(box))
        {
            Complete();
            return;
        }

        // deadly things and falling out of the world
        if (CollisionManager.HitsHazard(Player, Level) || Player.Y > Level.PixelH + 64f) Die();
    }

    private void Die()
    {
        Player.Dead = true;
        Player.DeadTime = 0f;
        deadTimer = 0f;
        Deaths++;
        Sfx.Play(SfxId.Death);
        Camera.Shake = 0.18f;
        float cx = Player.CenterX;
        float cy = Player.CenterY;
        for (int i = 0; i < 42; i++)
        {
            double a = rng.NextDouble() * Math.PI * 2.0;
            float sp = (float)(rng.NextDouble() * 420.0 + 60.0);
            Particle p = new Particle();
            p.X = cx;
            p.Y = cy;
            p.VX = (float)Math.Cos(a) * sp + Player.VX * 0.35f;
            p.VY = (float)Math.Sin(a) * sp - 120f + Player.VY * 0.2f;
            p.Gravity = 1500f;
            p.Size = 2.5f + (float)rng.NextDouble() * 4.5f;
            p.MaxLife = 0.9f;
            p.Life = p.MaxLife;
            p.Kind = 0;
            p.Color = (i % 3 == 0) ? Color.FromArgb(255, 60, 50) : Color.FromArgb(200, 20, 24);
            Particles.Add(p);
        }
    }

    private void Respawn()
    {
        PointF pos = CheckpointIndex >= 0 ? Level.Checkpoints[CheckpointIndex].RespawnPos : Level.Spawn;
        Player.Respawn(pos);
        jumpPressed = false;
        Sfx.Play(SfxId.Respawn);
        for (int i = 0; i < 8; i++) Spark(pos.X + GameConfig.PlayerW / 2f, pos.Y + GameConfig.PlayerH / 2f, Color.FromArgb(255, 170, 160), 140f);
    }

    private void Complete()
    {
        FinalTime = PlayTime;
        bool nt, nd;
        Scores.Submit(FinalTime, Deaths, out nt, out nd);
        NewBestTime = nt;
        NewBestDeaths = nd;
        Left = false;
        Right = false;
        JumpHeld = false;
        Flash = 0.5f;
        Sfx.Play(SfxId.Complete);
        float ex = Level.ExitCell.X * GameConfig.Tile + GameConfig.Tile / 2f;
        float ey = (Level.ExitCell.Y - 0.5f) * GameConfig.Tile;
        for (int i = 0; i < 50; i++) Spark(ex, ey, (i % 2 == 0) ? Color.FromArgb(120, 255, 220) : Color.White, 320f);
        State = GameState.Complete;
    }

    // ------------------------------------------------------------------ effects

    private void Dust(float x, float y, int count)
    {
        for (int i = 0; i < count; i++)
        {
            Particle p = new Particle();
            p.X = x + (float)(rng.NextDouble() * 10.0 - 5.0);
            p.Y = y - 2f;
            p.VX = (float)(rng.NextDouble() * 120.0 - 60.0);
            p.VY = -(float)(rng.NextDouble() * 50.0 + 10.0);
            p.Gravity = 80f;
            p.Size = 2f + (float)rng.NextDouble() * 2.5f;
            p.MaxLife = 0.3f + (float)rng.NextDouble() * 0.2f;
            p.Life = p.MaxLife;
            p.Kind = 1;
            p.Color = Color.FromArgb(200, 200, 205);
            Particles.Add(p);
        }
    }

    private void Spark(float x, float y, Color c, float speed)
    {
        double a = rng.NextDouble() * Math.PI * 2.0;
        float sp = (float)(rng.NextDouble() * 0.8 + 0.2) * speed;
        Particle p = new Particle();
        p.X = x;
        p.Y = y;
        p.VX = (float)Math.Cos(a) * sp;
        p.VY = (float)Math.Sin(a) * sp;
        p.Gravity = 300f;
        p.Size = 2f + (float)rng.NextDouble() * 3f;
        p.MaxLife = 0.35f + (float)rng.NextDouble() * 0.35f;
        p.Life = p.MaxLife;
        p.Kind = 2;
        p.Color = c;
        Particles.Add(p);
    }

    private void UpdateParticles(float dt)
    {
        for (int i = Particles.Count - 1; i >= 0; i--)
        {
            Particle p = Particles[i];
            p.Life -= dt;
            if (p.Life <= 0f)
            {
                Particles.RemoveAt(i);
                continue;
            }
            float px = p.X;
            float py = p.Y;
            p.VY += p.Gravity * dt;
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            if (p.Kind == 0 && Level.IsSolidPx(p.X, p.Y))
            {
                // blood that hits a wall or floor stays as a stain
                Decal d = new Decal();
                d.X = px;
                d.Y = py;
                d.R = 2f + (float)rng.NextDouble() * 3.5f;
                if (Decals.Count >= MaxDecals) Decals.RemoveRange(0, 100);
                Decals.Add(d);
                Particles.RemoveAt(i);
                continue;
            }
            Particles[i] = p;
        }
    }
}
