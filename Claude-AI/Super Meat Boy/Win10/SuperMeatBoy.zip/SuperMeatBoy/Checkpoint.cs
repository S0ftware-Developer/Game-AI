namespace SuperMeatBoy;

/// <summary>A flag. Touching it saves the respawn position.</summary>
public sealed class Checkpoint
{
    public readonly int Col;
    public readonly int Row;           // the cell the flag stands in (the floor is the row below)
    public bool Active;
    public float ActivatedAt;          // game time of activation, for the animation

    public Checkpoint(int col, int row)
    {
        Col = col;
        Row = row;
    }

    public RectangleF Trigger
    {
        get { return new RectangleF(Col * GameConfig.Tile - 6f, (Row - 1) * GameConfig.Tile, GameConfig.Tile + 12f, GameConfig.Tile * 2f); }
    }

    public PointF RespawnPos
    {
        get
        {
            return new PointF(Col * GameConfig.Tile + (GameConfig.Tile - GameConfig.PlayerW) / 2f,
                (Row + 1) * GameConfig.Tile - GameConfig.PlayerH);
        }
    }
}
