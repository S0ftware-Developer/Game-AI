using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace RTypeSpaceShooter;

/// <summary>
/// The parallax space battlefield: gradient sky, three nebula palettes that blend along the mission, three star layers,
/// planets, distant alien structures (industrial spires with turning gears, organic tendrils, the boss installation),
/// energy fields, drifting debris and dust. The solid walls (planet surface, industrial corridors, organic walls, the
/// boss lair) are drawn by <see cref="DrawTerrain"/> as vertical strips with style-specific details.
/// </summary>
public sealed class BackgroundRenderer : IDisposable
{
    private const int W = GameConfig.LogicalW;
    private const int ViewH = GameConfig.ViewH;
    private const int Strip = 12;
    private const int NebW = 1920;

    private struct Pal
    {
        public Color Base, Dark, Edge;
        public Pal(Color b, Color d, Color e) { Base = b; Dark = d; Edge = e; }
    }

    private static readonly Pal PalPlanet = new Pal(Color.FromArgb(255, 96, 68, 92), Color.FromArgb(255, 50, 34, 56), Color.FromArgb(255, 190, 130, 128));
    private static readonly Pal PalIndustrial = new Pal(Color.FromArgb(255, 60, 68, 90), Color.FromArgb(255, 30, 36, 54), Color.FromArgb(255, 150, 172, 206));
    private static readonly Pal PalOrganic = new Pal(Color.FromArgb(255, 100, 42, 74), Color.FromArgb(255, 56, 18, 42), Color.FromArgb(255, 214, 104, 134));
    private static readonly Pal PalLair = new Pal(Color.FromArgb(255, 46, 50, 66), Color.FromArgb(255, 20, 22, 32), Color.FromArgb(255, 204, 66, 66));

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Bitmap bgGrad;
    private readonly Bitmap[] nebula = new Bitmap[3];
    private readonly Bitmap[] planets = new Bitmap[3];
    private readonly Bitmap[] rocks = new Bitmap[4];
    private readonly ImageAttributes ia = new ImageAttributes();
    private readonly ColorMatrix cm = new ColorMatrix();
    private readonly float[] topT = new float[W / Strip + 3];
    private readonly float[] botT = new float[W / Strip + 3];
    private readonly float[] fAt = new float[W / Strip + 3];
    private readonly PointF[] curve = new PointF[6];
    private readonly PointF[] quad = new PointF[4];

    public BackgroundRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;
        bgGrad = MakeGradient();
        for (int i = 0; i < nebula.Length; i++) nebula[i] = MakeNebula(i);
        planets[0] = MakeEarth();
        planets[1] = MakeGasGiant();
        planets[2] = MakeMoon();
        for (int i = 0; i < rocks.Length; i++) rocks[i] = MakeRock(i);
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        ia.Dispose();
        bgGrad.Dispose();
        foreach (Bitmap b in nebula) b.Dispose();
        foreach (Bitmap b in planets) b.Dispose();
        foreach (Bitmap b in rocks) b.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static int Hash(int c)
    {
        unchecked
        {
            int h = c * 374761393;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    private static float Smooth(float t)
    {
        t = Math.Max(0f, Math.Min(1f, t));
        return t * t * (3f - 2f * t);
    }

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    // ------------------------------------------------------------------ the sky layers

    public void Draw(Graphics g, float scroll, float time)
    {
        g.DrawImageUnscaled(bgGrad, 0, 0);

        float w1 = Smooth((scroll - 6050f) / 1200f);
        float w2 = Smooth((scroll - 11650f) / 1200f);
        float off = scroll * 0.05f + time * 2f;
        DrawNebula(g, nebula[0], off, 1f - w1);
        DrawNebula(g, nebula[1], off, w1 * (1f - w2));
        DrawNebula(g, nebula[2], off, w2);

        DrawStars(g, scroll * 0.06f + time * 3f, 70, 2, 1f, 110, time, false);
        DrawStars(g, scroll * 0.15f + time * 6f, 90, 2, 1.5f, 160, time, false);
        DrawPlanets(g, scroll, time);
        DrawStructures(g, scroll, time);
        DrawEnergyFields(g, scroll, time);
        DrawStars(g, scroll * 0.32f + time * 10f, 130, 1, 2f, 230, time, true);
        DrawDebris(g, scroll, time);
        DrawDust(g, scroll, time);
    }

    private void DrawNebula(Graphics g, Bitmap bmp, float offset, float weight)
    {
        if (weight < 0.02f) return;
        cm.Matrix33 = weight;
        ia.SetColorMatrix(cm, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
        float x = -(offset % NebW);
        while (x < W)
        {
            g.DrawImage(bmp, new Rectangle((int)x, 0, NebW, ViewH), 0, 0, NebW, ViewH, GraphicsUnit.Pixel, ia);
            x += NebW;
        }
    }

    private void DrawStars(Graphics g, float offset, int cell, int perCell, float size, int baseAlpha, float time, bool tinted)
    {
        int i0 = (int)Math.Floor(offset / cell);
        int i1 = (int)Math.Floor((offset + W) / cell) + 1;
        for (int i = i0; i <= i1; i++)
        {
            for (int k = 0; k < perCell; k++)
            {
                int h = Hash(i * 31 + k * 977 + (int)(size * 13f));
                float x = i * cell + (h % cell) - offset;
                float y = (h >> 8) % ViewH;
                float tw = 0.6f + 0.4f * MathF.Sin(time * (1f + (h % 7) * 0.3f) + h);
                int a = A(baseAlpha * tw);
                Color c = tinted
                    ? ((h & 1) == 0 ? Color.FromArgb(a, 200, 220, 255) : Color.FromArgb(a, 255, 220, 190))
                    : Color.FromArgb(a, 220, 230, 255);
                g.FillRectangle(B(c), x, y, size, size);
                if (tinted && (h % 5) == 0)
                {
                    g.FillRectangle(B(Color.FromArgb(a / 2, c.R, c.G, c.B)), x - 2f, y + size / 2f - 0.5f, size + 4f, 1f);
                    g.FillRectangle(B(Color.FromArgb(a / 2, c.R, c.G, c.B)), x + size / 2f - 0.5f, y - 2f, 1f, size + 4f);
                }
            }
        }
    }

    private void DrawPlanets(Graphics g, float scroll, float time)
    {
        float off = scroll * 0.18f + time * 0.6f;
        DrawPlanet(g, planets[0], 170f - off, 560f);
        DrawPlanet(g, planets[1], 1900f - off, 160f);
        DrawPlanet(g, planets[2], 3600f - off, 380f);
    }

    private void DrawPlanet(Graphics g, Bitmap bmp, float cx, float cy)
    {
        if (cx < -bmp.Width / 2f - 20f || cx > W + bmp.Width / 2f + 20f) return;
        g.DrawImageUnscaled(bmp, (int)(cx - bmp.Width / 2f), (int)(cy - bmp.Height / 2f));
    }

    private void DrawStructures(Graphics g, float scroll, float time)
    {
        float ls = scroll * 0.4f + time * 3f;
        const int cell = 170;
        int i0 = (int)Math.Floor((ls - 220f) / cell);
        int i1 = (int)Math.Floor((ls + W + 220f) / cell);
        for (int i = i0; i <= i1; i++)
        {
            float lx = i * cell;
            if (lx < 3400f) continue;
            int h = Hash(i * 53 + 5);
            float x = lx + (h % 60) - ls;
            bool top = (h % 3) == 0;
            if (lx < 5200f) DrawSpire(g, x, h, top, time);
            else if (lx < 6200f) DrawTendril(g, x, h, top, time);
            else DrawHull(g, x, h, top, time);
        }
    }

    private void DrawSpire(Graphics g, float x, int h, bool top, float time)
    {
        float height = 90f + (h >> 4) % 220;
        float w = 26f + (h >> 9) % 30;
        float y0 = top ? 0f : ViewH;
        float dir = top ? 1f : -1f;
        Color body = Color.FromArgb(235, 22, 28, 52);
        quad[0] = new PointF(x - w / 2f, y0);
        quad[1] = new PointF(x + w / 2f, y0);
        quad[2] = new PointF(x + w * 0.2f, y0 + dir * height);
        quad[3] = new PointF(x - w * 0.2f, y0 + dir * height);
        g.FillPolygon(B(body), quad);
        g.DrawPolygon(P(Color.FromArgb(120, 70, 100, 170), 1.5f), quad);
        for (int k = 0; k < 6; k++)
        {
            if (((h >> k) & 1) == 0) continue;
            float wy = y0 + dir * (14f + k * (height - 20f) / 6f);
            g.FillRectangle(B(Color.FromArgb(200, 255, 190, 90)), x - 3f, wy, 5f, 6f);
        }
        if ((h % 2) == 0)
        {
            float gy = y0 + dir * height;
            float a = time * (0.7f + (h % 5) * 0.2f) * (top ? -1f : 1f);
            g.DrawEllipse(P(Color.FromArgb(200, 90, 120, 190), 3f), x - 14f, gy - 14f, 28f, 28f);
            for (int t = 0; t < 4; t++)
            {
                float ang = a + t * MathF.PI / 2f;
                g.DrawLine(P(Color.FromArgb(220, 120, 150, 220), 3f), x + MathF.Cos(ang) * 8f, gy + MathF.Sin(ang) * 8f, x + MathF.Cos(ang) * 19f, gy + MathF.Sin(ang) * 19f);
            }
        }
    }

    private void DrawTendril(Graphics g, float x, int h, bool top, float time)
    {
        float height = 120f + (h >> 4) % 200;
        float y0 = top ? 0f : ViewH;
        float dir = top ? 1f : -1f;
        for (int k = 0; k < curve.Length; k++)
        {
            float t = k / (float)(curve.Length - 1);
            curve[k] = new PointF(x + MathF.Sin(time * 0.8f + h + t * 3f) * 22f * t, y0 + dir * height * t);
        }
        g.DrawCurve(P(Color.FromArgb(220, 60, 18, 52), 16f), curve);
        g.DrawCurve(P(Color.FromArgb(160, 150, 50, 100), 7f), curve);
        PointF tip = curve[curve.Length - 1];
        float pulse = 0.5f + 0.5f * MathF.Sin(time * 2f + h);
        g.FillEllipse(B(Color.FromArgb(A(60 + 90 * pulse), 255, 130, 200)), tip.X - 14f, tip.Y - 14f, 28f, 28f);
        g.FillEllipse(B(Color.FromArgb(220, 255, 190, 230)), tip.X - 5f, tip.Y - 5f, 10f, 10f);
    }

    private void DrawHull(Graphics g, float x, int h, bool top, float time)
    {
        float height = 150f + (h >> 4) % 150;
        float w = 90f + (h >> 9) % 60;
        float y = top ? 0f : ViewH - height;
        g.FillRectangle(B(Color.FromArgb(240, 24, 26, 42)), x - w / 2f, y, w, height);
        g.DrawRectangle(P(Color.FromArgb(150, 70, 70, 100), 2f), x - w / 2f, y, w, height);
        bool blink = ((int)(time * 2f + h) & 1) == 0;
        for (int k = 0; k < 5; k++)
        {
            float yy = y + 14f + k * (height - 28f) / 5f;
            g.FillRectangle(B(Color.FromArgb(180, 40, 44, 66)), x - w / 2f + 8f, yy, w - 16f, 6f);
            g.FillRectangle(B(blink ? Color.FromArgb(255, 255, 70, 60) : Color.FromArgb(160, 120, 30, 30)), x - w / 2f + 10f + (k % 3) * 20f, yy + 1f, 6f, 4f);
        }
    }

    private void DrawEnergyFields(Graphics g, float scroll, float time)
    {
        bool industrial = scroll > 8800f && scroll < 12600f;
        bool lair = scroll > 14400f;
        if (!industrial && !lair) return;
        float ls = scroll * 0.55f + time * 4f;
        const int cell = 420;
        int i0 = (int)Math.Floor(ls / cell);
        int i1 = (int)Math.Floor((ls + W) / cell) + 1;
        for (int i = i0; i <= i1; i++)
        {
            int h = Hash(i * 71 + 9);
            if (h % 3 == 0) continue;
            float x = i * cell + (h % 200) - ls;
            float pulse = 0.5f + 0.5f * MathF.Sin(time * 1.5f + h);
            Color c = lair ? Color.FromArgb(255, 255, 90, 90) : Color.FromArgb(255, 90, 200, 255);
            g.FillRectangle(B(Color.FromArgb(A(18 + 22 * pulse), c.R, c.G, c.B)), x - 18f, 0f, 36f, ViewH);
            g.FillRectangle(B(Color.FromArgb(A(40 + 60 * pulse), c.R, c.G, c.B)), x - 2f, 0f, 4f, ViewH);
        }
    }

    private void DrawDebris(Graphics g, float scroll, float time)
    {
        float ls = scroll * 0.85f + time * 12f;
        const int cell = 240;
        int i0 = (int)Math.Floor((ls - 40f) / cell);
        int i1 = (int)Math.Floor((ls + W + 40f) / cell);
        for (int i = i0; i <= i1; i++)
        {
            int h = Hash(i * 19 + 3);
            if (h % 100 > 55) continue;
            Bitmap r = rocks[h % rocks.Length];
            float x = i * cell + (h >> 5) % cell - ls;
            float y = 20f + (h >> 11) % (ViewH - 40);
            g.DrawImageUnscaled(r, (int)x, (int)(y + MathF.Sin(time * 0.6f + h) * 6f));
        }
    }

    private void DrawDust(Graphics g, float scroll, float time)
    {
        float ls = scroll * 1.6f + time * 24f;
        const int cell = 150;
        int i0 = (int)Math.Floor(ls / cell);
        int i1 = (int)Math.Floor((ls + W + 80f) / cell);
        for (int i = i0; i <= i1; i++)
        {
            int h = Hash(i * 13 + 1);
            if (h % 100 > 45) continue;
            float x = i * cell + (h >> 4) % cell - ls;
            float y = (h >> 10) % ViewH;
            float len = 20f + (h >> 3) % 40;
            g.DrawLine(P(Color.FromArgb(34, 200, 220, 255), 1f), x, y, x + len, y);
        }
    }

    // ------------------------------------------------------------------ terrain

    private static Pal PaletteFor(int style)
    {
        switch (style)
        {
            case Terrain.StylePlanet: return PalPlanet;
            case Terrain.StyleIndustrial: return PalIndustrial;
            case Terrain.StyleOrganic: return PalOrganic;
            default: return PalLair;
        }
    }

    public void DrawTerrain(Graphics g, Terrain terrain, float scroll, float time)
    {
        int n = 0;
        for (int x = 0; x <= W + Strip; x += Strip)
        {
            float f = scroll + x;
            float t, b;
            terrain.Thickness(f, out t, out b);
            topT[n] = t;
            botT[n] = b;
            fAt[n] = f;
            n++;
        }
        bool any = false;
        for (int i = 0; i < n - 1; i++)
        {
            float t = topT[i];
            float b = botT[i];
            if (t <= 0.5f && b <= 0.5f) continue;
            any = true;
            float x = i * Strip;
            int st = terrain.StyleAt(fAt[i] + Strip / 2f);
            Pal p = PaletteFor(st);
            int cellIndex = (int)(fAt[i] / Strip);
            int h = Hash(cellIndex * 7 + st);
            if (t > 0.5f)
            {
                g.FillRectangle(B(p.Base), x, 0f, Strip + 0.8f, t);
                g.FillRectangle(B(Color.FromArgb(150, p.Dark.R, p.Dark.G, p.Dark.B)), x, 0f, Strip + 0.8f, t * 0.55f);
                g.FillRectangle(B(Color.FromArgb(70, p.Edge.R, p.Edge.G, p.Edge.B)), x, t - 9f, Strip + 0.8f, 9f);
                Detail(g, st, p, cellIndex, h, x, t, true, time);
            }
            if (b > 0.5f)
            {
                float y = ViewH - b;
                g.FillRectangle(B(p.Base), x, y, Strip + 0.8f, b);
                g.FillRectangle(B(Color.FromArgb(150, p.Dark.R, p.Dark.G, p.Dark.B)), x, y + b * 0.45f, Strip + 0.8f, b * 0.55f);
                g.FillRectangle(B(Color.FromArgb(70, p.Edge.R, p.Edge.G, p.Edge.B)), x, y, Strip + 0.8f, 9f);
                Detail(g, st, p, cellIndex, h, x, y, false, time);
            }
        }
        if (!any) return;

        // edge lines: a dark outline with a bright rim
        for (int pass = 0; pass < 2; pass++)
        {
            for (int i = 0; i < n - 1; i++)
            {
                int st = terrain.StyleAt(fAt[i] + Strip / 2f);
                Pal p = PaletteFor(st);
                Pen pen = pass == 0 ? P(Color.FromArgb(255, 8, 8, 18), 5f) : P(p.Edge, 2f);
                float x0 = i * Strip;
                float x1 = x0 + Strip;
                if (topT[i] > 0.5f && topT[i + 1] > 0.5f) g.DrawLine(pen, x0, topT[i], x1, topT[i + 1]);
                if (botT[i] > 0.5f && botT[i + 1] > 0.5f) g.DrawLine(pen, x0, ViewH - botT[i], x1, ViewH - botT[i + 1]);
            }
        }
    }

    /// <summary>Style-specific details on one strip; ey is the y of the edge, up says whether it is the ceiling.</summary>
    private void Detail(Graphics g, int st, Pal p, int cellIndex, int h, float x, float ey, bool up, float time)
    {
        float dirIn = up ? -1f : 1f;          // direction into the rock
        switch (st)
        {
            case Terrain.StylePlanet:
                if (h % 3 == 0)
                    g.FillRectangle(B(Color.FromArgb(150, p.Dark.R, p.Dark.G, p.Dark.B)), x + h % 8, ey + dirIn * (12f + (h >> 4) % 40), 4f, 3f);
                if (h % 11 == 0)
                    g.FillEllipse(B(Color.FromArgb(120, 30, 20, 36)), x - 4f, ey + dirIn * 22f - 6f, 22f, 12f);
                break;
            case Terrain.StyleIndustrial:
                if (cellIndex % 8 == 0)
                {
                    g.FillRectangle(B(Color.FromArgb(200, p.Dark.R, p.Dark.G, p.Dark.B)), x, up ? 0f : ey, 2f, 400f);
                    g.FillEllipse(B(p.Edge), x + 4f, ey + dirIn * 14f - 2f, 4f, 4f);
                }
                if (cellIndex % 12 < 4)
                {
                    bool yellow = (cellIndex & 1) == 0;
                    g.FillRectangle(B(yellow ? Color.FromArgb(255, 235, 190, 50) : Color.FromArgb(255, 30, 30, 36)), x, up ? ey - 7f : ey, Strip + 0.8f, 7f);
                }
                if (cellIndex % 16 == 3)
                {
                    float pulse = 0.5f + 0.5f * MathF.Sin(time * 4f + cellIndex);
                    g.FillEllipse(B(Color.FromArgb(A(120 + 130 * pulse), 90, 220, 255)), x + 2f, ey + dirIn * 20f - 3f, 7f, 7f);
                }
                break;
            case Terrain.StyleOrganic:
                if (h % 4 == 0)
                    g.DrawLine(P(Color.FromArgb(130, 160, 56, 100), 2f), x, ey + dirIn * (14f + h % 25), x + Strip, ey + dirIn * (22f + (h >> 3) % 25));
                if (h % 9 == 0)
                {
                    float pulse = 0.5f + 0.5f * MathF.Sin(time * 2.2f + h);
                    g.FillEllipse(B(Color.FromArgb(A(70 + 90 * pulse), 140, 255, 170)), x - 2f, ey + dirIn * 6f - 8f, 16f, 16f);
                    g.FillEllipse(B(Color.FromArgb(230, 210, 255, 220)), x + 3f, ey + dirIn * 6f - 3f, 6f, 6f);
                }
                break;
            default:    // lair
                if (cellIndex % 8 == 0) g.FillRectangle(B(Color.FromArgb(200, p.Dark.R, p.Dark.G, p.Dark.B)), x, up ? 0f : ey, 2f, 300f);
                if (cellIndex % 6 == 0)
                {
                    bool blink = ((int)(time * 2.5f + cellIndex) & 1) == 0;
                    g.FillRectangle(B(blink ? Color.FromArgb(255, 255, 70, 60) : Color.FromArgb(150, 110, 30, 30)), x + 2f, ey + dirIn * 12f - 2f, 8f, 4f);
                }
                break;
        }
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private static Bitmap MakeGradient()
    {
        Bitmap bmp = new Bitmap(W, ViewH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        using (LinearGradientBrush lg = new LinearGradientBrush(new Rectangle(0, 0, W, ViewH), Color.FromArgb(3, 5, 20), Color.FromArgb(12, 18, 46), 90f))
        {
            g.FillRectangle(lg, 0, 0, W, ViewH);
        }
        return bmp;
    }

    private static void SoftBlob(Graphics g, float cx, float cy, float rx, float ry, Color c)
    {
        using (GraphicsPath gp = new GraphicsPath())
        {
            gp.AddEllipse(cx - rx, cy - ry, rx * 2f, ry * 2f);
            using (PathGradientBrush pg = new PathGradientBrush(gp))
            {
                pg.CenterColor = c;
                pg.SurroundColors = new[] { Color.FromArgb(0, c.R, c.G, c.B) };
                g.FillPath(pg, gp);
            }
        }
    }

    private static Bitmap MakeNebula(int variant)
    {
        Bitmap bmp = new Bitmap(NebW, ViewH, PixelFormat.Format32bppPArgb);
        Color[][] pal =
        {
            new[] { Color.FromArgb(40, 60, 200), Color.FromArgb(120, 50, 200), Color.FromArgb(30, 140, 220) },
            new[] { Color.FromArgb(30, 170, 150), Color.FromArgb(60, 200, 110), Color.FromArgb(40, 100, 200) },
            new[] { Color.FromArgb(210, 40, 90), Color.FromArgb(150, 30, 190), Color.FromArgb(240, 100, 60) }
        };
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(500 + variant * 31);
            for (int i = 0; i < 34; i++)
            {
                float cx = rnd.Next(NebW);
                float cy = rnd.Next(ViewH);
                float rx = 160f + rnd.Next(260);
                float ry = 80f + rnd.Next(150);
                Color baseC = pal[variant][rnd.Next(3)];
                Color c = Color.FromArgb(40 + rnd.Next(50), baseC.R, baseC.G, baseC.B);
                for (int d = -1; d <= 1; d++) SoftBlob(g, cx + d * NebW, cy, rx, ry, c);
            }
        }
        return bmp;
    }

    private static Bitmap MakeEarth()
    {
        const int S = 580;
        Bitmap bmp = new Bitmap(S, S, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float c = S / 2f;
            float r = 250f;
            SoftBlob(g, c, c, r + 36f, r + 36f, Color.FromArgb(110, 90, 170, 255));
            using (GraphicsPath disc = new GraphicsPath())
            {
                disc.AddEllipse(c - r, c - r, r * 2f, r * 2f);
                using (PathGradientBrush pg = new PathGradientBrush(disc))
                {
                    pg.CenterColor = Color.FromArgb(255, 80, 160, 250);
                    pg.SurroundColors = new[] { Color.FromArgb(255, 10, 36, 110) };
                    pg.CenterPoint = new PointF(c - 70f, c - 70f);
                    g.FillPath(pg, disc);
                }
                GraphicsState st = g.Save();
                g.SetClip(disc);
                Random rnd = new Random(41);
                using (SolidBrush land = new SolidBrush(Color.FromArgb(200, 70, 140, 80)))
                using (SolidBrush land2 = new SolidBrush(Color.FromArgb(200, 150, 140, 90)))
                using (SolidBrush cloud = new SolidBrush(Color.FromArgb(110, 255, 255, 255)))
                {
                    for (int i = 0; i < 26; i++)
                    {
                        float x = c - r + rnd.Next((int)(r * 2f));
                        float y = c - r + rnd.Next((int)(r * 2f));
                        g.FillEllipse(rnd.Next(3) == 0 ? land2 : land, x, y, 40 + rnd.Next(90), 20 + rnd.Next(50));
                    }
                    for (int i = 0; i < 30; i++)
                    {
                        float x = c - r + rnd.Next((int)(r * 2f));
                        float y = c - r + rnd.Next((int)(r * 2f));
                        g.FillEllipse(cloud, x, y, 60 + rnd.Next(120), 14 + rnd.Next(24));
                    }
                }
                using (LinearGradientBrush shade = new LinearGradientBrush(new RectangleF(c - r, c - r, r * 2f, r * 2f), Color.FromArgb(0, 0, 0, 10), Color.FromArgb(230, 0, 0, 14), 40f))
                {
                    g.FillRectangle(shade, c - r, c - r, r * 2f, r * 2f);
                }
                g.Restore(st);
            }
            using (Pen rim = new Pen(Color.FromArgb(120, 150, 210, 255), 3f))
            {
                g.DrawArc(rim, c - r, c - r, r * 2f, r * 2f, 180f, 110f);
            }
        }
        return bmp;
    }

    private static Bitmap MakeGasGiant()
    {
        const int Wd = 560;
        const int Ht = 380;
        Bitmap bmp = new Bitmap(Wd, Ht, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float cx = Wd / 2f;
            float cy = Ht / 2f;
            float r = 110f;
            GraphicsState rs = g.Save();
            g.TranslateTransform(cx, cy);
            g.RotateTransform(-18f);
            using (Pen ring = new Pen(Color.FromArgb(120, 220, 190, 140), 20f))
            using (Pen ring2 = new Pen(Color.FromArgb(90, 170, 140, 110), 10f))
            {
                g.DrawEllipse(ring, -230f, -48f, 460f, 96f);
                g.DrawEllipse(ring2, -250f, -56f, 500f, 112f);
            }
            g.Restore(rs);
            using (GraphicsPath disc = new GraphicsPath())
            {
                disc.AddEllipse(cx - r, cy - r, r * 2f, r * 2f);
                using (PathGradientBrush pg = new PathGradientBrush(disc))
                {
                    pg.CenterColor = Color.FromArgb(255, 240, 170, 90);
                    pg.SurroundColors = new[] { Color.FromArgb(255, 120, 50, 30) };
                    pg.CenterPoint = new PointF(cx - 36f, cy - 36f);
                    g.FillPath(pg, disc);
                }
                GraphicsState st = g.Save();
                g.SetClip(disc);
                using (SolidBrush band = new SolidBrush(Color.FromArgb(60, 120, 50, 30)))
                using (SolidBrush band2 = new SolidBrush(Color.FromArgb(50, 255, 220, 160)))
                {
                    for (int i = 0; i < 9; i++) g.FillRectangle(i % 2 == 0 ? band : band2, cx - r, cy - r + 14 + i * 24, r * 2f, 10 + (i % 3) * 5);
                }
                using (LinearGradientBrush shade = new LinearGradientBrush(new RectangleF(cx - r, cy - r, r * 2f, r * 2f), Color.FromArgb(0, 0, 0, 10), Color.FromArgb(220, 0, 0, 14), 35f))
                {
                    g.FillRectangle(shade, cx - r, cy - r, r * 2f, r * 2f);
                }
                g.Restore(st);
            }
            GraphicsState fs = g.Save();
            g.TranslateTransform(cx, cy);
            g.RotateTransform(-18f);
            using (Pen ring = new Pen(Color.FromArgb(150, 230, 200, 150), 20f))
            {
                g.DrawArc(ring, -230f, -48f, 460f, 96f, 0f, 180f);
            }
            g.Restore(fs);
        }
        return bmp;
    }

    private static Bitmap MakeMoon()
    {
        const int S = 220;
        Bitmap bmp = new Bitmap(S, S, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float c = S / 2f;
            float r = 86f;
            SoftBlob(g, c, c, r + 20f, r + 20f, Color.FromArgb(70, 255, 120, 80));
            using (GraphicsPath disc = new GraphicsPath())
            {
                disc.AddEllipse(c - r, c - r, r * 2f, r * 2f);
                using (PathGradientBrush pg = new PathGradientBrush(disc))
                {
                    pg.CenterColor = Color.FromArgb(255, 230, 120, 80);
                    pg.SurroundColors = new[] { Color.FromArgb(255, 80, 30, 36) };
                    pg.CenterPoint = new PointF(c - 28f, c - 28f);
                    g.FillPath(pg, disc);
                }
                GraphicsState st = g.Save();
                g.SetClip(disc);
                Random rnd = new Random(77);
                using (SolidBrush crater = new SolidBrush(Color.FromArgb(70, 60, 20, 24)))
                {
                    for (int i = 0; i < 14; i++) g.FillEllipse(crater, c - r + rnd.Next((int)(r * 2f)), c - r + rnd.Next((int)(r * 2f)), 8 + rnd.Next(24), 8 + rnd.Next(18));
                }
                using (LinearGradientBrush shade = new LinearGradientBrush(new RectangleF(c - r, c - r, r * 2f, r * 2f), Color.FromArgb(0, 0, 0, 10), Color.FromArgb(220, 0, 0, 14), 35f))
                {
                    g.FillRectangle(shade, c - r, c - r, r * 2f, r * 2f);
                }
                g.Restore(st);
            }
        }
        return bmp;
    }

    private static Bitmap MakeRock(int variant)
    {
        Bitmap bmp = new Bitmap(40, 40, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(900 + variant * 7);
            PointF[] pts = new PointF[9];
            for (int i = 0; i < pts.Length; i++)
            {
                float a = i * MathF.PI * 2f / pts.Length;
                float rr = 8f + (float)rnd.NextDouble() * 8f + variant * 1.5f;
                pts[i] = new PointF(20f + MathF.Cos(a) * rr, 20f + MathF.Sin(a) * rr);
            }
            using (SolidBrush b = new SolidBrush(Color.FromArgb(190, 70, 72, 96)))
            using (SolidBrush hi = new SolidBrush(Color.FromArgb(120, 140, 146, 180)))
            using (Pen p = new Pen(Color.FromArgb(200, 20, 22, 36), 1.5f))
            {
                g.FillPolygon(b, pts);
                g.FillEllipse(hi, 14f, 12f, 8f, 6f);
                g.DrawPolygon(p, pts);
            }
        }
        return bmp;
    }
}
