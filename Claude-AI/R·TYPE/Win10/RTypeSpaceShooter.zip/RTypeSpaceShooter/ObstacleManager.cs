namespace RTypeSpaceShooter;

public struct ObstacleEvent
{
    public float T;
    public ObstacleType Type;
    public float Y, A, Phase;
    public bool FromTop;
}

/// <summary>The scripted placement and the behaviour of all environmental obstacles.</summary>
public sealed class ObstacleManager
{
    public readonly List<Obstacle> Items = new List<Obstacle>(64);
    public Action<Obstacle>? Destroyed;

    private readonly List<ObstacleEvent> script = new List<ObstacleEvent>(160);
    private readonly Random rng = new Random();
    private int next;

    public void Reset()
    {
        Items.Clear();
        script.Clear();
        next = 0;
        BuildScript();
    }

    // ------------------------------------------------------------------ the script

    private void Add(float t, ObstacleType type, float y, float a, bool fromTop, float phase = 0f)
    {
        ObstacleEvent e = new ObstacleEvent();
        e.T = t; e.Type = type; e.Y = y; e.A = a; e.FromTop = fromTop; e.Phase = phase;
        script.Add(e);
    }

    private void Asteroids(Random r, float t0, float t1, float step, params float[] radii)
    {
        for (float t = t0; t < t1; t += step)
        {
            float rad = radii[r.Next(radii.Length)];
            Add(t + (float)r.NextDouble() * 0.6f, ObstacleType.Asteroid, 40f + (float)r.NextDouble() * 460f, rad, false);
        }
    }

    private void BuildScript()
    {
        Random r = new Random(7);
        // section 1 and 2: scattered asteroids
        Asteroids(r, 10f, 48f, 2.8f, 13f, 22f, 22f, 36f);
        Asteroids(r, 52f, 92f, 6f, 13f, 22f);
        // section 3: the asteroid field
        Asteroids(r, 96f, 133f, 0.95f, 13f, 22f, 22f, 36f, 36f);

        // section 2: gun turrets on the planet surface
        foreach (float t in new[] { 56f, 60f, 64f, 70f, 74f, 84f, 88f }) Add(t, ObstacleType.Turret, 0f, 0f, false);

        // section 4: industrial corridors - barriers, energy gates, pillars and turrets
        foreach (float t in new[] { 138f, 146f, 154f, 164f }) Add(t, ObstacleType.Barrier, 0f, 0f, false, (t * 0.37f) % 1f);
        foreach (float t in new[] { 142f, 150f, 158f, 168f }) Add(t, ObstacleType.Gate, 0f, 0f, false, (t * 0.53f) % 1f);
        Add(144f, ObstacleType.Pillar, 0f, 170f, true);
        Add(148f, ObstacleType.Pillar, 0f, 170f, false);
        Add(156f, ObstacleType.Pillar, 0f, 190f, true);
        Add(160f, ObstacleType.Pillar, 0f, 190f, false);
        Add(166f, ObstacleType.Pillar, 0f, 170f, false);
        Add(140f, ObstacleType.Turret, 0f, 0f, false);
        Add(145f, ObstacleType.Turret, 0f, 0f, true);
        Add(152f, ObstacleType.Turret, 0f, 0f, false);
        Add(157f, ObstacleType.Turret, 0f, 0f, true);
        Add(162f, ObstacleType.Turret, 0f, 0f, false);
        Add(170f, ObstacleType.Turret, 0f, 0f, true);

        // section 5: organic pillars and spore turrets
        float[] pillarTimes = { 178f, 182f, 186f, 190f, 194f, 198f, 204f, 208f };
        for (int i = 0; i < pillarTimes.Length; i++) Add(pillarTimes[i], ObstacleType.Pillar, 0f, 150f + 20f * (i % 3), i % 2 == 0);
        float[] podTimes = { 180f, 184f, 188f, 192f, 196f, 200f, 206f };
        for (int i = 0; i < podTimes.Length; i++) Add(podTimes[i], ObstacleType.Turret, 0f, 0f, i % 2 == 0);
        Add(212f, ObstacleType.Barrier, 0f, 0f, false, 0.2f);

        // section 6: the mechanical installation
        Add(216f, ObstacleType.Gate, 0f, 0f, false, 0.1f);
        Add(222f, ObstacleType.Gate, 0f, 0f, false, 0.6f);
        Add(219f, ObstacleType.Barrier, 0f, 0f, false, 0.0f);
        Add(226f, ObstacleType.Barrier, 0f, 0f, false, 0.5f);
        Add(218f, ObstacleType.Turret, 0f, 0f, false);
        Add(224f, ObstacleType.Turret, 0f, 0f, true);
        Add(230f, ObstacleType.Turret, 0f, 0f, false);

        script.Sort((a, b) => a.T.CompareTo(b.T));
    }

    // ------------------------------------------------------------------ simulation

    private void Spawn(ObstacleEvent ev, float scroll, Terrain terrain, float diff)
    {
        float wx = scroll + GameConfig.LogicalW + 80f;
        Obstacle o = new Obstacle();
        o.Type = ev.Type;
        o.WX = wx;
        o.FromTop = ev.FromTop;
        o.Style = terrain.StyleAt(wx);
        o.Variant = rng.Next(4);
        float top, bot;
        terrain.MaxThickness(wx - 40f, wx + 40f, out top, out bot);
        switch (ev.Type)
        {
            case ObstacleType.Asteroid:
                o.W = ev.A * 2f;
                o.H = o.W;
                o.Y = ev.Y;
                o.DriftX = 20f + (float)rng.NextDouble() * 60f;
                o.DriftY = ((float)rng.NextDouble() - 0.5f) * 50f;
                o.Spin = ((float)rng.NextDouble() - 0.5f) * 1.6f;
                o.Rot = (float)rng.NextDouble() * 6.28f;
                o.MaxHp = ev.A >= 30f ? 8f : (ev.A >= 20f ? 4f : 2f);
                o.Hp = o.MaxHp;
                break;
            case ObstacleType.Barrier:
                {
                    o.W = 28f;
                    o.H = 110f;
                    o.YLo = top + o.H / 2f + 20f;
                    o.YHi = GameConfig.ViewH - bot - o.H / 2f - 20f;
                    if (o.YHi < o.YLo) o.YHi = o.YLo = (o.YLo + o.YHi) / 2f;
                    o.Period = 2.6f;
                    o.Phase = ev.Phase;
                    o.Y = (o.YLo + o.YHi) / 2f;
                    break;
                }
            case ObstacleType.Gate:
                o.W = 18f;
                o.GateTop = terrain.Top(wx) - 4f;
                o.GateBottom = GameConfig.ViewH - terrain.Bottom(wx) + 4f;
                o.Period = 3.2f;
                o.Phase = ev.Phase * o.Period;
                o.Y = (o.GateTop + o.GateBottom) / 2f;
                break;
            case ObstacleType.Turret:
                o.W = 36f;
                o.H = 32f;
                o.Y = ev.FromTop ? terrain.Top(wx) + 16f : GameConfig.ViewH - terrain.Bottom(wx) - 16f;
                o.MaxHp = 6f + MathF.Round(4f * diff);
                o.Hp = o.MaxHp;
                o.ShootTimer = 1f + (float)rng.NextDouble();
                break;
            default:    // Pillar
                {
                    o.W = 50f;
                    float edge = ev.FromTop ? top : bot;
                    float free = GameConfig.ViewH - top - bot - 230f;
                    float len = Math.Min(ev.A, Math.Max(60f, free));
                    o.H = edge + len;
                    o.Y = ev.FromTop ? o.H / 2f : GameConfig.ViewH - o.H / 2f;
                    break;
                }
        }
        Items.Add(o);
    }

    public void Update(float dt, float stageTime, float scroll, Terrain terrain, PlayerShip player, ProjectileManager shots, float diff, out bool anyFired)
    {
        anyFired = false;
        while (next < script.Count && script[next].T <= stageTime) Spawn(script[next++], scroll, terrain, diff);

        float px = player.Alive ? player.X : GameConfig.PlayerStartX;
        float py = player.Alive ? player.Y : GameConfig.PlayerStartY;
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Obstacle o = Items[i];
            o.Age += dt;
            if (o.HitFlash > 0f) o.HitFlash = Math.Max(0f, o.HitFlash - dt);
            float sx = o.ScreenX(scroll);
            switch (o.Type)
            {
                case ObstacleType.Asteroid:
                    o.WX -= o.DriftX * dt;
                    o.Y += o.DriftY * dt;
                    o.Rot += o.Spin * dt;
                    if (o.Y < o.Radius) { o.Y = o.Radius; o.DriftY = Math.Abs(o.DriftY); }
                    if (o.Y > GameConfig.ViewH - o.Radius) { o.Y = GameConfig.ViewH - o.Radius; o.DriftY = -Math.Abs(o.DriftY); }
                    break;
                case ObstacleType.Barrier:
                    {
                        float mid = (o.YLo + o.YHi) / 2f;
                        float amp = (o.YHi - o.YLo) / 2f;
                        o.Y = mid + amp * MathF.Sin(2f * MathF.PI * (o.Age / o.Period + o.Phase));
                        break;
                    }
                case ObstacleType.Gate:
                    {
                        float t = (o.Age + o.Phase) % o.Period;
                        o.GateOn = t >= 2.2f;
                        o.GateWarn = t >= 1.7f && t < 2.2f;
                        break;
                    }
                case ObstacleType.Turret:
                    o.ShootTimer -= dt;
                    if (o.ShootTimer <= 0f && sx < GameConfig.LogicalW - 30f && sx > 60f)
                    {
                        shots.FireAimed(ShotKind.EnemySmall, sx, o.Y + (o.FromTop ? 12f : -12f), px, py, 250f + 60f * diff, 0f);
                        o.ShootTimer = 2.4f - 0.6f * diff + (float)rng.NextDouble() * 0.6f;
                        anyFired = true;
                    }
                    break;
            }
            if (!o.Alive || sx < -160f) Items.RemoveAt(i);
        }
    }

    public void Damage(Obstacle o, float amount)
    {
        if (!o.Alive || !o.Destructible) return;
        o.Hp -= amount;
        o.HitFlash = 0.1f;
        if (o.Hp <= 0f)
        {
            o.Alive = false;
            Destroyed?.Invoke(o);
        }
    }

    public void BombAll(float damage, float scroll)
    {
        foreach (Obstacle o in Items)
        {
            float sx = o.ScreenX(scroll);
            if (o.Alive && o.Destructible && sx > -20f && sx < GameConfig.LogicalW + 20f) Damage(o, damage);
        }
    }
}
