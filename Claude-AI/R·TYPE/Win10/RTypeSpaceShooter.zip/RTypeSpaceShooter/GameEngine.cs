namespace RTypeSpaceShooter;

public enum GameState { Menu, Playing, Paused, GameOver, Victory }

/// <summary>Game rules and the fixed-step simulation (1/120 s): mission timeline, boss, scoring, bonuses, lives.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;

    public GameState State = GameState.Menu;
    public readonly Terrain Terrain = new Terrain();
    public readonly PlayerShip Player = new PlayerShip();
    public readonly ForcePod Pod = new ForcePod();
    public readonly ProjectileManager Shots = new ProjectileManager();
    public readonly EnemyManager Enemies = new EnemyManager();
    public readonly ObstacleManager Obstacles = new ObstacleManager();
    public readonly Boss Boss = new Boss();
    public readonly BonusManager Bonuses = new BonusManager();
    public readonly ExplosionManager Explosions = new ExplosionManager();
    public readonly ParticleSystem Particles = new ParticleSystem();
    public readonly ScoreManager Scores = new ScoreManager();

    // input set by the window
    public bool Up, Down, Left, Right, Fire, Charge;

    public float Clock;                  // keeps running for menu animations
    public float StageTime;
    public float PlayTime;
    public float Scroll;                 // distance scrolled, in pixels
    public int Score;
    public int Kills;
    public bool NewRecord;
    public float Shake;
    public float Flash;
    public string Banner = "";
    public float BannerTimer;
    public string BonusText = "";
    public float BonusTimer;

    private bool podQueued;
    private bool bossWarned;
    private bool bossSpawned;
    private float endTimer;
    private float trailTimer;
    private readonly Random rng = new Random();

    public float Difficulty
    {
        get { return Math.Max(0f, Math.Min(1f, StageTime / GameConfig.BossArrivalTime)); }
    }

    public float StageProgress
    {
        get { return Math.Max(0f, Math.Min(1f, StageTime / GameConfig.BossArrivalTime)); }
    }

    public GameEngine()
    {
        Scores.Load();
        Enemies.Killed = OnEnemyKilled;
        Obstacles.Destroyed = OnObstacleDestroyed;
        Enemies.Reset();
        Obstacles.Reset();
        Player.Reset(GameConfig.ViewH / 2f);
        Pod.Reset(Player);
    }

    // ------------------------------------------------------------------ flow

    public void StartGame()
    {
        Shots.Clear();
        Enemies.Reset();
        Obstacles.Reset();
        Boss.Reset();
        Bonuses.Clear();
        Explosions.Clear();
        Particles.Clear();
        Score = 0;
        Kills = 0;
        StageTime = 0f;
        PlayTime = 0f;
        Scroll = 0f;
        NewRecord = false;
        Shake = 0f;
        Flash = 0f;
        BonusText = "";
        BonusTimer = 0f;
        bossWarned = false;
        bossSpawned = false;
        endTimer = 0f;
        podQueued = false;
        Player.Reset(Terrain.CorridorCenter(GameConfig.PlayerStartX));
        Pod.Reset(Player);
        State = GameState.Playing;
        Sfx.Play(SfxId.Click);
        Banner = "MISSION START";
        BannerTimer = 2.2f;
    }

    public void Resume()
    {
        if (State != GameState.Paused) return;
        Sfx.Play(SfxId.Click);
        State = GameState.Playing;
    }

    public void Pause()
    {
        if (State != GameState.Playing) return;
        ClearInput();
        Sfx.Play(SfxId.Click);
        State = GameState.Paused;
    }

    public void GoToMenu()
    {
        ClearInput();
        Sfx.Play(SfxId.Click);
        State = GameState.Menu;
    }

    public void AutoPause()
    {
        ClearInput();
        if (State == GameState.Playing) State = GameState.Paused;
    }

    private void ClearInput()
    {
        Up = false; Down = false; Left = false; Right = false; Fire = false; Charge = false;
        podQueued = false;
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                if (State == GameState.Menu || State == GameState.GameOver || State == GameState.Victory) StartGame();
                else if (State == GameState.Paused) Resume();
                break;
            case Keys.Space:
                if (State == GameState.Menu) StartGame();
                break;
            case Keys.X:
                if (State == GameState.Playing) podQueued = true;
                break;
            case Keys.Escape:
            case Keys.P:
                if (State == GameState.Playing) Pause();
                else if (State == GameState.Paused) Resume();
                else if ((State == GameState.GameOver || State == GameState.Victory) && key == Keys.Escape) GoToMenu();
                break;
            case Keys.R:
                if (State != GameState.Menu) StartGame();
                break;
            case Keys.M:
                if (State == GameState.Paused || State == GameState.GameOver || State == GameState.Victory) GoToMenu();
                break;
            case Keys.N:
                Sfx.SetMuted(!Sfx.Muted);
                break;
        }
    }

    // ------------------------------------------------------------------ simulation

    public void Update()
    {
        Clock += Dt;
        if (State == GameState.Menu || State == GameState.Paused) return;

        if (State == GameState.GameOver || State == GameState.Victory)
        {
            Shots.Update(Dt);
            UpdateEffects();
            return;
        }

        StageTime += Dt;
        PlayTime += Dt;
        float scrollFactor = StageTime > GameConfig.BossWarningTime ? Math.Max(0f, 1f - (StageTime - GameConfig.BossWarningTime) / 4f) : 1f;
        Scroll += GameConfig.ScrollSpeed * scrollFactor * Dt;
        float diff = Difficulty;

        PlayerInput inp = new PlayerInput();
        inp.Up = Up; inp.Down = Down; inp.Left = Left; inp.Right = Right; inp.Fire = Fire; inp.Charge = Charge;
        float respawnY = Terrain.CorridorCenter(Scroll + GameConfig.PlayerStartX);
        Player.Update(Dt, inp, Shots, Terrain, Scroll, Pod, respawnY);
        if (podQueued)
        {
            podQueued = false;
            Pod.Toggle(Player);
        }
        HandlePlayerEvents();

        float tx, ty;
        bool hasTarget = Enemies.FindNearest(Pod.X, Pod.Y, 520f, out tx, out ty);
        if (!hasTarget && Boss.Vulnerable)
        {
            tx = Boss.X - 140f;
            ty = Boss.Y;
            hasTarget = true;
        }
        Pod.Update(Dt, Player, hasTarget, tx, ty, Shots);
        HandlePodEvents();

        Shots.Update(Dt);
        Bonuses.Update(Dt, StageTime, Scroll, Terrain);

        bool fired;
        Obstacles.Update(Dt, StageTime, Scroll, Terrain, Player, Shots, diff, out fired);
        if (fired) Sfx.Play(SfxId.EnemyShoot);
        Enemies.Update(Dt, StageTime, Player, diff, Shots, Particles, Terrain, Scroll, out fired);
        if (fired) Sfx.Play(SfxId.EnemyShoot);

        UpdateBoss();
        CollisionManager.Resolve(this);
        HandleBossPartEvents();

        if (!Player.Alive && Player.Lives <= 0)
        {
            endTimer += Dt;
            if (endTimer >= 1.7f) EndGame(false);
        }
        UpdateEffects();
    }

    private void UpdateEffects()
    {
        Particles.Update(Dt);
        Explosions.Update(Dt);
        if (Shake > 0f) Shake = Math.Max(0f, Shake - Dt);
        if (Flash > 0f) Flash = Math.Max(0f, Flash - Dt);
        if (BannerTimer > 0f) BannerTimer -= Dt;
        if (BonusTimer > 0f) BonusTimer -= Dt;

        if (State == GameState.Playing && Player.Alive)
        {
            trailTimer -= Dt;
            if (trailTimer <= 0f)
            {
                trailTimer = 0.04f;
                Particles.Flames(Player.X - 30f, Player.Y, 2f, 1);
            }
        }
    }

    private void HandlePlayerEvents()
    {
        WeaponSystem w = Player.Weapon;
        if (w.EvShot)
        {
            w.EvShot = false;
            Sfx.Play(SfxId.Shoot);
            Particles.Sparks(Player.X + 30f, Player.Y, 60f, 1, Color.FromArgb(160, 230, 255));
        }
        if (w.EvLaser)
        {
            w.EvLaser = false;
            Sfx.Play(SfxId.Laser);
            Particles.Sparks(Player.X + 30f, Player.Y, 80f, 3, Color.FromArgb(255, 150, 220));
        }
        if (w.EvCharged)
        {
            w.EvCharged = false;
            Sfx.Play(SfxId.Charged);
            Particles.Ring(Player.X + 30f, Player.Y, 30f + 50f * w.EvChargeLevel, Color.FromArgb(150, 220, 255));
            if (w.EvChargeLevel > 0.95f)
            {
                Shake = Math.Max(Shake, 0.15f);
                Flash = Math.Max(Flash, 0.08f);
            }
        }
        if (w.EvChargeFull)
        {
            w.EvChargeFull = false;
            Sfx.Play(SfxId.ChargeFull);
            Particles.Ring(Player.X + 30f, Player.Y, 50f, Color.White);
        }
        if (Player.EvShieldHit)
        {
            Player.EvShieldHit = false;
            Sfx.Play(SfxId.Shield);
            Particles.Ring(Player.X, Player.Y, 56f, Color.FromArgb(120, 200, 255));
        }
        if (Player.EvRespawned)
        {
            Player.EvRespawned = false;
            Pod.Reset(Player);
            Particles.Ring(Player.X, Player.Y, 60f, Color.White);
        }
    }

    private void HandlePodEvents()
    {
        if (Pod.EvLaunch)
        {
            Pod.EvLaunch = false;
            Sfx.Play(SfxId.PodLaunch);
            Particles.Ring(Pod.X, Pod.Y, 40f, Color.FromArgb(255, 170, 60));
        }
        if (Pod.EvRecall)
        {
            Pod.EvRecall = false;
            Sfx.Play(SfxId.PodRecall);
        }
        if (Pod.EvAttach)
        {
            Pod.EvAttach = false;
            Sfx.Play(SfxId.Click);
            Particles.Ring(Pod.X, Pod.Y, 36f, Color.FromArgb(120, 230, 255));
        }
    }

    public void PodAbsorbed()
    {
        Sfx.Play(SfxId.PodAbsorb);
    }

    private void UpdateBoss()
    {
        if (!bossWarned && StageTime >= GameConfig.BossWarningTime)
        {
            bossWarned = true;
            Banner = "WARNING!";
            BannerTimer = 4f;
            Sfx.Play(SfxId.BossArrive);
        }
        if (!bossSpawned && StageTime >= GameConfig.BossArrivalTime)
        {
            bossSpawned = true;
            Boss.Spawn();
        }

        Boss.Update(Dt, Player.Alive ? Player.X : GameConfig.PlayerStartX, Player.Alive ? Player.Y : GameConfig.PlayerStartY, Shots, Explosions, Particles);
        if (Boss.EvFired) Sfx.Play(SfxId.EnemyShoot);
        for (int i = 0; i < Boss.EvLarvae; i++)
            Enemies.SpawnChild(EnemyType.Larva, Boss.X - 150f, Boss.Y + (float)(rng.NextDouble() * 60.0 - 30.0));
        if (Boss.EvPhaseChanged)
        {
            Shots.ClearEnemy();
            Banner = Boss.Phase == 2 ? "PHASE 2" : "FINAL PHASE";
            BannerTimer = 2f;
            Sfx.Play(SfxId.BigExplosion);
            Shake = 0.4f;
            Flash = 0.25f;
            Explosions.Add(Boss.X - 140f, Boss.Y, ExplosionKind.Large);
            Explosions.Add(Boss.X - 100f, Boss.Y - 70f, ExplosionKind.Large, 0.1f);
            Explosions.Add(Boss.X - 100f, Boss.Y + 70f, ExplosionKind.Large, 0.2f);
        }
        if (Boss.Dying)
        {
            if (Boss.DeathTimer < 0.05f)
            {
                Shots.ClearEnemy();
                Sfx.Play(SfxId.BossDie);
            }
            Shake = Math.Max(Shake, 0.1f);
        }
        if (Boss.EvDeathBlast) Sfx.Play(SfxId.BigExplosion);
        if (Boss.EvDefeated)
        {
            Score += GameConfig.ScoreBoss;
            Shake = 0.8f;
            Flash = 0.6f;
            Sfx.Play(SfxId.BossDie);
            EndGame(true);
        }
    }

    /// <summary>Weak points destroyed by this step's collisions get their own explosion.</summary>
    private void HandleBossPartEvents()
    {
        if (!Boss.EvPartDestroyed) return;
        Boss.EvPartDestroyed = false;
        Explosions.Add(Boss.EvPartX, Boss.EvPartY, ExplosionKind.Large);
        Particles.Debris(Boss.EvPartX, Boss.EvPartY, 14, Color.FromArgb(210, 190, 160));
        Particles.Flames(Boss.EvPartX, Boss.EvPartY, 16f, 8);
        Sfx.Play(SfxId.BigExplosion);
        Shake = Math.Max(Shake, 0.3f);
        Score += 500;
        Particles.Text(Boss.EvPartX, Boss.EvPartY - 30f, "WEAK POINT DESTROYED +500", Color.FromArgb(255, 255, 220, 120));
    }

    private void EndGame(bool victory)
    {
        NewRecord = Scores.Submit(Score);
        ClearInput();
        State = victory ? GameState.Victory : GameState.GameOver;
        if (victory) Sfx.Play(SfxId.Victory);
    }

    // ------------------------------------------------------------------ events from the collision and enemy code

    public void PlayerHit()
    {
        HitResult r = Player.Hit();
        if (r == HitResult.Died)
        {
            Explosions.Add(Player.X, Player.Y, ExplosionKind.Large);
            Particles.Debris(Player.X, Player.Y, 16, Color.FromArgb(180, 190, 210));
            Particles.Flames(Player.X, Player.Y, 8f, 8);
            Sfx.Play(SfxId.Hit);
            Shake = 0.35f;
            Shots.ClearEnemy();          // a fresh start after a death is fairer
            endTimer = 0f;
        }
    }

    public void CollectBonus(Bonus b)
    {
        b.Alive = false;
        Score += GameConfig.ScoreBonusPickup;
        switch (b.Type)
        {
            case BonusType.Weapon:
                if (Player.Weapon.Upgrade())
                {
                    Sfx.Play(SfxId.WeaponUp);
                    BonusText = "WEAPON: " + Player.Weapon.Name + " LV" + Player.Weapon.Level;
                }
                else
                {
                    Score += 500;
                    Sfx.Play(SfxId.Bonus);
                    BonusText = "WEAPON AT MAXIMUM  +500";
                }
                break;
            case BonusType.Shield:
                Player.ShieldTimer = GameConfig.ShieldDuration;
                Sfx.Play(SfxId.Shield);
                BonusText = "SHIELD ACTIVE";
                break;
            case BonusType.Life:
                Player.Lives = Math.Min(GameConfig.MaxLives, Player.Lives + 1);
                Sfx.Play(SfxId.Bonus);
                BonusText = "EXTRA LIFE";
                break;
            case BonusType.Bomb:
                ActivateBomb();
                BonusText = "BOMB - SCREEN CLEARED";
                break;
            default:
                Score += GameConfig.ScoreBonusItem;
                Sfx.Play(SfxId.Bonus);
                BonusText = "BONUS +" + GameConfig.ScoreBonusItem;
                break;
        }
        BonusTimer = 2.4f;
        Particles.Ring(b.X, b.Y, 54f, Color.FromArgb(255, 230, 120));
        Particles.Sparks(b.X, b.Y, 200f, 10, Color.FromArgb(255, 240, 150));
        Particles.Text(b.X, b.Y - 22f, Bonus.Label(b.Type), Color.White);
    }

    private void ActivateBomb()
    {
        Sfx.Play(SfxId.Bomb);
        Shake = 0.55f;
        Flash = 0.5f;
        Particles.Ring(Player.X, Player.Y, 520f, Color.FromArgb(255, 220, 120));
        Enemies.BombAll(GameConfig.BombEnemyDamage);
        Obstacles.BombAll(GameConfig.BombEnemyDamage, Scroll);
        if (Boss.Vulnerable) Boss.BombDamage();
        Shots.ClearEnemy();
    }

    private void OnEnemyKilled(Enemy e)
    {
        Score += e.Score;
        Kills++;
        bool big = e.Type == EnemyType.Heavy || e.Type == EnemyType.Elite;
        Explosions.Add(e.X, e.Y, big ? ExplosionKind.Large : ExplosionKind.Small);
        Particles.Debris(e.X, e.Y, big ? 14 : 5, e.Type == EnemyType.Organic || e.Type == EnemyType.Larva ? Color.FromArgb(220, 120, 150) : Color.FromArgb(150, 160, 190));
        Particles.Flames(e.X, e.Y, big ? 14f : 6f, big ? 8 : 3);
        if (e.Type != EnemyType.Larva) Particles.Text(e.X, e.Y - 16f, e.Score.ToString(), Color.FromArgb(255, 255, 220, 120));
        Sfx.Play(big ? SfxId.BigExplosion : SfxId.Explosion);
        if (big) Shake = Math.Max(Shake, 0.2f);

        switch (e.Type)
        {
            case EnemyType.Fighter:
                if (rng.NextDouble() < 0.07) Bonuses.Spawn(e.X, e.Y, Bonuses.Pick(Player.Weapon.Stage, false));
                break;
            case EnemyType.Interceptor:
                if (rng.NextDouble() < 0.06) Bonuses.Spawn(e.X, e.Y, Bonuses.Pick(Player.Weapon.Stage, false));
                break;
            case EnemyType.Organic:
                if (rng.NextDouble() < 0.12) Bonuses.Spawn(e.X, e.Y, Bonuses.Pick(Player.Weapon.Stage, false));
                break;
            case EnemyType.Heavy:
            case EnemyType.Elite:
                Bonuses.Spawn(e.X, e.Y, Bonuses.Pick(Player.Weapon.Stage, true));
                break;
        }
    }

    private void OnObstacleDestroyed(Obstacle o)
    {
        float sx = o.ScreenX(Scroll);
        bool turret = o.Type == ObstacleType.Turret;
        Score += turret ? GameConfig.ScoreTurret : GameConfig.ScoreAsteroid;
        Explosions.Add(sx, o.Y, o.Radius >= 28f || turret ? ExplosionKind.Large : ExplosionKind.Small);
        Particles.Debris(sx, o.Y, turret ? 10 : 8, turret ? Color.FromArgb(150, 160, 190) : Color.FromArgb(130, 110, 100));
        Sfx.Play(turret ? SfxId.BigExplosion : SfxId.Explosion);
    }
}
