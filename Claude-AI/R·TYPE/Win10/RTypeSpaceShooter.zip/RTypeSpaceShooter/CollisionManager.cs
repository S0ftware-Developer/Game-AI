namespace RTypeSpaceShooter;

/// <summary>All collision tests of the game, in one place.</summary>
public static class CollisionManager
{
    public static bool CircleRect(float cx, float cy, float r, RectangleF rc)
    {
        float nx = Math.Max(rc.Left, Math.Min(cx, rc.Right));
        float ny = Math.Max(rc.Top, Math.Min(cy, rc.Bottom));
        float dx = cx - nx;
        float dy = cy - ny;
        return dx * dx + dy * dy <= r * r;
    }

    public static void Resolve(GameEngine g)
    {
        PlayerShotsVsWorld(g);
        BeamsVsWorld(g);
        EnemyShots(g);
        PodContacts(g);
        if (g.Player.Alive && g.Player.Invuln <= 0f)
        {
            EnemiesVsPlayer(g);
            if (g.Player.Alive && g.Player.Invuln <= 0f) ObstaclesVsPlayer(g);
            if (g.Player.Alive && g.Player.Invuln <= 0f) TerrainVsPlayer(g);
            if (g.Player.Alive && g.Player.Invuln <= 0f) BossVsPlayer(g);
        }
        if (g.Player.Alive) BonusesVsPlayer(g);
    }

    // ------------------------------------------------------------------ player weapons

    private static void PlayerShotsVsWorld(GameEngine g)
    {
        List<Projectile> shots = g.Shots.Player;
        for (int i = 0; i < shots.Count; i++)
        {
            Projectile p = shots[i];
            if (!p.Alive) continue;

            // rock stops every shot
            if (g.Terrain.IsSolid(g.Scroll + p.X, p.Y))
            {
                g.Particles.Sparks(p.X, p.Y, 110f, 3, Color.FromArgb(200, 200, 210));
                p.Alive = false;
                continue;
            }

            // obstacles
            foreach (Obstacle o in g.Obstacles.Items)
            {
                if (!o.Alive || !o.HitsCircle(p.X, p.Y, p.Radius, g.Scroll)) continue;
                if (o.Destructible)
                {
                    if (!p.TryHit(o.Id)) continue;
                    g.Obstacles.Damage(o, p.Damage);
                    g.Particles.Sparks(p.X, p.Y, 150f, 3, Color.FromArgb(255, 230, 140));
                    if (--p.Pierce <= 0) p.Alive = false;
                }
                else
                {
                    g.Particles.Sparks(p.X, p.Y, 100f, 2, Color.FromArgb(200, 210, 220));
                    p.Alive = false;
                }
                break;
            }
            if (!p.Alive) continue;

            // enemies
            foreach (Enemy e in g.Enemies.Enemies)
            {
                if (!e.Alive || e.X > GameConfig.LogicalW + 20f) continue;
                if (!CircleRect(p.X, p.Y, p.Radius, e.Hitbox)) continue;
                if (!p.TryHit(e.Id)) continue;
                g.Enemies.DamageEnemy(e, p.Damage);
                g.Particles.Sparks(p.X, p.Y, 160f, p.Kind == ShotKind.ChargeShot ? 8 : 3, Color.FromArgb(255, 230, 140));
                if (--p.Pierce <= 0) p.Alive = false;
                break;
            }
            if (!p.Alive) continue;

            // boss: weak points take damage, armour absorbs
            if (g.Boss.Vulnerable)
            {
                int part;
                BossHit h = g.Boss.TestHit(p.X, p.Y, p.Radius, out part);
                if (h == BossHit.Weak)
                {
                    if (p.TryHit(-part))
                    {
                        g.Boss.DamagePart(part, part == 3 ? p.Damage * 1.5f : p.Damage);
                        g.Particles.Sparks(p.X, p.Y, 180f, p.Kind == ShotKind.ChargeShot ? 10 : 3, Color.FromArgb(255, 200, 120));
                        if (--p.Pierce <= 0) p.Alive = false;
                    }
                }
                else if (h == BossHit.Armor && p.Kind != ShotKind.ChargeShot)
                {
                    g.Particles.Sparks(p.X, p.Y, 90f, 2, Color.FromArgb(190, 190, 200));
                    p.Alive = false;
                }
            }
        }
    }

    private static void BeamsVsWorld(GameEngine g)
    {
        foreach (LaserBeam b in g.Shots.Beams)
        {
            if (!b.Fresh) continue;
            b.Fresh = false;
            RectangleF rect = new RectangleF(b.X, b.Y - b.Thick / 2f, b.Length, b.Thick);
            foreach (Enemy e in g.Enemies.Enemies)
            {
                if (!e.Alive || e.X > GameConfig.LogicalW + 20f) continue;
                if (e.Hitbox.IntersectsWith(rect))
                {
                    g.Enemies.DamageEnemy(e, b.Damage);
                    g.Particles.Sparks(e.X, e.Y, 170f, 4, Color.FromArgb(255, 120, 200));
                }
            }
            foreach (Obstacle o in g.Obstacles.Items)
            {
                if (o.Alive && o.Destructible && o.HitsRect(rect, g.Scroll)) g.Obstacles.Damage(o, b.Damage);
            }
            if (g.Boss.Vulnerable) g.Boss.BeamDamage(rect, b.Damage);
        }
    }

    // ------------------------------------------------------------------ enemy shots

    private static void EnemyShots(GameEngine g)
    {
        PlayerShip pl = g.Player;
        ForcePod pod = g.Pod;
        List<Projectile> shots = g.Shots.Enemy;
        for (int i = 0; i < shots.Count; i++)
        {
            Projectile s = shots[i];
            if (!s.Alive) continue;

            if (g.Terrain.IsSolid(g.Scroll + s.X, s.Y))
            {
                g.Particles.Sparks(s.X, s.Y, 80f, 2, Color.FromArgb(255, 160, 80));
                s.Alive = false;
                continue;
            }

            // the Force Pod absorbs bullets
            float dx = s.X - pod.X;
            float dy = s.Y - pod.Y;
            float pr = ForcePod.Radius + s.Radius;
            if (dx * dx + dy * dy <= pr * pr)
            {
                s.Alive = false;
                pod.Flash = 0.15f;
                g.Particles.Sparks(s.X, s.Y, 130f, 4, Color.FromArgb(255, 170, 60));
                g.Particles.Ring(pod.X, pod.Y, 34f, Color.FromArgb(255, 160, 60));
                g.PodAbsorbed();
                continue;
            }

            if (pl.Alive && pl.Invuln <= 0f && CircleRect(s.X, s.Y, s.Radius * 0.85f, pl.Hitbox))
            {
                s.Alive = false;
                g.PlayerHit();
            }
        }
    }

    // ------------------------------------------------------------------ Force Pod ramming

    private static void PodContacts(GameEngine g)
    {
        ForcePod pod = g.Pod;
        if (pod.ContactTimer > 0f) return;
        bool hit = false;
        foreach (Enemy e in g.Enemies.Enemies)
        {
            if (!e.Alive || e.X > GameConfig.LogicalW + 20f) continue;
            if (CircleRect(pod.X, pod.Y, ForcePod.Radius, e.Hitbox))
            {
                g.Enemies.DamageEnemy(e, 2f);
                g.Particles.Sparks(e.X, e.Y, 140f, 3, Color.FromArgb(255, 180, 70));
                hit = true;
            }
        }
        foreach (Obstacle o in g.Obstacles.Items)
        {
            if (o.Alive && o.Destructible && o.HitsCircle(pod.X, pod.Y, ForcePod.Radius, g.Scroll))
            {
                g.Obstacles.Damage(o, 2f);
                hit = true;
            }
        }
        if (g.Boss.Vulnerable)
        {
            int part;
            if (g.Boss.TestHit(pod.X, pod.Y, ForcePod.Radius, out part) == BossHit.Weak)
            {
                g.Boss.DamagePart(part, 3f);
                g.Particles.Sparks(pod.X, pod.Y, 160f, 4, Color.FromArgb(255, 180, 70));
                hit = true;
            }
        }
        if (hit) pod.ContactTimer = 0.18f;
    }

    // ------------------------------------------------------------------ the player's body

    private static void EnemiesVsPlayer(GameEngine g)
    {
        RectangleF box = g.Player.Hitbox;
        foreach (Enemy e in g.Enemies.Enemies)
        {
            if (!e.Alive || e.X > GameConfig.LogicalW + 20f) continue;
            if (e.Hitbox.IntersectsWith(box))
            {
                g.Enemies.DamageEnemy(e, 4f);
                g.PlayerHit();
                return;
            }
        }
    }

    private static void ObstaclesVsPlayer(GameEngine g)
    {
        RectangleF box = g.Player.Hitbox;
        foreach (Obstacle o in g.Obstacles.Items)
        {
            if (o.HitsRect(box, g.Scroll))
            {
                g.PlayerHit();
                return;
            }
        }
    }

    private static void TerrainVsPlayer(GameEngine g)
    {
        RectangleF box = g.Player.Hitbox;
        for (float x = box.Left; ; x += 7f)
        {
            float sx = Math.Min(x, box.Right);
            if (g.Terrain.IsSolid(g.Scroll + sx, box.Top) || g.Terrain.IsSolid(g.Scroll + sx, box.Bottom))
            {
                g.PlayerHit();
                return;
            }
            if (sx >= box.Right) break;
        }
    }

    private static void BossVsPlayer(GameEngine g)
    {
        if (g.Boss.ContactsPlayer(g.Player.Hitbox)) g.PlayerHit();
    }

    private static void BonusesVsPlayer(GameEngine g)
    {
        PlayerShip p = g.Player;
        List<Bonus> items = g.Bonuses.Items;
        for (int i = 0; i < items.Count; i++)
        {
            Bonus b = items[i];
            if (!b.Alive) continue;
            if (CircleRect(b.X, b.Y, Bonus.Radius, new RectangleF(p.X - 22f, p.Y - 12f, 44f, 24f))) g.CollectBonus(b);
        }
    }
}
