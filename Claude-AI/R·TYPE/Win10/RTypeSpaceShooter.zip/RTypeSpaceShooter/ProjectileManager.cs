namespace RTypeSpaceShooter;

/// <summary>Owns all player and enemy projectiles and laser beams, creates the common firing patterns and moves everything.</summary>
public sealed class ProjectileManager
{
    public readonly List<Projectile> Player = new List<Projectile>(256);
    public readonly List<Projectile> Enemy = new List<Projectile>(512);
    public readonly List<LaserBeam> Beams = new List<LaserBeam>(8);
    private readonly Stack<Projectile> pool = new Stack<Projectile>(512);

    private Projectile Make()
    {
        Projectile p = pool.Count > 0 ? pool.Pop() : new Projectile();
        p.AX = 0f;
        p.AY = 0f;
        p.Age = 0f;
        p.Damage = 1f;
        p.Charge = 0f;
        p.Pierce = 1;
        p.ResetHits();
        p.Alive = true;
        return p;
    }

    public void Clear()
    {
        foreach (Projectile p in Player) pool.Push(p);
        foreach (Projectile p in Enemy) pool.Push(p);
        Player.Clear();
        Enemy.Clear();
        Beams.Clear();
    }

    public void ClearEnemy()
    {
        foreach (Projectile p in Enemy) pool.Push(p);
        Enemy.Clear();
    }

    public Projectile SpawnPlayer(ShotKind kind, float x, float y, float vx, float vy, float damage, float radius, int pierce)
    {
        Projectile p = Make();
        p.Kind = kind;
        p.X = x; p.Y = y; p.VX = vx; p.VY = vy;
        p.Radius = radius;
        p.Damage = damage;
        p.Pierce = pierce;
        Player.Add(p);
        return p;
    }

    public Projectile SpawnEnemy(ShotKind kind, float x, float y, float vx, float vy)
    {
        Projectile p = Make();
        p.Kind = kind;
        p.X = x; p.Y = y; p.VX = vx; p.VY = vy;
        switch (kind)
        {
            case ShotKind.EnemyOrb: p.Radius = 8f; break;
            case ShotKind.EnemyHeavy: p.Radius = 11f; break;
            case ShotKind.BossOrb: p.Radius = 11f; break;
            case ShotKind.BossBolt: p.Radius = 7f; break;
            default: p.Radius = 5f; break;
        }
        Enemy.Add(p);
        return p;
    }

    public LaserBeam AddBeam(float x, float y, float length, float damage)
    {
        LaserBeam b = new LaserBeam();
        b.X = x; b.Y = y; b.Length = length; b.Damage = damage;
        b.Thick = 10f;
        b.Life = 0.16f;
        Beams.Add(b);
        return b;
    }

    /// <summary>One shot aimed at a target point, rotated by an extra angle (radians).</summary>
    public Projectile FireAimed(ShotKind kind, float x, float y, float tx, float ty, float speed, float angleOffset)
    {
        float a = MathF.Atan2(ty - y, tx - x) + angleOffset;
        return SpawnEnemy(kind, x, y, MathF.Cos(a) * speed, MathF.Sin(a) * speed);
    }

    /// <summary>A fan of shots centred on the target direction.</summary>
    public void FireFan(ShotKind kind, float x, float y, float tx, float ty, float speed, int count, float totalAngle)
    {
        for (int i = 0; i < count; i++)
        {
            float t = count == 1 ? 0f : (i / (float)(count - 1) - 0.5f);
            FireAimed(kind, x, y, tx, ty, speed, t * totalAngle);
        }
    }

    public void FireRing(ShotKind kind, float x, float y, int count, float speed, float phase)
    {
        for (int i = 0; i < count; i++)
        {
            float a = phase + i * MathF.PI * 2f / count;
            SpawnEnemy(kind, x, y, MathF.Cos(a) * speed, MathF.Sin(a) * speed);
        }
    }

    public void Update(float dt)
    {
        Step(Player, dt);
        Step(Enemy, dt);
        for (int i = Beams.Count - 1; i >= 0; i--)
        {
            LaserBeam b = Beams[i];
            b.Age += dt;
            if (b.Age >= b.Life) Beams.RemoveAt(i);
        }
    }

    private void Step(List<Projectile> list, float dt)
    {
        for (int i = list.Count - 1; i >= 0; i--)
        {
            Projectile p = list[i];
            p.Age += dt;
            p.VX += p.AX * dt;
            p.VY += p.AY * dt;
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            bool gone = p.X < -80f || p.X > GameConfig.LogicalW + 80f || p.Y < -80f || p.Y > GameConfig.ViewH + 80f;
            if (!p.Alive || gone)
            {
                p.Alive = false;
                list[i] = list[list.Count - 1];
                list.RemoveAt(list.Count - 1);
                pool.Push(p);
            }
        }
    }
}
