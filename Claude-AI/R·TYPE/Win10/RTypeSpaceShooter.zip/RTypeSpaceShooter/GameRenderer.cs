using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace RTypeSpaceShooter;

/// <summary>
/// Draws the whole screen in logical 960x572 coordinates scaled to the window: the parallax battlefield and terrain
/// (<see cref="BackgroundRenderer"/>), all sprites (<see cref="Sprites"/>), the HUD and the menu screens.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    public static readonly Rectangle PlayButton = new Rectangle(330, 336, 300, 54);
    public static readonly Rectangle ResumeButton = new Rectangle(360, 200, 240, 46);
    public static readonly Rectangle PauseRestartButton = new Rectangle(360, 256, 240, 46);
    public static readonly Rectangle PauseMenuButton = new Rectangle(360, 312, 240, 46);
    public static readonly Rectangle EndRestartButton = new Rectangle(240, 436, 210, 52);
    public static readonly Rectangle EndMenuButton = new Rectangle(510, 436, 210, 52);

    private const int W = GameConfig.LogicalW;
    private const int ViewH = GameConfig.ViewH;

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly BackgroundRenderer bg = new BackgroundRenderer();
    private readonly Sprites sprites = new Sprites();
    private readonly Font fHud;
    private readonly Font fLabel;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fBig;
    private readonly Font fFooter;
    private readonly Font fTitle;
    private readonly Font fSub;
    private readonly Font fBanner;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;
    private readonly StringFormat sfRight;
    private readonly GraphicsPath titleR;
    private readonly GraphicsPath titleType;
    private readonly LinearGradientBrush titleFill;
    private readonly float orbX;
    private readonly Projectile[] menuShots = new Projectile[8];
    private readonly Obstacle[] menuRocks = new Obstacle[3];
    private readonly ForcePod menuPod = new ForcePod();
    private readonly Explosion menuExp = new Explosion();

    public GameRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;

        fHud = new Font("Segoe UI", 22f, FontStyle.Bold, GraphicsUnit.Pixel);
        fLabel = new Font("Segoe UI", 11f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Segoe UI", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Segoe UI", 17f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBig = new Font("Segoe UI", 44f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitle = new Font("Impact", 120f, FontStyle.Regular, GraphicsUnit.Pixel);
        fSub = new Font("Impact", 38f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBanner = new Font("Impact", 58f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;
        sfRight = new StringFormat();
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfRight.FormatFlags = StringFormatFlags.NoWrap;

        // the title: "R", an orange orb, "TYPE"
        titleR = new GraphicsPath();
        titleR.AddString("R", fTitle.FontFamily, (int)FontStyle.Regular, 120f, new PointF(0f, 0f), StringFormat.GenericTypographic);
        titleType = new GraphicsPath();
        titleType.AddString("TYPE", fTitle.FontFamily, (int)FontStyle.Regular, 120f, new PointF(0f, 0f), StringFormat.GenericTypographic);
        RectangleF rb = titleR.GetBounds();
        RectangleF tb = titleType.GetBounds();
        float total = rb.Width + 56f + tb.Width;
        float x0 = (W - total) / 2f;
        float cy = 112f;
        using (Matrix m = new Matrix())
        {
            m.Translate(x0 - rb.X, cy - (rb.Y + rb.Height / 2f));
            titleR.Transform(m);
        }
        using (Matrix m = new Matrix())
        {
            m.Translate(x0 + rb.Width + 56f - tb.X, cy - (tb.Y + tb.Height / 2f));
            titleType.Transform(m);
        }
        orbX = x0 + rb.Width + 28f;
        RectangleF all = RectangleF.Union(titleR.GetBounds(), titleType.GetBounds());
        titleFill = new LinearGradientBrush(new RectangleF(all.X, all.Y, all.Width, all.Height), Color.FromArgb(255, 240, 250, 255), Color.FromArgb(255, 40, 100, 220), 90f);

        for (int i = 0; i < menuShots.Length; i++)
        {
            Projectile p = new Projectile();
            p.Kind = ShotKind.PlayerBullet;
            p.VX = 760f;
            menuShots[i] = p;
        }
        for (int i = 0; i < menuRocks.Length; i++)
        {
            Obstacle o = new Obstacle();
            o.Type = ObstacleType.Asteroid;
            o.W = 56f + i * 22f;
            o.H = o.W;
            o.Variant = i;
            o.Spin = 0.5f - i * 0.3f;
            menuRocks[i] = o;
        }
        menuExp.Kind = ExplosionKind.Large;
        menuExp.Size = 70f;
        menuExp.Duration = 0.7f;
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        bg.Dispose();
        sprites.Dispose();
        fHud.Dispose();
        fLabel.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fBig.Dispose();
        fFooter.Dispose();
        fTitle.Dispose();
        fSub.Dispose();
        fBanner.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        sfRight.Dispose();
        titleR.Dispose();
        titleType.Dispose();
        titleFill.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow) g.DrawString(s, f, B(Color.FromArgb(Math.Min((int)c.A, 200), 0, 0, 20)), x + 2f, y + 2f, sf);
        g.DrawString(s, f, B(c), x, y, sf);
    }

    private static GraphicsPath RoundRect(float x, float y, float w, float h, float r)
    {
        GraphicsPath p = new GraphicsPath();
        float d = r * 2f;
        p.AddArc(x, y, d, d, 180f, 90f);
        p.AddArc(x + w - d, y, d, d, 270f, 90f);
        p.AddArc(x + w - d, y + h - d, d, d, 0f, 90f);
        p.AddArc(x, y + h - d, d, d, 90f, 90f);
        p.CloseFigure();
        return p;
    }

    private void Panel(Graphics g, float x, float y, float w, float h, int alpha)
    {
        using (GraphicsPath p = RoundRect(x, y, w, h, 9f))
        {
            g.FillPath(B(Color.FromArgb(alpha, 6, 12, 32)), p);
            g.DrawPath(P(Color.FromArgb(255, 60, 150, 220), 2f), p);
        }
    }

    private void Button(Graphics g, Rectangle r, string text, bool primary, float clock)
    {
        using (GraphicsPath p = RoundRect(r.X, r.Y, r.Width, r.Height, 8f))
        {
            g.FillPath(B(primary ? Color.FromArgb(255, 8, 22, 50) : Color.FromArgb(255, 14, 26, 50)), p);
            float k = primary ? 0.5f + 0.5f * MathF.Sin(clock * 4f) : 1f;
            g.DrawPath(P(Color.FromArgb(A(170 + 85 * k), 60, 220, 255), 3f), p);
        }
        Txt(g, text, fText, Color.White, r.X + r.Width / 2f, r.Y + r.Height / 2f, sfCenter, true);
    }

    private static string FormatTime(float seconds)
    {
        int total = (int)seconds;
        return (total / 60).ToString("D2") + ":" + (total % 60).ToString("D2");
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)GameConfig.LogicalW, clientH / (float)GameConfig.LogicalH);
        float offX = (clientW - GameConfig.LogicalW * scale) / 2f;
        float offY = (clientH - GameConfig.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, GameConfig.LogicalW, GameConfig.LogicalH));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (e.State == GameState.Menu) DrawMenu(g, e);
            else
            {
                DrawGame(g, e);
                if (e.State == GameState.Paused) DrawPause(g, e);
                else if (e.State == GameState.GameOver) DrawEnd(g, e, false);
                else if (e.State == GameState.Victory) DrawEnd(g, e, true);
            }
            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ battlefield

    private void DrawGame(Graphics g, GameEngine e)
    {
        GraphicsState outer = g.Save();
        g.SetClip(new Rectangle(0, 0, W, ViewH));
        bg.Draw(g, e.Scroll, e.Clock);

        if (e.Shake > 0f)
        {
            g.TranslateTransform(MathF.Sin(e.Clock * 150f) * e.Shake * 14f, MathF.Cos(e.Clock * 130f) * e.Shake * 12f);
        }
        bg.DrawTerrain(g, e.Terrain, e.Scroll, e.Clock);

        float px = e.Player.Alive ? e.Player.X : GameConfig.PlayerStartX;
        float py = e.Player.Alive ? e.Player.Y : GameConfig.PlayerStartY;
        foreach (Obstacle o in e.Obstacles.Items) sprites.DrawObstacle(g, o, e.Scroll, e.Clock, px, py);
        foreach (Bonus b in e.Bonuses.Items) sprites.DrawBonus(g, b, e.Clock);
        foreach (Enemy en in e.Enemies.Enemies)
        {
            if (!en.Alive || en.X < -80f || en.X > W + 80f) continue;
            sprites.DrawEnemy(g, en, e.Clock);
        }
        if (e.Boss.Active) sprites.DrawBoss(g, e.Boss, e.Clock);

        sprites.DrawPod(g, e.Pod, e.Clock);
        sprites.DrawPlayer(g, e.Player, e.Clock);
        foreach (Projectile p in e.Shots.Player) sprites.DrawProjectile(g, p, e.Clock);
        foreach (LaserBeam b in e.Shots.Beams) sprites.DrawBeam(g, b);
        foreach (Projectile p in e.Shots.Enemy) sprites.DrawProjectile(g, p, e.Clock);
        foreach (Explosion x in e.Explosions.Items) sprites.DrawExplosion(g, x);
        sprites.DrawParticles(g, e.Particles);

        g.Restore(outer);

        if (e.Flash > 0f) g.FillRectangle(B(Color.FromArgb(A(150 * e.Flash / 0.5f), 255, 245, 220)), 0, 0, W, ViewH);
        DrawHud(g, e);
    }

    private void DrawBar(Graphics g, float x, float y, float w, float h, float fill, Color c)
    {
        g.FillRectangle(B(Color.FromArgb(200, 8, 12, 26)), x, y, w, h);
        if (fill > 0f) g.FillRectangle(B(c), x + 1f, y + 1f, (w - 2f) * Math.Min(1f, fill), h - 2f);
        g.DrawRectangle(P(Color.FromArgb(255, 130, 170, 215), 1.2f), x, y, w, h);
    }

    private void DrawHud(Graphics g, GameEngine e)
    {
        // top strip: score, best score, lives
        g.FillRectangle(B(Color.FromArgb(150, 4, 8, 24)), 0, 0, W, 42);
        g.FillRectangle(B(Color.FromArgb(255, 60, 170, 230)), 0, 42, W, 2);
        Txt(g, "SCORE", fLabel, Color.FromArgb(255, 130, 190, 255), 16f, 11f, sfLeft, false);
        Txt(g, e.Score.ToString("D7"), fHud, Color.White, 16f, 29f, sfLeft, true);
        Txt(g, "BEST", fLabel, Color.FromArgb(255, 130, 190, 255), 250f, 11f, sfLeft, false);
        Txt(g, Math.Max(e.Scores.Best, e.Score).ToString("D7"), fHud, Color.FromArgb(255, 255, 220, 90), 250f, 29f, sfLeft, true);

        // mission progress in the middle of the strip
        Txt(g, "MISSION", fLabel, Color.FromArgb(255, 130, 190, 255), 480f, 11f, sfLeft, false);
        float bx = 480f;
        float bw = 300f;
        g.FillRectangle(B(Color.FromArgb(170, 6, 12, 30)), bx, 24f, bw, 10f);
        g.FillRectangle(B(Color.FromArgb(235, 90, 210, 255)), bx, 24f, bw * e.StageProgress, 10f);
        g.DrawRectangle(P(Color.FromArgb(220, 130, 170, 215), 1f), bx, 24f, bw, 10f);
        for (int k = 1; k < 6; k++) g.DrawLine(P(Color.FromArgb(120, 130, 170, 215), 1f), bx + bw * k / 6f, 24f, bx + bw * k / 6f, 34f);
        g.FillEllipse(B(Color.FromArgb(255, 230, 60, 60)), bx + bw - 6f, 22f, 14f, 14f);
        float mx = bx + bw * e.StageProgress;
        g.FillEllipse(B(Color.White), mx - 4f, 25f, 8f, 8f);

        Txt(g, "LIVES", fLabel, Color.FromArgb(255, 130, 190, 255), W - 16f, 11f, sfRight, false);
        int shown = Math.Min(e.Player.Lives, 5);
        for (int i = 0; i < shown; i++) sprites.DrawShipBody(g, W - 34f - i * 34f, 30f, 0f, e.Clock, 0f, 0.36f, 1f, false);
        if (e.Player.Lives <= 0) Txt(g, "0", fText, Color.FromArgb(255, 255, 110, 100), W - 22f, 30f, sfRight, true);
        else if (e.Player.Lives > 5) Txt(g, "+" + (e.Player.Lives - 5), fSmall, Color.White, W - 34f - 5 * 34f, 30f, sfRight, true);

        // boss health
        if (e.Boss.Active)
        {
            Txt(g, "ALIEN GUARDIAN", fLabel, Color.FromArgb(255, 255, 150, 140), W / 2f, 58f, sfCenter, true);
            float hx = 220f;
            float hw = W - 440f;
            Color fc = e.Boss.HitFlash > 0f ? Color.White : Color.FromArgb(255, 226, 40, 50);
            DrawBar(g, hx, 68f, hw, 14f, e.Boss.HealthFraction, fc);
            g.DrawLine(P(Color.FromArgb(220, 255, 255, 255), 1.5f), hx + hw * 0.66f, 68f, hx + hw * 0.66f, 82f);
            g.DrawLine(P(Color.FromArgb(220, 255, 255, 255), 1.5f), hx + hw * 0.33f, 68f, hx + hw * 0.33f, 82f);
        }

        // bottom panel: weapon, charge, force pod, shield, kills
        float py = ViewH - 50f;
        Panel(g, 8f, py, W - 16f, 42f, 160);
        WeaponSystem w = e.Player.Weapon;
        Txt(g, "WEAPON", fLabel, Color.FromArgb(255, 130, 190, 255), 22f, py + 11f, sfLeft, false);
        Txt(g, w.Name + " LV" + w.Level, fText, Color.White, 22f, py + 28f, sfLeft, true);
        for (int i = 0; i <= WeaponSystem.MaxStage; i++)
        {
            bool on = i <= w.Stage;
            g.FillRectangle(B(on ? Color.FromArgb(255, 255, 206, 60) : Color.FromArgb(150, 60, 70, 100)), 150f + i * 16f, py + 22f, 13f, 10f);
        }

        Txt(g, w.Charge >= 1f ? "CHARGE [C]  FULL!" : "CHARGE [C]", fLabel, w.Charge >= 1f ? Color.FromArgb(255, 255, 255, 255) : Color.FromArgb(255, 130, 190, 255), 280f, py + 11f, sfLeft, false);
        DrawBar(g, 280f, py + 22f, 170f, 11f, w.Charge, w.Charge >= 1f ? Color.FromArgb(255, 255, 255, 255) : Color.FromArgb(255, 90, 190, 255));

        Color podC = e.Pod.State == PodState.Launched ? Color.FromArgb(255, 255, 160, 70) : (e.Pod.State == PodState.Returning ? Color.FromArgb(255, 255, 230, 110) : Color.FromArgb(255, 110, 230, 255));
        Txt(g, "FORCE POD [X]", fLabel, Color.FromArgb(255, 130, 190, 255), 480f, py + 11f, sfLeft, false);
        g.FillEllipse(B(podC), 480f, py + 22f, 12f, 12f);
        Txt(g, e.Pod.StatusText, fSmall, podC, 498f, py + 28f, sfLeft, true);

        float sh = e.Player.ShieldTimer / GameConfig.ShieldDuration;
        Txt(g, "SHIELD", fLabel, Color.FromArgb(255, 130, 190, 255), 650f, py + 11f, sfLeft, false);
        DrawBar(g, 650f, py + 22f, 120f, 11f, sh, Color.FromArgb(255, 80, 160, 255));

        Txt(g, "KILLS", fLabel, Color.FromArgb(255, 130, 190, 255), W - 24f, py + 11f, sfRight, false);
        Txt(g, e.Kills.ToString(), fText, Color.White, W - 24f, py + 28f, sfRight, true);

        // last collected bonus
        if (e.BonusTimer > 0f && e.BonusText.Length > 0)
        {
            float a = Math.Min(1f, e.BonusTimer * 1.5f);
            Txt(g, e.BonusText, fText, Color.FromArgb(A(255 * a), 255, 240, 160), W / 2f, py - 16f, sfCenter, true);
        }

        // banners
        if (e.BannerTimer > 0f && e.Banner.Length > 0)
        {
            float a = Math.Min(1f, e.BannerTimer * 1.5f);
            bool warn = e.Banner == "WARNING!";
            bool blink = !warn || ((int)(e.Clock * 6f) & 1) == 0;
            Color c = warn ? Color.FromArgb(A(255 * a), 255, blink ? 70 : 255, blink ? 60 : 255) : Color.FromArgb(A(255 * a), 255, 255, 255);
            Txt(g, e.Banner, fBanner, c, W / 2f, 210f, sfCenter, true);
            if (warn) Txt(g, "A COLOSSAL ALIEN LIFEFORM IS APPROACHING", fText, Color.FromArgb(A(255 * a), 255, 220, 200), W / 2f, 256f, sfCenter, true);
        }
    }

    // ------------------------------------------------------------------ menu

    private void DrawMenu(Graphics g, GameEngine e)
    {
        float clock = e.Clock;
        GraphicsState outer = g.Save();
        g.SetClip(new Rectangle(0, 0, W, ViewH));
        bg.Draw(g, clock * 110f, clock);

        // asteroids drifting by
        for (int i = 0; i < menuRocks.Length; i++)
        {
            Obstacle o = menuRocks[i];
            o.WX = W + 80f - ((clock * (50f + i * 18f) + i * 420f) % (W + 260f)) + 20f;
            o.Y = 120f + i * 150f + MathF.Sin(clock * 0.6f + i) * 24f;
            o.Rot = clock * o.Spin;
            sprites.DrawObstacle(g, o, 0f, clock, 0f, 0f);
        }

        // jellyfish-like creatures and other enemies
        EnemyType[] types = { EnemyType.Organic, EnemyType.Organic, EnemyType.Fighter, EnemyType.Organic, EnemyType.Interceptor, EnemyType.Heavy };
        for (int k = 0; k < types.Length; k++)
        {
            float x = W + 60f - ((clock * (40f + k * 9f) + k * 240f) % (W + 220f));
            float y = 90f + (k * 83f) % 340f + MathF.Sin(clock * 0.9f + k) * 30f;
            sprites.DrawEnemyShape(g, types[k], x, y, MathF.Cos(clock * 0.9f + k) * 0.4f, 0f, clock + k, 1f, 1f);
        }

        // the player's ship with its Force Pod, firing
        float shipX = 190f;
        float shipY = 292f + MathF.Sin(clock * 1.7f) * 12f;
        menuPod.X = shipX + ForcePod.SlotDistance;
        menuPod.Y = shipY;
        menuPod.Spin = clock * 2.5f;
        for (int i = 0; i < menuShots.Length; i++)
        {
            Projectile p = menuShots[i];
            p.X = shipX + 40f + ((clock * 520f + i * 105f) % 760f);
            p.Y = shipY;
            sprites.DrawProjectile(g, p, clock);
        }
        sprites.DrawShipBody(g, shipX, shipY, MathF.Sin(clock * 1.7f) * 0.4f, clock, 0.3f, 1.5f, 1f, ((int)(clock * 10f) & 1) == 0);
        sprites.DrawPod(g, menuPod, clock);

        float ea = clock % 2.6f;
        if (ea < menuExp.Duration)
        {
            menuExp.X = 720f;
            menuExp.Y = 250f;
            menuExp.Age = ea;
            sprites.DrawExplosion(g, menuExp);
        }
        g.Restore(outer);

        // title
        g.FillRectangle(B(Color.FromArgb(60, 2, 6, 24)), 0, 0, W, 250);
        g.DrawPath(P(Color.FromArgb(255, 6, 14, 50), 14f), titleR);
        g.DrawPath(P(Color.FromArgb(255, 6, 14, 50), 14f), titleType);
        g.FillPath(titleFill, titleR);
        g.FillPath(titleFill, titleType);
        g.DrawPath(P(Color.FromArgb(160, 170, 220, 255), 2f), titleR);
        g.DrawPath(P(Color.FromArgb(160, 170, 220, 255), 2f), titleType);
        float orbPulse = 0.7f + 0.3f * MathF.Sin(clock * 4f);
        g.FillEllipse(B(Color.FromArgb(A(70 * orbPulse), 255, 120, 30)), orbX - 28f, 84f, 56f, 56f);
        g.FillEllipse(B(Color.FromArgb(255, 255, 150, 40)), orbX - 13f, 99f, 26f, 26f);
        g.FillEllipse(B(Color.FromArgb(255, 255, 230, 160)), orbX - 6f, 102f, 12f, 12f);
        // the glowing orange line under the title
        g.FillRectangle(B(Color.FromArgb(70, 255, 100, 20)), 70f, 178f, W - 140f, 8f);
        g.FillRectangle(B(Color.FromArgb(255, 255, 150, 60)), 70f, 181f, W - 140f, 2.5f);
        Txt(g, "SPACE SHOOTER", fSub, Color.FromArgb(255, 150, 225, 255), W / 2f, 212f, sfCenter, true);

        Button(g, PlayButton, "PLAY  [ENTER]", true, clock);
        Txt(g, "BEST SCORE  " + e.Scores.Best.ToString("D7"), fText, Color.FromArgb(255, 255, 224, 100), W / 2f, 412f, sfCenter, true);
        Txt(g, "W A S D / ARROWS - move       SPACE - fire (hold)       C - hold to charge, release to fire the wave cannon", fSmall, Color.White, W / 2f, 446f, sfCenter, true);
        Txt(g, "X - launch / recall the Force Pod       ESC / P - pause       R - restart       N - sound       F11 - fullscreen", fSmall, Color.FromArgb(255, 210, 225, 250), W / 2f, 468f, sfCenter, true);
        Txt(g, "Collect bonuses, survive six sections and destroy the weak points of the final guardian!", fSmall, Color.FromArgb(255, 210, 225, 250), W / 2f, 490f, sfCenter, true);
    }

    // ------------------------------------------------------------------ overlays

    private void DrawPause(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(170, 2, 6, 20)), 0, 0, W, ViewH);
        Txt(g, "PAUSED", fBig, Color.White, W / 2f, 140f, sfCenter, true);
        Button(g, ResumeButton, "RESUME  [ESC]", true, e.Clock);
        Button(g, PauseRestartButton, "RESTART  [R]", false, e.Clock);
        Button(g, PauseMenuButton, "MAIN MENU  [M]", false, e.Clock);
    }

    private void DrawEnd(Graphics g, GameEngine e, bool victory)
    {
        g.FillRectangle(B(Color.FromArgb(180, 2, 6, 20)), 0, 0, W, ViewH);
        Panel(g, 180f, 50f, 600f, 460f, 244);
        if (victory)
        {
            Txt(g, "MISSION COMPLETED!", fBig, Color.FromArgb(255, 255, 220, 80), W / 2f, 100f, sfCenter, true);
            Txt(g, "BOSS DEFEATED", fMid, Color.FromArgb(255, 120, 255, 160), W / 2f, 150f, sfCenter, true);
        }
        else
        {
            Txt(g, "GAME OVER", fBig, Color.FromArgb(255, 255, 90, 80), W / 2f, 110f, sfCenter, true);
        }
        float y0 = victory ? 190f : 170f;
        Txt(g, "FINAL SCORE", fLabel, Color.FromArgb(255, 130, 190, 255), W / 2f, y0, sfCenter, false);
        Txt(g, e.Score.ToString("D7"), fBig, Color.White, W / 2f, y0 + 36f, sfCenter, true);
        if (e.NewRecord) Txt(g, "NEW RECORD!", fText, Color.FromArgb(255, 255, 230, 90), W / 2f, y0 + 78f, sfCenter, true);
        float y = y0 + 108f;
        Txt(g, "BEST SCORE  " + e.Scores.Best.ToString("D7"), fText, Color.FromArgb(255, 255, 224, 100), W / 2f, y, sfCenter, true);
        Txt(g, "ENEMIES DESTROYED  " + e.Kills, fText, Color.White, W / 2f, y + 30f, sfCenter, true);
        if (victory)
        {
            Txt(g, "COMPLETION TIME  " + FormatTime(e.PlayTime), fText, Color.White, W / 2f, y + 60f, sfCenter, true);
            Txt(g, "LIVES REMAINING  " + e.Player.Lives, fText, Color.White, W / 2f, y + 90f, sfCenter, true);
        }
        Button(g, EndRestartButton, "RESTART  [R]", true, e.Clock);
        Button(g, EndMenuButton, "MAIN MENU  [M]", false, e.Clock);
    }

    private void DrawFooter(Graphics g)
    {
        Rectangle r = new Rectangle(0, GameConfig.LogicalH - GameConfig.FooterH, W, GameConfig.FooterH);
        g.FillRectangle(B(Color.FromArgb(255, 4, 8, 22)), r);
        g.FillRectangle(B(Color.FromArgb(255, 60, 170, 230)), 0, r.Y, W, 2);
        g.DrawString(FooterText, fFooter, B(Color.FromArgb(255, 220, 232, 252)),
            new RectangleF(0f, r.Y + 3f, W, r.Height - 3f), sfCenter);
    }
}
