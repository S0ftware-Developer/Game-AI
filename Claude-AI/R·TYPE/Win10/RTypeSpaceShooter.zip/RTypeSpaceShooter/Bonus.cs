namespace RTypeSpaceShooter;

public enum BonusType { Weapon, Shield, Life, Bomb, Score }

/// <summary>A floating collectible.</summary>
public sealed class Bonus
{
    public float X, Y, BaseY, Age;
    public BonusType Type;
    public bool Alive;
    public const float Radius = 17f;

    public static string Label(BonusType t)
    {
        switch (t)
        {
            case BonusType.Weapon: return "WEAPON UP!";
            case BonusType.Shield: return "SHIELD!";
            case BonusType.Life: return "EXTRA LIFE!";
            case BonusType.Bomb: return "BOMB!";
            default: return "+" + GameConfig.ScoreBonusItem;
        }
    }
}
