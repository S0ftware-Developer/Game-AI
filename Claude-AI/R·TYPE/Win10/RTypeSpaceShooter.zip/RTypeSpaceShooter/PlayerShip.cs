namespace RTypeSpaceShooter;

public struct PlayerInput
{
    public bool Up, Down, Left, Right, Fire, Charge, PodPressed;
}

public enum HitResult { None, Shielded, Died }

/// <summary>The player's fighter: smooth movement, weapons, shield, lives and respawn.</summary>
public sealed class PlayerShip
{
    public float X, Y, VX, VY;
    public float Bank;                // -1..1 vertical tilt for the animation
    public int Lives = GameConfig.StartLives;
    public bool Alive = true;
    public float RespawnTimer;
    public float Invuln;
    public float ShieldTimer;
    public float ShieldFlash;
    public float Age;
    public readonly WeaponSystem Weapon = new WeaponSystem();

    // events read (and cleared) by the engine
    public bool EvShieldHit, EvRespawned;

    public RectangleF Hitbox
    {
        get { return new RectangleF(X - 14f, Y - 6f, 28f, 12f); }
    }

    public bool IsInvulnerable { get { return !Alive || Invuln > 0f || ShieldTimer > 0f; } }

    public void Reset(float spawnY)
    {
        Lives = GameConfig.StartLives;
        ShieldTimer = 0f;
        Weapon.Reset();
        Respawn(spawnY);
        Invuln = 1.5f;
        EvRespawned = false;
    }

    public void Respawn(float spawnY)
    {
        X = GameConfig.PlayerStartX;
        Y = spawnY;
        VX = 0f;
        VY = 0f;
        Bank = 0f;
        Alive = true;
        Invuln = GameConfig.RespawnInvulnerability;
        Weapon.Charging = false;
        Weapon.Charge = 0f;
        EvRespawned = true;
    }

    private static float Approach(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    public void Update(float dt, PlayerInput inp, ProjectileManager shots, Terrain terrain, float scroll, ForcePod pod, float respawnY)
    {
        Age += dt;
        if (!Alive)
        {
            if (Lives > 0)
            {
                RespawnTimer -= dt;
                if (RespawnTimer <= 0f) Respawn(respawnY);
            }
            return;
        }

        if (Invuln > 0f) Invuln = Math.Max(0f, Invuln - dt);
        if (ShieldTimer > 0f) ShieldTimer = Math.Max(0f, ShieldTimer - dt);
        if (ShieldFlash > 0f) ShieldFlash = Math.Max(0f, ShieldFlash - dt);

        float dx = (inp.Right ? 1f : 0f) - (inp.Left ? 1f : 0f);
        float dy = (inp.Down ? 1f : 0f) - (inp.Up ? 1f : 0f);
        float len = MathF.Sqrt(dx * dx + dy * dy);
        if (len > 0f)
        {
            dx /= len;       // diagonals are not faster
            dy /= len;
        }
        float max = GameConfig.PlayerMaxSpeed;
        VX = Approach(VX, dx * max, (dx != 0f ? GameConfig.PlayerAccel : GameConfig.PlayerDecel) * dt);
        VY = Approach(VY, dy * max, (dy != 0f ? GameConfig.PlayerAccel : GameConfig.PlayerDecel) * dt);
        X += VX * dt;
        Y += VY * dt;
        if (X < 26f) { X = 26f; VX = 0f; }
        if (X > GameConfig.LogicalW - 40f) { X = GameConfig.LogicalW - 40f; VX = 0f; }
        if (Y < 20f) { Y = 20f; VY = 0f; }
        if (Y > GameConfig.ViewH - 20f) { Y = GameConfig.ViewH - 20f; VY = 0f; }
        Bank = Approach(Bank, Math.Max(-1f, Math.Min(1f, VY / max)), 8f * dt);

        Weapon.Update(dt, this, inp.Fire, inp.Charge, shots, terrain, scroll, pod);
        if (Weapon.EvShot || Weapon.EvLaser) Weapon.PodVolley(shots, pod);
    }

    /// <summary>Called when something dangerous touches the ship.</summary>
    public HitResult Hit()
    {
        if (!Alive || Invuln > 0f) return HitResult.None;
        if (ShieldTimer > 0f)
        {
            ShieldFlash = 0.25f;
            EvShieldHit = true;
            return HitResult.Shielded;
        }
        Lives--;
        Alive = false;
        RespawnTimer = GameConfig.RespawnDelay;
        return HitResult.Died;
    }
}
