namespace RTypeSpaceShooter;

public struct EnemySpawn
{
    public float T;
    public EnemyType Type;
    public float Y, Amp, Freq, Phase;
}

/// <summary>The scripted wave timeline of the mission, plus ownership and updating of all enemies.</summary>
public sealed class EnemyManager
{
    public readonly List<Enemy> Enemies = new List<Enemy>(48);
    public Action<Enemy>? Killed;                 // an enemy was shot down

    private readonly List<EnemySpawn> script = new List<EnemySpawn>(128);
    private readonly List<Enemy> children = new List<Enemy>(8);
    private readonly Stack<Enemy> pool = new Stack<Enemy>();
    private readonly Random rng = new Random();
    private float childDiff;
    private int next;

    public bool ScriptDone { get { return next >= script.Count; } }

    public void Reset()
    {
        foreach (Enemy e in Enemies) pool.Push(e);
        Enemies.Clear();
        children.Clear();
        script.Clear();
        next = 0;
        BuildScript();
    }

    // ------------------------------------------------------------------ the mission script

    private void E(float t, EnemyType type, float y, float amp = 0f, float freq = 0f, float phase = 0f)
    {
        EnemySpawn s = new EnemySpawn();
        s.T = t; s.Type = type; s.Y = y; s.Amp = amp; s.Freq = freq; s.Phase = phase;
        script.Add(s);
    }

    private void Row(float t, float step, EnemyType type, float amp, float freq, params float[] ys)
    {
        for (int i = 0; i < ys.Length; i++) E(t + i * step, type, ys[i], amp, freq, 0f);
    }

    private void BuildScript()
    {
        // section 1: deep space - fighters, the first interceptors and organic creatures, the first heavy ship
        Row(3f, 0.6f, EnemyType.Fighter, 0f, 0f, 270f, 200f, 340f);
        Row(9f, 0.4f, EnemyType.Fighter, 60f, 2f, 120f, 200f, 280f, 360f, 440f);
        E(16f, EnemyType.Interceptor, 90f);
        E(17f, EnemyType.Interceptor, 450f);
        Row(22f, 0.5f, EnemyType.Fighter, 40f, 1.5f, 150f, 250f, 350f, 450f);
        E(28f, EnemyType.Organic, 270f);
        Row(34f, 0.5f, EnemyType.Interceptor, 0f, 0f, 130f, 270f, 410f);
        E(40f, EnemyType.Heavy, 270f);
        Row(41f, 0.5f, EnemyType.Fighter, 50f, 2f, 160f, 380f);
        E(46f, EnemyType.Organic, 150f);
        E(48f, EnemyType.Organic, 400f);

        // section 2: planet surface
        Row(52f, 0.4f, EnemyType.Fighter, 70f, 2f, 100f, 180f, 260f, 340f, 420f);
        E(60f, EnemyType.Interceptor, 100f);
        E(61f, EnemyType.Interceptor, 400f);
        E(62f, EnemyType.Interceptor, 250f);
        E(66f, EnemyType.Organic, 160f);
        E(68f, EnemyType.Organic, 360f);
        E(74f, EnemyType.Heavy, 220f);
        Row(76f, 0.5f, EnemyType.Fighter, 60f, 2f, 150f, 300f, 420f);
        Row(82f, 0.4f, EnemyType.Fighter, 80f, 2.2f, 110f, 190f, 270f, 350f, 430f);
        E(88f, EnemyType.Elite, 270f);
        Row(92f, 0.5f, EnemyType.Interceptor, 0f, 0f, 100f, 230f, 360f, 440f);

        // section 3: asteroid field
        Row(98f, 0.5f, EnemyType.Fighter, 50f, 2f, 120f, 220f, 320f, 420f);
        E(106f, EnemyType.Organic, 270f);
        E(112f, EnemyType.Heavy, 150f);
        E(114f, EnemyType.Heavy, 390f);
        Row(120f, 0.4f, EnemyType.Interceptor, 0f, 0f, 100f, 180f, 260f, 340f, 420f);
        E(126f, EnemyType.Elite, 200f);
        Row(128f, 0.5f, EnemyType.Fighter, 60f, 2f, 300f, 380f, 460f);

        // section 4: alien industrial corridors
        Row(138f, 0.6f, EnemyType.Fighter, 30f, 2f, 270f, 270f, 270f);
        E(144f, EnemyType.Interceptor, 270f);
        E(146f, EnemyType.Interceptor, 270f);
        E(152f, EnemyType.Heavy, 270f);
        Row(158f, 0.5f, EnemyType.Fighter, 30f, 2f, 270f, 270f, 270f, 270f);
        E(165f, EnemyType.Organic, 270f);
        E(170f, EnemyType.Elite, 270f);

        // section 5: organic architecture
        E(177f, EnemyType.Organic, 200f);
        E(179f, EnemyType.Organic, 340f);
        Row(184f, 0.4f, EnemyType.Interceptor, 0f, 0f, 200f, 270f, 340f);
        E(190f, EnemyType.Heavy, 270f);
        E(196f, EnemyType.Organic, 160f);
        E(197f, EnemyType.Organic, 380f);
        E(202f, EnemyType.Elite, 270f);
        Row(208f, 0.5f, EnemyType.Fighter, 40f, 2f, 200f, 270f, 340f);

        // section 6: the mechanical installation before the boss
        E(216f, EnemyType.Heavy, 160f);
        E(217f, EnemyType.Heavy, 380f);
        Row(222f, 0.4f, EnemyType.Interceptor, 0f, 0f, 130f, 200f, 270f, 340f, 410f);
        E(228f, EnemyType.Elite, 200f);
        E(230f, EnemyType.Elite, 340f);

        script.Sort((a, b) => a.T.CompareTo(b.T));
    }

    // ------------------------------------------------------------------ simulation

    private Enemy Take()
    {
        return pool.Count > 0 ? pool.Pop() : new Enemy();
    }

    /// <summary>Used by organic creatures and the boss to release small enemies.</summary>
    public void SpawnChild(EnemyType type, float x, float y)
    {
        Enemy e = Take();
        e.Init(type, x, y, 0f, 0f, 0f, childDiff, rng);
        children.Add(e);
    }

    public void Update(float dt, float stageTime, PlayerShip player, float diff, ProjectileManager shots, ParticleSystem parts, Terrain terrain, float scroll, out bool anyFired)
    {
        anyFired = false;
        childDiff = diff;
        while (next < script.Count && script[next].T <= stageTime)
        {
            EnemySpawn s = script[next++];
            float wx = scroll + GameConfig.LogicalW + 40f;
            float top, bot;
            terrain.Thickness(wx, out top, out bot);
            float y = s.Y;
            float lo = top + 34f;
            float hi = GameConfig.ViewH - bot - 34f;
            if (hi < lo) y = (lo + hi) / 2f;
            else y = Math.Max(lo, Math.Min(hi, y));
            Enemy e = Take();
            e.Init(s.Type, GameConfig.LogicalW + 40f, y, s.Amp, s.Freq, s.Phase, diff, rng);
            Enemies.Add(e);
        }

        float px = player.Alive ? player.X : GameConfig.PlayerStartX;
        float py = player.Alive ? player.Y : GameConfig.PlayerStartY;
        for (int i = Enemies.Count - 1; i >= 0; i--)
        {
            Enemy e = Enemies[i];
            if (e.Alive)
            {
                bool fired;
                e.Update(dt, px, py, diff, shots, this, rng, out fired);
                if (fired) anyFired = true;
                if (e.Smoking)
                {
                    e.SmokeTimer -= dt;
                    if (e.SmokeTimer <= 0f)
                    {
                        e.SmokeTimer = 0.07f;
                        parts.Smoke(e.X + e.HitW * 0.5f, e.Y + (float)(rng.NextDouble() * 8.0 - 4.0), 40f, 0f, 7f, 0.8f, 40);
                    }
                }
                if (e.X < -90f || e.Y < -90f || e.Y > GameConfig.ViewH + 90f) e.Alive = false;
            }
            if (!e.Alive)
            {
                Enemies[i] = Enemies[Enemies.Count - 1];
                Enemies.RemoveAt(Enemies.Count - 1);
                pool.Push(e);
            }
        }
        if (children.Count > 0)
        {
            Enemies.AddRange(children);
            children.Clear();
        }
    }

    /// <summary>Applies damage; destroys the enemy and reports it when its durability is used up.</summary>
    public void DamageEnemy(Enemy e, float amount)
    {
        if (!e.Alive) return;
        e.Damage(amount);
        if (e.Hp > 0f) return;
        e.Alive = false;
        Killed?.Invoke(e);
    }

    /// <summary>The nearest living enemy on the screen within a range, for the Force Pod's auto fire.</summary>
    public bool FindNearest(float x, float y, float range, out float tx, out float ty)
    {
        tx = 0f;
        ty = 0f;
        float best = range * range;
        bool found = false;
        foreach (Enemy e in Enemies)
        {
            if (!e.Alive || e.X > GameConfig.LogicalW + 10f) continue;
            float dx = e.X - x;
            float dy = e.Y - y;
            float d = dx * dx + dy * dy;
            if (d < best)
            {
                best = d;
                tx = e.X;
                ty = e.Y;
                found = true;
            }
        }
        return found;
    }

    /// <summary>The bomb bonus: damages every enemy that is currently on the screen.</summary>
    public void BombAll(float damage)
    {
        foreach (Enemy e in Enemies)
        {
            if (e.Alive && e.X > -20f && e.X < GameConfig.LogicalW + 20f) DamageEnemy(e, damage);
        }
    }
}
