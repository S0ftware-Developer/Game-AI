namespace RTypeSpaceShooter;

/// <summary>Bonuses dropped by destroyed enemies plus the scripted supply drops placed along the mission.</summary>
public sealed class BonusManager
{
    public readonly List<Bonus> Items = new List<Bonus>(16);
    private readonly Random rng = new Random();
    private int next;

    private static readonly (float t, float y, BonusType type)[] Drops =
    {
        (20f, 270f, BonusType.Weapon), (34f, 150f, BonusType.Score), (46f, 380f, BonusType.Shield),
        (56f, 270f, BonusType.Weapon), (72f, 200f, BonusType.Bomb), (86f, 300f, BonusType.Weapon),
        (100f, 250f, BonusType.Shield), (118f, 260f, BonusType.Weapon), (128f, 150f, BonusType.Life),
        (140f, 270f, BonusType.Score), (152f, 270f, BonusType.Shield), (168f, 270f, BonusType.Bomb),
        (180f, 270f, BonusType.Weapon), (196f, 300f, BonusType.Shield), (210f, 270f, BonusType.Life),
        (222f, 270f, BonusType.Bomb), (232f, 270f, BonusType.Shield)
    };

    public void Clear()
    {
        Items.Clear();
        next = 0;
    }

    public void Spawn(float x, float y, BonusType type)
    {
        Bonus b = new Bonus();
        b.X = x;
        b.Y = y;
        b.BaseY = y;
        b.Type = type;
        b.Alive = true;
        Items.Add(b);
    }

    /// <summary>Picks a random bonus. Weapon upgrades are favoured while the weapon is not at its maximum.</summary>
    public BonusType Pick(int weaponStage, bool allowLife)
    {
        int wWeapon = weaponStage < WeaponSystem.MaxStage ? 34 : 6;
        int wShield = 22;
        int wBomb = 16;
        int wScore = 22;
        int wLife = allowLife ? 8 : 0;
        int total = wWeapon + wShield + wBomb + wScore + wLife;
        int r = rng.Next(total);
        if ((r -= wWeapon) < 0) return BonusType.Weapon;
        if ((r -= wShield) < 0) return BonusType.Shield;
        if ((r -= wBomb) < 0) return BonusType.Bomb;
        if ((r -= wScore) < 0) return BonusType.Score;
        return BonusType.Life;
    }

    public void Update(float dt, float stageTime, float scroll, Terrain terrain)
    {
        while (next < Drops.Length && Drops[next].t <= stageTime)
        {
            float wx = scroll + GameConfig.LogicalW + 30f;
            float top, bot;
            terrain.Thickness(wx, out top, out bot);
            float y = Drops[next].y;
            if (top > 0f || bot > 0f) y = terrain.CorridorCenter(wx);
            Spawn(GameConfig.LogicalW + 30f, y, Drops[next].type);
            next++;
        }
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Bonus b = Items[i];
            b.Age += dt;
            b.X -= 55f * dt;
            b.Y = b.BaseY + MathF.Sin(b.Age * 2.5f) * 14f;
            if (!b.Alive || b.X < -30f) Items.RemoveAt(i);
        }
    }
}
