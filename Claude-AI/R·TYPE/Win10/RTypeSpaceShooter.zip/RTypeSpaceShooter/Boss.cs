namespace RTypeSpaceShooter;

public enum BossPattern { EyeOrbs, LaneBolts, Fan, Ring, Spawn, Spiral, Beam, Rest }
public enum BossHit { None, Armor, Weak }

/// <summary>
/// The final boss: a huge bio-mechanical alien skull with two jointed claw arms. Its armour absorbs shots; the two red
/// eyes are always vulnerable and the mouth core opens in phase two. Three phases (by remaining health), each with its
/// own attacks: aimed eye orbs and warned lane bolts; fans, rings and larvae; spirals and a sweeping beam.
/// </summary>
public sealed class Boss
{
    public const float EyeR = 30f;
    public const float CoreR = 40f;
    public const float BeamThick = 30f;

    public bool Active, Entering, Dying;
    public float X, Y, Age, HitFlash, DeathTimer, Openness;
    public float EyeTopHp, EyeBottomHp, CoreHp;
    public int Phase = 1;
    public BossPattern Current = BossPattern.Rest;
    public float LaneY = -1f;             // the row of an announced lane attack (-1 = none)
    public bool BeamWarn, BeamActive;
    public float BeamY;
    public readonly PointF[][] Arms = { new PointF[4], new PointF[4] };

    // events read by the engine
    public bool EvFired, EvPhaseChanged, EvDeathBlast, EvDefeated, EvPartDestroyed;
    public float EvPartX, EvPartY;
    public int EvLarvae;

    private float patternAge, patternDur, attackTimer, spiralAngle, spiralTimer, ringPhase, blastTimer, eyeTimer, laneTime, laneCooldown;
    private int seqIndex, eyeFlip;
    private readonly Random rng = new Random();

    private static readonly BossPattern[][] Sequences =
    {
        new[] { BossPattern.EyeOrbs, BossPattern.LaneBolts, BossPattern.EyeOrbs, BossPattern.Rest },
        new[] { BossPattern.Fan, BossPattern.Ring, BossPattern.Spawn, BossPattern.Fan, BossPattern.Rest },
        new[] { BossPattern.Spiral, BossPattern.Beam, BossPattern.Fan, BossPattern.Ring, BossPattern.Rest }
    };

    public float TotalHp { get { return EyeTopHp + EyeBottomHp + CoreHp; } }
    public float HealthFraction { get { return TotalHp / GameConfig.BossMaxHp; } }
    public bool Vulnerable { get { return Active && !Entering && !Dying; } }
    public bool CoreOpen { get { return Phase >= 2 || (EyeTopHp <= 0f && EyeBottomHp <= 0f); } }

    public PointF EyeTopPos { get { return new PointF(X - 138f, Y - 78f); } }
    public PointF EyeBottomPos { get { return new PointF(X - 138f, Y + 78f); } }
    public PointF CorePos { get { return new PointF(X - 140f, Y); } }
    public RectangleF HeadRect { get { return new RectangleF(X - 140f, Y - 160f, 270f, 320f); } }

    public void Reset()
    {
        Active = false;
        Entering = false;
        Dying = false;
        Phase = 1;
        HitFlash = 0f;
        BeamWarn = false;
        BeamActive = false;
        LaneY = -1f;
    }

    public void Spawn()
    {
        Active = true;
        Entering = true;
        Dying = false;
        EyeTopHp = GameConfig.BossEyeHp;
        EyeBottomHp = GameConfig.BossEyeHp;
        CoreHp = GameConfig.BossCoreHp;
        X = GameConfig.LogicalW + 260f;
        Y = 270f;
        Age = 0f;
        Phase = 1;
        seqIndex = -1;
        Current = BossPattern.Rest;
        patternAge = 0f;
        patternDur = 1f;
        HitFlash = 0f;
        DeathTimer = 0f;
        Openness = 0f;
        spiralAngle = 0f;
        ringPhase = 0f;
        eyeTimer = 1.5f;
        BeamWarn = false;
        BeamActive = false;
        LaneY = -1f;
        UpdateArms();
    }

    // ------------------------------------------------------------------ hit testing and damage

    /// <summary>Tests a circle against the boss. part: 1 top eye, 2 bottom eye, 3 mouth core.</summary>
    public BossHit TestHit(float cx, float cy, float r, out int part)
    {
        part = 0;
        PointF e1 = EyeTopPos;
        PointF e2 = EyeBottomPos;
        PointF c = CorePos;
        if (EyeTopHp > 0f && Dist2(cx, cy, e1.X, e1.Y) <= (r + EyeR) * (r + EyeR)) { part = 1; return BossHit.Weak; }
        if (EyeBottomHp > 0f && Dist2(cx, cy, e2.X, e2.Y) <= (r + EyeR) * (r + EyeR)) { part = 2; return BossHit.Weak; }
        if (CoreOpen && CoreHp > 0f && Dist2(cx, cy, c.X, c.Y) <= (r + CoreR) * (r + CoreR)) { part = 3; return BossHit.Weak; }
        if (CollisionManager.CircleRect(cx, cy, r, HeadRect)) return BossHit.Armor;
        if (ArmHit(cx, cy, r)) return BossHit.Armor;
        return BossHit.None;
    }

    private static float Dist2(float ax, float ay, float bx, float by)
    {
        float dx = ax - bx;
        float dy = ay - by;
        return dx * dx + dy * dy;
    }

    private bool ArmHit(float cx, float cy, float r)
    {
        for (int a = 0; a < 2; a++)
        {
            for (int i = 0; i < 3; i++)
            {
                PointF p0 = Arms[a][i];
                PointF p1 = Arms[a][i + 1];
                for (int k = 0; k <= 3; k++)
                {
                    float t = k / 3f;
                    float px = p0.X + (p1.X - p0.X) * t;
                    float py = p0.Y + (p1.Y - p0.Y) * t;
                    float rr = r + 15f;
                    if (Dist2(cx, cy, px, py) <= rr * rr) return true;
                }
            }
        }
        return false;
    }

    /// <summary>True when the player's box touches the head, an arm or the active beam.</summary>
    public bool ContactsPlayer(RectangleF box)
    {
        if (!Active || Dying) return false;
        if (HeadRect.IntersectsWith(box)) return true;
        float cx = box.X + box.Width / 2f;
        float cy = box.Y + box.Height / 2f;
        if (ArmHit(cx, cy, 6f)) return true;
        if (BeamActive)
        {
            RectangleF beam = new RectangleF(0f, BeamY - BeamThick / 2f, X - 150f, BeamThick);
            if (beam.IntersectsWith(box)) return true;
        }
        return false;
    }

    public void DamagePart(int part, float dmg)
    {
        if (!Vulnerable) return;
        switch (part)
        {
            case 1:
                if (EyeTopHp <= 0f) return;
                EyeTopHp = Math.Max(0f, EyeTopHp - dmg);
                if (EyeTopHp <= 0f) { EvPartDestroyed = true; EvPartX = X - 138f; EvPartY = Y - 78f; }
                break;
            case 2:
                if (EyeBottomHp <= 0f) return;
                EyeBottomHp = Math.Max(0f, EyeBottomHp - dmg);
                if (EyeBottomHp <= 0f) { EvPartDestroyed = true; EvPartX = X - 138f; EvPartY = Y + 78f; }
                break;
            case 3:
                if (!CoreOpen || CoreHp <= 0f) return;
                CoreHp = Math.Max(0f, CoreHp - dmg);
                if (CoreHp <= 0f) { EvPartDestroyed = true; EvPartX = X - 140f; EvPartY = Y; }
                break;
            default:
                return;
        }
        HitFlash = 0.08f;
        if (TotalHp <= 0f)
        {
            Dying = true;
            DeathTimer = 0f;
            blastTimer = 0f;
            BeamWarn = false;
            BeamActive = false;
            LaneY = -1f;
        }
    }

    /// <summary>A laser beam rectangle damages every exposed weak point it crosses.</summary>
    public void BeamDamage(RectangleF beam, float dmg)
    {
        if (!Vulnerable) return;
        PointF e1 = EyeTopPos;
        PointF e2 = EyeBottomPos;
        PointF c = CorePos;
        if (EyeTopHp > 0f && CollisionManager.CircleRect(e1.X, e1.Y, EyeR, beam)) DamagePart(1, dmg);
        if (EyeBottomHp > 0f && CollisionManager.CircleRect(e2.X, e2.Y, EyeR, beam)) DamagePart(2, dmg);
        if (CoreOpen && CoreHp > 0f && CollisionManager.CircleRect(c.X, c.Y, CoreR, beam)) DamagePart(3, dmg);
    }

    /// <summary>The bomb bonus damages every exposed weak point a little.</summary>
    public void BombDamage()
    {
        DamagePart(1, GameConfig.BombBossPartDamage);
        DamagePart(2, GameConfig.BombBossPartDamage);
        DamagePart(3, GameConfig.BombBossPartDamage);
    }

    // ------------------------------------------------------------------ behaviour

    private void UpdateArms()
    {
        float speed = 1f + 0.35f * (Phase - 1);
        for (int a = 0; a < 2; a++)
        {
            float s = a == 0 ? -1f : 1f;                  // top arm, bottom arm
            float t = Age * speed + (a == 0 ? 0f : 1.7f);
            float a1 = MathF.PI + s * (0.55f + 0.45f * MathF.Sin(t * 1.1f));
            float a2 = a1 - s * (0.6f + 0.5f * MathF.Sin(t * 1.4f + 1f));
            float a3 = a2 + s * (0.4f + 0.4f * MathF.Sin(t * 1.9f + 2f));
            PointF p0 = new PointF(X + 40f, Y + s * 135f);
            PointF p1 = new PointF(p0.X + MathF.Cos(a1) * 110f, p0.Y + MathF.Sin(a1) * 110f);
            PointF p2 = new PointF(p1.X + MathF.Cos(a2) * 100f, p1.Y + MathF.Sin(a2) * 100f);
            PointF p3 = new PointF(p2.X + MathF.Cos(a3) * 60f, p2.Y + MathF.Sin(a3) * 60f);
            Arms[a][0] = p0;
            Arms[a][1] = p1;
            Arms[a][2] = p2;
            Arms[a][3] = p3;
        }
    }

    private void NextPattern()
    {
        BossPattern[] seq = Sequences[Phase - 1];
        seqIndex = (seqIndex + 1) % seq.Length;
        Current = seq[seqIndex];
        patternAge = 0f;
        attackTimer = 0.3f;
        spiralTimer = 0f;
        BeamWarn = false;
        BeamActive = false;
        LaneY = -1f;
        laneCooldown = 0.3f;
        switch (Current)
        {
            case BossPattern.EyeOrbs: patternDur = 2.8f; break;
            case BossPattern.LaneBolts: patternDur = 3.0f; break;
            case BossPattern.Fan: patternDur = 2.6f; break;
            case BossPattern.Ring: patternDur = 3.0f; break;
            case BossPattern.Spawn: patternDur = 2.4f; break;
            case BossPattern.Spiral: patternDur = 3.2f; break;
            case BossPattern.Beam: patternDur = 3.4f; break;
            default: patternDur = 1.0f; break;
        }
    }

    private void FireFromEye(ProjectileManager shots, float px, float py, float speed)
    {
        eyeFlip ^= 1;
        PointF src;
        if (eyeFlip == 0 && EyeTopHp > 0f) src = EyeTopPos;
        else if (EyeBottomHp > 0f) src = EyeBottomPos;
        else if (EyeTopHp > 0f) src = EyeTopPos;
        else src = CorePos;
        float jitter = ((float)rng.NextDouble() - 0.5f) * 0.16f;
        shots.FireAimed(ShotKind.BossOrb, src.X, src.Y, px, py, speed, jitter);
        EvFired = true;
    }

    public void Update(float dt, float px, float py, ProjectileManager shots, ExplosionManager expl, ParticleSystem parts)
    {
        EvFired = false;
        EvPhaseChanged = false;
        EvDeathBlast = false;
        EvDefeated = false;
        EvPartDestroyed = false;
        EvLarvae = 0;
        if (!Active) return;

        Age += dt;
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        UpdateArms();
        float target = CoreOpen ? 1f : 0f;
        Openness += (target - Openness) * Math.Min(1f, 3f * dt);

        if (Dying)
        {
            DeathTimer += dt;
            blastTimer -= dt;
            if (blastTimer <= 0f)
            {
                blastTimer = 0.1f;
                float ex = X + (float)(rng.NextDouble() * 260.0 - 140.0);
                float ey = Y + (float)(rng.NextDouble() * 300.0 - 150.0);
                bool large = rng.Next(4) == 0;
                expl.Add(ex, ey, large ? ExplosionKind.Large : ExplosionKind.Small);
                parts.Flames(ex, ey, 12f, 3);
                parts.Smoke(ex, ey, 30f, -10f, 14f, 1.2f, 50);
                if (large) EvDeathBlast = true;
            }
            if (DeathTimer >= 4.2f)
            {
                expl.Add(X - 40f, Y, ExplosionKind.Boss);
                expl.Add(X - 110f, Y - 90f, ExplosionKind.Large, 0.15f);
                expl.Add(X - 110f, Y + 90f, ExplosionKind.Large, 0.25f);
                expl.Add(X + 40f, Y, ExplosionKind.Large, 0.35f);
                parts.Debris(X, Y, 60, Color.FromArgb(190, 180, 160));
                Active = false;
                EvDefeated = true;
            }
            return;
        }

        if (Entering)
        {
            float k = Math.Min(1f, Age / 4f);
            float e = k * k * (3f - 2f * k);
            X = (GameConfig.LogicalW + 260f) + ((GameConfig.LogicalW - 230f) - (GameConfig.LogicalW + 260f)) * e;
            Y = 270f;
            if (k >= 1f)
            {
                Entering = false;
                Age = 0f;
                NextPattern();
            }
            return;
        }

        // movement: a slow vertical sweep, faster in later phases
        float spd = 0.55f + 0.15f * Phase;
        Y = 270f + 55f * MathF.Sin(Age * spd);
        X = GameConfig.LogicalW - 230f + 12f * MathF.Sin(Age * 0.9f);

        // phase changes by remaining health
        float frac = HealthFraction;
        int newPhase = frac > 0.66f ? 1 : (frac > 0.33f ? 2 : 3);
        if (newPhase > Phase)
        {
            Phase = newPhase;
            EvPhaseChanged = true;
            seqIndex = -1;
            Current = BossPattern.Rest;
            patternAge = 0f;
            patternDur = 1.6f;
            attackTimer = 1f;
            BeamWarn = false;
            BeamActive = false;
            LaneY = -1f;
            return;
        }

        patternAge += dt;
        if (patternAge >= patternDur) NextPattern();

        // from phase two the eyes keep firing next to the main pattern
        if (Phase >= 2 && Current != BossPattern.EyeOrbs && Current != BossPattern.Rest)
        {
            eyeTimer -= dt;
            if (eyeTimer <= 0f)
            {
                FireFromEye(shots, px, py, 200f);
                eyeTimer = Phase == 2 ? 1.8f : 1.3f;
            }
        }

        PointF mouth = new PointF(X - 145f, Y);
        switch (Current)
        {
            case BossPattern.EyeOrbs:
                attackTimer -= dt;
                if (attackTimer <= 0f)
                {
                    FireFromEye(shots, px, py, 210f + 10f * Phase);
                    attackTimer = 0.55f;
                }
                break;
            case BossPattern.LaneBolts:
                if (LaneY < 0f)
                {
                    laneCooldown -= dt;
                    if (laneCooldown <= 0f)
                    {
                        LaneY = py;
                        laneTime = 0.55f;
                    }
                }
                else
                {
                    laneTime -= dt;
                    if (laneTime <= 0f)
                    {
                        for (int k = -1; k <= 1; k++) shots.SpawnEnemy(ShotKind.BossBolt, mouth.X, LaneY + k * 22f, -400f, 0f);
                        LaneY = -1f;
                        laneCooldown = 0.45f;
                        EvFired = true;
                    }
                }
                break;
            case BossPattern.Fan:
                attackTimer -= dt;
                if (attackTimer <= 0f)
                {
                    shots.FireFan(ShotKind.BossOrb, mouth.X, mouth.Y, px, py, 185f + 10f * Phase, Phase == 2 ? 7 : 9, 1.3f);
                    attackTimer = 0.9f;
                    EvFired = true;
                }
                break;
            case BossPattern.Ring:
                attackTimer -= dt;
                if (attackTimer <= 0f)
                {
                    shots.FireRing(ShotKind.EnemyOrb, mouth.X + 15f, mouth.Y, Phase == 2 ? 14 : 18, 140f, ringPhase);
                    ringPhase += 0.2f;
                    attackTimer = 1.5f;
                    EvFired = true;
                }
                break;
            case BossPattern.Spawn:
                attackTimer -= dt;
                if (attackTimer <= 0f)
                {
                    EvLarvae += 2;
                    attackTimer = 1.2f;
                    EvFired = true;
                }
                break;
            case BossPattern.Spiral:
                spiralTimer -= dt;
                if (spiralTimer <= 0f)
                {
                    shots.SpawnEnemy(ShotKind.EnemyOrb, mouth.X + 15f, mouth.Y, MathF.Cos(spiralAngle) * 170f, MathF.Sin(spiralAngle) * 170f);
                    shots.SpawnEnemy(ShotKind.EnemyOrb, mouth.X + 15f, mouth.Y, MathF.Cos(spiralAngle + MathF.PI) * 170f, MathF.Sin(spiralAngle + MathF.PI) * 170f);
                    spiralAngle += 0.3f;
                    spiralTimer = 0.09f;
                    EvFired = true;
                }
                break;
            case BossPattern.Beam:
                if (patternAge < 1f)
                {
                    BeamWarn = true;
                    BeamActive = false;
                    BeamY = 190f;
                }
                else if (patternAge < 3.2f)
                {
                    BeamWarn = false;
                    BeamActive = true;
                    BeamY = 190f + 110f * MathF.Sin((patternAge - 1f) * 1.4f);
                }
                else
                {
                    BeamWarn = false;
                    BeamActive = false;
                }
                break;
        }
    }
}
