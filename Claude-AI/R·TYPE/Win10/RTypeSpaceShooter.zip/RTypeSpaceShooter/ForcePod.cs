namespace RTypeSpaceShooter;

public enum PodState { AttachedFront, AttachedRear, Launched, Returning }

/// <summary>
/// The Force Pod: an indestructible orb that rides on the front or the back of the ship, adding a shot in its
/// direction and absorbing bullets. Pressing the pod key detaches it (it flies ahead and fires at enemies by itself);
/// pressing again recalls it, and it re-attaches on the side it was on.
/// </summary>
public sealed class ForcePod
{
    public const float Radius = 19f;
    public const float SlotDistance = 46f;

    public float X, Y;
    public float Spin;
    public float Flash;                   // flashes when it absorbs a bullet
    public float Glow;                    // brief glow after attaching or launching
    public float ContactTimer;            // limits how often ramming damages enemies
    public PodState State = PodState.AttachedFront;
    public bool EvLaunch, EvRecall, EvAttach;

    private float holdX;
    private float fireTimer;
    private int returnSide = 1;

    public bool Attached { get { return State == PodState.AttachedFront || State == PodState.AttachedRear; } }

    public string StatusText
    {
        get
        {
            switch (State)
            {
                case PodState.AttachedFront: return "ATTACHED FRONT";
                case PodState.AttachedRear: return "ATTACHED REAR";
                case PodState.Launched: return "DETACHED";
                default: return "RETURNING";
            }
        }
    }

    public void Reset(PlayerShip s)
    {
        State = PodState.AttachedFront;
        X = s.X + SlotDistance;
        Y = s.Y;
        Flash = 0f;
        Glow = 0f;
    }

    /// <summary>The pod key: launch when attached, recall when detached.</summary>
    public void Toggle(PlayerShip s)
    {
        if (!s.Alive) return;
        if (Attached)
        {
            State = PodState.Launched;
            holdX = Math.Min(GameConfig.LogicalW - 110f, Math.Max(s.X + 340f, X + 200f));
            fireTimer = 0.1f;
            Glow = 0.4f;
            EvLaunch = true;
        }
        else if (State == PodState.Launched)
        {
            returnSide = X >= s.X ? 1 : -1;
            State = PodState.Returning;
            EvRecall = true;
        }
    }

    private static float Clamp(float v, float lo, float hi)
    {
        return Math.Max(lo, Math.Min(hi, v));
    }

    public void Update(float dt, PlayerShip s, bool hasTarget, float tx, float ty, ProjectileManager shots)
    {
        Spin += dt * (Attached ? 2.5f : 7f);
        if (Flash > 0f) Flash = Math.Max(0f, Flash - dt);
        if (Glow > 0f) Glow = Math.Max(0f, Glow - dt);
        if (ContactTimer > 0f) ContactTimer -= dt;

        switch (State)
        {
            case PodState.AttachedFront:
            case PodState.AttachedRear:
                {
                    float side = State == PodState.AttachedFront ? 1f : -1f;
                    float k = 1f - MathF.Exp(-18f * dt);
                    X += (s.X + side * SlotDistance - X) * k;
                    Y += (s.Y - Y) * k;
                    break;
                }
            case PodState.Launched:
                {
                    X += (holdX - X) * Math.Min(1f, 6f * dt);
                    Y += Clamp(s.Y - Y, -110f * dt, 110f * dt);
                    fireTimer -= dt;
                    if (fireTimer <= 0f)
                    {
                        if (hasTarget)
                        {
                            shots.SpawnPlayer(ShotKind.PodShot, X, Y, 0f, 0f, 1.2f, 4f, 1);
                            Projectile p = shots.Player[shots.Player.Count - 1];
                            float a = MathF.Atan2(ty - Y, tx - X);
                            p.VX = MathF.Cos(a) * 650f;
                            p.VY = MathF.Sin(a) * 650f;
                            fireTimer = 0.2f;
                        }
                        else
                        {
                            shots.SpawnPlayer(ShotKind.PodShot, X + 14f, Y, 650f, 0f, 1f, 4f, 1);
                            fireTimer = 0.4f;
                        }
                    }
                    break;
                }
            default:    // Returning
                {
                    float gx = s.X + returnSide * SlotDistance;
                    float gy = s.Y;
                    float dx = gx - X;
                    float dy = gy - Y;
                    float dist = MathF.Sqrt(dx * dx + dy * dy);
                    float step = 950f * dt;
                    if (dist <= step + 8f)
                    {
                        X = gx;
                        Y = gy;
                        State = returnSide > 0 ? PodState.AttachedFront : PodState.AttachedRear;
                        Glow = 0.4f;
                        EvAttach = true;
                    }
                    else
                    {
                        X += dx / dist * step;
                        Y += dy / dist * step;
                    }
                    break;
                }
        }
        X = Clamp(X, -10f, GameConfig.LogicalW + 10f);
        Y = Clamp(Y, 10f, GameConfig.ViewH - 10f);
    }
}
