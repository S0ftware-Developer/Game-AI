using System.Drawing.Drawing2D;

namespace RTypeSpaceShooter;

/// <summary>
/// All ship, enemy, obstacle, boss, bonus, projectile and effect drawing. Ship polygons are static arrays in local
/// coordinates with the nose pointing right; enemies are drawn mirrored so they face left.
/// </summary>
public sealed class Sprites : IDisposable
{
    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fBonus = new Font("Segoe UI", 17f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly Font fText = new Font("Segoe UI", 13f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly StringFormat sfCenter = new StringFormat();
    private readonly PointF[] starPts = new PointF[10];
    private readonly PointF[] quad = new PointF[4];
    private readonly PointF[] tri = new PointF[3];
    private readonly PointF[] rockPts = new PointF[12];
    private readonly PointF[] curve = new PointF[5];
    private readonly LinearGradientBrush boneBrush;

    private static PointF[] MirrorY(PointF[] a)
    {
        PointF[] r = new PointF[a.Length];
        for (int i = 0; i < a.Length; i++) r[i] = new PointF(a[i].X, -a[i].Y);
        return r;
    }

    private static PointF[] Pts(params float[] v)
    {
        PointF[] r = new PointF[v.Length / 2];
        for (int i = 0; i < r.Length; i++) r[i] = new PointF(v[i * 2], v[i * 2 + 1]);
        return r;
    }

    // ---- player ship
    private static readonly PointF[] PlFuse = Pts(32, 0, 24, -4, 8, -7, -12, -8, -26, -6, -32, 0, -26, 6, -12, 8, 8, 7, 24, 4);
    private static readonly PointF[] PlWingTop = Pts(8, -6, -6, -24, -24, -26, -20, -8);
    private static readonly PointF[] PlWingBot = MirrorY(PlWingTop);
    private static readonly PointF[] PlTipTop = Pts(-6, -24, -24, -26, -22, -19, -9, -18);
    private static readonly PointF[] PlTipBot = MirrorY(PlTipTop);
    private static readonly PointF[] PlNose = Pts(32, 0, 24, -4, 24, 4);
    private static readonly PointF[] PlEngine = Pts(-34, -7, -26, -7, -26, 7, -34, 7);

    // ---- enemies
    private static readonly PointF[] FiHull = Pts(22, 0, 10, -5, -8, -7, -18, -4, -20, 0, -18, 4, -8, 7, 10, 5);
    private static readonly PointF[] FiFinTop = Pts(-2, -6, -14, -18, -20, -16, -12, -5);
    private static readonly PointF[] FiFinBot = MirrorY(FiFinTop);
    private static readonly PointF[] InBody = Pts(16, 0, 4, -3, -10, -3, -14, 0, -10, 3, 4, 3);
    private static readonly PointF[] InWingTop = Pts(8, -3, -4, -16, -16, -20, -10, -8, -6, -3);
    private static readonly PointF[] InWingBot = MirrorY(InWingTop);
    private static readonly PointF[] HeHull = Pts(48, 0, 38, -14, 10, -24, -30, -26, -46, -14, -48, 0, -46, 14, -30, 26, 10, 24, 38, 14);
    private static readonly PointF[] HeArmorTop = Pts(30, -12, 8, -20, -26, -22, -38, -12, -10, -10);
    private static readonly PointF[] HeArmorBot = MirrorY(HeArmorTop);
    private static readonly PointF[] ElHull = Pts(40, 0, 28, -10, 0, -16, -26, -14, -38, -6, -38, 6, -26, 14, 0, 16, 28, 10);
    private static readonly PointF[] ElSpikeTop = Pts(-10, -14, -26, -30, -30, -12);
    private static readonly PointF[] ElSpikeBot = MirrorY(ElSpikeTop);

    // ---- boss (faces left)
    private static readonly PointF[] BossHead = Pts(-150, -30, -146, -92, -110, -142, -40, -168, 50, -168, 112, -136, 136, -70, 138, 70, 112, 136, 50, 168, -40, 168, -110, 142, -146, 92, -150, 30);

    public Sprites()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        boneBrush = new LinearGradientBrush(new RectangleF(-150f, -170f, 290f, 340f), Color.FromArgb(255, 232, 222, 198), Color.FromArgb(255, 146, 134, 118), 0f);
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fBonus.Dispose();
        fText.Dispose();
        sfCenter.Dispose();
        boneBrush.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    /// <summary>Colour tinted toward white by the hit flash, with an alpha multiplier.</summary>
    private static Color C(int r, int g, int b, float flash, float alpha)
    {
        int rr = (int)(r + (255 - r) * flash);
        int gg = (int)(g + (255 - g) * flash);
        int bb = (int)(b + (255 - b) * flash);
        return Color.FromArgb(A(255f * alpha), rr, gg, bb);
    }

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private void Poly(Graphics g, PointF[] pts, Color fill, Color line, float lw)
    {
        g.FillPolygon(B(fill), pts);
        if (lw > 0f) g.DrawPolygon(P(line, lw), pts);
    }

    private void Star(Graphics g, float cx, float cy, float r, Color c)
    {
        for (int i = 0; i < 10; i++)
        {
            float a = -MathF.PI / 2f + i * MathF.PI / 5f;
            float rr = (i % 2 == 0) ? r : r * 0.42f;
            starPts[i] = new PointF(cx + MathF.Cos(a) * rr, cy + MathF.Sin(a) * rr);
        }
        g.FillPolygon(B(c), starPts);
    }

    private void Glow(Graphics g, float x, float y, float r, Color c, float alpha)
    {
        g.FillEllipse(B(Color.FromArgb(A(c.A * alpha * 0.30f), c.R, c.G, c.B)), x - r * 1.6f, y - r * 1.6f, r * 3.2f, r * 3.2f);
        g.FillEllipse(B(Color.FromArgb(A(c.A * alpha * 0.55f), c.R, c.G, c.B)), x - r * 1.15f, y - r * 1.15f, r * 2.3f, r * 2.3f);
        g.FillEllipse(B(Color.FromArgb(A(c.A * alpha), c.R, c.G, c.B)), x - r * 0.7f, y - r * 0.7f, r * 1.4f, r * 1.4f);
    }

    // ------------------------------------------------------------------ the player ship

    public void DrawPlayer(Graphics g, PlayerShip p, float time)
    {
        if (!p.Alive) return;
        bool flicker = p.Invuln > 0f && p.ShieldTimer <= 0f && ((int)(time * 18f) & 1) == 0;
        float thrust = Math.Max(0f, p.VX) / GameConfig.PlayerMaxSpeed;
        if (!flicker) DrawShipBody(g, p.X, p.Y, p.Bank, time, thrust, 1f, 1f, p.Weapon.MuzzleTimer > 0f);

        WeaponSystem w = p.Weapon;
        if (w.Charging && w.Charge > 0.04f)
        {
            float c = w.Charge;
            float nx = p.X + 38f;
            float pulse = c >= 1f ? 0.6f + 0.4f * MathF.Sin(time * 30f) : 1f;
            float r = 4f + 18f * c;
            Glow(g, nx, p.Y, r, Color.FromArgb(255, 110, 190, 255), pulse);
            g.FillEllipse(B(Color.FromArgb(A(255 * pulse), 230, 250, 255)), nx - r * 0.5f, p.Y - r * 0.5f, r, r);
            for (int k = 0; k < 4; k++)
            {
                float a = time * 9f + k * 1.57f;
                float rr = r * 1.7f + 4f * MathF.Sin(time * 14f + k);
                g.FillRectangle(B(Color.FromArgb(A(200 * c), 190, 230, 255)), nx + MathF.Cos(a) * rr - 1.5f, p.Y + MathF.Sin(a) * rr - 1.5f, 3f, 3f);
            }
            // a small gauge under the ship
            g.FillRectangle(B(Color.FromArgb(170, 10, 14, 30)), p.X - 24f, p.Y + 34f, 48f, 6f);
            g.FillRectangle(B(c >= 1f ? Color.FromArgb(255, 255, 255, 255) : Color.FromArgb(255, 110, 200, 255)), p.X - 23f, p.Y + 35f, 46f * c, 4f);
            g.DrawRectangle(P(Color.FromArgb(220, 150, 190, 230), 1f), p.X - 24f, p.Y + 34f, 48f, 6f);
        }

        if (p.ShieldTimer > 0f)
        {
            bool fading = p.ShieldTimer < 2f && ((int)(time * 10f) & 1) == 0;
            if (!fading)
            {
                float pulse = 0.65f + 0.35f * MathF.Sin(time * 8f) + p.ShieldFlash * 2.5f;
                g.FillEllipse(B(Color.FromArgb(A(36 * pulse), 110, 190, 255)), p.X - 44f, p.Y - 34f, 88f, 68f);
                g.DrawEllipse(P(Color.FromArgb(A(210 * pulse), 150, 215, 255), 2.5f), p.X - 44f, p.Y - 34f, 88f, 68f);
                g.DrawEllipse(P(Color.FromArgb(A(110 * pulse), 200, 240, 255), 1f), p.X - 40f, p.Y - 30f, 80f, 60f);
            }
        }
    }

    public void DrawShipBody(Graphics g, float x, float y, float bank, float time, float thrust, float scale, float alpha, bool muzzle)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(x, y);
        g.RotateTransform(bank * 7f);
        g.ScaleTransform(scale, scale);
        Color line = C(18, 24, 50, 0f, alpha);

        // engine flame (animated)
        float fl = 16f + 7f * MathF.Sin(time * 42f) + 12f * thrust;
        g.FillEllipse(B(Color.FromArgb(A(120 * alpha), 60, 140, 255)), -34f - fl * 1.5f, -9f, fl * 1.5f, 18f);
        g.FillEllipse(B(Color.FromArgb(A(220 * alpha), 120, 200, 255)), -34f - fl, -6f, fl, 12f);
        g.FillEllipse(B(Color.FromArgb(A(255 * alpha), 235, 250, 255)), -34f - fl * 0.6f, -3f, fl * 0.6f, 6f);

        Poly(g, PlWingBot, C(190, 198, 218, 0f, alpha), line, 1.3f);
        Poly(g, PlWingTop, C(205, 212, 230, 0f, alpha), line, 1.3f);
        Poly(g, PlTipBot, C(200, 40, 56, 0f, alpha), line, 1f);
        Poly(g, PlTipTop, C(200, 40, 56, 0f, alpha), line, 1f);
        g.FillEllipse(B(C(70, 78, 100, 0f, alpha)), -17f, 22f, 10f, 5f);          // wing weapon pods
        g.FillEllipse(B(C(70, 78, 100, 0f, alpha)), -17f, -27f, 10f, 5f);
        Poly(g, PlEngine, C(60, 66, 88, 0f, alpha), line, 1f);
        Poly(g, PlFuse, C(228, 234, 246, 0f, alpha), line, 1.5f);
        g.FillRectangle(B(C(160, 170, 196, 0f, alpha)), -24f, 3f, 40f, 3f);
        g.FillRectangle(B(C(200, 40, 56, 0f, alpha)), -18f, -4f, 18f, 2.5f);
        Poly(g, PlNose, C(200, 40, 56, 0f, alpha), line, 1f);
        g.FillRectangle(B(C(70, 76, 98, 0f, alpha)), 22f, 5f, 12f, 3f);            // under-nose cannon
        g.FillEllipse(B(C(70, 160, 255, 0f, alpha)), 2f, -10f, 22f, 9f);           // cockpit
        g.FillEllipse(B(Color.FromArgb(A(170 * alpha), 255, 255, 255)), 6f, -9f, 9f, 3.5f);
        g.DrawEllipse(P(line, 1f), 2f, -10f, 22f, 9f);

        if (muzzle)
        {
            g.FillEllipse(B(Color.FromArgb(A(220 * alpha), 160, 230, 255)), 30f, -7f, 22f, 14f);
            g.FillEllipse(B(Color.FromArgb(A(255 * alpha), 255, 255, 255)), 32f, -3.5f, 12f, 7f);
        }
        g.Restore(st);
    }

    // ------------------------------------------------------------------ the Force Pod

    public void DrawPod(Graphics g, ForcePod pod, float time)
    {
        bool attached = pod.Attached;
        Color core = attached ? Color.FromArgb(255, 90, 220, 255) : Color.FromArgb(255, 255, 150, 50);
        float pulse = 0.65f + 0.35f * MathF.Sin(time * 6f);
        float glowK = 0.5f + pod.Glow * 2f + pod.Flash * 3f;
        Glow(g, pod.X, pod.Y, 18f, Color.FromArgb(90, core.R, core.G, core.B), glowK * pulse);

        GraphicsState st = g.Save();
        g.TranslateTransform(pod.X, pod.Y);
        float r = ForcePod.Radius;
        g.FillEllipse(B(Color.FromArgb(255, 70, 76, 100)), -r, -r, r * 2f, r * 2f);
        g.FillEllipse(B(Color.FromArgb(255, 150, 158, 182)), -r + 2f, -r + 2f, r * 2f - 5f, r * 2f - 5f);
        g.FillEllipse(B(Color.FromArgb(255, 210, 216, 232)), -r + 5f, -r + 4f, r * 1.2f, r * 0.9f);

        // a turning ring of plates
        for (int k = 0; k < 3; k++)
        {
            float a = pod.Spin + k * 2.094f;
            float cx = MathF.Cos(a) * (r - 3f);
            float cy = MathF.Sin(a) * (r - 3f) * 0.55f;
            g.FillEllipse(B(Color.FromArgb(255, 60, 64, 86)), cx - 4f, cy - 3f, 8f, 6f);
        }
        g.DrawEllipse(P(Color.FromArgb(255, 20, 24, 44), 1.8f), -r, -r, r * 2f, r * 2f);

        // the glowing core
        float cr = 7f + 2f * pulse;
        g.FillEllipse(B(Color.FromArgb(255, core.R, core.G, core.B)), -cr, -cr, cr * 2f, cr * 2f);
        g.FillEllipse(B(Color.FromArgb(255, 255, 255, 235)), -cr * 0.45f, -cr * 0.55f, cr * 0.9f, cr * 0.9f);
        if (pod.Flash > 0f) g.FillEllipse(B(Color.FromArgb(A(220 * pod.Flash / 0.15f), 255, 255, 255)), -r, -r, r * 2f, r * 2f);
        g.Restore(st);
    }

    // ------------------------------------------------------------------ enemies

    public void DrawEnemy(Graphics g, Enemy e, float time)
    {
        DrawEnemyShape(g, e.Type, e.X, e.Y, e.Bank, e.HitFlash > 0f ? 0.8f : 0f, time + e.Id * 0.37f, 1f, 1f);
    }

    /// <summary>Draws one enemy type facing left (the way they fly in the game).</summary>
    public void DrawEnemyShape(Graphics g, EnemyType type, float x, float y, float bank, float fl, float time, float scale, float alpha)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(x, y);
        g.RotateTransform(-bank * 10f);
        g.ScaleTransform(-scale, scale);
        switch (type)
        {
            case EnemyType.Fighter: DrawFighter(g, fl, time, alpha); break;
            case EnemyType.Interceptor: DrawInterceptor(g, fl, time, alpha); break;
            case EnemyType.Heavy: DrawHeavy(g, fl, time, alpha); break;
            case EnemyType.Organic: DrawOrganic(g, fl, time, alpha); break;
            case EnemyType.Elite: DrawElite(g, fl, time, alpha); break;
            default: DrawLarva(g, fl, time, alpha); break;
        }
        g.Restore(st);
    }

    private void Exhaust(Graphics g, float x, float y, float len, float time, float alpha, Color c)
    {
        float l = len * (0.8f + 0.25f * MathF.Sin(time * 40f + x));
        g.FillEllipse(B(Color.FromArgb(A(160 * alpha), c.R, c.G, c.B)), x - l, y - 3.5f, l, 7f);
        g.FillEllipse(B(Color.FromArgb(A(230 * alpha), 255, 255, 220)), x - l * 0.5f, y - 1.5f, l * 0.5f, 3f);
    }

    private void DrawFighter(Graphics g, float fl, float time, float al)
    {
        Color line = C(8, 30, 40, 0f, al);
        Exhaust(g, -20f, 0f, 14f, time, al, Color.FromArgb(255, 80, 220, 255));
        Poly(g, FiFinTop, C(30, 120, 130, fl, al), line, 1.2f);
        Poly(g, FiFinBot, C(30, 120, 130, fl, al), line, 1.2f);
        Poly(g, FiHull, C(52, 180, 170, fl, al), line, 1.4f);
        g.DrawLine(P(C(160, 250, 230, fl, al), 1.5f), -14f, 0f, 16f, 0f);
        g.FillEllipse(B(C(255, 190, 50, fl, al)), 4f, -3.5f, 9f, 7f);
        g.FillEllipse(B(Color.FromArgb(A(220 * al), 255, 255, 200)), 6f, -2f, 3.5f, 3f);
        g.FillRectangle(B(C(30, 90, 100, fl, al)), -12f, -2f, 8f, 4f);
    }

    private void DrawInterceptor(Graphics g, float fl, float time, float al)
    {
        Color line = C(50, 24, 8, 0f, al);
        Exhaust(g, -14f, 0f, 12f, time, al, Color.FromArgb(255, 255, 170, 60));
        Poly(g, InWingTop, C(226, 130, 40, fl, al), line, 1.2f);
        Poly(g, InWingBot, C(226, 130, 40, fl, al), line, 1.2f);
        g.DrawLine(P(C(255, 226, 120, fl, al), 1.6f), -4f, -4f, -14f, -17f);
        g.DrawLine(P(C(255, 226, 120, fl, al), 1.6f), -4f, 4f, -14f, 17f);
        Poly(g, InBody, C(250, 190, 80, fl, al), line, 1.2f);
        g.FillEllipse(B(C(230, 40, 40, fl, al)), 2f, -2.6f, 7f, 5.2f);
        g.FillEllipse(B(Color.FromArgb(A(230 * al), 255, 220, 200)), 4f, -1.5f, 2.5f, 2f);
    }

    private void DrawHeavy(Graphics g, float fl, float time, float al)
    {
        Color line = C(24, 20, 44, 0f, al);
        Exhaust(g, -47f, -12f, 22f, time, al, Color.FromArgb(255, 160, 100, 255));
        Exhaust(g, -47f, 12f, 22f, time + 1f, al, Color.FromArgb(255, 160, 100, 255));
        g.FillRectangle(B(C(60, 56, 84, fl, al)), 38f, -12f, 14f, 5f);              // front cannons
        g.FillRectangle(B(C(60, 56, 84, fl, al)), 38f, 7f, 14f, 5f);
        Poly(g, HeHull, C(96, 88, 132, fl, al), line, 1.8f);
        Poly(g, HeArmorTop, C(130, 122, 170, fl, al), line, 1.2f);
        Poly(g, HeArmorBot, C(130, 122, 170, fl, al), line, 1.2f);
        for (int k = -2; k <= 2; k++) g.DrawLine(P(C(60, 54, 90, fl, al), 1.2f), k * 14f, -24f, k * 14f, 24f);
        g.FillEllipse(B(C(70, 64, 100, fl, al)), -10f, -32f, 22f, 12f);           // turrets
        g.FillEllipse(B(C(70, 64, 100, fl, al)), -10f, 20f, 22f, 12f);
        g.FillEllipse(B(C(255, 70, 70, fl, al)), 10f, -4f, 10f, 8f);              // sensor
        g.FillEllipse(B(Color.FromArgb(A(200 * al), 255, 220, 200)), 12f, -2f, 4f, 3f);
        bool blink = ((int)(time * 3f) & 1) == 0;
        g.FillEllipse(B(blink ? Color.FromArgb(A(255 * al), 255, 90, 70) : Color.FromArgb(A(120 * al), 120, 30, 30)), -30f, -3f, 5f, 5f);
    }

    private void DrawOrganic(Graphics g, float fl, float time, float al)
    {
        Color line = C(70, 20, 50, 0f, al);
        // tentacles hang behind the dome (the creature faces right here, so they trail to the left)
        for (int k = 0; k < 5; k++)
        {
            float oy = -14f + k * 7f;
            for (int i = 0; i < curve.Length; i++)
            {
                float t = i / (float)(curve.Length - 1);
                curve[i] = new PointF(-8f - 34f * t, oy + MathF.Sin(time * 4f + k * 0.9f + t * 4f) * (6f + 8f * t));
            }
            g.DrawCurve(P(C(190, 70, 120, fl, al), 3.2f), curve);
        }
        g.FillEllipse(B(C(214, 100, 140, fl, al)), -22f, -24f, 46f, 40f);
        g.FillEllipse(B(C(236, 150, 180, fl, al)), -12f, -22f, 28f, 16f);
        g.DrawEllipse(P(line, 1.6f), -22f, -24f, 46f, 40f);
        for (int k = 0; k < 4; k++) g.FillEllipse(B(Color.FromArgb(A(130 * al), 150, 40, 90)), -14f + k * 8f, -12f + (k % 2) * 7f, 5f, 5f);
        float pulse = 0.6f + 0.4f * MathF.Sin(time * 5f);
        g.FillEllipse(B(C(255, 60, 50, fl, al)), 6f, -8f, 12f, 12f);
        g.FillEllipse(B(Color.FromArgb(A((120 + 100 * pulse) * al), 255, 220, 190)), 9f, -6f, 5f, 5f);
    }

    private void DrawElite(Graphics g, float fl, float time, float al)
    {
        Color line = C(14, 6, 10, 0f, al);
        Color gold = C(236, 196, 70, fl, al);
        Exhaust(g, -38f, -3f, 20f, time, al, Color.FromArgb(255, 255, 90, 60));
        Exhaust(g, -38f, 3f, 20f, time + 0.5f, al, Color.FromArgb(255, 255, 90, 60));
        Poly(g, ElSpikeTop, C(110, 30, 44, fl, al), line, 1.2f);
        Poly(g, ElSpikeBot, C(110, 30, 44, fl, al), line, 1.2f);
        Poly(g, ElHull, C(66, 24, 38, fl, al), line, 1.8f);
        g.DrawLine(P(gold, 1.8f), -30f, -8f, 24f, -8f);
        g.DrawLine(P(gold, 1.8f), -30f, 8f, 24f, 8f);
        for (int s = -1; s <= 1; s += 2)
        {
            float cx = -4f;
            float cy = s * 22f;
            g.FillEllipse(B(C(90, 30, 46, fl, al)), cx - 8f, cy - 8f, 16f, 16f);
            g.DrawEllipse(P(gold, 1.4f), cx - 8f, cy - 8f, 16f, 16f);
            float a = time * 5f * s;
            g.DrawLine(P(C(40, 14, 22, fl, al), 3.5f), cx, cy, cx + MathF.Cos(a) * 15f, cy + MathF.Sin(a) * 15f);
        }
        float pulse = 0.6f + 0.4f * MathF.Sin(time * 6f);
        g.FillEllipse(B(Color.FromArgb(A(150 * al), 255, 60, 60)), 8f, -9f, 22f, 18f);
        g.FillEllipse(B(C(255, 80, 60, fl, al)), 12f, -6f, 14f, 12f);
        g.FillEllipse(B(Color.FromArgb(A((140 + 110 * pulse) * al), 255, 230, 200)), 16f, -3f, 6f, 6f);
    }

    private void DrawLarva(Graphics g, float fl, float time, float al)
    {
        for (int k = 0; k < 3; k++)
        {
            float w = MathF.Sin(time * 10f + k * 1.2f) * 2.5f;
            float r = 4.5f - k * 0.8f;
            g.FillEllipse(B(C(110, 220, 100, fl, al)), -k * 7f - r, w - r, r * 2f, r * 2f);
        }
        g.FillEllipse(B(C(255, 80, 80, fl, al)), 1f, -2.5f, 4f, 4f);
    }

    // ------------------------------------------------------------------ obstacles

    public void DrawObstacle(Graphics g, Obstacle o, float scroll, float time, float px, float py)
    {
        float sx = o.ScreenX(scroll);
        if (sx < -150f || sx > GameConfig.LogicalW + 150f) return;
        float fl = o.HitFlash > 0f ? 0.7f : 0f;
        switch (o.Type)
        {
            case ObstacleType.Asteroid: DrawAsteroid(g, o, sx, fl); break;
            case ObstacleType.Barrier: DrawBarrier(g, o, sx, time); break;
            case ObstacleType.Gate: DrawGate(g, o, sx, time); break;
            case ObstacleType.Turret: DrawTurret(g, o, sx, px, py, time, fl); break;
            default: DrawPillar(g, o, sx, time); break;
        }
    }

    private void DrawAsteroid(Graphics g, Obstacle o, float sx, float fl)
    {
        float r = o.Radius;
        int n = rockPts.Length;
        for (int i = 0; i < n; i++)
        {
            float a = o.Rot + i * MathF.PI * 2f / n;
            float noise = 0.82f + 0.18f * MathF.Sin(i * 2.3f + o.Variant * 1.7f) + 0.08f * MathF.Sin(i * 5.1f + o.Id);
            rockPts[i] = new PointF(sx + MathF.Cos(a) * r * noise, o.Y + MathF.Sin(a) * r * noise);
        }
        g.FillEllipse(B(Color.FromArgb(50, 0, 0, 20)), sx - r + 5f, o.Y - r + 7f, r * 2f, r * 2f);
        g.FillPolygon(B(C(104, 94, 106, fl, 1f)), rockPts);
        // shaded lower half and craters
        g.FillEllipse(B(Color.FromArgb(80, 30, 24, 40)), sx - r * 0.5f, o.Y, r * 1.2f, r * 0.7f);
        g.FillEllipse(B(Color.FromArgb(120, 150, 140, 156)), sx - r * 0.55f, o.Y - r * 0.6f, r * 0.7f, r * 0.45f);
        g.FillEllipse(B(Color.FromArgb(110, 52, 44, 60)), sx + r * 0.1f + MathF.Cos(o.Rot) * 3f, o.Y - r * 0.2f, r * 0.45f, r * 0.35f);
        g.FillEllipse(B(Color.FromArgb(100, 52, 44, 60)), sx - r * 0.45f, o.Y + r * 0.15f, r * 0.3f, r * 0.25f);
        g.DrawPolygon(P(Color.FromArgb(255, 30, 24, 40), 1.8f), rockPts);
    }

    private void DrawBarrier(Graphics g, Obstacle o, float sx, float time)
    {
        // the rail it slides on
        g.FillRectangle(B(Color.FromArgb(120, 50, 58, 82)), sx - 3f, o.YLo - o.H / 2f - 10f, 6f, o.YHi - o.YLo + o.H + 20f);
        float x = sx - o.W / 2f;
        float y = o.Y - o.H / 2f;
        g.FillRectangle(B(Color.FromArgb(255, 80, 88, 112)), x, y, o.W, o.H);
        for (float sy = y + 4f; sy < y + o.H - 8f; sy += 16f)
        {
            g.FillRectangle(B(Color.FromArgb(255, 240, 190, 40)), x + 2f, sy, o.W - 4f, 8f);
            g.FillRectangle(B(Color.FromArgb(255, 30, 30, 38)), x + 2f, sy + 8f, o.W - 4f, 8f);
        }
        g.FillRectangle(B(Color.FromArgb(255, 120, 130, 160)), x, y, o.W, 4f);
        g.FillRectangle(B(Color.FromArgb(255, 50, 56, 78)), x, y + o.H - 4f, o.W, 4f);
        g.DrawRectangle(P(Color.FromArgb(255, 14, 16, 28), 2f), x, y, o.W, o.H);
        bool blink = ((int)(time * 4f) & 1) == 0;
        g.FillEllipse(B(blink ? Color.FromArgb(255, 255, 70, 60) : Color.FromArgb(255, 110, 24, 24)), sx - 4f, y + o.H / 2f - 4f, 8f, 8f);
    }

    private void DrawGate(Graphics g, Obstacle o, float sx, float time)
    {
        float t = o.GateTop;
        float b = o.GateBottom;
        // emitters at both ends
        for (int e = 0; e < 2; e++)
        {
            float ey = e == 0 ? t : b;
            float dir = e == 0 ? 1f : -1f;
            g.FillRectangle(B(Color.FromArgb(255, 70, 76, 100)), sx - 16f, e == 0 ? ey - 8f : ey - 2f, 32f, 10f);
            g.FillRectangle(B(Color.FromArgb(255, 120, 126, 156)), sx - 16f, e == 0 ? ey - 8f : ey + 6f, 32f, 2f);
            g.FillEllipse(B(o.GateOn ? Color.FromArgb(255, 255, 120, 200) : Color.FromArgb(255, 120, 60, 110)), sx - 6f, ey + dir * 2f - 4f, 12f, 8f);
        }
        if (o.GateOn)
        {
            float flick = 0.8f + 0.2f * MathF.Sin(time * 60f);
            g.FillRectangle(B(Color.FromArgb(A(70 * flick), 255, 80, 180)), sx - 15f, t, 30f, b - t);
            g.FillRectangle(B(Color.FromArgb(A(160 * flick), 255, 110, 200)), sx - 8f, t, 16f, b - t);
            g.FillRectangle(B(Color.FromArgb(255, 255, 240, 250)), sx - 3f, t, 6f, b - t);
        }
        else if (o.GateWarn)
        {
            bool on = ((int)(time * 20f) & 1) == 0;
            if (on) g.FillRectangle(B(Color.FromArgb(180, 255, 100, 190)), sx - 1.5f, t, 3f, b - t);
        }
        else
        {
            for (float y = t + 6f; y < b; y += 22f) g.FillRectangle(B(Color.FromArgb(90, 255, 120, 200)), sx - 1f, y, 2f, 8f);
        }
    }

    private void DrawTurret(Graphics g, Obstacle o, float sx, float px, float py, float time, float fl)
    {
        float dirIn = o.FromTop ? -1f : 1f;
        float baseY = o.Y + dirIn * 4f;
        float ang = MathF.Atan2(py - o.Y, px - sx);
        if (o.Style == Terrain.StyleOrganic)
        {
            // a fleshy spore pod with an eye
            g.FillEllipse(B(C(150, 50, 100, fl, 1f)), sx - 18f, o.Y - 16f, 36f, 32f);
            g.FillEllipse(B(C(210, 100, 150, fl, 1f)), sx - 12f, o.Y - 14f, 20f, 12f);
            g.DrawEllipse(P(Color.FromArgb(255, 60, 14, 40), 1.8f), sx - 18f, o.Y - 16f, 36f, 32f);
            float pulse = 0.6f + 0.4f * MathF.Sin(time * 4f + o.Id);
            g.FillEllipse(B(C(255, 70, 60, fl, 1f)), sx - 7f, o.Y - 7f, 14f, 14f);
            g.FillEllipse(B(Color.FromArgb(A(150 + 100 * pulse), 255, 230, 200)), sx - 2.5f + MathF.Cos(ang) * 2f, o.Y - 2.5f + MathF.Sin(ang) * 2f, 5f, 5f);
            return;
        }
        g.FillRectangle(B(C(70, 76, 100, fl, 1f)), sx - 18f, o.FromTop ? o.Y - 16f : o.Y + 2f, 36f, 14f);
        g.FillEllipse(B(C(110, 118, 148, fl, 1f)), sx - 13f, o.Y - 13f, 26f, 26f);
        g.DrawEllipse(P(Color.FromArgb(255, 16, 18, 30), 1.8f), sx - 13f, o.Y - 13f, 26f, 26f);
        g.DrawLine(P(Color.FromArgb(255, 30, 34, 50), 6f), sx, o.Y, sx + MathF.Cos(ang) * 20f, o.Y + MathF.Sin(ang) * 20f);
        g.DrawLine(P(Color.FromArgb(255, 150, 158, 188), 2.5f), sx, o.Y, sx + MathF.Cos(ang) * 19f, o.Y + MathF.Sin(ang) * 19f);
        bool blink = ((int)(time * 3f + o.Id) & 1) == 0;
        g.FillEllipse(B(blink ? Color.FromArgb(255, 255, 80, 70) : Color.FromArgb(255, 110, 30, 30)), sx - 3.5f, o.Y - 3.5f, 7f, 7f);
    }

    private void DrawPillar(Graphics g, Obstacle o, float sx, float time)
    {
        RectangleF r = o.Rect(0f);
        float x = sx - o.W / 2f;
        float y = r.Y;
        float h = o.H;
        bool organic = o.Style == Terrain.StyleOrganic;
        Color baseC = organic ? Color.FromArgb(255, 150, 66, 104) : Color.FromArgb(255, 92, 100, 128);
        Color darkC = organic ? Color.FromArgb(255, 84, 28, 60) : Color.FromArgb(255, 50, 56, 78);
        g.FillRectangle(B(baseC), x, y, o.W, h);
        g.FillRectangle(B(darkC), x + o.W * 0.6f, y, o.W * 0.4f, h);
        float tipY = o.FromTop ? y + h : y;
        if (organic)
        {
            g.FillEllipse(B(baseC), x - 4f, tipY - 16f, o.W + 8f, 32f);
            g.DrawEllipse(P(Color.FromArgb(255, 56, 14, 40), 2f), x - 4f, tipY - 16f, o.W + 8f, 32f);
            for (float k = 20f; k < h - 10f; k += 34f)
            {
                float vy = o.FromTop ? y + h - k : y + k;
                g.DrawLine(P(Color.FromArgb(150, 220, 110, 150), 2f), x + 6f, vy, x + o.W - 6f, vy + 10f);
            }
            float pulse = 0.5f + 0.5f * MathF.Sin(time * 2f + o.Id);
            g.FillEllipse(B(Color.FromArgb(A(120 + 120 * pulse), 140, 255, 170)), sx - 6f, tipY - 6f, 12f, 12f);
        }
        else
        {
            for (float k = 14f; k < h; k += 28f)
            {
                float ly = o.FromTop ? y + k : y + h - k;
                g.FillRectangle(B(Color.FromArgb(255, 60, 68, 92)), x, ly, o.W, 3f);
            }
            for (float k = 0; k < 4; k++)
            {
                bool yel = ((int)k & 1) == 0;
                float ty = o.FromTop ? y + h - 8f - k * 8f : y + k * 8f;
                g.FillRectangle(B(yel ? Color.FromArgb(255, 240, 190, 40) : Color.FromArgb(255, 30, 30, 38)), x, ty, o.W, 8f);
            }
            bool blink = ((int)(time * 3f + o.Id) & 1) == 0;
            g.FillEllipse(B(blink ? Color.FromArgb(255, 90, 220, 255) : Color.FromArgb(255, 40, 90, 110)), sx - 3.5f, o.FromTop ? y + h - 46f : y + 38f, 7f, 7f);
        }
        g.DrawRectangle(P(Color.FromArgb(255, 14, 16, 28), 2f), x, y, o.W, h);
    }

    // ------------------------------------------------------------------ boss

    public void DrawBoss(Graphics g, Boss b, float time)
    {
        float fl = b.HitFlash > 0f ? 0.6f : 0f;

        // the warned lane and the sweeping beam (behind the body)
        if (b.LaneY >= 0f)
        {
            bool on = ((int)(time * 16f) & 1) == 0;
            g.FillRectangle(B(Color.FromArgb(on ? 120 : 50, 255, 60, 60)), 0f, b.LaneY - 2f, b.X - 150f, 4f);
        }
        if (b.BeamWarn)
        {
            bool on = ((int)(time * 14f) & 1) == 0;
            g.FillRectangle(B(Color.FromArgb(on ? 150 : 60, 255, 70, 90)), 0f, b.BeamY - 3f, b.X - 150f, 6f);
        }
        if (b.BeamActive)
        {
            float flick = 0.8f + 0.2f * MathF.Sin(time * 70f);
            float len = b.X - 150f;
            g.FillRectangle(B(Color.FromArgb(A(70 * flick), 255, 60, 110)), 0f, b.BeamY - 28f, len, 56f);
            g.FillRectangle(B(Color.FromArgb(A(170 * flick), 255, 90, 140)), 0f, b.BeamY - Boss.BeamThick / 2f, len, Boss.BeamThick);
            g.FillRectangle(B(Color.FromArgb(255, 255, 240, 245)), 0f, b.BeamY - 5f, len, 10f);
        }

        DrawBossArms(g, b, fl);

        GraphicsState st = g.Save();
        float wobble = b.Dying ? MathF.Sin(time * 45f) * 3f : 0f;
        g.TranslateTransform(b.X + wobble, b.Y);
        Color line = Color.FromArgb(255, 30, 26, 24);

        // crest spikes on the back of the head
        for (int k = -2; k <= 2; k++)
        {
            tri[0] = new PointF(70f, k * 60f - 16f);
            tri[1] = new PointF(70f, k * 60f + 16f);
            tri[2] = new PointF(112f, k * 60f);
            g.FillPolygon(B(C(170, 158, 138, fl, 1f)), tri);
            g.DrawPolygon(P(line, 2f), tri);
        }

        g.FillPolygon(boneBrush, BossHead);
        g.DrawPolygon(P(line, 3.5f), BossHead);

        // mechanical plates and pipes on the rear of the skull
        g.FillRectangle(B(C(104, 108, 124, fl, 1f)), 10f, -156f, 112f, 62f);
        g.FillRectangle(B(C(104, 108, 124, fl, 1f)), 10f, 94f, 112f, 62f);
        g.FillRectangle(B(C(80, 84, 100, fl, 1f)), 28f, -34f, 96f, 68f);
        g.DrawRectangle(P(line, 2f), 10f, -156f, 112f, 62f);
        g.DrawRectangle(P(line, 2f), 10f, 94f, 112f, 62f);
        g.DrawRectangle(P(line, 2f), 28f, -34f, 96f, 68f);
        for (int k = 0; k < 6; k++) g.DrawLine(P(Color.FromArgb(255, 50, 54, 68), 2f), 34f, -28f + k * 11f, 118f, -28f + k * 11f);
        for (int k = 0; k < 5; k++)
        {
            g.FillEllipse(B(Color.FromArgb(255, 60, 64, 78)), 16f + k * 22f, -150f, 6f, 6f);
            g.FillEllipse(B(Color.FromArgb(255, 60, 64, 78)), 16f + k * 22f, 144f, 6f, 6f);
        }
        float lightPulse = 0.5f + 0.5f * MathF.Sin(time * 5f);
        g.FillEllipse(B(Color.FromArgb(A(120 + 130 * lightPulse), 255, 60, 50)), 100f, -8f, 14f, 16f);

        // brow ridges
        g.DrawLine(P(Color.FromArgb(255, 140, 128, 110), 5f), -140f, -118f, -60f, -140f);
        g.DrawLine(P(Color.FromArgb(255, 140, 128, 110), 5f), -140f, 118f, -60f, 140f);

        DrawBossEye(g, b.EyeTopHp > 0f, -138f, -78f, time, fl, b.Phase);
        DrawBossEye(g, b.EyeBottomHp > 0f, -138f, 78f, time, fl, b.Phase);
        DrawBossMouth(g, b, time);

        if (fl > 0f)
        {
            g.FillPolygon(B(Color.FromArgb(A(110 * fl / 0.6f), 255, 255, 255)), BossHead);
        }
        if (b.Dying)
        {
            g.FillPolygon(B(Color.FromArgb(A(Math.Min(160f, b.DeathTimer * 50f)), 30, 10, 0)), BossHead);
        }
        g.Restore(st);
    }

    private void DrawBossEye(Graphics g, bool alive, float x, float y, float time, float fl, int phase)
    {
        g.FillEllipse(B(Color.FromArgb(255, 40, 14, 16)), x - 36f, y - 36f, 72f, 72f);
        g.DrawEllipse(P(Color.FromArgb(255, 20, 8, 8), 3f), x - 36f, y - 36f, 72f, 72f);
        if (alive)
        {
            float pulse = 0.65f + 0.35f * MathF.Sin(time * (3f + phase * 1.5f) + y);
            Glow(g, x, y, 26f, Color.FromArgb(255, 255, 60, 40), 0.5f + 0.5f * pulse);
            g.FillEllipse(B(C(230, 40, 30, fl, 1f)), x - 26f, y - 26f, 52f, 52f);
            g.FillEllipse(B(C(255, 110, 70, fl, 1f)), x - 17f, y - 19f, 28f, 22f);
            g.FillEllipse(B(Color.FromArgb(220, 255, 240, 220)), x - 12f, y - 16f, 11f, 8f);
            g.FillEllipse(B(Color.FromArgb(255, 40, 10, 10)), x - 6f, y - 4f, 12f, 12f);
        }
        else
        {
            g.FillEllipse(B(Color.FromArgb(255, 24, 10, 10)), x - 26f, y - 26f, 52f, 52f);
            g.FillEllipse(B(Color.FromArgb(100, 80, 80, 80)), x - 20f, y - 20f + MathF.Sin(time * 3f) * 3f, 30f, 18f);
        }
    }

    private void DrawBossMouth(Graphics g, Boss b, float time)
    {
        float open = b.Openness;
        float h = 8f + 100f * open;
        float x0 = -150f;
        float w = 86f;
        g.FillRectangle(B(Color.FromArgb(255, 70, 8, 16)), x0, -h / 2f, w, h);
        if (b.CoreOpen && b.CoreHp > 0f && open > 0.4f)
        {
            float pulse = 0.6f + 0.4f * MathF.Sin(time * 7f);
            float frac = b.CoreHp / GameConfig.BossCoreHp;
            Glow(g, -140f, 0f, 30f, Color.FromArgb(255, 255, 150, 40), (0.5f + 0.5f * pulse) * open);
            g.FillEllipse(B(Color.FromArgb(255, 255, (int)(110 + 80 * frac), 40)), -140f - 28f, -28f, 56f, 56f);
            g.FillEllipse(B(Color.FromArgb(255, 255, 240, 190)), -140f - 12f, -14f, 24f, 24f);
        }
        // teeth on the upper and lower jaw
        for (int k = 0; k < 6; k++)
        {
            float tx = x0 + 4f + k * 14f;
            tri[0] = new PointF(tx, -h / 2f);
            tri[1] = new PointF(tx + 12f, -h / 2f);
            tri[2] = new PointF(tx + 6f, -h / 2f + 18f);
            g.FillPolygon(B(Color.FromArgb(255, 236, 228, 206)), tri);
            tri[0] = new PointF(tx, h / 2f);
            tri[1] = new PointF(tx + 12f, h / 2f);
            tri[2] = new PointF(tx + 6f, h / 2f - 18f);
            g.FillPolygon(B(Color.FromArgb(255, 236, 228, 206)), tri);
        }
        g.DrawRectangle(P(Color.FromArgb(255, 30, 6, 10), 2.5f), x0, -h / 2f, w, h);
    }

    private void DrawBossArms(Graphics g, Boss b, float fl)
    {
        for (int a = 0; a < 2; a++)
        {
            PointF[] pts = b.Arms[a];
            for (int i = 0; i < 3; i++)
            {
                float wd = 22f - 4f * i;
                g.DrawLine(P(Color.FromArgb(255, 30, 26, 24), wd + 5f), pts[i], pts[i + 1]);
                g.DrawLine(P(C(206, 196, 174, fl, 1f), wd), pts[i], pts[i + 1]);
                g.DrawLine(P(C(120, 112, 98, fl, 1f), wd * 0.35f), pts[i], pts[i + 1]);
                g.FillEllipse(B(C(104, 108, 124, fl, 1f)), pts[i].X - wd / 2f - 3f, pts[i].Y - wd / 2f - 3f, wd + 6f, wd + 6f);
                g.DrawEllipse(P(Color.FromArgb(255, 30, 26, 24), 2f), pts[i].X - wd / 2f - 3f, pts[i].Y - wd / 2f - 3f, wd + 6f, wd + 6f);
            }
            // the claw at the tip: two curved prongs
            float ang = MathF.Atan2(pts[3].Y - pts[2].Y, pts[3].X - pts[2].X);
            for (int s = -1; s <= 1; s += 2)
            {
                float pa = ang + s * 0.55f;
                PointF tip = new PointF(pts[3].X + MathF.Cos(pa) * 34f, pts[3].Y + MathF.Sin(pa) * 34f);
                g.DrawLine(P(Color.FromArgb(255, 30, 26, 24), 11f), pts[3], tip);
                g.DrawLine(P(C(226, 216, 190, fl, 1f), 7f), pts[3], tip);
            }
            g.FillEllipse(B(Color.FromArgb(255, 255, 70, 60)), pts[3].X - 4f, pts[3].Y - 4f, 8f, 8f);
        }
    }

    // ------------------------------------------------------------------ bonuses

    public void DrawBonus(Graphics g, Bonus b, float time)
    {
        float spin = MathF.Cos(b.Age * 3.2f);
        float sx = 0.62f + 0.38f * Math.Abs(spin);
        float pulse = 0.6f + 0.4f * MathF.Sin(b.Age * 6f);
        Color baseC, rim;
        switch (b.Type)
        {
            case BonusType.Weapon: baseC = Color.FromArgb(214, 36, 36); rim = Color.FromArgb(255, 130, 110); break;
            case BonusType.Shield: baseC = Color.FromArgb(30, 84, 200); rim = Color.FromArgb(140, 200, 255); break;
            case BonusType.Life: baseC = Color.FromArgb(40, 160, 76); rim = Color.FromArgb(150, 255, 170); break;
            case BonusType.Bomb: baseC = Color.FromArgb(190, 140, 20); rim = Color.FromArgb(255, 226, 110); break;
            default: baseC = Color.FromArgb(130, 50, 180); rim = Color.FromArgb(230, 160, 255); break;
        }
        g.FillEllipse(B(Color.FromArgb(A(55 * pulse), rim.R, rim.G, rim.B)), b.X - 28f, b.Y - 28f, 56f, 56f);
        g.FillEllipse(B(Color.FromArgb(A(40 * pulse), rim.R, rim.G, rim.B)), b.X - 36f, b.Y - 36f, 72f, 72f);

        GraphicsState st = g.Save();
        g.TranslateTransform(b.X, b.Y);
        g.ScaleTransform(sx, 1f);
        const float r = Bonus.Radius;
        g.FillEllipse(B(baseC), -r, -r, r * 2f, r * 2f);
        g.FillEllipse(B(Color.FromArgb(70, 255, 255, 255)), -r * 0.7f, -r * 0.9f, r * 1.2f, r * 0.8f);
        g.DrawEllipse(P(rim, 3f), -r, -r, r * 2f, r * 2f);
        g.DrawEllipse(P(Color.FromArgb(255, 20, 20, 30), 1.2f), -r - 1.5f, -r - 1.5f, r * 2f + 3f, r * 2f + 3f);
        switch (b.Type)
        {
            case BonusType.Weapon:
                g.DrawString("P", fBonus, B(Color.FromArgb(255, 255, 230, 120)), 0f, 1f, sfCenter);
                break;
            case BonusType.Shield:
                quad[0] = new PointF(-9f, -9f);
                quad[1] = new PointF(9f, -9f);
                quad[2] = new PointF(9f, 2f);
                quad[3] = new PointF(0f, 11f);
                g.FillPolygon(B(Color.White), quad);
                g.FillPolygon(B(Color.FromArgb(255, 60, 120, 230)), new[] { new PointF(-5f, -5f), new PointF(5f, -5f), new PointF(5f, 1f), new PointF(0f, 6f), new PointF(-5f, 1f) });
                break;
            case BonusType.Life:
                g.FillRectangle(B(Color.White), -11f, -2f, 22f, 4f);
                g.FillRectangle(B(Color.White), -3f, -10f, 6f, 20f);
                g.FillEllipse(B(Color.White), 6f, -3f, 6f, 6f);
                break;
            case BonusType.Bomb:
                g.DrawString("B", fBonus, B(Color.FromArgb(255, 255, 250, 200)), 0f, 1f, sfCenter);
                break;
            default:
                g.DrawString("$", fBonus, B(Color.White), 0f, 1f, sfCenter);
                break;
        }
        g.Restore(st);
    }

    // ------------------------------------------------------------------ projectiles and beams

    public void DrawProjectile(Graphics g, Projectile p, float time)
    {
        float sp = MathF.Sqrt(p.VX * p.VX + p.VY * p.VY);
        float nx = sp > 0.01f ? p.VX / sp : 1f;
        float ny = sp > 0.01f ? p.VY / sp : 0f;
        switch (p.Kind)
        {
            case ShotKind.PlayerBullet:
                g.DrawLine(P(Color.FromArgb(110, 70, 170, 255), 9f), p.X - nx * 12f, p.Y - ny * 12f, p.X + nx * 6f, p.Y + ny * 6f);
                g.DrawLine(P(Color.FromArgb(255, 120, 210, 255), 5f), p.X - nx * 10f, p.Y - ny * 10f, p.X + nx * 6f, p.Y + ny * 6f);
                g.DrawLine(P(Color.White, 2.2f), p.X - nx * 8f, p.Y - ny * 8f, p.X + nx * 6f, p.Y + ny * 6f);
                break;
            case ShotKind.PlayerSpread:
                g.DrawLine(P(Color.FromArgb(110, 200, 255, 100), 8f), p.X - nx * 8f, p.Y - ny * 8f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.FromArgb(255, 230, 255, 120), 4.5f), p.X - nx * 7f, p.Y - ny * 7f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.White, 1.8f), p.X - nx * 5f, p.Y - ny * 5f, p.X + nx * 4f, p.Y + ny * 4f);
                break;
            case ShotKind.PodShot:
                g.DrawLine(P(Color.FromArgb(120, 255, 140, 40), 8f), p.X - nx * 9f, p.Y - ny * 9f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.FromArgb(255, 255, 190, 80), 4.5f), p.X - nx * 8f, p.Y - ny * 8f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.White, 1.8f), p.X - nx * 5f, p.Y - ny * 5f, p.X + nx * 4f, p.Y + ny * 4f);
                break;
            case ShotKind.ChargeShot:
                DrawChargeShot(g, p, time);
                break;
            case ShotKind.EnemySmall:
                g.DrawLine(P(Color.FromArgb(120, 255, 80, 30), 9f), p.X - nx * 8f, p.Y - ny * 8f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.FromArgb(255, 255, 110, 40), 6f), p.X - nx * 7f, p.Y - ny * 7f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.FromArgb(255, 255, 230, 120), 3f), p.X - nx * 4f, p.Y - ny * 4f, p.X + nx * 4f, p.Y + ny * 4f);
                break;
            case ShotKind.EnemyOrb:
                {
                    float pulse = 0.8f + 0.2f * MathF.Sin(time * 14f + p.Age * 8f);
                    g.FillEllipse(B(Color.FromArgb(A(110 * pulse), 255, 70, 40)), p.X - 13f, p.Y - 13f, 26f, 26f);
                    g.FillEllipse(B(Color.FromArgb(255, 255, 100, 50)), p.X - 8f, p.Y - 8f, 16f, 16f);
                    g.FillEllipse(B(Color.FromArgb(255, 255, 230, 140)), p.X - 4.5f, p.Y - 4.5f, 9f, 9f);
                    break;
                }
            case ShotKind.EnemyHeavy:
                g.FillEllipse(B(Color.FromArgb(100, 230, 60, 200)), p.X - 17f, p.Y - 17f, 34f, 34f);
                g.FillEllipse(B(Color.FromArgb(255, 220, 50, 170)), p.X - 11f, p.Y - 11f, 22f, 22f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 160, 230)), p.X - 6.5f, p.Y - 6.5f, 13f, 13f);
                g.FillEllipse(B(Color.White), p.X - 3f, p.Y - 3f, 6f, 6f);
                break;
            case ShotKind.BossOrb:
                g.FillEllipse(B(Color.FromArgb(90, 255, 70, 140)), p.X - 18f, p.Y - 18f, 36f, 36f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 70, 130)), p.X - 11f, p.Y - 11f, 22f, 22f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 170, 200)), p.X - 6.5f, p.Y - 6.5f, 13f, 13f);
                g.FillEllipse(B(Color.White), p.X - 3f, p.Y - 3f, 6f, 6f);
                break;
            default:    // boss bolt: a long red lance
                g.DrawLine(P(Color.FromArgb(110, 255, 40, 60), 11f), p.X - nx * 24f, p.Y - ny * 24f, p.X + nx * 8f, p.Y + ny * 8f);
                g.DrawLine(P(Color.FromArgb(255, 255, 80, 90), 6f), p.X - nx * 22f, p.Y - ny * 22f, p.X + nx * 8f, p.Y + ny * 8f);
                g.DrawLine(P(Color.White, 2.5f), p.X - nx * 16f, p.Y - ny * 16f, p.X + nx * 8f, p.Y + ny * 8f);
                break;
        }
    }

    private void DrawChargeShot(Graphics g, Projectile p, float time)
    {
        float c = p.Charge;
        float r = p.Radius;
        bool full = c > 0.95f;
        float pulse = 0.85f + 0.15f * MathF.Sin(time * 40f);
        // a bright trail
        g.FillRectangle(B(Color.FromArgb(A(70 + 40 * c), 90, 190, 255)), p.X - r * 4f, p.Y - r * 0.55f, r * 4f, r * 1.1f);
        g.FillRectangle(B(Color.FromArgb(A(120 + 60 * c), 170, 230, 255)), p.X - r * 2.4f, p.Y - r * 0.3f, r * 2.4f, r * 0.6f);
        g.FillEllipse(B(Color.FromArgb(A(80 * pulse), 90, 180, 255)), p.X - r * 1.7f, p.Y - r * 1.7f, r * 3.4f, r * 3.4f);
        g.FillEllipse(B(Color.FromArgb(A(170 * pulse), 120, 210, 255)), p.X - r * 1.25f, p.Y - r * 1.25f, r * 2.5f, r * 2.5f);
        g.FillEllipse(B(Color.FromArgb(255, 190, 240, 255)), p.X - r, p.Y - r, r * 2f, r * 2f);
        g.FillEllipse(B(Color.White), p.X - r * 0.55f, p.Y - r * 0.55f, r * 1.1f, r * 1.1f);
        if (full)
        {
            for (int k = 0; k < 3; k++)
            {
                float a = time * 18f + k * 2.1f;
                g.DrawEllipse(P(Color.FromArgb(200, 220, 250, 255), 2f), p.X - r * 1.5f + MathF.Cos(a) * 4f, p.Y - r * 0.7f + MathF.Sin(a) * 6f, r * 3f, r * 1.4f);
            }
        }
    }

    public void DrawBeam(Graphics g, LaserBeam b)
    {
        float k = 1f - b.Age / b.Life;
        g.FillRectangle(B(Color.FromArgb(A(70 * k), 255, 80, 190)), b.X, b.Y - 12f, b.Length, 24f);
        g.FillRectangle(B(Color.FromArgb(A(170 * k), 255, 130, 220)), b.X, b.Y - 6f, b.Length, 12f);
        g.FillRectangle(B(Color.FromArgb(A(255 * k), 255, 245, 255)), b.X, b.Y - 2.5f, b.Length, 5f);
        g.FillEllipse(B(Color.FromArgb(A(220 * k), 255, 200, 240)), b.X + b.Length - 8f, b.Y - 8f, 16f, 16f);
    }

    // ------------------------------------------------------------------ explosions and particles

    public void DrawExplosion(Graphics g, Explosion e)
    {
        if (e.Age < 0f) return;
        float t = e.Progress;
        float ease = 1f - (1f - t) * (1f - t);
        float r = e.Size * (0.3f + 0.7f * ease);
        float fade = 1f - t;
        if (t > 0.45f)
        {
            float s = (t - 0.45f) / 0.55f;
            g.FillEllipse(B(Color.FromArgb(A(120 * (1f - s)), 50, 50, 56)), e.X - r * 1.15f, e.Y - r * 1.15f, r * 2.3f, r * 2.3f);
        }
        g.FillEllipse(B(Color.FromArgb(A(230 * fade), 255, 100, 30)), e.X - r, e.Y - r, r * 2f, r * 2f);
        g.FillEllipse(B(Color.FromArgb(A(240 * fade), 255, 180, 50)), e.X - r * 0.72f, e.Y - r * 0.72f, r * 1.44f, r * 1.44f);
        float core = r * 0.5f * fade;
        g.FillEllipse(B(Color.FromArgb(A(255 * fade * fade + 20), 255, 250, 210)), e.X - core, e.Y - core, core * 2f, core * 2f);
        if (e.Kind != ExplosionKind.Small)
        {
            float rr = e.Size * (0.4f + 1.3f * t);
            g.DrawEllipse(P(Color.FromArgb(A(200 * fade), 255, 230, 170), 3f), e.X - rr, e.Y - rr, rr * 2f, rr * 2f);
        }
    }

    public void DrawParticles(Graphics g, ParticleSystem ps)
    {
        for (int i = 0; i < ps.Count; i++)
        {
            Particle p = ps.Items[i];
            float k = p.Life / p.MaxLife;
            switch (p.Kind)
            {
                case 0:
                    {
                        float r = p.Size * (1f + (1f - k) * 1.4f);
                        g.FillEllipse(B(Color.FromArgb(A(130 * k), p.R, p.G, p.B)), p.X - r, p.Y - r, r * 2f, r * 2f);
                        break;
                    }
                case 1:
                    {
                        float vx = p.VX * 0.03f;
                        float vy = p.VY * 0.03f;
                        g.DrawLine(P(Color.FromArgb(A(255 * k), p.R, p.G, p.B), p.Size), p.X, p.Y, p.X - vx, p.Y - vy);
                        break;
                    }
                case 2:
                    {
                        float c = MathF.Cos(p.Rot) * p.Size;
                        float s = MathF.Sin(p.Rot) * p.Size;
                        quad[0] = new PointF(p.X - c - s * 0.5f, p.Y - s + c * 0.5f);
                        quad[1] = new PointF(p.X + c - s * 0.5f, p.Y + s + c * 0.5f);
                        quad[2] = new PointF(p.X + c + s * 0.5f, p.Y + s - c * 0.5f);
                        quad[3] = new PointF(p.X - c + s * 0.5f, p.Y - s - c * 0.5f);
                        g.FillPolygon(B(Color.FromArgb(A(255 * Math.Min(1f, k * 2f)), p.R, p.G, p.B)), quad);
                        break;
                    }
                case 3:
                    {
                        float r = p.Size * (1f - k);
                        g.DrawEllipse(P(Color.FromArgb(A(220 * k), p.R, p.G, p.B), 3f), p.X - r, p.Y - r, r * 2f, r * 2f);
                        break;
                    }
                default:
                    {
                        float r = p.Size * k;
                        g.FillEllipse(B(Color.FromArgb(A(220 * k), p.R, p.G, p.B)), p.X - r, p.Y - r, r * 2f, r * 2f);
                        break;
                    }
            }
        }
        foreach (FloatText t in ps.Texts)
        {
            float a = Math.Min(1f, t.Life * 2f);
            g.DrawString(t.Text, fText, B(Color.FromArgb(A(200 * a), 0, 0, 0)), t.X + 1f, t.Y + 1f, sfCenter);
            g.DrawString(t.Text, fText, B(Color.FromArgb(A(255 * a), t.Color.R, t.Color.G, t.Color.B)), t.X, t.Y, sfCenter);
        }
    }
}
