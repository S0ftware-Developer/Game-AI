namespace RTypeSpaceShooter;

public enum WeaponType { Standard, Spread, Laser }

/// <summary>
/// The player's weapons: the primary weapon advances through five stages (standard single, standard twin, spread of
/// three, spread of five, laser), and the chargeable wave cannon on a separate key. A Force Pod attached to the ship
/// adds shots in its direction.
/// </summary>
public sealed class WeaponSystem
{
    public const int MaxStage = 4;

    public int Stage;
    public float FireTimer, LaserTimer, Charge, ChargeCooldown, MuzzleTimer;
    public bool Charging;
    public bool EvShot, EvLaser, EvCharged, EvChargeFull;
    public float EvChargeLevel;
    private bool wasFull;

    public WeaponType Type
    {
        get { return Stage <= 1 ? WeaponType.Standard : (Stage <= 3 ? WeaponType.Spread : WeaponType.Laser); }
    }

    public string Name
    {
        get { return Type == WeaponType.Standard ? "VULCAN" : (Type == WeaponType.Spread ? "SPREAD" : "LASER"); }
    }

    /// <summary>1-based level inside the current weapon type.</summary>
    public int Level
    {
        get { return Stage <= 1 ? Stage + 1 : (Stage <= 3 ? Stage - 1 : 1); }
    }

    public int MaxLevel
    {
        get { return Type == WeaponType.Laser ? 1 : 2; }
    }

    public void Reset()
    {
        Stage = 0;
        FireTimer = 0f;
        LaserTimer = 0f;
        Charge = 0f;
        ChargeCooldown = 0f;
        MuzzleTimer = 0f;
        Charging = false;
        wasFull = false;
    }

    /// <summary>Advances to the next stage. Returns false when the weapon is already at its maximum.</summary>
    public bool Upgrade()
    {
        if (Stage >= MaxStage) return false;
        Stage++;
        return true;
    }

    public void Update(float dt, PlayerShip s, bool fire, bool chargeHeld, ProjectileManager shots, Terrain terrain, float scroll, ForcePod pod)
    {
        if (FireTimer > 0f) FireTimer -= dt;
        if (LaserTimer > 0f) LaserTimer -= dt;
        if (ChargeCooldown > 0f) ChargeCooldown -= dt;
        if (MuzzleTimer > 0f) MuzzleTimer = Math.Max(0f, MuzzleTimer - dt);

        float nx = s.X + 28f;
        float ny = s.Y;

        if (fire)
        {
            if (Type == WeaponType.Laser)
            {
                if (LaserTimer <= 0f)
                {
                    FireLaser(shots, terrain, scroll, nx, ny);
                    LaserTimer = GameConfig.LaserInterval;
                    MuzzleTimer = 0.1f;
                    EvLaser = true;
                }
            }
            else if (FireTimer <= 0f)
            {
                Volley(shots, nx, ny);
                FireTimer = GameConfig.FireInterval;
                MuzzleTimer = 0.05f;
                EvShot = true;
            }
        }

        // the wave cannon: hold to charge, release to fire, and it must be released before charging again
        if (chargeHeld && ChargeCooldown <= 0f)
        {
            Charging = true;
            Charge = Math.Min(1f, Charge + dt / GameConfig.ChargeTime);
            if (Charge >= 1f && !wasFull)
            {
                wasFull = true;
                EvChargeFull = true;
            }
        }
        else if (Charging)
        {
            if (Charge >= GameConfig.ChargeMin) FireCharged(shots, nx, ny);
            Charging = false;
            Charge = 0f;
            wasFull = false;
        }
    }

    private void Volley(ProjectileManager shots, float nx, float ny)
    {
        const float v = 760f;
        switch (Stage)
        {
            case 0:
                shots.SpawnPlayer(ShotKind.PlayerBullet, nx, ny, v, 0f, 1f, 4f, 1);
                break;
            case 1:
                shots.SpawnPlayer(ShotKind.PlayerBullet, nx, ny - 5f, v, 0f, 1f, 4f, 1);
                shots.SpawnPlayer(ShotKind.PlayerBullet, nx, ny + 5f, v, 0f, 1f, 4f, 1);
                break;
            case 2:
                for (int i = -1; i <= 1; i++)
                {
                    float a = i * 0.2f;
                    shots.SpawnPlayer(ShotKind.PlayerSpread, nx, ny, MathF.Cos(a) * 700f, MathF.Sin(a) * 700f, 1f, 4f, 1);
                }
                break;
            default:
                for (int i = -2; i <= 2; i++)
                {
                    float a = i * 0.17f;
                    shots.SpawnPlayer(ShotKind.PlayerSpread, nx, ny, MathF.Cos(a) * 700f, MathF.Sin(a) * 700f, 1f, 4f, 1);
                }
                break;
        }
    }

    /// <summary>Called by the engine for the Force Pod's extra shots when it is attached.</summary>
    public void PodVolley(ProjectileManager shots, ForcePod pod)
    {
        if (pod.State == PodState.AttachedFront)
            shots.SpawnPlayer(ShotKind.PodShot, pod.X + 18f, pod.Y, 700f, 0f, 1f, 4f, 1);
        else if (pod.State == PodState.AttachedRear)
            shots.SpawnPlayer(ShotKind.PodShot, pod.X - 18f, pod.Y, -700f, 0f, 1f, 4f, 1);
    }

    private void FireLaser(ProjectileManager shots, Terrain terrain, float scroll, float nx, float ny)
    {
        float length = GameConfig.LogicalW - nx + 20f;
        for (float x = nx; x < GameConfig.LogicalW; x += 8f)
        {
            float t, b;
            terrain.Thickness(scroll + x, out t, out b);
            if (ny - 4f < t || ny + 4f > GameConfig.ViewH - b)
            {
                length = x - nx;
                break;
            }
        }
        shots.AddBeam(nx, ny, Math.Max(10f, length), 5f);
    }

    private void FireCharged(ProjectileManager shots, float nx, float ny)
    {
        float c = Charge;
        float damage = 6f + 44f * c;
        float radius = 9f + 24f * c;
        int pierce = 1 + (int)(c * 8f);
        Projectile p = shots.SpawnPlayer(ShotKind.ChargeShot, nx + 10f, ny, 780f, 0f, damage, radius, pierce);
        p.Charge = c;
        EvCharged = true;
        EvChargeLevel = c;
        ChargeCooldown = GameConfig.ChargeCooldown;
        MuzzleTimer = 0.15f;
    }
}
