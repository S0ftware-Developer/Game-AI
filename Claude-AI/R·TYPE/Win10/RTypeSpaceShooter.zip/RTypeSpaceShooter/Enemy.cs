namespace RTypeSpaceShooter;

public enum EnemyType { Fighter, Interceptor, Heavy, Organic, Elite, Larva }

/// <summary>
/// One alien craft. Every type has its own movement, durability and attack pattern; the numbers grow a little with
/// the difficulty value (0..1 over the mission). Enemies fly from right to left.
/// </summary>
public sealed class Enemy
{
    private static int nextId = 1;

    public int Id;
    public EnemyType Type;
    public float X, Y, VX, VY;
    public float Hp, MaxHp;
    public float HitW, HitH;              // half sizes of the hit box
    public float Age;
    public float HitFlash;
    public float SmokeTimer;
    public float Bank;                    // -1..1 vertical movement, for drawing
    public bool Alive;
    public int Score;

    private float baseY, amp, freq, phase;
    private float shootTimer, burstTimer, spawnTimer;
    private int burstLeft, pattern;

    public bool Smoking { get { return Hp < MaxHp * 0.5f; } }

    public RectangleF Hitbox
    {
        get { return new RectangleF(X - HitW, Y - HitH, HitW * 2f, HitH * 2f); }
    }

    public void Init(EnemyType type, float x, float y, float amp, float freq, float phase, float diff, Random rng)
    {
        Id = nextId++;
        Type = type;
        X = x;
        Y = y;
        baseY = y;
        this.amp = amp;
        this.freq = freq;
        this.phase = phase;
        Alive = true;
        Age = 0f;
        HitFlash = 0f;
        SmokeTimer = 0f;
        Bank = 0f;
        VX = 0f;
        VY = 0f;
        burstLeft = 0;
        pattern = 0;
        switch (type)
        {
            case EnemyType.Fighter:
                HitW = 20f; HitH = 12f; Hp = MathF.Round(3f + 3f * diff); Score = GameConfig.ScoreFighter;
                shootTimer = 1f + (float)rng.NextDouble() * 1.2f;
                break;
            case EnemyType.Interceptor:
                HitW = 16f; HitH = 9f; Hp = MathF.Round(2f + 2f * diff); Score = GameConfig.ScoreInterceptor;
                if (this.amp == 0f) { this.amp = 120f; this.freq = 2.4f; }
                shootTimer = 1.5f + (float)rng.NextDouble() * 2f;
                break;
            case EnemyType.Heavy:
                HitW = 46f; HitH = 28f; Hp = MathF.Round(20f + 12f * diff); Score = GameConfig.ScoreHeavy;
                shootTimer = 1.6f;
                break;
            case EnemyType.Organic:
                HitW = 28f; HitH = 26f; Hp = MathF.Round(12f + 6f * diff); Score = GameConfig.ScoreOrganic;
                shootTimer = 2f;
                spawnTimer = 3.5f;
                break;
            case EnemyType.Elite:
                HitW = 36f; HitH = 24f; Hp = MathF.Round(34f + 16f * diff); Score = GameConfig.ScoreElite;
                shootTimer = 2.4f;
                break;
            default:
                HitW = 10f; HitH = 7f; Hp = 1f; Score = GameConfig.ScoreLarva;
                break;
        }
        MaxHp = Hp;
    }

    public void Damage(float amount)
    {
        Hp -= amount;
        HitFlash = 0.1f;
    }

    private static float Approach(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    private static float Clamp(float v, float lo, float hi)
    {
        return Math.Max(lo, Math.Min(hi, v));
    }

    public void Update(float dt, float px, float py, float diff, ProjectileManager shots, EnemyManager mgr, Random rng, out bool fired)
    {
        fired = false;
        Age += dt;
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        shootTimer -= dt;
        float oldY = Y;
        const float maxY = GameConfig.ViewH - 18f;

        switch (Type)
        {
            case EnemyType.Fighter:
                X -= (170f + 40f * diff) * dt;
                baseY += Clamp(py - baseY, -35f * dt, 35f * dt);
                Y = Clamp(baseY + amp * MathF.Sin(phase + Age * freq), 18f, maxY);
                if (shootTimer <= 0f && X < GameConfig.LogicalW - 40f && X > 180f)
                {
                    float sp = 260f + 60f * diff;
                    shots.FireAimed(ShotKind.EnemySmall, X - 18f, Y, px, py, sp, 0f);
                    if (diff > 0.5f)
                    {
                        shots.FireAimed(ShotKind.EnemySmall, X - 18f, Y, px, py, sp, 0.16f);
                        shots.FireAimed(ShotKind.EnemySmall, X - 18f, Y, px, py, sp, -0.16f);
                    }
                    fired = true;
                    shootTimer = 2f - 0.6f * diff + (float)rng.NextDouble() * 0.8f;
                }
                break;

            case EnemyType.Interceptor:
                X -= 280f * dt;
                baseY += Clamp(py - baseY, -90f * dt, 90f * dt);
                Y = Clamp(baseY + amp * MathF.Sin(phase + Age * freq), 18f, maxY);
                if (diff > 0.3f && shootTimer <= 0f && X < GameConfig.LogicalW - 40f && X > 180f)
                {
                    shots.SpawnEnemy(ShotKind.EnemySmall, X - 14f, Y, -300f, 0f);
                    fired = true;
                    shootTimer = 2.5f + (float)rng.NextDouble() * 1.5f;
                }
                break;

            case EnemyType.Heavy:
                X -= (X > GameConfig.LogicalW - 230f ? 55f : 12f) * dt;
                Y = Clamp(baseY + 30f * MathF.Sin(Age * 0.8f + phase), 40f, GameConfig.ViewH - 40f);
                if (shootTimer <= 0f && X < GameConfig.LogicalW - 40f && X > 150f)
                {
                    if (pattern % 2 == 0)
                    {
                        shots.FireFan(ShotKind.EnemySmall, X - 40f, Y, px, py, 240f, 3, 0.5f);
                        shots.SpawnEnemy(ShotKind.EnemySmall, X - 40f, Y - 16f, -260f, 0f);
                        shots.SpawnEnemy(ShotKind.EnemySmall, X - 40f, Y + 16f, -260f, 0f);
                    }
                    else
                    {
                        shots.FireAimed(ShotKind.EnemyHeavy, X - 40f, Y, px, py, 170f, 0f);
                    }
                    pattern++;
                    fired = true;
                    shootTimer = 2.3f - 0.6f * diff;
                }
                break;

            case EnemyType.Organic:
                {
                    float pulse = 0.4f + 0.6f * MathF.Abs(MathF.Sin(Age * 1.6f));
                    X -= 95f * pulse * dt;
                    Y = Clamp(baseY + 90f * MathF.Sin(Age * 1.1f + phase), 40f, GameConfig.ViewH - 40f);
                    if (shootTimer <= 0f && X < GameConfig.LogicalW - 40f && X > 100f)
                    {
                        shots.FireRing(ShotKind.EnemyOrb, X, Y, 6, 110f, (float)rng.NextDouble() * 6.28f);
                        fired = true;
                        shootTimer = 3.2f - 0.6f * diff;
                    }
                    spawnTimer -= dt;
                    if (spawnTimer <= 0f && X < GameConfig.LogicalW - 60f)
                    {
                        mgr.SpawnChild(EnemyType.Larva, X - 12f, Y - 12f);
                        mgr.SpawnChild(EnemyType.Larva, X - 12f, Y + 12f);
                        spawnTimer = 6f;
                    }
                }
                break;

            case EnemyType.Elite:
                {
                    if (Age < 2f)
                    {
                        float k = Age / 2f;
                        float e = k * k * (3f - 2f * k);
                        X = (GameConfig.LogicalW + 40f) + ((GameConfig.LogicalW - 220f) - (GameConfig.LogicalW + 40f)) * e;
                    }
                    else if (Age < 22f)
                    {
                        X = GameConfig.LogicalW - 220f + 40f * MathF.Sin((Age - 2f) * 1.3f);
                        Y = Clamp(Y + Clamp(py - Y, -130f * dt, 130f * dt), 40f, GameConfig.ViewH - 40f);
                    }
                    else
                    {
                        X -= 180f * dt;
                    }

                    if (burstLeft > 0)
                    {
                        burstTimer -= dt;
                        if (burstTimer <= 0f)
                        {
                            shots.FireFan(ShotKind.EnemySmall, X - 30f, Y, px, py, 270f, 3, 0.45f);
                            burstLeft--;
                            burstTimer = 0.35f;
                            fired = true;
                        }
                    }
                    else if (shootTimer <= 0f && X < GameConfig.LogicalW - 40f && X > 150f)
                    {
                        int p = pattern % 3;
                        if (p == 0)
                        {
                            burstLeft = 2;
                            burstTimer = 0f;
                        }
                        else if (p == 1)
                        {
                            shots.FireRing(ShotKind.EnemyOrb, X, Y, 10, 130f, (float)rng.NextDouble() * 6.28f);
                            fired = true;
                        }
                        else
                        {
                            shots.FireAimed(ShotKind.EnemyHeavy, X - 30f, Y - 14f, px, py, 200f, 0.12f);
                            shots.FireAimed(ShotKind.EnemyHeavy, X - 30f, Y + 14f, px, py, 200f, -0.12f);
                            fired = true;
                        }
                        pattern++;
                        shootTimer = 2.4f - 0.6f * diff;
                    }
                }
                break;

            default:    // Larva: a small homing swarmer
                X -= 125f * dt;
                Y = Clamp(Y + Clamp(py - Y, -95f * dt, 95f * dt) + MathF.Sin(Age * 8f) * 30f * dt, 18f, maxY);
                break;
        }

        Bank = Clamp((Y - oldY) / (dt * 200f), -1f, 1f);
    }
}
