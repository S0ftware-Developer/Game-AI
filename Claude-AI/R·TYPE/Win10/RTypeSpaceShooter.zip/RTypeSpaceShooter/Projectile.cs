namespace RTypeSpaceShooter;

public enum ShotKind { PlayerBullet, PlayerSpread, PodShot, ChargeShot, EnemySmall, EnemyOrb, EnemyHeavy, BossOrb, BossBolt }

/// <summary>A bullet. Instances are pooled by <see cref="ProjectileManager"/>.</summary>
public sealed class Projectile
{
    public float X, Y, VX, VY, AX, AY;
    public float Radius;
    public float Damage;
    public float Age;
    public float Charge;                 // 0..1, only for charged shots (drives size and visuals)
    public ShotKind Kind;
    public bool Alive;
    public int Pierce = 1;               // how many targets it can still pass through
    private readonly int[] hitIds = new int[10];
    private int hitCount;

    /// <summary>Remembers the target; returns false when this shot already hit it (piercing shots).</summary>
    public bool TryHit(int id)
    {
        for (int i = 0; i < hitCount; i++)
        {
            if (hitIds[i] == id) return false;
        }
        if (hitCount < hitIds.Length) hitIds[hitCount++] = id;
        return true;
    }

    public void ResetHits()
    {
        hitCount = 0;
    }
}

/// <summary>A short-lived laser beam. It damages everything along its length once, at the moment it is fired.</summary>
public sealed class LaserBeam
{
    public float X, Y, Length, Thick, Damage, Age, Life;
    public bool Fresh = true;
}
