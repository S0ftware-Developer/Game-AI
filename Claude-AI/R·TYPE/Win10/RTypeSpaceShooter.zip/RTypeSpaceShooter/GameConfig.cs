namespace RTypeSpaceShooter;

/// <summary>All tunable numbers of the game in one place (pixels and seconds).</summary>
public static class GameConfig
{
    // ---- layout (logical pixels, landscape)
    public const int LogicalW = 960;
    public const int LogicalH = 572;
    public const int FooterH = 32;
    public const int ViewH = LogicalH - FooterH;     // height of the battlefield: 540

    // ---- player
    public const float PlayerStartX = 140f;
    public const float PlayerStartY = 270f;
    public const float PlayerMaxSpeed = 290f;
    public const float PlayerAccel = 2800f;
    public const float PlayerDecel = 2400f;
    public const int StartLives = 3;
    public const int MaxLives = 9;
    public const float RespawnDelay = 1.2f;
    public const float RespawnInvulnerability = 2.5f;
    public const float ShieldDuration = 10f;

    // ---- weapons
    public const float FireInterval = 0.13f;
    public const float LaserInterval = 0.42f;
    public const float ChargeTime = 1.4f;            // seconds to a full charge
    public const float ChargeMin = 0.14f;            // the smallest charge that can be released as a shot
    public const float ChargeCooldown = 0.45f;

    // ---- stage
    public const float ScrollSpeed = 70f;
    public const float BossWarningTime = 234f;
    public const float BossArrivalTime = 240f;

    // ---- score
    public const int ScoreFighter = 100;
    public const int ScoreInterceptor = 150;
    public const int ScoreHeavy = 600;
    public const int ScoreOrganic = 300;
    public const int ScoreElite = 1000;
    public const int ScoreLarva = 50;
    public const int ScoreAsteroid = 20;
    public const int ScoreTurret = 150;
    public const int ScoreBoss = 15000;
    public const int ScoreBonusPickup = 250;
    public const int ScoreBonusItem = 1000;

    // ---- boss
    public const int BossEyeHp = 150;
    public const int BossCoreHp = 260;
    public const int BossMaxHp = BossEyeHp * 2 + BossCoreHp;
    public const float BombEnemyDamage = 30f;
    public const float BombBossPartDamage = 15f;
}
