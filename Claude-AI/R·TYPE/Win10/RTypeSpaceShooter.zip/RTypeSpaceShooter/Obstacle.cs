namespace RTypeSpaceShooter;

public enum ObstacleType { Asteroid, Barrier, Gate, Turret, Pillar }

/// <summary>
/// An environmental hazard fixed in the world (it scrolls with the battlefield): drifting asteroids, moving mechanical
/// barriers, pulsing energy gates, stationary turrets on the walls, and pillars that block part of the corridor.
/// </summary>
public sealed class Obstacle
{
    private static int nextId = 1000;

    public int Id = nextId++;
    public ObstacleType Type;
    public float WX, Y;                   // world x and screen y of the centre
    public float W, H;
    public float Hp, MaxHp;
    public float Age, Rot, Spin, DriftX, DriftY;
    public float YLo, YHi, Period, Phase;
    public float GateTop, GateBottom;
    public float ShootTimer, HitFlash;
    public bool FromTop;
    public bool Alive = true;
    public bool GateOn, GateWarn;
    public int Variant;
    public int Style;                     // terrain style at its position (drawing)

    public bool Destructible { get { return Type == ObstacleType.Asteroid || Type == ObstacleType.Turret; } }

    public float Radius { get { return W / 2f; } }

    public float ScreenX(float scroll)
    {
        return WX - scroll;
    }

    /// <summary>The rectangle of a non-round obstacle in screen coordinates.</summary>
    public RectangleF Rect(float scroll)
    {
        float sx = WX - scroll;
        switch (Type)
        {
            case ObstacleType.Barrier:
                return new RectangleF(sx - W / 2f, Y - H / 2f, W, H);
            case ObstacleType.Pillar:
                return FromTop ? new RectangleF(sx - W / 2f, 0f, W, H) : new RectangleF(sx - W / 2f, GameConfig.ViewH - H, W, H);
            case ObstacleType.Turret:
                return new RectangleF(sx - 18f, Y - 16f, 36f, 32f);
            case ObstacleType.Gate:
                return new RectangleF(sx - 9f, GateTop, 18f, GateBottom - GateTop);
            default:
                return new RectangleF(sx - Radius, Y - Radius, W, W);
        }
    }

    /// <summary>True when this obstacle is dangerous right now (gates are only deadly while their beam is on).</summary>
    public bool Dangerous { get { return Type != ObstacleType.Gate || GateOn; } }

    public bool HitsCircle(float cx, float cy, float r, float scroll)
    {
        if (!Alive || !Dangerous) return false;
        if (Type == ObstacleType.Asteroid)
        {
            float dx = cx - (WX - scroll);
            float dy = cy - Y;
            float rr = r + Radius * 0.88f;
            return dx * dx + dy * dy <= rr * rr;
        }
        return CollisionManager.CircleRect(cx, cy, r, Rect(scroll));
    }

    public bool HitsRect(RectangleF box, float scroll)
    {
        if (!Alive || !Dangerous) return false;
        if (Type == ObstacleType.Asteroid) return CollisionManager.CircleRect(WX - scroll, Y, Radius * 0.88f, box);
        return Rect(scroll).IntersectsWith(box);
    }
}
