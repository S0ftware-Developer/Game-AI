namespace RTypeSpaceShooter;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        try
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new GameForm());
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString(), "R-Type Space Shooter - критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
