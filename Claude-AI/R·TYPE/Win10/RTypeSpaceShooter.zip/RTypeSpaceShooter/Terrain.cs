namespace RTypeSpaceShooter;

/// <summary>
/// The solid walls at the top and bottom of the battlefield, defined by the world position (scroll distance) f.
/// Planet surface, industrial corridors with narrow passages, organic walls and the boss lair are blended by
/// keyframes; the combined thickness is capped so the corridor never becomes narrower than 220 px.
/// </summary>
public sealed class Terrain
{
    // keyframes along the stage: f, ceiling amplitude, floor amplitude
    private static readonly float[] KF = { 0f, 3450f, 3900f, 6350f, 6900f, 9300f, 9800f, 12050f, 12250f, 12450f, 14900f, 15500f, 100000f };
    private static readonly float[] KT = { 0f, 0f, 0f, 0f, 0f, 0f, 125f, 125f, 40f, 125f, 125f, 40f, 40f };
    private static readonly float[] KB = { 0f, 0f, 105f, 105f, 0f, 0f, 125f, 125f, 40f, 125f, 125f, 40f, 40f };

    public const int StyleNone = 0, StylePlanet = 1, StyleIndustrial = 2, StyleOrganic = 3, StyleLair = 4;
    public const float MaxCombined = 320f;

    private static float Smooth(float t)
    {
        t = Math.Max(0f, Math.Min(1f, t));
        return t * t * (3f - 2f * t);
    }

    private static float Interp(float[] vals, float f)
    {
        for (int i = 0; i < KF.Length - 1; i++)
        {
            if (f < KF[i + 1])
            {
                float t = Smooth((f - KF[i]) / (KF[i + 1] - KF[i]));
                return vals[i] + (vals[i + 1] - vals[i]) * t;
            }
        }
        return vals[vals.Length - 1];
    }

    private static float Pulse(float f, float c)
    {
        float d = (f - c) / 260f;
        return MathF.Exp(-d * d);
    }

    public int StyleAt(float f)
    {
        if (f >= 15000f) return StyleLair;
        if (f >= 12250f) return StyleOrganic;
        if (f >= 9300f && f < 12250f) return StyleIndustrial;
        if (f >= 3450f && f < 6900f) return StylePlanet;
        return StyleNone;
    }

    /// <summary>Thickness of the ceiling and the floor (in pixels) at the world position f.</summary>
    public void Thickness(float f, out float top, out float bot)
    {
        float at = Interp(KT, f);
        float ab = Interp(KB, f);
        if (at <= 0.5f && ab <= 0.5f)
        {
            top = 0f;
            bot = 0f;
            return;
        }
        int st = StyleAt(f);
        float s1 = 0.62f + 0.30f * MathF.Sin(f * 0.0041f + 1.0f) + 0.12f * MathF.Sin(f * 0.0107f + 2.2f);
        float s2 = 0.62f + 0.30f * MathF.Sin(f * 0.0037f + 3.1f) + 0.12f * MathF.Sin(f * 0.0097f + 0.7f);
        if (st == StylePlanet) s2 += 0.08f * MathF.Sin(f * 0.021f + 1f);
        if (st == StyleOrganic)
        {
            s1 += 0.08f * MathF.Sin(f * 0.031f);
            s2 += 0.08f * MathF.Sin(f * 0.027f + 1.3f);
        }
        top = at * s1;
        bot = ab * s2;
        if (st == StyleIndustrial)
        {
            float p = Pulse(f, 10500f) + Pulse(f, 11450f);
            float env = Math.Min(at, ab) / 125f;
            top += 45f * p * env;
            bot += 45f * p * env;
        }
        top = Math.Max(0f, top);
        bot = Math.Max(0f, bot);
        float sum = top + bot;
        if (sum > MaxCombined)
        {
            float k = MaxCombined / sum;
            top *= k;
            bot *= k;
        }
    }

    public float Top(float f)
    {
        float t, b;
        Thickness(f, out t, out b);
        return t;
    }

    public float Bottom(float f)
    {
        float t, b;
        Thickness(f, out t, out b);
        return b;
    }

    /// <summary>The y of the middle of the free corridor at f.</summary>
    public float CorridorCenter(float f)
    {
        float t, b;
        Thickness(f, out t, out b);
        return (t + (GameConfig.ViewH - b)) / 2f;
    }

    /// <summary>True when the point (world x, screen y) is inside rock.</summary>
    public bool IsSolid(float f, float y)
    {
        float t, b;
        Thickness(f, out t, out b);
        return y < t || y > GameConfig.ViewH - b;
    }

    /// <summary>The largest thickness over a world x range (used to place structures safely).</summary>
    public void MaxThickness(float f0, float f1, out float top, out float bot)
    {
        top = 0f;
        bot = 0f;
        for (float f = f0; f <= f1; f += 12f)
        {
            float t, b;
            Thickness(f, out t, out b);
            if (t > top) top = t;
            if (b > bot) bot = b;
        }
    }
}
