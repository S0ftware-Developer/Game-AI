using System.Media;

namespace Asteroids;

/// <summary>Synthesised sound effects (no files). Every call is guarded: no audio device = silent game.</summary>
internal sealed class Sfx : IDisposable
{
    private readonly Dictionary<string, SoundPlayer> players = new();
    public bool Muted;

    public Sfx()
    {
        // segment: (startHz, endHz, ms, wave 0=square 1=sine 2=noise 3=rumble, volume)
        Add("shoot", MakeWav((950, 240, 80, 0, 0.18)));
        Add("boomBig", MakeWav((0, 0, 480, 3, 0.75)));
        Add("boomMid", MakeWav((0, 0, 300, 3, 0.6)));
        Add("boomSmall", MakeWav((0, 0, 150, 2, 0.28)));
        Add("shipBoom", MakeWav((0, 0, 900, 3, 0.85)));
        Add("level", MakeWav((523, 523, 90, 1, 0.4), (659, 659, 90, 1, 0.4), (784, 784, 90, 1, 0.4), (1047, 1047, 260, 1, 0.4)));
        Add("extralife", MakeWav((880, 880, 80, 1, 0.4), (1175, 1175, 80, 1, 0.4), (1568, 1568, 230, 1, 0.4)));
    }

    public void Play(string name)
    {
        if (Muted) return;
        if (players.TryGetValue(name, out var p))
        {
            try { p.Play(); } catch { /* audio unavailable - ignore */ }
        }
    }

    private void Add(string name, byte[] wav)
    {
        try
        {
            var p = new SoundPlayer(new MemoryStream(wav));
            p.Load();
            players[name] = p;
        }
        catch { /* audio unavailable - ignore */ }
    }

    public void Dispose()
    {
        foreach (var p in players.Values)
        {
            try { p.Stop(); p.Dispose(); } catch { }
        }
        players.Clear();
    }

    private static byte[] MakeWav(params (double f0, double f1, int ms, int wave, double vol)[] segs)
    {
        const int sr = 22050;
        var samples = new List<short>();
        var rnd = new Random(7);
        double phase = 0, lp = 0;

        foreach (var s in segs)
        {
            int n = sr * s.ms / 1000;
            for (int i = 0; i < n; i++)
            {
                double t = (double)i / n;
                double f = s.f0 + (s.f1 - s.f0) * t;
                phase += 2 * Math.PI * f / sr;
                double v;
                switch (s.wave)
                {
                    case 0: v = Math.Sin(phase) >= 0 ? 1.0 : -1.0; break;
                    case 1: v = Math.Sin(phase); break;
                    case 2: v = rnd.NextDouble() * 2 - 1; break;
                    default:
                        lp += 0.12 * ((rnd.NextDouble() * 2 - 1) - lp);      // low-pass noise = rumble
                        v = Math.Max(-1.0, Math.Min(1.0, lp * 4.0));
                        break;
                }
                double env = Math.Min(1.0, i / (sr * 0.004)) * (1.0 - t) * (1.0 - t * 0.3);
                samples.Add((short)(v * env * s.vol * short.MaxValue));
            }
        }

        var ms2 = new MemoryStream();
        var w = new BinaryWriter(ms2);
        int dataLen = samples.Count * 2;
        w.Write(new[] { 'R', 'I', 'F', 'F' });
        w.Write(36 + dataLen);
        w.Write(new[] { 'W', 'A', 'V', 'E' });
        w.Write(new[] { 'f', 'm', 't', ' ' });
        w.Write(16);
        w.Write((short)1);
        w.Write((short)1);
        w.Write(sr);
        w.Write(sr * 2);
        w.Write((short)2);
        w.Write((short)16);
        w.Write(new[] { 'd', 'a', 't', 'a' });
        w.Write(dataLen);
        foreach (short sm in samples) w.Write(sm);
        w.Flush();
        return ms2.ToArray();
    }
}
