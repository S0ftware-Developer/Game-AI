namespace Asteroids;

/// <summary>Hi-score persistence: one integer in %LocalAppData%\Asteroids\highscore.txt (no admin rights needed).</summary>
internal static class HighScoreStore
{
    private static readonly string FilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "Asteroids", "highscore.txt");

    public static int Load()
    {
        try
        {
            if (File.Exists(FilePath) && int.TryParse(File.ReadAllText(FilePath).Trim(), out int v) && v > 0)
                return v;
        }
        catch { /* missing or broken file -> 0 */ }
        return 0;
    }

    public static void Save(int value)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, value.ToString());
        }
        catch { /* ignore */ }
    }
}
