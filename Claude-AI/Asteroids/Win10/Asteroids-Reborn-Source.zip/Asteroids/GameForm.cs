using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace Asteroids;

/// <summary>Window, input and the fixed-timestep loop. No gameplay rules live here.</summary>
internal sealed class GameForm : Form
{
    private const int FooterH = 32;
    private const float StepDt = 1f / 120f;

    private readonly Game game = new();
    private readonly Sfx sfx = new();
    private readonly Renderer renderer = new();
    private readonly System.Windows.Forms.Timer timer = new();
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private double lastTime, acc;
    private float scale = 1f, offX, offY;
    private bool fullscreen;

    public GameForm()
    {
        Text = "Asteroids Reborn";
        DoubleBuffered = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.Black;
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(640, 420);

        // default size = 1:1 logical size, shrunk if the screen is too small
        var wa = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        float s = Math.Min(1f, Math.Min((wa.Width - 40) / Renderer.LW, (wa.Height - 100 - FooterH) / Renderer.LH));
        ClientSize = new Size((int)(Renderer.LW * s), (int)(Renderer.LH * s) + FooterH);

        game.Sound = name => sfx.Play(name);
        RecalcLayout();

        timer.Interval = 10;
        timer.Tick += (_, _) => Tick();
        timer.Start();
        lastTime = clock.Elapsed.TotalSeconds;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Stop();
            timer.Dispose();
            renderer.Dispose();
            sfx.Dispose();
        }
        base.Dispose(disposing);
    }

    // ---------- layout ----------
    private void RecalcLayout()
    {
        float availW = Math.Max(1, ClientSize.Width);
        float availH = Math.Max(1, ClientSize.Height - FooterH);
        scale = Math.Min(availW / Renderer.LW, availH / Renderer.LH);
        offX = (availW - Renderer.LW * scale) / 2f;
        offY = (availH - Renderer.LH * scale) / 2f;
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        RecalcLayout();
        Invalidate();
    }

    protected override void OnPaintBackground(PaintEventArgs e) { }

    private void ToggleFullscreen()
    {
        fullscreen = !fullscreen;
        if (fullscreen)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
        }
        else
        {
            WindowState = FormWindowState.Normal;
            FormBorderStyle = FormBorderStyle.Sizable;
        }
    }

    // ---------- game loop ----------
    private void Tick()
    {
        double now = clock.Elapsed.TotalSeconds;
        double dt = now - lastTime;
        lastTime = now;
        if (dt > 0.1) dt = 0.1;                 // never try to "catch up" after a long stall
        acc += dt;
        while (acc >= StepDt)
        {
            game.Update(StepDt);
            if (game.State != GameState.Paused) renderer.Tick(StepDt);
            acc -= StepDt;
        }
        Invalidate();
    }

    // ---------- input ----------
    protected override void OnKeyDown(KeyEventArgs e)
    {
        switch (e.KeyCode)
        {
            case Keys.Left: game.Left = true; break;
            case Keys.Right: game.Right = true; break;
            case Keys.Up: game.ThrustHeld = true; break;
            case Keys.Space: game.Fire = true; break;
            case Keys.Enter:
                if (game.State == GameState.Menu || game.State == GameState.GameOver) game.StartNewGame();
                break;
            case Keys.P: game.TogglePause(); break;
            case Keys.M: sfx.Muted = !sfx.Muted; break;
            case Keys.F11: ToggleFullscreen(); break;
            case Keys.Escape:
                switch (game.State)
                {
                    case GameState.Menu: Close(); break;
                    case GameState.Playing:
                    case GameState.Paused: game.TogglePause(); break;
                    case GameState.GameOver: game.GoMenu(); break;
                }
                break;
        }
        e.SuppressKeyPress = true;
        e.Handled = true;
        base.OnKeyDown(e);
    }

    protected override void OnKeyUp(KeyEventArgs e)
    {
        switch (e.KeyCode)
        {
            case Keys.Left: game.Left = false; break;
            case Keys.Right: game.Right = false; break;
            case Keys.Up: game.ThrustHeld = false; break;
            case Keys.Space: game.Fire = false; break;
        }
        base.OnKeyUp(e);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left || game.State != GameState.Menu) return;
        var p = new PointF((e.X - offX) / scale, (e.Y - offY) / scale);
        if (Renderer.BtnPlay.Contains(p)) game.StartNewGame();
        else if (Renderer.BtnQuit.Contains(p)) Close();
    }

    protected override void OnDeactivate(EventArgs e)
    {
        base.OnDeactivate(e);
        game.ClearInput();                                          // no stuck keys after Alt+Tab
        if (game.State == GameState.Playing) game.TogglePause();    // and never play on in the background
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        timer.Stop();
        game.SaveHi();
        base.OnFormClosing(e);
    }

    // ---------- painting ----------
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Color.Black);

        g.SetClip(new RectangleF(offX, offY, Renderer.LW * scale, Renderer.LH * scale));
        g.TranslateTransform(offX, offY);
        g.ScaleTransform(scale, scale);
        renderer.Render(g, game, sfx.Muted);
        g.ResetTransform();
        g.ResetClip();

        DrawFooter(g);
    }

    private void DrawFooter(Graphics g)
    {
        int cw = ClientSize.Width;
        int top = ClientSize.Height - FooterH;
        using (var b = new SolidBrush(Color.FromArgb(4, 8, 24))) g.FillRectangle(b, 0, top, cw, FooterH);
        using (var pen = new Pen(Color.FromArgb(70, 190, 255), 2)) g.DrawLine(pen, 0, top, cw, top);

        const string a = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: ";
        const string c = "orlovandrei.space";

        g.SmoothingMode = SmoothingMode.None;
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        var fmt = StringFormat.GenericTypographic;
        float size = 15f;
        Font f = new("Consolas", size, FontStyle.Regular, GraphicsUnit.Pixel);
        float wa = g.MeasureString(a, f, 3000, fmt).Width;
        float wc = g.MeasureString(c, f, 3000, fmt).Width;
        while (wa + wc > cw - 12 && size > 7f)          // shrink until the whole line fits the window width
        {
            f.Dispose();
            size -= 0.5f;
            f = new Font("Consolas", size, FontStyle.Regular, GraphicsUnit.Pixel);
            wa = g.MeasureString(a, f, 3000, fmt).Width;
            wc = g.MeasureString(c, f, 3000, fmt).Width;
        }
        float x = (cw - (wa + wc)) / 2f;
        float y = top + (FooterH - f.Height) / 2f;
        using (var b1 = new SolidBrush(Color.FromArgb(235, 238, 245))) g.DrawString(a, f, b1, x, y, fmt);
        using (var b2 = new SolidBrush(Color.FromArgb(110, 235, 255))) g.DrawString(c, f, b2, x + wa, y, fmt);
        f.Dispose();
    }
}
