using System.Drawing;

namespace Asteroids;

internal enum GameState { Menu, Playing, Paused, GameOver }

internal sealed class Rock
{
    public float X, Y, VX, VY, Angle, Spin, Radius;
    public int Size;                 // 0 = large, 1 = medium, 2 = small
    public int Shade;                // colour variant 0..3
    public bool Dead;
    public PointF[] Shape = Array.Empty<PointF>();      // jagged outline (local coordinates)
    public float[] Craters = Array.Empty<float>();      // x, y, radius triples
}

internal sealed class Bullet
{
    public float X, Y, VX, VY, Life;
    public bool Dead;
}

internal sealed class Particle
{
    public float X, Y, VX, VY, Life, MaxLife, Size, Ang, Spin, Len;
    public int Kind;                 // 0 = dot, 1 = debris line
    public Color Color;
}

/// <summary>
/// Pure game logic (no drawing). The playfield is a torus: W x H logical pixels, everything wraps around.
/// Ship angle 0 = pointing up; direction vector = (sin a, -cos a).
/// </summary>
internal sealed class Game
{
    public const float W = 1280f, H = 664f;
    public const float ShipRadius = 11f;

    public static readonly float[] RockRadius = { 52f, 30f, 16f };
    private static readonly int[] RockScore = { 20, 50, 100 };
    private static readonly float[] SpeedMin = { 40f, 65f, 95f };
    private static readonly float[] SpeedMax = { 80f, 110f, 160f };

    // ---------- tuning ----------
    private const float TurnSpeed = 4.2f;        // rad/s
    private const float ThrustAccel = 380f;      // px/s^2
    private const float MaxSpeed = 520f;
    private const float DragPerSecond = 0.55f;   // gentle slow-down when coasting
    private const float BulletSpeed = 780f, BulletLife = 1.1f, FireInterval = 0.2f;
    private const int MaxBullets = 8, MaxParticles = 500, ExtraLifeEvery = 10000;
    private const float RespawnDelay = 1.8f, InvulnTime = 3.0f;

    // ---------- state read by the renderer ----------
    public GameState State = GameState.Menu;
    public int Score, HiScore, Lives = 3, Level = 1;
    public bool NewRecord;
    public float Time, BannerTimer;
    public float ShipX = W / 2f, ShipY = H / 2f, ShipVX, ShipVY, ShipAngle, Invuln;
    public bool ShipAlive = true, Thrusting;
    public readonly List<Rock> Rocks = new();
    public readonly List<Bullet> Bullets = new();
    public readonly List<Particle> Particles = new();
    public Action<string>? Sound;

    // ---------- input (set by the window) ----------
    public bool Left, Right, ThrustHeld, Fire;

    private readonly Random rng = new();
    private readonly List<Rock> spawned = new();
    private float fireCooldown, respawnTimer, respawnWait, clearTimer, exhaustTimer;
    private int nextLife = ExtraLifeEvery, startHi;

    public Game()
    {
        HiScore = HighScoreStore.Load();
        SpawnMenuRocks();
    }

    // =====================================================================
    //  Flow
    // =====================================================================
    public void StartNewGame()
    {
        Score = 0; Lives = 3; NewRecord = false; nextLife = ExtraLifeEvery; startHi = HiScore;
        Rocks.Clear(); Bullets.Clear(); Particles.Clear();
        PlaceShip();
        Invuln = 2f;
        Level = 0;
        StartLevel(1);
        State = GameState.Playing;
    }

    public void GoMenu()
    {
        SaveHi();
        Rocks.Clear(); Bullets.Clear(); Particles.Clear();
        SpawnMenuRocks();
        State = GameState.Menu;
    }

    public void TogglePause()
    {
        if (State == GameState.Playing) State = GameState.Paused;
        else if (State == GameState.Paused) State = GameState.Playing;
    }

    public void ClearInput()
    {
        Left = Right = ThrustHeld = Fire = false;
    }

    public void SaveHi()
    {
        if (Score > HiScore) HiScore = Score;
        HighScoreStore.Save(HiScore);
    }

    private void EndGame()
    {
        State = GameState.GameOver;
        NewRecord = Score > 0 && Score > startHi;
        SaveHi();
    }

    private void PlaceShip()
    {
        ShipX = W / 2f; ShipY = H / 2f; ShipVX = 0; ShipVY = 0; ShipAngle = 0;
        ShipAlive = true; Thrusting = false; respawnWait = 0;
    }

    private void StartLevel(int level)
    {
        Level = level;
        BannerTimer = 2.2f;
        clearTimer = 0;
        int count = Math.Min(3 + level, 10);
        float mul = SpeedMul();
        for (int i = 0; i < count; i++)
        {
            float x, y;
            int guard = 0;
            do
            {
                x = (float)rng.NextDouble() * W;
                y = (float)rng.NextDouble() * H;
            } while (guard++ < 40 && Near(x, y, W / 2f, H / 2f, 240f));   // never spawn on top of the ship
            Rocks.Add(NewRock(0, x, y, RandomHeading(), RandomSpeed(0) * mul));
        }
    }

    private float SpeedMul() { return Math.Min(1.8f, 1f + 0.06f * (Level - 1)); }

    // =====================================================================
    //  Rocks
    // =====================================================================
    private float RandomHeading() { return (float)(rng.NextDouble() * Math.PI * 2); }

    private float RandomSpeed(int size)
    {
        return SpeedMin[size] + (float)rng.NextDouble() * (SpeedMax[size] - SpeedMin[size]);
    }

    private Rock NewRock(int size, float x, float y, float heading, float speed)
    {
        float r = RockRadius[size];
        int n = 10 + rng.Next(5);
        var shape = new PointF[n];
        for (int i = 0; i < n; i++)
        {
            double a = Math.PI * 2 * i / n;
            float rr = r * (0.74f + (float)rng.NextDouble() * 0.38f);
            shape[i] = new PointF((float)Math.Cos(a) * rr, (float)Math.Sin(a) * rr);
        }
        int craterCount = size == 2 ? 1 : 2 + rng.Next(2);
        var craters = new float[craterCount * 3];
        for (int i = 0; i < craterCount; i++)
        {
            double a = rng.NextDouble() * Math.PI * 2;
            float d = r * 0.5f * (float)rng.NextDouble();
            craters[i * 3] = (float)Math.Cos(a) * d;
            craters[i * 3 + 1] = (float)Math.Sin(a) * d;
            craters[i * 3 + 2] = r * (0.12f + 0.12f * (float)rng.NextDouble());
        }
        return new Rock
        {
            X = x, Y = y, Size = size, Radius = r,
            VX = (float)Math.Cos(heading) * speed, VY = (float)Math.Sin(heading) * speed,
            Angle = RandomHeading(), Spin = ((float)rng.NextDouble() - 0.5f) * 1.6f,
            Shade = rng.Next(4), Shape = shape, Craters = craters
        };
    }

    private void SpawnMenuRocks()
    {
        for (int i = 0; i < 9; i++)
        {
            int size = i < 3 ? 0 : (i < 6 ? 1 : 2);
            Rocks.Add(NewRock(size, (float)rng.NextDouble() * W, (float)rng.NextDouble() * H,
                RandomHeading(), RandomSpeed(size) * 0.7f));
        }
    }

    private void MoveRocks(float dt)
    {
        foreach (var r in Rocks)
        {
            r.X = Wrap(r.X + r.VX * dt, W);
            r.Y = Wrap(r.Y + r.VY * dt, H);
            r.Angle += r.Spin * dt;
        }
    }

    // =====================================================================
    //  Helpers
    // =====================================================================
    private static float Wrap(float v, float size)
    {
        v %= size;
        return v < 0 ? v + size : v;
    }

    private static float WrapDelta(float d, float size)
    {
        d = Math.Abs(d);
        return d > size / 2f ? size - d : d;
    }

    /// <summary>Distance test on the torus, so collisions work across the screen edges.</summary>
    public static bool Near(float x1, float y1, float x2, float y2, float r)
    {
        float dx = WrapDelta(x1 - x2, W), dy = WrapDelta(y1 - y2, H);
        return dx * dx + dy * dy < r * r;
    }

    private void AddScore(int n)
    {
        Score += n;
        if (Score > HiScore) HiScore = Score;
        while (Score >= nextLife)
        {
            Lives++;
            nextLife += ExtraLifeEvery;
            Sound?.Invoke("extralife");
        }
    }

    // =====================================================================
    //  Update
    // =====================================================================
    public void Update(float dt)
    {
        switch (State)
        {
            case GameState.Menu:
                Time += dt;
                MoveRocks(dt);
                break;
            case GameState.Playing:
                UpdatePlaying(dt);
                break;
            case GameState.GameOver:
                Time += dt;
                MoveRocks(dt);
                UpdateParticles(dt);
                break;
        }
    }

    private void UpdatePlaying(float dt)
    {
        Time += dt;
        if (BannerTimer > 0f) BannerTimer -= dt;

        UpdateShip(dt);
        MoveRocks(dt);
        MoveBullets(dt);
        UpdateParticles(dt);
        CollideBullets();
        CollideShip();

        if (Rocks.Count == 0)
        {
            clearTimer += dt;
            if (clearTimer >= 1.6f)
            {
                StartLevel(Level + 1);
                Sound?.Invoke("level");
            }
        }
    }

    private void UpdateShip(float dt)
    {
        if (!ShipAlive)
        {
            Thrusting = false;
            respawnTimer -= dt;
            if (respawnTimer > 0f) return;
            if (Lives <= 0) { EndGame(); return; }

            // wait (up to 3 extra seconds) until the centre of the field is free of rocks
            respawnWait += dt;
            bool blocked = false;
            foreach (var r in Rocks)
                if (Near(r.X, r.Y, W / 2f, H / 2f, r.Radius + 90f)) { blocked = true; break; }
            if (!blocked || respawnWait > 3f)
            {
                PlaceShip();
                Invuln = InvulnTime;
            }
            return;
        }

        if (Left) ShipAngle -= TurnSpeed * dt;
        if (Right) ShipAngle += TurnSpeed * dt;

        float dx = (float)Math.Sin(ShipAngle), dy = -(float)Math.Cos(ShipAngle);
        Thrusting = ThrustHeld;
        if (Thrusting)
        {
            ShipVX += dx * ThrustAccel * dt;
            ShipVY += dy * ThrustAccel * dt;
            EmitExhaust(dt, dx, dy);
        }

        float drag = (float)Math.Exp(-DragPerSecond * dt);
        ShipVX *= drag; ShipVY *= drag;
        float speed = (float)Math.Sqrt(ShipVX * ShipVX + ShipVY * ShipVY);
        if (speed > MaxSpeed) { ShipVX *= MaxSpeed / speed; ShipVY *= MaxSpeed / speed; }

        ShipX = Wrap(ShipX + ShipVX * dt, W);
        ShipY = Wrap(ShipY + ShipVY * dt, H);
        if (Invuln > 0f) Invuln -= dt;

        fireCooldown -= dt;
        if (Fire && fireCooldown <= 0f && Bullets.Count < MaxBullets)
        {
            Bullets.Add(new Bullet
            {
                X = Wrap(ShipX + dx * 16f, W), Y = Wrap(ShipY + dy * 16f, H),
                VX = dx * BulletSpeed + ShipVX * 0.4f, VY = dy * BulletSpeed + ShipVY * 0.4f,
                Life = BulletLife
            });
            fireCooldown = FireInterval;
            Sound?.Invoke("shoot");
        }
    }

    private void MoveBullets(float dt)
    {
        foreach (var b in Bullets)
        {
            b.X = Wrap(b.X + b.VX * dt, W);
            b.Y = Wrap(b.Y + b.VY * dt, H);
            b.Life -= dt;
            if (b.Life <= 0f) b.Dead = true;
        }
        Bullets.RemoveAll(b => b.Dead);
    }

    // ---------- collisions ----------
    private void CollideBullets()
    {
        foreach (var b in Bullets)
        {
            if (b.Dead) continue;
            foreach (var r in Rocks)
            {
                if (r.Dead) continue;
                if (!Near(b.X, b.Y, r.X, r.Y, r.Radius * 0.9f + 2f)) continue;
                b.Dead = true;                       // a bullet hits only one rock
                Explode(b.X, b.Y, 6, Color.FromArgb(255, 240, 180), 110f);
                DestroyRock(r);
                break;
            }
        }
        Bullets.RemoveAll(b => b.Dead);
        Rocks.RemoveAll(r => r.Dead);
        Rocks.AddRange(spawned);
        spawned.Clear();
    }

    private void DestroyRock(Rock r)
    {
        r.Dead = true;                                // flagged first: can never be scored twice
        AddScore(RockScore[r.Size]);
        Explode(r.X, r.Y, r.Size == 0 ? 26 : (r.Size == 1 ? 16 : 9), Color.FromArgb(190, 195, 210), 140f + 30f * (2 - r.Size));
        Sound?.Invoke(r.Size == 0 ? "boomBig" : (r.Size == 1 ? "boomMid" : "boomSmall"));

        if (r.Size >= 2) return;
        int child = r.Size + 1;
        float heading = (float)Math.Atan2(r.VY, r.VX);
        float parentSpeed = (float)Math.Sqrt(r.VX * r.VX + r.VY * r.VY);
        float mul = SpeedMul();
        for (int i = 0; i < 2; i++)
        {
            float turn = (0.35f + (float)rng.NextDouble() * 0.8f) * (i == 0 ? 1f : -1f);
            float speed = RandomSpeed(child) * mul * 0.8f + parentSpeed * 0.3f;
            spawned.Add(NewRock(child, r.X, r.Y, heading + turn, speed));
        }
    }

    private void CollideShip()
    {
        if (!ShipAlive || Invuln > 0f) return;
        foreach (var r in Rocks)
        {
            if (Near(ShipX, ShipY, r.X, r.Y, r.Radius * 0.85f + ShipRadius)) { KillShip(); return; }
        }
    }

    private void KillShip()
    {
        ShipAlive = false;
        Thrusting = false;
        Lives--;
        respawnTimer = RespawnDelay;
        Explode(ShipX, ShipY, 36, Color.FromArgb(120, 230, 255), 230f);
        Explode(ShipX, ShipY, 18, Color.FromArgb(255, 170, 60), 170f);
        for (int i = 0; i < 7 && Particles.Count < MaxParticles; i++)
        {
            float ang = RandomHeading(), sp = 40f + (float)rng.NextDouble() * 110f;
            Particles.Add(new Particle
            {
                X = ShipX, Y = ShipY, VX = (float)Math.Cos(ang) * sp, VY = (float)Math.Sin(ang) * sp,
                Life = 1.4f, MaxLife = 1.4f, Kind = 1, Ang = RandomHeading(),
                Spin = ((float)rng.NextDouble() - 0.5f) * 10f, Len = 6f + (float)rng.NextDouble() * 9f,
                Color = Color.FromArgb(130, 235, 255), Size = 2f
            });
        }
        Sound?.Invoke("shipBoom");
    }

    // ---------- particles ----------
    private void Explode(float x, float y, int count, Color color, float maxSpeed)
    {
        for (int i = 0; i < count && Particles.Count < MaxParticles; i++)
        {
            float ang = RandomHeading();
            float sp = maxSpeed * (0.2f + 0.8f * (float)rng.NextDouble());
            float life = 0.4f + (float)rng.NextDouble() * 0.7f;
            Particles.Add(new Particle
            {
                X = x, Y = y, VX = (float)Math.Cos(ang) * sp, VY = (float)Math.Sin(ang) * sp,
                Life = life, MaxLife = life, Size = 1.5f + (float)rng.NextDouble() * 2.5f, Color = color
            });
        }
    }

    private void EmitExhaust(float dt, float dx, float dy)
    {
        exhaustTimer -= dt;
        while (exhaustTimer <= 0f)
        {
            exhaustTimer += 0.018f;
            if (Particles.Count >= MaxParticles) return;
            float jx = ((float)rng.NextDouble() - 0.5f) * 60f, jy = ((float)rng.NextDouble() - 0.5f) * 60f;
            float back = 140f + (float)rng.NextDouble() * 90f;
            float life = 0.22f + (float)rng.NextDouble() * 0.2f;
            Particles.Add(new Particle
            {
                X = ShipX - dx * 10f, Y = ShipY - dy * 10f,
                VX = ShipVX - dx * back + jx, VY = ShipVY - dy * back + jy,
                Life = life, MaxLife = life, Size = 2.4f,
                Color = rng.Next(2) == 0 ? Color.FromArgb(255, 170, 50) : Color.FromArgb(255, 230, 120)
            });
        }
    }

    private void UpdateParticles(float dt)
    {
        foreach (var p in Particles)
        {
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            p.VX *= 0.985f; p.VY *= 0.985f;
            p.Ang += p.Spin * dt;
            p.Life -= dt;
        }
        Particles.RemoveAll(p => p.Life <= 0f);
    }
}
