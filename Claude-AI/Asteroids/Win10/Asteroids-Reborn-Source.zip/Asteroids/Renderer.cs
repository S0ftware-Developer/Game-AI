using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace Asteroids;

/// <summary>
/// Draws one frame in logical coordinates (1280 x 720). The window applies the scaling, so all lines stay sharp.
/// Pens, brushes and fonts are created once and reused.
/// </summary>
internal sealed class Renderer : IDisposable
{
    public const float LW = 1280f, LH = 720f, HudH = 56f;

    // clickable areas on the title screen (logical coordinates)
    public static readonly RectangleF BtnPlay = new(460, 408, 360, 64);
    public static readonly RectangleF BtnQuit = new(540, 560, 200, 44);

    private sealed class Star
    {
        public float X, Y, Speed, Phase, Size;
        public Color Color;
        public bool Twinkle;
    }

    private readonly List<Star> stars = new();
    private readonly Random rng = new(11);
    private readonly Bitmap bg;
    private float anim;

    private readonly Brush[] rockBrush;
    private readonly Brush craterBrush = new SolidBrush(Color.FromArgb(80, 0, 0, 10));
    private readonly Brush shipFill = new SolidBrush(Color.FromArgb(18, 38, 78));
    private readonly Brush cockpit = new SolidBrush(Color.FromArgb(210, 90, 215, 255));
    private readonly Brush flameOuter = new SolidBrush(Color.FromArgb(255, 150, 40));
    private readonly Brush flameInner = new SolidBrush(Color.FromArgb(255, 235, 140));
    private readonly SolidBrush tmp = new(Color.White);
    private readonly Pen rockGlow = new(Color.FromArgb(55, 150, 190, 255), 5f) { LineJoin = LineJoin.Round };
    private readonly Pen rockEdge = new(Color.FromArgb(205, 190, 205, 235), 1.6f) { LineJoin = LineJoin.Round };
    private readonly Pen shipGlow = new(Color.FromArgb(60, 110, 230, 255), 6f) { LineJoin = LineJoin.Round };
    private readonly Pen shipEdge = new(Color.FromArgb(125, 238, 255), 2f) { LineJoin = LineJoin.Round };
    private readonly Pen shipDetail = new(Color.FromArgb(150, 150, 220, 255), 1.2f);
    private readonly Pen bulletGlow = new(Color.FromArgb(90, 120, 220, 255), 8f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen bulletCore = new(Color.FromArgb(255, 255, 255), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen debrisPen = new(Color.White, 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen neonPen = new(Color.FromArgb(70, 190, 255), 2.2f) { LineJoin = LineJoin.Round };
    private readonly Pen neonGlow = new(Color.FromArgb(60, 70, 190, 255), 7f) { LineJoin = LineJoin.Round };

    private readonly Font fLabel, fValue, fTitle, fSub, fMid, fBig, fSmall;
    private readonly StringFormat center = new() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Near, FormatFlags = StringFormatFlags.NoWrap };
    private readonly StringFormat near = new() { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Near, FormatFlags = StringFormatFlags.NoWrap };
    private readonly StringFormat far = new() { Alignment = StringAlignment.Far, LineAlignment = StringAlignment.Near, FormatFlags = StringFormatFlags.NoWrap };

    private static readonly PointF[] ShipShape =
    {
        new(0, -17), new(11, 13), new(0, 7), new(-11, 13)
    };

    public Renderer()
    {
        rockBrush = new Brush[]
        {
            new SolidBrush(Color.FromArgb(92, 96, 108)), new SolidBrush(Color.FromArgb(106, 101, 99)),
            new SolidBrush(Color.FromArgb(82, 92, 106)), new SolidBrush(Color.FromArgb(112, 110, 116))
        };

        string family = PickFamily("Bahnschrift", "Segoe UI", "Arial");
        fLabel = MakeFont(family, 14, FontStyle.Bold);
        fValue = MakeFont(family, 26, FontStyle.Bold);
        fTitle = MakeFont(family, 128, FontStyle.Bold | FontStyle.Italic);
        fSub = MakeFont(family, 36, FontStyle.Bold);
        fMid = MakeFont(family, 28, FontStyle.Bold);
        fBig = MakeFont(family, 68, FontStyle.Bold);
        fSmall = MakeFont(family, 18, FontStyle.Regular);

        Color[] tints = { Color.White, Color.FromArgb(170, 205, 255), Color.FromArgb(255, 225, 170), Color.FromArgb(255, 170, 220) };
        for (int layer = 0; layer < 3; layer++)
        {
            int count = layer == 0 ? 110 : (layer == 1 ? 70 : 36);
            for (int i = 0; i < count; i++)
            {
                stars.Add(new Star
                {
                    X = rng.Next((int)LW), Y = rng.Next((int)LH),
                    Speed = 3f + layer * 7f, Phase = (float)(rng.NextDouble() * 6.28),
                    Size = 1f + layer * 0.7f + (float)rng.NextDouble() * 0.5f,
                    Color = layer == 0 ? Color.FromArgb(140, 150, 180) : tints[rng.Next(tints.Length)],
                    Twinkle = rng.Next(3) != 0
                });
            }
        }
        bg = BuildBackground();
    }

    private static string PickFamily(params string[] names)
    {
        foreach (string n in names)
            foreach (var f in FontFamily.Families)
                if (string.Equals(f.Name, n, StringComparison.OrdinalIgnoreCase)) return n;
        return "Arial";
    }

    private static Font MakeFont(string family, float px, FontStyle style)
    {
        try { return new Font(family, px, style, GraphicsUnit.Pixel); }
        catch { return new Font("Arial", px, style, GraphicsUnit.Pixel); }
    }

    public void Tick(float dt)
    {
        anim += dt;
        foreach (var s in stars)
        {
            s.X -= s.Speed * dt;
            if (s.X < 0) { s.X += LW; s.Y = rng.Next((int)LH); }
        }
    }

    public void Dispose()
    {
        bg.Dispose();
        foreach (var b in rockBrush) b.Dispose();
        craterBrush.Dispose(); shipFill.Dispose(); cockpit.Dispose(); flameOuter.Dispose(); flameInner.Dispose(); tmp.Dispose();
        rockGlow.Dispose(); rockEdge.Dispose(); shipGlow.Dispose(); shipEdge.Dispose(); shipDetail.Dispose();
        bulletGlow.Dispose(); bulletCore.Dispose(); debrisPen.Dispose(); neonPen.Dispose(); neonGlow.Dispose();
        fLabel.Dispose(); fValue.Dispose(); fTitle.Dispose(); fSub.Dispose(); fMid.Dispose(); fBig.Dispose(); fSmall.Dispose();
        center.Dispose(); near.Dispose(); far.Dispose();
    }

    // =====================================================================
    //  Static background: deep space gradient, nebulae, distant planet
    // =====================================================================
    private static Bitmap BuildBackground()
    {
        var bmp = new Bitmap((int)LW, (int)LH, PixelFormat.Format32bppPArgb);
        using var g = Graphics.FromImage(bmp);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var full = new Rectangle(0, 0, (int)LW, (int)LH);
        using (var br = new LinearGradientBrush(full, Color.FromArgb(2, 4, 16), Color.FromArgb(7, 14, 46), 90f))
            g.FillRectangle(br, full);

        Blob(g, 220, 520, 420, Color.FromArgb(150, 60, 220), 70);
        Blob(g, 1020, 170, 460, Color.FromArgb(90, 60, 230), 60);
        Blob(g, 640, 640, 360, Color.FromArgb(40, 90, 230), 45);
        Blob(g, 420, 130, 260, Color.FromArgb(120, 40, 200), 30);

        // distant planet in the lower right corner
        float cx = 1230f, cy = 850f, r = 380f;
        using (var path = new GraphicsPath())
        {
            path.AddEllipse(cx - r, cy - r, r * 2, r * 2);
            using var pb = new PathGradientBrush(path)
            {
                CenterPoint = new PointF(cx - r * 0.55f, cy - r * 0.7f),
                CenterColor = Color.FromArgb(70, 125, 205),
                SurroundColors = new[] { Color.FromArgb(5, 10, 34) }
            };
            g.FillPath(pb, path);
            using var halo = new Pen(Color.FromArgb(40, 110, 190, 255), 16f);
            using var rim = new Pen(Color.FromArgb(150, 130, 210, 255), 3f);
            g.DrawEllipse(halo, cx - r, cy - r, r * 2, r * 2);
            g.DrawEllipse(rim, cx - r, cy - r, r * 2, r * 2);
        }
        var rr = new Random(5);
        using (var cb = new SolidBrush(Color.FromArgb(28, 0, 0, 30)))
            for (int i = 0; i < 14; i++)
            {
                float a = (float)(rr.NextDouble() * Math.PI), d = (float)(rr.NextDouble() * r * 0.85f);
                float x = cx - (float)Math.Cos(a) * d * 0.9f, y = cy - (float)Math.Sin(a) * d;
                float s = 14 + rr.Next(46);
                if (y < 600 || x < 880) continue;
                g.FillEllipse(cb, x - s, y - s * 0.6f, s * 2, s * 1.2f);
            }
        return bmp;
    }

    private static void Blob(Graphics g, float cx, float cy, float r, Color c, int alpha)
    {
        using var path = new GraphicsPath();
        path.AddEllipse(cx - r, cy - r * 0.65f, r * 2, r * 1.3f);
        using var pb = new PathGradientBrush(path)
        {
            CenterColor = Color.FromArgb(alpha, c),
            SurroundColors = new[] { Color.FromArgb(0, c) }
        };
        g.FillPath(pb, path);
    }

    // =====================================================================
    //  Frame
    // =====================================================================
    public void Render(Graphics g, Game game, bool muted)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.AntiAlias;
        g.InterpolationMode = InterpolationMode.HighQualityBilinear;

        g.DrawImage(bg, 0, 0, LW, LH);
        DrawStars(g);

        GraphicsState st = g.Save();
        g.TranslateTransform(0, HudH);
        foreach (var r in game.Rocks) DrawRock(g, r);
        if (game.State != GameState.Menu)
        {
            foreach (var b in game.Bullets) DrawBullet(g, b);
            if (game.ShipAlive && game.State != GameState.GameOver) DrawShip(g, game);
            foreach (var p in game.Particles) DrawParticle(g, p);
        }
        g.Restore(st);

        if (game.State == GameState.Menu)
        {
            DrawMenu(g, game, muted);
            return;
        }

        DrawHud(g, game, muted);

        if (game.State == GameState.Playing && game.BannerTimer > 0f)
        {
            float a = Math.Min(1f, game.BannerTimer / 0.6f);
            DrawGlowText(g, "LEVEL " + game.Level, fBig, LW / 2f, 250, Color.White, (int)(255 * a));
        }
        if (game.State == GameState.Paused) DrawPaused(g, muted);
        if (game.State == GameState.GameOver) DrawGameOver(g, game);
    }

    private void DrawStars(Graphics g)
    {
        foreach (var s in stars)
        {
            int a = s.Twinkle ? 110 + (int)(110 * Math.Sin(anim * 2.2f + s.Phase)) : 190;
            a = Math.Max(30, Math.Min(255, a));
            tmp.Color = Color.FromArgb(a, s.Color);
            g.FillEllipse(tmp, s.X, s.Y, s.Size, s.Size);
        }
    }

    // ---------- world objects (drawn on the torus: copies appear at the opposite edge) ----------
    private static IEnumerable<(float ox, float oy)> WrapCopies(float x, float y, float r)
    {
        for (int ix = -1; ix <= 1; ix++)
            for (int iy = -1; iy <= 1; iy++)
            {
                float ox = x + ix * Game.W, oy = y + iy * Game.H;
                if (ox + r < 0 || ox - r > Game.W || oy + r < 0 || oy - r > Game.H) continue;
                yield return (ox, oy);
            }
    }

    private void DrawRock(Graphics g, Rock r)
    {
        foreach (var (ox, oy) in WrapCopies(r.X, r.Y, r.Radius * 1.2f))
        {
            GraphicsState s = g.Save();
            g.TranslateTransform(ox, oy);
            g.RotateTransform(r.Angle * 180f / (float)Math.PI);
            g.FillPolygon(rockBrush[r.Shade], r.Shape);
            for (int i = 0; i < r.Craters.Length; i += 3)
            {
                float cr = r.Craters[i + 2];
                g.FillEllipse(craterBrush, r.Craters[i] - cr, r.Craters[i + 1] - cr, cr * 2, cr * 2);
            }
            g.DrawPolygon(rockGlow, r.Shape);
            g.DrawPolygon(rockEdge, r.Shape);
            g.Restore(s);
        }
    }

    private void DrawBullet(Graphics g, Bullet b)
    {
        foreach (var (ox, oy) in WrapCopies(b.X, b.Y, 12f))
        {
            g.DrawLine(bulletGlow, ox - b.VX * 0.012f, oy - b.VY * 0.012f, ox, oy);
            g.DrawLine(bulletCore, ox - b.VX * 0.012f, oy - b.VY * 0.012f, ox, oy);
        }
    }

    private void DrawShip(Graphics g, Game game)
    {
        bool blink = game.Invuln > 0f;
        if (blink && (((int)(game.Time * 12f)) & 1) == 1) return;
        foreach (var (ox, oy) in WrapCopies(game.ShipX, game.ShipY, 30f))
        {
            DrawShipShape(g, ox, oy, game.ShipAngle * 180f / (float)Math.PI, 1f, game.Thrusting, game.Time);
            if (blink)
            {
                tmp.Color = Color.FromArgb(28, 120, 220, 255);
                g.FillEllipse(tmp, ox - 22, oy - 22, 44, 44);
            }
        }
    }

    private void DrawShipShape(Graphics g, float x, float y, float angleDeg, float scale, bool thrusting, float t)
    {
        GraphicsState s = g.Save();
        g.TranslateTransform(x, y);
        g.RotateTransform(angleDeg);
        g.ScaleTransform(scale, scale);

        if (thrusting)
        {
            float len = 12f + 8f * (0.5f + 0.5f * (float)Math.Sin(t * 60f)) + (float)rng.NextDouble() * 3f;
            g.FillPolygon(flameOuter, new PointF[] { new(-5, 9), new(5, 9), new(0, 9 + len) });
            g.FillPolygon(flameInner, new PointF[] { new(-2.5f, 9), new(2.5f, 9), new(0, 9 + len * 0.55f) });
        }
        g.FillPolygon(shipFill, ShipShape);
        g.DrawPolygon(shipGlow, ShipShape);
        g.DrawPolygon(shipEdge, ShipShape);
        g.DrawLine(shipDetail, 0, -17, 0, 7);
        g.DrawLine(shipDetail, -6, 8, -9.5f, 12f);
        g.DrawLine(shipDetail, 6, 8, 9.5f, 12f);
        g.FillPolygon(cockpit, new PointF[] { new(0, -8), new(3.5f, 2), new(-3.5f, 2) });
        g.Restore(s);
    }

    private void DrawParticle(Graphics g, Particle p)
    {
        float k = Math.Max(0f, p.Life / p.MaxLife);
        int a = (int)(255 * k);
        if (p.Kind == 1)
        {
            debrisPen.Color = Color.FromArgb(a, p.Color);
            float dx = (float)Math.Cos(p.Ang) * p.Len * 0.5f, dy = (float)Math.Sin(p.Ang) * p.Len * 0.5f;
            g.DrawLine(debrisPen, p.X - dx, p.Y - dy, p.X + dx, p.Y + dy);
        }
        else
        {
            tmp.Color = Color.FromArgb(a, p.Color);
            float s = p.Size * (0.4f + 0.6f * k);
            g.FillEllipse(tmp, p.X - s / 2f, p.Y - s / 2f, s, s);
        }
    }

    // =====================================================================
    //  Text helpers
    // =====================================================================
    private void Text(Graphics g, string s, Font f, float x, float y, Color c, StringFormat fmt)
    {
        tmp.Color = c;
        g.DrawString(s, f, tmp, x, y, fmt);
    }

    private void DrawGlowText(Graphics g, string s, Font f, float cx, float y, Color c, int alpha)
    {
        for (int i = 2; i >= 1; i--)
            for (int dx = -i; dx <= i; dx += i)
                for (int dy = -i; dy <= i; dy += i)
                    if (dx != 0 || dy != 0)
                        Text(g, s, f, cx + dx * 1.5f, y + dy * 1.5f, Color.FromArgb(Math.Min(alpha, 26), 60, 150, 255), center);
        Text(g, s, f, cx, y, Color.FromArgb(alpha, c), center);
    }

    private static PointF[] Chamfer(RectangleF r, float c)
    {
        return new PointF[]
        {
            new(r.Left + c, r.Top), new(r.Right - c, r.Top), new(r.Right, r.Top + c), new(r.Right, r.Bottom - c),
            new(r.Right - c, r.Bottom), new(r.Left + c, r.Bottom), new(r.Left, r.Bottom - c), new(r.Left, r.Top + c)
        };
    }

    private void Panel(Graphics g, RectangleF r, int alpha)
    {
        var poly = Chamfer(r, 12);
        tmp.Color = Color.FromArgb(alpha, 6, 14, 40);
        g.FillPolygon(tmp, poly);
        g.DrawPolygon(neonGlow, poly);
        g.DrawPolygon(neonPen, poly);
    }

    // =====================================================================
    //  HUD and screens
    // =====================================================================
    private void DrawHud(Graphics g, Game game, bool muted)
    {
        tmp.Color = Color.FromArgb(235, 3, 8, 26);
        g.FillRectangle(tmp, 0, 0, LW, HudH);
        g.DrawLine(neonGlow, 0, HudH, LW, HudH);
        g.DrawLine(neonPen, 0, HudH, LW, HudH);

        Color label = Color.FromArgb(120, 190, 255);
        Text(g, "SCORE", fLabel, 28, 8, label, near);
        Text(g, game.Score.ToString("D6"), fValue, 28, 22, Color.White, near);
        Text(g, "HIGH SCORE", fLabel, 330, 8, label, near);
        Text(g, game.HiScore.ToString("D6"), fValue, 330, 22, Color.FromArgb(255, 220, 120), near);
        Text(g, "LEVEL", fLabel, 660, 8, label, near);
        Text(g, game.Level.ToString("D2"), fValue, 660, 22, Color.FromArgb(120, 255, 170), near);
        Text(g, "LIVES", fLabel, 860, 8, label, near);
        int icons = Math.Max(0, Math.Min(game.Lives, 8));
        for (int i = 0; i < icons; i++) DrawShipShape(g, 872 + i * 34, 38, 0f, 0.8f, false, 0f);
        Text(g, muted ? "SOUND OFF" : "SOUND ON", fLabel, LW - 24, 8, muted ? Color.FromArgb(255, 140, 140) : label,
            far);
        Text(g, "[M]", fLabel, LW - 24, 28, Color.FromArgb(90, 140, 200), far);
    }

    private void DrawMenu(Graphics g, Game game, bool muted)
    {
        // decorative ship with a flame, like on the title art
        DrawShipShape(g, 250, 560, 58f, 3.4f, true, anim);

        DrawGlowText(g, "ASTEROIDS", fTitle, LW / 2f, 96, Color.White, 255);
        Text(g, "R  E  B  O  R  N", fSub, LW / 2f, 238, Color.FromArgb(110, 215, 255), center);

        var play = BtnPlay;
        Panel(g, play, 235);
        Text(g, "PLAY", fMid, LW / 2f, play.Y + 16, Color.White, center);
        Text(g, "press ENTER", fLabel, LW / 2f, play.Y + 46, Color.FromArgb(120, 190, 255), center);

        Text(g, "HIGH SCORE  " + game.HiScore.ToString("D6"), fMid, LW / 2f, 496, Color.FromArgb(255, 220, 120), center);
        Text(g, "QUIT  [ESC]", fMid, LW / 2f, BtnQuit.Y + 6, Color.FromArgb(170, 190, 225), center);

        Text(g, "LEFT / RIGHT : ROTATE      UP : THRUST      SPACE : FIRE", fSmall, LW / 2f, 624, Color.FromArgb(200, 215, 240), center);
        Text(g, "P / ESC : PAUSE      M : SOUND " + (muted ? "OFF" : "ON") + "      F11 : FULLSCREEN", fSmall, LW / 2f, 650,
            Color.FromArgb(150, 175, 215), center);
    }

    private void Dim(Graphics g, int alpha)
    {
        tmp.Color = Color.FromArgb(alpha, 0, 2, 14);
        g.FillRectangle(tmp, 0, HudH + 2, LW, LH - HudH - 2);
    }

    private void DrawPaused(Graphics g, bool muted)
    {
        Dim(g, 150);
        var r = new RectangleF(LW / 2f - 230, 270, 460, 210);
        Panel(g, r, 240);
        DrawGlowText(g, "PAUSED", fBig, LW / 2f, r.Y + 24, Color.White, 255);
        Text(g, "P / ESC : RESUME", fMid, LW / 2f, r.Y + 122, Color.FromArgb(170, 220, 255), center);
        Text(g, "M : SOUND " + (muted ? "OFF" : "ON"), fSmall, LW / 2f, r.Y + 164, Color.FromArgb(130, 160, 205), center);
    }

    private void DrawGameOver(Graphics g, Game game)
    {
        Dim(g, 160);
        var r = new RectangleF(LW / 2f - 280, 190, 560, 380);
        Panel(g, r, 242);
        DrawGlowText(g, "GAME OVER", fBig, LW / 2f, r.Y + 22, Color.FromArgb(255, 110, 90), 255);
        Text(g, "SCORE", fLabel, LW / 2f, r.Y + 130, Color.FromArgb(120, 190, 255), center);
        Text(g, game.Score.ToString("D6"), fBig, LW / 2f, r.Y + 148, Color.White, center);
        Text(g, "HIGH SCORE", fLabel, LW / 2f, r.Y + 232, Color.FromArgb(255, 210, 120), center);
        Text(g, game.HiScore.ToString("D6"), fMid, LW / 2f, r.Y + 252, Color.White, center);
        if (game.NewRecord && ((int)(anim * 3f) & 1) == 0)
            Text(g, "NEW HIGH SCORE!", fMid, LW / 2f, r.Y + 292, Color.FromArgb(120, 255, 170), center);
        Text(g, "Press ENTER to play again", fMid, LW / 2f, r.Y + 330, Color.FromArgb(180, 225, 255), center);
    }
}
