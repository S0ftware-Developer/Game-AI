using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace KolobokReborn
{
    /// <summary>Draws one frame into a 992x672 logical bitmap. Reads game state only.</summary>
    internal sealed class Renderer
    {
        public const int T = 32;                 // tile size
        public const int OY = 64;                // maze top (HUD above)
        public const int LW = Maze.W * T;        // 992
        public const int LH = OY + Maze.H * T;   // 672

        private static readonly Color Gold = Color.FromArgb(255, 204, 30);
        private static readonly Color Cream = Color.FromArgb(255, 240, 200);
        private static readonly Color Cyan = Color.FromArgb(90, 220, 255);
        private static readonly Color Green = Color.FromArgb(110, 235, 60);
        private static readonly Color RedOutline = Color.FromArgb(170, 30, 10);
        private static readonly Color Shade = Color.FromArgb(10, 18, 14);

        private readonly Bitmap bgNormal, bgFlash;
        private readonly Font f12 = MakeFont(12, FontStyle.Bold), f16 = MakeFont(16, FontStyle.Bold),
            f20 = MakeFont(20, FontStyle.Bold), f28 = MakeFont(28, FontStyle.Bold),
            f32 = MakeFont(32, FontStyle.Bold), f48 = MakeFont(48, FontStyle.Bold),
            f64 = MakeFont(64, FontStyle.Bold), f64i = MakeFont(64, FontStyle.Bold | FontStyle.Italic),
            f110 = MakeFont(110, FontStyle.Bold);
        private readonly StringFormat sf = new StringFormat(StringFormatFlags.NoWrap);

        private static Font MakeFont(float px, FontStyle st)
        {
            return new Font("Consolas", px, st, GraphicsUnit.Pixel);
        }

        public Renderer()
        {
            var m = new Maze();
            bgNormal = BuildBackground(m, false);
            bgFlash = BuildBackground(m, true);
        }

        // =====================================================================
        //  Helpers
        // =====================================================================
        private static void Fill(Graphics g, Color c, float x, float y, float w, float h)
        {
            using (var b = new SolidBrush(c)) g.FillRectangle(b, x, y, w, h);
        }

        private static void Oval(Graphics g, Color c, float x, float y, float w, float h)
        {
            using (var b = new SolidBrush(c)) g.FillEllipse(b, x, y, w, h);
        }

        private void DrawTxt(Graphics g, string s, Font f, float x, float y, Color fill, Color outline, int th,
            StringAlignment al)
        {
            sf.Alignment = al;
            if (th > 0)
            {
                using (var ob = new SolidBrush(outline))
                    for (int dx = -th; dx <= th; dx += th)
                        for (int dy = -th; dy <= th; dy += th)
                            if (dx != 0 || dy != 0) g.DrawString(s, f, ob, x + dx, y + dy, sf);
            }
            using (var fb = new SolidBrush(fill)) g.DrawString(s, f, fb, x, y, sf);
        }

        private void Ctr(Graphics g, string s, Font f, float x, float y, Color fill, Color outline, int th)
        {
            DrawTxt(g, s, f, x, y, fill, outline, th, StringAlignment.Center);
        }

        private static Point[] Chamfer(Rectangle r, int c)
        {
            return new[]
            {
                new Point(r.Left + c, r.Top), new Point(r.Right - c, r.Top),
                new Point(r.Right, r.Top + c), new Point(r.Right, r.Bottom - c),
                new Point(r.Right - c, r.Bottom), new Point(r.Left + c, r.Bottom),
                new Point(r.Left, r.Bottom - c), new Point(r.Left, r.Top + c)
            };
        }

        private static void Panel(Graphics g, Rectangle r, Color border, int alpha)
        {
            var poly = Chamfer(r, 8);
            using (var fill = new SolidBrush(Color.FromArgb(alpha, 12, 24, 16))) g.FillPolygon(fill, poly);
            using (var glow = new Pen(Color.FromArgb(70, border), 5)) g.DrawPolygon(glow, poly);
            using (var pen = new Pen(border, 2)) g.DrawPolygon(pen, poly);
        }

        // =====================================================================
        //  Baked maze background (walls, folk-art motifs, decorations, house)
        // =====================================================================
        private static RectangleF RectInset(Maze m, int x, int y, float ins)
        {
            float l = x * T + (m.IsWall(x - 1, y) ? 0 : ins);
            float t = OY + y * T + (m.IsWall(x, y - 1) ? 0 : ins);
            float r = (x + 1) * T - (m.IsWall(x + 1, y) ? 0 : ins);
            float b = OY + (y + 1) * T - (m.IsWall(x, y + 1) ? 0 : ins);
            return new RectangleF(l, t, r - l, b - t);
        }

        private static void WallLayer(Graphics g, Maze m, Color c, float ins)
        {
            using (var br = new SolidBrush(c))
                for (int y = 0; y < Maze.H; y++)
                    for (int x = 0; x < Maze.W; x++)
                        if (m.IsWall(x, y))
                        {
                            var r = RectInset(m, x, y, ins);
                            g.FillRectangle(br, r.X, r.Y, r.Width, r.Height);
                        }
        }

        private static void CornerPieces(Graphics g, Maze m, Color c, float a, float b)
        {
            int[] sxs = { -1, 1, -1, 1 };
            int[] sys = { -1, -1, 1, 1 };
            using (var br = new SolidBrush(c))
                for (int y = 0; y < Maze.H; y++)
                    for (int x = 0; x < Maze.W; x++)
                    {
                        if (!m.IsWall(x, y)) continue;
                        for (int k = 0; k < 4; k++)
                        {
                            int sx = sxs[k], sy = sys[k];
                            if (!m.IsWall(x + sx, y) || !m.IsWall(x, y + sy) || m.IsWall(x + sx, y + sy)) continue;
                            float px = (x + (sx > 0 ? 1 : 0)) * T;
                            float py = OY + (y + (sy > 0 ? 1 : 0)) * T;
                            float x0 = sx > 0 ? px - b : px, x1 = sx > 0 ? px : px + b;
                            float y0 = sy > 0 ? py - b : py + a, y1 = sy > 0 ? py - a : py + b;
                            g.FillRectangle(br, x0, y0, x1 - x0, y1 - y0);
                            x0 = sx > 0 ? px - b : px + a; x1 = sx > 0 ? px - a : px + b;
                            y0 = sy > 0 ? py - b : py; y1 = sy > 0 ? py : py + b;
                            g.FillRectangle(br, x0, y0, x1 - x0, y1 - y0);
                        }
                    }
        }

        private Bitmap BuildBackground(Maze m, bool flash)
        {
            var bmp = new Bitmap(LW, LH, PixelFormat.Format32bppPArgb);
            Color glow = flash ? Color.FromArgb(120, 90, 10) : Color.FromArgb(10, 36, 120);
            Color neon = flash ? Color.FromArgb(255, 214, 80) : Color.FromArgb(70, 160, 255);
            Color mid = flash ? Color.FromArgb(220, 150, 40) : Color.FromArgb(30, 100, 230);
            Color dark = flash ? Color.FromArgb(44, 28, 6) : Color.FromArgb(4, 10, 38);
            Color motif = flash ? Color.FromArgb(130, 84, 20) : Color.FromArgb(22, 56, 140);

            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.None;
                g.Clear(Color.FromArgb(2, 6, 4));

                // soft forest-green glow in the corridors
                Fill(g, Color.FromArgb(5, 16, 10), 0, OY, LW, Maze.H * T);

                using (var gb = new SolidBrush(glow))
                    for (int y = 0; y < Maze.H; y++)
                        for (int x = 0; x < Maze.W; x++)
                            if (m.IsWall(x, y)) g.FillRectangle(gb, x * T - 3, OY + y * T - 3, T + 6, T + 6);

                WallLayer(g, m, neon, 0);
                WallLayer(g, m, dark, 2);
                WallLayer(g, m, mid, 4);
                WallLayer(g, m, dark, 6);
                CornerPieces(g, m, neon, 0, 2);
                CornerPieces(g, m, mid, 4, 6);

                // folk-art stitch motifs inside the walls
                using (var mb = new SolidBrush(motif))
                    for (int y = 0; y < Maze.H; y++)
                        for (int x = 0; x < Maze.W; x++)
                        {
                            if (!m.IsWall(x, y)) continue;
                            float cx = x * T + T / 2f, cy = OY + y * T + T / 2f;
                            if (((x + y) & 1) == 0)
                                g.FillPolygon(mb, new[] { new PointF(cx, cy - 5), new PointF(cx + 5, cy), new PointF(cx, cy + 5), new PointF(cx - 5, cy) });
                            else
                            {
                                g.FillRectangle(mb, cx - 4, cy - 1, 8, 2);
                                g.FillRectangle(mb, cx - 1, cy - 4, 2, 8);
                            }
                        }

                g.SmoothingMode = SmoothingMode.AntiAlias;
                DrawIslandDecor(g, m);

                // enemy house: floor, hut, spruces, door
                Fill(g, Color.FromArgb(12, 28, 16), 13 * T, OY + 8 * T, 5 * T, 3 * T);
                Sprites.Spruce(g, 14.2f * T, OY + 9.5f * T + 4, 1.1f);
                Sprites.Spruce(g, 16.8f * T, OY + 9.5f * T + 4, 1.1f);
                Sprites.Izba(g, 15.5f * T, OY + 9.5f * T + 6, 1.0f);
                g.SmoothingMode = SmoothingMode.None;
                Fill(g, Color.FromArgb(255, 200, 90), 15 * T + 2, OY + 7 * T + 13, T - 4, 6);
                Fill(g, Color.FromArgb(170, 110, 30), 15 * T + 2, OY + 7 * T + 17, T - 4, 2);
            }
            return bmp;
        }

        /// <summary>Puts a mushroom / flower / spruce / grass tuft into every wall island at least 2 tiles tall.</summary>
        private static void DrawIslandDecor(Graphics g, Maze m)
        {
            var seen = new bool[Maze.H, Maze.W];
            int compIndex = 0;
            for (int sy = 0; sy < Maze.H; sy++)
                for (int sx = 0; sx < Maze.W; sx++)
                {
                    if (seen[sy, sx] || !m.IsWall(sx, sy)) continue;
                    int minx = sx, maxx = sx, miny = sy, maxy = sy;
                    bool border = false, house = false;
                    var q = new Queue<int>();
                    q.Enqueue(sy * Maze.W + sx);
                    seen[sy, sx] = true;
                    while (q.Count > 0)
                    {
                        int cur = q.Dequeue();
                        int cx = cur % Maze.W, cy = cur / Maze.W;
                        if (cx < minx) minx = cx; if (cx > maxx) maxx = cx;
                        if (cy < miny) miny = cy; if (cy > maxy) maxy = cy;
                        if (cx == 0 || cy == 0 || cx == Maze.W - 1 || cy == Maze.H - 1) border = true;
                        if (cx == 12 && cy == 8) house = true;
                        int[] dxs = { 1, -1, 0, 0 };
                        int[] dys = { 0, 0, 1, -1 };
                        for (int i = 0; i < 4; i++)
                        {
                            int nx = cx + dxs[i], ny = cy + dys[i];
                            if (nx < 0 || ny < 0 || nx >= Maze.W || ny >= Maze.H) continue;
                            if (seen[ny, nx] || !m.IsWall(nx, ny)) continue;
                            seen[ny, nx] = true;
                            q.Enqueue(ny * Maze.W + nx);
                        }
                    }
                    compIndex++;
                    if (border || house) continue;
                    int w = maxx - minx + 1, h = maxy - miny + 1;
                    if (h < 2) continue;
                    int n = Math.Max(1, w / 4);
                    for (int k = 0; k < n; k++)
                    {
                        float xc = (minx + (k + 0.5f) * w / n) * T;
                        float yc = OY + (miny + h / 2f) * T;
                        switch ((compIndex + k) % 4)
                        {
                            case 0: Sprites.Mushroom(g, xc, yc, 1.0f); break;
                            case 1: Sprites.Flower(g, xc, yc, 1.0f); break;
                            case 2: Sprites.Spruce(g, xc, yc, 1.0f); break;
                            default: Sprites.Grass(g, xc, yc, 1.0f); break;
                        }
                    }
                }
        }

        // =====================================================================
        //  Frame
        // =====================================================================
        public void Render(Graphics g, Game game, bool muted)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            if (game.State == GameState.Title)
            {
                DrawTitle(g, game, muted);
                return;
            }

            bool flash = game.State == GameState.LevelClear && (((int)(game.StateTimer * 6f)) & 1) == 0;
            g.DrawImage(flash ? bgFlash : bgNormal, 0, 0, LW, LH);

            DrawCrumbs(g, game);
            DrawActors(g, game);
            DrawPopups(g, game);
            DrawHud(g, game, muted);

            switch (game.State)
            {
                case GameState.Ready: DrawReady(g); break;
                case GameState.Paused: DrawPaused(g); break;
                case GameState.LevelClear: DrawLevelClear(g, game); break;
                case GameState.GameOver: DrawGameOver(g, game); break;
            }
        }

        private void DrawCrumbs(Graphics g, Game game)
        {
            float pulse = 1f + 0.10f * (float)Math.Sin(game.Time * 6f);
            using (var crumb = new SolidBrush(Color.FromArgb(255, 218, 80)))
            using (var crumbHi = new SolidBrush(Color.FromArgb(255, 245, 190)))
                for (int y = 0; y < Maze.H; y++)
                    for (int x = 0; x < Maze.W; x++)
                    {
                        char c = game.Maze.Cells[y, x];
                        float cx = x * T + T / 2f, cy = OY + y * T + T / 2f;
                        if (c == '.')
                        {
                            g.FillEllipse(crumb, cx - 3, cy - 3, 6, 6);
                            g.FillEllipse(crumbHi, cx - 1.5f, cy - 2.5f, 2.5f, 2.5f);
                        }
                        else if (c == 'o') Sprites.Apple(g, cx, cy, pulse);
                    }
        }

        private void DrawActors(Graphics g, Game game)
        {
            var p = game.Player;
            float px = (p.X + 0.5f) * T, py = OY + (p.Y + 0.5f) * T;

            if (game.State == GameState.Dying)
            {
                float prog = 1f - game.StateTimer / 1.6f;
                Sprites.Kolobok(g, px, py, Math.Max(0.05f, 1f - prog), p.FaceX, p.FaceY, 1f, game.RollAngle + prog * 900f, 0f);
                return;
            }

            foreach (var gh in game.Ghosts)
            {
                float gx = (gh.X + 0.5f) * T, gy = OY + (gh.Y + 0.5f) * T;
                float bob = (float)Math.Sin(game.Time * 8f + gh.Kind * 1.7f);
                if (gh.Mode == GhostMode.InHouse) gy += bob * 3f;
                else if (gh.Kind == 2) gy += Math.Abs(bob) * -2f;           // bear: heavy, slow stomp
                else gy += bob * 1.2f;
                bool flash = gh.Frightened && game.FrightLeft < 2f && (((int)(game.Time * 6f)) & 1) == 0;
                Sprites.Ghost(g, gh.Kind, gx, gy, 1.0f, gh.FaceX, gh.FaceY, gh.Frightened, flash,
                    gh.Mode == GhostMode.Eaten, game.Time);
            }

            bool visible = game.Invuln <= 0f || (((int)(game.Time * 14f)) & 1) == 0;
            if (visible)
            {
                float mouth = p.Moving ? 0.1f + 0.9f * (float)Math.Abs(Math.Sin(game.MouthT)) : 0.25f;
                float hop = p.Moving ? (float)Math.Abs(Math.Sin(game.MouthT * 0.7f)) * 2.5f : 0f;
                Sprites.Kolobok(g, px, py, 0.98f, p.FaceX, p.FaceY, mouth, game.RollAngle, hop);
            }
        }

        private void DrawPopups(Graphics g, Game game)
        {
            foreach (var p in game.Popups)
            {
                float rise = (1f - p.Life) * 22f;
                Ctr(g, p.Text, f16, (p.X + 0.5f) * T, OY + p.Y * T - rise, Cream, Color.FromArgb(120, 70, 0), 1);
            }
        }

        // ---------- HUD ----------
        private void DrawHud(Graphics g, Game game, bool muted)
        {
            Fill(g, Color.Black, 0, 0, LW, OY);
            Fill(g, Color.FromArgb(70, 40, 10), 0, OY - 3, LW, 3);
            Fill(g, Color.FromArgb(255, 204, 30), 0, OY - 3, LW, 1);

            DrawTxt(g, "SCORE", f16, 18, 6, Gold, Color.Black, 0, StringAlignment.Near);
            DrawTxt(g, game.Score.ToString("D6"), f28, 18, 24, Color.White, Color.Black, 0, StringAlignment.Near);
            DrawTxt(g, "HIGH SCORE", f16, 180, 6, Gold, Color.Black, 0, StringAlignment.Near);
            DrawTxt(g, game.HiScore.ToString("D6"), f28, 180, 24, Color.White, Color.Black, 0, StringAlignment.Near);

            Ctr(g, "K O L O B O K  R E B O R N", f28, LW / 2f, 4, Gold, RedOutline, 2);
            Ctr(g, muted ? "[M] SOUND OFF" : "[M] SOUND ON", f12, LW / 2f, 38, muted ? Color.FromArgb(255, 150, 150) : Cyan,
                Color.Black, 0);

            DrawTxt(g, "LEVEL", f16, 740, 6, Gold, Color.Black, 0, StringAlignment.Near);
            DrawTxt(g, game.Level.ToString("D2"), f28, 740, 24, Green, Color.Black, 0, StringAlignment.Near);
            DrawTxt(g, "LIVES", f16, 850, 6, Gold, Color.Black, 0, StringAlignment.Near);
            for (int i = 0; i < Math.Max(0, game.Lives); i++)
                Sprites.Kolobok(g, 862 + i * 28, 42, 0.48f, 0, 1, 0.1f, 0f, 0f);

            if (game.FrightLeft > 0f && game.FrightTotal > 0f)
            {
                float frac = Math.Max(0f, Math.Min(1f, game.FrightLeft / game.FrightTotal));
                Fill(g, Color.FromArgb(40, 30, 6), 330, 54, 332, 6);
                Fill(g, game.FrightLeft < 2f ? Color.FromArgb(255, 90, 60) : Color.FromArgb(255, 210, 60), 331, 55, 330 * frac, 4);
            }
        }

        // ---------- overlays ----------
        private void DrawReady(Graphics g)
        {
            var r = new Rectangle(386, 414, 220, 36);
            Panel(g, r, Gold, 235);
            Ctr(g, "READY!", f32, LW / 2f, 417, Gold, Color.FromArgb(120, 60, 0), 2);
        }

        private void DrawPaused(Graphics g)
        {
            Fill(g, Color.FromArgb(150, 0, 0, 0), 0, OY, LW, Maze.H * T);
            var r = new Rectangle(LW / 2 - 200, OY + 190, 400, 170);
            Panel(g, r, Gold, 245);
            Ctr(g, "PAUSED", f64, LW / 2f, r.Y + 18, Gold, RedOutline, 3);
            Ctr(g, "P / ESC = RESUME", f20, LW / 2f, r.Y + 112, Cream, Color.Black, 1);
            Ctr(g, "M = SOUND", f16, LW / 2f, r.Y + 140, Cyan, Color.Black, 0);
        }

        private void DrawLevelClear(Graphics g, Game game)
        {
            var r = new Rectangle(LW / 2 - 280, OY + 240, 560, 90);
            Panel(g, r, Green, 235);
            Ctr(g, "LEVEL " + game.Level + " COMPLETE!", f48, LW / 2f, r.Y + 18, Green, Color.FromArgb(10, 60, 10), 2);
        }

        private void DrawGameOver(Graphics g, Game game)
        {
            Fill(g, Color.FromArgb(160, 0, 0, 0), 0, OY, LW, Maze.H * T);
            var r = new Rectangle(LW / 2 - 240, OY + 150, 480, 290);
            Panel(g, r, Color.FromArgb(255, 90, 60), 245);
            Ctr(g, "GAME OVER", f64, LW / 2f, r.Y + 18, Color.FromArgb(255, 90, 60), Color.FromArgb(80, 0, 0), 3);
            Ctr(g, "SCORE", f16, LW / 2f, r.Y + 110, Cyan, Color.Black, 0);
            Ctr(g, game.Score.ToString("D6"), f32, LW / 2f, r.Y + 130, Color.White, Color.Black, 1);
            Ctr(g, "HIGH SCORE", f16, LW / 2f, r.Y + 176, Gold, Color.Black, 0);
            Ctr(g, game.HiScore.ToString("D6"), f28, LW / 2f, r.Y + 196, Color.White, Color.Black, 1);
            Ctr(g, "ENTER = RESTART      ESC = TITLE", f16, LW / 2f, r.Y + 250, Cream, Color.Black, 0);
        }

        // ---------- title screen ----------
        private void DrawTitle(Graphics g, Game game, bool muted)
        {
            using (var br = new LinearGradientBrush(new Rectangle(0, 0, LW, LH), Color.FromArgb(8, 34, 20),
                Color.FromArgb(0, 0, 0), 90f))
                g.FillRectangle(br, 0, 0, LW, LH);

            for (int x = 10, i = 0; x < LW; x += 62, i++)
                Sprites.Spruce(g, x, LH - 22 - (i % 3) * 7, 1.7f);

            Ctr(g, "KOLOBOK", f110, LW / 2f, 14, Gold, RedOutline, 4);
            Ctr(g, "REBORN", f64i, LW / 2f, 130, Green, Color.FromArgb(10, 50, 10), 3);

            float t = game.Time;
            float hop = (float)Math.Abs(Math.Sin(t * 5f)) * 8f;
            float mouth = 0.5f + 0.5f * (float)Math.Sin(t * 6f);
            Sprites.Kolobok(g, LW / 2f, 300, 4.0f, 1, 0, mouth, t * 160f, hop);

            string[] names = { "FOX (\u041B\u0418\u0421\u0410)", "WOLF (\u0412\u041E\u041B\u041A)", "BEAR (\u041C\u0415\u0414\u0412\u0415\u0414\u042C)", "HARE (\u0417\u0410\u042F\u0426)" };
            for (int i = 0; i < 4; i++)
            {
                float x = LW / 2f + (i - 1.5f) * 190f;
                Sprites.Ghost(g, i, x, 466, 2.0f, 0, 1, false, false, false, t + i);
                Ctr(g, names[i], f16, x, 512, Cream, Color.Black, 1);
            }

            if (((int)(t * 2f) & 1) == 0)
                Ctr(g, "Press ENTER to start", f32, LW / 2f, 548, Gold, RedOutline, 2);
            Ctr(g, "ARROWS / WASD: MOVE     P / ESC: PAUSE     M: SOUND " + (muted ? "OFF" : "ON") + "     ESC (here): EXIT",
                f16, LW / 2f, 592, Cyan, Color.Black, 1);
            Ctr(g, "Eat every crumb. Golden apples make the forest folk run!", f16, LW / 2f, 616, Cream, Color.Black, 1);
            Ctr(g, "HIGH SCORE " + game.HiScore.ToString("D6"), f20, LW / 2f, 640, Gold, Color.Black, 1);
        }
    }
}
