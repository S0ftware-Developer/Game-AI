using System;
using System.Collections.Generic;

namespace KolobokReborn
{
    /// <summary>
    /// Enemy behaviour. Every decision uses shortest-path distances on the real maze, so enemies always
    /// follow corridors and can never get stuck.
    ///   Fox  - chases Kolobok's tile.            Wolf - aims 4 tiles ahead of Kolobok (interception).
    ///   Bear - chases, but is slower (see speed). Hare - mostly random turns, sometimes chases.
    /// </summary>
    internal static class GhostAI
    {
        private static readonly int[] Dx = { 0, -1, 0, 1 };   // up, left, down, right
        private static readonly int[] Dy = { -1, 0, 1, 0 };
        private static readonly int[] CornerX = { 29, 1, 1, 29 };
        private static readonly int[] CornerY = { 1, 1, 17, 17 };

        public static void Choose(Ghost g, Maze m, Actor player, bool scatter, Random rng)
        {
            // state transitions that happen on reaching a tile centre
            if (g.Mode == GhostMode.Leaving && g.TX == Maze.ExitX && g.TY == Maze.ExitY) g.Mode = GhostMode.Active;
            if (g.Mode == GhostMode.Eaten && g.TX == Maze.HouseX && g.TY == Maze.HouseY)
            {
                g.Mode = GhostMode.Leaving;
                g.Frightened = false;
            }

            bool door = g.Mode == GhostMode.Leaving || g.Mode == GhostMode.Eaten;
            bool allowReverse = door;

            // gather legal directions
            var cand = new List<int>(4);
            for (int pass = 0; pass < 2 && cand.Count == 0; pass++)
            {
                for (int i = 0; i < 4; i++)
                {
                    bool isReverse = g.Moving && Dx[i] == -g.DX && Dy[i] == -g.DY;
                    if (isReverse && !allowReverse && pass == 0) continue;
                    if (m.Open(g.TX + Dx[i], g.TY + Dy[i], true, door)) cand.Add(i);
                }
            }
            if (cand.Count == 0) { g.DX = 0; g.DY = 0; return; }

            int pick;
            bool random = false;
            int tx = 0, ty = 0;

            if (g.Mode == GhostMode.Eaten) { tx = Maze.HouseX; ty = Maze.HouseY; }
            else if (g.Mode == GhostMode.Leaving) { tx = Maze.ExitX; ty = Maze.ExitY; }
            else if (g.Frightened) random = true;
            else if (scatter) { tx = CornerX[g.Kind]; ty = CornerY[g.Kind]; }
            else
            {
                int px = Math.Max(0, Math.Min(Maze.W - 1, player.TX));
                int py = player.TY;
                tx = px; ty = py;
                if (g.Kind == 1)
                {
                    // Wolf: aim ahead of Kolobok, backing off until the aim point is a real corridor tile
                    int fx = player.Moving ? player.DX : 0, fy = player.Moving ? player.DY : 0;
                    for (int k = 4; k >= 1; k--)
                    {
                        int ax = px + fx * k, ay = py + fy * k;
                        if (ax >= 0 && ax < Maze.W && m.Open(ax, ay, true, false)) { tx = ax; ty = ay; break; }
                    }
                }
                else if (g.Kind == 3 && rng.NextDouble() < 0.6) random = true;   // Hare: erratic
            }

            if (random)
            {
                pick = cand[rng.Next(cand.Count)];
            }
            else
            {
                int[,] dist = m.Distances(tx, ty, door);
                pick = cand[0];
                int best = int.MaxValue;
                foreach (int i in cand)
                {
                    int nx = g.TX + Dx[i], ny = g.TY + Dy[i];
                    if (nx == -1) nx = Maze.W - 1; else if (nx == Maze.W) nx = 0;
                    int d = dist[ny, nx];
                    if (d < best) { best = d; pick = i; }
                }
            }

            g.DX = Dx[pick];
            g.DY = Dy[pick];
        }
    }
}
