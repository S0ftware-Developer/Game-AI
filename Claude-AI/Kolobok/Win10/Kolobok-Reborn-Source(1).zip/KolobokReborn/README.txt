KOLOBOK REBORN  -  C# / .NET 8 / Windows Forms  (Windows 10/11 x64)
====================================================================

A Pac-Man-style maze game with Russian folk-tale characters. You are Kolobok, the golden bun.
Eat every crumb while the Fox, the Wolf, the Bear and the Hare chase you through the forest maze.
Golden apples make them run away - catch them for bonus points. No external assets or NuGet
packages: graphics are drawn in code, sounds are synthesised at start-up.

BUILD (needs the .NET 8 SDK and internet access on the first build)
  1. Unzip the archive anywhere.
  2. Double-click build.bat   (it runs exactly:
       dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true )

RESULT - the ONLY thing you need to distribute
  bin\Release\net8.0-windows\win-x64\publish\KolobokReborn.exe
  One self-contained file: no .NET installation and no other files are needed next to it.
  (Expect a large file, tens of MB: the .NET runtime and Windows Forms are embedded in it.)

WHY THERE WERE ~240 FILES AFTER THE BUILD
  A self-contained build also copies the whole .NET runtime (~240 files, many .dll) into
  bin\Release\net8.0-windows\win-x64\ as INTERMEDIATE build output. Those files are not the game.
  build.bat deletes them after publishing, so only the "publish" folder is left there, and it
  contains just KolobokReborn.exe (any .pdb is removed; none is produced anyway).
  If you run "dotnet build" or "dotnet run" by hand, the ~240 files will appear again - ignore them.

CONTROLS
  Arrow keys / WASD ... move (a turn is remembered until the next junction; reversing is instant)
  P or Esc ............ pause / resume
  Enter ............... start (title screen) / restart (game over)
  Esc on title screen . exit the game          Esc on game over ... back to the title screen
  M ................... sound on / off

RULES
  - 251 crumbs (10 pts) and 4 golden apples (50 pts) per level. Eat them all to clear the level.
  - Apples frighten the enemies (blue, flashing white in the last 2 s; a bar under the title shows the
    time left). Catching them scores 200 / 400 / 800 / 1600; eaten enemies fly home and come back out.
  - Touching a dangerous enemy costs a life (3 lives, +1 at 10000 points). After respawn Kolobok blinks and is
    invulnerable for 2.5 s; enemies are reset to their house.
  - Enemies: Fox - chases you; Wolf - aims 4 tiles ahead of you (interception); Bear - slow but relentless;
    Hare - fast and erratic. They alternate between scatter (corner) and chase phases.
  - Each level: enemies get faster, apples last shorter, enemies leave the house sooner.
  - Tunnel: row in the middle - leave one side and appear on the other.
  - Hi-score file: %LocalAppData%\KolobokReborn\highscore.txt

FILES
  Game.cs (rules/state, no drawing)   Maze.cs (level data, grid queries, BFS)
  Actors.cs (grid movement)           GhostAI.cs (enemy behaviour)
  Renderer.cs (all drawing)           Sprites.cs (characters and props)
  GameForm.cs (window, input, loop)   Sfx.cs (sounds)   Storage.cs (hi-score)
  Program.cs   KolobokReborn.csproj   build.bat   README.txt

VERIFICATION STATUS
  The source was written WITHOUT access to a .NET SDK, so it has NOT been compiled, published or run by
  its author. The size of the .exe and its stand-alone start have not been measured or tested.
  What WAS checked: the .csproj properties (script above), the maze (all crumbs reachable, no dead ends)
  and a Python model of the movement/AI logic. If the compiler reports errors, send them back to be fixed.

(c) 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space
