@echo off
rem Kolobok Reborn - publish a standalone single-file Windows x64 executable.
rem Result: bin\Release\net8.0-windows\win-x64\publish\KolobokReborn.exe
setlocal
cd /d "%~dp0"

set "WINX64=bin\Release\net8.0-windows\win-x64"
set "PUB=%WINX64%\publish"

dotnet --version >nul 2>&1
if errorlevel 1 (
  echo .NET SDK not found. Install the .NET 8 SDK: https://dotnet.microsoft.com/download
  pause
  exit /b 1
)

dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true
if errorlevel 1 (
  echo.
  echo BUILD FAILED - see the messages above.
  pause
  exit /b 1
)

rem A self-contained build also leaves ~240 runtime files in %WINX64%\ (intermediate build output).
rem They are NOT part of the game: delete them so that only the "publish" folder remains.
for %%F in ("%WINX64%\*") do del /q "%%F" >nul 2>&1
for /d %%D in ("%WINX64%\*") do if /i not "%%~nxD"=="publish" rmdir /s /q "%%D" >nul 2>&1
del /q "%PUB%\*.pdb" >nul 2>&1

if not exist "%PUB%\KolobokReborn.exe" (
  echo.
  echo ERROR: %PUB%\KolobokReborn.exe was not produced.
  pause
  exit /b 1
)

echo.
echo SUCCESS. Standalone game (copy only this file to another PC):
echo   %~dp0%PUB%\KolobokReborn.exe
for %%A in ("%PUB%\KolobokReborn.exe") do echo   size: %%~zA bytes
echo.
echo Files in the publish folder:
dir /b "%PUB%"
pause
exit /b 0
