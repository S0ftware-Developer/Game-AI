using System;
using System.Collections.Generic;

namespace KolobokReborn
{
    /// <summary>
    /// Level data and grid queries. Legend: # wall, . crumb, o golden apple (power-up), space = empty corridor,
    /// H enemy-house floor, - house door, P player start. Row 9 is the tunnel row (open at both side edges).
    /// The layout is left/right symmetric; every crumb is reachable from the start (checked offline).
    /// </summary>
    internal sealed class Maze
    {
        public const int W = 31, H = 19, TunnelRow = 9;
        public const int HouseX = 15, HouseY = 8;      // inside the house, just below the door
        public const int ExitX = 15, ExitY = 6;        // corridor tile just above the door
        public const int StartX = 15, StartY = 14;     // Kolobok start

        // Enemy start tiles inside the house: Fox, Wolf, Bear, Hare
        public static readonly int[] GhostStartX = { 15, 13, 17, 15 };
        public static readonly int[] GhostStartY = { 8, 9, 9, 10 };

        private static readonly string[] Template =
        {
            "###############################",
            "#o...........................o#",
            "#.####.####.###.###.####.####.#",
            "#.####.####.###.###.####.####.#",
            "#.............................#",
            "#.####.####.#######.####.####.#",
            "#.............................#",
            "#.#########.###-###.#########.#",
            "#.#########.#HHHHH#.#########.#",
            " ...........#HHHHH#........... ",
            "#.#########.#HHHHH#.#########.#",
            "#.#########.#######.#########.#",
            "#.............................#",
            "#.####.####.#######.####.####.#",
            "#..............P..............#",
            "#.####.####.###.###.####.####.#",
            "#.####.####.###.###.####.####.#",
            "#o...........................o#",
            "###############################"
        };

        public readonly char[,] Cells = new char[H, W];
        public int DotsLeft;
        public int DotsTotal;

        public Maze() { Reset(); }

        public void Reset()
        {
            DotsLeft = 0;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                {
                    char c = Template[y][x];
                    if (c == 'P') c = ' ';
                    Cells[y, x] = c;
                    if (c == '.' || c == 'o') DotsLeft++;
                }
            DotsTotal = DotsLeft;
        }

        public bool IsWall(int x, int y)
        {
            if (x < 0 || x >= W || y < 0 || y >= H) return true;
            return Cells[y, x] == '#';
        }

        /// <summary>Can an actor step onto tile (x,y)? x may be -1 or W only on the tunnel row.</summary>
        public bool Open(int x, int y, bool ghost, bool door)
        {
            if (y < 0 || y >= H) return false;
            if (x == -1 || x == W) return y == TunnelRow;
            if (x < 0 || x > W - 1) return false;
            char c = Cells[y, x];
            if (c == '#') return false;
            if (c == 'H') return ghost;
            if (c == '-') return ghost && door;
            return true;
        }

        /// <summary>Shortest-path distances (in tiles) from target tile to every reachable tile.</summary>
        public int[,] Distances(int tx, int ty, bool door)
        {
            var d = new int[H, W];
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++) d[y, x] = 9999;
            var q = new Queue<int>();
            d[ty, tx] = 0;
            q.Enqueue(ty * W + tx);
            int[] dxs = { 0, -1, 0, 1 };
            int[] dys = { -1, 0, 1, 0 };
            while (q.Count > 0)
            {
                int cur = q.Dequeue();
                int cx = cur % W, cy = cur / W;
                for (int i = 0; i < 4; i++)
                {
                    int nx = cx + dxs[i], ny = cy + dys[i];
                    if (!Open(nx, ny, true, door)) continue;
                    if (nx == -1) nx = W - 1; else if (nx == W) nx = 0;   // tunnel wrap
                    if (d[ny, nx] != 9999) continue;
                    d[ny, nx] = d[cy, cx] + 1;
                    q.Enqueue(ny * W + nx);
                }
            }
            return d;
        }

        /// <summary>Remove a crumb/apple from tile; returns '.', 'o' or ' ' (nothing).</summary>
        public char Eat(int x, int y)
        {
            if (x < 0 || x >= W || y < 0 || y >= H) return ' ';
            char c = Cells[y, x];
            if (c == '.' || c == 'o')
            {
                Cells[y, x] = ' ';
                DotsLeft--;
                return c;
            }
            return ' ';
        }
    }
}
