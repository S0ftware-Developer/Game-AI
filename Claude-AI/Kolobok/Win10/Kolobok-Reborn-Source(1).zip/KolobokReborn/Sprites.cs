using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace KolobokReborn
{
    /// <summary>Cartoon characters and props drawn with GDI+ primitives (no image files).</summary>
    internal static class Sprites
    {
        private static readonly Color Ink = Color.FromArgb(28, 20, 24);

        public static Color Mix(Color a, Color b, float t)
        {
            return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t),
                (int)(a.B + (b.B - a.B) * t));
        }

        private static void Fill(Graphics g, Color c, float x, float y, float w, float h)
        {
            using (var b = new SolidBrush(c)) g.FillRectangle(b, x, y, w, h);
        }

        private static void Oval(Graphics g, Color c, float x, float y, float w, float h)
        {
            using (var b = new SolidBrush(c)) g.FillEllipse(b, x, y, w, h);
        }

        private static void OvalO(Graphics g, Color fill, Color line, float lw, float x, float y, float w, float h)
        {
            using (var b = new SolidBrush(fill)) g.FillEllipse(b, x, y, w, h);
            using (var p = new Pen(line, lw)) g.DrawEllipse(p, x, y, w, h);
        }

        private static void Poly(Graphics g, Color fill, params PointF[] pts)
        {
            using (var b = new SolidBrush(fill)) g.FillPolygon(b, pts);
        }

        private static void PolyO(Graphics g, Color fill, Color line, params PointF[] pts)
        {
            using (var b = new SolidBrush(fill)) g.FillPolygon(b, pts);
            using (var p = new Pen(line, 1.5f)) g.DrawPolygon(p, pts);
        }

        private static void Line(Graphics g, Color c, float w, float x1, float y1, float x2, float y2)
        {
            using (var p = new Pen(c, w)) { p.StartCap = LineCap.Round; p.EndCap = LineCap.Round; g.DrawLine(p, x1, y1, x2, y2); }
        }

        // =====================================================================
        //  Kolobok
        // =====================================================================
        /// <summary>The golden bun. mouth 0..1 = how wide it is open; roll = rolling angle in degrees.</summary>
        public static void Kolobok(Graphics g, float cx, float cy, float s, int fx, int fy, float mouth,
            float roll, float hop)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(cx, cy - hop * s);
            g.ScaleTransform(s, s);

            Oval(g, Color.FromArgb(70, 0, 0, 0), -11, 12 + hop, 22, 5);                       // ground shadow
            OvalO(g, Color.FromArgb(255, 204, 48), Color.FromArgb(150, 90, 10), 1.6f, -14, -14, 28, 28);
            Oval(g, Color.FromArgb(120, 230, 150, 30), -8, 2, 20, 11);                          // baked shade
            Oval(g, Color.FromArgb(255, 236, 130), -10, -12, 13, 9);                            // highlight

            for (int k = 0; k < 7; k++)                                                          // baked-crust spots roll with the bun
            {
                double a = (roll + k * 51.4) * Math.PI / 180.0;
                float px = (float)Math.Cos(a) * 10.5f, py = (float)Math.Sin(a) * 10.5f;
                Oval(g, Color.FromArgb(215, 145, 30), px - 1.4f, py - 1.4f, 2.8f, 2.8f);
            }

            Oval(g, Color.FromArgb(150, 255, 120, 100), -12, 1, 7, 5);                          // cheeks
            Oval(g, Color.FromArgb(150, 255, 120, 100), 5, 1, 7, 5);

            float ex = fx * 1.4f, ey = fy * 1.4f;
            OvalO(g, Color.White, Ink, 1f, -8.5f, -8.5f, 7.5f, 8.5f);                           // eyes
            OvalO(g, Color.White, Ink, 1f, 1f, -8.5f, 7.5f, 8.5f);
            Oval(g, Ink, -5.8f + ex, -5.5f + ey, 3f, 4f);
            Oval(g, Ink, 3.8f + ex, -5.5f + ey, 3f, 4f);
            Line(g, Color.FromArgb(110, 60, 10), 1.8f, -9.5f, -11.5f, -3.5f, -12.5f);           // brows (one cheekily raised)
            Line(g, Color.FromArgb(110, 60, 10), 1.8f, 3.5f, -13.5f, 9.5f, -11f);

            Oval(g, Color.FromArgb(235, 140, 40), -1.5f, -1f, 3f, 3f);                          // nose
            if (mouth < 0.15f)
            {
                using (var p = new Pen(Color.FromArgb(120, 30, 20), 1.6f))
                    g.DrawArc(p, -6, 1.5f, 12, 8, 20, 140);
            }
            else
            {
                float h = 2f + 8f * mouth;
                Oval(g, Color.FromArgb(120, 24, 30), -5, 4, 10, h);
                Oval(g, Color.FromArgb(230, 100, 100), -3, 4 + h * 0.5f, 6, h * 0.5f);
            }
            g.Restore(st);
        }

        // =====================================================================
        //  Forest enemies. kind: 0 Fox, 1 Wolf, 2 Bear, 3 Hare
        // =====================================================================
        public static void Ghost(Graphics g, int kind, float cx, float cy, float s, int fx, int fy,
            bool fright, bool flash, bool eaten, float t)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(cx, cy);
            g.ScaleTransform(s, s);
            if (kind == 2) g.ScaleTransform(1.12f, 1.12f);          // the bear has the biggest silhouette

            Color body;
            switch (kind)
            {
                case 0: body = Color.FromArgb(240, 120, 24); break;
                case 1: body = Color.FromArgb(122, 128, 144); break;
                case 2: body = Color.FromArgb(140, 86, 42); break;
                default: body = Color.FromArgb(228, 228, 236); break;
            }
            Color outline = Mix(body, Color.Black, 0.45f);
            if (fright)
            {
                body = flash ? Color.FromArgb(245, 245, 255) : Color.FromArgb(46, 66, 220);
                outline = Color.FromArgb(18, 20, 90);
            }

            float px = fx * 1.5f, py = fy * 1.5f;
            if (!eaten)
            {
                Ears(g, kind, body, outline, fright);
                Body(g, body, outline, t);
                if (fright) FrightFace(g, flash);
                else Face(g, kind, px, py);
            }
            else
            {
                Eye(g, -8.5f, -5f, 7.5f, 9f, px, py, 3f, 4f, Ink);
                Eye(g, 1f, -5f, 7.5f, 9f, px, py, 3f, 4f, Ink);
            }
            g.Restore(st);
        }

        private static void Eye(Graphics g, float x, float y, float w, float h, float px, float py,
            float pw, float ph, Color line)
        {
            OvalO(g, Color.White, line, 1f, x, y, w, h);
            Oval(g, Ink, x + (w - pw) / 2f + px * 0.6f, y + (h - ph) / 2f + py * 0.6f, pw, ph);
        }

        private static void Body(Graphics g, Color body, Color outline, float t)
        {
            float w = (float)Math.Sin(t * 10f) * 1.5f;
            using (var path = new GraphicsPath())
            {
                path.AddArc(-13f, -14f, 26f, 26f, 180f, 180f);
                path.AddLine(13f, -1f, 13f, 12f);
                path.AddLines(new[]
                {
                    new PointF(13f, 12f), new PointF(8.7f, 8f + w), new PointF(4.3f, 12f), new PointF(0f, 8f + w),
                    new PointF(-4.3f, 12f), new PointF(-8.7f, 8f + w), new PointF(-13f, 12f)
                });
                path.CloseFigure();
                using (var b = new SolidBrush(body)) g.FillPath(b, path);
                using (var p = new Pen(outline, 1.5f)) g.DrawPath(p, path);
            }
        }

        private static void Ears(Graphics g, int kind, Color body, Color outline, bool fright)
        {
            switch (kind)
            {
                case 0:   // fox: tall pointed ears with dark insides
                    PolyO(g, body, outline, new PointF(-13, -5), new PointF(-10, -22), new PointF(-2, -11));
                    PolyO(g, body, outline, new PointF(13, -5), new PointF(10, -22), new PointF(2, -11));
                    if (!fright)
                    {
                        Poly(g, Color.FromArgb(80, 30, 10), new PointF(-11, -8), new PointF(-10, -17), new PointF(-5.5f, -11));
                        Poly(g, Color.FromArgb(80, 30, 10), new PointF(11, -8), new PointF(10, -17), new PointF(5.5f, -11));
                    }
                    break;
                case 1:   // wolf: pointed ears
                    PolyO(g, body, outline, new PointF(-13, -4), new PointF(-11, -23), new PointF(-3, -12));
                    PolyO(g, body, outline, new PointF(13, -4), new PointF(11, -23), new PointF(3, -12));
                    if (!fright)
                    {
                        Poly(g, Color.FromArgb(60, 62, 78), new PointF(-11.5f, -7), new PointF(-10.5f, -18), new PointF(-6, -11));
                        Poly(g, Color.FromArgb(60, 62, 78), new PointF(11.5f, -7), new PointF(10.5f, -18), new PointF(6, -11));
                    }
                    break;
                case 2:   // bear: small round ears
                    OvalO(g, body, outline, 1.5f, -16, -19, 10, 10);
                    OvalO(g, body, outline, 1.5f, 6, -19, 10, 10);
                    if (!fright)
                    {
                        Oval(g, Color.FromArgb(214, 168, 106), -14, -17, 6, 6);
                        Oval(g, Color.FromArgb(214, 168, 106), 8, -17, 6, 6);
                    }
                    break;
                default:  // hare: very long ears
                    OvalO(g, body, outline, 1.5f, -10, -36, 8, 26);
                    OvalO(g, body, outline, 1.5f, 2, -36, 8, 26);
                    if (!fright)
                    {
                        Oval(g, Color.FromArgb(255, 170, 190), -8.5f, -33, 5, 19);
                        Oval(g, Color.FromArgb(255, 170, 190), 3.5f, -33, 5, 19);
                    }
                    break;
            }
        }

        private static void Face(Graphics g, int kind, float px, float py)
        {
            switch (kind)
            {
                case 0:   // fox: white muzzle, sly smile, slanted eyelids
                    Oval(g, Color.FromArgb(255, 240, 226), -9, -1, 18, 12);
                    Oval(g, Ink, -2, -1, 4, 3);
                    using (var p = new Pen(Ink, 1.3f)) g.DrawArc(p, -6, 2, 12, 6, 20, 140);
                    Eye(g, -9.5f, -9, 7, 6.5f, px, py, 3f, 3.5f, Ink);
                    Eye(g, 2.5f, -9, 7, 6.5f, px, py, 3f, 3.5f, Ink);
                    Line(g, Ink, 1.6f, -10.5f, -9.5f, -3f, -6.5f);
                    Line(g, Ink, 1.6f, 3f, -6.5f, 10.5f, -9.5f);
                    break;
                case 1:   // wolf: long muzzle, teeth, angry brows
                    Oval(g, Color.FromArgb(198, 202, 214), -8, -2, 16, 14);
                    Oval(g, Ink, -3, -2, 6, 4);
                    Line(g, Ink, 1.2f, -6, 7, 6, 7);
                    Poly(g, Color.White, new PointF(-5, 7), new PointF(-2.5f, 7), new PointF(-3.7f, 10.5f));
                    Poly(g, Color.White, new PointF(2.5f, 7), new PointF(5, 7), new PointF(3.7f, 10.5f));
                    Eye(g, -10, -9, 7, 6, px, py, 3f, 3.5f, Ink);
                    Eye(g, 3, -9, 7, 6, px, py, 3f, 3.5f, Ink);
                    Line(g, Ink, 2f, -11, -12, -3, -8.5f);
                    Line(g, Ink, 2f, 3, -8.5f, 11, -12);
                    break;
                case 2:   // bear: tan muzzle, small eyes
                    OvalO(g, Color.FromArgb(214, 168, 106), Color.FromArgb(120, 80, 40), 1f, -7, 0, 14, 11);
                    Oval(g, Ink, -3, 0.5f, 6, 4);
                    Line(g, Ink, 1.2f, 0, 4.5f, 0, 7);
                    using (var p = new Pen(Ink, 1.2f)) g.DrawArc(p, -4, 5, 8, 4, 10, 160);
                    Oval(g, Ink, -8 + px * 0.5f, -7 + py * 0.5f, 4, 5);
                    Oval(g, Ink, 4 + px * 0.5f, -7 + py * 0.5f, 4, 5);
                    Oval(g, Color.White, -7 + px * 0.5f, -6.5f + py * 0.5f, 1.5f, 1.5f);
                    Oval(g, Color.White, 5 + px * 0.5f, -6.5f + py * 0.5f, 1.5f, 1.5f);
                    Line(g, Color.FromArgb(70, 40, 20), 2f, -9.5f, -9.5f, -4, -8.5f);
                    Line(g, Color.FromArgb(70, 40, 20), 2f, 4, -8.5f, 9.5f, -9.5f);
                    break;
                default:  // hare: huge nervous eyes, pink nose, buck teeth, whiskers
                    Oval(g, Color.FromArgb(255, 170, 185), -12, 1, 6, 4);
                    Oval(g, Color.FromArgb(255, 170, 185), 6, 1, 6, 4);
                    Eye(g, -9.5f, -10, 8, 9, px, py, 3f, 3.5f, Color.FromArgb(110, 110, 125));
                    Eye(g, 1.5f, -10, 8, 9, px, py, 3f, 3.5f, Color.FromArgb(110, 110, 125));
                    Oval(g, Color.FromArgb(255, 150, 170), -2, 0, 4, 3);
                    Fill(g, Color.White, -2, 3.5f, 4, 4.5f);
                    Line(g, Color.FromArgb(120, 120, 130), 0.8f, 0, 3.5f, 0, 8);
                    Line(g, Color.FromArgb(120, 120, 130), 1f, -9, 2, -17, 0);
                    Line(g, Color.FromArgb(120, 120, 130), 1f, -9, 4, -17, 5);
                    Line(g, Color.FromArgb(120, 120, 130), 1f, 9, 2, 17, 0);
                    Line(g, Color.FromArgb(120, 120, 130), 1f, 9, 4, 17, 5);
                    break;
            }
        }

        private static void FrightFace(Graphics g, bool flash)
        {
            Color c = flash ? Color.FromArgb(220, 40, 40) : Color.White;
            Oval(g, c, -6.5f, -6, 4, 4.5f);
            Oval(g, c, 2.5f, -6, 4, 4.5f);
            using (var p = new Pen(c, 1.5f))
                g.DrawLines(p, new[]
                {
                    new PointF(-8, 6), new PointF(-5, 3), new PointF(-2, 6), new PointF(1, 3),
                    new PointF(4, 6), new PointF(7, 3)
                });
        }

        // =====================================================================
        //  Props
        // =====================================================================
        /// <summary>Large golden apple (power-up).</summary>
        public static void Apple(Graphics g, float cx, float cy, float pulse)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(cx, cy);
            g.ScaleTransform(pulse, pulse);
            OvalO(g, Color.FromArgb(255, 210, 60), Color.FromArgb(150, 90, 10), 1.6f, -10, -9, 20, 20);
            Oval(g, Color.FromArgb(120, 235, 130, 40), -2, 0, 11, 10);
            Oval(g, Color.FromArgb(255, 246, 180), -6.5f, -6, 7, 6);
            Fill(g, Color.FromArgb(110, 70, 30), -1, -14, 2.5f, 6);
            Poly(g, Color.FromArgb(90, 200, 70), new PointF(1.5f, -12), new PointF(9, -16), new PointF(7.5f, -9.5f));
            g.Restore(st);
        }

        public static void Mushroom(Graphics g, float cx, float cy, float s)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(cx, cy);
            g.ScaleTransform(s, s);
            OvalO(g, Color.FromArgb(250, 235, 205), Color.FromArgb(150, 120, 80), 1f, -4.5f, -2, 9, 13);
            using (var b = new SolidBrush(Color.FromArgb(215, 40, 40))) g.FillPie(b, -12, -13, 24, 22, 180, 180);
            using (var p = new Pen(Color.FromArgb(110, 20, 20), 1.2f)) g.DrawArc(p, -12, -13, 24, 22, 180, 180);
            Oval(g, Color.White, -7, -9, 5, 4);
            Oval(g, Color.White, 2, -11, 5, 4);
            Oval(g, Color.White, 5, -5, 4, 3);
            Oval(g, Color.FromArgb(80, 190, 70), -9, 9, 18, 4);
            g.Restore(st);
        }

        public static void Flower(Graphics g, float cx, float cy, float s)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(cx, cy);
            g.ScaleTransform(s, s);
            Poly(g, Color.FromArgb(60, 170, 60), new PointF(0, 14), new PointF(-9, 6), new PointF(-2, 9));
            Poly(g, Color.FromArgb(60, 170, 60), new PointF(0, 14), new PointF(9, 6), new PointF(2, 9));
            Line(g, Color.FromArgb(60, 150, 60), 2f, 0, 4, 0, 14);
            for (int k = 0; k < 6; k++)
            {
                double a = k * Math.PI / 3.0;
                float px = (float)Math.Cos(a) * 6.5f, py = (float)Math.Sin(a) * 6.5f - 3f;
                OvalO(g, Color.White, Color.FromArgb(190, 190, 205), 0.8f, px - 3.5f, py - 3.5f, 7, 7);
            }
            Oval(g, Color.FromArgb(255, 200, 30), -3.5f, -6.5f, 7, 7);
            g.Restore(st);
        }

        public static void Spruce(Graphics g, float cx, float cy, float s)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(cx, cy);
            g.ScaleTransform(s, s);
            Fill(g, Color.FromArgb(110, 70, 30), -2.5f, 8, 5, 6);
            PolyO(g, Color.FromArgb(30, 120, 50), Color.FromArgb(14, 70, 28), new PointF(-12, 10), new PointF(0, -2), new PointF(12, 10));
            PolyO(g, Color.FromArgb(38, 142, 60), Color.FromArgb(14, 70, 28), new PointF(-10, 2), new PointF(0, -10), new PointF(10, 2));
            PolyO(g, Color.FromArgb(48, 164, 70), Color.FromArgb(14, 70, 28), new PointF(-7, -6), new PointF(0, -17), new PointF(7, -6));
            g.Restore(st);
        }

        public static void Grass(Graphics g, float cx, float cy, float s)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(cx, cy);
            g.ScaleTransform(s, s);
            Poly(g, Color.FromArgb(40, 170, 60), new PointF(-9, 10), new PointF(-11, -8), new PointF(-3, 10));
            Poly(g, Color.FromArgb(70, 200, 80), new PointF(-4, 10), new PointF(0, -12), new PointF(4, 10));
            Poly(g, Color.FromArgb(40, 170, 60), new PointF(3, 10), new PointF(11, -8), new PointF(9, 10));
            g.Restore(st);
        }

        /// <summary>Log hut (izba) with a thatched roof - decorates the enemy house.</summary>
        public static void Izba(Graphics g, float cx, float cy, float s)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(cx, cy);
            g.ScaleTransform(s, s);
            Fill(g, Color.FromArgb(130, 84, 40), -24, -2, 48, 24);
            for (int k = 0; k < 4; k++) Fill(g, Color.FromArgb(96, 58, 26), -24, 3 + k * 6, 48, 1.5f);
            Fill(g, Color.FromArgb(60, 34, 14), -24, -2, 2, 24);
            Fill(g, Color.FromArgb(60, 34, 14), 22, -2, 2, 24);
            Fill(g, Color.FromArgb(130, 84, 40), 10, -22, 7, 12);                                    // chimney
            PolyO(g, Color.FromArgb(230, 180, 50), Color.FromArgb(150, 100, 20), new PointF(-30, -1), new PointF(0, -28), new PointF(30, -1));
            Line(g, Color.FromArgb(180, 130, 30), 1.2f, -20, -6, 20, -6);
            Line(g, Color.FromArgb(180, 130, 30), 1.2f, -12, -13, 12, -13);
            Fill(g, Color.FromArgb(40, 110, 200), -6, 4, 12, 12);                                    // window
            Fill(g, Color.FromArgb(235, 235, 235), -0.8f, 4, 1.6f, 12);
            Fill(g, Color.FromArgb(235, 235, 235), -6, 9.2f, 12, 1.6f);
            g.Restore(st);
        }
    }
}
