using System;
using System.IO;

namespace KolobokReborn
{
    /// <summary>Hi-score persistence: one integer in %LocalAppData%\KolobokReborn\highscore.txt.</summary>
    internal static class HighScoreStore
    {
        private static readonly string FilePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "KolobokReborn", "highscore.txt");

        public static int Load()
        {
            try
            {
                int v;
                if (File.Exists(FilePath) && int.TryParse(File.ReadAllText(FilePath).Trim(), out v) && v > 0)
                    return v;
            }
            catch { }
            return 0;
        }

        public static void Save(int value)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
                File.WriteAllText(FilePath, value.ToString());
            }
            catch { }
        }
    }
}
