KOLOBOK REBORN  -  C# / .NET 8 / Windows Forms  (Windows 10/11 x64)
====================================================================

A Pac-Man-style maze game with Russian folk-tale characters. You are Kolobok, the golden bun.
Eat every crumb while the Fox, the Wolf, the Bear and the Hare chase you through the forest maze.
Golden apples make them run away - catch them for bonus points. No external assets or NuGet
packages: all graphics are drawn in code and all sounds are synthesised at start-up.

REQUIREMENTS (to BUILD)
  - Windows 10/11 x64
  - .NET 8 SDK  (https://dotnet.microsoft.com/download)  - check with:  dotnet --version
  - Internet access on the first build: the SDK downloads the win-x64 runtime pack from NuGet
    (needed for a self-contained build). It is cached afterwards.

BUILD AND PUBLISH (easy way)
  1. Unzip the archive anywhere.
  2. Double-click build.bat
  3. Result: dist\KolobokReborn.exe  (single file; no .NET installation needed to run it)

BUILD AND PUBLISH (manual commands, in the folder with KolobokReborn.csproj)
  dotnet restore
  dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
  Output: bin\Release\net8.0-windows\win-x64\publish\KolobokReborn.exe

  The .csproj already contains win-x64, SelfContained, PublishSingleFile,
  IncludeNativeLibrariesForSelfExtract and compression, so the two commands above are enough.
  Native files that cannot be embedded (if any) are extracted to a temp folder on first start;
  there is nothing else to ship next to the .exe.

QUICK DEV RUN
  dotnet run -c Release

CONTROLS
  Arrow keys / WASD ... move (a turn is remembered until the next junction; reversing is instant)
  P or Esc ............ pause / resume
  Enter ............... start (title screen) / restart (game over)
  Esc on title screen . exit the game          Esc on game over ... back to the title screen
  M ................... sound on / off

RULES
  - 251 crumbs (10 pts) and 4 golden apples (50 pts) per level. Eat them all to clear the level.
  - Apples frighten the enemies (blue, flashing white in the last 2 s; a bar under the title shows the
    time left). Catching them scores 200 / 400 / 800 / 1600; eaten enemies fly home and come back out.
  - Touching a dangerous enemy costs a life (3 lives, +1 at 10000 points). After respawn Kolobok blinks and is
    invulnerable for 2.5 s; enemies are reset to their house.
  - Enemies: Fox - chases you; Wolf - aims 4 tiles ahead of you (interception); Bear - slow but relentless;
    Hare - fast and erratic. They alternate between scatter (corner) and chase phases.
  - Each level: enemies get faster, apples last shorter, enemies leave the house sooner.
  - Tunnel: row in the middle - leave one side and appear on the other.
  - Hi-score file: %LocalAppData%\KolobokReborn\highscore.txt

FILES
  Game.cs (rules/state, no drawing)   Maze.cs (level data, grid queries, BFS)
  Actors.cs (grid movement)           GhostAI.cs (enemy behaviour)
  Renderer.cs (all drawing)           Sprites.cs (characters and props)
  GameForm.cs (window, input, loop)   Sfx.cs (sounds)   Storage.cs (hi-score)
  Program.cs   KolobokReborn.csproj   build.bat   README.txt

VERIFICATION STATUS
  The source was written WITHOUT access to a .NET SDK, so it has NOT been compiled or run by its author.
  What WAS checked: the maze (every crumb reachable from the start, every tile reachable by the enemies,
  no dead ends) and a Python model of the movement/AI logic (no wall violations, all enemies leave the
  house and roam the whole maze). Please run build.bat; if the compiler reports errors, send them back.

(c) 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space
