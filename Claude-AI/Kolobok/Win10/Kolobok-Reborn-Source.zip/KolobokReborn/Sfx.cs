using System;
using System.Collections.Generic;
using System.IO;
using System.Media;

namespace KolobokReborn
{
    /// <summary>Synthesised sound effects (no files). All calls are guarded: no audio device = silent game.</summary>
    internal sealed class Sfx
    {
        private readonly Dictionary<string, SoundPlayer> players = new Dictionary<string, SoundPlayer>();
        public bool Muted;

        public Sfx()
        {
            // segment: (startHz, endHz, ms, wave 0=square 1=sine 2=noise, volume)
            Add("crumb1", MakeWav((700, 900, 35, 1, 0.35)));
            Add("crumb2", MakeWav((560, 760, 35, 1, 0.35)));
            Add("power", MakeWav((400, 1300, 260, 1, 0.40)));
            Add("eatghost", MakeWav((700, 1500, 90, 0, 0.22), (1500, 400, 140, 0, 0.22)));
            Add("die", MakeWav((800, 120, 1100, 0, 0.25)));
            Add("level", MakeWav((523, 523, 100, 1, 0.4), (659, 659, 100, 1, 0.4), (784, 784, 100, 1, 0.4), (1047, 1047, 300, 1, 0.4)));
            Add("over", MakeWav((330, 330, 200, 0, 0.25), (262, 262, 200, 0, 0.25), (196, 196, 200, 0, 0.25), (130, 130, 500, 0, 0.25)));
            Add("start", MakeWav((392, 392, 110, 1, 0.4), (523, 523, 110, 1, 0.4), (659, 659, 110, 1, 0.4), (784, 784, 260, 1, 0.4)));
        }

        public void Play(string name)
        {
            if (Muted) return;
            SoundPlayer p;
            if (players.TryGetValue(name, out p))
            {
                try { p.Play(); } catch { }
            }
        }

        private void Add(string name, byte[] wav)
        {
            try
            {
                var p = new SoundPlayer(new MemoryStream(wav));
                p.Load();
                players[name] = p;
            }
            catch { }
        }

        private static byte[] MakeWav(params (double f0, double f1, int ms, int wave, double vol)[] segs)
        {
            const int sr = 22050;
            var samples = new List<short>();
            var rnd = new Random(3);
            double phase = 0;

            foreach (var s in segs)
            {
                int n = sr * s.ms / 1000;
                for (int i = 0; i < n; i++)
                {
                    double t = (double)i / n;
                    double f = s.f0 + (s.f1 - s.f0) * t;
                    phase += 2 * Math.PI * f / sr;
                    double v;
                    switch (s.wave)
                    {
                        case 0: v = Math.Sin(phase) >= 0 ? 1.0 : -1.0; break;
                        case 1: v = Math.Sin(phase); break;
                        default: v = rnd.NextDouble() * 2 - 1; break;
                    }
                    double env = Math.Min(1.0, i / (sr * 0.004)) * (1.0 - t);
                    samples.Add((short)(v * env * s.vol * short.MaxValue));
                }
            }

            var ms2 = new MemoryStream();
            var w = new BinaryWriter(ms2);
            int dataLen = samples.Count * 2;
            w.Write(new[] { 'R', 'I', 'F', 'F' });
            w.Write(36 + dataLen);
            w.Write(new[] { 'W', 'A', 'V', 'E' });
            w.Write(new[] { 'f', 'm', 't', ' ' });
            w.Write(16);
            w.Write((short)1);
            w.Write((short)1);
            w.Write(sr);
            w.Write(sr * 2);
            w.Write((short)2);
            w.Write((short)16);
            w.Write(new[] { 'd', 'a', 't', 'a' });
            w.Write(dataLen);
            foreach (short sm in samples) w.Write(sm);
            w.Flush();
            return ms2.ToArray();
        }
    }
}
