using System;
using System.Collections.Generic;

namespace KolobokReborn
{
    internal enum GameState { Title, Ready, Playing, Paused, Dying, LevelClear, GameOver }

    internal sealed class Popup { public float X, Y, Life; public string Text; }

    /// <summary>Pure game logic (no drawing). Positions are in tile units.</summary>
    internal sealed class Game
    {
        // ---------- tuning ----------
        private const float PlayerSpeed = 6.0f;                       // tiles per second
        private static readonly float[] GhostBase = { 5.4f, 5.4f, 4.4f, 5.8f };   // Fox, Wolf, Bear (slow), Hare
        private static readonly float[] GhostRelease = { 0f, 3f, 6f, 9f };        // seconds before leaving the house
        private const float FrightenedSpeed = 3.0f, EatenSpeed = 11f, LeavingSpeed = 4.5f;
        private const int ExtraLifeScore = 10000;

        // ---------- state read by the renderer ----------
        public GameState State = GameState.Title;
        public readonly Maze Maze = new Maze();
        public readonly Actor Player = new Actor();
        public readonly Ghost[] Ghosts = new Ghost[4];
        public readonly List<Popup> Popups = new List<Popup>();
        public int Score, HiScore, Level = 1, Lives = 3;
        public float StateTimer, Time, FrightLeft, FrightTotal, Invuln, MouthT, RollAngle;
        public Action<string> Sound;

        private int wantDX, wantDY, chain, crumbToggle;
        private float releaseClock, modeTimer;
        private bool scatter = true, extraLifeGiven;
        private readonly Random rng = new Random();

        public Game()
        {
            HiScore = HighScoreStore.Load();
            for (int i = 0; i < 4; i++)
            {
                var g = new Ghost { Kind = i, BaseSpeed = GhostBase[i] };
                Ghost captured = g;
                g.DecideFn = a => GhostAI.Choose(captured, Maze, Player, scatter, rng);
                Ghosts[i] = g;
            }
            ResetActors();
        }

        // =====================================================================
        //  Flow control
        // =====================================================================
        public void StartNewGame()
        {
            Score = 0; Level = 1; Lives = 3; extraLifeGiven = false;
            Maze.Reset();
            ResetActors();
            Time = 0;
            State = GameState.Ready;
            StateTimer = 2.4f;
            Sound?.Invoke("start");
        }

        private void NextLevel()
        {
            Level++;
            Maze.Reset();
            ResetActors();
            State = GameState.Ready;
            StateTimer = 2.0f;
            Sound?.Invoke("start");
        }

        public void GoTitle()
        {
            SaveHi();
            State = GameState.Title;
        }

        public void TogglePause()
        {
            if (State == GameState.Playing) State = GameState.Paused;
            else if (State == GameState.Paused) State = GameState.Playing;
        }

        public void SaveHi()
        {
            if (Score > HiScore) HiScore = Score;
            HighScoreStore.Save(HiScore);
        }

        private void ResetActors()
        {
            Player.Place(Maze.StartX, Maze.StartY);
            Player.FaceX = -1; Player.FaceY = 0;
            wantDX = 0; wantDY = 0;
            float rel = Math.Max(0.4f, 1f - 0.12f * (Level - 1));
            for (int i = 0; i < 4; i++)
            {
                var g = Ghosts[i];
                g.Place(Maze.GhostStartX[i], Maze.GhostStartY[i]);
                g.FaceX = 0; g.FaceY = 1;
                g.Mode = GhostMode.InHouse;
                g.Frightened = false;
                g.ReleaseAt = GhostRelease[i] * rel;
            }
            FrightLeft = 0; Invuln = 0; releaseClock = 0; modeTimer = 0; scatter = true; chain = 0;
            Popups.Clear();
        }

        /// <summary>Queue a turn. Reversing is instant; other turns happen at the next junction.</summary>
        public void SetDirection(int dx, int dy)
        {
            if (State != GameState.Playing && State != GameState.Ready) return;
            wantDX = dx; wantDY = dy;
            if (State == GameState.Playing && Player.Moving && dx == -Player.DX && dy == -Player.DY)
                Player.Reverse();
        }

        // =====================================================================
        //  Update
        // =====================================================================
        public void Update(float dt)
        {
            switch (State)
            {
                case GameState.Title:
                case GameState.GameOver:
                    Time += dt;
                    break;
                case GameState.Ready:
                    Time += dt;
                    StateTimer -= dt;
                    if (StateTimer <= 0f) { State = GameState.Playing; Invuln = 2.5f; }
                    break;
                case GameState.Playing:
                    UpdatePlaying(dt);
                    break;
                case GameState.Dying:
                    Time += dt;
                    UpdatePopups(dt);
                    StateTimer -= dt;
                    if (StateTimer <= 0f)
                    {
                        if (Lives <= 0)
                        {
                            State = GameState.GameOver;
                            SaveHi();
                            Sound?.Invoke("over");
                        }
                        else
                        {
                            ResetActors();
                            State = GameState.Ready;
                            StateTimer = 1.6f;
                        }
                    }
                    break;
                case GameState.LevelClear:
                    Time += dt;
                    StateTimer -= dt;
                    if (StateTimer <= 0f) NextLevel();
                    break;
            }
        }

        private void UpdatePopups(float dt)
        {
            foreach (var p in Popups) p.Life -= dt;
            Popups.RemoveAll(p => p.Life <= 0f);
        }

        private void UpdatePlaying(float dt)
        {
            Time += dt;
            UpdatePopups(dt);
            if (Invuln > 0f) Invuln -= dt;

            // enemy release from the house
            releaseClock += dt;
            foreach (var g in Ghosts)
                if (g.Mode == GhostMode.InHouse && releaseClock >= g.ReleaseAt) g.Mode = GhostMode.Leaving;

            // frightened countdown, or scatter/chase cycle
            if (FrightLeft > 0f)
            {
                FrightLeft -= dt;
                if (FrightLeft <= 0f) EndFright();
            }
            else
            {
                modeTimer += dt;
                float limit = scatter ? Math.Max(2.5f, 6f - 0.6f * (Level - 1)) : Math.Min(40f, 20f + 3f * (Level - 1));
                if (modeTimer >= limit) { modeTimer = 0f; scatter = !scatter; }
            }

            MovePlayer(dt);
            foreach (var g in Ghosts) MoveGhost(g, dt);

            CheckCollisions();
            if (State != GameState.Playing) return;

            if (Maze.DotsLeft <= 0)
            {
                State = GameState.LevelClear;
                StateTimer = 2.2f;
                FrightLeft = 0f;
                Sound?.Invoke("level");
            }
        }

        // ---------- Kolobok ----------
        private void PlayerDecide(Actor a)
        {
            if ((wantDX != 0 || wantDY != 0) && Maze.Open(a.TX + wantDX, a.TY + wantDY, false, false))
            {
                a.DX = wantDX; a.DY = wantDY;
            }
            else if (a.Moving && !Maze.Open(a.TX + a.DX, a.TY + a.DY, false, false))
            {
                a.DX = 0; a.DY = 0;      // wall ahead: stop
            }
        }

        private void MovePlayer(float dt)
        {
            Player.Step(PlayerSpeed * dt, PlayerDecide);
            if (Player.Moving)
            {
                MouthT += dt * 14f;
                RollAngle += 131f * PlayerSpeed * dt;
            }

            int cx = (int)Math.Round(Player.X), cy = (int)Math.Round(Player.Y);
            char c = Maze.Eat(cx, cy);
            if (c == '.')
            {
                AddScore(10);
                crumbToggle ^= 1;
                Sound?.Invoke(crumbToggle == 0 ? "crumb1" : "crumb2");
            }
            else if (c == 'o')
            {
                AddScore(50);
                StartFright();
                Sound?.Invoke("power");
            }
        }

        private void AddScore(int n)
        {
            Score += n;
            if (Score > HiScore) HiScore = Score;
            if (!extraLifeGiven && Score >= ExtraLifeScore) { extraLifeGiven = true; Lives++; }
        }

        // ---------- power-up ----------
        private void StartFright()
        {
            FrightTotal = Math.Max(3f, 8f - 0.8f * (Level - 1));
            FrightLeft = FrightTotal;
            chain = 0;
            foreach (var g in Ghosts)
            {
                if (g.Mode == GhostMode.Eaten) continue;
                g.Frightened = true;
                if (g.Mode == GhostMode.Active) g.Reverse();    // run away
            }
        }

        private void EndFright()
        {
            foreach (var g in Ghosts) g.Frightened = false;
        }

        // ---------- enemies ----------
        private float GhostSpeed(Ghost g)
        {
            float mul = Math.Min(1.3f, 1f + 0.04f * (Level - 1));
            if (g.Mode == GhostMode.Eaten) return EatenSpeed;
            if (g.Mode == GhostMode.Leaving) return LeavingSpeed;
            if (g.Frightened) return FrightenedSpeed;
            return g.BaseSpeed * mul;
        }

        private void MoveGhost(Ghost g, float dt)
        {
            if (g.Mode == GhostMode.InHouse) return;
            g.Step(GhostSpeed(g) * dt, g.DecideFn);
        }

        private void CheckCollisions()
        {
            foreach (var g in Ghosts)
            {
                if (g.Mode == GhostMode.InHouse || g.Mode == GhostMode.Eaten) continue;
                float dx = g.X - Player.X, dy = g.Y - Player.Y;
                if (dx * dx + dy * dy >= 0.36f) continue;

                if (g.Frightened)
                {
                    g.Mode = GhostMode.Eaten;
                    g.Frightened = false;
                    int pts = 200 << Math.Min(chain, 3);
                    chain++;
                    AddScore(pts);
                    Popups.Add(new Popup { X = g.X, Y = g.Y, Life = 1.0f, Text = pts.ToString() });
                    Sound?.Invoke("eatghost");
                }
                else if (Invuln <= 0f)
                {
                    Die();
                    return;
                }
            }
        }

        private void Die()
        {
            State = GameState.Dying;
            StateTimer = 1.6f;
            Lives--;
            FrightLeft = 0f;
            EndFright();
            Sound?.Invoke("die");
        }
    }
}
