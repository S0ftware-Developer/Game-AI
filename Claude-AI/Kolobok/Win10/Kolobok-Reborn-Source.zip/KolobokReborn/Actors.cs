using System;

namespace KolobokReborn
{
    /// <summary>
    /// Grid mover. The actor is on tile (TX,TY) and travels towards (TX+DX, TY+DY); Prog is 0..1 progress.
    /// Direction decisions are made only when a tile centre is reached, so actors can never leave corridors.
    /// </summary>
    internal class Actor
    {
        public int TX, TY, DX, DY, FaceX = -1, FaceY;
        public float Prog;

        public float X { get { return TX + DX * Prog; } }
        public float Y { get { return TY + DY * Prog; } }
        public bool Moving { get { return DX != 0 || DY != 0; } }

        public void Place(int x, int y)
        {
            TX = x; TY = y; DX = 0; DY = 0; Prog = 0f;
        }

        /// <summary>Turn around in place (swaps the source and destination tiles).</summary>
        public void Reverse()
        {
            if (!Moving) return;
            TX += DX; TY += DY;
            Prog = 1f - Prog;
            DX = -DX; DY = -DY;
            FaceX = DX; FaceY = DY;
        }

        /// <summary>Advance by dist tiles. decide() is called on arrival at every tile centre (and when idle).</summary>
        public void Step(float dist, Action<Actor> decide)
        {
            int guard = 0;
            while (dist > 0f && guard++ < 6)
            {
                if (!Moving)
                {
                    decide(this);
                    if (!Moving) return;
                    FaceX = DX; FaceY = DY;
                }
                float need = 1f - Prog;
                if (dist < need) { Prog += dist; return; }
                dist -= need;
                TX += DX; TY += DY; Prog = 0f;

                // tunnel: leave one side, re-enter from the other
                if (TX == -1 && DX < 0) TX = Maze.W;
                else if (TX == Maze.W && DX > 0) TX = -1;

                decide(this);
                if (Moving) { FaceX = DX; FaceY = DY; }
            }
        }
    }

    internal enum GhostMode { InHouse, Leaving, Active, Eaten }

    /// <summary>One of the four forest animals. Kind: 0 Fox, 1 Wolf, 2 Bear, 3 Hare.</summary>
    internal sealed class Ghost : Actor
    {
        public int Kind;
        public GhostMode Mode = GhostMode.InHouse;
        public bool Frightened;
        public float ReleaseAt;
        public float BaseSpeed;
        public Action<Actor> DecideFn;
    }
}
