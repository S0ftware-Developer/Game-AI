using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Windows.Forms;

namespace KolobokReborn
{
    /// <summary>Window, input and the fixed-timestep loop. No gameplay rules live here.</summary>
    internal sealed class GameForm : Form
    {
        private const int FooterH = 30;
        private const float StepDt = 1f / 120f;

        private readonly Game game = new Game();
        private readonly Sfx sfx = new Sfx();
        private readonly Renderer renderer = new Renderer();
        private readonly Bitmap frame = new Bitmap(Renderer.LW, Renderer.LH, PixelFormat.Format32bppPArgb);
        private readonly Graphics fg;
        private readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        private Rectangle gameRect;
        private readonly Stopwatch clock = Stopwatch.StartNew();
        private double lastTime, acc;

        public GameForm()
        {
            Text = "Kolobok Reborn";
            DoubleBuffered = true;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.Black;
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(640, 460);

            var wa = Screen.PrimaryScreen.WorkingArea;
            float s = Math.Min(1f, Math.Min((wa.Width - 40) / (float)Renderer.LW,
                (wa.Height - 100 - FooterH) / (float)Renderer.LH));
            ClientSize = new Size((int)(Renderer.LW * s), (int)(Renderer.LH * s) + FooterH);

            fg = Graphics.FromImage(frame);
            fg.InterpolationMode = InterpolationMode.NearestNeighbor;
            fg.PixelOffsetMode = PixelOffsetMode.Half;
            fg.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;

            game.Sound = name => sfx.Play(name);
            RecalcLayout();

            timer.Interval = 8;
            timer.Tick += (o, e) => Tick();
            timer.Start();
            lastTime = clock.Elapsed.TotalSeconds;
        }

        private void RecalcLayout()
        {
            int availW = Math.Max(1, ClientSize.Width);
            int availH = Math.Max(1, ClientSize.Height - FooterH);
            float s = Math.Min(availW / (float)Renderer.LW, availH / (float)Renderer.LH);
            int w = Math.Max(1, (int)(Renderer.LW * s));
            int h = Math.Max(1, (int)(Renderer.LH * s));
            gameRect = new Rectangle((availW - w) / 2, (availH - h) / 2, w, h);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            RecalcLayout();
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        private void Tick()
        {
            double now = clock.Elapsed.TotalSeconds;
            double dt = now - lastTime;
            lastTime = now;
            if (dt > 0.1) dt = 0.1;
            acc += dt;
            while (acc >= StepDt)
            {
                game.Update(StepDt);
                acc -= StepDt;
            }
            Invalidate();
        }

        // ---------- input ----------
        protected override void OnKeyDown(KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.A: game.SetDirection(-1, 0); break;
                case Keys.Right:
                case Keys.D: game.SetDirection(1, 0); break;
                case Keys.Up:
                case Keys.W: game.SetDirection(0, -1); break;
                case Keys.Down:
                case Keys.S: game.SetDirection(0, 1); break;
                case Keys.Enter:
                    if (game.State == GameState.Title || game.State == GameState.GameOver) game.StartNewGame();
                    break;
                case Keys.P: game.TogglePause(); break;
                case Keys.M: sfx.Muted = !sfx.Muted; break;
                case Keys.Escape:
                    switch (game.State)
                    {
                        case GameState.Title: Close(); break;
                        case GameState.Playing:
                        case GameState.Paused: game.TogglePause(); break;
                        case GameState.GameOver: game.GoTitle(); break;
                    }
                    break;
            }
            e.SuppressKeyPress = true;
            base.OnKeyDown(e);
        }

        protected override void OnDeactivate(EventArgs e)
        {
            base.OnDeactivate(e);
            if (game.State == GameState.Playing) game.TogglePause();   // auto-pause on focus loss
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            game.SaveHi();
            base.OnFormClosing(e);
        }

        // ---------- painting ----------
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Color.Black);

            renderer.Render(fg, game, sfx.Muted);

            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.DrawImage(frame, gameRect, 0, 0, Renderer.LW, Renderer.LH, GraphicsUnit.Pixel);

            DrawFooter(g);
        }

        private void DrawFooter(Graphics g)
        {
            int cw = ClientSize.Width;
            int top = ClientSize.Height - FooterH;
            using (var b = new SolidBrush(Color.FromArgb(10, 14, 12))) g.FillRectangle(b, 0, top, cw, FooterH);
            using (var pen = new Pen(Color.FromArgb(255, 204, 30), 2)) g.DrawLine(pen, 0, top, cw, top);

            string a = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: ";
            string c = "orlovandrei.space";

            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            var fmt = StringFormat.GenericTypographic;
            float size = 14f;
            Font f = null;
            float wa = 0, wc = 0;
            while (true)
            {
                if (f != null) f.Dispose();
                f = new Font("Consolas", size, FontStyle.Regular, GraphicsUnit.Pixel);
                wa = g.MeasureString(a, f, 2000, fmt).Width;
                wc = g.MeasureString(c, f, 2000, fmt).Width;
                if (wa + wc <= cw - 12 || size <= 7f) break;
                size -= 0.5f;
            }
            float x = (cw - (wa + wc)) / 2f;
            float y = top + (FooterH - f.Height) / 2f;
            using (var b1 = new SolidBrush(Color.FromArgb(235, 235, 235))) g.DrawString(a, f, b1, x, y, fmt);
            using (var b2 = new SolidBrush(Color.FromArgb(110, 235, 60))) g.DrawString(c, f, b2, x + wa, y, fmt);
            f.Dispose();
        }
    }
}
