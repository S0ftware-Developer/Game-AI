using System.Media;

namespace BarioBrosers;

/// <summary>Synthesised sound effects (no files). Every call is guarded: no audio device = silent game.</summary>
internal sealed class Sfx : IDisposable
{
    private readonly Dictionary<string, SoundPlayer> players = new();
    public bool Muted;

    public Sfx()
    {
        // segment: (startHz, endHz, ms, wave 0=square 1=sine 2=noise, volume)
        Add("jump", MakeWav((280, 620, 130, 0, 0.16)));
        Add("coin", MakeWav((988, 988, 60, 0, 0.16), (1319, 1319, 170, 0, 0.16)));
        Add("bump", MakeWav((150, 70, 90, 0, 0.3)));
        Add("stomp", MakeWav((520, 130, 110, 0, 0.22)));
        Add("lose", MakeWav((520, 520, 110, 0, 0.2), (440, 440, 110, 0, 0.2), (330, 330, 110, 0, 0.2), (200, 90, 420, 0, 0.2)));
        Add("win", MakeWav((523, 523, 100, 0, 0.18), (659, 659, 100, 0, 0.18), (784, 784, 100, 0, 0.18), (1047, 1047, 100, 0, 0.18),
            (784, 784, 100, 0, 0.18), (1047, 1047, 380, 0, 0.18)));
    }

    public void Play(string name)
    {
        if (Muted) return;
        if (players.TryGetValue(name, out var p))
        {
            try { p.Play(); } catch { /* audio unavailable - ignore */ }
        }
    }

    private void Add(string name, byte[] wav)
    {
        try
        {
            var p = new SoundPlayer(new MemoryStream(wav));
            p.Load();
            players[name] = p;
        }
        catch { /* audio unavailable - ignore */ }
    }

    public void Dispose()
    {
        foreach (var p in players.Values)
        {
            try { p.Stop(); p.Dispose(); } catch { }
        }
        players.Clear();
    }

    private static byte[] MakeWav(params (double f0, double f1, int ms, int wave, double vol)[] segs)
    {
        const int sr = 22050;
        var samples = new List<short>();
        var rnd = new Random(5);
        double phase = 0;

        foreach (var s in segs)
        {
            int n = sr * s.ms / 1000;
            for (int i = 0; i < n; i++)
            {
                double t = (double)i / n;
                double f = s.f0 + (s.f1 - s.f0) * t;
                phase += 2 * Math.PI * f / sr;
                double v = s.wave switch
                {
                    0 => Math.Sin(phase) >= 0 ? 1.0 : -1.0,
                    1 => Math.Sin(phase),
                    _ => rnd.NextDouble() * 2 - 1
                };
                double env = Math.Min(1.0, i / (sr * 0.003)) * (1.0 - 0.6 * t);
                samples.Add((short)(v * env * s.vol * short.MaxValue));
            }
        }

        var ms2 = new MemoryStream();
        var w = new BinaryWriter(ms2);
        int dataLen = samples.Count * 2;
        w.Write(new[] { 'R', 'I', 'F', 'F' });
        w.Write(36 + dataLen);
        w.Write(new[] { 'W', 'A', 'V', 'E' });
        w.Write(new[] { 'f', 'm', 't', ' ' });
        w.Write(16);
        w.Write((short)1);
        w.Write((short)1);
        w.Write(sr);
        w.Write(sr * 2);
        w.Write((short)2);
        w.Write((short)16);
        w.Write(new[] { 'd', 'a', 't', 'a' });
        w.Write(dataLen);
        foreach (short sm in samples) w.Write(sm);
        w.Flush();
        return ms2.ToArray();
    }
}
