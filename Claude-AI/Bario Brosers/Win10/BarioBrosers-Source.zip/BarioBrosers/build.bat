@echo off
rem Bario Brosers - standalone single-file Windows x64 publish.
rem Result: bin\Release\net8.0-windows\win-x64\publish\BarioBrosers.exe
setlocal
cd /d "%~dp0"

set "WINX64=bin\Release\net8.0-windows\win-x64"
set "PUB=%WINX64%\publish"
set "RC=0"

where dotnet >nul 2>&1
if errorlevel 1 (
  echo ERROR: .NET SDK not found. Install the .NET 8 SDK: https://dotnet.microsoft.com/download
  set "RC=1"
  goto finish
)

dotnet publish "%~dp0BarioBrosers.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishTrimmed=false
if errorlevel 1 (
  echo.
  echo ERROR: dotnet publish failed - see the messages above.
  set "RC=1"
  goto finish
)

if not exist "%PUB%\BarioBrosers.exe" (
  echo.
  echo ERROR: %PUB%\BarioBrosers.exe was not produced.
  set "RC=1"
  goto finish
)

rem --- publish succeeded: tidy up (sources are never touched) ---
rem 1) keep only the exe in the publish folder
for %%F in ("%PUB%\*") do if /i not "%%~nxF"=="BarioBrosers.exe" del /q "%%F" >nul 2>&1
rem 2) a self-contained build also leaves ~240 runtime files in %WINX64%\ (intermediate build output, not the game)
for %%F in ("%WINX64%\*") do del /q "%%F" >nul 2>&1
for /d %%D in ("%WINX64%\*") do if /i not "%%~nxD"=="publish" rmdir /s /q "%%D" >nul 2>&1

echo.
echo SUCCESS. Standalone game (copy only this file to another PC):
echo   %~dp0%PUB%\BarioBrosers.exe
for %%A in ("%PUB%\BarioBrosers.exe") do echo   size: %%~zA bytes
echo.
echo Files in the publish folder:
dir /b "%PUB%"

:finish
if not defined NOPAUSE pause
exit /b %RC%
