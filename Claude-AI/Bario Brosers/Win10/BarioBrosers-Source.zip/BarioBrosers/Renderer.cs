using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace BarioBrosers;

/// <summary>
/// Draws one frame into an 800 x 480 logical bitmap in a pixel-art style. Sprites are built once from the
/// 16x16 maps in SpriteData (2x scale); scenery (hills, clouds, flag, title) is drawn with pixel-sized rectangles.
/// </summary>
internal sealed class Renderer : IDisposable
{
    private const int T = Game.T;

    private sealed class Cloud { public float X, Y; }
    private sealed class Hill { public float X, W, H; public bool Near; }

    private readonly Dictionary<string, Bitmap> sprites = new();
    private readonly List<Cloud> clouds = new();
    private readonly List<Hill> hills = new();
    private readonly SolidBrush brush = new(Color.White);
    private readonly Pen polePen = new(Color.FromArgb(232, 236, 240), 6f);
    private readonly Font hudFont, bigFont, midFont, smallFont, titleFont;
    private readonly StringFormat center = new() { Alignment = StringAlignment.Center, FormatFlags = StringFormatFlags.NoWrap };
    private readonly StringFormat near = new() { Alignment = StringAlignment.Near, FormatFlags = StringFormatFlags.NoWrap };
    private readonly PointF[] tri = new PointF[3];
    private readonly PointF[] star = new PointF[10];
    private readonly Color[] sky = new Color[12];

    private static readonly string[] CloudShape =
    {
        "......XXXX......",
        "....XXXXXXXX....",
        "..XXXXXXXXXXXXX.",
        ".XXXXXXXXXXXXXXX",
        "XXXXXXXXXXXXXXXX",
        ".XXXXXXXXXXXXXX.",
    };

    public Renderer()
    {
        foreach (var kv in SpriteData.Maps)
        {
            var pal = new Dictionary<char, Color>();
            foreach (var p in SpriteData.Palettes[SpriteData.Group[kv.Key]]) pal[p.Key] = ColorTranslator.FromHtml(p.Value);
            sprites[kv.Key] = MakeSprite(kv.Value, pal, false);
            sprites[kv.Key + "_f"] = MakeSprite(kv.Value, pal, true);
        }

        string family = PickFamily("Arial Black", "Impact", "Arial");
        titleFont = MakeFont(family, 84, FontStyle.Bold);
        hudFont = MakeFont("Consolas", 18, FontStyle.Bold);
        smallFont = MakeFont("Consolas", 16, FontStyle.Bold);
        midFont = MakeFont("Consolas", 28, FontStyle.Bold);
        bigFont = MakeFont("Consolas", 52, FontStyle.Bold);

        var rnd = new Random(4);
        for (int i = 0; i < 40; i++) clouds.Add(new Cloud { X = i * 300 + rnd.Next(160), Y = 36 + rnd.Next(110) });
        for (int i = 0; i < 24; i++)
        {
            hills.Add(new Hill { X = i * 340 + rnd.Next(120), W = 220 + rnd.Next(120), H = 70 + rnd.Next(70), Near = false });
            hills.Add(new Hill { X = i * 280 + 90 + rnd.Next(100), W = 180 + rnd.Next(100), H = 50 + rnd.Next(50), Near = true });
        }
        for (int i = 0; i < sky.Length; i++)
        {
            float t = i / (float)(sky.Length - 1);
            sky[i] = Color.FromArgb((int)(60 + 110 * t), (int)(140 + 80 * t), (int)(245 + 10 * t));
        }
    }

    private static string PickFamily(params string[] names)
    {
        foreach (string n in names)
            foreach (var f in FontFamily.Families)
                if (string.Equals(f.Name, n, StringComparison.OrdinalIgnoreCase)) return n;
        return "Arial";
    }

    private static Font MakeFont(string family, float px, FontStyle style)
    {
        try { return new Font(family, px, style, GraphicsUnit.Pixel); }
        catch { return new Font("Arial", px, style, GraphicsUnit.Pixel); }
    }

    private static Bitmap MakeSprite(string[] map, Dictionary<char, Color> pal, bool flip)
    {
        var bmp = new Bitmap(32, 32, PixelFormat.Format32bppPArgb);
        using var g = Graphics.FromImage(bmp);
        using var b = new SolidBrush(Color.White);
        for (int y = 0; y < 16; y++)
            for (int x = 0; x < 16; x++)
            {
                char ch = map[y][x];
                if (ch == '.' || !pal.TryGetValue(ch, out var c)) continue;
                b.Color = c;
                g.FillRectangle(b, (flip ? 15 - x : x) * 2, y * 2, 2, 2);
            }
        return bmp;
    }

    public void Dispose()
    {
        foreach (var b in sprites.Values) b.Dispose();
        brush.Dispose(); polePen.Dispose();
        titleFont.Dispose(); hudFont.Dispose(); smallFont.Dispose(); midFont.Dispose(); bigFont.Dispose();
        center.Dispose(); near.Dispose();
    }

    // =====================================================================
    //  Helpers
    // =====================================================================
    private void Fill(Graphics g, Color c, float x, float y, float w, float h)
    {
        brush.Color = c;
        g.FillRectangle(brush, x, y, w, h);
    }

    private void Spr(Graphics g, string name, float x, float y, bool flip = false, float scale = 1f)
    {
        g.DrawImage(sprites[flip ? name + "_f" : name], x, y, 32f * scale, 32f * scale);
    }

    private void Text(Graphics g, string s, Font f, float x, float y, Color c, StringFormat fmt)
    {
        brush.Color = c;
        g.DrawString(s, f, brush, x, y, fmt);
    }

    private void Shadowed(Graphics g, string s, Font f, float x, float y, Color c, StringFormat fmt)
    {
        Text(g, s, f, x + 2, y + 2, Color.FromArgb(160, 20, 20, 40), fmt);
        Text(g, s, f, x, y, c, fmt);
    }

    private void Outlined(Graphics g, string s, Font f, float x, float y, Color fill, Color line, int th)
    {
        for (int dx = -th; dx <= th; dx += th)
            for (int dy = -th; dy <= th + 4; dy += th + 2)
                Text(g, s, f, x + dx, y + dy, line, center);
        Text(g, s, f, x, y, fill, center);
    }

    private void Star(Graphics g, float cx, float cy, float r)
    {
        for (int i = 0; i < 10; i++)
        {
            double a = -Math.PI / 2 + i * Math.PI / 5;
            float rr = i % 2 == 0 ? r : r * 0.45f;
            star[i] = new PointF(cx + (float)Math.Cos(a) * rr, cy + (float)Math.Sin(a) * rr);
        }
        brush.Color = Color.FromArgb(40, 30, 10);
        g.FillPolygon(brush, star);
        for (int i = 0; i < 10; i++) { star[i].X = cx + (star[i].X - cx) * 0.8f; star[i].Y = cy + (star[i].Y - cy) * 0.8f; }
        brush.Color = Color.FromArgb(255, 214, 50);
        g.FillPolygon(brush, star);
    }

    // =====================================================================
    //  Scenery
    // =====================================================================
    private void DrawSky(Graphics g)
    {
        float h = Game.ViewH / (float)sky.Length;
        for (int i = 0; i < sky.Length; i++) Fill(g, sky[i], 0, i * h, Game.ViewW, h + 1f);
    }

    private void DrawClouds(Graphics g, float cam)
    {
        foreach (var c in clouds)
        {
            float x = c.X - cam * 0.2f;
            if (x < -100f || x > Game.ViewW + 20f) continue;
            for (int r = 0; r < CloudShape.Length; r++)
                for (int k = 0; k < 16; k++)
                    if (CloudShape[r][k] == 'X')
                        Fill(g, r == CloudShape.Length - 1 ? Color.FromArgb(205, 226, 252) : Color.White, x + k * 5, c.Y + r * 5, 5, 5);
        }
    }

    private void DrawHills(Graphics g, float cam)
    {
        const float baseY = 13 * T;
        foreach (var layer in new[] { false, true })
        {
            float par = layer ? 0.55f : 0.35f;
            Color c1 = layer ? Color.FromArgb(78, 172, 86) : Color.FromArgb(124, 204, 132);
            Color c2 = layer ? Color.FromArgb(60, 146, 70) : Color.FromArgb(100, 180, 112);
            foreach (var h in hills)
            {
                if (h.Near != layer) continue;
                float cx = h.X - cam * par;
                if (cx + h.W / 2f < 0f || cx - h.W / 2f > Game.ViewW) continue;
                for (float v = h.H - 2f, y = baseY - h.H; v > 0f; v -= 4f, y += 4f)
                {
                    float k = v / h.H;
                    float hw = h.W / 2f * (float)Math.Sqrt(Math.Max(0f, 1f - k * k));
                    Fill(g, c1, cx - hw, y, hw * 2f, 4f);
                    if (((int)(y / 4f) & 3) == 1) Fill(g, c2, cx - hw * 0.5f, y, hw * 0.3f, 4f);     // darker patches
                }
            }
        }
    }

    // =====================================================================
    //  Frame
    // =====================================================================
    public void Render(Graphics g, Game game, bool muted)
    {
        if (game.State == GameState.Title)
        {
            DrawTitle(g, game);
            return;
        }

        int cam = (int)Math.Round(game.CamX);
        DrawSky(g);
        DrawClouds(g, cam);
        DrawHills(g, cam);
        DrawTiles(g, game, cam);
        DrawCheckpoint(g, game, cam);
        DrawFlag(g, game, cam);
        DrawCoins(g, game, cam);
        DrawEnemies(g, game, cam);
        DrawPlayer(g, game, cam);
        DrawEffects(g, game, cam);
        DrawHud(g, game, muted);

        switch (game.State)
        {
            case GameState.Paused: DrawPaused(g); break;
            case GameState.GameOver: DrawGameOver(g); break;
            case GameState.Win: DrawWin(g, game); break;
        }
    }

    private static string TileSprite(char t, float time)
    {
        switch (t)
        {
            case 'G': return "grass";
            case 'D': return "dirt";
            case 'B': return "brick";
            case '?': return ((int)(time * 2.5f) & 1) == 0 ? "quest1" : "quest2";
            case 'U': return "used";
            case 'S': return "stone";
            case 'a': return "pipe_tl";
            case 'b': return "pipe_tr";
            case 'c': return "pipe_bl";
            case 'd': return "pipe_br";
            default: return "";
        }
    }

    private void DrawTiles(Graphics g, Game game, int cam)
    {
        int c0 = Math.Max(0, cam / T), c1 = Math.Min(game.Cols - 1, (cam + Game.ViewW) / T);
        for (int r = 0; r < Game.Rows; r++)
            for (int c = c0; c <= c1; c++)
            {
                string name = TileSprite(game.Tiles[r, c], game.Time);
                if (name.Length == 0) continue;
                float dy = 0f;
                foreach (var b in game.Bumps)                                  // a hit block hops up a little
                    if (b.C == c && b.R == r) dy = -(float)Math.Sin(b.T / 0.2f * Math.PI) * 9f;
                Spr(g, name, c * T - cam, r * T + dy);
            }
    }

    private void DrawCheckpoint(Graphics g, Game game, int cam)
    {
        float x = 75 * T + T / 2f - cam;
        if (x < -40f || x > Game.ViewW + 40f) return;
        Fill(g, Color.FromArgb(110, 70, 30), x - 2, 13 * T - 52, 4, 52);
        tri[0] = new PointF(x + 2, 13 * T - 52);
        tri[1] = new PointF(x + 26, 13 * T - 42);
        tri[2] = new PointF(x + 2, 13 * T - 32);
        brush.Color = game.CheckpointReached ? Color.FromArgb(60, 200, 90) : Color.FromArgb(225, 70, 60);
        g.FillPolygon(brush, tri);
    }

    private void DrawFlag(Graphics g, Game game, int cam)
    {
        float x = game.FlagX - cam;
        if (x < -60f || x > Game.ViewW + 60f) return;
        float top = 3 * T + 4, bottom = 13 * T;
        g.DrawLine(polePen, x, top, x, bottom);
        Fill(g, Color.FromArgb(170, 176, 190), x + 1, top, 2, bottom - top);
        Fill(g, Color.FromArgb(40, 30, 10), x - 9, top - 14, 18, 18);
        Fill(g, Color.FromArgb(255, 214, 50), x - 7, top - 12, 14, 14);
        float slide = game.Won ? Math.Min(1f, game.WinT / 1.3f) : 0f;
        float y0 = top + 14 + slide * (bottom - top - 70);
        tri[0] = new PointF(x - 2, y0);
        tri[1] = new PointF(x - 44, y0 + 16);
        tri[2] = new PointF(x - 2, y0 + 32);
        brush.Color = Color.FromArgb(30, 110, 60);
        g.FillPolygon(brush, tri);
        tri[0].X += 2; tri[1].X += 4; tri[2].X += 2; tri[0].Y += 2; tri[1].Y += 2; tri[2].Y -= 2;
        brush.Color = Color.FromArgb(70, 215, 100);
        g.FillPolygon(brush, tri);
    }

    private void DrawCoins(Graphics g, Game game, int cam)
    {
        int[] widths = { 30, 22, 10, 22 };
        int frame = (int)(game.Time * 8f) & 3;
        foreach (var c in game.CoinList)
        {
            if (c.Taken) continue;
            float x = c.X - cam;
            if (x < -20f || x > Game.ViewW + 20f) continue;
            float w = widths[frame];
            g.DrawImage(sprites["coin"], x - w / 2f, c.Y - 16f, w, 32f);
        }
    }

    private void DrawEnemies(Graphics g, Game game, int cam)
    {
        foreach (var e in game.Enemies)
        {
            float x = e.X - cam;
            if (x < -40f || x > Game.ViewW + 40f) continue;
            string baseName = e.Kind == 0 ? "slime" : "beetle";
            if (e.Dead) { Spr(g, baseName + "_flat", x - 4f, e.Y + e.H - 32f, e.Dir > 0); continue; }
            string name = baseName + (((int)(e.Anim * 4f) & 1) == 0 ? "1" : "2");
            Spr(g, name, x - 4f, e.Y + e.H - 30f, e.Kind == 1 && e.Dir > 0);
        }
    }

    private void DrawPlayer(Graphics g, Game game, int cam)
    {
        var p = game.P;
        if (p.Invuln > 0f && (((int)(game.Time * 16f)) & 1) == 0) return;      // blinks while protected
        string name;
        if (game.Won && p.Y + p.H < 13 * T) name = "hero_jump";
        else if (game.Dead || !p.OnGround) name = "hero_jump";
        else if (Math.Abs(p.VX) < 8f && !game.Won) name = "hero_idle";
        else name = ((int)p.Anim & 1) == 0 ? "hero_run1" : "hero_run2";
        Spr(g, name, p.X - 6f - cam, p.Y + p.H - 32f, p.Facing < 0);
    }

    private void DrawEffects(Graphics g, Game game, int cam)
    {
        foreach (var d in game.Debris)
            g.DrawImage(sprites["brick"], d.X - cam - 7f, d.Y - 7f, 14f, 14f);

        foreach (var p in game.Popups)
        {
            float k = p.T / 0.7f;
            if (p.IsCoin)
            {
                float w = 30f * Math.Abs((float)Math.Cos(p.T * 24f));
                g.DrawImage(sprites["coin"], p.X - cam - w / 2f, p.Y - 20f - (float)Math.Sin(Math.Min(1f, k * 1.4f) * Math.PI / 2) * 56f, w + 2f, 32f);
            }
            else Shadowed(g, p.Text, smallFont, p.X - cam, p.Y - 10f - k * 30f, Color.White, center);
        }
    }

    // =====================================================================
    //  HUD and screens
    // =====================================================================
    private void DrawHud(Graphics g, Game game, bool muted)
    {
        Color label = Color.FromArgb(255, 250, 200);
        Shadowed(g, "SCORE", hudFont, 24, 6, label, near);
        Shadowed(g, game.Score.ToString("D6"), hudFont, 24, 26, Color.White, near);

        Shadowed(g, "COINS", hudFont, 230, 6, label, near);
        g.DrawImage(sprites["coin"], 226f, 22f, 26f, 26f);
        Shadowed(g, "x " + game.Coins.ToString("D2"), hudFont, 256, 26, Color.White, near);

        Shadowed(g, "LEVEL", hudFont, 440, 6, label, near);
        Shadowed(g, "1", hudFont, 440, 26, Color.White, near);

        Shadowed(g, "LIVES", hudFont, 600, 6, label, near);
        g.DrawImage(sprites["hero_idle"], 594f, 20f, 28f, 28f);
        Shadowed(g, "x " + Math.Max(0, game.Lives), hudFont, 628, 26, Color.White, near);

        if (muted) Shadowed(g, "MUTE", smallFont, 730, 26, Color.FromArgb(255, 150, 150), near);
    }

    private void Dim(Graphics g, int a)
    {
        Fill(g, Color.FromArgb(a, 10, 14, 40), 0, 0, Game.ViewW, Game.ViewH);
    }

    private void DrawPaused(Graphics g)
    {
        Dim(g, 130);
        Outlined(g, "PAUSED", bigFont, 400, 170, Color.White, Color.FromArgb(30, 30, 60), 3);
        Text(g, "press ESC to continue", midFont, 400, 250, Color.FromArgb(255, 240, 160), center);
    }

    private void DrawGameOver(Graphics g)
    {
        Dim(g, 170);
        Outlined(g, "GAME OVER", bigFont, 400, 150, Color.FromArgb(255, 90, 70), Color.FromArgb(50, 10, 10), 3);
        Text(g, "press R to try again", midFont, 400, 250, Color.FromArgb(255, 240, 160), center);
    }

    private void DrawWin(Graphics g, Game game)
    {
        Dim(g, 150);
        Outlined(g, "LEVEL COMPLETE!", bigFont, 400, 90, Color.FromArgb(255, 220, 60), Color.FromArgb(70, 40, 10), 3);
        Text(g, "SCORE  " + game.Score.ToString("D6"), midFont, 400, 200, Color.White, center);
        Text(g, "COINS  " + game.Coins, midFont, 400, 240, Color.White, center);
        Text(g, "press R to play again", midFont, 400, 320, Color.FromArgb(255, 240, 160), center);
    }

    // ---------- title screen ----------
    private void DrawTitle(Graphics g, Game game)
    {
        float t = game.Time;
        DrawSky(g);
        DrawClouds(g, t * 12f);
        DrawHills(g, t * 20f);

        // ground strip, pipe, blocks, coins, walking enemies and the jumping hero
        for (int c = 0; c < 25; c++)
        {
            Spr(g, "grass", c * T, 13 * T);
            Spr(g, "dirt", c * T, 14 * T);
        }
        Spr(g, "pipe_tl", 5 * T, 11 * T); Spr(g, "pipe_tr", 6 * T, 11 * T);
        Spr(g, "pipe_bl", 5 * T, 12 * T); Spr(g, "pipe_br", 6 * T, 12 * T);
        Spr(g, "pipe_tl", 19 * T, 10 * T); Spr(g, "pipe_tr", 20 * T, 10 * T);
        for (int r = 11; r < 13; r++) { Spr(g, "pipe_bl", 19 * T, r * T); Spr(g, "pipe_br", 20 * T, r * T); }
        Spr(g, "pipe_bl", 19 * T, 12 * T);
        Spr(g, "brick", 9 * T, 9 * T); Spr(g, "quest1", 10 * T, 9 * T); Spr(g, "brick", 11 * T, 9 * T);
        Spr(g, "quest2", 14 * T, 9 * T);
        for (int i = 0; i < 4; i++) g.DrawImage(sprites["coin"], 7 * T + i * 36 + 4, 8 * T + 6, 26f - 8 * (float)Math.Abs(Math.Sin(t * 5 + i)), 32f);

        float ex = 2 * T + (float)(Math.Sin(t * 0.8) * 1.0 + 1.0) * 40;
        Spr(g, ((int)(t * 4) & 1) == 0 ? "slime1" : "slime2", ex, 13 * T - 30);
        Spr(g, ((int)(t * 4) & 1) == 0 ? "beetle1" : "beetle2", 15 * T + (float)Math.Sin(t) * 40, 13 * T - 30, Math.Cos(t) > 0);
        Spr(g, ((int)(t * 4) & 1) == 0 ? "slime1" : "slime2", 22 * T - (float)(Math.Sin(t * 0.7) + 1.0) * 30, 13 * T - 30);

        float hop = (float)Math.Abs(Math.Sin(t * 2.4));
        Spr(g, "hero_jump", 400 - 48f, 270f - hop * 40f, false, 3f);

        // title
        Star(g, 120, 100, 26); Star(g, 400, 48, 22); Star(g, 680, 100, 26);
        Outlined(g, "BARIO", titleFont, 400, 22, Color.FromArgb(240, 62, 40), Color.FromArgb(40, 20, 10), 4);
        Outlined(g, "BROSERS", titleFont, 400, 112, Color.FromArgb(255, 206, 40), Color.FromArgb(60, 30, 10), 4);

        if (((int)(t * 2.2f) & 1) == 0)
            Outlined(g, "PRESS ENTER TO START", midFont, 400, 400, Color.FromArgb(255, 222, 70), Color.FromArgb(20, 30, 90), 2);
        Text(g, "A/D or arrows: move    SPACE: jump    ESC: pause    R: restart", smallFont, 400, 446, Color.White, center);
    }
}
