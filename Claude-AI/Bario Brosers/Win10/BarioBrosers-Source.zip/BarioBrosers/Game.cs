namespace BarioBrosers;

internal enum GameState { Title, Playing, Paused, GameOver, Win }

/// <summary>Axis-aligned box that moves through the tile grid (top-left corner + size, pixels).</summary>
internal class Body
{
    public float X, Y, W, H, VX, VY;
    public bool OnGround, HitWall;
}

internal sealed class Player : Body
{
    public int Facing = 1;
    public float Anim, Invuln;
}

internal sealed class Enemy : Body
{
    public int Kind;                   // 0 slime, 1 beetle
    public int Dir = -1;
    public bool Dead;
    public float DeadT, Anim;
}

internal sealed class Coin { public float X, Y; public bool Taken; }
internal sealed class Debris { public float X, Y, VX, VY, Life; }
internal sealed class Bump { public int C, R; public float T; }
internal sealed class Popup { public float X, Y, T; public string Text = ""; public bool IsCoin; }

/// <summary>
/// All game rules: one hand-made level, tile collisions, hero, enemies, coins, blocks, lives and score.
/// No drawing here. World units are pixels; one tile = 32 px; the view is 25 x 15 tiles.
/// </summary>
internal sealed class Game
{
    public const int T = 32, Rows = 15, ViewW = 800, ViewH = 480;

    private const float Gravity = 2200f, MaxFall = 900f;
    private const float WalkAccel = 1800f, Friction = 1600f, MaxSpeed = 235f;
    private const float JumpV = 820f, JumpCut = 320f;
    private const float Coyote = 0.09f, JumpBuffer = 0.1f;
    private const int CheckpointCol = 75;

    // ---------- state read by the renderer ----------
    public GameState State = GameState.Title;
    public int Cols;
    public char[,] Tiles = new char[Rows, 1];
    public int Score, Coins, Lives = 3;
    public float Time, CamX, WinT, DeadT;
    public bool Won, CheckpointReached;
    public int FlagCol;
    public readonly Player P = new() { W = 20, H = 30 };
    public readonly List<Enemy> Enemies = new();
    public readonly List<Coin> CoinList = new();
    public readonly List<Debris> Debris = new();
    public readonly List<Bump> Bumps = new();
    public readonly List<Popup> Popups = new();
    public Action<string>? Sound;

    public bool Dead { get { return deadFlag; } }
    public float FlagX { get { return FlagCol * T + T / 2f; } }

    // ---------- input (set by the window) ----------
    public bool Left, Right, JumpHeld;

    private bool deadFlag;
    private float jumpBuf, coyoteT, prevBottom, startX, startY;

    public Game() { LoadLevel(); }

    // =====================================================================
    //  Level and flow
    // =====================================================================
    private void LoadLevel()
    {
        string[] rows = LevelData.Rows;
        Cols = rows[0].Length;
        Tiles = new char[Rows, Cols];
        Enemies.Clear(); CoinList.Clear(); Debris.Clear(); Bumps.Clear(); Popups.Clear();
        for (int r = 0; r < Rows; r++)
            for (int c = 0; c < Cols; c++)
            {
                char ch = rows[r][c];
                char tile = ch;
                switch (ch)
                {
                    case 'o': CoinList.Add(new Coin { X = c * T + T / 2f, Y = r * T + T / 2f }); tile = '.'; break;
                    case 'e':
                    case 'f':
                        Enemies.Add(new Enemy { Kind = ch == 'e' ? 0 : 1, W = 24, H = 24, X = c * T + 4, Y = (r + 1) * T - 24, Dir = -1 });
                        tile = '.';
                        break;
                    case 'M': startX = c * T + (T - P.W) / 2f; startY = (r + 1) * T - P.H; tile = '.'; break;
                    case 'F': FlagCol = c; tile = '.'; break;
                }
                Tiles[r, c] = tile;
            }
    }

    public void StartGame()
    {
        LoadLevel();
        Score = 0; Coins = 0; Lives = 3;
        Won = false; deadFlag = false; CheckpointReached = false; WinT = 0; DeadT = 0;
        PlacePlayer(startX, startY);
        P.Invuln = 0;
        State = GameState.Playing;
    }

    private void PlacePlayer(float x, float y)
    {
        P.X = x; P.Y = y; P.VX = 0; P.VY = 0; P.OnGround = false; P.Facing = 1;
        jumpBuf = 0; coyoteT = 0;
        CamX = Math.Max(0f, Math.Min(Cols * T - ViewW, x - ViewW * 0.42f));
    }

    public void TogglePause()
    {
        if (State == GameState.Playing) State = GameState.Paused;
        else if (State == GameState.Paused) State = GameState.Playing;
    }

    public void GoTitle() { State = GameState.Title; }

    public void ClearInput() { Left = Right = JumpHeld = false; }

    public void PressJump() { jumpBuf = JumpBuffer; }

    // =====================================================================
    //  Tiles
    // =====================================================================
    public bool Solid(int c, int r)
    {
        if (c < 0 || c >= Cols) return true;           // invisible walls at both ends of the level
        if (r < 0 || r >= Rows) return false;          // open above and below (pits)
        char t = Tiles[r, c];
        return t == 'G' || t == 'D' || t == 'B' || t == '?' || t == 'U' || t == 'S' || (t >= 'a' && t <= 'd');
    }

    private static int Cell(float v) { return (int)Math.Floor(v / T); }

    private void MoveX(Body b, float dx)
    {
        b.X += dx;
        b.HitWall = false;
        int r0 = Cell(b.Y), r1 = Cell(b.Y + b.H - 0.01f);
        if (dx > 0f)
        {
            int c = Cell(b.X + b.W - 0.01f);
            for (int r = r0; r <= r1; r++)
                if (Solid(c, r)) { b.X = c * T - b.W; b.VX = 0; b.HitWall = true; break; }
        }
        else if (dx < 0f)
        {
            int c = Cell(b.X);
            for (int r = r0; r <= r1; r++)
                if (Solid(c, r)) { b.X = (c + 1) * T; b.VX = 0; b.HitWall = true; break; }
        }
    }

    /// <summary>Vertical move; returns the tile hit from below (for blocks) or (-1,-1).</summary>
    private (int c, int r) MoveY(Body b, float dy)
    {
        b.Y += dy;
        b.OnGround = false;
        int c0 = Cell(b.X), c1 = Cell(b.X + b.W - 0.01f);
        if (dy > 0f)
        {
            int r = Cell(b.Y + b.H - 0.01f);
            for (int c = c0; c <= c1; c++)
                if (Solid(c, r)) { b.Y = r * T - b.H; b.VY = 0; b.OnGround = true; break; }
        }
        else if (dy < 0f)
        {
            int r = Cell(b.Y);
            int best = -1;
            float centre = b.X + b.W / 2f, bestDist = float.MaxValue;
            for (int c = c0; c <= c1; c++)
            {
                if (!Solid(c, r)) continue;
                float d = Math.Abs(c * T + T / 2f - centre);
                if (d < bestDist) { bestDist = d; best = c; }
            }
            if (best >= 0)
            {
                b.Y = (r + 1) * T;
                b.VY = 0;
                return (best, r);
            }
        }
        return (-1, -1);
    }

    private void HitBlock(int c, int r)
    {
        char t = Tiles[r, c];
        if (t == '?')
        {
            Tiles[r, c] = 'U';
            Bumps.Add(new Bump { C = c, R = r });
            Popups.Add(new Popup { X = c * T + T / 2f, Y = r * T, IsCoin = true });
            Coins++; Score += 100;
            Sound?.Invoke("coin");
        }
        else if (t == 'B')
        {
            Tiles[r, c] = '.';
            for (int i = 0; i < 4; i++)
                Debris.Add(new Debris
                {
                    X = c * T + (i % 2) * 16 + 8, Y = r * T + (i / 2) * 16 + 8,
                    VX = (i % 2 == 0 ? -1 : 1) * (90 + i * 25), VY = -420 - (i / 2) * 120, Life = 1.2f
                });
            Score += 50;
            Sound?.Invoke("bump");
        }
        else
        {
            Bumps.Add(new Bump { C = c, R = r });
            Sound?.Invoke("bump");
        }
    }

    // =====================================================================
    //  Update
    // =====================================================================
    public void Update(float dt)
    {
        switch (State)
        {
            case GameState.Title:
            case GameState.GameOver:
            case GameState.Win:
                Time += dt;
                UpdateEffects(dt);
                break;
            case GameState.Playing:
                UpdatePlaying(dt);
                break;
        }
    }

    private void UpdatePlaying(float dt)
    {
        Time += dt;
        if (Won) UpdateWin(dt);
        else if (deadFlag) UpdateDeath(dt);
        else
        {
            UpdatePlayer(dt);
            UpdateEnemies(dt);
            CheckEnemyContacts();
            CheckCoins();
            CheckFlag();
        }
        UpdateEffects(dt);
        UpdateCamera(dt);
    }

    private void UpdatePlayer(float dt)
    {
        var p = P;
        prevBottom = p.Y + p.H;
        if (p.Invuln > 0f) p.Invuln -= dt;

        // ----- horizontal: smooth acceleration, quick braking -----
        int dir = (Right ? 1 : 0) - (Left ? 1 : 0);
        float target = dir * MaxSpeed;
        float rate = dir == 0 ? Friction : (Math.Sign(p.VX) == -dir && p.VX != 0f ? WalkAccel * 1.6f : WalkAccel);
        if (p.VX < target) p.VX = Math.Min(target, p.VX + rate * dt);
        else if (p.VX > target) p.VX = Math.Max(target, p.VX - rate * dt);
        if (dir != 0) p.Facing = dir;

        // ----- jump: coyote time + input buffer + variable height -----
        coyoteT = p.OnGround ? Coyote : coyoteT - dt;
        jumpBuf -= dt;
        if (jumpBuf > 0f && coyoteT > 0f)
        {
            p.VY = -JumpV;
            p.OnGround = false;
            coyoteT = 0f; jumpBuf = 0f;
            Sound?.Invoke("jump");
        }
        if (!JumpHeld && p.VY < -JumpCut) p.VY = -JumpCut;        // let go of Space = shorter jump

        p.VY = Math.Min(MaxFall, p.VY + Gravity * dt);

        MoveX(p, p.VX * dt);
        var hit = MoveY(p, p.VY * dt);
        if (hit.c >= 0) HitBlock(hit.c, hit.r);

        if (p.X < 0f) { p.X = 0f; p.VX = 0f; }
        p.Anim += Math.Abs(p.VX) * dt * 0.035f;

        if (!CheckpointReached && p.X > CheckpointCol * T) CheckpointReached = true;
        if (p.Y > Rows * T + 40f) KillPlayer(true);               // fell into a pit
    }

    // ---------- enemies ----------
    private void UpdateEnemies(float dt)
    {
        foreach (var e in Enemies)
        {
            if (e.Dead) { e.DeadT += dt; continue; }
            if (Math.Abs(e.X - (CamX + ViewW / 2f)) > ViewW * 0.9f) continue;   // only the ones near the screen walk

            e.Anim += dt;
            e.VX = e.Dir * (e.Kind == 0 ? 45f : 62f);
            e.VY = Math.Min(MaxFall, e.VY + Gravity * dt);
            MoveX(e, e.VX * dt);
            if (e.HitWall) e.Dir = -e.Dir;
            MoveY(e, e.VY * dt);

            if (e.OnGround)                                                     // turn around at platform edges
            {
                int c = Cell(e.Dir > 0 ? e.X + e.W + 2f : e.X - 2f);
                int r = Cell(e.Y + e.H + 2f);
                if (!Solid(c, r)) e.Dir = -e.Dir;
            }
            if (e.Y > Rows * T + 80f) e.Dead = true;
        }
        Enemies.RemoveAll(e => e.Dead && e.DeadT > 0.5f);
    }

    private void CheckEnemyContacts()
    {
        var p = P;
        foreach (var e in Enemies)
        {
            if (e.Dead) continue;
            if (p.X + p.W <= e.X || p.X >= e.X + e.W || p.Y + p.H <= e.Y || p.Y >= e.Y + e.H) continue;

            bool stomp = p.VY > 0f && prevBottom <= e.Y + 12f;           // came down on its head
            if (stomp)
            {
                e.Dead = true; e.DeadT = 0f;
                p.VY = JumpHeld ? -560f : -400f;
                Score += 200;
                Popups.Add(new Popup { X = e.X + e.W / 2f, Y = e.Y, Text = "200" });
                Sound?.Invoke("stomp");
            }
            else if (p.Invuln <= 0f)
            {
                KillPlayer(false);                                       // touched from the side: lose a life
                return;
            }
        }
    }

    private void CheckCoins()
    {
        var p = P;
        foreach (var c in CoinList)
        {
            if (c.Taken) continue;
            if (p.X + p.W < c.X - 10f || p.X > c.X + 10f || p.Y + p.H < c.Y - 12f || p.Y > c.Y + 12f) continue;
            c.Taken = true;
            Coins++; Score += 100;
            Sound?.Invoke("coin");
        }
    }

    // ---------- death, respawn, finish ----------
    private void KillPlayer(bool pit)
    {
        if (deadFlag || Won) return;
        deadFlag = true;
        DeadT = 0f;
        Lives--;
        P.VX = 0f;
        P.VY = pit ? 0f : -640f;
        Sound?.Invoke("lose");
    }

    private void UpdateDeath(float dt)
    {
        DeadT += dt;
        P.VY = Math.Min(MaxFall, P.VY + Gravity * dt);
        P.Y += P.VY * dt;                                                // no collisions: the hero tumbles out of the level
        if (DeadT < 1.7f) return;

        if (Lives > 0)
        {
            float x = CheckpointReached ? CheckpointCol * T + (T - P.W) / 2f : startX;
            PlacePlayer(x, startY);
            P.Invuln = 2.0f;
            deadFlag = false;
        }
        else State = GameState.GameOver;
    }

    private void CheckFlag()
    {
        var p = P;
        if (p.X + p.W > FlagX - 5f && p.X < FlagX + 5f && p.Y < 13 * T)
        {
            Won = true;
            WinT = 0f;
            p.X = FlagX - p.W - 3f;
            p.VX = 0f; p.VY = 0f;
            Score += 1000;
            Sound?.Invoke("win");
        }
    }

    private void UpdateWin(float dt)
    {
        WinT += dt;
        var p = P;
        float ground = 13 * T - p.H;
        if (p.Y < ground) p.Y = Math.Min(ground, p.Y + 170f * dt);       // slide down the pole
        else { p.Facing = 1; p.X = Math.Min(FlagX + 60f, p.X + 70f * dt); p.Anim += dt * 3f; }
        if (WinT > 2.6f) State = GameState.Win;
    }

    // ---------- camera and effects ----------
    private void UpdateCamera(float dt)
    {
        float target = P.X + P.W / 2f - ViewW * 0.42f;
        target = Math.Max(0f, Math.Min(Cols * T - ViewW, target));
        CamX += (target - CamX) * Math.Min(1f, 9f * dt);
    }

    private void UpdateEffects(float dt)
    {
        foreach (var d in Debris)
        {
            d.VY += Gravity * dt;
            d.X += d.VX * dt;
            d.Y += d.VY * dt;
            d.Life -= dt;
        }
        Debris.RemoveAll(d => d.Life <= 0f);

        foreach (var b in Bumps) b.T += dt;
        Bumps.RemoveAll(b => b.T > 0.2f);

        foreach (var p in Popups) p.T += dt;
        Popups.RemoveAll(p => p.T > 0.7f);
    }
}
