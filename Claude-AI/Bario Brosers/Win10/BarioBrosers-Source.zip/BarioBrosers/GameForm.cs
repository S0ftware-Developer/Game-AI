using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace BarioBrosers;

/// <summary>Window, input, the fixed-timestep game loop and scaling of the 800x480 pixel frame.</summary>
internal sealed class GameForm : Form
{
    private const int FooterH = 32;
    private const float StepDt = 1f / 120f;

    private readonly Game game = new();
    private readonly Sfx sfx = new();
    private readonly Renderer renderer = new();
    private readonly Bitmap frame = new(Game.ViewW, Game.ViewH, PixelFormat.Format32bppPArgb);
    private readonly Graphics fg;
    private readonly System.Windows.Forms.Timer timer = new();
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private double lastTime, acc;
    private Rectangle gameRect;
    private bool fullscreen, spaceDown;

    // the copyright line is drawn in its own strip under the playfield; resources are created once
    private const string FooterA = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: ";
    private const string FooterC = "orlovandrei.space";
    private readonly SolidBrush footBg = new(Color.FromArgb(18, 22, 52));
    private readonly SolidBrush footWhite = new(Color.FromArgb(238, 238, 245));
    private readonly SolidBrush footGreen = new(Color.FromArgb(130, 235, 140));
    private readonly Pen footLine = new(Color.FromArgb(255, 200, 60), 2f);
    private Font? footFont;
    private int footForWidth = -1;
    private float footWa, footX;

    public GameForm()
    {
        Text = "Bario Brosers";
        DoubleBuffered = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.Black;
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(640, 420);

        // default size = 1:1 logical size, shrunk if the screen is too small
        var wa = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        float s = Math.Min(1f, Math.Min((wa.Width - 40) / (float)Game.ViewW, (wa.Height - 110 - FooterH) / (float)Game.ViewH));
        ClientSize = new Size((int)(Game.ViewW * s), (int)(Game.ViewH * s) + FooterH);

        fg = Graphics.FromImage(frame);
        fg.SmoothingMode = SmoothingMode.None;                     // crisp pixel look
        fg.InterpolationMode = InterpolationMode.NearestNeighbor;
        fg.PixelOffsetMode = PixelOffsetMode.Half;
        fg.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;

        game.Sound = name => sfx.Play(name);
        RecalcLayout();

        timer.Interval = 10;
        timer.Tick += (_, _) => Tick();
        timer.Start();
        lastTime = clock.Elapsed.TotalSeconds;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Stop();
            timer.Dispose();
            renderer.Dispose();
            sfx.Dispose();
            fg.Dispose();
            frame.Dispose();
            footFont?.Dispose();
            footBg.Dispose(); footWhite.Dispose(); footGreen.Dispose(); footLine.Dispose();
        }
        base.Dispose(disposing);
    }

    // ---------- layout ----------
    private void RecalcLayout()
    {
        int availW = Math.Max(1, ClientSize.Width);
        int availH = Math.Max(1, ClientSize.Height - FooterH);
        float s = Math.Min(availW / (float)Game.ViewW, availH / (float)Game.ViewH);
        int w = Math.Max(1, (int)(Game.ViewW * s));
        int h = Math.Max(1, (int)(Game.ViewH * s));
        gameRect = new Rectangle((availW - w) / 2, (availH - h) / 2, w, h);
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        RecalcLayout();
        Invalidate();
    }

    protected override void OnPaintBackground(PaintEventArgs e) { }

    private void ToggleFullscreen()
    {
        fullscreen = !fullscreen;
        if (fullscreen)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
        }
        else
        {
            WindowState = FormWindowState.Normal;
            FormBorderStyle = FormBorderStyle.Sizable;
        }
    }

    // ---------- game loop ----------
    private void Tick()
    {
        double now = clock.Elapsed.TotalSeconds;
        double dt = now - lastTime;
        lastTime = now;
        if (dt > 0.1) dt = 0.1;                 // never try to "catch up" after a long stall
        acc += dt;
        while (acc >= StepDt)
        {
            game.Update(StepDt);                // does nothing while paused
            acc -= StepDt;
        }
        Invalidate();
    }

    // ---------- input ----------
    protected override void OnKeyDown(KeyEventArgs e)
    {
        switch (e.KeyCode)
        {
            case Keys.Left:
            case Keys.A: game.Left = true; break;
            case Keys.Right:
            case Keys.D: game.Right = true; break;
            case Keys.Space:
                game.JumpHeld = true;
                if (!spaceDown)                                    // key repeat must not re-trigger the jump
                {
                    spaceDown = true;
                    if (game.State == GameState.Title) game.StartGame();
                    else game.PressJump();
                }
                break;
            case Keys.Enter:
                if (game.State == GameState.Title || game.State == GameState.GameOver || game.State == GameState.Win) game.StartGame();
                break;
            case Keys.R:
                if (game.State == GameState.GameOver || game.State == GameState.Win) game.StartGame();
                break;
            case Keys.M: sfx.Muted = !sfx.Muted; break;
            case Keys.F11: ToggleFullscreen(); break;
            case Keys.Escape:
                if (game.State == GameState.Title) Close();
                else if (game.State == GameState.Playing || game.State == GameState.Paused) game.TogglePause();
                break;
        }
        e.SuppressKeyPress = true;
        e.Handled = true;
        base.OnKeyDown(e);
    }

    protected override void OnKeyUp(KeyEventArgs e)
    {
        switch (e.KeyCode)
        {
            case Keys.Left:
            case Keys.A: game.Left = false; break;
            case Keys.Right:
            case Keys.D: game.Right = false; break;
            case Keys.Space: game.JumpHeld = false; spaceDown = false; break;
        }
        base.OnKeyUp(e);
    }

    protected override void OnDeactivate(EventArgs e)
    {
        base.OnDeactivate(e);
        game.ClearInput();                                          // no stuck keys after Alt+Tab
        spaceDown = false;
        if (game.State == GameState.Playing) game.TogglePause();    // and never play on in the background
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        timer.Stop();
        base.OnFormClosing(e);
    }

    // ---------- painting ----------
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Color.Black);

        renderer.Render(fg, game, sfx.Muted);

        g.InterpolationMode = InterpolationMode.NearestNeighbor;    // keeps the pixels sharp at any window size
        g.PixelOffsetMode = PixelOffsetMode.Half;
        g.DrawImage(frame, gameRect, 0, 0, Game.ViewW, Game.ViewH, GraphicsUnit.Pixel);

        DrawFooter(g);
    }

    private void RebuildFooterFont(Graphics g, int cw)
    {
        var fmt = StringFormat.GenericTypographic;
        float size = 15f;
        footFont?.Dispose();
        footFont = new Font("Consolas", size, FontStyle.Regular, GraphicsUnit.Pixel);
        footWa = g.MeasureString(FooterA, footFont, 3000, fmt).Width;
        float wc = g.MeasureString(FooterC, footFont, 3000, fmt).Width;
        while (footWa + wc > cw - 12 && size > 7f)       // shrink until the whole line fits the window width
        {
            footFont.Dispose();
            size -= 0.5f;
            footFont = new Font("Consolas", size, FontStyle.Regular, GraphicsUnit.Pixel);
            footWa = g.MeasureString(FooterA, footFont, 3000, fmt).Width;
            wc = g.MeasureString(FooterC, footFont, 3000, fmt).Width;
        }
        footX = (cw - (footWa + wc)) / 2f;
        footForWidth = cw;
    }

    private void DrawFooter(Graphics g)
    {
        int cw = ClientSize.Width;
        int top = ClientSize.Height - FooterH;
        g.SmoothingMode = SmoothingMode.None;
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        if (footFont == null || footForWidth != cw) RebuildFooterFont(g, cw);

        g.FillRectangle(footBg, 0, top, cw, FooterH);
        g.DrawLine(footLine, 0, top, cw, top);
        var fmt = StringFormat.GenericTypographic;
        float y = top + (FooterH - footFont!.Height) / 2f;
        g.DrawString(FooterA, footFont, footWhite, footX, y, fmt);
        g.DrawString(FooterC, footFont, footGreen, footX + footWa, y, fmt);
    }
}
