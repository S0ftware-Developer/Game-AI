namespace CircusCharlie;

/// <summary>Keyboard state: which keys are held, and one-shot "pressed" edges that the game consumes once.</summary>
public sealed class InputManager
{
    private readonly HashSet<Keys> held = new HashSet<Keys>();
    private readonly HashSet<Keys> pressed = new HashSet<Keys>();

    public void KeyDown(Keys key)
    {
        if (held.Add(key)) pressed.Add(key);     // auto-repeat does not create a new press
    }

    public void KeyUp(Keys key)
    {
        held.Remove(key);
    }

    public bool Held(Keys key)
    {
        return held.Contains(key);
    }

    public bool AnyHeld(Keys a, Keys b)
    {
        return held.Contains(a) || held.Contains(b);
    }

    public bool AnyHeld(Keys a, Keys b, Keys c)
    {
        return held.Contains(a) || held.Contains(b) || held.Contains(c);
    }

    /// <summary>True once per key press; the press is consumed.</summary>
    public bool Pressed(Keys key)
    {
        return pressed.Remove(key);
    }

    public bool AnyPressed(Keys a, Keys b)
    {
        bool r1 = pressed.Remove(a);
        bool r2 = pressed.Remove(b);
        return r1 || r2;
    }

    public void ClearPressed()
    {
        pressed.Clear();
    }

    public void Clear()
    {
        held.Clear();
        pressed.Clear();
    }
}
