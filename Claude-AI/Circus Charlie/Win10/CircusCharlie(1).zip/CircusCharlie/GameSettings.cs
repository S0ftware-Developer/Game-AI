namespace CircusCharlie;

public sealed class LevelInfo
{
    public string Name = "";
    public string Act = "";
    public string Hint = "";
    public int Meters;
}

/// <summary>All fixed numbers of the game. The game is drawn on a 480 x 270 pixel canvas that is scaled up by two.</summary>
public static class GameSettings
{
    public const int ViewW = 480;
    public const int ViewH = 270;
    public const int PixelScale = 2;
    public const int LogicalW = ViewW * PixelScale;                 // 960
    public const int FooterH = 32;
    public const int LogicalH = ViewH * PixelScale + FooterH;       // 572

    public const float GroundY = 214f;       // the arena track and the lion's / horse's feet
    public const float MeterPx = 30f;        // one metre of level distance in pixels
    public const int StartLives = 3;

    public const int ScoreBag = 100;
    public const int ScoreJump = 50;
    public const int ScoreSequence = 200;
    public const int ScoreLevel = 1000;
    public const int ScoreNoDeath = 500;
    public const int ScoreAllLevels = 5000;
    public const float StartBonus = 2000f;

    public const int LevelCount = 6;

    public static readonly LevelInfo[] Levels =
    {
        new LevelInfo { Name = "LION RIDER", Act = "FIRE HOOPS AND FIRE BOWLS", Meters = 100,
            Hint = "SPACE: JUMP THROUGH THE HOOPS - A BOWL NEEDS A SHORT JUMP" },
        new LevelInfo { Name = "TIGHTROPE MONKEYS", Act = "BALANCE ABOVE THE ARENA", Meters = 70,
            Hint = "LEFT / RIGHT: WALK   SPACE: JUMP OVER THE MONKEYS" },
        new LevelInfo { Name = "TRAMPOLINES AND KNIVES", Act = "BOUNCE FROM TRAMPOLINE TO TRAMPOLINE", Meters = 90,
            Hint = "HOLD RIGHT IN THE AIR - PRESS SPACE ON LANDING FOR A HIGHER BOUNCE" },
        new LevelInfo { Name = "BALL JUMPER", Act = "LEAP FROM BALL TO BALL", Meters = 80,
            Hint = "SPACE: JUMP   LEFT / RIGHT: STEER IN THE AIR" },
        new LevelInfo { Name = "HORSE RIDER", Act = "GALLOP OVER THE HURDLES", Meters = 200,
            Hint = "SPACE: JUMP THE HURDLES AND FIRE BOWLS" },
        new LevelInfo { Name = "TRAPEZE ARTIST", Act = "FLY THROUGH THE BIG TOP", Meters = 50,
            Hint = "SPACE: LET GO AT THE RIGHT MOMENT - FOLLOW THE DOTS" }
    };
}
