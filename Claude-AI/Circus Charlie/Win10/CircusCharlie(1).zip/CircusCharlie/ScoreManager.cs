namespace CircusCharlie;

/// <summary>Stores the best score in the user's application data folder. The game works without it.</summary>
public sealed class ScoreManager
{
    public int Best;

    private static string SavePath
    {
        get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CircusCharlie", "best.txt"); }
    }

    public void Load()
    {
        try
        {
            string path = SavePath;
            if (!File.Exists(path)) return;
            int v;
            if (int.TryParse(File.ReadAllText(path).Trim(), out v)) Best = Math.Max(0, v);
        }
        catch (Exception)
        {
            // saving is optional
        }
    }

    public void Save()
    {
        try
        {
            string path = SavePath;
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            File.WriteAllText(path, Best.ToString());
        }
        catch (Exception)
        {
        }
    }

    /// <summary>Records a finished game. Returns true for a new record.</summary>
    public bool Submit(int score)
    {
        if (score <= Best) return false;
        Best = score;
        Save();
        return true;
    }
}
