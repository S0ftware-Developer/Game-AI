namespace CircusCharlie;

/// <summary>A trampoline on a striped pedestal. Its surface sags when Charlie lands and springs back when he is launched.</summary>
public sealed class Trampoline
{
    public const float HalfW = 21f;
    public float Half { get { return IsGoal ? 46f : HalfW; } }

    public float X, Y;                   // the surface line at rest
    public float Compress;               // 0..1
    public bool IsGoal;                  // the final platform: a firm landing spot without a bounce

    public void Update(float dt)
    {
        if (Compress > 0f) Compress = Math.Max(0f, Compress - dt * 4f);
    }
}
