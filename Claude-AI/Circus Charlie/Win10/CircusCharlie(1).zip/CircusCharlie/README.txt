﻿CIRCUS CHARLIE
==============

© 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space

GAME
----
A colourful 8-bit style circus arcade game. You are Charlie the clown and you perform six different circus acts, each
with its own mechanics. Collect money bags, jump the hazards and reach the end of every act. After the sixth act the
game starts again from act 1 in a faster, harder round, so you can keep playing through many cycles.

WINDOWS REQUIREMENTS
--------------------
Windows 10 or 11, 64-bit. The built game is one standalone EXE and needs nothing installed.
To BUILD it you need the .NET SDK 8 or newer (8, 9 and 10 all work). The game is not pre-built: build it locally with
build.bat (see below).

CONTROLS
--------
Left / Right arrow   move (walk the rope, steer in the air); A / D work too
Space                jump (on the trampoline: press as you land for a higher bounce; on the trapeze: let go)
Esc                  pause / resume (pause menu: Resume, Restart, Sound on/off, Title screen)
Enter                start / confirm / skip the act introduction
F11 / Alt+Enter      full screen
Menus: Up / Down and Enter, or the mouse.

THE SIX ACTS
------------
1. LION RIDER (100 m): the lion runs by itself; Charlie jumps off its back through flaming hoops and over fire bowls.
   A hoop needs a high jump (go through its opening), a bowl needs only a short hop. Some obstacles come in pairs.
2. TIGHTROPE MONKEYS (70 m): walk along a high rope and jump over the monkeys. Some are fast, some turn around, some hop.
   A hit throws Charlie off the rope.
3. TRAMPOLINES AND KNIVES (90 m): Charlie bounces from trampoline to trampoline. Hold Right in the air to travel; press
   Space just as you land for a higher bounce. Knives fly in from the right (a warning arrow shows the height). Missing a
   trampoline means falling.
4. BALL JUMPER (80 m): leap from big circus ball to ball. Balls differ in size, height and distance, and some drift.
   You can shift your position on a ball with Left / Right and steer in the air. Missing a ball means falling.
5. HORSE RIDER (200 m): gallop over hurdles and fire bowls; horse and Charlie jump together. The horse speeds up.
6. TRAPEZE ARTIST (50 m): hang from a swinging trapeze and let go with Space so that you fly into the next one. The dotted
   line shows where you would fly if you let go now. Miss the trapeze and you fall; the last one lands on a platform.

LIVES, CHECKPOINTS AND SCORE
----------------------------
You start with 3 lives. Hitting an obstacle, an enemy, a knife or falling costs a life; you replay the act from the last
checkpoint (every 20 or 40 m, or the last trampoline / ball / trapeze you reached) with a short invulnerability. When all
lives are gone the game is over.
Money bag 100 (plus 50 for each bag in a quick row, up to +200), a cleared obstacle or enemy 50, five in a row
200 (SEQUENCE), completing an act 1000, no life lost in the act 500, all six acts 5000, plus the remaining time bonus.
The best score is saved in %APPDATA%\CircusCharlie\best.txt.

HOW TO BUILD AND LAUNCH
-----------------------
1. Unzip CircusCharlie.zip to any folder (a path with spaces or parentheses is fine).
2. Double-click build.bat. It shows the installed SDK version, checks that it is 8 or newer, publishes a self-contained
   single-file Windows x64 build and keeps the window open. The first build needs an internet connection (NuGet).
3. The game is created at:   bin\Release\net8.0-windows\win-x64\publish\CircusCharlie.exe
   Double-click it to play. The publish folder contains only this one file.

PROJECT FILES
-------------
CircusCharlie.csproj, Program.cs, GameForm.cs (window, loop, mouse), InputManager.cs, GameEngine.cs (states, lives, score,
cycle), LevelManager.cs (the six acts), Charlie.cs, Lion.cs, Horse.cs, Monkey.cs, Obstacle.cs (hoops, bowls, hurdles,
knives), Trampoline.cs, CircusBall.cs, Trapeze.cs, MoneyBag.cs, GameSettings.cs, GameRenderer.cs (pixel canvas, HUD,
screens), Sprites.cs (all pixel-art characters and props), Background.cs (arena, crowd, tent), ParticleSystem.cs,
SoundManager.cs (generated sound effects), ScoreManager.cs, build.bat, README.txt.

TECHNICAL NOTES
---------------
C#, .NET 8, Windows Forms, GDI+. The game is drawn on a 480x270 pixel canvas with hard edges and scaled by two with
nearest-neighbour filtering (the aspect ratio is kept when the window is resized). Fixed 1/120 s simulation step. All
graphics are drawn by code and all sounds are generated in memory; Windows plays one sound at a time, so the quiet gallop
and swing sounds are throttled. There is no music.

NOTE ON TESTING
---------------
This project was written without compiling or running it (the author's environment has no .NET SDK or Windows). Please
build it locally; if the compiler reports an error or something behaves wrongly, report it and it will be fixed.
