namespace CircusCharlie;

public enum ObstacleKind { FireBowl, Hoop, Hurdle, TallHurdle, WideHurdle }

/// <summary>A ground obstacle of the riding acts: a fire bowl, a flaming hoop or a hurdle.</summary>
public sealed class Obstacle
{
    public ObstacleKind Kind;
    public float X;
    public float Y = GameSettings.GroundY;
    public bool Passed;
    public bool Hit;

    public float HalfWidth
    {
        get
        {
            switch (Kind)
            {
                case ObstacleKind.Hoop: return 7f;
                case ObstacleKind.FireBowl: return 8f;
                case ObstacleKind.WideHurdle: return 18f;
                default: return 6f;
            }
        }
    }

    /// <summary>The dangerous area. The hoop's opening is above its box: Charlie must be high enough to pass through it.</summary>
    public RectangleF Box
    {
        get
        {
            switch (Kind)
            {
                case ObstacleKind.Hoop: return new RectangleF(X - 7f, Y - 44f, 14f, 44f);
                case ObstacleKind.FireBowl: return new RectangleF(X - 8f, Y - 30f, 16f, 30f);
                case ObstacleKind.TallHurdle: return new RectangleF(X - 6f, Y - 34f, 12f, 34f);
                case ObstacleKind.WideHurdle: return new RectangleF(X - 18f, Y - 22f, 36f, 22f);
                default: return new RectangleF(X - 6f, Y - 22f, 12f, 22f);
            }
        }
    }
}

/// <summary>A flying knife of the trampoline act. It shows a warning arrow before it enters the screen.</summary>
public sealed class Knife
{
    public float X, Y, VX;
    public float Warn;             // seconds left before it appears
    public float Rot;
    public bool Active;

    public RectangleF Box
    {
        get { return new RectangleF(X - 11f, Y - 3f, 22f, 6f); }
    }
}
