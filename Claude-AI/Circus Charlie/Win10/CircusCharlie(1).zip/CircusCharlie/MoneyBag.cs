namespace CircusCharlie;

public sealed class MoneyBag
{
    public float X, Y;
    public bool Collected;
    public float Age;
}
