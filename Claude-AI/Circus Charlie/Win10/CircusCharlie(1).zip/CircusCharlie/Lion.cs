namespace CircusCharlie;

/// <summary>The lion Charlie rides in the first act. It runs on the ground; Charlie jumps off its back and lands on it again.</summary>
public sealed class Lion
{
    public float X;
    public float Phase;
    public float Speed;
    public bool Stopped;

    public void Reset(float x)
    {
        X = x;
        Phase = 0f;
        Speed = 0f;
        Stopped = false;
    }

    public void Update(float dt, float speed)
    {
        Speed = speed;
        X += speed * dt;
        Phase += speed * dt * 0.1f;
    }
}
