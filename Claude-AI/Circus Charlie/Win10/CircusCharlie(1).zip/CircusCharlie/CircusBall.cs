namespace CircusCharlie;

/// <summary>A big circus ball. It may drift up and down or sideways, squashes when Charlie lands and rolls under his feet.</summary>
public sealed class CircusBall
{
    public float BaseX, BaseY, X, Y, R;
    public int Motion;                   // 0 still, 1 vertical, 2 horizontal
    public float Amp, Speed, Phase;
    public float Squash;
    public float Roll;
    public int Color;
    public bool IsGoal;
    public float DX, DY;                 // movement during the last update

    public void Update(float dt, float time)
    {
        float nx = BaseX, ny = BaseY;
        if (Motion == 1) ny = BaseY + (float)Math.Sin(time * Speed + Phase) * Amp;
        else if (Motion == 2) nx = BaseX + (float)Math.Sin(time * Speed + Phase) * Amp;
        DX = nx - X;
        DY = ny - Y;
        X = nx;
        Y = ny;
        if (Squash > 0f) Squash = Math.Max(0f, Squash - dt * 3.5f);
    }

    /// <summary>The y of the ball's top surface at a horizontal offset from its centre.</summary>
    public float SurfaceY(float dx)
    {
        float h = (float)Math.Sqrt(Math.Max(0.0, R * R - dx * dx));
        return Y - h + Squash * 3f;
    }
}
