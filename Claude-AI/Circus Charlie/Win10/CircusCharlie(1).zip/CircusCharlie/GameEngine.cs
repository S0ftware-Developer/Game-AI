namespace CircusCharlie;

public enum GameState { Title, Controls, Intro, Playing, Paused, LevelComplete, GameOver, Victory }

/// <summary>Game flow and rules: states, lives, score, the six-act cycle with rising difficulty, pause and menus.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;

    public GameState State = GameState.Title;
    public readonly InputManager Input = new InputManager();
    public readonly LevelManager Level = new LevelManager();
    public readonly ParticleSystem Particles = new ParticleSystem();
    public readonly ScoreManager Scores = new ScoreManager();
    public Action? ExitRequested;

    public float Clock;                  // always running (menus)
    public float GameTime;               // runs while the game is being played (everything freezes in pause)
    public int Score;
    public int Lives = GameSettings.StartLives;
    public int Act = 1;                  // 1..6
    public int Cycle;                    // completed full cycles
    public float IntroTimer, CompleteTimer;
    public int AwardLevel, AwardNoDeath, AwardBonus, AwardBags;
    public bool LifeLost;
    public bool NewRecord;
    public int TitleIndex, PauseIndex, EndIndex;
    public string Note = "";
    public float NoteTimer;

    private bool deathHandled, completeHandled;

    public GameEngine()
    {
        Scores.Load();
        Level.Particles = Particles;
        Level.OnScore = OnScore;
    }

    // ------------------------------------------------------------------ flow

    public void StartGame()
    {
        Score = 0;
        Lives = GameSettings.StartLives;
        Cycle = 0;
        Act = 1;
        NewRecord = false;
        SoundManager.Play(SfxId.Confirm);
        EnterIntro();
    }

    private void EnterIntro()
    {
        Particles.Clear();
        Level.Load(Act, Cycle);
        LifeLost = false;
        deathHandled = false;
        completeHandled = false;
        IntroTimer = 0f;
        State = GameState.Intro;
        Input.Clear();
        SoundManager.Play(SfxId.Ready);
    }

    public int ItemCount(GameState s)
    {
        switch (s)
        {
            case GameState.Title: return 2;
            case GameState.Paused: return 4;
            case GameState.GameOver:
            case GameState.Victory: return 2;
            default: return 1;
        }
    }

    public void Hover(GameState s, int index)
    {
        if (index < 0 || index >= ItemCount(s)) return;
        if (s == GameState.Title) TitleIndex = index;
        else if (s == GameState.Paused) PauseIndex = index;
        else if (s == GameState.GameOver || s == GameState.Victory) EndIndex = index;
    }

    public void Activate(GameState s, int index)
    {
        SoundManager.Play(SfxId.Confirm);
        switch (s)
        {
            case GameState.Title:
                if (index == 0) StartGame();
                else State = GameState.Controls;
                break;
            case GameState.Controls:
                State = GameState.Title;
                break;
            case GameState.Paused:
                if (index == 0) State = GameState.Playing;
                else if (index == 1) StartGame();
                else if (index == 2) SoundManager.SetMuted(!SoundManager.Muted);
                else State = GameState.Title;
                break;
            case GameState.GameOver:
                if (index == 0) StartGame();
                else State = GameState.Title;
                break;
            case GameState.Victory:
                if (index == 0) NextCycle();
                else State = GameState.Title;
                break;
        }
    }

    public void AutoPause()
    {
        Input.Clear();
        if (State == GameState.Playing)
        {
            PauseIndex = 0;
            State = GameState.Paused;
        }
    }

    private void Navigate(ref int index, int count)
    {
        if (Input.AnyPressed(Keys.Up, Keys.W))
        {
            index = (index + count - 1) % count;
            SoundManager.Play(SfxId.Menu);
        }
        if (Input.AnyPressed(Keys.Down, Keys.S))
        {
            index = (index + 1) % count;
            SoundManager.Play(SfxId.Menu);
        }
    }

    private void OnScore(int points, float x, float y, string text)
    {
        Score += points;
        Particles.Text(x, y - 10f, text, Color.FromArgb(255, 255, 240, 140));
    }

    // ------------------------------------------------------------------ the fixed step

    public void Update()
    {
        Clock += Dt;
        switch (State)
        {
            case GameState.Title:
                Navigate(ref TitleIndex, 2);
                if (Input.AnyPressed(Keys.Enter, Keys.Space)) Activate(GameState.Title, TitleIndex);
                break;
            case GameState.Controls:
                if (Input.AnyPressed(Keys.Enter, Keys.Escape) | Input.Pressed(Keys.Space)) Activate(GameState.Controls, 0);
                break;
            case GameState.Intro:
                GameTime += Dt;
                IntroTimer += Dt;
                if ((IntroTimer > 0.5f && Input.AnyPressed(Keys.Enter, Keys.Space)) || IntroTimer > 3.4f)
                {
                    State = GameState.Playing;
                    Input.Clear();
                }
                break;
            case GameState.Paused:
                Navigate(ref PauseIndex, 4);
                if (Input.Pressed(Keys.Escape)) State = GameState.Playing;
                else if (Input.AnyPressed(Keys.Enter, Keys.Space)) Activate(GameState.Paused, PauseIndex);
                else if (Input.Pressed(Keys.R)) StartGame();
                else if (Input.Pressed(Keys.M)) SoundManager.SetMuted(!SoundManager.Muted);
                break;
            case GameState.LevelComplete:
                GameTime += Dt;
                CompleteTimer += Dt;
                Particles.Update(Dt);
                Level.Update(Dt, new LevelInput());
                if ((CompleteTimer > 1.0f && Input.AnyPressed(Keys.Enter, Keys.Space)) || CompleteTimer > 6f) NextAct();
                break;
            case GameState.GameOver:
                Navigate(ref EndIndex, 2);
                GameTime += Dt;
                Particles.Update(Dt);
                if (Input.Pressed(Keys.R)) StartGame();
                else if (Input.Pressed(Keys.Escape)) State = GameState.Title;
                else if (Input.AnyPressed(Keys.Enter, Keys.Space)) Activate(GameState.GameOver, EndIndex);
                break;
            case GameState.Victory:
                Navigate(ref EndIndex, 2);
                GameTime += Dt;
                Particles.Update(Dt);
                if (((int)(Clock * 10f)) != ((int)((Clock - Dt) * 10f)))
                {
                    Color[] cs = { Color.FromArgb(255, 80, 80), Color.FromArgb(255, 220, 60), Color.FromArgb(80, 220, 120), Color.FromArgb(90, 170, 255) };
                    Random r = Random.Shared;
                    Particles.Sparks(Level.CameraX + (float)(r.NextDouble() * GameSettings.ViewW), 20f, 70f, 3, cs[r.Next(cs.Length)]);
                }
                if (Input.AnyPressed(Keys.Enter, Keys.Space)) Activate(GameState.Victory, EndIndex);
                else if (Input.Pressed(Keys.Escape)) State = GameState.Title;
                break;
            default:
                UpdatePlaying();
                break;
        }
        if (NoteTimer > 0f) NoteTimer -= Dt;
        Input.ClearPressed();
    }

    private void UpdatePlaying()
    {
        if (Input.Pressed(Keys.Escape))
        {
            PauseIndex = 0;
            State = GameState.Paused;
            SoundManager.Play(SfxId.Menu);
            return;
        }
        GameTime += Dt;
        LevelInput inp = new LevelInput();
        inp.Left = Input.AnyHeld(Keys.Left, Keys.A);
        inp.Right = Input.AnyHeld(Keys.Right, Keys.D);
        inp.JumpPressed = Input.Pressed(Keys.Space);
        inp.JumpHeld = Input.Held(Keys.Space);

        Level.Update(Dt, inp);
        Particles.Update(Dt);

        // a life is lost when the death begins; the act is replayed from its checkpoint when the animation ends
        if (Level.Charlie.Dying && !deathHandled)
        {
            deathHandled = true;
            LifeLost = true;
            Lives--;
            SoundManager.Play(SfxId.Death);
        }
        if (Level.Charlie.DeathDone)
        {
            if (Lives > 0)
            {
                Level.Respawn();
                deathHandled = false;
                Note = "LIVES LEFT: " + Lives;
                NoteTimer = 2f;
            }
            else
            {
                NewRecord = Scores.Submit(Score);
                EndIndex = 0;
                State = GameState.GameOver;
                SoundManager.Play(SfxId.GameOver);
            }
            return;
        }

        // the act is complete: award the bonuses, then show the result
        if (Level.Completed && !completeHandled)
        {
            completeHandled = true;
            AwardLevel = GameSettings.ScoreLevel;
            AwardNoDeath = LifeLost ? 0 : GameSettings.ScoreNoDeath;
            AwardBonus = (int)Level.Bonus;
            AwardBags = Level.BagCount;
            Score += AwardLevel + AwardNoDeath + AwardBonus;
            SoundManager.Play(SfxId.LevelComplete);
        }
        if (Level.Ready)
        {
            CompleteTimer = 0f;
            State = GameState.LevelComplete;
        }
    }

    private void NextAct()
    {
        if (Act >= GameSettings.LevelCount)
        {
            Score += GameSettings.ScoreAllLevels;
            NewRecord = Scores.Submit(Score);
            EndIndex = 0;
            State = GameState.Victory;
            SoundManager.Play(SfxId.Victory);
            return;
        }
        Act++;
        EnterIntro();
    }

    private void NextCycle()
    {
        Cycle++;
        Act = 1;
        EnterIntro();
    }
}
