using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace CircusCharlie;

/// <summary>
/// The circus at night: a banded sky with stars and moving spotlights, far tents, a crowd in the stands, the red and white
/// arena barrier, the sandy track and the big-top canopy with twinkling bulbs. Layers are pre-rendered once with hard edges.
/// </summary>
public sealed class Background : IDisposable
{
    private const int W = GameSettings.ViewW;
    private const int H = GameSettings.ViewH;
    private const int TileW = 960;

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fSign = new Font("Consolas", 8f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly StringFormat sfCenter = new StringFormat();
    private readonly Bitmap sky;
    private readonly Bitmap far;
    private readonly Bitmap crowd;
    private readonly Bitmap canopy;
    private readonly PointF[] beam = new PointF[4];

    public Background()
    {
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sky = MakeSky();
        far = MakeFar();
        crowd = MakeCrowd();
        canopy = MakeCanopy();
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fSign.Dispose();
        sfCenter.Dispose();
        sky.Dispose();
        far.Dispose();
        crowd.Dispose();
        canopy.Dispose();
    }

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private void R(Graphics g, Color c, float x, float y, float w, float h)
    {
        g.FillRectangle(B(c), (int)Math.Round(x), (int)Math.Round(y), (int)Math.Round(w), (int)Math.Round(h));
    }

    private static int Hash(int a, int b)
    {
        unchecked
        {
            int h = a * 73856093 ^ b * 19349663;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    private void DrawTile(Graphics g, Bitmap bmp, float offset, int y)
    {
        int x = -(int)(((offset % TileW) + TileW) % TileW);
        while (x < W)
        {
            g.DrawImageUnscaled(bmp, x, y);
            x += TileW;
        }
    }

    // ------------------------------------------------------------------ the scenery

    /// <summary>Draws the backdrop. The arena acts (1 and 5) have the stands low behind the track; the others have a lower floor.</summary>
    public void Draw(Graphics g, int level, float camX, float time)
    {
        bool arena = level == 1 || level == 5;
        g.DrawImageUnscaled(sky, 0, 0);

        // twinkling stars
        for (int i = 0; i < 26; i++)
        {
            int h = Hash(i, 3);
            if (((int)(time * 2f + h % 7) & 3) == 0) continue;
            R(g, Color.FromArgb(255, 240, 240, 255), (h % W), (h >> 8) % 90, 1, 1);
        }
        // spotlight beams sweeping across the tent
        for (int i = 0; i < 3; i++)
        {
            float sx = 90f + i * 150f + (float)Math.Sin(time * 0.5f + i * 2f) * 50f - camX * 0.03f;
            float ex = sx + (float)Math.Sin(time * 0.7f + i) * 90f;
            beam[0] = new PointF(sx - 6f, 0f);
            beam[1] = new PointF(sx + 6f, 0f);
            beam[2] = new PointF(ex + 46f, 190f);
            beam[3] = new PointF(ex - 46f, 190f);
            g.FillPolygon(B(Color.FromArgb(26, 255, 250, 200)), beam);
        }

        DrawTile(g, far, camX * 0.1f, arena ? 70 : 76);
        int crowdTop = arena ? 94 : 130;
        DrawTile(g, crowd, camX * 0.2f, crowdTop);
        DrawTile(g, canopy, camX * 0.3f, 0);
        // bulbs along the canopy
        for (int x = -((int)(camX * 0.3f) % 24); x < W; x += 24)
        {
            bool on = (((x + (int)(camX * 0.3f)) / 24 + (int)(time * 3f)) & 1) == 0;
            R(g, on ? Color.FromArgb(255, 255, 240, 140) : Color.FromArgb(255, 200, 120, 40), x + 8, 30, 3, 3);
        }

        if (arena)
        {
            // the red and white barrier in front of the stands and the sandy track
            R(g, Color.FromArgb(255, 20, 12, 36), 0, 188, W, 20);
            int bx = -(int)(camX % 16f);
            for (int x = bx - 16; x < W; x += 16)
            {
                int stripe = (int)Math.Floor((x + camX) / 16f);
                R(g, (stripe & 1) == 0 ? Color.FromArgb(255, 232, 52, 52) : Color.FromArgb(255, 252, 252, 255), x, 190, 16, 16);
            }
            R(g, Color.FromArgb(255, 252, 208, 60), 0, 186, W, 4);
            R(g, Color.FromArgb(255, 120, 80, 20), 0, 190, W, 1);
            DrawTrack(g, camX, 206);
        }
        else
        {
            R(g, Color.FromArgb(255, 20, 12, 36), 0, 236, W, 12);
            int bx = -(int)(camX * 0.5f % 16f);
            for (int x = bx - 16; x < W; x += 16)
            {
                int stripe = (int)Math.Floor((x + camX * 0.5f) / 16f);
                R(g, (stripe & 1) == 0 ? Color.FromArgb(255, 232, 52, 52) : Color.FromArgb(255, 252, 252, 255), x, 238, 16, 9);
            }
            R(g, Color.FromArgb(255, 252, 208, 60), 0, 234, W, 3);
            DrawTrack(g, camX * 0.5f, 247);
        }
    }

    private void DrawTrack(Graphics g, float camX, int top)
    {
        R(g, Color.FromArgb(255, 226, 180, 108), 0, top, W, H - top);
        R(g, Color.FromArgb(255, 204, 154, 86), 0, top + 12, W, H - top - 12);
        R(g, Color.FromArgb(255, 252, 214, 140), 0, top, W, 2);
        for (int x = -(int)(camX % 40f) - 40; x < W; x += 40)
            R(g, Color.FromArgb(255, 252, 252, 255), x, top + 28, 22, 2);
        for (int x = -(int)(camX % 7f) - 7; x < W; x += 7)
        {
            int h = Hash((int)Math.Floor((x + camX) / 7f), 5);
            if (h % 3 == 0) R(g, Color.FromArgb(255, 176, 128, 70), x, top + 4 + h % 8, 2, 1);
            if (h % 5 == 0) R(g, Color.FromArgb(255, 244, 204, 140), x + 2, top + 18 + h % 10, 2, 1);
        }
    }

    /// <summary>Distance posts every 10 metres, counting down to the finish.</summary>
    public void DrawMeterPosts(Graphics g, float endX, float camX, float groundY)
    {
        int meters = (int)(endX / GameSettings.MeterPx);
        for (int m = 10; m < meters; m += 10)
        {
            float x = endX - m * GameSettings.MeterPx;
            if (x < camX - 20f || x > camX + W + 20f) continue;
            int ix = (int)x;
            R(g, Color.FromArgb(255, 40, 24, 30), ix - 8, groundY - 22, 17, 12);
            R(g, Color.FromArgb(255, 252, 252, 255), ix - 7, groundY - 21, 15, 10);
            R(g, Color.FromArgb(255, 232, 52, 52), ix - 7, groundY - 21, 15, 2);
            g.DrawString(m + "M", fSign, B(Color.FromArgb(255, 40, 24, 30)), ix + 1, groundY - 14, sfCenter);
            R(g, Color.FromArgb(255, 80, 50, 30), ix - 1, groundY - 10, 3, 10);
        }
    }

    /// <summary>The tightrope with its poles and guy lines.</summary>
    public void DrawRope(Graphics g, float ropeY, float endX, float charlieX, float time)
    {
        float x0 = 40f;
        float x1 = endX + 40f;
        R(g, Color.FromArgb(255, 20, 10, 20), x0, ropeY - 1, x1 - x0, 4);
        for (float x = x0; x < x1; x += 4f)
        {
            float d = Math.Abs(x - charlieX);
            float sag = d < 40f ? (1f - d / 40f) * 2f : 0f;
            R(g, Color.FromArgb(255, 226, 190, 130), x, ropeY + (float)Math.Round(sag), 4, 2);
            if (((int)(x / 4f) & 3) == 0) R(g, Color.FromArgb(255, 150, 110, 60), x, ropeY + (float)Math.Round(sag), 2, 1);
        }
        // the end poles and the support wires
        R(g, Color.FromArgb(255, 20, 10, 20), x0 - 4, ropeY - 80, 8, 260);
        R(g, Color.FromArgb(255, 232, 52, 52), x0 - 3, ropeY - 80, 6, 260);
        for (int y = (int)ropeY - 78; y < H; y += 12) R(g, Color.FromArgb(255, 252, 252, 255), x0 - 3, y, 6, 6);
        R(g, Color.FromArgb(255, 20, 10, 20), x1 - 4, ropeY - 80, 8, 260);
        R(g, Color.FromArgb(255, 232, 52, 52), x1 - 3, ropeY - 80, 6, 260);
        for (int y = (int)ropeY - 78; y < H; y += 12) R(g, Color.FromArgb(255, 252, 252, 255), x1 - 3, y, 6, 6);
    }

    /// <summary>The roof rail from which the trapezes hang.</summary>
    public void DrawRoofRail(Graphics g, float camX, List<Trapeze> trapezes)
    {
        R(g, Color.FromArgb(255, 30, 16, 28), camX - 10, 18, W + 20, 9);
        R(g, Color.FromArgb(255, 196, 40, 50), camX - 10, 19, W + 20, 5);
        R(g, Color.FromArgb(255, 252, 208, 60), camX - 10, 18, W + 20, 1);
        foreach (Trapeze t in trapezes)
        {
            if (t.AnchorX < camX - 30f || t.AnchorX > camX + W + 30f) continue;
            R(g, Color.FromArgb(255, 30, 16, 28), t.AnchorX - 13, 24, 26, 6);
            R(g, Color.FromArgb(255, 252, 208, 60), t.AnchorX - 12, 25, 24, 3);
        }
    }

    // ------------------------------------------------------------------ pre-rendered layers

    private static Graphics Pixel(Bitmap bmp)
    {
        Graphics g = Graphics.FromImage(bmp);
        g.SmoothingMode = SmoothingMode.None;
        g.PixelOffsetMode = PixelOffsetMode.Half;
        g.InterpolationMode = InterpolationMode.NearestNeighbor;
        return g;
    }

    private static Bitmap MakeSky()
    {
        Bitmap bmp = new Bitmap(W, H, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            int bands = 20;
            for (int i = 0; i < bands; i++)
            {
                float t = i / (float)(bands - 1);
                Color c = Color.FromArgb(255, (int)(10 + 50 * t), (int)(14 + 54 * t), (int)(66 + 110 * t));
                using (SolidBrush b = new SolidBrush(c))
                {
                    g.FillRectangle(b, 0, i * H / bands, W, H / bands + 2);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeFar()
    {
        Bitmap bmp = new Bitmap(TileW, 120, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            Random rnd = new Random(9);
            using (SolidBrush tree = new SolidBrush(Color.FromArgb(255, 22, 44, 70)))
            using (SolidBrush red = new SolidBrush(Color.FromArgb(255, 170, 40, 60)))
            using (SolidBrush white = new SolidBrush(Color.FromArgb(255, 200, 204, 230)))
            using (SolidBrush dark = new SolidBrush(Color.FromArgb(255, 24, 24, 56)))
            {
                for (int i = 0; i < 24; i++)
                {
                    int x = rnd.Next(TileW);
                    int w = 30 + rnd.Next(40);
                    g.FillEllipse(tree, x, 70 + rnd.Next(20), w, 50);
                }
                // striped tents with flags
                for (int k = 0; k < 4; k++)
                {
                    int cx = 120 + k * 230 + rnd.Next(40);
                    int w = 70 + rnd.Next(30);
                    for (int i = 0; i < w / 2; i++)
                    {
                        int y = 50 + i * 40 / (w / 2);
                        SolidBrush stripe = ((i / 4) & 1) == 0 ? red : white;
                        g.FillRectangle(stripe, cx - i, y, 2, 96 - y);
                        g.FillRectangle(stripe, cx + i, y, 2, 96 - y);
                    }
                    g.FillRectangle(dark, cx - w / 2, 96, w, 3);
                    g.FillRectangle(dark, cx - 1, 40, 2, 12);
                    g.FillRectangle(red, cx + 1, 40, 8, 5);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeCrowd()
    {
        Bitmap bmp = new Bitmap(TileW, 100, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            Random rnd = new Random(21);
            using (SolidBrush stand = new SolidBrush(Color.FromArgb(255, 32, 28, 74)))
            {
                g.FillRectangle(stand, 0, 0, TileW, 100);
            }
            Color[] clothes =
            {
                Color.FromArgb(255, 200, 60, 70), Color.FromArgb(255, 70, 110, 220), Color.FromArgb(255, 230, 190, 60),
                Color.FromArgb(255, 70, 170, 100), Color.FromArgb(255, 160, 80, 200), Color.FromArgb(255, 230, 230, 240), Color.FromArgb(255, 230, 130, 50)
            };
            Color[] skins = { Color.FromArgb(255, 244, 206, 170), Color.FromArgb(255, 214, 160, 120), Color.FromArgb(255, 160, 110, 80), Color.FromArgb(255, 250, 220, 190) };
            for (int row = 0; row < 9; row++)
            {
                int y = 4 + row * 10;
                float dim = 0.45f + row * 0.07f;
                for (int x = (row & 1) * 3; x < TileW; x += 7)
                {
                    Color body = clothes[rnd.Next(clothes.Length)];
                    Color skin = skins[rnd.Next(skins.Length)];
                    Color bodyD = Color.FromArgb(255, (int)(body.R * dim), (int)(body.G * dim), (int)(body.B * dim));
                    Color skinD = Color.FromArgb(255, (int)(skin.R * dim), (int)(skin.G * dim), (int)(skin.B * dim));
                    using (SolidBrush b = new SolidBrush(bodyD))
                    using (SolidBrush s = new SolidBrush(skinD))
                    using (SolidBrush hair = new SolidBrush(Color.FromArgb(255, (int)(60 * dim), (int)(40 * dim), (int)(30 * dim))))
                    {
                        g.FillRectangle(b, x, y + 5, 6, 6);
                        g.FillRectangle(s, x + 1, y, 4, 4);
                        g.FillRectangle(hair, x + 1, y, 4, 1);
                        if (rnd.Next(9) == 0) g.FillRectangle(s, x - 1, y + 2, 1, 4);     // a raised arm
                    }
                }
                using (SolidBrush rail = new SolidBrush(Color.FromArgb(255, 20, 16, 50)))
                {
                    g.FillRectangle(rail, 0, y + 11, TileW, 1);
                }
            }
            // flags and banners in the stands
            using (SolidBrush red = new SolidBrush(Color.FromArgb(255, 220, 50, 60)))
            using (SolidBrush yel = new SolidBrush(Color.FromArgb(255, 250, 210, 70)))
            {
                for (int k = 0; k < 16; k++)
                {
                    int x = rnd.Next(TileW);
                    g.FillRectangle(red, x, 0, 10, 8);
                    g.FillRectangle(yel, x + 3, 2, 4, 4);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeCanopy()
    {
        Bitmap bmp = new Bitmap(TileW, 40, PixelFormat.Format32bppPArgb);
        using (Graphics g = Pixel(bmp))
        {
            using (SolidBrush red = new SolidBrush(Color.FromArgb(255, 200, 36, 52)))
            using (SolidBrush white = new SolidBrush(Color.FromArgb(255, 244, 244, 252)))
            using (SolidBrush shade = new SolidBrush(Color.FromArgb(70, 0, 0, 30)))
            using (SolidBrush gold = new SolidBrush(Color.FromArgb(255, 250, 208, 60)))
            {
                for (int x = 0; x < TileW; x += 24)
                {
                    g.FillRectangle(((x / 24) & 1) == 0 ? red : white, x, 0, 24, 22);
                    // the scalloped edge
                    g.FillEllipse(((x / 24) & 1) == 0 ? red : white, x, 12, 24, 20);
                    g.FillRectangle(shade, x + 14, 0, 10, 22);
                }
                g.FillRectangle(gold, 0, 26, TileW, 2);
            }
        }
        return bmp;
    }
}
