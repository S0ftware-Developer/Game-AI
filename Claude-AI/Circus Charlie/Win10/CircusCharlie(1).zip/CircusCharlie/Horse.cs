namespace CircusCharlie;

/// <summary>The galloping horse of the fifth act. Horse and rider jump together as one unit.</summary>
public sealed class Horse
{
    public float X, Y, VY;               // Y is the hoof line
    public float Phase;
    public float Speed;
    public bool OnGround = true;
    public float Squash;

    public RectangleF Hitbox
    {
        get { return new RectangleF(X - 17f, Y - 48f, 34f, 48f); }
    }

    public void Reset(float x)
    {
        X = x;
        Y = GameSettings.GroundY;
        VY = 0f;
        Phase = 0f;
        Speed = 0f;
        OnGround = true;
        Squash = 0f;
    }
}
