namespace CircusCharlie;

/// <summary>A swinging trapeze: a pendulum hanging from the tent roof. Charlie holds the bar with his hands.</summary>
public sealed class Trapeze
{
    public float AnchorX, AnchorY, Length;
    public float Amp, Omega, Phase;
    public float Theta, ThetaDot;
    public float BarX, BarY;

    public void Update(float time)
    {
        float a = time * Omega + Phase;
        Theta = Amp * (float)Math.Sin(a);
        ThetaDot = Amp * Omega * (float)Math.Cos(a);
        BarX = AnchorX + Length * (float)Math.Sin(Theta);
        BarY = AnchorY + Length * (float)Math.Cos(Theta);
    }

    /// <summary>The velocity of the bar (and so of a hanging Charlie) at this moment.</summary>
    public void BarVelocity(out float vx, out float vy)
    {
        vx = Length * (float)Math.Cos(Theta) * ThetaDot;
        vy = -Length * (float)Math.Sin(Theta) * ThetaDot;
    }
}
