using System.Drawing.Drawing2D;

namespace CircusCharlie;

/// <summary>
/// All pixel-art drawing of characters, animals, props and effects. Everything is built from hard-edged blocks on the small
/// canvas; Charlie is drawn in a design grid and may be enlarged by an integer scale for the title screen.
/// </summary>
public sealed class Sprites : IDisposable
{
    private static readonly Color Outline = Color.FromArgb(255, 28, 18, 40);
    private static readonly Color Face = Color.FromArgb(255, 254, 246, 240);
    private static readonly Color Red = Color.FromArgb(255, 232, 52, 50);
    private static readonly Color RedDark = Color.FromArgb(255, 164, 28, 40);
    private static readonly Color Blue = Color.FromArgb(255, 52, 96, 214);
    private static readonly Color BlueDark = Color.FromArgb(255, 30, 56, 150);
    private static readonly Color Yellow = Color.FromArgb(255, 252, 208, 60);
    private static readonly Color White = Color.FromArgb(255, 252, 252, 255);

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fText = new Font("Consolas", 10f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly Font fSmall = new Font("Consolas", 8f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly StringFormat sfCenter = new StringFormat();
    private readonly PointF[]?[] polyCache = new PointF[17][];
    private Graphics gg = null!;
    private float ox, oy;
    private int sc = 1;
    private int fac = 1;

    public Sprites()
    {
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        sfCenter.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private static Color Mix(Color a, Color b, float t)
    {
        t = Math.Max(0f, Math.Min(1f, t));
        return Color.FromArgb(a.A, (int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private void Begin(Graphics g, float x, float y, int scale, int facing)
    {
        gg = g;
        ox = x;
        oy = y;
        sc = scale;
        fac = facing >= 0 ? 1 : -1;
    }

    /// <summary>A block in the design grid, mirrored by the facing direction.</summary>
    private void M(Color c, float x, float y, float w, float h)
    {
        float lx = fac > 0 ? x : -x - w;
        int ix = (int)Math.Round(ox + lx * sc);
        int iy = (int)Math.Round(oy + y * sc);
        int iw = Math.Max(1, (int)Math.Round(ox + (lx + w) * sc) - ix);
        int ih = Math.Max(1, (int)Math.Round(oy + (y + h) * sc) - iy);
        gg.FillRectangle(B(c), ix, iy, iw, ih);
    }

    private void Ml(Color c, float x, float y, float w, float h)
    {
        M(Outline, x - 1, y - 1, w + 2, h + 2);
        M(c, x, y, w, h);
    }

    private void Em(Color c, float x, float y, float w, float h)
    {
        float lx = fac > 0 ? x : -x - w;
        int ix = (int)Math.Round(ox + lx * sc);
        int iy = (int)Math.Round(oy + y * sc);
        int iw = Math.Max(1, (int)Math.Round(ox + (lx + w) * sc) - ix);
        int ih = Math.Max(1, (int)Math.Round(oy + (y + h) * sc) - iy);
        gg.FillEllipse(B(c), ix, iy, iw, ih);
    }

    private void Eo(Color c, float x, float y, float w, float h)
    {
        Em(Outline, x - 1, y - 1, w + 2, h + 2);
        Em(c, x, y, w, h);
    }

    private void Pm(Color c, params float[] pts)
    {
        int n = pts.Length / 2;
        PointF[] arr = polyCache[n] ??= new PointF[n];
        for (int i = 0; i < n; i++)
        {
            float x = fac > 0 ? pts[i * 2] : -pts[i * 2];
            arr[i] = new PointF((float)Math.Round(ox + x * sc), (float)Math.Round(oy + pts[i * 2 + 1] * sc));
        }
        gg.FillPolygon(B(c), arr);
    }

    // ------------------------------------------------------------------ Charlie

    public void DrawCharlie(Graphics g, Charlie c, float time)
    {
        if (c.Dying)
        {
            float t = c.DeathTimer;
            if (t < 0.45f)
            {
                DrawCharlieAt(g, c.X, c.Y, Pose.Jump, c.Facing, time, 1, ((int)(t * 24f) & 1) == 0 ? 0.8f : 0f);
            }
            else
            {
                int face = ((int)(t * 14f) & 1) == 0 ? 1 : -1;
                DrawCharlieAt(g, c.X, c.Y, Pose.Fly, face, time, 1, 0f);
                for (int i = 0; i < 3; i++)
                {
                    float a = time * 7f + i * 2.1f;
                    Begin(g, c.X, c.Y, 1, 1);
                    M(Yellow, (float)Math.Cos(a) * 10f - 1, -48f + (float)Math.Sin(a) * 3f, 3, 3);
                }
            }
            return;
        }
        if (c.Invuln > 0f && c.Invuln < 100f && ((int)(time * 16f) & 1) == 0) return;
        Pose p = c.Pose;
        DrawCharlieAt(g, c.X, c.Y, p, c.Facing, time + c.Anim, 1, 0f);
    }

    /// <summary>Draws Charlie with his feet (or seat) at the given point.</summary>
    public void DrawCharlieAt(Graphics g, float x, float y, Pose pose, int facing, float time, int scale, float flash)
    {
        Begin(g, x, y, scale, facing);
        Color face = flash > 0f ? Color.White : Face;
        Color jacket = flash > 0f ? Color.FromArgb(255, 255, 160, 160) : Red;
        float step = (float)Math.Sin(time * 14f);
        bool run = pose == Pose.Run || pose == Pose.Balance;
        float bob = pose == Pose.Stand || pose == Pose.Ride ? (float)Math.Round(Math.Sin(time * 5f) * 0.7) : 0f;
        float down = 0f;                     // how far the upper body sits lower than when standing
        if (pose == Pose.Ride) down = 10f;
        else if (pose == Pose.Land) down = 3f;
        else if (pose == Pose.Hang) down = 5f;
        else if (pose == Pose.Cheer) bob = -(float)Math.Round(Math.Abs(Math.Sin(time * 9f)) * 3f);
        float top = down + bob;

        // legs and shoes
        Color shoe = Color.FromArgb(255, 230, 40, 52);
        Color shoeDark = Color.FromArgb(255, 150, 20, 36);
        if (pose == Pose.Ride)
        {
            // seated: legs hang over the animal's flank
            Ml(Blue, -4, -3, 8, 7);
            Ml(White, -2, -1, 3, 4);
            Ml(shoe, 0, 4, 10, 6);
            M(shoeDark, 0, 8, 10, 2);
            Ml(shoe, -6, 3, 9, 6);
            M(shoeDark, -6, 7, 9, 2);
        }
        else if (pose == Pose.Jump || pose == Pose.Fly)
        {
            // legs apart in the air
            Ml(Blue, -9, -13, 5, 7);
            Ml(shoe, -14, -7, 10, 5);
            M(shoeDark, -14, -3, 10, 1);
            Ml(Blue, 1, -12, 5, 6);
            Ml(shoe, 3, -7, 10, 5);
            M(shoeDark, 3, -3, 10, 1);
        }
        else if (pose == Pose.Hang)
        {
            float sw = (float)Math.Round(Math.Sin(time * 6f) * 1.5);
            Ml(Blue, -5, -12 + down, 4, 9);
            Ml(Blue, 1, -12 + down, 4, 9);
            Ml(shoe, -5 + sw, -4 + down, 9, 5);
            Ml(shoe, 0 + sw, -4 + down, 9, 5);
            M(shoeDark, -5 + sw, -1 + down, 9, 1);
            M(shoeDark, 0 + sw, -1 + down, 9, 1);
        }
        else
        {
            float a = run ? step * 4f : 0f;
            float lift1 = run && step > 0 ? 3f : 0f;
            float lift2 = run && step < 0 ? 3f : 0f;
            float cr = pose == Pose.Land ? 3f : 0f;
            Ml(Blue, -5 - a * 0.5f, -13 + cr, 4, 9 - lift1 - cr);
            M(White, -5 - a * 0.5f, -10 + cr, 4, 2);
            Ml(shoe, -6 - a, -5 - lift1, 10, 5);
            M(shoeDark, -6 - a, -1 - lift1, 10, 1);
            Ml(Blue, 1 + a * 0.5f, -13 + cr, 4, 9 - lift2 - cr);
            M(White, 1 + a * 0.5f, -10 + cr, 4, 2);
            Ml(shoe, 0 + a, -5 - lift2, 11, 5);
            M(shoeDark, 0 + a, -1 - lift2, 11, 1);
            M(Color.FromArgb(255, 255, 140, 150), 2 + a, -4 - lift2, 3, 1);
        }

        // arms (behind the body)
        float shoulder = -22 + top;
        switch (pose)
        {
            case Pose.Balance:
                Ml(jacket, -15, shoulder, 8, 3);
                Ml(White, -19, shoulder - 1, 5, 5);
                break;
            case Pose.Jump:
            case Pose.Fly:
            case Pose.Cheer:
                Ml(jacket, -9, shoulder - 8, 3, 9);
                Ml(White, -10, shoulder - 13, 5, 5);
                break;
            case Pose.Hang:
                Ml(jacket, -7, -42, 3, 28);
                Ml(White, -8, -48, 5, 6);
                break;
            default:
                {
                    float sw = run ? step * 2f : 0f;
                    Ml(jacket, -10, shoulder + sw * 0.3f, 3, 8);
                    Ml(White, -10, shoulder + 7 + sw, 5, 4);
                    break;
                }
        }

        // body: jacket, shirt, buttons and the big bow tie
        Ml(jacket, -7, -24 + top, 14, 11);
        M(RedDark, -7, -15 + top, 14, 2);
        M(White, -1, -23 + top, 3, 9);
        M(Yellow, 0, -21 + top, 1, 1);
        M(Yellow, 0, -18 + top, 1, 1);
        M(Color.FromArgb(255, 255, 120, 110), -6, -23 + top, 2, 3);
        Ml(Yellow, -5, -26 + top, 10, 4);
        M(Color.FromArgb(255, 220, 150, 20), -5, -23 + top, 10, 1);
        M(Red, -1, -25 + top, 2, 2);

        // front arm
        switch (pose)
        {
            case Pose.Balance:
                Ml(jacket, 7, shoulder, 8, 3);
                Ml(White, 15, shoulder - 1, 5, 5);
                break;
            case Pose.Jump:
            case Pose.Fly:
            case Pose.Cheer:
                Ml(jacket, 6, shoulder - 8 - (pose == Pose.Cheer ? (float)Math.Round(Math.Sin(time * 12f) * 2f) : 0f), 3, 9);
                Ml(White, 5, shoulder - 13 - (pose == Pose.Cheer ? (float)Math.Round(Math.Sin(time * 12f) * 2f) : 0f), 5, 5);
                break;
            case Pose.Hang:
                Ml(jacket, 5, -42, 3, 28);
                Ml(White, 4, -48, 5, 6);
                break;
            default:
                {
                    float sw = run ? -step * 2f : 0f;
                    Ml(jacket, 6, shoulder + sw * 0.3f, 3, 8);
                    Ml(White, 6, shoulder + 7 + sw, 5, 4);
                    break;
                }
        }

        // the head: hair, face, nose, eyes, smile and the little blue hat
        float hy = -36 + top;
        Eo(Red, -10, hy + 1, 6, 8);
        Eo(Red, 4, hy + 1, 6, 8);
        Eo(Red, -6, hy - 1, 12, 5);
        Eo(face, -6, hy, 12, 11);
        M(Color.FromArgb(255, 255, 170, 190), -5, hy + 7, 2, 2);
        Em(White, -3, hy + 2, 4, 5);
        Em(White, 1, hy + 2, 4, 5);
        M(Outline, -1, hy + 3, 2, 3);
        M(Outline, 3, hy + 3, 2, 3);
        M(Outline, -4, hy + 1, 4, 1);
        M(Outline, 1, hy + 1, 4, 1);
        Eo(Color.FromArgb(255, 240, 36, 40), 1, hy + 5, 5, 5);
        M(Color.FromArgb(255, 255, 150, 150), 2, hy + 5, 2, 2);
        M(Color.FromArgb(255, 200, 24, 40), -3, hy + 9, 5, 1);
        if (pose == Pose.Cheer) { M(Outline, -3, hy + 9, 6, 2); M(Color.FromArgb(255, 230, 60, 70), -2, hy + 10, 4, 1); }
        // hat
        Ml(Blue, -7, hy - 3, 14, 3);
        Ml(Blue, -4, hy - 9, 8, 7);
        M(Yellow, -4, hy - 5, 8, 2);
        M(Color.FromArgb(255, 110, 150, 255), -3, hy - 8, 2, 2);
    }

    // ------------------------------------------------------------------ the lion

    public void DrawLion(Graphics g, float x, float ground, float phase, float time)
    {
        Begin(g, x, ground, 1, 1);
        Color fur = Color.FromArgb(255, 232, 170, 64);
        Color furD = Color.FromArgb(255, 186, 118, 34);
        Color mane = Color.FromArgb(255, 190, 92, 28);
        Color maneD = Color.FromArgb(255, 130, 56, 20);
        float s1 = (float)Math.Sin(phase);
        float s2 = (float)Math.Sin(phase + 3.14f);
        float bounce = (float)Math.Round(Math.Abs(Math.Sin(phase)) * 1.5);
        Em(Color.FromArgb(70, 0, 0, 0), -26, -3, 56, 6);
        // the legs: the far pair first
        DrawLionLeg(-17 + s2 * 6, bounce, furD, s2);
        DrawLionLeg(13 + s2 * 6, bounce, furD, s2);
        // tail with a tuft
        Pm(furD, -23, -22 - bounce, -30, -28 - bounce, -34, -26 - bounce, -26, -18 - bounce);
        Eo(mane, -37, -34 - bounce + (float)Math.Round(Math.Sin(time * 8f)), 7, 8);
        // body
        Eo(fur, -24, -27 - bounce, 40, 17);
        Em(furD, -22, -16 - bounce, 36, 6);
        Em(Color.FromArgb(255, 250, 214, 130), -16, -26 - bounce, 22, 5);
        DrawLionLeg(-17 + s1 * 6, bounce, fur, s1);
        DrawLionLeg(13 + s1 * 6, bounce, fur, s1);
        // mane and face
        Eo(maneD, 6, -40 - bounce, 28, 28);
        Eo(mane, 8, -38 - bounce, 24, 24);
        for (int i = 0; i < 8; i++)
        {
            float a = i * 0.785f;
            M(maneD, 20 + (float)Math.Cos(a) * 12 - 1, -26 - bounce + (float)Math.Sin(a) * 12 - 1, 3, 3);
        }
        Eo(fur, 13, -33 - bounce, 15, 15);
        Em(Color.FromArgb(255, 252, 226, 160), 17, -26 - bounce, 11, 7);
        M(Color.FromArgb(255, 70, 30, 30), 24, -27 - bounce, 4, 3);
        M(Outline, 17, -31 - bounce, 3, 3);
        M(White, 17, -31 - bounce, 1, 1);
        M(Color.FromArgb(255, 220, 60, 70), 20, -22 - bounce, 6, 2);
        M(Outline, 22, -23 - bounce, 1, 3);
        M(fur, 12, -38 - bounce, 4, 4);
        M(fur, 25, -38 - bounce, 4, 4);
    }

    private void DrawLionLeg(float lx, float bounce, Color c, float swing)
    {
        float lift = swing > 0.4f ? 4f : 0f;
        M(Outline, lx - 3, -14 - bounce, 8, 12 - lift + bounce);
        M(c, lx - 2, -13 - bounce, 6, 10 - lift + bounce);
        M(Color.FromArgb(255, 150, 90, 30), lx - 3 + swing * 1.5f, -4 - lift, 8, 3);
    }

    // ------------------------------------------------------------------ the horse

    public void DrawHorse(Graphics g, float x, float ground, float phase, bool onGround, float squash, float time)
    {
        Begin(g, x, ground, 1, 1);
        Color coat = Color.FromArgb(255, 168, 96, 48);
        Color coatD = Color.FromArgb(255, 112, 60, 28);
        Color mane = Color.FromArgb(255, 36, 24, 24);
        float s1 = (float)Math.Sin(phase);
        float s2 = (float)Math.Sin(phase + 3.14f);
        float bounce = onGround ? (float)Math.Round(Math.Abs(Math.Sin(phase)) * 2) : 0f;
        float sq = squash * 2f;
        Em(Color.FromArgb(70, 0, 0, 0), -30, -3, 64, 6);
        if (onGround)
        {
            DrawHorseLeg(-18, s2, bounce, coatD, 1);
            DrawHorseLeg(16, s2, bounce, coatD, -1);
        }
        else
        {
            // legs stretched out in the jump
            Pm(coatD, -18, -16, -34, -10, -34, -6, -16, -10);
            Pm(coatD, 16, -16, 30, -26, 33, -22, 18, -12);
        }
        // tail
        Pm(mane, -24, -34 - bounce, -38, -26 + (float)Math.Round(Math.Sin(time * 9f) * 2), -36, -14, -22, -24 - bounce);
        // body and neck
        Eo(coat, -26, -36 - bounce + sq, 46, 20 - sq);
        Em(coatD, -22, -22 - bounce, 40, 6);
        Eo(coat, 8, -34 - bounce, 16, 12);
        Pm(coat, 12, -40 - bounce, 26, -52 - bounce, 32, -46 - bounce, 22, -32 - bounce);
        Pm(mane, 12, -42 - bounce, 24, -56 - bounce, 28, -52 - bounce, 16, -36 - bounce);
        // head
        Eo(coat, 24, -56 - bounce, 16, 10);
        Pm(coat, 30, -52 - bounce, 42, -46 - bounce, 41, -42 - bounce, 30, -44 - bounce);
        M(Color.FromArgb(255, 70, 40, 30), 40, -46 - bounce, 3, 3);
        M(Outline, 28, -54 - bounce, 2, 2);
        M(coatD, 26, -59 - bounce, 3, 4);
        M(Color.FromArgb(255, 230, 190, 70), 33, -53 - bounce, 6, 1);
        // the saddle
        Eo(Color.FromArgb(255, 220, 50, 60), -10, -39 - bounce + sq, 16, 6);
        M(Yellow, -10, -37 - bounce + sq, 16, 1);
        M(Yellow, -3, -33 - bounce, 2, 8);
        if (onGround)
        {
            DrawHorseLeg(-18, s1, bounce, coat, 1);
            DrawHorseLeg(16, s1, bounce, coat, -1);
        }
        else
        {
            Pm(coat, -16, -16, -32, -6, -32, -2, -14, -8);
            Pm(coat, 14, -16, 28, -22, 31, -18, 16, -10);
        }
    }

    private void DrawHorseLeg(float lx, float swing, float bounce, Color c, int dir)
    {
        float lift = swing > 0.3f ? 6f : 0f;
        float reach = swing * 7f;
        M(Outline, lx - 3 + reach, -18 - bounce, 8, 17 - lift + bounce);
        M(c, lx - 2 + reach, -17 - bounce, 6, 15 - lift + bounce);
        M(Color.FromArgb(255, 40, 30, 30), lx - 3 + reach, -4 - lift, 8, 4);
    }

    // ------------------------------------------------------------------ monkeys

    public void DrawMonkey(Graphics g, Monkey m, float time)
    {
        int facing = m.Reversing ? 1 : -1;
        Begin(g, m.X, m.Y, 1, facing);
        Color fur, furD, vest;
        switch (m.Kind)
        {
            case MonkeyKind.Fast: fur = Color.FromArgb(255, 150, 64, 36); furD = Color.FromArgb(255, 100, 36, 24); vest = Color.FromArgb(255, 240, 200, 60); break;
            case MonkeyKind.Reverser: fur = Color.FromArgb(255, 112, 112, 130); furD = Color.FromArgb(255, 70, 70, 92); vest = Color.FromArgb(255, 60, 120, 220); break;
            case MonkeyKind.Hopper: fur = Color.FromArgb(255, 196, 140, 80); furD = Color.FromArgb(255, 140, 90, 46); vest = Color.FromArgb(255, 80, 190, 100); break;
            default: fur = Color.FromArgb(255, 140, 86, 46); furD = Color.FromArgb(255, 92, 54, 28); vest = Color.FromArgb(255, 220, 60, 60); break;
        }
        float step = (float)Math.Sin(time * (m.Kind == MonkeyKind.Fast ? 22f : 14f) + m.X * 0.1f);
        // tail curling up behind
        M(Outline, -10, -13, 4, 9); M(fur, -9, -12, 2, 8);
        M(Outline, -12, -15, 5, 4); M(fur, -11, -14, 3, 2);
        // legs
        M(Outline, -5 + step * 2, -5, 4, 5); M(furD, -4 + step * 2, -5, 2, 4);
        M(Outline, 1 - step * 2, -5, 4, 5); M(furD, 2 - step * 2, -5, 2, 4);
        // body with a vest
        Eo(fur, -6, -13, 12, 10);
        M(vest, -4, -11, 8, 5);
        // arms out for balance
        M(Outline, 5, -12 + step, 6, 3); M(fur, 6, -11 + step, 4, 1);
        // head with face
        Eo(fur, -2, -21, 11, 10);
        Em(Color.FromArgb(255, 238, 200, 150), 2, -18, 7, 6);
        M(Outline, 4, -19, 1, 2);
        M(Outline, 7, -19, 1, 2);
        M(Color.FromArgb(255, 120, 50, 40), 4, -14, 3, 1);
        Eo(fur, -4, -19, 4, 4);
        Eo(Color.FromArgb(255, 238, 200, 150), -3, -18, 2, 2);
        if (m.Kind == MonkeyKind.Fast) { M(Red, -1, -24, 8, 3); M(Outline, -1, -24, 8, 1); }
        if (m.Kind == MonkeyKind.Hopper) { M(Yellow, 0, -23, 3, 2); M(Yellow, 4, -23, 3, 2); M(Red, 3, -23, 1, 2); }
    }

    // ------------------------------------------------------------------ balls, trampolines, trapezes

    private static readonly Color[][] BallColors =
    {
        new[] { Color.FromArgb(255, 232, 50, 50), Color.FromArgb(255, 252, 252, 255) },
        new[] { Color.FromArgb(255, 52, 110, 230), Color.FromArgb(255, 252, 210, 60) },
        new[] { Color.FromArgb(255, 50, 180, 80), Color.FromArgb(255, 252, 252, 255) },
        new[] { Color.FromArgb(255, 150, 70, 210), Color.FromArgb(255, 252, 210, 60) }
    };

    public void DrawBall(Graphics g, CircusBall b, float time)
    {
        float sq = b.Squash * 0.14f;
        float w = b.R * 2f * (1f + sq);
        float h = b.R * 2f * (1f - sq);
        float x = b.X - w / 2f;
        float y = b.Y + b.R - h;
        Color[] pal = BallColors[b.Color % BallColors.Length];
        g.FillEllipse(B(Color.FromArgb(60, 0, 0, 0)), (int)(b.X - b.R), (int)(GameSettings.ViewH - 10), (int)(b.R * 2), 6);
        g.FillEllipse(B(Outline), (int)x - 1, (int)y - 1, (int)w + 2, (int)h + 2);
        float roll = b.Roll + b.X * 0.04f;
        for (int i = 0; i < 6; i++)
        {
            float start = (roll * 57.3f) + i * 60f;
            g.FillPie(B(pal[i & 1]), (int)x, (int)y, (int)w, (int)h, start, 60f);
        }
        // shading and highlight
        g.FillPie(B(Color.FromArgb(60, 0, 0, 40)), (int)x, (int)y, (int)w, (int)h, 20f, 150f);
        g.FillEllipse(B(Color.FromArgb(200, 255, 255, 255)), (int)(x + w * 0.2f), (int)(y + h * 0.14f), (int)Math.Max(3, w * 0.2f), (int)Math.Max(2, h * 0.14f));
        if (b.IsGoal)
        {
            g.FillRectangle(B(Outline), (int)b.X - 1, (int)(b.Y - b.R - 24), 3, 24);
            g.FillRectangle(B(Red), (int)b.X + 2, (int)(b.Y - b.R - 24), 14, 8);
            g.FillRectangle(B(White), (int)b.X + 2, (int)(b.Y - b.R - 20), 14, 2);
        }
    }

    public void DrawTrampoline(Graphics g, Trampoline t, float time)
    {
        int x = (int)Math.Round(t.X);
        int y = (int)Math.Round(t.Y);
        int sag = (int)Math.Round(t.Compress * 5f);
        int half = (int)t.Half;
        Begin(g, 0, 0, 1, 1);
        // the striped pedestal down to the arena floor
        int pw = half - 4;
        for (int py = y + 3; py < GameSettings.ViewH; py += 6)
        {
            Color c = (((py - y) / 6) & 1) == 0 ? Color.FromArgb(255, 232, 52, 52) : Color.FromArgb(255, 252, 252, 255);
            g.FillRectangle(B(c), x - pw, py, pw * 2, Math.Min(6, GameSettings.ViewH - py));
        }
        g.FillRectangle(B(Outline), x - pw - 1, y + 3, 1, GameSettings.ViewH);
        g.FillRectangle(B(Outline), x + pw, y + 3, 1, GameSettings.ViewH);
        if (t.IsGoal)
        {
            g.FillRectangle(B(Yellow), x - half, y - 2, half * 2, 5);
            g.FillRectangle(B(Outline), x - half, y - 3, half * 2, 1);
            g.FillRectangle(B(Outline), x - 1, y - 40, 3, 38);
            g.FillRectangle(B(Red), x + 2, y - 40, 20, 12);
            g.FillRectangle(B(White), x + 2, y - 36, 20, 3);
            g.FillRectangle(B(Yellow), x + 9, y - 38, 6, 6);
            return;
        }
        // the frame and the sagging net
        g.FillRectangle(B(Outline), x - half - 1, y - 2, half * 2 + 2, 6);
        g.FillRectangle(B(Color.FromArgb(255, 232, 52, 52)), x - half, y - 1, half * 2, 4);
        g.FillRectangle(B(Color.FromArgb(255, 252, 252, 255)), x - half + 4, y - 1, 4, 4);
        g.FillRectangle(B(Color.FromArgb(255, 252, 252, 255)), x + half - 8, y - 1, 4, 4);
        for (int i = -half + 6; i < half - 6; i += 2)
        {
            float k = 1f - (float)Math.Abs(i) / (half - 6);
            int d = (int)Math.Round(sag * k);
            g.FillRectangle(B(Color.FromArgb(255, 70, 90, 230)), x + i, y + 1 + d, 2, 3);
            g.FillRectangle(B(Color.FromArgb(255, 150, 190, 255)), x + i, y + 1 + d, 2, 1);
        }
    }

    public void DrawTrapeze(Graphics g, Trapeze t, bool held, float time)
    {
        float ax = t.AnchorX, ay = t.AnchorY, bx = t.BarX, by = t.BarY;
        Pen rope = P(Color.FromArgb(255, 220, 190, 140), 2f);
        g.DrawLine(rope, ax - 10f, ay, bx - 11f, by);
        g.DrawLine(rope, ax + 10f, ay, bx + 11f, by);
        P(Color.FromArgb(255, 120, 90, 60), 1f);
        g.DrawLine(tmpPen, ax - 9f, ay, bx - 10f, by);
        g.DrawLine(tmpPen, ax + 11f, ay, bx + 12f, by);
        // the bar with red and white stripes
        int ix = (int)Math.Round(bx);
        int iy = (int)Math.Round(by);
        g.FillRectangle(B(Outline), ix - 15, iy - 2, 30, 5);
        for (int i = -14; i < 14; i += 4)
            g.FillRectangle(B(((i + 14) / 4 & 1) == 0 ? Color.FromArgb(255, 232, 52, 52) : Color.FromArgb(255, 252, 252, 255)), ix + i, iy - 1, 4, 3);
        g.FillRectangle(B(Yellow), ix - 16, iy - 2, 2, 5);
        g.FillRectangle(B(Yellow), ix + 14, iy - 2, 2, 5);
        if (held) g.FillEllipse(B(Color.FromArgb(70, 255, 240, 140)), ix - 20, iy - 8, 40, 16);
    }

    // ------------------------------------------------------------------ obstacles, bags, knives

    private void Flame(float x, float baseY, float h, float w, float time, float seed)
    {
        float f1 = (float)Math.Sin(time * 14f + seed);
        float f2 = (float)Math.Sin(time * 19f + seed * 2f);
        Begin(gg, x, baseY, 1, 1);
        Pm(Color.FromArgb(255, 240, 70, 20), -w, 0, w, 0, w * 0.4f, -h * 0.6f + f1, f2 * 2f, -h - f1 * 2f, -w * 0.5f, -h * 0.55f);
        Pm(Color.FromArgb(255, 255, 170, 30), -w * 0.7f, 0, w * 0.7f, 0, w * 0.2f, -h * 0.5f, f1, -h * 0.8f, -w * 0.3f, -h * 0.45f);
        Pm(Color.FromArgb(255, 255, 240, 160), -w * 0.4f, 0, w * 0.4f, 0, 0, -h * 0.5f);
    }

    public void DrawObstacle(Graphics g, Obstacle o, float time)
    {
        gg = g;
        float x = o.X;
        float gy = o.Y;
        switch (o.Kind)
        {
            case ObstacleKind.FireBowl:
                Begin(g, x, gy, 1, 1);
                M(Outline, -9, -14, 18, 14);
                M(Color.FromArgb(255, 230, 170, 40), -8, -13, 16, 5);
                M(Color.FromArgb(255, 170, 110, 20), -6, -9, 12, 7);
                M(Color.FromArgb(255, 255, 230, 120), -7, -13, 5, 1);
                M(Color.FromArgb(255, 170, 110, 20), -3, -3, 6, 3);
                M(Color.FromArgb(255, 230, 170, 40), -8, -1, 16, 1);
                Flame(x, gy - 13f, 20f, 7f, time, x);
                break;
            case ObstacleKind.Hoop:
                {
                    // the pot at the bottom and the burning ring, seen from the side
                    Begin(g, x, gy, 1, 1);
                    M(Outline, -3, -44, 6, 44);
                    M(Color.FromArgb(255, 150, 110, 60), -2, -43, 4, 43);
                    M(Outline, -9, -12, 18, 12);
                    M(Color.FromArgb(255, 230, 170, 40), -8, -11, 16, 5);
                    M(Color.FromArgb(255, 170, 110, 20), -6, -7, 12, 6);
                    Flame(x, gy - 11f, 14f, 6f, time, x);
                    float cy = gy - 72f;
                    float fl = (float)Math.Sin(time * 16f + x);
                    g.FillEllipse(B(Color.FromArgb(255, 240, 70, 20)), (int)(x - 8), (int)(cy - 30), 16, 60);
                    g.FillEllipse(B(Color.FromArgb(255, 20, 10, 40)), (int)(x - 4), (int)(cy - 27), 8, 54);
                    g.FillEllipse(B(Color.FromArgb(255, 255, 180, 40)), (int)(x - 7), (int)(cy - 28), 5, 56);
                    g.FillEllipse(B(Color.FromArgb(255, 20, 10, 40)), (int)(x - 3), (int)(cy - 25), 6, 50);
                    for (int i = 0; i < 6; i++)
                    {
                        float a = time * 9f + i * 1.05f;
                        float fy = cy + (float)Math.Sin(a) * 28f;
                        g.FillRectangle(B(Color.FromArgb(255, 255, 230, 120)), (int)(x - 6 + (float)Math.Cos(a * 1.3f) * 2), (int)fy, 3, 4 + (int)(fl * 1.5f + 1.5f));
                    }
                    g.FillRectangle(B(Color.FromArgb(255, 180, 150, 110)), (int)x - 1, 0, 2, (int)(cy - 30));
                    break;
                }
            default:
                {
                    // a hurdle with striped rails
                    float h = o.Kind == ObstacleKind.TallHurdle ? 34f : 22f;
                    float half = o.Kind == ObstacleKind.WideHurdle ? 18f : 6f;
                    Begin(g, x, gy, 1, 1);
                    M(Outline, -half - 2, -h - 1, 5, h + 1);
                    M(Outline, half - 3, -h - 1, 5, h + 1);
                    M(Color.FromArgb(255, 252, 252, 255), -half - 1, -h, 3, h);
                    M(Color.FromArgb(255, 252, 252, 255), half - 2, -h, 3, h);
                    int rails = o.Kind == ObstacleKind.TallHurdle ? 3 : 2;
                    for (int r = 0; r < rails; r++)
                    {
                        float ry = -h + 2 + r * 10;
                        M(Outline, -half - 1, ry - 1, half * 2 + 2, 8);
                        for (float sx = -half; sx < half; sx += 4)
                            M(((int)((sx + half) / 4) & 1) == 0 ? Red : White, sx, ry, Math.Min(4f, half - sx), 6);
                    }
                    break;
                }
        }
    }

    public void DrawBag(Graphics g, MoneyBag b, float time)
    {
        if (b.Collected) return;
        int bob = (int)Math.Round(Math.Sin(b.Age * 4f + b.X) * 1.5);
        Begin(g, b.X, b.Y + bob, 1, 1);
        Eo(Color.FromArgb(255, 246, 200, 50), -7, -5, 14, 13);
        Em(Color.FromArgb(255, 200, 150, 20), -6, 1, 12, 7);
        M(Color.FromArgb(255, 255, 240, 130), -5, -3, 3, 3);
        M(Outline, -3, -8, 6, 4);
        M(Color.FromArgb(255, 246, 200, 50), -2, -9, 4, 3);
        M(Red, -4, -5, 8, 1);
        // the dollar sign
        M(Color.FromArgb(255, 90, 60, 10), -1, -2, 2, 9);
        M(Color.FromArgb(255, 90, 60, 10), -3, -1, 6, 1);
        M(Color.FromArgb(255, 90, 60, 10), -3, 2, 4, 1);
        M(Color.FromArgb(255, 90, 60, 10), -1, 4, 4, 1);
        M(Color.FromArgb(255, 90, 60, 10), -3, 6, 6, 1);
        if (((int)(b.Age * 5f + b.X) & 3) == 0) M(Color.White, 5, -8, 2, 2);
    }

    public void DrawKnife(Graphics g, Knife k)
    {
        Begin(g, k.X, k.Y, 1, -1);
        float spin = (float)Math.Abs(Math.Cos(k.Rot));
        float bh = 2f + 3f * spin;
        M(Outline, -13, -bh - 1, 22, bh * 2 + 2);
        M(Color.FromArgb(255, 220, 228, 240), -12, -bh, 16, bh * 2);
        M(White, -12, -bh, 16, 1);
        Pm(Color.FromArgb(255, 220, 228, 240), -12, -bh, -16, 0, -12, bh);
        M(Outline, 3, -3, 9, 6);
        M(Red, 4, -2, 7, 4);
        M(Yellow, 3, -3, 2, 6);
    }

    // ------------------------------------------------------------------ platforms

    public void DrawPlatform(Graphics g, float x, float top)
    {
        int ix = (int)Math.Round(x);
        int iy = (int)Math.Round(top);
        for (int py = iy + 4; py < GameSettings.ViewH; py += 6)
        {
            Color c = (((py - iy) / 6) & 1) == 0 ? Color.FromArgb(255, 232, 52, 52) : Color.FromArgb(255, 252, 252, 255);
            g.FillRectangle(B(c), ix - 42, py, 84, Math.Min(6, GameSettings.ViewH - py));
        }
        g.FillRectangle(B(Outline), ix - 46, iy - 1, 92, 7);
        g.FillRectangle(B(Yellow), ix - 45, iy, 90, 5);
        g.FillRectangle(B(Color.FromArgb(255, 220, 150, 20)), ix - 45, iy + 3, 90, 2);
        g.FillRectangle(B(Outline), ix - 1, iy - 44, 3, 44);
        g.FillRectangle(B(Red), ix + 2, iy - 44, 22, 13);
        g.FillRectangle(B(White), ix + 2, iy - 39, 22, 3);
        g.FillRectangle(B(Yellow), ix + 10, iy - 42, 6, 8);
    }

    public void DrawFinishPodium(Graphics g, float x, float ground, float time)
    {
        int ix = (int)Math.Round(x);
        int iy = (int)Math.Round(ground);
        g.FillRectangle(B(Outline), ix - 30, iy - 26, 62, 26);
        for (int i = 0; i < 6; i++)
            g.FillRectangle(B((i & 1) == 0 ? Color.FromArgb(255, 232, 52, 52) : Color.FromArgb(255, 252, 252, 255)), ix - 29 + i * 10, iy - 25, 10, 24);
        g.FillRectangle(B(Yellow), ix - 31, iy - 28, 64, 4);
        g.FillRectangle(B(Outline), ix - 1, iy - 70, 3, 44);
        float wave = (float)Math.Sin(time * 5f) * 2f;
        g.FillRectangle(B(Color.FromArgb(255, 60, 110, 230)), ix + 2, iy - 70, 26, 14);
        g.FillRectangle(B(Yellow), ix + 8, iy - 66 + (int)wave, 6, 6);
        // the finish tape
        g.FillRectangle(B(Color.White), ix - 120, iy - 3, 90, 2);
    }

    // ------------------------------------------------------------------ particles

    public void DrawParticles(Graphics g, ParticleSystem ps)
    {
        for (int i = 0; i < ps.Count; i++)
        {
            Particle p = ps.Items[i];
            float k = p.Life / p.MaxLife;
            int x = (int)Math.Round(p.X);
            int y = (int)Math.Round(p.Y);
            Color c = Color.FromArgb(255, p.R, p.G, p.B);
            switch (p.Kind)
            {
                case 0:
                    {
                        int s = Math.Max(1, (int)(p.Size * (1f + (1f - k))));
                        g.FillRectangle(B(Color.FromArgb(A(160 * k), p.R, p.G, p.B)), x - s / 2, y - s / 2, s, s);
                        break;
                    }
                case 1:
                    g.FillRectangle(B(c), x, y, 2, 2);
                    break;
                case 2:
                    {
                        int s = Math.Max(2, (int)(p.Size * 0.8f));
                        g.FillRectangle(B(c), x, y, s, s);
                        break;
                    }
                case 3:
                    {
                        float r = p.Size * (1f - k * 0.6f) * 0.9f;
                        for (int d = 0; d < 16; d++)
                        {
                            double a = d * 6.2832 / 16;
                            g.FillRectangle(B(c), x + (int)(Math.Cos(a) * r), y + (int)(Math.Sin(a) * r), 2, 2);
                        }
                        break;
                    }
                default:
                    {
                        int s = Math.Max(1, (int)(p.Size * k));
                        g.FillRectangle(B(c), x - s / 2, y - s / 2, s, s);
                        break;
                    }
            }
        }
        foreach (FloatText t in ps.Texts)
        {
            float a = Math.Min(1f, t.Life * 2f);
            if (a < 0.2f) continue;
            g.DrawString(t.Text, fText, B(Color.Black), (int)t.X + 1, (int)t.Y + 1, sfCenter);
            g.DrawString(t.Text, fText, B(Color.FromArgb(255, t.Color.R, t.Color.G, t.Color.B)), (int)t.X, (int)t.Y, sfCenter);
        }
    }
}
