using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace CircusCharlie;

/// <summary>
/// Draws everything on a 480 x 270 pixel canvas with hard edges and presents it scaled by two with nearest-neighbour
/// filtering. The copyright footer is drawn below the canvas at full resolution.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    private const int VW = GameSettings.ViewW;
    private const int VH = GameSettings.ViewH;
    private const int S = GameSettings.PixelScale;

    private static Rectangle ItemRect(int baseY, int i)
    {
        return new Rectangle(160, baseY + i * 24, 160, 20);
    }

    /// <summary>The clickable menu items of a screen, in window-logical coordinates.</summary>
    public static Rectangle[] RectsFor(GameState state)
    {
        Rectangle[] r;
        switch (state)
        {
            case GameState.Title:
                r = new Rectangle[2];
                for (int i = 0; i < 2; i++) r[i] = ItemRect(196, i);
                break;
            case GameState.Paused:
                r = new Rectangle[4];
                for (int i = 0; i < 4; i++) r[i] = ItemRect(100, i);
                break;
            case GameState.GameOver:
            case GameState.Victory:
                r = new Rectangle[2];
                for (int i = 0; i < 2; i++) r[i] = ItemRect(196, i);
                break;
            case GameState.Controls:
                r = new Rectangle[1];
                r[0] = ItemRect(238, 0);
                break;
            default:
                return new Rectangle[0];
        }
        for (int i = 0; i < r.Length; i++) r[i] = new Rectangle(r[i].X * S, r[i].Y * S, r[i].Width * S, r[i].Height * S);
        return r;
    }

    private readonly Bitmap canvas = new Bitmap(VW, VH, PixelFormat.Format32bppPArgb);
    private readonly Graphics gc;
    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Background bg = new Background();
    private readonly Sprites sprites = new Sprites();
    private readonly Font fSmall;
    private readonly Font fMid;
    private readonly Font fBig;
    private readonly Font fTitleA;
    private readonly Font fTitleB;
    private readonly Font fHead;
    private readonly Font fFooter;
    private readonly StringFormat sfTight = new StringFormat(StringFormat.GenericTypographic);
    private readonly StringFormat sfCenter = new StringFormat();
    private readonly StringFormat sfRight = new StringFormat();
    private readonly StringFormat sfLeft = new StringFormat();
    private readonly StringFormat sfFooter = new StringFormat();
    private readonly PointF[] tri = new PointF[3];

    public GameRenderer()
    {
        gc = Graphics.FromImage(canvas);
        gc.SmoothingMode = SmoothingMode.None;
        gc.InterpolationMode = InterpolationMode.NearestNeighbor;
        gc.PixelOffsetMode = PixelOffsetMode.Half;
        gc.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
        gc.CompositingQuality = CompositingQuality.HighSpeed;

        fSmall = new Font("Consolas", 9f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Consolas", 12f, FontStyle.Bold, GraphicsUnit.Pixel);
        fBig = new Font("Consolas", 22f, FontStyle.Bold, GraphicsUnit.Pixel);
        fTitleA = new Font("Impact", 40f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitleB = new Font("Impact", 44f, FontStyle.Regular, GraphicsUnit.Pixel);
        fHead = new Font("Impact", 26f, FontStyle.Regular, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfTight.FormatFlags |= StringFormatFlags.NoWrap;
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfFooter.Alignment = StringAlignment.Center;
        sfFooter.LineAlignment = StringAlignment.Center;
    }

    public void Dispose()
    {
        gc.Dispose();
        canvas.Dispose();
        tmp.Dispose();
        bg.Dispose();
        sprites.Dispose();
        fSmall.Dispose();
        fMid.Dispose();
        fBig.Dispose();
        fTitleA.Dispose();
        fTitleB.Dispose();
        fHead.Dispose();
        fFooter.Dispose();
        sfTight.Dispose();
        sfCenter.Dispose();
        sfRight.Dispose();
        sfLeft.Dispose();
        sfFooter.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private void Rect(Color c, int x, int y, int w, int h)
    {
        gc.FillRectangle(B(c), x, y, w, h);
    }

    private void Txt(string s, Font f, Color c, int x, int y, int align, bool shadow = true)
    {
        StringFormat sf = align == 0 ? sfLeft : (align == 1 ? sfCenter : sfRight);
        if (shadow) gc.DrawString(s, f, B(Color.FromArgb(255, 10, 8, 30)), x + 1, y + 1, sf);
        gc.DrawString(s, f, B(c), x, y, sf);
    }

    private void Panel(int x, int y, int w, int h, int alpha)
    {
        Rect(Color.FromArgb(alpha, 14, 12, 50), x, y, w, h);
        Color edge = Color.FromArgb(255, 252, 208, 60);
        Rect(edge, x, y, w, 2);
        Rect(edge, x, y + h - 2, w, 2);
        Rect(edge, x, y, 2, h);
        Rect(edge, x + w - 2, y, 2, h);
        Rect(Color.FromArgb(255, 220, 50, 60), x + 2, y + 2, w - 4, 1);
    }

    private static string FormatPoints(int v)
    {
        return v.ToString("D7");
    }

    private void MiniClown(int x, int y)
    {
        Rect(Color.FromArgb(255, 28, 18, 40), x, y + 3, 11, 10);
        Rect(Color.FromArgb(255, 254, 246, 240), x + 1, y + 4, 9, 8);
        Rect(Color.FromArgb(255, 232, 52, 50), x - 1, y + 4, 2, 5);
        Rect(Color.FromArgb(255, 232, 52, 50), x + 10, y + 4, 2, 5);
        Rect(Color.FromArgb(255, 240, 36, 40), x + 5, y + 7, 3, 3);
        Rect(Color.FromArgb(255, 28, 18, 40), x + 3, y + 6, 1, 2);
        Rect(Color.FromArgb(255, 52, 96, 214), x + 2, y, 7, 4);
        Rect(Color.FromArgb(255, 252, 208, 60), x + 2, y + 3, 7, 1);
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        gc.ResetClip();
        gc.ResetTransform();
        gc.Clear(Color.Black);
        switch (e.State)
        {
            case GameState.Title: DrawTitle(e); break;
            case GameState.Controls: DrawControls(e); break;
            default:
                DrawScene(e);
                DrawHud(e);
                if (e.State == GameState.Intro) DrawIntro(e);
                else if (e.State == GameState.Paused) DrawPause(e);
                else if (e.State == GameState.LevelComplete) DrawComplete(e);
                else if (e.State == GameState.GameOver) DrawGameOver(e);
                else if (e.State == GameState.Victory) DrawVictory(e);
                break;
        }

        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;
        float scale = Math.Min(clientW / (float)GameSettings.LogicalW, clientH / (float)GameSettings.LogicalH);
        float offX = (clientW - GameSettings.LogicalW * scale) / 2f;
        float offY = (clientH - GameSettings.LogicalH * scale) / 2f;
        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.SmoothingMode = SmoothingMode.None;
            g.DrawImage(canvas, new Rectangle(0, 0, VW * S, VH * S), 0, 0, VW, VH, GraphicsUnit.Pixel);

            Rectangle foot = new Rectangle(0, VH * S, GameSettings.LogicalW, GameSettings.FooterH);
            using (SolidBrush back = new SolidBrush(Color.FromArgb(255, 14, 12, 44)))
            using (SolidBrush line = new SolidBrush(Color.FromArgb(255, 252, 208, 60)))
            using (SolidBrush text = new SolidBrush(Color.FromArgb(255, 244, 244, 252)))
            {
                g.FillRectangle(back, foot);
                g.FillRectangle(line, 0, foot.Y, GameSettings.LogicalW, 2);
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                g.DrawString(FooterText, fFooter, text, new RectangleF(0f, foot.Y + 3f, GameSettings.LogicalW, foot.Height - 3f), sfFooter);
            }
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ the acts

    private void DrawScene(GameEngine e)
    {
        LevelManager L = e.Level;
        float time = e.GameTime;
        int cam = (int)Math.Round(L.CameraX);
        bg.Draw(gc, L.Level, cam, time);

        GraphicsState st = gc.Save();
        gc.TranslateTransform(-cam, 0);
        float gy = GameSettings.GroundY;
        switch (L.Level)
        {
            case 1:
                bg.DrawMeterPosts(gc, L.EndX, cam, gy);
                sprites.DrawFinishPodium(gc, L.EndX + 80f, gy, time);
                foreach (Obstacle o in L.Obstacles) if (o.X > cam - 40 && o.X < cam + VW + 40) sprites.DrawObstacle(gc, o, time);
                foreach (MoneyBag b in L.Bags) if (b.X > cam - 20 && b.X < cam + VW + 20) sprites.DrawBag(gc, b, time);
                sprites.DrawLion(gc, L.Lion.X, gy, L.Lion.Phase, time);
                sprites.DrawCharlie(gc, L.Charlie, time);
                break;
            case 2:
                bg.DrawRope(gc, LevelManager.RopeY, L.EndX, L.Charlie.X, time);
                sprites.DrawPlatform(gc, 8f, LevelManager.RopeY);
                sprites.DrawPlatform(gc, L.EndX + 52f, LevelManager.RopeY);
                foreach (MoneyBag b in L.Bags) if (b.X > cam - 20 && b.X < cam + VW + 20) sprites.DrawBag(gc, b, time);
                foreach (Monkey m in L.Monkeys) if (m.Active) sprites.DrawMonkey(gc, m, time);
                sprites.DrawCharlie(gc, L.Charlie, time);
                break;
            case 3:
                foreach (Trampoline t in L.Trampolines) if (t.X > cam - 60 && t.X < cam + VW + 60) sprites.DrawTrampoline(gc, t, time);
                foreach (MoneyBag b in L.Bags) if (b.X > cam - 20 && b.X < cam + VW + 20) sprites.DrawBag(gc, b, time);
                foreach (Knife k in L.Knives) if (k.Active) sprites.DrawKnife(gc, k);
                sprites.DrawCharlie(gc, L.Charlie, time);
                break;
            case 4:
                foreach (CircusBall b in L.Balls) if (b.X > cam - 50 && b.X < cam + VW + 50) sprites.DrawBall(gc, b, time);
                foreach (MoneyBag b in L.Bags) if (b.X > cam - 20 && b.X < cam + VW + 20) sprites.DrawBag(gc, b, time);
                sprites.DrawCharlie(gc, L.Charlie, time);
                break;
            case 5:
                bg.DrawMeterPosts(gc, L.EndX, cam, gy);
                sprites.DrawFinishPodium(gc, L.EndX + 90f, gy, time);
                foreach (Obstacle o in L.Obstacles) if (o.X > cam - 40 && o.X < cam + VW + 40) sprites.DrawObstacle(gc, o, time);
                foreach (MoneyBag b in L.Bags) if (b.X > cam - 20 && b.X < cam + VW + 20) sprites.DrawBag(gc, b, time);
                sprites.DrawHorse(gc, L.Horse.X, L.Horse.Y, L.Horse.Phase, L.Horse.OnGround, L.Horse.Squash, time);
                sprites.DrawCharlie(gc, L.Charlie, time);
                break;
            default:
                bg.DrawRoofRail(gc, cam, L.Trapezes);
                sprites.DrawPlatform(gc, L.PlatformX, LevelManager.PlatformTop);
                for (int i = 0; i < L.Trapezes.Count; i++)
                {
                    Trapeze t = L.Trapezes[i];
                    if (t.AnchorX > cam - 40 && t.AnchorX < cam + VW + 40) sprites.DrawTrapeze(gc, t, L.Holding == i, time);
                }
                foreach (MoneyBag b in L.Bags) if (b.X > cam - 20 && b.X < cam + VW + 20) sprites.DrawBag(gc, b, time);
                if (L.ShowPreview && L.Holding >= 0)
                {
                    for (int i = 1; i < L.Preview.Length; i += 1)
                    {
                        if ((i & 1) == 0) continue;
                        Rect(Color.FromArgb(220, 255, 250, 180), (int)L.Preview[i].X - 1, (int)L.Preview[i].Y - 1, 3, 3);
                    }
                }
                sprites.DrawCharlie(gc, L.Charlie, time);
                break;
        }
        sprites.DrawParticles(gc, e.Particles);
        gc.Restore(st);

        // warning arrows for knives that are about to fly in
        foreach (Knife k in L.Knives)
        {
            if (k.Active || k.Warn <= 0f) continue;
            if (((int)(k.Warn * 10f) & 1) == 0) continue;
            int ky = (int)k.Y;
            tri[0] = new PointF(VW - 22, ky);
            tri[1] = new PointF(VW - 10, ky - 7);
            tri[2] = new PointF(VW - 10, ky + 7);
            gc.FillPolygon(B(Color.FromArgb(255, 255, 60, 50)), tri);
            Rect(Color.FromArgb(255, 255, 230, 120), VW - 10, ky - 2, 5, 5);
        }
    }

    private void DrawHud(GameEngine e)
    {
        LevelManager L = e.Level;
        for (int i = 0; i < 3; i++) Rect(Color.FromArgb(210, 12 + i * 3, 10 + i * 3, 44 + i * 6), 0, i * 9, VW, 9);
        Rect(Color.FromArgb(255, 252, 208, 60), 0, 27, VW, 1);

        Txt("1UP", fSmall, Color.FromArgb(255, 252, 208, 60), 6, 8, 0);
        Txt(FormatPoints(e.Score), fMid, Color.White, 30, 8, 0);
        Txt("HI", fSmall, Color.FromArgb(255, 252, 208, 60), 118, 8, 0);
        Txt(FormatPoints(Math.Max(e.Scores.Best, e.Score)), fMid, Color.FromArgb(255, 255, 224, 120), 134, 8, 0);
        Txt("ACT " + e.Act + "/6  " + GameSettings.Levels[e.Act - 1].Name + (e.Cycle > 0 ? "  R" + (e.Cycle + 1) : ""), fSmall, Color.FromArgb(255, 255, 240, 190), 290, 8, 1);
        for (int i = 0; i < Math.Min(e.Lives, 6); i++) MiniClown(VW - 92 + i * 12, 2);
        Txt("x" + Math.Max(0, e.Lives), fSmall, Color.White, VW - 4, 8, 2);

        // second row: distance, bags and the running bonus
        int bx = 8;
        int bw = 170;
        Rect(Color.FromArgb(255, 30, 20, 60), bx, 17, bw, 7);
        Rect(Color.FromArgb(255, 232, 52, 52), bx + 1, 18, (int)((bw - 2) * L.Progress), 5);
        for (int i = 1; i < 10; i++) Rect(Color.FromArgb(120, 255, 255, 255), bx + i * bw / 10, 18, 1, 5);
        MiniClown(bx + (int)((bw - 12) * L.Progress), 12);
        Txt(L.MetersLeft + "M", fSmall, Color.FromArgb(255, 255, 240, 190), bx + bw + 24, 21, 1);
        Rect(Color.FromArgb(255, 246, 200, 50), 238, 16, 9, 9);
        Rect(Color.FromArgb(255, 28, 18, 40), 241, 14, 3, 3);
        Txt("x" + L.BagCount, fSmall, Color.White, 250, 21, 0);
        Txt("BONUS", fSmall, Color.FromArgb(255, 252, 208, 60), 300, 21, 0);
        Txt(((int)L.Bonus).ToString("D4"), fMid, Color.White, 336, 21, 0);
        if (L.Streak > 1) Txt("STREAK x" + L.Streak, fSmall, Color.FromArgb(255, 120, 255, 160), VW - 6, 21, 2);

        if (e.NoteTimer > 0f && e.Note.Length > 0 && e.State == GameState.Playing)
        {
            Rect(Color.FromArgb(190, 10, 10, 40), 150, 34, 180, 14);
            Txt(e.Note, fSmall, Color.FromArgb(255, 255, 244, 160), VW / 2, 41, 1);
        }
    }

    // ------------------------------------------------------------------ title and controls

    private void DrawTitle(GameEngine e)
    {
        float clock = e.Clock;
        bg.Draw(gc, 3, clock * 20f, clock);

        // a big-top tent in the middle and the podium row at the bottom
        int tx = 240;
        for (int i = 0; i < 70; i++)
        {
            int y = 142 + i * 36 / 70;
            gc.FillRectangle(B(((i / 6) & 1) == 0 ? Color.FromArgb(255, 220, 50, 60) : Color.FromArgb(255, 246, 246, 252)), tx - 70 + i, y - (70 - i) * 0, 2, 190 - y);
            gc.FillRectangle(B(((i / 6) & 1) == 0 ? Color.FromArgb(255, 220, 50, 60) : Color.FromArgb(255, 246, 246, 252)), tx + 70 - i - 2, y - (70 - i) * 0, 2, 190 - y);
        }
        for (int x = 0; x < VW; x += 40)
        {
            Color c = ((x / 40) & 1) == 0 ? Color.FromArgb(255, 220, 50, 60) : Color.FromArgb(255, 252, 208, 60);
            Rect(c, x, 244, 40, 26);
            Rect(Color.FromArgb(255, 252, 252, 255), x + 14, 248, 12, 18);
            Rect(Color.FromArgb(255, 28, 18, 40), x, 242, 40, 3);
        }
        Rect(Color.FromArgb(255, 252, 208, 60), 0, 240, VW, 3);

        // the characters
        sprites.DrawCharlieAt(gc, 84, 240 + (int)Math.Round(Math.Abs(Math.Sin(clock * 6)) * -3), Pose.Run, 1, clock, 3, 0f);
        sprites.DrawBag(gc, new MoneyBag { X = 30, Y = 218, Age = clock }, clock);
        sprites.DrawBag(gc, new MoneyBag { X = 420, Y = 216, Age = clock + 1f }, clock);
        sprites.DrawBag(gc, new MoneyBag { X = 450, Y = 226, Age = clock + 2f }, clock);
        float sw = (float)Math.Sin(clock * 2f) * 0.4f;
        Trapeze tp = new Trapeze { AnchorX = 440f, AnchorY = 30f, Length = 70f, Amp = 0.4f, Omega = 2f, Phase = 0f };
        tp.Update(clock);
        sprites.DrawTrapeze(gc, tp, false, clock);
        Monkey mk = new Monkey { Kind = MonkeyKind.Normal, X = tp.BarX, Y = tp.BarY + 32f, Active = true, GroundLine = tp.BarY + 32f };
        sprites.DrawMonkey(gc, mk, clock);
        CircusBall ball = new CircusBall { X = 330, Y = 206, R = 18, Color = 0, Roll = clock * 2f };
        sprites.DrawBall(gc, ball, clock);

        DrawMarquee(clock);

        string[] items = { "START GAME", "CONTROLS" };
        for (int i = 0; i < 2; i++) MenuItem(items[i], ItemRect(196, i), e.TitleIndex == i, clock);
        if (((int)(clock * 2f) & 1) == 0) Txt("PRESS ENTER", fSmall, Color.White, VW / 2, 148, 1);
        Txt("HIGH SCORE  " + FormatPoints(e.Scores.Best), fMid, Color.FromArgb(255, 255, 230, 100), VW / 2, 250, 1);
    }

    private void DrawMarquee(float clock)
    {
        int x = 74, y = 12, w = 332, h = 104;
        Rect(Color.FromArgb(255, 28, 12, 20), x - 4, y - 4, w + 8, h + 8);
        Rect(Color.FromArgb(255, 150, 22, 36), x, y, w, h);
        Rect(Color.FromArgb(255, 196, 40, 50), x + 4, y + 4, w - 8, h - 8);
        Rect(Color.FromArgb(255, 120, 14, 30), x + 8, y + 8, w - 16, h - 16);
        // the bulbs around the sign
        int n = 0;
        for (int bx = x - 2; bx < x + w; bx += 10, n++) { BulbAt(bx, y - 3, n, clock); BulbAt(bx, y + h - 1, n + 1, clock); }
        for (int by = y + 8; by < y + h - 8; by += 10, n++) { BulbAt(x - 3, by, n, clock); BulbAt(x + w - 3, by, n + 1, clock); }
        // two stars
        Star(x + 28, y + 52, 12, Color.FromArgb(255, 252, 208, 60));
        Star(x + w - 28, y + 52, 12, Color.FromArgb(255, 252, 208, 60));

        // the lettering with a dark outline
        DrawOutlined("CIRCUS", fTitleA, x + w / 2, y + 28, Color.FromArgb(255, 255, 238, 90), Color.FromArgb(255, 252, 150, 20), Color.FromArgb(255, 80, 20, 10));
        DrawOutlined("CHARLIE", fTitleB, x + w / 2, y + 72, Color.FromArgb(255, 252, 252, 255), Color.FromArgb(255, 90, 140, 240), Color.FromArgb(255, 14, 20, 90));
    }

    private void BulbAt(int x, int y, int n, float clock)
    {
        bool on = ((n + (int)(clock * 4f)) & 1) == 0;
        Rect(Color.FromArgb(255, 28, 12, 20), x, y, 6, 6);
        Rect(on ? Color.FromArgb(255, 255, 244, 150) : Color.FromArgb(255, 210, 120, 40), x + 1, y + 1, 4, 4);
        if (on) Rect(Color.White, x + 2, y + 2, 1, 1);
    }

    private void Star(int cx, int cy, int r, Color c)
    {
        PointF[] pts = new PointF[10];
        for (int i = 0; i < 10; i++)
        {
            double a = -Math.PI / 2 + i * Math.PI / 5;
            double rr = (i % 2 == 0) ? r : r * 0.45;
            pts[i] = new PointF((float)(cx + Math.Cos(a) * rr), (float)(cy + Math.Sin(a) * rr));
        }
        gc.FillPolygon(B(Color.FromArgb(255, 120, 60, 10)), new[] { new PointF(cx, cy - r - 1), new PointF(cx + r + 1, cy), new PointF(cx, cy + r + 1), new PointF(cx - r - 1, cy) });
        gc.FillPolygon(B(c), pts);
    }

    private void DrawOutlined(string text, Font font, int cx, int cy, Color top, Color bottom, Color outline)
    {
        SizeF size = gc.MeasureString(text, font, 600, sfTight);
        float x = cx - size.Width / 2f;
        float y = cy - size.Height / 2f;
        for (int dx = -2; dx <= 2; dx++)
        {
            for (int dy = -2; dy <= 3; dy++)
            {
                if (dx == 0 && dy == 0) continue;
                gc.DrawString(text, font, B(outline), x + dx, y + dy, sfTight);
            }
        }
        using (LinearGradientBrush fill = new LinearGradientBrush(new RectangleF(x, y, size.Width + 1, size.Height), top, bottom, 90f))
        {
            gc.DrawString(text, font, fill, x, y, sfTight);
        }
    }

    private void MenuItem(string text, Rectangle r, bool selected, float clock)
    {
        if (selected)
        {
            Rect(Color.FromArgb(235, 14, 12, 50), r.X, r.Y, r.Width, r.Height);
            Rect(Color.FromArgb(255, 252, 208, 60), r.X, r.Y, r.Width, 2);
            Rect(Color.FromArgb(255, 252, 208, 60), r.X, r.Y + r.Height - 2, r.Width, 2);
            if (((int)(clock * 4f) & 1) == 0)
            {
                Rect(Color.FromArgb(255, 255, 230, 90), r.X + 8, r.Y + 5, 6, 10);
                Rect(Color.FromArgb(255, 255, 230, 90), r.Right - 14, r.Y + 5, 6, 10);
            }
        }
        else
        {
            Rect(Color.FromArgb(150, 14, 12, 50), r.X, r.Y, r.Width, r.Height);
        }
        Txt(text, fMid, selected ? Color.FromArgb(255, 255, 230, 90) : Color.White, r.X + r.Width / 2, r.Y + 10, 1);
    }

    private void DrawControls(GameEngine e)
    {
        bg.Draw(gc, 3, e.Clock * 10f, e.Clock);
        Rect(Color.FromArgb(150, 8, 8, 30), 0, 0, VW, VH);
        Panel(30, 10, VW - 60, 252, 240);
        Txt("CONTROLS", fHead, Color.FromArgb(255, 255, 220, 70), VW / 2, 30, 1);
        string[,] keys =
        {
            { "LEFT / RIGHT", "MOVE (WALK THE ROPE, STEER IN THE AIR)" },
            { "SPACE", "JUMP / LET GO OF THE TRAPEZE" },
            { "ESC", "PAUSE / RESUME" },
            { "ENTER", "START / CONFIRM" }
        };
        for (int i = 0; i < keys.GetLength(0); i++)
        {
            int y = 56 + i * 16;
            Rect(Color.FromArgb(255, 70, 40, 100), 44, y - 6, 92, 13);
            Rect(Color.FromArgb(255, 150, 110, 200), 44, y - 6, 92, 1);
            Txt(keys[i, 0], fSmall, Color.White, 90, y, 1);
            Txt(keys[i, 1], fSmall, Color.FromArgb(255, 230, 236, 255), 144, y, 0);
        }
        Txt("THE SIX ACTS", fSmall, Color.FromArgb(255, 252, 208, 60), 44, 128, 0);
        for (int i = 0; i < GameSettings.LevelCount; i++)
        {
            LevelInfo li = GameSettings.Levels[i];
            Txt((i + 1) + ". " + li.Name + " - " + li.Meters + "M", fSmall, Color.White, 44, 142 + i * 14, 0);
        }
        Txt("Collect money bags, jump the obstacles, keep your lives.", fSmall, Color.FromArgb(255, 200, 255, 200), VW / 2, 228, 1);
        MenuItem("BACK  [ENTER]", ItemRect(238, 0), true, e.Clock);
    }

    // ------------------------------------------------------------------ overlays

    private void DrawIntro(GameEngine e)
    {
        LevelInfo info = GameSettings.Levels[e.Act - 1];
        Panel(50, 70, VW - 100, 128, 232);
        Txt("ACT " + e.Act, fHead, Color.FromArgb(255, 255, 220, 70), VW / 2, 92, 1);
        Txt(info.Name, fBig, Color.White, VW / 2, 120, 1);
        Txt(info.Act, fSmall, Color.FromArgb(255, 255, 190, 120), VW / 2, 142, 1);
        Txt("DISTANCE  " + info.Meters + " M", fMid, Color.FromArgb(255, 255, 240, 160), VW / 2, 160, 1);
        Txt(info.Hint, fSmall, Color.FromArgb(255, 200, 230, 255), VW / 2, 180, 1);
        if (e.Cycle > 0) Txt("ROUND " + (e.Cycle + 1) + " - HARDER!", fSmall, Color.FromArgb(255, 255, 120, 110), VW / 2, 192, 1);
        if (((int)(e.Clock * 3f) & 1) == 0) Txt("PRESS ENTER", fSmall, Color.White, VW / 2, 208, 1);
    }

    private void DrawPause(GameEngine e)
    {
        Rect(Color.FromArgb(170, 6, 6, 24), 0, 0, VW, VH);
        Panel(130, 48, 220, 144, 240);
        Txt("PAUSED", fHead, Color.White, VW / 2, 72, 1);
        string[] labels = { "RESUME", "RESTART", "SOUND: " + (SoundManager.Muted ? "OFF" : "ON"), "TITLE SCREEN" };
        for (int i = 0; i < 4; i++) MenuItem(labels[i], ItemRect(100, i), e.PauseIndex == i, e.Clock);
    }

    private void DrawComplete(GameEngine e)
    {
        Panel(100, 40, 280, 190, 238);
        Txt("ACT COMPLETE!", fHead, Color.FromArgb(255, 255, 220, 70), VW / 2, 62, 1);
        int y = 88;
        Txt("COMPLETE BONUS   " + e.AwardLevel, fMid, Color.White, VW / 2, y, 1);
        Txt(e.AwardNoDeath > 0 ? "NO LIFE LOST    " + e.AwardNoDeath : "NO LIFE LOST    -", fMid, e.AwardNoDeath > 0 ? Color.FromArgb(255, 150, 255, 170) : Color.FromArgb(255, 170, 170, 200), VW / 2, y + 18, 1);
        Txt("TIME BONUS       " + e.AwardBonus, fMid, Color.White, VW / 2, y + 36, 1);
        Txt("MONEY BAGS       " + e.AwardBags, fMid, Color.FromArgb(255, 255, 224, 100), VW / 2, y + 54, 1);
        Txt("SCORE  " + FormatPoints(e.Score), fBig, Color.White, VW / 2, y + 86, 1);
        string next = e.Act >= GameSettings.LevelCount ? "ALL ACTS DONE!" : "NEXT: " + GameSettings.Levels[e.Act].Name;
        Txt(next, fSmall, Color.FromArgb(255, 255, 190, 120), VW / 2, y + 112, 1);
        if (e.CompleteTimer > 1f && ((int)(e.Clock * 3f) & 1) == 0) Txt("PRESS ENTER", fSmall, Color.White, VW / 2, y + 128, 1);
        sprites.DrawCharlieAt(gc, 140, 182, Pose.Cheer, 1, e.GameTime, 1, 0f);
        sprites.DrawParticles(gc, e.Particles);
    }

    private void DrawGameOver(GameEngine e)
    {
        Rect(Color.FromArgb(185, 6, 6, 24), 0, 0, VW, VH);
        Panel(110, 40, 260, 188, 240);
        Txt("GAME OVER", fHead, Color.FromArgb(255, 255, 90, 80), VW / 2, 66, 1);
        Txt("ACT " + e.Act + " - " + GameSettings.Levels[e.Act - 1].Name, fSmall, Color.FromArgb(255, 220, 230, 255), VW / 2, 92, 1);
        Txt("FINAL SCORE", fSmall, Color.FromArgb(255, 252, 208, 60), VW / 2, 112, 1);
        Txt(FormatPoints(e.Score), fBig, Color.White, VW / 2, 132, 1);
        Txt("HIGH SCORE  " + FormatPoints(e.Scores.Best), fMid, Color.FromArgb(255, 255, 230, 100), VW / 2, 158, 1);
        if (e.NewRecord && ((int)(e.Clock * 3f) & 1) == 0) Txt("NEW HIGH SCORE!", fMid, Color.FromArgb(255, 255, 120, 100), VW / 2, 176, 1);
        MenuItem("RESTART  [ENTER]", ItemRect(196, 0), e.EndIndex == 0, e.Clock);
        MenuItem("TITLE SCREEN", ItemRect(196, 1), e.EndIndex == 1, e.Clock);
    }

    private void DrawVictory(GameEngine e)
    {
        Rect(Color.FromArgb(170, 6, 6, 24), 0, 0, VW, VH);
        Panel(90, 20, 300, 212, 240);
        Txt("CONGRATULATIONS!", fHead, Color.FromArgb(255, 255, 220, 70), VW / 2, 44, 1);
        Txt("ALL SIX ACTS COMPLETE", fMid, Color.FromArgb(255, 130, 255, 170), VW / 2, 70, 1);
        Txt("BONUS  +" + GameSettings.ScoreAllLevels, fMid, Color.White, VW / 2, 92, 1);
        Txt("SCORE  " + FormatPoints(e.Score), fBig, Color.White, VW / 2, 118, 1);
        Txt("HIGH SCORE  " + FormatPoints(e.Scores.Best), fMid, Color.FromArgb(255, 255, 230, 100), VW / 2, 146, 1);
        if (e.NewRecord && ((int)(e.Clock * 3f) & 1) == 0) Txt("NEW HIGH SCORE!", fMid, Color.FromArgb(255, 255, 120, 100), VW / 2, 164, 1);
        Txt("NEXT: ROUND " + (e.Cycle + 2) + " - FASTER AND HARDER", fSmall, Color.FromArgb(255, 255, 190, 120), VW / 2, 182, 1);
        MenuItem("NEXT ROUND  [ENTER]", ItemRect(196, 0), e.EndIndex == 0, e.Clock);
        MenuItem("TITLE SCREEN", ItemRect(196, 1), e.EndIndex == 1, e.Clock);
        sprites.DrawCharlieAt(gc, 130, 150, Pose.Cheer, 1, e.GameTime, 1, 0f);
        sprites.DrawCharlieAt(gc, 350, 150, Pose.Cheer, -1, e.GameTime + 0.3f, 1, 0f);
        sprites.DrawParticles(gc, e.Particles);
    }
}
