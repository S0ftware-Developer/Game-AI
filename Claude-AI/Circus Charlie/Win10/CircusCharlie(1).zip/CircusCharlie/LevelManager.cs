namespace CircusCharlie;

public struct LevelInput
{
    public bool Left, Right, JumpPressed, JumpHeld;
}

/// <summary>
/// Builds and runs the six circus acts. Each act has its own mechanics: the lion ride (jumping hoops and fire bowls), the
/// tightrope (monkeys), trampolines (bounce timing and flying knives), the balls (leaps between moving balls), the horse
/// ride (hurdles) and the trapeze (pendulum swings and release timing).
/// </summary>
public sealed class LevelManager
{
    public int Level = 1;
    public int Cycle;
    public float Diff = 1f;
    public readonly Charlie Charlie = new Charlie();
    public readonly Lion Lion = new Lion();
    public readonly Horse Horse = new Horse();
    public readonly List<Obstacle> Obstacles = new List<Obstacle>(64);
    public readonly List<Monkey> Monkeys = new List<Monkey>(32);
    public readonly List<Trampoline> Trampolines = new List<Trampoline>(48);
    public readonly List<CircusBall> Balls = new List<CircusBall>(48);
    public readonly List<Trapeze> Trapezes = new List<Trapeze>(24);
    public readonly List<MoneyBag> Bags = new List<MoneyBag>(48);
    public readonly List<Knife> Knives = new List<Knife>(16);
    public readonly PointF[] Preview = new PointF[26];
    public bool ShowPreview;

    public float EndX, CameraX, Time, Bonus, FinishTimer;
    public bool Completed;
    public int Cleared, BagCount, Streak;
    public const float RopeY = 176f;
    public const float RideY = GameSettings.GroundY - 24f;
    public const float PlatformTop = 176f;
    public float PlatformX;                       // the finish platform of the trapeze act
    public int Holding = -1;                      // the trapeze Charlie hangs from

    public Action<int, float, float, string>? OnScore;
    public ParticleSystem Particles = new ParticleSystem();

    private Random rng = new Random(1);
    private float streakTimer, gallopTimer, dustTimer, knifeTimer, releaseCooldown;
    private int seq, tIndex = -1, lastTramp, ballIdx, bestIdx, lastHold;
    private float compressTimer, lastPress = -10f, offset, hx, hy;
    private bool boostRequested;

    public int Meters { get { return (int)(Math.Max(0f, Math.Min(Charlie.X, EndX)) / GameSettings.MeterPx); } }
    public float Progress { get { return EndX <= 0f ? 0f : Math.Max(0f, Math.Min(1f, Charlie.X / EndX)); } }
    public int MetersLeft { get { return Math.Max(0, GameSettings.Levels[Level - 1].Meters - Meters); } }
    public bool Ready { get { return Completed && FinishTimer > 2.2f; } }

    public RectangleF CatchBox
    {
        get
        {
            if (Level == 6) return new RectangleF(Charlie.X - 8f, Charlie.Y - 46f, 16f, 46f);
            RectangleF h = Charlie.Hitbox;
            h.Inflate(4f, 3f);
            return h;
        }
    }

    // ------------------------------------------------------------------ loading

    public void Load(int level, int cycle)
    {
        Level = level;
        Cycle = cycle;
        Diff = 1f + 0.14f * cycle;
        rng = new Random(level * 7919 + cycle * 104729);
        Obstacles.Clear(); Monkeys.Clear(); Trampolines.Clear(); Balls.Clear(); Trapezes.Clear(); Bags.Clear(); Knives.Clear();
        EndX = GameSettings.Levels[level - 1].Meters * GameSettings.MeterPx;
        Time = 0f;
        Bonus = GameSettings.StartBonus;
        Completed = false;
        FinishTimer = 0f;
        Cleared = 0;
        BagCount = 0;
        Streak = 0;
        seq = 0;
        tIndex = -1;
        lastTramp = 0;
        ballIdx = 0;
        bestIdx = 0;
        Holding = -1;
        knifeTimer = 2.5f;
        Charlie.Reset(80f, RideY, Pose.Ride);
        Charlie.Invuln = 1f;
        switch (level)
        {
            case 1: BuildLion(); break;
            case 2: BuildRope(); break;
            case 3: BuildTrampolines(); break;
            case 4: BuildBalls(); break;
            case 5: BuildHorse(); break;
            default: BuildTrapeze(); break;
        }
        CameraX = Math.Max(0f, Math.Min(MaxCamera, CameraTarget));
    }

    private float MaxCamera { get { return Math.Max(0f, EndX + 150f - GameSettings.ViewW); } }

    private float CameraTarget
    {
        get { return (Level == 6 ? Charlie.X : Charlie.X) - 150f; }
    }

    private void AddBag(float x, float y)
    {
        MoneyBag b = new MoneyBag();
        b.X = x;
        b.Y = y;
        Bags.Add(b);
    }

    private void BuildLion()
    {
        Lion.Reset(80f);
        Charlie.Reset(84f, RideY, Pose.Ride);
        float x = 440f;
        while (x < EndX - 280f)
        {
            bool hoop = rng.NextDouble() < 0.45;
            AddObstacle(hoop ? ObstacleKind.Hoop : ObstacleKind.FireBowl, x);
            AddBag(x, GameSettings.GroundY - (hoop ? 76f : 74f));
            float last = x;
            if (rng.NextDouble() < 0.2 + 0.05 * Cycle && x + 110f < EndX - 280f)
            {
                bool hoop2 = rng.NextDouble() < 0.5;
                last = x + 112f;
                AddObstacle(hoop2 ? ObstacleKind.Hoop : ObstacleKind.FireBowl, last);
                AddBag(last, GameSettings.GroundY - (hoop2 ? 76f : 74f));
            }
            if (rng.NextDouble() < 0.45) AddBag(last + 70f, GameSettings.GroundY - 40f);
            x = last + (165f + (float)rng.NextDouble() * 70f) / Math.Min(1.35f, Diff);
        }
    }

    private void AddObstacle(ObstacleKind kind, float x)
    {
        Obstacle o = new Obstacle();
        o.Kind = kind;
        o.X = x;
        Obstacles.Add(o);
    }

    private void BuildRope()
    {
        Charlie.Reset(70f, RopeY, Pose.Stand);
        float x = 560f;
        while (x < EndX - 120f)
        {
            Monkey m = new Monkey();
            double r = rng.NextDouble();
            m.Kind = r < 0.5 ? MonkeyKind.Normal : (r < 0.72 ? MonkeyKind.Fast : (r < 0.87 ? MonkeyKind.Reverser : MonkeyKind.Hopper));
            m.BaseSpeed = (m.Kind == MonkeyKind.Fast ? 100f : 58f) * Math.Min(1.4f, Diff);
            m.X = x;
            m.Y = RopeY;
            m.GroundLine = RopeY;
            Monkeys.Add(m);
            AddBag(x - 95f, RopeY - 52f);
            x += (205f + (float)rng.NextDouble() * 85f) / Math.Min(1.3f, Diff);
        }
        for (float bx = 300f; bx < EndX - 150f; bx += 330f) AddBag(bx, RopeY - 30f);
    }

    private void BuildTrampolines()
    {
        float x = 80f;
        float y = 196f;
        int i = 0;
        while (x < EndX - 140f)
        {
            Trampoline t = new Trampoline();
            t.X = x;
            t.Y = y;
            Trampolines.Add(t);
            float spacing = 74f + (float)rng.NextDouble() * (18f + 7f * Math.Min(Cycle, 3));
            float nx = x + spacing;
            float ny = Math.Max(150f, Math.Min(214f, y + ((float)rng.NextDouble() - 0.5f) * 40f));
            if (i > 0 && i % 2 == 0) AddBag((x + nx) / 2f, Math.Min(y, ny) - 80f);
            x = nx;
            y = ny;
            i++;
        }
        Trampoline goal = new Trampoline();
        goal.X = EndX + 20f;
        goal.Y = Trampolines[Trampolines.Count - 1].Y;
        goal.IsGoal = true;
        Trampolines.Add(goal);
        Charlie.Reset(Trampolines[0].X, Trampolines[0].Y, Pose.Land);
        tIndex = 0;
        compressTimer = 0.4f;
        boostRequested = false;
        Charlie.OnGround = false;
    }

    private void BuildBalls()
    {
        float x = 80f;
        float y = 176f;
        int i = 0;
        float dmax = 92f + 4f * Math.Min(Cycle, 2);
        while (x < EndX - 120f)
        {
            CircusBall b = new CircusBall();
            b.R = i == 0 ? 26f : 16f + (float)rng.NextDouble() * 8f;
            b.BaseX = x;
            b.BaseY = y;
            b.X = x;
            b.Y = y;
            b.Color = i % 4;
            b.Phase = (float)rng.NextDouble() * 6f;
            double r = rng.NextDouble();
            if (i > 1)
            {
                if (r < 0.3 + 0.1 * Cycle) { b.Motion = 1; b.Amp = 12f; b.Speed = 1.4f + 0.2f * Cycle; }
                else if (r < 0.45 + 0.12 * Cycle) { b.Motion = 2; b.Amp = 9f; b.Speed = 1.2f + 0.2f * Cycle; }
            }
            Balls.Add(b);
            float d = 72f + (float)rng.NextDouble() * (dmax - 72f);
            float ny = Math.Max(120f, Math.Min(198f, y + ((float)rng.NextDouble() - 0.5f) * 44f));
            if (i > 0 && i % 2 == 1) AddBag(x + d / 2f, Math.Min(y, ny) - 62f);
            x += d;
            y = ny;
            i++;
        }
        CircusBall goal = new CircusBall();
        goal.R = 34f;
        goal.BaseX = EndX + 10f;
        goal.BaseY = 200f;
        goal.X = goal.BaseX;
        goal.Y = goal.BaseY;
        goal.IsGoal = true;
        goal.Color = 2;
        Balls.Add(goal);
        ballIdx = 0;
        offset = 0f;
        Charlie.Reset(Balls[0].X, Balls[0].SurfaceY(0f), Pose.Balance);
    }

    private void BuildHorse()
    {
        Horse.Reset(80f);
        Charlie.Reset(80f, Horse.Y - 30f, Pose.Ride);
        float x = 500f;
        while (x < EndX - 300f)
        {
            double r = rng.NextDouble();
            ObstacleKind k = r < 0.4 ? ObstacleKind.Hurdle : (r < 0.62 ? ObstacleKind.TallHurdle : (r < 0.8 ? ObstacleKind.WideHurdle : ObstacleKind.FireBowl));
            AddObstacle(k, x);
            AddBag(x, GameSettings.GroundY - 70f);
            float last = x;
            if (rng.NextDouble() < 0.18 + 0.05 * Cycle)
            {
                last = x + 150f;
                AddObstacle(ObstacleKind.Hurdle, last);
                AddBag(last, GameSettings.GroundY - 70f);
            }
            if (rng.NextDouble() < 0.4) AddBag(last + 110f, GameSettings.GroundY - 36f);
            x = last + (230f + (float)rng.NextDouble() * 110f) * Math.Min(1.1f, 1f + 0.03f * Cycle) / Math.Min(1.3f, Diff);
        }
    }

    private void BuildTrapeze()
    {
        float x = 90f;
        int i = 0;
        float spacing = 112f;
        while (x < EndX - 100f)
        {
            Trapeze t = new Trapeze();
            t.AnchorX = x;
            t.AnchorY = 26f;
            t.Length = 92f;
            t.Amp = Math.Min(0.82f, 0.62f + 0.05f * (i % 4) + 0.02f * Cycle);
            t.Omega = 2.2f + 0.08f * (i % 3) + 0.1f * Cycle;
            t.Phase = i * 1.7f;
            Trapezes.Add(t);
            if (i > 0) AddBag(x - spacing / 2f + 4f, 110f);
            x += spacing;
            i++;
        }
        PlatformX = EndX + 10f;
        foreach (Trapeze t in Trapezes) t.Update(0f);
        Holding = 0;
        bestIdx = 0;
        lastHold = -1;
        Charlie.Reset(Trapezes[0].BarX, Trapezes[0].BarY + 44f, Pose.Hang);
    }

    // ------------------------------------------------------------------ respawn

    public void Respawn()
    {
        Charlie.Dying = false;
        Charlie.DeathTimer = 0f;
        Charlie.Invuln = 2.2f;
        Charlie.VX = 0f;
        Charlie.VY = 0f;
        Knives.Clear();
        knifeTimer = 2.5f;
        Streak = 0;
        seq = 0;
        switch (Level)
        {
            case 1:
                {
                    float cp = Math.Max(80f, (float)Math.Floor(Lion.X / 600f) * 600f);
                    Lion.Reset(cp);
                    Obstacles.RemoveAll(o => o.X > cp - 120f && o.X < cp + 180f);
                    Charlie.Reset(cp + 4f, RideY, Pose.Ride);
                    Charlie.Invuln = 2.2f;
                    break;
                }
            case 2:
                {
                    float cp = Math.Max(70f, (float)Math.Floor(Charlie.X / 600f) * 600f);
                    Monkeys.RemoveAll(m => m.X > cp - 250f && m.X < cp + 320f);
                    Charlie.Reset(cp, RopeY, Pose.Stand);
                    Charlie.Invuln = 2.2f;
                    break;
                }
            case 3:
                {
                    Trampoline t = Trampolines[Math.Max(0, Math.Min(lastTramp, Trampolines.Count - 2))];
                    Charlie.Reset(t.X, t.Y, Pose.Land);
                    Charlie.Invuln = 2.2f;
                    Charlie.OnGround = false;
                    tIndex = Trampolines.IndexOf(t);
                    compressTimer = 0.4f;
                    boostRequested = false;
                    break;
                }
            case 4:
                {
                    ballIdx = Math.Max(0, Math.Min(bestIdx, Balls.Count - 2));
                    offset = 0f;
                    Charlie.Reset(Balls[ballIdx].X, Balls[ballIdx].SurfaceY(0f), Pose.Balance);
                    Charlie.Invuln = 2.2f;
                    break;
                }
            case 5:
                {
                    float cp = Math.Max(80f, (float)Math.Floor(Horse.X / 1200f) * 1200f);
                    Horse.Reset(cp);
                    Obstacles.RemoveAll(o => o.X > cp - 150f && o.X < cp + 260f);
                    Charlie.Reset(cp, Horse.Y - 30f, Pose.Ride);
                    Charlie.Invuln = 2.2f;
                    break;
                }
            default:
                {
                    Holding = Math.Max(0, Math.Min(bestIdx, Trapezes.Count - 1));
                    lastHold = -1;
                    releaseCooldown = 0f;
                    Trapeze t = Trapezes[Holding];
                    Charlie.Reset(t.BarX, t.BarY + 44f, Pose.Hang);
                    Charlie.Invuln = 2.2f;
                    break;
                }
        }
        CameraX = Math.Max(0f, Math.Min(MaxCamera, CameraTarget));
    }

    // ------------------------------------------------------------------ events

    private void Score(int points, float x, float y, string text)
    {
        OnScore?.Invoke(points, x, y, text);
    }

    private void Hurt()
    {
        if (Charlie.Invuln > 0f || Charlie.Dying || Completed) return;
        Charlie.Dying = true;
        Charlie.DeathTimer = 0f;
        Charlie.Pose = Pose.Death;
        Charlie.VY = -180f;
        Charlie.VX = -25f;
        Streak = 0;
        seq = 0;
        SoundManager.Play(SfxId.Hit);
        Particles.Sparks(Charlie.X, Charlie.Y - 16f, 90f, 10, Color.FromArgb(255, 240, 80));
    }

    private void JumpCleared(float x, float y)
    {
        Cleared++;
        Score(GameSettings.ScoreJump, x, y, "+" + GameSettings.ScoreJump);
        seq++;
        if (seq >= 5)
        {
            seq = 0;
            Score(GameSettings.ScoreSequence, x, y - 14f, "SEQUENCE! +" + GameSettings.ScoreSequence);
            SoundManager.Play(SfxId.Sequence);
        }
    }

    private void Finish()
    {
        if (Completed) return;
        Completed = true;
        FinishTimer = 0f;
        Charlie.Pose = Pose.Cheer;
        Charlie.Invuln = 999f;
        Particles.Sparks(Charlie.X, Charlie.Y - 30f, 110f, 18, Color.FromArgb(255, 255, 220, 80));
    }

    private void CollectBags(float dt)
    {
        if (streakTimer > 0f)
        {
            streakTimer -= dt;
            if (streakTimer <= 0f) Streak = 0;
        }
        RectangleF cb = CatchBox;
        foreach (MoneyBag b in Bags)
        {
            if (b.Collected) continue;
            b.Age += dt;
            if (cb.IntersectsWith(new RectangleF(b.X - 7f, b.Y - 8f, 14f, 16f)))
            {
                b.Collected = true;
                BagCount++;
                Streak++;
                streakTimer = 4f;
                int pts = GameSettings.ScoreBag + 50 * Math.Min(Streak - 1, 4);
                Score(pts, b.X, b.Y, Streak > 1 ? "+" + pts + " x" + Streak : "+" + pts);
                SoundManager.Play(SfxId.Coin);
                Particles.Sparks(b.X, b.Y, 80f, 10, Color.FromArgb(255, 255, 220, 60));
                Particles.Ring(b.X, b.Y, 16f, Color.FromArgb(255, 255, 240, 120));
            }
        }
    }

    // ------------------------------------------------------------------ the update

    public void Update(float dt, LevelInput inp)
    {
        Time += dt;
        foreach (Trampoline t in Trampolines) t.Update(dt);

        if (Charlie.Dying)
        {
            Charlie.DeathTimer += dt;
            Charlie.Anim += dt;
            Charlie.VY = Math.Min(520f, Charlie.VY + 800f * dt);
            Charlie.Y += Charlie.VY * dt;
            Charlie.X += Charlie.VX * dt;
            if (Level == 6) { foreach (Trapeze t in Trapezes) t.Update(Time); }
            return;
        }
        if (Completed)
        {
            FinishTimer += dt;
            Charlie.Anim += dt;
            if (Level == 1) { Lion.Update(dt, Math.Max(0f, Lion.Speed - 130f * dt)); Charlie.X = Lion.X + 4f; }
            else if (Level == 5) { Horse.Speed = Math.Max(0f, Horse.Speed - 150f * dt); Horse.X += Horse.Speed * dt; Horse.Phase += Horse.Speed * dt * 0.075f; Charlie.X = Horse.X; }
            if (Level == 6) { foreach (Trapeze t in Trapezes) t.Update(Time); }
            if (Level == 4) foreach (CircusBall b in Balls) b.Update(dt, Time);
            CameraX += (Math.Max(0f, Math.Min(MaxCamera, CameraTarget)) - CameraX) * Math.Min(1f, 6f * dt);
            return;
        }

        Bonus = Math.Max(0f, Bonus - 20f * dt);
        if (Charlie.Invuln > 0f) Charlie.Invuln = Math.Max(0f, Charlie.Invuln - dt);
        Charlie.Anim += dt;
        if (Charlie.LandTimer > 0f) Charlie.LandTimer -= dt;

        switch (Level)
        {
            case 1: UpdateLion(dt, inp); break;
            case 2: UpdateRope(dt, inp); break;
            case 3: UpdateTrampolines(dt, inp); break;
            case 4: UpdateBalls(dt, inp); break;
            case 5: UpdateHorse(dt, inp); break;
            default: UpdateTrapeze(dt, inp); break;
        }
        CollectBags(dt);
        float target = Math.Max(0f, Math.Min(MaxCamera, CameraTarget));
        CameraX += (target - CameraX) * Math.Min(1f, 9f * dt);
        if (Level == 1 || Level == 5) CameraX = target;
    }

    // ------------------------------------------------------------------ act 1: the lion

    private void UpdateLion(float dt, LevelInput inp)
    {
        float speed = (92f + 32f * Progress) * Diff;
        Lion.Update(dt, speed);
        Charlie.X = Lion.X + 4f;
        Charlie.OnGround = Charlie.OnGround && Charlie.Y >= RideY - 0.01f;
        if (Charlie.OnGround)
        {
            Charlie.Y = RideY;
            Charlie.Pose = Pose.Ride;
            if (inp.JumpPressed)
            {
                Charlie.VY = -288f;
                Charlie.OnGround = false;
                Charlie.Pose = Pose.Jump;
                SoundManager.Play(SfxId.Jump);
            }
        }
        else
        {
            Charlie.VY += 900f * dt;
            Charlie.Y += Charlie.VY * dt;
            Charlie.Pose = Pose.Jump;
            if (Charlie.Y >= RideY && Charlie.VY >= 0f)
            {
                Charlie.Y = RideY;
                Charlie.VY = 0f;
                Charlie.OnGround = true;
                Charlie.LandTimer = 0.15f;
                Charlie.Pose = Pose.Ride;
                SoundManager.Play(SfxId.Land);
                Particles.Smoke(Charlie.X, GameSettings.GroundY - 2f, -30f, -10f, 4f, 0.4f, 200);
            }
        }
        Gallop(dt, speed, 0.34f);
        UpdateObstacles(Charlie.Hitbox, Charlie.X, true);
        if (Lion.X >= EndX) Finish();
    }

    private void Gallop(float dt, float speed, float interval)
    {
        gallopTimer -= dt;
        if (gallopTimer <= 0f)
        {
            gallopTimer = interval * 100f / Math.Max(60f, speed);
            SoundManager.Play(SfxId.Gallop);
        }
        dustTimer -= dt;
        if (dustTimer <= 0f)
        {
            dustTimer = 0.09f;
            float x = Level == 5 ? Horse.X - 16f : Lion.X - 14f;
            Particles.Smoke(x, GameSettings.GroundY - 2f, -35f, -8f, 3f, 0.45f, 215);
        }
    }

    private void UpdateObstacles(RectangleF body, float x, bool jumpScore)
    {
        foreach (Obstacle o in Obstacles)
        {
            if (!o.Hit && Charlie.Invuln <= 0f && o.Box.IntersectsWith(body))
            {
                o.Hit = true;
                Hurt();
            }
            if (!o.Passed && x > o.X + o.HalfWidth + 10f)
            {
                o.Passed = true;
                if (!o.Hit && jumpScore) JumpCleared(o.X, o.Y - 70f);
            }
        }
        Obstacles.RemoveAll(o => o.X < CameraX - 80f);
    }

    // ------------------------------------------------------------------ act 5: the horse

    private void UpdateHorse(float dt, LevelInput inp)
    {
        float speed = (120f + 62f * Progress) * Diff;
        Horse.Speed = speed;
        Horse.X += speed * dt;
        Horse.Phase += speed * dt * 0.075f;
        if (Horse.Squash > 0f) Horse.Squash = Math.Max(0f, Horse.Squash - dt * 5f);
        if (Horse.OnGround)
        {
            Horse.Y = GameSettings.GroundY;
            if (inp.JumpPressed)
            {
                Horse.VY = -335f;
                Horse.OnGround = false;
                SoundManager.Play(SfxId.Jump);
            }
        }
        else
        {
            Horse.VY += 900f * dt;
            Horse.Y += Horse.VY * dt;
            if (Horse.Y >= GameSettings.GroundY && Horse.VY >= 0f)
            {
                Horse.Y = GameSettings.GroundY;
                Horse.VY = 0f;
                Horse.OnGround = true;
                Horse.Squash = 1f;
                SoundManager.Play(SfxId.Land);
                Particles.Smoke(Horse.X - 10f, GameSettings.GroundY - 2f, -40f, -12f, 5f, 0.5f, 205);
            }
        }
        Charlie.X = Horse.X;
        Charlie.Y = Horse.Y - 30f;
        Charlie.OnGround = Horse.OnGround;
        Charlie.Pose = Pose.Ride;
        if (Horse.OnGround) Gallop(dt, speed, 0.3f);
        UpdateObstacles(Horse.Hitbox, Horse.X, true);
        if (Horse.X >= EndX) Finish();
    }

    // ------------------------------------------------------------------ act 2: the tightrope

    private void UpdateRope(float dt, LevelInput inp)
    {
        float walk = 62f * Math.Min(1.25f, Diff);
        float dir = (inp.Right ? 1f : 0f) - (inp.Left ? 1f : 0f);
        float vx = dir > 0f ? walk : (dir < 0f ? -walk * 0.7f : 0f);
        Charlie.VX = vx;
        if (dir != 0f) Charlie.Facing = dir > 0f ? 1 : -1;
        if (Charlie.OnGround)
        {
            Charlie.Y = RopeY;
            Charlie.Pose = Pose.Balance;
            if (inp.JumpPressed)
            {
                Charlie.VY = -275f;
                Charlie.OnGround = false;
                Charlie.Pose = Pose.Jump;
                SoundManager.Play(SfxId.Jump);
            }
        }
        else
        {
            Charlie.VY += 900f * dt;
            Charlie.Y += Charlie.VY * dt;
            Charlie.Pose = Pose.Jump;
            if (Charlie.Y >= RopeY && Charlie.VY >= 0f)
            {
                Charlie.Y = RopeY;
                Charlie.VY = 0f;
                Charlie.OnGround = true;
                Charlie.LandTimer = 0.12f;
                SoundManager.Play(SfxId.Land);
            }
        }
        Charlie.X = Math.Max(30f, Charlie.X + Charlie.VX * dt);

        foreach (Monkey m in Monkeys)
        {
            if (!m.Active && m.X < CameraX + GameSettings.ViewW + 30f) m.Active = true;
            if (!m.Active) continue;
            m.Update(dt, Charlie.X);
            if (Charlie.Invuln <= 0f && m.Box.IntersectsWith(Charlie.Hitbox)) Hurt();
            if (!m.Cleared && m.X < Charlie.X - 22f)
            {
                m.Cleared = true;
                JumpCleared(m.X, m.Y - 30f);
            }
        }
        Monkeys.RemoveAll(m => m.Active && m.X < CameraX - 60f);
        if (Charlie.X >= EndX) Finish();
    }

    // ------------------------------------------------------------------ act 3: trampolines and knives

    private void UpdateTrampolines(float dt, LevelInput inp)
    {
        if (inp.JumpPressed) lastPress = Time;
        float target = inp.Right ? 85f : (inp.Left ? -60f : 0f);
        if (inp.Right) Charlie.Facing = 1;
        else if (inp.Left) Charlie.Facing = -1;

        if (tIndex >= 0)
        {
            Trampoline tr = Trampolines[tIndex];
            compressTimer -= dt;
            if (inp.JumpPressed) boostRequested = true;
            Charlie.Y = tr.Y + 3f * tr.Compress;
            Charlie.Pose = Pose.Land;
            if (compressTimer <= 0f)
            {
                float h = boostRequested ? 172f : 106f;
                Charlie.VY = -(float)Math.Sqrt(2f * 800f * h);
                Charlie.VX = target * 0.5f;
                Charlie.OnGround = false;
                Charlie.Pose = Pose.Jump;
                tr.Compress = 0f;
                tIndex = -1;
                SoundManager.Play(SfxId.Bounce);
                Particles.Sparks(Charlie.X, Charlie.Y, 60f, boostRequested ? 10 : 4, Color.FromArgb(255, 255, 240, 140));
            }
        }
        else
        {
            float accel = 320f * dt;
            if (Charlie.VX < target) Charlie.VX = Math.Min(target, Charlie.VX + accel);
            else Charlie.VX = Math.Max(target, Charlie.VX - accel);
            Charlie.X = Math.Max(20f, Charlie.X + Charlie.VX * dt);
            float prevY = Charlie.Y;
            Charlie.VY += 800f * dt;
            Charlie.Y += Charlie.VY * dt;
            Charlie.Pose = Pose.Jump;
            if (Charlie.VY > 0f)
            {
                for (int i = 0; i < Trampolines.Count; i++)
                {
                    Trampoline tr = Trampolines[i];
                    if (Math.Abs(Charlie.X - tr.X) <= tr.Half + 3f && prevY <= tr.Y + 2f && Charlie.Y >= tr.Y)
                    {
                        tIndex = i;
                        Charlie.Y = tr.Y;
                        Charlie.VX = 0f;
                        Charlie.VY = 0f;
                        compressTimer = tr.IsGoal ? 0.2f : 0.14f;
                        boostRequested = Time - lastPress <= 0.18f;
                        tr.Compress = 1f;
                        Charlie.OnGround = true;
                        SoundManager.Play(SfxId.Land);
                        if (tr.IsGoal) { Finish(); break; }
                        if (i > lastTramp) { lastTramp = i; JumpCleared(tr.X, tr.Y - 40f); }
                        break;
                    }
                }
            }
        }
        if (Charlie.Y > 262f) Hurt();

        // flying knives with a warning before they appear
        knifeTimer -= dt;
        if (knifeTimer <= 0f && Charlie.X > 220f && Charlie.X < EndX - 160f && !Completed)
        {
            Knife k = new Knife();
            float baseY = tIndex >= 0 ? Trampolines[tIndex].Y : Math.Min(214f, Charlie.Y + 60f);
            k.Y = Math.Max(48f, Math.Min(204f, baseY - 20f - (float)rng.NextDouble() * 115f));
            k.Warn = 0.9f;
            k.VX = -(115f + 18f * Diff + (float)rng.NextDouble() * 30f);
            Knives.Add(k);
            knifeTimer = Math.Max(1.3f, (2.5f - 0.35f * Math.Min(Cycle, 3)) + (float)rng.NextDouble() * 1.0f);
        }
        foreach (Knife k in Knives)
        {
            if (!k.Active)
            {
                k.Warn -= dt;
                if (k.Warn <= 0f)
                {
                    k.Active = true;
                    k.X = CameraX + GameSettings.ViewW + 24f;
                    SoundManager.Play(SfxId.Knife);
                }
                continue;
            }
            k.X += k.VX * dt;
            k.Rot += dt * 14f;
            if (Charlie.Invuln <= 0f && k.Box.IntersectsWith(Charlie.Hitbox)) Hurt();
        }
        Knives.RemoveAll(k => k.Active && k.X < CameraX - 40f);
    }

    // ------------------------------------------------------------------ act 4: the balls

    private void UpdateBalls(float dt, LevelInput inp)
    {
        foreach (CircusBall b in Balls) b.Update(dt, Time);
        float dir = (inp.Right ? 1f : 0f) - (inp.Left ? 1f : 0f);
        if (dir != 0f) Charlie.Facing = dir > 0f ? 1 : -1;

        if (ballIdx >= 0)
        {
            CircusBall b = Balls[ballIdx];
            offset = Math.Max(-b.R * 0.55f, Math.Min(b.R * 0.55f, offset + dir * 30f * dt));
            b.Roll += dir * dt * 3f + dt * 0.4f;
            Charlie.X = b.X + offset;
            Charlie.Y = b.SurfaceY(offset);
            Charlie.VX = 0f;
            Charlie.VY = 0f;
            Charlie.OnGround = true;
            Charlie.Pose = Pose.Balance;
            if (inp.JumpPressed && !b.IsGoal)
            {
                Charlie.VY = -330f;
                Charlie.VX = (inp.Right ? 100f : (inp.Left ? -45f : 50f)) + (dt > 0f ? b.DX / dt : 0f) * 0.5f;
                Charlie.OnGround = false;
                Charlie.Pose = Pose.Jump;
                b.Squash = 1f;
                ballIdx = -1;
                SoundManager.Play(SfxId.Jump);
            }
            return;
        }

        float target = dir > 0f ? 100f : (dir < 0f ? -45f : 50f);
        float accel = 260f * dt;
        if (Charlie.VX < target) Charlie.VX = Math.Min(target, Charlie.VX + accel);
        else Charlie.VX = Math.Max(target, Charlie.VX - accel);
        Charlie.X = Math.Max(20f, Charlie.X + Charlie.VX * dt);
        float prevY = Charlie.Y;
        Charlie.VY += 900f * dt;
        Charlie.Y += Charlie.VY * dt;
        Charlie.Pose = Pose.Jump;
        if (Charlie.VY > 0f)
        {
            for (int i = 0; i < Balls.Count; i++)
            {
                CircusBall b = Balls[i];
                float dx = Charlie.X - b.X;
                if (Math.Abs(dx) > b.R * 0.85f) continue;
                float surf = b.SurfaceY(dx);
                if (prevY <= surf + 3f && Charlie.Y >= surf)
                {
                    ballIdx = i;
                    offset = Math.Max(-b.R * 0.55f, Math.Min(b.R * 0.55f, dx));
                    b.Squash = 1f;
                    Charlie.Pose = Pose.Balance;
                    SoundManager.Play(SfxId.Bounce);
                    Particles.Sparks(Charlie.X, surf, 40f, 4, Color.FromArgb(255, 255, 240, 160));
                    if (i > bestIdx) { bestIdx = i; JumpCleared(b.X, b.Y - b.R - 30f); }
                    if (b.IsGoal) Finish();
                    break;
                }
            }
        }
        if (Charlie.Y > 262f) Hurt();
    }

    // ------------------------------------------------------------------ act 6: the trapeze

    private void UpdateTrapeze(float dt, LevelInput inp)
    {
        foreach (Trapeze t in Trapezes) t.Update(Time);
        if (releaseCooldown > 0f) releaseCooldown -= dt;

        if (Holding >= 0)
        {
            Trapeze t = Trapezes[Holding];
            Charlie.X = t.BarX;
            Charlie.Y = t.BarY + 44f;
            Charlie.Pose = Pose.Hang;
            Charlie.Facing = t.ThetaDot >= 0f ? 1 : -1;
            Charlie.OnGround = false;
            ComputePreview(t);
            if (inp.JumpPressed)
            {
                float vx, vy;
                t.BarVelocity(out vx, out vy);
                Charlie.VX = vx * 1.15f;
                Charlie.VY = vy * 1.15f;
                hx = t.BarX;
                hy = t.BarY;
                lastHold = Holding;
                Holding = -1;
                releaseCooldown = 0.35f;
                ShowPreview = false;
                SoundManager.Play(SfxId.Swing);
            }
            return;
        }

        ShowPreview = false;
        float prevFeet = hy + 44f;
        Charlie.VY += 190f * dt;
        hx += Charlie.VX * dt;
        hy += Charlie.VY * dt;
        Charlie.X = hx;
        Charlie.Y = hy + 44f;
        Charlie.Pose = Pose.Fly;
        Charlie.Facing = Charlie.VX >= 0f ? 1 : -1;

        for (int i = 0; i < Trapezes.Count; i++)
        {
            if (i == lastHold && releaseCooldown > 0f) continue;
            Trapeze t = Trapezes[i];
            float dx = hx - t.BarX;
            float dy = hy - t.BarY;
            if (dx * dx + dy * dy <= 22f * 22f)
            {
                Holding = i;
                if (i > bestIdx) { bestIdx = i; JumpCleared(t.BarX, t.BarY - 30f); }
                SoundManager.Play(SfxId.Swing);
                Particles.Sparks(t.BarX, t.BarY, 50f, 6, Color.FromArgb(255, 255, 240, 160));
                return;
            }
        }

        // the finish platform
        if (Charlie.VY > 0f && Math.Abs(hx - PlatformX) <= 46f && prevFeet <= PlatformTop + 10f && Charlie.Y >= PlatformTop)
        {
            Charlie.Y = PlatformTop;
            Charlie.VX = 0f;
            Charlie.VY = 0f;
            Charlie.OnGround = true;
            SoundManager.Play(SfxId.Land);
            Finish();
            return;
        }
        if (hy > 252f) Hurt();
    }

    /// <summary>The dotted path Charlie would follow if he let go now.</summary>
    private void ComputePreview(Trapeze t)
    {
        float vx, vy;
        t.BarVelocity(out vx, out vy);
        vx *= 1.15f;
        vy *= 1.15f;
        float x = t.BarX, y = t.BarY;
        for (int i = 0; i < Preview.Length; i++)
        {
            Preview[i] = new PointF(x, y);
            vy += 190f * 0.05f;
            x += vx * 0.05f;
            y += vy * 0.05f;
        }
        ShowPreview = true;
    }
}
