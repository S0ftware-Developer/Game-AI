namespace CircusCharlie;

public enum Pose { Stand, Run, Jump, Land, Ride, Balance, Hang, Fly, Death, Cheer }

/// <summary>Charlie the clown. Position is the point between his feet (or his saddle seat when riding).</summary>
public sealed class Charlie
{
    public const float W = 12f;
    public const float H = 26f;

    public float X, Y, VX, VY;
    public int Facing = 1;
    public Pose Pose = Pose.Stand;
    public bool OnGround = true;
    public bool Dying;
    public float DeathTimer, Invuln, LandTimer, Anim, Squash;

    public RectangleF Hitbox
    {
        get { return new RectangleF(X - W / 2f, Y - H, W, H); }
    }

    public bool DeathDone { get { return Dying && DeathTimer >= 1.5f; } }

    public void Reset(float x, float y, Pose pose)
    {
        X = x;
        Y = y;
        VX = 0f;
        VY = 0f;
        Facing = 1;
        Pose = pose;
        OnGround = true;
        Dying = false;
        DeathTimer = 0f;
        LandTimer = 0f;
        Squash = 0f;
    }
}
