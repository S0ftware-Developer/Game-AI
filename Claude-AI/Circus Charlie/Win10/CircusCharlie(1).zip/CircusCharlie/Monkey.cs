namespace CircusCharlie;

public enum MonkeyKind { Normal, Fast, Reverser, Hopper }

/// <summary>A monkey walking toward Charlie along the tightrope. Some are faster, some turn around, some hop.</summary>
public sealed class Monkey
{
    public MonkeyKind Kind;
    public float X, Y, VX, VY;           // Y is the rope line
    public bool Active, Cleared;
    public float Anim, Timer;
    public bool Reversing, ReversedOnce;
    public float BaseSpeed;

    public RectangleF Box
    {
        get { return new RectangleF(X - 6f, Y - 14f, 12f, 14f); }
    }

    public float GroundLine;             // the rope y; Y is lifted above it while hopping

    public void Update(float dt, float charlieX)
    {
        Anim += dt;
        Timer += dt;
        float dir = -1f;
        switch (Kind)
        {
            case MonkeyKind.Reverser:
                if (!ReversedOnce && Math.Abs(X - charlieX) < 120f)
                {
                    ReversedOnce = true;
                    Reversing = true;
                    Timer = 0f;
                }
                if (Reversing)
                {
                    dir = 1f;
                    if (Timer > 0.9f) Reversing = false;
                }
                break;
            case MonkeyKind.Hopper:
                if (Y >= GroundLine && VY == 0f && Timer > 1.0f && Math.Abs(X - charlieX) < 150f && Math.Abs(X - charlieX) > 40f)
                {
                    VY = -190f;
                    Timer = 0f;
                }
                break;
        }
        X += dir * BaseSpeed * dt;
        if (Y < GroundLine || VY != 0f)
        {
            VY += 900f * dt;
            Y += VY * dt;
            if (Y >= GroundLine)
            {
                Y = GroundLine;
                VY = 0f;
            }
        }
    }
}
