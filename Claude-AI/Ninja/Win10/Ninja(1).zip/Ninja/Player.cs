namespace Ninja;

/// <summary>Input for one simulation step.</summary>
public struct PlayerInput
{
    public bool Left;
    public bool Right;
    public bool JumpHeld;
    public bool JumpPressed;     // true only on the step where a jump key went down
}

public struct Ghost
{
    public float X;
    public float Y;
    public int Facing;
    public float Age;
}

/// <summary>
/// The ninja: momentum-based platformer physics on a fixed 1/120 s step. Acceleration, friction, air control,
/// variable jump height (release early for a shorter jump), coyote time and jump buffering.
/// The same constants are used by the offline level checker that verified the levels.
/// </summary>
public sealed class Player
{
    public const float W = 12f;
    public const float H = 22f;

    public const float Gravity = 1500f;
    public const float JumpSpeed = 460f;     // apex about 70 px (2.8 tiles)
    public const float MaxSpeed = 250f;
    public const float GroundAccel = 1400f;
    public const float Friction = 900f;
    public const float AirAccel = 700f;
    public const float CutGravity = 2.2f;    // gravity multiplier when the jump key is released while rising
    public const float MaxFall = 700f;
    public const float CoyoteTime = 0.07f;
    public const float BufferTime = 0.10f;

    public float X;
    public float Y;
    public float VX;
    public float VY;
    public int Facing = 1;
    public bool OnGround;
    public bool Dead;
    public float DeadTime;
    public float RunPhase;
    public float Squash;                     // landing squash 0..1
    public float AnimTime;

    public bool EvJump;
    public bool EvLand;
    public float EvLandSpeed;

    public readonly float[] ScarfX = new float[7];
    public readonly float[] ScarfY = new float[7];
    public readonly List<Ghost> Ghosts = new List<Ghost>();

    private float coyote;
    private float buffer;
    private float ghostTimer;

    public float CenterX { get { return X + W / 2f; } }
    public float CenterY { get { return Y + H / 2f; } }

    public void Reset(Level lv)
    {
        X = lv.StartPos.X;
        Y = lv.StartPos.Y;
        VX = 0f;
        VY = 0f;
        Facing = 1;
        OnGround = true;
        Dead = false;
        DeadTime = 0f;
        RunPhase = 0f;
        Squash = 0f;
        coyote = 0f;
        buffer = 0f;
        ghostTimer = 0f;
        Ghosts.Clear();
        EvJump = false;
        EvLand = false;
        for (int i = 0; i < ScarfX.Length; i++)
        {
            ScarfX[i] = CenterX - i * 2f;
            ScarfY[i] = Y + 7f;
        }
    }

    public void Kill()
    {
        if (Dead) return;
        Dead = true;
        DeadTime = 0f;
    }

    private static float Approach(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    public void Update(float dt, Level lv, PlayerInput inp)
    {
        EvJump = false;
        EvLand = false;
        AnimTime += dt;

        coyote = OnGround ? CoyoteTime : Math.Max(0f, coyote - dt);
        buffer = inp.JumpPressed ? BufferTime : Math.Max(0f, buffer - dt);

        int dir = (inp.Right ? 1 : 0) - (inp.Left ? 1 : 0);
        if (dir != 0)
        {
            float acc = OnGround ? GroundAccel : AirAccel;
            if (OnGround && VX != 0f && (VX > 0f) != (dir > 0)) acc += Friction;   // turning around is harder
            VX = Approach(VX, dir * MaxSpeed, acc * dt);
            Facing = dir;
        }
        else if (OnGround)
        {
            VX = Approach(VX, 0f, Friction * dt);
        }

        if (buffer > 0f && coyote > 0f)
        {
            VY = -JumpSpeed;
            OnGround = false;
            coyote = 0f;
            buffer = 0f;
            EvJump = true;
        }

        float g = Gravity;
        if (VY < 0f && !inp.JumpHeld) g *= CutGravity;
        VY = Math.Min(MaxFall, VY + g * dt);

        bool wasGround = OnGround;
        float impact = VY;
        MoveX(dt, lv);
        bool landed = MoveY(dt, lv);
        OnGround = landed;
        if (landed && !wasGround && impact > 160f)
        {
            EvLand = true;
            EvLandSpeed = impact;
            Squash = Math.Min(1f, impact / 520f);
        }

        // animation helpers
        if (OnGround) RunPhase += Math.Abs(VX) * dt * 0.075f;
        Squash = Math.Max(0f, Squash - dt * 5f);
        UpdateScarf(dt);
        UpdateGhosts(dt);
    }

    private void UpdateScarf(float dt)
    {
        float k = Math.Min(1f, dt * 38f);
        ScarfX[0] = CenterX - Facing * 1.5f;
        ScarfY[0] = Y + 6f;
        for (int i = 1; i < ScarfX.Length; i++)
        {
            float tx = ScarfX[i - 1] - Facing * 2.6f - VX * 0.010f;
            float ty = ScarfY[i - 1] + 0.9f - VY * 0.006f + MathF.Sin(AnimTime * 9f + i) * 0.5f;
            ScarfX[i] += (tx - ScarfX[i]) * k;
            ScarfY[i] += (ty - ScarfY[i]) * k;
        }
    }

    private void UpdateGhosts(float dt)
    {
        for (int i = Ghosts.Count - 1; i >= 0; i--)
        {
            Ghost gh = Ghosts[i];
            gh.Age += dt;
            if (gh.Age > 0.22f) Ghosts.RemoveAt(i);
            else Ghosts[i] = gh;
        }
        ghostTimer -= dt;
        bool fast = Math.Abs(VX) > 170f || (!OnGround && Math.Abs(VX) > 60f);
        if (fast && ghostTimer <= 0f)
        {
            ghostTimer = 0.035f;
            Ghost gh = new Ghost();
            gh.X = X;
            gh.Y = Y;
            gh.Facing = Facing;
            gh.Age = 0f;
            Ghosts.Add(gh);
        }
    }

    // ------------------------------------------------------------------ collision (same maths as the level checker)

    private void MoveX(float dt, Level lv)
    {
        X += VX * dt;
        int r0 = (int)Math.Floor(Y / Cfg.T);
        int r1 = (int)Math.Floor((Y + H - 0.01f) / Cfg.T);
        if (VX > 0f)
        {
            int c = (int)Math.Floor((X + W - 0.01f) / Cfg.T);
            for (int r = r0; r <= r1; r++)
            {
                if (lv.IsSolid(c, r))
                {
                    X = c * Cfg.T - W;
                    VX = 0f;
                    break;
                }
            }
        }
        else if (VX < 0f)
        {
            int c = (int)Math.Floor(X / Cfg.T);
            for (int r = r0; r <= r1; r++)
            {
                if (lv.IsSolid(c, r))
                {
                    X = (c + 1) * Cfg.T;
                    VX = 0f;
                    break;
                }
            }
        }
    }

    private bool MoveY(float dt, Level lv)
    {
        Y += VY * dt;
        int c0 = (int)Math.Floor(X / Cfg.T);
        int c1 = (int)Math.Floor((X + W - 0.01f) / Cfg.T);
        if (VY > 0f)
        {
            int r = (int)Math.Floor((Y + H - 0.01f) / Cfg.T);
            for (int c = c0; c <= c1; c++)
            {
                if (lv.IsSolid(c, r))
                {
                    Y = r * Cfg.T - H;
                    VY = 0f;
                    return true;
                }
            }
        }
        else if (VY < 0f)
        {
            int r = (int)Math.Floor(Y / Cfg.T);
            for (int c = c0; c <= c1; c++)
            {
                if (lv.IsSolid(c, r))
                {
                    Y = (r + 1) * Cfg.T;
                    VY = 0f;
                    break;
                }
            }
        }
        return false;
    }
}
