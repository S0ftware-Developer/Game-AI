using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace Ninja;

public enum NinjaPose { Idle, Run, Jump, Fall }

/// <summary>
/// GDI+ renderer: a dark night backdrop, bright platforms, red hazards, a teal exit portal and a black ninja
/// silhouette with a light rim and a red scarf. Everything is drawn in logical 800x640 coordinates and scaled to the window.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    public static readonly Rectangle StartButton = new Rectangle(250, 395, 300, 46);

    private const int T = Cfg.T;

    private static readonly Color cDark = Color.FromArgb(14, 14, 28);
    private static readonly Color cRim = Color.FromArgb(150, 178, 255);
    private static readonly Color cRed = Color.FromArgb(236, 48, 70);
    private static readonly Color cRedHi = Color.FromArgb(255, 130, 140);
    private static readonly Color cRedDark = Color.FromArgb(140, 18, 40);
    private static readonly Color cTeal = Color.FromArgb(90, 240, 255);
    private static readonly Color cWhite = Color.FromArgb(246, 248, 255);
    private static readonly Color cTile = Color.FromArgb(172, 184, 212);
    private static readonly Color cTileAlt = Color.FromArgb(180, 192, 218);
    private static readonly Color cTileTop = Color.FromArgb(250, 252, 255);
    private static readonly Color cTileSide = Color.FromArgb(212, 222, 240);
    private static readonly Color cTileLow = Color.FromArgb(104, 114, 148);

    private readonly Bitmap bg;
    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fHud;
    private readonly Font fLabel;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fBig;
    private readonly Font fFooter;
    private readonly Font fTitle;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;
    private readonly StringFormat sfRight;
    private readonly GraphicsPath titlePath;

    private readonly PointF[] tri = new PointF[3];
    private readonly PointF[] quad = new PointF[4];
    private readonly PointF[] teeth = new PointF[24];

    public GameRenderer()
    {
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;
        tmpPen.LineJoin = LineJoin.Round;

        fHud = new Font("Segoe UI", 15f, FontStyle.Bold, GraphicsUnit.Pixel);
        fLabel = new Font("Segoe UI", 11f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Segoe UI", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Segoe UI", 17f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBig = new Font("Segoe UI", 44f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitle = new Font("Impact", 110f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;
        sfRight = new StringFormat();
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfRight.FormatFlags = StringFormatFlags.NoWrap;

        bg = MakeBackground();
        titlePath = MakeTitlePath();
    }

    public void Dispose()
    {
        bg.Dispose();
        tmp.Dispose();
        tmpPen.Dispose();
        fHud.Dispose();
        fLabel.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fBig.Dispose();
        fFooter.Dispose();
        fTitle.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        sfRight.Dispose();
        titlePath.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static Color A(Color c, float alpha)
    {
        int a = (int)Math.Max(0f, Math.Min(255f, c.A * alpha));
        return Color.FromArgb(a, c.R, c.G, c.B);
    }

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow)
        {
            Color sh = Color.FromArgb(Math.Min((int)c.A, 200), 4, 6, 16);
            g.DrawString(s, f, B(sh), x + 1.5f, y + 1.5f, sf);
        }
        g.DrawString(s, f, B(c), x, y, sf);
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)Cfg.LogicalW, clientH / (float)Cfg.LogicalH);
        float offX = (clientW - Cfg.LogicalW * scale) / 2f;
        float offY = (clientH - Cfg.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, Cfg.LogicalW, Cfg.LogicalH));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (e.State == GameState.Menu) DrawMenu(g, e);
            else if (e.State == GameState.Victory) DrawVictory(g, e);
            else
            {
                DrawGame(g, e);
                if (e.State == GameState.Paused) DrawPause(g);
            }
            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ game screen

    private void DrawGame(Graphics g, GameEngine e)
    {
        g.DrawImage(bg, 0, 0, Cfg.LogicalW, Cfg.LogicalH);
        g.FillRectangle(B(Color.FromArgb(110, 2, 4, 16)), 0, 0, Cfg.LogicalW, Cfg.LogicalH);

        float shx = 0f;
        float shy = 0f;
        if (e.ShakeTimer > 0f)
        {
            float amp = e.ShakeTimer * 18f;
            shx = MathF.Sin(e.Clock * 130f) * amp;
            shy = MathF.Cos(e.Clock * 110f) * amp;
        }

        GraphicsState st = g.Save();
        g.TranslateTransform(shx, Cfg.WorldTop + shy);
        Level lv = e.Level;
        DrawTiles(g, lv);
        DrawSpikes(g, lv);
        DrawLasers(g, lv, e.LevelTime);
        foreach (Saw s in lv.Saws) DrawSawRail(g, s);
        foreach (Saw s in lv.Saws) DrawSaw(g, s.X, s.Y, s.Angle, 12.5f);
        foreach (Spinner sp in lv.Spinners) DrawSpinner(g, sp);
        DrawPortal(g, lv.ExitCenter.X, lv.ExitCenter.Y, e.Clock, e.Completing ? 1f + e.CompleteTimer * 1.6f : 1f);
        DrawPlayer(g, e);
        DrawEffects(g, e);
        g.Restore(st);

        DrawHud(g, e);

        if (e.TipTimer > 0f && !e.Player.Dead && !e.Completing)
        {
            float a = Math.Min(1f, e.TipTimer * 0.8f);
            Txt(g, lv.Tip, fText, Color.FromArgb((int)(235 * a), 214, 224, 255), Cfg.LogicalW / 2f, Cfg.WorldTop + Cfg.WorldH - 22f, sfCenter, true);
        }
        if (e.Player.Dead)
        {
            float a = Math.Min(1f, e.DeathTimer * 6f);
            g.FillRectangle(B(Color.FromArgb((int)(60 * (1f - e.DeathTimer / GameEngine.DeathDelay) * a), 255, 30, 50)), 0, Cfg.HudH, Cfg.LogicalW, Cfg.ViewH);
            Txt(g, "ПОГИБ: " + e.DeathReason.ToUpperInvariant(), fMid, Color.FromArgb((int)(255 * a), cRed), Cfg.LogicalW / 2f, Cfg.HudH + 46f, sfCenter, true);
            Txt(g, "R — сразу заново", fSmall, Color.FromArgb((int)(210 * a), 220, 228, 255), Cfg.LogicalW / 2f, Cfg.HudH + 74f, sfCenter, true);
        }
        if (e.Completing)
        {
            float a = Math.Min(1f, e.CompleteTimer * 3f);
            Txt(g, "УРОВЕНЬ ПРОЙДЕН", fBig, Color.FromArgb((int)(255 * a), cTeal), Cfg.LogicalW / 2f, Cfg.WorldTop + 200f, sfCenter, true);
        }
    }

    private void DrawHud(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(215, 6, 8, 22)), 0, 0, Cfg.LogicalW, Cfg.HudH);
        g.FillRectangle(B(cRed), 0, Cfg.HudH - 3, Cfg.LogicalW, 3);
        Txt(g, "УРОВЕНЬ " + (e.LevelIndex + 1) + " / " + e.LevelCount, fHud, cWhite, 16f, 15f, sfLeft, true);
        Txt(g, e.Level.Name.ToUpperInvariant(), fLabel, Color.FromArgb(255, 170, 190, 235), 16f, 31f, sfLeft, false);
        Txt(g, "ПОПЫТКИ: " + e.Deaths, fHud, cWhite, Cfg.LogicalW - 16f, 15f, sfRight, true);
        Txt(g, "ВРЕМЯ " + FormatTime(e.RunTime), fLabel, Color.FromArgb(255, 170, 190, 235), Cfg.LogicalW - 16f, 31f, sfRight, false);
        if (e.State == GameState.Paused) Txt(g, "ПАУЗА", fHud, cRed, Cfg.LogicalW / 2f, 20f, sfCenter, true);
    }

    private static string FormatTime(float seconds)
    {
        int s = (int)seconds;
        return (s / 60).ToString("D2") + ":" + (s % 60).ToString("D2");
    }

    private void DrawTiles(Graphics g, Level lv)
    {
        for (int r = 0; r < Cfg.Rows; r++)
        {
            for (int c = 0; c < Cfg.Cols; c++)
            {
                if (!lv.Solid[c, r]) continue;
                float x = c * T;
                float y = r * T;
                g.FillRectangle(B(((c + r) & 1) == 0 ? cTile : cTileAlt), x, y, T, T);
                if (!lv.IsSolid(c, r - 1)) g.FillRectangle(B(cTileTop), x, y, T, 4f);
                if (!lv.IsSolid(c, r + 1)) g.FillRectangle(B(cTileLow), x, y + T - 3f, T, 3f);
                if (!lv.IsSolid(c - 1, r)) g.FillRectangle(B(cTileSide), x, y, 2f, T);
                if (!lv.IsSolid(c + 1, r)) g.FillRectangle(B(cTileLow), x + T - 2f, y, 2f, T);
            }
        }
    }

    private void DrawSpikes(Graphics g, Level lv)
    {
        for (int r = 0; r < Cfg.Rows; r++)
        {
            for (int c = 0; c < Cfg.Cols; c++)
            {
                int dir = lv.Spike[c, r];
                if (dir == 0) continue;
                float x = c * T;
                float y = r * T;
                GraphicsState st = g.Save();
                g.TranslateTransform(x + T / 2f, y + T / 2f);
                if (dir == 2) g.RotateTransform(180f);
                else if (dir == 3) g.RotateTransform(-90f);
                else if (dir == 4) g.RotateTransform(90f);
                g.TranslateTransform(-T / 2f, -T / 2f);
                g.FillRectangle(B(cRedDark), 0f, T - 3f, T, 3f);
                for (int i = 0; i < 2; i++)
                {
                    float x0 = 1.5f + i * 11.5f;
                    tri[0] = new PointF(x0, T);
                    tri[1] = new PointF(x0 + 10.5f, T);
                    tri[2] = new PointF(x0 + 5.25f, 9.5f);
                    g.FillPolygon(B(cRed), tri);
                    tri[0] = new PointF(x0, T);
                    tri[1] = new PointF(x0 + 5.25f, T);
                    tri[2] = new PointF(x0 + 5.25f, 9.5f);
                    g.FillPolygon(B(cRedHi), tri);
                }
                g.Restore(st);
            }
        }
    }

    private void DrawLasers(Graphics g, Level lv, float time)
    {
        foreach (Laser l in lv.Lasers)
        {
            bool on = l.Active(time);
            float ex = l.Origin.X;
            float ey = l.Origin.Y;
            // emitter lens on the wall face
            g.FillEllipse(B(on ? Color.FromArgb(255, 255, 90, 110) : Color.FromArgb(255, 110, 20, 40)), ex - 4f, ey - 4f, 8f, 8f);
            g.FillEllipse(B(Color.FromArgb(on ? 255 : 160, 255, 210, 215)), ex - 1.5f, ey - 1.5f, 3f, 3f);
            if (on)
            {
                RectangleF b = l.Beam;
                g.FillRectangle(B(Color.FromArgb(46, 255, 40, 70)), b.X - 5f, b.Y - 5f, b.Width + 10f, b.Height + 10f);
                g.FillRectangle(B(Color.FromArgb(120, 255, 50, 80)), b.X - 2f, b.Y - 2f, b.Width + 4f, b.Height + 4f);
                g.FillRectangle(B(Color.FromArgb(255, 255, 90, 110)), b);
                float cx = b.X + b.Width / 2f;
                float cy = b.Y + b.Height / 2f;
                if (b.Width > b.Height) g.FillRectangle(B(Color.White), b.X, cy - 0.8f, b.Width, 1.6f);
                else g.FillRectangle(B(Color.White), cx - 0.8f, b.Y, 1.6f, b.Height);
            }
            else if (l.Warning(time) && ((int)(time * 16f)) % 2 == 0)
            {
                RectangleF b = l.Beam;
                g.FillRectangle(B(Color.FromArgb(120, 255, 120, 140)), b.X + b.Width / 2f - 0.6f, b.Y + b.Height / 2f - 0.6f,
                    b.Width > b.Height ? b.Width : 1.2f, b.Width > b.Height ? 1.2f : b.Height);
            }
        }
    }

    private void DrawSawRail(Graphics g, Saw s)
    {
        if (Math.Abs(s.X1 - s.X2) < 1f && Math.Abs(s.Y1 - s.Y2) < 1f) return;
        g.DrawLine(P(Color.FromArgb(120, 96, 110, 170), 2f), s.X1, s.Y1, s.X2, s.Y2);
        g.FillEllipse(B(Color.FromArgb(150, 96, 110, 170)), s.X1 - 3f, s.Y1 - 3f, 6f, 6f);
        g.FillEllipse(B(Color.FromArgb(150, 96, 110, 170)), s.X2 - 3f, s.Y2 - 3f, 6f, 6f);
    }

    private void DrawSaw(Graphics g, float cx, float cy, float angle, float radius)
    {
        g.FillEllipse(B(Color.FromArgb(40, 255, 40, 70)), cx - radius - 5f, cy - radius - 5f, (radius + 5f) * 2f, (radius + 5f) * 2f);
        int n = teeth.Length;
        for (int i = 0; i < n; i++)
        {
            float a = angle + i * MathF.PI * 2f / n;
            float rad = (i % 2 == 0) ? radius : radius * 0.7f;
            teeth[i] = new PointF(cx + MathF.Cos(a) * rad, cy + MathF.Sin(a) * rad);
        }
        g.FillPolygon(B(cRed), teeth);
        g.FillEllipse(B(Color.FromArgb(255, 255, 214, 220)), cx - radius * 0.52f, cy - radius * 0.52f, radius * 1.04f, radius * 1.04f);
        g.FillEllipse(B(cRedDark), cx - radius * 0.2f, cy - radius * 0.2f, radius * 0.4f, radius * 0.4f);
    }

    private void DrawSpinner(Graphics g, Spinner sp)
    {
        float cs = MathF.Cos(sp.Angle);
        float sn = MathF.Sin(sp.Angle);
        float ax = sp.X + cs * sp.Radius;
        float ay = sp.Y + sn * sp.Radius;
        float bx = sp.X - cs * sp.Radius;
        float by = sp.Y - sn * sp.Radius;
        g.DrawLine(P(Color.FromArgb(255, cRedDark), 6f), bx, by, ax, ay);
        g.DrawLine(P(cRed, 3.6f), bx, by, ax, ay);
        g.DrawLine(P(Color.FromArgb(220, 255, 170, 180), 1.2f), bx, by, ax, ay);
        DrawSaw(g, ax, ay, sp.Angle * 3f, 10f);
        DrawSaw(g, bx, by, sp.Angle * 3f + 1f, 10f);
        g.FillEllipse(B(Color.FromArgb(255, 70, 78, 120)), sp.X - 7f, sp.Y - 7f, 14f, 14f);
        g.FillEllipse(B(Color.FromArgb(255, 190, 204, 245)), sp.X - 4f, sp.Y - 4f, 8f, 8f);
    }

    private void DrawPortal(Graphics g, float cx, float cy, float clock, float boost)
    {
        float pulse = 0.5f + 0.5f * MathF.Sin(clock * 3f);
        for (int i = 0; i < 4; i++)
        {
            float rw = (12f + i * 7f + pulse * 3f) * boost;
            float rh = (17f + i * 9f + pulse * 4f) * boost;
            g.FillEllipse(B(Color.FromArgb(24 - i * 4, 90, 240, 255)), cx - rw, cy - rh, rw * 2f, rh * 2f);
        }
        float w = 11f * boost;
        float h = 15f * boost;
        g.FillEllipse(B(Color.FromArgb(255, 20, 60, 90)), cx - w, cy - h, w * 2f, h * 2f);
        g.FillEllipse(B(Color.FromArgb(255, 150, 250, 255)), cx - w * 0.62f, cy - h * 0.62f, w * 1.24f, h * 1.24f);
        g.FillEllipse(B(Color.White), cx - w * 0.3f, cy - h * 0.3f, w * 0.6f, h * 0.6f);
        for (int k = 0; k < 3; k++)
        {
            float start = clock * 160f + k * 120f;
            g.DrawArc(P(cTeal, 2.6f), cx - w - 3f, cy - h - 3f, (w + 3f) * 2f, (h + 3f) * 2f, start, 70f);
        }
        for (int k = 0; k < 4; k++)
        {
            float a = clock * 2.4f + k * MathF.PI / 2f;
            float ox = cx + MathF.Cos(a) * (w + 9f);
            float oy = cy + MathF.Sin(a) * (h + 9f);
            g.FillEllipse(B(Color.FromArgb(220, 220, 255, 255)), ox - 1.5f, oy - 1.5f, 3f, 3f);
        }
    }

    // ------------------------------------------------------------------ the ninja

    private void DrawPlayer(Graphics g, GameEngine e)
    {
        Player p = e.Player;
        if (p.Dead) return;

        foreach (Ghost gh in p.Ghosts)
        {
            float k = 1f - gh.Age / 0.22f;
            Color c = Color.FromArgb((int)(60 * k), 130, 160, 255);
            float gx = gh.X + Player.W / 2f;
            g.FillEllipse(B(c), gx - 4.5f, gh.Y + 0.5f, 9f, 9f);
            g.FillRectangle(B(c), gx - 4f, gh.Y + 8f, 8f, 12f);
        }

        NinjaPose pose = NinjaPose.Idle;
        if (!p.OnGround) pose = p.VY < 0f ? NinjaPose.Jump : NinjaPose.Fall;
        else if (Math.Abs(p.VX) > 20f) pose = NinjaPose.Run;
        DrawNinja(g, p.CenterX, p.Y + Player.H, p.Facing, pose, p.RunPhase, p.Squash, p.ScarfX, p.ScarfY, p.AnimTime);
    }

    /// <summary>Draws the ninja with the origin at the centre of his feet. The scarf points are in the same coordinate space as (fx, fy).</summary>
    private void DrawNinja(Graphics g, float fx, float fy, int facing, NinjaPose pose, float phase, float squash,
        float[] scx, float[] scy, float anim)
    {
        // scarf (world space, behind the body)
        for (int i = scx.Length - 1; i >= 1; i--)
        {
            float w = 3.6f - i * 0.42f;
            g.DrawLine(P(Color.FromArgb(255, 120, 14, 36), w + 1.4f), scx[i - 1], scy[i - 1], scx[i], scy[i]);
            g.DrawLine(P(cRed, w), scx[i - 1], scy[i - 1], scx[i], scy[i]);
        }

        GraphicsState st = g.Save();
        g.TranslateTransform(fx, fy);
        float sx = 1f + squash * 0.28f;
        float sy = 1f - squash * 0.28f;
        if (pose == NinjaPose.Jump) { sx = 0.92f; sy = 1.08f; }
        g.ScaleTransform(facing * sx, sy);

        float s = MathF.Sin(phase);
        float c = MathF.Cos(phase);
        float fax = 3f, fay = 0f, fbx = -3f, fby = 0f;
        float hax = 4f, hay = -9f, hbx = -4f, hby = -9f;
        switch (pose)
        {
            case NinjaPose.Run:
                fax = 6f * s; fay = -2.5f * MathF.Max(0f, c);
                fbx = -6f * s; fby = -2.5f * MathF.Max(0f, -c);
                hax = 3f - 5f * s; hay = -10f;
                hbx = -3f + 5f * s; hby = -10f;
                break;
            case NinjaPose.Jump:
                fax = 5f; fay = -6f; fbx = -2f; fby = -3.5f;
                hax = 6f; hay = -19f; hbx = -5f; hby = -17f;
                break;
            case NinjaPose.Fall:
                fax = 4f; fay = -1f; fbx = -4f; fby = -2f;
                hax = 6f; hay = -20f; hbx = -6f; hby = -20f;
                break;
            default:
                hay = -9f + MathF.Sin(anim * 3f) * 0.6f;
                hby = hay;
                break;
        }

        Color dark = cDark;
        // legs
        DrawLimb(g, 1.2f, -8f, fax, fay - 0.5f, 4.4f, dark);
        DrawLimb(g, -1.2f, -8f, fbx, fby - 0.5f, 4.4f, dark);
        // sword on the back
        g.DrawLine(P(Color.FromArgb(255, 176, 186, 214), 1.6f), -1.5f, -14f, -8f, -23f);
        g.DrawLine(P(cRed, 2.2f), -1.5f, -14f, -3.4f, -16.8f);
        // torso
        g.FillRectangle(B(cRim), -5.6f, -16.6f, 11.2f, 10.8f);
        g.FillRectangle(B(dark), -4.8f, -15.8f, 9.6f, 9.2f);
        g.FillRectangle(B(cRed), -4.8f, -9.6f, 9.6f, 1.6f);
        // arms
        DrawLimb(g, 0f, -14.2f, hax, hay, 3.2f, dark);
        DrawLimb(g, 0f, -14.2f, hbx, hby, 3.2f, dark);
        // head
        g.FillEllipse(B(cRim), -5.2f, -23.2f, 10.8f, 10.8f);
        g.FillEllipse(B(dark), -4.4f, -22.4f, 9.2f, 9.2f);
        g.FillRectangle(B(cRed), -4.2f, -19.4f, 8.8f, 2.2f);
        g.FillRectangle(B(Color.White), 0.8f, -18.7f, 3.6f, 1.1f);
        g.Restore(st);
    }

    private void DrawLimb(Graphics g, float x0, float y0, float x1, float y1, float width, Color dark)
    {
        g.DrawLine(P(cRim, width + 1.6f), x0, y0, x1, y1);
        g.DrawLine(P(dark, width), x0, y0, x1, y1);
    }

    private void DrawEffects(Graphics g, GameEngine e)
    {
        foreach (Particle p in e.Particles)
        {
            float k = p.Life / p.MaxLife;
            Color c = Color.FromArgb((int)(255 * k), p.Color.R, p.Color.G, p.Color.B);
            float cs = MathF.Cos(p.Rot) * p.Size;
            float sn = MathF.Sin(p.Rot) * p.Size;
            quad[0] = new PointF(p.X - cs + sn, p.Y - sn - cs);
            quad[1] = new PointF(p.X + cs + sn, p.Y + sn - cs);
            quad[2] = new PointF(p.X + cs - sn, p.Y + sn + cs);
            quad[3] = new PointF(p.X - cs - sn, p.Y - sn + cs);
            g.FillPolygon(B(c), quad);
        }
        foreach (Ring r in e.Rings)
        {
            float k = r.Age / r.MaxAge;
            float rad = r.Radius * (0.2f + 0.8f * k);
            g.DrawEllipse(P(Color.FromArgb((int)(220 * (1f - k)), r.Color.R, r.Color.G, r.Color.B), 3f * (1f - k) + 0.8f),
                r.X - rad, r.Y - rad, rad * 2f, rad * 2f);
        }
    }

    // ------------------------------------------------------------------ menu, pause, victory

    private void DrawMenu(Graphics g, GameEngine e)
    {
        float clock = e.Clock;
        g.DrawImage(bg, 0, 0, Cfg.LogicalW, Cfg.LogicalH);

        // falling petals
        for (int i = 0; i < 9; i++)
        {
            float px = (i * 97f + clock * (14f + i * 3f)) % 840f - 20f;
            float py = (i * 61f + clock * (24f + i * 4f)) % 560f;
            float rot = clock * (1.5f + i * 0.2f);
            GraphicsState st = g.Save();
            g.TranslateTransform(px, py);
            g.RotateTransform(rot * 57f);
            g.FillEllipse(B(Color.FromArgb(200, 230, 40, 64)), -4f, -2f, 8f, 4f);
            g.Restore(st);
        }

        // platforms and the spike pit
        g.FillRectangle(B(cTile), 0, 525, 215, 83);
        g.FillRectangle(B(cTileTop), 0, 525, 215, 5);
        g.FillRectangle(B(cTile), 585, 525, 215, 83);
        g.FillRectangle(B(cTileTop), 585, 525, 215, 5);
        g.FillRectangle(B(cTile), 215, 590, 370, 18);
        for (int x = 215; x < 585; x += 25)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(x, 565f);
            g.FillRectangle(B(cRedDark), 0f, 22f, 25f, 3f);
            for (int i = 0; i < 2; i++)
            {
                float x0 = 1.5f + i * 11.5f;
                tri[0] = new PointF(x0, 25f);
                tri[1] = new PointF(x0 + 10.5f, 25f);
                tri[2] = new PointF(x0 + 5.25f, 9.5f);
                g.FillPolygon(B(cRed), tri);
            }
            g.Restore(st);
        }

        // the ninja leaps over the pit
        float bob = MathF.Sin(clock * 2.2f) * 6f;
        float nx = 400f;
        float ny = 330f + bob;
        for (int i = 0; i < 4; i++)
        {
            g.DrawLine(P(Color.FromArgb(120 - i * 25, 255, 255, 255), 2f), nx - 40f - i * 26f, ny - 40f + i * 5f, nx - 80f - i * 26f, ny - 30f + i * 6f);
        }
        float[] sx = new float[7];
        float[] sy = new float[7];
        GraphicsState ns = g.Save();
        g.TranslateTransform(nx, ny);
        g.ScaleTransform(3f, 3f);
        for (int i = 0; i < 7; i++)
        {
            sx[i] = -1.5f - i * 3.2f;
            sy[i] = -17f + i * 1.0f + MathF.Sin(clock * 8f + i) * 1.5f;
        }
        DrawNinja(g, 0f, 0f, 1, NinjaPose.Jump, 0f, 0f, sx, sy, clock);
        g.Restore(ns);

        // title: red brush ring, slanted white lettering and a slash
        g.DrawArc(P(Color.FromArgb(235, 215, 30, 50), 11f), 400f - 150f, 92f - 96f, 300f, 192f, 130f + clock * 12f, 290f);
        GraphicsState ts = g.Save();
        g.TranslateTransform(0f, MathF.Sin(clock * 1.6f) * 2f);
        g.DrawPath(P(Color.FromArgb(255, 60, 8, 22), 9f), titlePath);
        g.FillPath(B(cWhite), titlePath);
        g.Restore(ts);
        tri[0] = new PointF(250f, 172f);
        tri[1] = new PointF(640f, 148f);
        tri[2] = new PointF(250f, 178f);
        g.FillPolygon(B(cRed), tri);

        Txt(g, "Добегите до портала. Красное — смерть. Инерция — ваш союзник и враг.", fText, Color.FromArgb(255, 214, 224, 255), Cfg.LogicalW / 2f, 205f, sfCenter, true);

        // level selector
        Txt(g, "ВЫБОР УРОВНЯ:  ←  →", fLabel, Color.FromArgb(255, 170, 190, 235), Cfg.LogicalW / 2f, 356f, sfCenter, true);
        for (int i = 0; i < e.LevelCount; i++)
        {
            float bx = 400f - e.LevelCount * 21f + i * 42f + 2f;
            bool unlocked = i <= e.Unlocked;
            bool sel = i == e.MenuSelect;
            g.FillRectangle(B(sel ? cRed : (unlocked ? Color.FromArgb(230, 40, 54, 110) : Color.FromArgb(150, 20, 26, 56))), bx, 368f, 36f, 22f);
            if (sel) g.DrawRectangle(P(Color.White, 1.6f), bx, 368f, 36f, 22f);
            Txt(g, (i + 1).ToString(), fLabel, unlocked ? cWhite : Color.FromArgb(120, 140, 150, 190), bx + 18f, 379f, sfCenter, false);
        }

        // start prompt
        Rectangle sb = StartButton;
        float pulse = 0.5f + 0.5f * MathF.Sin(clock * 4f);
        quad[0] = new PointF(sb.X + 14f, sb.Y);
        quad[1] = new PointF(sb.Right, sb.Y + 4f);
        quad[2] = new PointF(sb.Right - 14f, sb.Bottom);
        quad[3] = new PointF(sb.X, sb.Bottom - 4f);
        g.FillPolygon(B(Color.FromArgb((int)(210 + 45 * pulse), 220, 30, 52)), quad);
        string startText = e.Unlocked > 0 && e.MenuSelect > 0 ? "ENTER — ИГРАТЬ  УРОВЕНЬ " + (e.MenuSelect + 1) : "ENTER — НАЧАТЬ ИГРУ";
        Txt(g, startText, fText, Color.White, sb.X + sb.Width / 2f, sb.Y + sb.Height / 2f, sfCenter, true);

        Txt(g, "A / D  ← →  бег      ПРОБЕЛ / ↑  прыжок      R  заново      Esc  пауза / меню", fSmall, Color.FromArgb(255, 206, 218, 250), Cfg.LogicalW / 2f, 462f, sfCenter, true);
        Txt(g, "Отпустите прыжок раньше — прыжок будет ниже.   N — звук   F11 — полный экран", fSmall, Color.FromArgb(255, 160, 178, 225), Cfg.LogicalW / 2f, 484f, sfCenter, true);
    }

    private void DrawPause(Graphics g)
    {
        g.FillRectangle(B(Color.FromArgb(160, 2, 4, 16)), 0, Cfg.HudH, Cfg.LogicalW, Cfg.ViewH);
        Txt(g, "ПАУЗА", fBig, cWhite, Cfg.LogicalW / 2f, 250f, sfCenter, true);
        g.FillRectangle(B(cRed), 320, 280, 160, 3);
        Txt(g, "Enter / Esc — продолжить", fText, Color.FromArgb(255, 214, 224, 255), Cfg.LogicalW / 2f, 318f, sfCenter, true);
        Txt(g, "R — начать уровень заново", fText, Color.FromArgb(255, 214, 224, 255), Cfg.LogicalW / 2f, 346f, sfCenter, true);
        Txt(g, "M — главное меню", fText, Color.FromArgb(255, 214, 224, 255), Cfg.LogicalW / 2f, 374f, sfCenter, true);
    }

    private void DrawVictory(Graphics g, GameEngine e)
    {
        g.DrawImage(bg, 0, 0, Cfg.LogicalW, Cfg.LogicalH);
        float clock = e.Clock;
        DrawPortal(g, 400f, 250f, clock, 3.2f);
        Txt(g, "ВСЕ УРОВНИ ПРОЙДЕНЫ", fBig, cWhite, Cfg.LogicalW / 2f, 120f, sfCenter, true);
        g.FillRectangle(B(cRed), 280, 152, 240, 3);
        Txt(g, "Время: " + FormatTime(e.RunTime) + "      Попыток: " + e.Deaths, fMid, Color.FromArgb(255, 214, 224, 255), Cfg.LogicalW / 2f, 420f, sfCenter, true);
        Txt(g, "Enter — в главное меню", fText, Color.FromArgb(255, 255, 255, 255), Cfg.LogicalW / 2f, 470f, sfCenter, true);
        Txt(g, "R — сыграть снова", fText, Color.FromArgb(255, 255, 255, 255), Cfg.LogicalW / 2f, 498f, sfCenter, true);
    }

    private void DrawFooter(Graphics g)
    {
        Rectangle r = new Rectangle(0, Cfg.LogicalH - Cfg.FooterH, Cfg.LogicalW, Cfg.FooterH);
        g.FillRectangle(B(Color.FromArgb(255, 5, 7, 18)), r);
        g.FillRectangle(B(Color.FromArgb(255, 180, 30, 52)), 0, r.Y, Cfg.LogicalW, 2);
        g.DrawString(FooterText, fFooter, B(Color.FromArgb(255, 220, 228, 250)),
            new RectangleF(0f, r.Y + 3f, Cfg.LogicalW, r.Height - 3f), sfCenter);
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private GraphicsPath MakeTitlePath()
    {
        GraphicsPath path = new GraphicsPath();
        path.AddString("NINJA", fTitle.FontFamily, (int)FontStyle.Regular, 110f, new PointF(0f, 0f), StringFormat.GenericTypographic);
        RectangleF b = path.GetBounds();
        using (Matrix m = new Matrix())
        {
            m.Translate(Cfg.LogicalW / 2f - (b.X + b.Width / 2f), 92f - (b.Y + b.Height / 2f));
            path.Transform(m);
        }
        using (Matrix sh = new Matrix(1f, 0f, -0.22f, 1f, 92f * 0.22f, 0f))
        {
            path.Transform(sh);
        }
        return path;
    }

    private static Bitmap MakeBackground()
    {
        int W = Cfg.LogicalW;
        int H = Cfg.LogicalH;
        Bitmap bmp = new Bitmap(W, H, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush grad = new LinearGradientBrush(new Rectangle(0, 0, W, H), Color.FromArgb(6, 10, 34), Color.FromArgb(22, 46, 112), 90f))
            {
                g.FillRectangle(grad, 0, 0, W, H);
            }
            Random rnd = new Random(33);
            using (SolidBrush star = new SolidBrush(Color.White))
            {
                for (int i = 0; i < 90; i++)
                {
                    int a = 60 + rnd.Next(150);
                    star.Color = Color.FromArgb(a, 230, 240, 255);
                    float sz = 0.8f + (float)rnd.NextDouble() * 1.6f;
                    g.FillEllipse(star, rnd.Next(W), rnd.Next(H / 2), sz, sz);
                }
            }
            // moon with soft glow
            float mx = 610f;
            float my = 200f;
            using (SolidBrush glow = new SolidBrush(Color.FromArgb(14, 150, 190, 255)))
            {
                for (int i = 7; i >= 1; i--)
                {
                    float r = 62f + i * 22f;
                    g.FillEllipse(glow, mx - r, my - r, r * 2f, r * 2f);
                }
            }
            using (SolidBrush moon = new SolidBrush(Color.FromArgb(232, 240, 255)))
            using (SolidBrush crater = new SolidBrush(Color.FromArgb(70, 150, 175, 225)))
            {
                g.FillEllipse(moon, mx - 62f, my - 62f, 124f, 124f);
                g.FillEllipse(crater, mx - 30f, my - 20f, 26f, 22f);
                g.FillEllipse(crater, mx + 6f, my + 14f, 30f, 24f);
                g.FillEllipse(crater, mx - 4f, my - 44f, 18f, 14f);
                g.FillEllipse(crater, mx + 28f, my - 22f, 14f, 12f);
            }
            // layered mountains
            using (SolidBrush m1 = new SolidBrush(Color.FromArgb(20, 38, 92)))
            using (SolidBrush m2 = new SolidBrush(Color.FromArgb(12, 24, 66)))
            using (SolidBrush m3 = new SolidBrush(Color.FromArgb(6, 12, 38)))
            {
                PointF[] a = { new PointF(0, 470), new PointF(120, 380), new PointF(240, 450), new PointF(380, 350), new PointF(520, 450), new PointF(660, 390), new PointF(800, 470), new PointF(800, 640), new PointF(0, 640) };
                PointF[] b = { new PointF(0, 520), new PointF(160, 440), new PointF(300, 510), new PointF(470, 430), new PointF(640, 520), new PointF(800, 450), new PointF(800, 640), new PointF(0, 640) };
                PointF[] c = { new PointF(0, 580), new PointF(200, 520), new PointF(420, 580), new PointF(620, 540), new PointF(800, 590), new PointF(800, 640), new PointF(0, 640) };
                g.FillPolygon(m1, a);
                g.FillPolygon(m2, b);
                g.FillPolygon(m3, c);
                // pagoda silhouette
                float px = 690f;
                float py = 470f;
                for (int tier = 0; tier < 4; tier++)
                {
                    float w = 70f - tier * 11f;
                    float y = py - tier * 24f;
                    g.FillRectangle(m3, px - w / 2f + 6f, y - 14f, w - 12f, 14f);
                    PointF[] roof = { new PointF(px - w / 2f - 8f, y - 14f), new PointF(px + w / 2f + 8f, y - 14f), new PointF(px + w / 2f - 2f, y - 22f), new PointF(px - w / 2f + 2f, y - 22f) };
                    g.FillPolygon(m3, roof);
                }
                g.FillRectangle(m3, px - 1.5f, py - 4f * 24f - 22f, 3f, 20f);
            }
            // faint mist
            using (SolidBrush mist = new SolidBrush(Color.FromArgb(10, 120, 160, 230)))
            {
                g.FillEllipse(mist, -60, 430, 520, 70);
                g.FillEllipse(mist, 330, 470, 560, 80);
            }
        }
        return bmp;
    }
}
