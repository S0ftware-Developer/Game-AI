namespace Ninja;

public static class Geometry
{
    public static bool CircleHitsRect(float cx, float cy, float radius, RectangleF rect)
    {
        float nx = Math.Max(rect.Left, Math.Min(cx, rect.Right));
        float ny = Math.Max(rect.Top, Math.Min(cy, rect.Bottom));
        float dx = cx - nx;
        float dy = cy - ny;
        return dx * dx + dy * dy <= radius * radius;
    }
}

/// <summary>A saw blade that glides back and forth along a rail at constant speed.</summary>
public sealed class Saw
{
    public const float Radius = 11f;

    public readonly float X1, Y1, X2, Y2;
    public float X;
    public float Y;
    public float Angle;
    private readonly float speed;
    private readonly float phase;
    private readonly float length;

    public Saw(SawDef d)
    {
        X1 = d.X1 * Cfg.T;
        Y1 = d.Y1 * Cfg.T;
        X2 = d.X2 * Cfg.T;
        Y2 = d.Y2 * Cfg.T;
        speed = d.Speed;
        phase = d.Phase;
        float dx = X2 - X1;
        float dy = Y2 - Y1;
        length = MathF.Sqrt(dx * dx + dy * dy);
        Update(0f);
    }

    public void Update(float time)
    {
        Angle = time * 14f;
        if (length < 1f)
        {
            X = X1;
            Y = Y1;
            return;
        }
        float u = (time * speed + phase * 2f * length) % (2f * length);
        float d = u < length ? u : 2f * length - u;
        float f = d / length;
        X = X1 + (X2 - X1) * f;
        Y = Y1 + (Y2 - Y1) * f;
    }

    public bool Hits(RectangleF box)
    {
        return Geometry.CircleHitsRect(X, Y, Radius - 1f, box);
    }
}

/// <summary>A rotating bar with a blade at each end, turning around a fixed pivot.</summary>
public sealed class Spinner
{
    public readonly float X;
    public readonly float Y;
    public readonly float Radius;      // pivot to blade centre, in pixels
    public float Angle;
    private readonly float omega;
    private readonly float phase;

    public Spinner(SpinnerDef d)
    {
        X = d.X * Cfg.T;
        Y = d.Y * Cfg.T;
        Radius = d.Length * Cfg.T;
        omega = d.Omega;
        phase = d.Phase * MathF.PI * 2f;
        Update(0f);
    }

    public void Update(float time)
    {
        Angle = omega * time + phase;
    }

    public bool Hits(RectangleF box)
    {
        float cs = MathF.Cos(Angle);
        float sn = MathF.Sin(Angle);
        if (Geometry.CircleHitsRect(X, Y, 6f, box)) return true;
        for (int k = 1; k <= 4; k++)
        {
            float f = Radius * k / 4f;
            float rad = (k == 4) ? 9f : 5f;
            if (Geometry.CircleHitsRect(X + cs * f, Y + sn * f, rad, box)) return true;
            if (Geometry.CircleHitsRect(X - cs * f, Y - sn * f, rad, box)) return true;
        }
        return false;
    }
}

/// <summary>A laser barrier fired from a wall tile. It blinks on a fixed schedule and is deadly only while on.</summary>
public sealed class Laser
{
    public readonly int Col;
    public readonly int Row;
    public readonly int Dir;
    public readonly float OnTime;
    public readonly float OffTime;
    public readonly float Phase;
    public readonly RectangleF Beam;
    public readonly PointF Origin;     // where the beam leaves the emitter

    public Laser(LaserDef d, Level lv)
    {
        Col = d.Col;
        Row = d.Row;
        Dir = d.Dir;
        OnTime = d.On;
        OffTime = d.Off;
        Phase = d.Phase;

        if (!lv.IsSolid(Col, Row) || Col < 0 || Col >= Cfg.Cols || Row < 0 || Row >= Cfg.Rows)
            throw new InvalidDataException("A laser emitter at " + Col + "," + Row + " must sit inside a solid tile.");

        int dc = Dir == 1 ? 1 : (Dir == 3 ? -1 : 0);
        int dr = Dir == 2 ? 1 : (Dir == 0 ? -1 : 0);
        int c = Col + dc;
        int r = Row + dr;
        int count = 0;
        while (r < Cfg.Rows + 4 && c >= 0 && c < Cfg.Cols && r >= 0 && !lv.IsSolid(c, r))
        {
            c += dc;
            r += dr;
            count++;
            if (count > 60) break;
        }
        if (count == 0) throw new InvalidDataException("The laser at " + Col + "," + Row + " has no free space in front of it.");

        float cx = Col * Cfg.T + Cfg.T / 2f;
        float cy = Row * Cfg.T + Cfg.T / 2f;
        float len = count * Cfg.T;
        if (dc == 0)
        {
            float y0 = dr > 0 ? (Row + 1) * Cfg.T : Row * Cfg.T - len;
            Beam = new RectangleF(cx - 2f, y0, 4f, len);
            Origin = new PointF(cx, dr > 0 ? (Row + 1) * Cfg.T : Row * Cfg.T);
        }
        else
        {
            float x0 = dc > 0 ? (Col + 1) * Cfg.T : Col * Cfg.T - len;
            Beam = new RectangleF(x0, cy - 2f, len, 4f);
            Origin = new PointF(dc > 0 ? (Col + 1) * Cfg.T : Col * Cfg.T, cy);
        }
    }

    private float Cycle { get { return OnTime + OffTime; } }

    private float LocalTime(float time)
    {
        return (time + Phase * Cycle) % Cycle;
    }

    public bool Active(float time)
    {
        return LocalTime(time) < OnTime;
    }

    /// <summary>True during the last moments before the beam switches on.</summary>
    public bool Warning(float time)
    {
        float t = LocalTime(time);
        return t >= Cycle - 0.45f;
    }
}
