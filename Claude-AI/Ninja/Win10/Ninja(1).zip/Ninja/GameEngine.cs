namespace Ninja;

public enum GameState { Menu, Playing, Paused, Victory }

public struct Particle
{
    public float X, Y, VX, VY, Gravity, Size, Rot, Spin;
    public float Life, MaxLife;
    public Color Color;
}

public struct Ring
{
    public float X, Y, Age, MaxAge, Radius;
    public Color Color;
}

/// <summary>Game rules, state machine, hazards, effects and progress. Updated on a fixed 1/120 s step.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;
    public const float DeathDelay = 0.55f;
    public const float CompleteDelay = 1.15f;

    public GameState State = GameState.Menu;
    public int LevelIndex;
    public Level Level;
    public readonly Player Player = new Player();
    public readonly List<Particle> Particles = new List<Particle>();
    public readonly List<Ring> Rings = new List<Ring>();

    public float Clock;              // keeps running (animations)
    public float LevelTime;          // drives hazards; restarts at every respawn
    public float RunTime;
    public int Deaths;
    public int LevelDeaths;
    public int Unlocked;             // highest level index the player may start from
    public int MenuSelect;
    public bool Completing;
    public float CompleteTimer;
    public float DeathTimer;
    public string DeathReason = "";
    public float TipTimer;
    public float ShakeTimer;

    private readonly Random rng = new Random();
    private bool jumpPressed;

    public int LevelCount { get { return LevelLibrary.All.Length; } }

    public GameEngine()
    {
        foreach (LevelDef def in LevelLibrary.All)
        {
            Level.Load(def);        // validates every level before the game starts
        }
        Level = Level.Load(LevelLibrary.All[0]);
        Player.Reset(Level);
    }

    // ------------------------------------------------------------------ flow

    public void StartGame(int index)
    {
        Deaths = 0;
        RunTime = 0f;
        LoadLevel(Math.Max(0, Math.Min(LevelCount - 1, index)));
        State = GameState.Playing;
        Sfx.Play(SfxId.Start);
    }

    private void LoadLevel(int index)
    {
        LevelIndex = index;
        Level = Level.Load(LevelLibrary.All[index]);
        LevelDeaths = 0;
        Completing = false;
        CompleteTimer = 0f;
        TipTimer = 6f;
        Particles.Clear();
        Rings.Clear();
        Respawn();
    }

    private void Respawn()
    {
        LevelTime = 0f;
        DeathTimer = 0f;
        Completing = false;
        ShakeTimer = 0f;
        Player.Reset(Level);
        Level.UpdateHazards(0f);
        jumpPressed = false;
    }

    public void RestartLevel()
    {
        Particles.Clear();
        Rings.Clear();
        Respawn();
    }

    public void AutoPause()
    {
        if (State == GameState.Playing) State = GameState.Paused;
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                if (State == GameState.Menu) StartGame(MenuSelect);
                else if (State == GameState.Paused) State = GameState.Playing;
                else if (State == GameState.Victory) State = GameState.Menu;
                break;
            case Keys.Escape:
                if (State == GameState.Playing) State = GameState.Paused;
                else if (State == GameState.Paused) State = GameState.Playing;
                else if (State == GameState.Victory) State = GameState.Menu;
                break;
            case Keys.M:
                if (State == GameState.Paused) State = GameState.Menu;
                break;
            case Keys.R:
                if (State == GameState.Playing || State == GameState.Paused)
                {
                    RestartLevel();
                    State = GameState.Playing;
                }
                else if (State == GameState.Victory)
                {
                    StartGame(0);
                }
                break;
            case Keys.Left:
            case Keys.A:
                if (State == GameState.Menu)
                {
                    MenuSelect = Math.Max(0, MenuSelect - 1);
                    Sfx.Play(SfxId.Click);
                }
                break;
            case Keys.Right:
            case Keys.D:
                if (State == GameState.Menu)
                {
                    MenuSelect = Math.Min(Unlocked, MenuSelect + 1);
                    Sfx.Play(SfxId.Click);
                }
                break;
            case Keys.Space:
            case Keys.Up:
            case Keys.W:
                if (State == GameState.Playing) jumpPressed = true;
                break;
            case Keys.N:
                Sfx.Muted = !Sfx.Muted;
                break;
        }
    }

    // ------------------------------------------------------------------ update

    public void Update(bool left, bool right, bool jumpHeld)
    {
        Clock += Dt;
        if (State == GameState.Paused || State == GameState.Menu || State == GameState.Victory)
        {
            jumpPressed = false;
            if (State != GameState.Paused) UpdateEffects(Dt);
            return;
        }

        UpdateEffects(Dt);
        LevelTime += Dt;
        if (TipTimer > 0f) TipTimer -= Dt;
        if (ShakeTimer > 0f) ShakeTimer -= Dt;
        Level.UpdateHazards(LevelTime);

        if (Completing)
        {
            CompleteTimer += Dt;
            jumpPressed = false;
            if (CompleteTimer >= CompleteDelay) AdvanceLevel();
            return;
        }

        if (Player.Dead)
        {
            DeathTimer += Dt;
            jumpPressed = false;
            if (DeathTimer >= DeathDelay) Respawn();
            return;
        }

        RunTime += Dt;
        PlayerInput inp = new PlayerInput();
        inp.Left = left;
        inp.Right = right;
        inp.JumpHeld = jumpHeld;
        inp.JumpPressed = jumpPressed;
        jumpPressed = false;

        Player.Update(Dt, Level, inp);
        if (Player.EvJump) Sfx.Play(SfxId.Jump);
        if (Player.EvLand)
        {
            Sfx.Play(SfxId.Land);
            Dust(Player.CenterX, Player.Y + Player.H, Player.EvLandSpeed > 380f ? 10 : 5);
        }

        CheckExit();
        if (!Completing) CheckHazards();
    }

    private void CheckExit()
    {
        Player p = Player;
        if (Math.Abs(p.CenterX - Level.ExitCenter.X) < 10f && Math.Abs(p.CenterY - Level.ExitCenter.Y) < 14f)
        {
            Completing = true;
            CompleteTimer = 0f;
            Sfx.Play(SfxId.Complete);
            Burst(Level.ExitCenter.X, Level.ExitCenter.Y, 46, Color.FromArgb(90, 240, 255), Color.White, 150f, 0f);
            AddRing(Level.ExitCenter.X, Level.ExitCenter.Y, Color.FromArgb(90, 240, 255), 90f, 0.9f);
            AddRing(Level.ExitCenter.X, Level.ExitCenter.Y, Color.White, 55f, 0.6f);
        }
    }

    private void AdvanceLevel()
    {
        Unlocked = Math.Max(Unlocked, Math.Min(LevelCount - 1, LevelIndex + 1));
        if (LevelIndex + 1 >= LevelCount)
        {
            State = GameState.Victory;
            Completing = false;
            return;
        }
        MenuSelect = Math.Min(Unlocked, LevelIndex + 1);
        LoadLevel(LevelIndex + 1);
    }

    private void CheckHazards()
    {
        Player p = Player;
        RectangleF box = new RectangleF(p.X + 1f, p.Y + 1f, Player.W - 2f, Player.H - 2f);

        int c0 = (int)Math.Floor((p.X - 1f) / Cfg.T);
        int c1 = (int)Math.Floor((p.X + Player.W + 1f) / Cfg.T);
        int r0 = (int)Math.Floor((p.Y - 1f) / Cfg.T);
        int r1 = (int)Math.Floor((p.Y + Player.H + 1f) / Cfg.T);
        for (int r = r0; r <= r1; r++)
        {
            for (int c = c0; c <= c1; c++)
            {
                if (c < 0 || c >= Cfg.Cols || r < 0 || r >= Cfg.Rows) continue;
                int dir = Level.Spike[c, r];
                if (dir == 0) continue;
                if (box.IntersectsWith(Level.SpikeRect(c, r, dir)))
                {
                    Kill("Шипы");
                    return;
                }
            }
        }

        foreach (Saw s in Level.Saws)
        {
            if (s.Hits(box))
            {
                Kill("Пила");
                return;
            }
        }
        foreach (Spinner sp in Level.Spinners)
        {
            if (sp.Hits(box))
            {
                Kill("Вращающийся клинок");
                return;
            }
        }
        foreach (Laser l in Level.Lasers)
        {
            if (l.Active(LevelTime) && box.IntersectsWith(l.Beam))
            {
                Kill("Лазер");
                return;
            }
        }
        if (p.Y > Cfg.WorldH + 30f) Kill("Пропасть");
    }

    private void Kill(string reason)
    {
        if (Player.Dead) return;
        Player.Kill();
        DeathReason = reason;
        Deaths++;
        LevelDeaths++;
        ShakeTimer = 0.28f;
        Sfx.Play(SfxId.Death);
        float cx = Player.CenterX;
        float cy = Math.Min(Player.CenterY, Cfg.WorldH - 4f);
        Burst(cx, cy, 34, Color.FromArgb(235, 50, 70), Color.FromArgb(20, 22, 40), 170f, 420f);
        Burst(cx, cy, 14, Color.White, Color.FromArgb(150, 170, 255), 120f, 300f);
        AddRing(cx, cy, Color.FromArgb(235, 50, 70), 46f, 0.4f);
    }

    // ------------------------------------------------------------------ effects

    private void UpdateEffects(float dt)
    {
        for (int i = Particles.Count - 1; i >= 0; i--)
        {
            Particle p = Particles[i];
            p.Life -= dt;
            if (p.Life <= 0f)
            {
                Particles.RemoveAt(i);
                continue;
            }
            p.VY += p.Gravity * dt;
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            p.Rot += p.Spin * dt;
            Particles[i] = p;
        }
        for (int i = Rings.Count - 1; i >= 0; i--)
        {
            Ring r = Rings[i];
            r.Age += dt;
            if (r.Age >= r.MaxAge) Rings.RemoveAt(i);
            else Rings[i] = r;
        }
    }

    private void Burst(float x, float y, int count, Color c1, Color c2, float speed, float gravity)
    {
        for (int i = 0; i < count; i++)
        {
            double a = rng.NextDouble() * Math.PI * 2.0;
            float sp = (float)(rng.NextDouble() * 0.85 + 0.15) * speed;
            Particle p = new Particle();
            p.X = x;
            p.Y = y;
            p.VX = (float)Math.Cos(a) * sp;
            p.VY = (float)Math.Sin(a) * sp - speed * 0.2f;
            p.Gravity = gravity;
            p.Size = 2f + (float)rng.NextDouble() * 3.5f;
            p.Rot = (float)(rng.NextDouble() * 6.28);
            p.Spin = (float)(rng.NextDouble() * 16.0 - 8.0);
            p.MaxLife = 0.45f + (float)rng.NextDouble() * 0.5f;
            p.Life = p.MaxLife;
            p.Color = (i % 2 == 0) ? c1 : c2;
            Particles.Add(p);
        }
    }

    private void Dust(float x, float y, int count)
    {
        for (int i = 0; i < count; i++)
        {
            Particle p = new Particle();
            p.X = x + (float)(rng.NextDouble() * 10.0 - 5.0);
            p.Y = y - 1f;
            p.VX = (float)(rng.NextDouble() * 120.0 - 60.0);
            p.VY = -(float)(rng.NextDouble() * 40.0 + 8.0);
            p.Gravity = 60f;
            p.Size = 1.5f + (float)rng.NextDouble() * 2f;
            p.MaxLife = 0.3f + (float)rng.NextDouble() * 0.2f;
            p.Life = p.MaxLife;
            p.Color = Color.FromArgb(190, 210, 245);
            Particles.Add(p);
        }
    }

    private void AddRing(float x, float y, Color color, float radius, float maxAge)
    {
        Ring r = new Ring();
        r.X = x;
        r.Y = y;
        r.Color = color;
        r.Radius = radius;
        r.MaxAge = maxAge;
        Rings.Add(r);
    }
}
