using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Snake
{
    // Направление движения змейки
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }

    // Главное окно игры «Змейка»
    public class GameForm : Form
    {
        // ==========================================================
        //  Константы окна
        // ==========================================================
        private const int WindowWidth = 900;
        private const int WindowHeight = 650;

        // ==========================================================
        //  Константы игровой сетки
        // ==========================================================
        private const int PlayAreaWidth = 800;
        private const int PlayAreaHeight = 560;
        private const int CellSize = 20;
        private const int Cols = PlayAreaWidth / CellSize;   // 40
        private const int Rows = PlayAreaHeight / CellSize;  // 28

        // Игровое поле размещено по центру верхней части окна,
        // сверху остаётся место под счёт, снизу — под служебную информацию.
        private const int PlayAreaX = (WindowWidth - PlayAreaWidth) / 2;  // 50
        private const int PlayAreaY = 45;

        // Размер отдельного сегмента змейки и еды внутри клетки (с небольшим зазором)
        private const int SegmentSize = 18;
        private const int SegmentOffset = (CellSize - SegmentSize) / 2;

        // ==========================================================
        //  Параметры игрового цикла
        // ==========================================================
        private const int TickIntervalMs = 140;

        private readonly System.Windows.Forms.Timer gameTimer;

        // ==========================================================
        //  Состояние змейки
        // ==========================================================
        private List<Point> snake = new List<Point>(); // [0] — голова
        private Direction currentDirection;
        private readonly Queue<Direction> directionQueue = new Queue<Direction>();
        private const int MaxQueuedDirections = 2;

        // ==========================================================
        //  Еда
        // ==========================================================
        private Point food;
        private bool foodActive;

        // ==========================================================
        //  Общее состояние игры
        // ==========================================================
        private int score;
        private bool isGameOver;

        private readonly Random rng = new Random();

        // ==========================================================
        //  Шрифты и цвета
        // ==========================================================
        private readonly Font scoreFont;
        private readonly Font hintFont;
        private readonly Font titleFont;
        private readonly Font subtitleFont;

        private static readonly Color BorderColor = Color.FromArgb(70, 70, 70);
        private static readonly Color BodyColor = Color.Green;
        private static readonly Color HeadColor = Color.LimeGreen;
        private static readonly Color FoodColor = Color.OrangeRed;
        private static readonly Color PrimaryTextColor = Color.White;
        private static readonly Color SecondaryTextColor = Color.LightGray;

        private const string CopyrightText =
            "© 2026 [Орлов Андрей (совместно с Claude AI)]. Сайт: orlovandrei.space. Все права защищены.";
        private const string ControlsHintText =
            "Стрелки или WASD — движение. R — новая игра после проигрыша. Esc — выход.";

        public GameForm()
        {
            // --- Настройка окна ---
            this.Text = "Змейка";
            this.ClientSize = new Size(WindowWidth, WindowHeight);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Black;
            this.KeyPreview = true;

            // Двойная буферизация, чтобы отрисовка не мерцала
            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer,
                true);

            // --- Шрифты ---
            scoreFont = new Font("Consolas", 16f, FontStyle.Bold);
            hintFont = new Font("Consolas", 10f, FontStyle.Regular);
            titleFont = new Font("Consolas", 28f, FontStyle.Bold);
            subtitleFont = new Font("Consolas", 16f, FontStyle.Regular);

            // --- Подписка на события ---
            this.KeyDown += GameForm_KeyDown;
            this.Paint += GameForm_Paint;

            // --- Игровой таймер ---
            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = TickIntervalMs;
            gameTimer.Tick += GameTimer_Tick;

            StartNewGame();

            gameTimer.Start();
        }

        // ==========================================================
        //  Запуск / перезапуск игры
        // ==========================================================
        private void StartNewGame()
        {
            ResetGame();
        }

        private void ResetGame()
        {
            snake.Clear();
            directionQueue.Clear();

            // Змейка из 4 сегментов примерно в центре поля, движется вправо.
            // Голова — первый элемент списка, хвост тянется влево от неё.
            int centerCol = Cols / 2;
            int centerRow = Rows / 2;

            snake.Add(new Point(centerCol, centerRow));
            snake.Add(new Point(centerCol - 1, centerRow));
            snake.Add(new Point(centerCol - 2, centerRow));
            snake.Add(new Point(centerCol - 3, centerRow));

            currentDirection = Direction.Right;

            score = 0;
            isGameOver = false;

            SpawnFood();
        }

        // ==========================================================
        //  Обработка клавиатуры
        // ==========================================================
        private void GameForm_KeyDown(object? sender, KeyEventArgs e)
        {
            HandleKeyDown(e.KeyCode);
            e.Handled = true;
            e.SuppressKeyPress = true;
        }

        private void HandleKeyDown(Keys key)
        {
            switch (key)
            {
                case Keys.Up:
                case Keys.W:
                    QueueDirection(Direction.Up);
                    break;

                case Keys.Down:
                case Keys.S:
                    QueueDirection(Direction.Down);
                    break;

                case Keys.Left:
                case Keys.A:
                    QueueDirection(Direction.Left);
                    break;

                case Keys.Right:
                case Keys.D:
                    QueueDirection(Direction.Right);
                    break;

                case Keys.R:
                    if (isGameOver)
                    {
                        ResetGame();
                    }
                    break;

                case Keys.Escape:
                    this.Close();
                    break;
            }
        }

        // --- Буферизация направлений: не даём змейке развернуться на 180° ---
        private void QueueDirection(Direction newDirection)
        {
            if (isGameOver) return;

            // Сравниваем с последним направлением в очереди (или текущим, если очередь пуста),
            // чтобы корректно отклонять разворот даже при нескольких быстрых нажатиях подряд.
            Direction compareDirection = directionQueue.Count > 0
                ? directionQueue.Last()
                : currentDirection;

            if (newDirection == GetOppositeDirection(compareDirection))
            {
                return; // разворот на 180° игнорируется
            }

            if (newDirection == compareDirection)
            {
                return; // то же самое направление, нет смысла копить дубликаты
            }

            if (directionQueue.Count >= MaxQueuedDirections)
            {
                return; // очередь уже заполнена — лишние нажатия отбрасываем
            }

            directionQueue.Enqueue(newDirection);
        }

        private static Direction GetOppositeDirection(Direction direction)
        {
            switch (direction)
            {
                case Direction.Up: return Direction.Down;
                case Direction.Down: return Direction.Up;
                case Direction.Left: return Direction.Right;
                default: return Direction.Left; // Right
            }
        }

        private static Point GetDirectionVector(Direction direction)
        {
            switch (direction)
            {
                case Direction.Up: return new Point(0, -1);
                case Direction.Down: return new Point(0, 1);
                case Direction.Left: return new Point(-1, 0);
                default: return new Point(1, 0); // Right
            }
        }

        // ==========================================================
        //  Главный игровой цикл
        // ==========================================================
        private void GameTimer_Tick(object? sender, EventArgs e)
        {
            if (!isGameOver)
            {
                UpdateGame();
            }
            this.Invalidate();
        }

        private void UpdateGame()
        {
            // 1. Берём следующее направление из очереди, если оно есть
            if (directionQueue.Count > 0)
            {
                currentDirection = directionQueue.Dequeue();
            }

            MoveSnake();
        }

        // ==========================================================
        //  Движение змейки и обработка столкновений
        // ==========================================================
        private void MoveSnake()
        {
            Point head = snake[0];
            Point delta = GetDirectionVector(currentDirection);
            Point newHead = new Point(head.X + delta.X, head.Y + delta.Y);

            // 2-3. Проверка столкновения со стеной
            if (CheckCollisionWithWall(newHead))
            {
                EndGame();
                return;
            }

            bool willEatFood = foodActive && newHead == food;

            // 4. Проверка столкновения с собственным телом.
            // Если еда не съедена, хвост на этом шаге уедет — исключаем его из проверки,
            // чтобы голова могла корректно войти в клетку, которую хвост как раз покидает.
            if (CheckCollisionWithSelf(newHead, willEatFood))
            {
                EndGame();
                return;
            }

            // 5. Добавляем новую голову в начало списка сегментов
            snake.Insert(0, newHead);

            // 6-7. Проверяем, съедена ли еда
            if (willEatFood)
            {
                score++;
                SpawnFood();
                // хвост не удаляем — змейка выросла на один сегмент
            }
            else
            {
                // 8. Еда не съедена — удаляем последний сегмент (хвост)
                snake.RemoveAt(snake.Count - 1);
            }
        }

        private bool CheckCollisionWithWall(Point head)
        {
            return head.X < 0 || head.X >= Cols || head.Y < 0 || head.Y >= Rows;
        }

        private bool CheckCollisionWithSelf(Point head, bool willGrow)
        {
            // Если змейка не растёт в этом шаге, последний сегмент (хвост) всё равно уедет,
            // поэтому столкновением с ним пренебрегаем.
            int countToCheck = willGrow ? snake.Count : snake.Count - 1;

            for (int i = 0; i < countToCheck; i++)
            {
                if (snake[i] == head)
                {
                    return true;
                }
            }
            return false;
        }

        // ==========================================================
        //  Еда
        // ==========================================================
        private void SpawnFood()
        {
            List<Point> freeCells = GetFreeCells();

            if (freeCells.Count == 0)
            {
                // Свободных клеток не осталось — редчайший случай победы на всю доску.
                // Просто не создаём новую еду, чтобы не зациклиться в поиске места.
                foodActive = false;
                return;
            }

            food = freeCells[rng.Next(freeCells.Count)];
            foodActive = true;
        }

        private List<Point> GetFreeCells()
        {
            var occupied = new HashSet<Point>(snake);
            var freeCells = new List<Point>(Cols * Rows - occupied.Count);

            for (int x = 0; x < Cols; x++)
            {
                for (int y = 0; y < Rows; y++)
                {
                    Point cell = new Point(x, y);
                    if (!occupied.Contains(cell))
                    {
                        freeCells.Add(cell);
                    }
                }
            }

            return freeCells;
        }

        private bool IsCellOccupied(Point cell)
        {
            for (int i = 0; i < snake.Count; i++)
            {
                if (snake[i] == cell) return true;
            }
            return false;
        }

        // ==========================================================
        //  Завершение игры
        // ==========================================================
        private void EndGame()
        {
            isGameOver = true;
        }

        // ==========================================================
        //  Отрисовка
        // ==========================================================
        private void GameForm_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.Black);

            DrawGame(g);
            DrawHud(g);

            if (isGameOver)
            {
                DrawGameOverScreen(g);
            }
        }

        private void DrawGame(Graphics g)
        {
            // Рамка игрового поля
            using (Pen borderPen = new Pen(BorderColor, 1f))
            {
                g.DrawRectangle(borderPen, PlayAreaX - 1, PlayAreaY - 1, PlayAreaWidth + 1, PlayAreaHeight + 1);
            }

            // Еда
            if (foodActive)
            {
                using (Brush foodBrush = new SolidBrush(FoodColor))
                {
                    float fx = PlayAreaX + food.X * CellSize + SegmentOffset;
                    float fy = PlayAreaY + food.Y * CellSize + SegmentOffset;
                    g.FillEllipse(foodBrush, fx, fy, SegmentSize, SegmentSize);
                }
            }

            // Тело змейки (все сегменты, кроме головы)
            using (Brush bodyBrush = new SolidBrush(BodyColor))
            {
                for (int i = 1; i < snake.Count; i++)
                {
                    DrawSegment(g, bodyBrush, snake[i]);
                }
            }

            // Голова змейки — отдельным ярким цветом
            using (Brush headBrush = new SolidBrush(HeadColor))
            {
                DrawSegment(g, headBrush, snake[0]);
            }

            // Небольшой светлый акцент на голове, чтобы её было легко отличить от тела
            using (Brush eyeBrush = new SolidBrush(Color.White))
            {
                float hx = PlayAreaX + snake[0].X * CellSize + CellSize / 2f - 2f;
                float hy = PlayAreaY + snake[0].Y * CellSize + CellSize / 2f - 2f;
                g.FillEllipse(eyeBrush, hx, hy, 4f, 4f);
            }
        }

        private void DrawSegment(Graphics g, Brush brush, Point cell)
        {
            float x = PlayAreaX + cell.X * CellSize + SegmentOffset;
            float y = PlayAreaY + cell.Y * CellSize + SegmentOffset;
            g.FillRectangle(brush, x, y, SegmentSize, SegmentSize);
        }

        private void DrawHud(Graphics g)
        {
            using (Brush primaryBrush = new SolidBrush(PrimaryTextColor))
            using (Brush secondaryBrush = new SolidBrush(SecondaryTextColor))
            {
                // Счёт — в верхней части окна, над игровым полем
                g.DrawString($"Счёт: {score}", scoreFont, primaryBrush, PlayAreaX, 10f);

                // Служебная информация и копирайт — в нижней части окна
                SizeF hintSize = g.MeasureString(ControlsHintText, hintFont);
                g.DrawString(
                    ControlsHintText,
                    hintFont,
                    secondaryBrush,
                    (WindowWidth - hintSize.Width) / 2f,
                    PlayAreaY + PlayAreaHeight + 8f);

                SizeF copyrightSize = g.MeasureString(CopyrightText, hintFont);
                g.DrawString(
                    CopyrightText,
                    hintFont,
                    secondaryBrush,
                    (WindowWidth - copyrightSize.Width) / 2f,
                    PlayAreaY + PlayAreaHeight + 26f);
            }
        }

        private void DrawGameOverScreen(Graphics g)
        {
            string title = "Игра окончена";
            string scoreLine = $"Счёт: {score}";
            string restartLine = "Нажмите R для новой игры";

            using (Brush whiteBrush = new SolidBrush(Color.White))
            {
                SizeF titleSize = g.MeasureString(title, titleFont);
                SizeF scoreSize = g.MeasureString(scoreLine, subtitleFont);
                SizeF restartSize = g.MeasureString(restartLine, subtitleFont);

                float centerX = PlayAreaX + PlayAreaWidth / 2f;
                float centerY = PlayAreaY + PlayAreaHeight / 2f;

                float titleY = centerY - titleSize.Height - 10f;
                float scoreY = centerY + 10f;
                float restartY = scoreY + scoreSize.Height + 10f;

                g.DrawString(title, titleFont, whiteBrush, centerX - titleSize.Width / 2f, titleY);
                g.DrawString(scoreLine, subtitleFont, whiteBrush, centerX - scoreSize.Width / 2f, scoreY);
                g.DrawString(restartLine, subtitleFont, whiteBrush, centerX - restartSize.Width / 2f, restartY);
            }
        }

        // ==========================================================
        //  Освобождение ресурсов
        // ==========================================================
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                gameTimer?.Stop();
                gameTimer?.Dispose();
                scoreFont?.Dispose();
                hintFont?.Dispose();
                titleFont?.Dispose();
                subtitleFont?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
