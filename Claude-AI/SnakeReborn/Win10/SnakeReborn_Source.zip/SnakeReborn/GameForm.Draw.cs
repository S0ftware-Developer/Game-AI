using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SnakeReborn
{
    public partial class GameForm
    {
        private static readonly Color BackgroundColor = Color.FromArgb(5, 8, 16);
        private static readonly Color FieldColor = Color.FromArgb(11, 20, 34);
        private static readonly Color GridColor = Color.FromArgb(27, 48, 76);
        private static readonly Color NeonGreen = Color.FromArgb(90, 240, 40);
        private static readonly Color NeonGreenDark = Color.FromArgb(10, 70, 10);
        private static readonly Color ScoreGreen = Color.FromArgb(80, 235, 40);

        // ==========================================================
        //  Главный обработчик отрисовки (с масштабированием под размер окна)
        // ==========================================================
        private void GameForm_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.Black);

            float scale = Math.Min(
                this.ClientSize.Width / (float)DesignWidth,
                this.ClientSize.Height / (float)DesignHeight);
            if (scale <= 0f) return;

            float offX = (this.ClientSize.Width - DesignWidth * scale) / 2f;
            float offY = (this.ClientSize.Height - DesignHeight * scale) / 2f;

            // Небольшая тряска экрана в первые кадры Game Over
            if (state == GameState.GameOver && gameOverTicks < 12)
            {
                offX += (float)Math.Sin(gameOverTicks * 2.3) * (12 - gameOverTicks) * 0.8f * scale;
            }

            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);

            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

            using (Brush bg = new SolidBrush(BackgroundColor))
            {
                g.FillRectangle(bg, 0, 0, DesignWidth, DesignHeight);
            }

            DrawPlayfield(g);
            DrawGround(g);
            DrawGrassTufts(g);
            DrawApple(g);
            DrawSnake(g);
            DrawEffects(g);
            DrawFrame(g);
            DrawHud(g);
            DrawFooter(g);

            switch (state)
            {
                case GameState.Start:
                    DrawStartOverlay(g);
                    break;
                case GameState.GameOver:
                    DrawGameOverOverlay(g);
                    break;
            }
        }

        // ==========================================================
        //  Вспомогательные функции
        // ==========================================================
        private static GraphicsPath RoundedRect(RectangleF rect, float radius)
        {
            var path = new GraphicsPath();
            float d = Math.Min(radius * 2f, Math.Min(rect.Width, rect.Height));
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        private static FontFamily GetMonoFamily()
        {
            try
            {
                return new FontFamily("Consolas");
            }
            catch (ArgumentException)
            {
                return FontFamily.GenericMonospace;
            }
        }

        private static StringFormat CreateTypographicFormat()
        {
            var sf = new StringFormat(StringFormat.GenericTypographic);
            sf.FormatFlags |= StringFormatFlags.MeasureTrailingSpaces | StringFormatFlags.NoWrap;
            return sf;
        }

        private static float MeasureTextWidth(Graphics g, string text, Font font, StringFormat sf)
        {
            return g.MeasureString(text, font, PointF.Empty, sf).Width;
        }

        // Текст с тёмной обводкой, выровненный по центру заданной точки
        private static void DrawOutlinedText(Graphics g, string text, float pixelSize,
            float centerX, float centerY, Color fill, Color outline, float outlineWidth)
        {
            using (FontFamily family = GetMonoFamily())
            using (var path = new GraphicsPath())
            {
                path.AddString(text, family, (int)FontStyle.Bold, pixelSize, PointF.Empty, StringFormat.GenericTypographic);

                RectangleF bounds = path.GetBounds();
                using (var m = new Matrix())
                {
                    m.Translate(centerX - (bounds.X + bounds.Width / 2f), centerY - (bounds.Y + bounds.Height / 2f));
                    path.Transform(m);
                }

                using (var pen = new Pen(outline, outlineWidth) { LineJoin = LineJoin.Round })
                using (var brush = new SolidBrush(fill))
                {
                    g.DrawPath(pen, path);
                    g.FillPath(brush, path);
                }
            }
        }

        private static int ClampAlpha(double value)
        {
            return (int)Math.Max(0, Math.Min(255, value));
        }

        // ==========================================================
        //  Игровое поле и сетка
        // ==========================================================
        private void DrawPlayfield(Graphics g)
        {
            using (Brush fieldBrush = new SolidBrush(FieldColor))
            {
                g.FillRectangle(fieldBrush, PlayAreaLeft, GridTop, PlayAreaRight - PlayAreaLeft, GridBottom - GridTop);
            }

            using (Brush gridBrush = new SolidBrush(GridColor))
            {
                for (int i = 0; i <= Cols; i++)
                {
                    g.FillRectangle(gridBrush, PlayAreaLeft + i * CellSize, GridTop, 1f, GridBottom - GridTop);
                }
                for (int j = 0; j <= Rows; j++)
                {
                    g.FillRectangle(gridBrush, PlayAreaLeft, GridTop + j * CellSize, PlayAreaRight - PlayAreaLeft, 1f);
                }
            }
        }

        // ==========================================================
        //  Декоративная полоса: трава + земля
        // ==========================================================
        private void DrawGround(Graphics g)
        {
            float width = PlayAreaRight - PlayAreaLeft;

            // Земля
            using (var dirtBrush = new LinearGradientBrush(
                       new RectangleF(PlayAreaLeft, GroundTop, width, GroundBottom - GroundTop),
                       Color.FromArgb(104, 60, 26), Color.FromArgb(70, 38, 16), LinearGradientMode.Vertical))
            {
                g.FillRectangle(dirtBrush, PlayAreaLeft, GroundTop, width, GroundBottom - GroundTop);
            }

            // Крапинки земли
            for (int i = 0; i < dirtSpecks.Count; i++)
            {
                using (Brush speck = new SolidBrush(dirtSpeckColors[i]))
                {
                    g.FillRectangle(speck, dirtSpecks[i]);
                }
            }

            // Тёмная подложка травы
            using (Brush grassDark = new SolidBrush(Color.FromArgb(48, 160, 28)))
            {
                g.FillRectangle(grassDark, PlayAreaLeft, GroundTop + 14f, width, 12f);
            }

            // Пиксельные травинки разной высоты
            using (Brush grassBrush = new SolidBrush(Color.FromArgb(92, 228, 42)))
            using (Brush grassLight = new SolidBrush(Color.FromArgb(170, 255, 90)))
            {
                for (int i = 0; i < grassHeights.Count; i++)
                {
                    float h = grassHeights[i];
                    float x = PlayAreaLeft + i * 8f;
                    float top = GroundTop + 24f - h;
                    g.FillRectangle(grassBrush, x, top, 8f, h);
                    g.FillRectangle(grassLight, x, top, 8f, 2f);
                }
            }
        }

        // --- Пучки травы по нижним углам (как на референсе) ---
        private void DrawGrassTufts(Graphics g)
        {
            DrawTuft(g, PlayAreaLeft + 6f, GroundTop + 6f, 1f);
            DrawTuft(g, PlayAreaRight - 6f, GroundTop + 6f, -1f);
        }

        private void DrawTuft(Graphics g, float baseX, float baseY, float dir)
        {
            float[] offsets = { 0f, 7f, 14f, 21f, 28f };
            float[] heights = { 16f, 30f, 22f, 34f, 18f };

            using (var fill = new SolidBrush(Color.FromArgb(100, 238, 46)))
            using (var outline = new Pen(Color.FromArgb(14, 80, 14), 1.5f))
            {
                for (int i = 0; i < offsets.Length; i++)
                {
                    float x = baseX + offsets[i] * dir;
                    PointF[] blade =
                    {
                        new PointF(x - 3.5f, baseY),
                        new PointF(x + 0.5f * dir, baseY - heights[i]),
                        new PointF(x + 3.5f, baseY)
                    };
                    g.FillPolygon(fill, blade);
                    g.DrawPolygon(outline, blade);
                }
            }
        }

        // ==========================================================
        //  Неоновая зелёная рамка
        // ==========================================================
        private void DrawNeonBorder(Graphics g, RectangleF rect, float radius, float mainWidth)
        {
            for (int i = 5; i >= 1; i--)
            {
                int alpha = 12 + (6 - i) * 5;
                using (var glowPen = new Pen(Color.FromArgb(alpha, 80, 255, 60), mainWidth + i * 5f) { LineJoin = LineJoin.Round })
                using (var glowPath = RoundedRect(rect, radius))
                {
                    g.DrawPath(glowPen, glowPath);
                }
            }

            using (var outerPen = new Pen(NeonGreenDark, mainWidth + 3f) { LineJoin = LineJoin.Round })
            using (var outerPath = RoundedRect(rect, radius))
            {
                g.DrawPath(outerPen, outerPath);
            }

            using (var mainPen = new Pen(NeonGreen, mainWidth) { LineJoin = LineJoin.Round })
            using (var mainPath = RoundedRect(rect, radius))
            {
                g.DrawPath(mainPen, mainPath);
            }

            float inset = mainWidth / 2f - 1.5f;
            using (var highlightPen = new Pen(Color.FromArgb(210, 190, 255, 140), 2f) { LineJoin = LineJoin.Round })
            using (var highlightPath = RoundedRect(RectangleF.Inflate(rect, -inset, -inset), Math.Max(2f, radius - inset)))
            {
                g.DrawPath(highlightPen, highlightPath);
            }
        }

        private void DrawFrame(Graphics g)
        {
            DrawNeonBorder(g, FrameRect, 10f, 9f);
        }

        // ==========================================================
        //  HUD: SCORE и LEVEL
        // ==========================================================
        private void DrawHud(Graphics g)
        {
            var hudRect = new RectangleF(HudLeft, HudTop, HudWidth, HudHeight);

            using (var panelPath = RoundedRect(hudRect, 24f))
            using (var panelBrush = new LinearGradientBrush(hudRect, Color.FromArgb(9, 20, 30), Color.FromArgb(4, 9, 16), LinearGradientMode.Vertical))
            {
                g.FillPath(panelBrush, panelPath);
            }
            DrawNeonBorder(g, hudRect, 24f, 7f);

            using (StringFormat sf = CreateTypographicFormat())
            {
                float textY = HudTop + (HudHeight - hudFont.Height) / 2f;

                // Слева: SCORE: 000120
                string scoreLabel = "SCORE: ";
                string scoreValue = score.ToString("000000");
                float scoreX = HudLeft + 55f;
                DrawShadowedText(g, scoreLabel, hudFont, Color.White, scoreX, textY, sf);
                float labelW = MeasureTextWidth(g, scoreLabel, hudFont, sf);
                DrawShadowedText(g, scoreValue, hudFont, ScoreGreen, scoreX + labelW, textY, sf);

                // Справа: LEVEL: 01
                string levelLabel = "LEVEL: ";
                string levelValue = level.ToString("00");
                float levelLabelW = MeasureTextWidth(g, levelLabel, hudFont, sf);
                float levelValueW = MeasureTextWidth(g, levelValue, hudFont, sf);
                float levelX = HudLeft + HudWidth - 55f - levelLabelW - levelValueW;
                DrawShadowedText(g, levelLabel, hudFont, Color.White, levelX, textY, sf);
                DrawShadowedText(g, levelValue, hudFont, Color.White, levelX + levelLabelW, textY, sf);
            }
        }

        private static void DrawShadowedText(Graphics g, string text, Font font, Color color, float x, float y, StringFormat sf)
        {
            using (Brush shadow = new SolidBrush(Color.FromArgb(150, 0, 30, 0)))
            using (Brush brush = new SolidBrush(color))
            {
                g.DrawString(text, font, shadow, x + 2.5f, y + 2.5f, sf);
                g.DrawString(text, font, brush, x, y, sf);
            }
        }

        // ==========================================================
        //  Нижняя авторская надпись (всегда помещается целиком)
        // ==========================================================
        private void DrawFooter(Graphics g)
        {
            using (StringFormat sf = CreateTypographicFormat())
            {
                Font font = footerFont;
                bool ownsFont = false;

                float w1 = MeasureTextWidth(g, FooterTextBeforeSite, font, sf);
                float w2 = MeasureTextWidth(g, FooterSiteText, font, sf);
                float maxWidth = DesignWidth - 30f;

                // Если текст не помещается — уменьшаем шрифт, чтобы надпись была видна полностью
                if (w1 + w2 > maxWidth)
                {
                    float factor = maxWidth / (w1 + w2);
                    font = new Font(footerFont.FontFamily, footerFont.Size * factor, FontStyle.Bold, GraphicsUnit.Pixel);
                    ownsFont = true;
                    w1 = MeasureTextWidth(g, FooterTextBeforeSite, font, sf);
                    w2 = MeasureTextWidth(g, FooterSiteText, font, sf);
                }

                float x = (DesignWidth - (w1 + w2)) / 2f;
                float y = FooterTop + (FooterHeight - font.Height) / 2f;

                using (Brush white = new SolidBrush(Color.FromArgb(245, 245, 245)))
                using (Brush green = new SolidBrush(ScoreGreen))
                {
                    g.DrawString(FooterTextBeforeSite, font, white, x, y, sf);
                    g.DrawString(FooterSiteText, font, green, x + w1, y, sf);
                }

                if (ownsFont) font.Dispose();
            }
        }

        // ==========================================================
        //  Яблоко: объёмное тело, стебель, лист, блик
        // ==========================================================
        private void DrawApple(Graphics g)
        {
            if (!foodActive) return;

            float px = PlayAreaLeft + food.X * CellSize;
            float py = GridTop + food.Y * CellSize;
            float bob = (float)Math.Sin(tickCounter * 0.12) * 0.9f;

            var bodyRect = new RectangleF(px + 2.5f, py + 7f + bob, 20f, 17f);

            using (var bodyBrush = new LinearGradientBrush(bodyRect, Color.FromArgb(255, 95, 85), Color.FromArgb(175, 8, 20), LinearGradientMode.ForwardDiagonal))
            using (var outlinePen = new Pen(Color.FromArgb(25, 0, 0), 2f))
            {
                g.FillEllipse(bodyBrush, bodyRect);
                g.DrawEllipse(outlinePen, bodyRect);
            }

            // Блик
            using (Brush glint = new SolidBrush(Color.FromArgb(215, 255, 255, 255)))
            {
                g.FillEllipse(glint, px + 6f, py + 10f + bob, 5f, 4f);
            }

            // Стебель
            using (Brush stem = new SolidBrush(Color.FromArgb(118, 66, 22)))
            using (var stemPen = new Pen(Color.FromArgb(40, 20, 6), 1f))
            {
                var stemRect = new RectangleF(px + 11.2f, py + 2f + bob, 3f, 7f);
                g.FillRectangle(stem, stemRect);
                g.DrawRectangle(stemPen, stemRect.X, stemRect.Y, stemRect.Width, stemRect.Height);
            }

            // Лист
            PointF[] leaf =
            {
                new PointF(px + 14f, py + 5.5f + bob),
                new PointF(px + 20.5f, py + 1.5f + bob),
                new PointF(px + 19.5f, py + 7.5f + bob)
            };
            using (Brush leafBrush = new SolidBrush(Color.FromArgb(100, 235, 60)))
            using (var leafPen = new Pen(Color.FromArgb(12, 70, 12), 1.2f))
            {
                g.FillPolygon(leafBrush, leaf);
                g.DrawPolygon(leafPen, leaf);
            }
        }

        // ==========================================================
        //  Змейка
        // ==========================================================
        private PointF GetSegmentPixel(int index)
        {
            float t = 1f;
            Point current = snake[index];
            Point previous = current;

            if (state == GameState.Playing && stepIntervalMs > 0 && index < prevSnake.Count)
            {
                t = (float)Math.Min(1.0, stepAccumulatorMs / stepIntervalMs);
                previous = prevSnake[index];
            }

            float gx = previous.X + (current.X - previous.X) * t;
            float gy = previous.Y + (current.Y - previous.Y) * t;
            return new PointF(PlayAreaLeft + gx * CellSize, GridTop + gy * CellSize);
        }

        private void DrawSnake(Graphics g)
        {
            // Хвост → голова, чтобы голова всегда рисовалась поверх тела
            for (int i = snake.Count - 1; i >= 1; i--)
            {
                PointF p = GetSegmentPixel(i);
                DrawBodySegment(g, p.X, p.Y);
            }

            PointF headPos = GetSegmentPixel(0);
            DrawHead(g, headPos.X, headPos.Y);
        }

        private void DrawBodySegment(Graphics g, float x, float y)
        {
            var r = new RectangleF(x + 1.5f, y + 1.5f, CellSize - 3f, CellSize - 3f);

            using (var path = RoundedRect(r, 5f))
            using (var fill = new LinearGradientBrush(r, Color.FromArgb(135, 255, 75), Color.FromArgb(32, 170, 24), LinearGradientMode.ForwardDiagonal))
            using (var outline = new Pen(Color.FromArgb(8, 50, 8), 2f) { LineJoin = LineJoin.Round })
            {
                g.FillPath(fill, path);
                g.DrawPath(outline, path);
            }

            // Блики (стеклянный пиксельный вид)
            using (Brush glint = new SolidBrush(Color.FromArgb(130, 255, 255, 255)))
            {
                using (var glintPath = RoundedRect(new RectangleF(r.X + 3.5f, r.Y + 3f, 8f, 4f), 2f))
                {
                    g.FillPath(glint, glintPath);
                }
                g.FillRectangle(glint, r.X + 3.5f, r.Y + 9f, 3f, 3f);
            }

            // Тень внизу справа
            using (Brush shade = new SolidBrush(Color.FromArgb(55, 0, 40, 0)))
            {
                g.FillRectangle(shade, r.X + 4f, r.Bottom - 5f, r.Width - 8f, 3f);
            }
        }

        private void DrawHead(Graphics g, float x, float y)
        {
            var r = new RectangleF(x + 0.5f, y + 0.5f, CellSize - 1f, CellSize - 1f);

            using (var path = RoundedRect(r, 7f))
            using (var fill = new LinearGradientBrush(r, Color.FromArgb(175, 255, 105), Color.FromArgb(55, 205, 32), LinearGradientMode.ForwardDiagonal))
            using (var outline = new Pen(Color.FromArgb(6, 45, 6), 2.2f) { LineJoin = LineJoin.Round })
            {
                g.FillPath(fill, path);
                g.DrawPath(outline, path);
            }

            using (Brush glint = new SolidBrush(Color.FromArgb(120, 255, 255, 255)))
            {
                g.FillRectangle(glint, r.X + 4f, r.Y + 2.5f, 7f, 2.5f);
            }

            // Векторы направления взгляда
            Point dv = GetDirectionVector(currentDirection);
            float fx = dv.X;
            float fy = dv.Y;
            float px = -fy; // перпендикуляр
            float py = fx;

            float cx = x + CellSize / 2f;
            float cy = y + CellSize / 2f;

            // Язычок (мигает)
            if (tickCounter % 60 < 42)
            {
                float mx = cx + fx * 17f;
                float my = cy + fy * 17f;
                using (var tonguePen = new Pen(Color.FromArgb(235, 30, 40), 2.4f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
                {
                    g.DrawLine(tonguePen, cx + fx * 11f, cy + fy * 11f, mx, my);
                    g.DrawLine(tonguePen, mx, my, mx + fx * 5f + px * 3.2f, my + fy * 5f + py * 3.2f);
                    g.DrawLine(tonguePen, mx, my, mx + fx * 5f - px * 3.2f, my + fy * 5f - py * 3.2f);
                }
            }

            // Глаза: два белых глаза с чёрными зрачками, смотрящими по ходу движения
            for (int side = -1; side <= 1; side += 2)
            {
                float ex = cx + fx * 3.5f + px * 5.6f * side;
                float ey = cy + fy * 3.5f + py * 5.6f * side;
                const float eyeR = 4.6f;

                using (Brush eyeWhite = new SolidBrush(Color.White))
                using (var eyePen = new Pen(Color.FromArgb(10, 40, 10), 1.2f))
                {
                    g.FillEllipse(eyeWhite, ex - eyeR, ey - eyeR, eyeR * 2f, eyeR * 2f);
                    g.DrawEllipse(eyePen, ex - eyeR, ey - eyeR, eyeR * 2f, eyeR * 2f);
                }

                float pxx = ex + fx * 1.7f;
                float pyy = ey + fy * 1.7f;
                const float pupilR = 2.3f;
                using (Brush pupil = new SolidBrush(Color.Black))
                {
                    g.FillEllipse(pupil, pxx - pupilR, pyy - pupilR, pupilR * 2f, pupilR * 2f);
                }
            }
        }

        // ==========================================================
        //  Эффекты: частицы и всплывающее "+10"
        // ==========================================================
        private void DrawEffects(Graphics g)
        {
            foreach (Particle p in particles)
            {
                double life = 1.0 - (double)p.Age / p.MaxAge;
                int alpha = ClampAlpha(255 * life);
                float size = Math.Max(1.5f, p.Size * (float)(0.4 + 0.6 * life));

                using (Brush brush = new SolidBrush(Color.FromArgb(alpha, p.Color)))
                {
                    g.FillRectangle(brush, p.X - size / 2f, p.Y - size / 2f, size, size);
                }
            }

            foreach (FloatingText t in floatingTexts)
            {
                double life = 1.0 - (double)t.Age / FloatingText.MaxAge;
                int alpha = ClampAlpha(255 * Math.Min(1.0, life * 1.6));
                DrawOutlinedText(g, t.Text, 22f, t.X, t.Y,
                    Color.FromArgb(alpha, 255, 255, 200),
                    Color.FromArgb(alpha, 10, 70, 10), 4f);
            }
        }

        // ==========================================================
        //  Стартовый экран: SNAKE / PRESS SPACE TO START
        // ==========================================================
        private void DrawStartOverlay(Graphics g)
        {
            float centerX = (PlayAreaLeft + PlayAreaRight) / 2f;
            float centerY = (GridTop + GridBottom) / 2f;

            using (Brush dim = new SolidBrush(Color.FromArgb(185, 3, 8, 14)))
            {
                g.FillRectangle(dim, PlayAreaLeft, GridTop, PlayAreaRight - PlayAreaLeft, GridBottom - GridTop);
            }

            DrawOutlinedText(g, "SNAKE", 120f, centerX, centerY - 70f, Color.FromArgb(110, 255, 60), NeonGreenDark, 14f);

            int blinkAlpha = ClampAlpha(150 + 105 * Math.Sin(tickCounter * 0.12));
            DrawOutlinedText(g, "PRESS SPACE TO START", 34f, centerX, centerY + 40f,
                Color.FromArgb(blinkAlpha, 255, 255, 255), Color.FromArgb(blinkAlpha, 10, 40, 10), 6f);

            DrawOutlinedText(g, "Управление: стрелки на клавиатуре", 20f, centerX, centerY + 100f,
                Color.FromArgb(200, 170, 190, 200), Color.FromArgb(200, 5, 12, 20), 4f);
        }

        // ==========================================================
        //  Экран проигрыша с анимацией: GAME OVER / SCORE / PRESS R TO RESTART
        // ==========================================================
        private void DrawGameOverOverlay(Graphics g)
        {
            float centerX = (PlayAreaLeft + PlayAreaRight) / 2f;
            float centerY = (GridTop + GridBottom) / 2f;

            double t = Math.Min(1.0, gameOverTicks / (double)GameOverAnimTicks);
            double ease = 1.0 - Math.Pow(1.0 - t, 3.0);

            using (Brush dim = new SolidBrush(Color.FromArgb(ClampAlpha(200 * ease), 30, 0, 4)))
            {
                g.FillRectangle(dim, PlayAreaLeft, GridTop, PlayAreaRight - PlayAreaLeft, GridBottom - GridTop);
            }

            // Красная вспышка в момент поражения
            if (gameOverTicks < 8)
            {
                int flashAlpha = ClampAlpha(120 * (1.0 - gameOverTicks / 8.0));
                using (Brush flash = new SolidBrush(Color.FromArgb(flashAlpha, 255, 40, 40)))
                {
                    g.FillRectangle(flash, PlayAreaLeft, GridTop, PlayAreaRight - PlayAreaLeft, GridBottom - GridTop);
                }
            }

            int titleAlpha = ClampAlpha(255 * ease);
            float titleSize = (float)(40 + 72 * ease);
            DrawOutlinedText(g, "GAME OVER", titleSize, centerX, centerY - 80f,
                Color.FromArgb(titleAlpha, 255, 70, 70), Color.FromArgb(titleAlpha, 70, 0, 6), 12f);

            if (ease > 0.55)
            {
                int subAlpha = ClampAlpha(255 * (ease - 0.55) / 0.45);

                DrawOutlinedText(g, "SCORE: " + score.ToString("000000"), 44f, centerX, centerY + 10f,
                    Color.FromArgb(subAlpha, 255, 255, 255), Color.FromArgb(subAlpha, 10, 40, 10), 7f);

                int blink = ClampAlpha(150 + 105 * Math.Sin(tickCounter * 0.12));
                blink = Math.Min(blink, subAlpha);
                DrawOutlinedText(g, "PRESS R TO RESTART", 32f, centerX, centerY + 80f,
                    Color.FromArgb(blink, 120, 255, 80), Color.FromArgb(blink, 10, 60, 10), 6f);
            }
        }
    }
}
