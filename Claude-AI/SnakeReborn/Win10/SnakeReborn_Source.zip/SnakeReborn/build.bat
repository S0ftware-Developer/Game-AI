@echo off
cd /d "%~dp0"

echo ============================================
echo Building Snake for Windows x64
echo ============================================
echo.

dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true

echo.
if errorlevel 1 goto BUILD_FAILED

echo BUILD SUCCESSFUL.
echo.
echo EXE file location:
echo bin\Release\net8.0-windows\win-x64\publish\Snake.exe
goto END

:BUILD_FAILED
echo BUILD FAILED.
echo Check whether .NET SDK is installed.
echo Copy all error text and send it for troubleshooting.

:END
echo.
pause
