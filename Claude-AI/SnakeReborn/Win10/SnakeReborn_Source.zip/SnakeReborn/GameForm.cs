using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SnakeReborn
{
    // Направление движения змейки
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }

    // Состояние игры
    public enum GameState
    {
        Start,     // стартовый экран: SNAKE / PRESS SPACE TO START
        Playing,   // идёт игра
        GameOver   // экран проигрыша
    }

    // Пиксельная частица для эффекта поедания яблока
    public class Particle
    {
        public float X;
        public float Y;
        public float VX;
        public float VY;
        public int Age;
        public int MaxAge;
        public float Size;
        public Color Color;
    }

    // Всплывающая надпись "+10" над съеденным яблоком
    public class FloatingText
    {
        public float X;
        public float Y;
        public int Age;
        public string Text = "";
        public const int MaxAge = 50;
    }

    // Главное окно игры «Змейка»
    public partial class GameForm : Form
    {
        // ==========================================================
        //  Логические размеры "холста" (окно масштабируется под них)
        // ==========================================================
        private const int DesignWidth = 900;
        private const int DesignHeight = 950;

        // HUD (верхняя панель)
        private const float HudLeft = 35f;
        private const float HudTop = 10f;
        private const float HudWidth = 830f;
        private const float HudHeight = 100f;

        // Игровая сетка: 32 x 26 клеток по 25 пикселей
        private const int CellSize = 25;
        private const int Cols = 32;
        private const int Rows = 26;
        private const float PlayAreaLeft = 50f;
        private const float PlayAreaRight = 850f;  // 50 + 32*25
        private const float GridTop = 140f;
        private const float GridBottom = 790f;     // 140 + 26*25

        // Декоративная полоса "трава + земля" под сеткой (вне игровой логики)
        private const float GroundTop = 790f;
        private const float GroundBottom = 850f;

        // Неоновая рамка вокруг игровой зоны
        private static readonly RectangleF FrameRect = new RectangleF(35f, 125f, 830f, 740f);

        // Нижняя область с авторской надписью
        private const float FooterTop = 880f;
        private const float FooterHeight = 50f;

        // ==========================================================
        //  Параметры скорости и очков
        // ==========================================================
        private const int PointsPerApple = 10;
        private const int PointsPerLevel = 100;
        private const double BaseStepIntervalMs = 140.0;
        private const double StepIntervalDecreasePerLevel = 8.0;
        private const double MinStepIntervalMs = 70.0;

        private const int MaxQueuedDirections = 2;
        private const int GameOverAnimTicks = 30;

        // ==========================================================
        //  Состояние змейки
        // ==========================================================
        private readonly List<Point> snake = new List<Point>();      // [0] — голова
        private List<Point> prevSnake = new List<Point>();           // позиции на предыдущем шаге (для плавного движения)
        private Direction currentDirection;
        private readonly Queue<Direction> directionQueue = new Queue<Direction>();

        // ==========================================================
        //  Яблоко
        // ==========================================================
        private Point food;
        private bool foodActive;

        // ==========================================================
        //  Общее состояние игры
        // ==========================================================
        private GameState state;
        private int score;
        private int level;
        private int gameOverTicks;
        private int tickCounter;

        private double stepAccumulatorMs;
        private double stepIntervalMs;
        private long lastElapsedMs;

        private readonly Stopwatch stopwatch = new Stopwatch();
        private readonly System.Windows.Forms.Timer gameTimer;
        private readonly Random rng = new Random();

        private readonly List<Particle> particles = new List<Particle>();
        private readonly List<FloatingText> floatingTexts = new List<FloatingText>();

        // Декор нижней полосы (генерируется один раз)
        private readonly List<float> grassHeights = new List<float>();
        private readonly List<RectangleF> dirtSpecks = new List<RectangleF>();
        private readonly List<Color> dirtSpeckColors = new List<Color>();

        // ==========================================================
        //  Шрифты
        // ==========================================================
        private readonly Font hudFont;
        private readonly Font footerFont;

        private const string FooterTextBeforeSite = "© 2026 Орлов Андрей (совместно с Claude AI). Сайт: ";
        private const string FooterSiteText = "orlovandrei.space.";

        public GameForm()
        {
            this.Text = "Змейка";
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.MaximizeBox = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Black;
            this.KeyPreview = true;
            this.AutoScaleMode = AutoScaleMode.None;

            // Начальный размер окна: 900x950, но не больше доступной высоты экрана
            Rectangle workArea = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
            double fit = Math.Min(1.0, (workArea.Height - 80) / (double)DesignHeight);
            fit = Math.Max(fit, 0.5);
            this.ClientSize = new Size((int)(DesignWidth * fit), (int)(DesignHeight * fit));
            this.MinimumSize = new Size(480, 520);

            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw,
                true);

            hudFont = new Font("Consolas", 34f, FontStyle.Bold, GraphicsUnit.Pixel);
            footerFont = new Font("Consolas", 18f, FontStyle.Bold, GraphicsUnit.Pixel);

            BuildGroundDecor();

            this.KeyDown += GameForm_KeyDown;
            this.Paint += GameForm_Paint;

            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 16; // ~60 кадров в секунду (отрисовка и плавное движение)
            gameTimer.Tick += GameTimer_Tick;

            StartNewGame(false);

            stopwatch.Start();
            lastElapsedMs = 0;
            gameTimer.Start();
        }

        // --- Декор нижней полосы: высота травинок и крапинки земли ---
        private void BuildGroundDecor()
        {
            int bladeCount = (int)((PlayAreaRight - PlayAreaLeft) / 8f);
            for (int i = 0; i < bladeCount; i++)
            {
                grassHeights.Add(6f + rng.Next(0, 3) * 4f); // 6, 10 или 14
            }

            float dirtTop = GroundTop + 24f;
            for (int i = 0; i < 90; i++)
            {
                float w = 6f + rng.Next(0, 3) * 4f;
                float h = 4f + rng.Next(0, 2) * 4f;
                float x = PlayAreaLeft + (float)rng.NextDouble() * (PlayAreaRight - PlayAreaLeft - w);
                float y = dirtTop + (float)rng.NextDouble() * (GroundBottom - dirtTop - h);
                dirtSpecks.Add(new RectangleF(x, y, w, h));

                int shade = rng.Next(3);
                dirtSpeckColors.Add(shade == 0 ? Color.FromArgb(120, 70, 30)
                                  : shade == 1 ? Color.FromArgb(70, 38, 16)
                                  : Color.FromArgb(150, 92, 44));
            }
        }

        // ==========================================================
        //  Освобождение ресурсов
        // ==========================================================
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                gameTimer?.Stop();
                gameTimer?.Dispose();
                hudFont?.Dispose();
                footerFont?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
