using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace SnakeReborn
{
    public partial class GameForm
    {
        // ==========================================================
        //  Запуск / перезапуск игры
        // ==========================================================
        // startImmediately = false — показать стартовый экран (SPACE для старта);
        // true — сразу начать игру (так работает клавиша R).
        private void StartNewGame(bool startImmediately)
        {
            snake.Clear();
            directionQueue.Clear();
            particles.Clear();
            floatingTexts.Clear();

            // Змейка из 5 сегментов в левой-центральной части поля, движется вправо.
            // Голова — первый элемент списка, хвост тянется влево от неё.
            int headCol = Cols / 2;
            int headRow = Rows / 2;
            for (int i = 0; i < 5; i++)
            {
                snake.Add(new Point(headCol - i, headRow));
            }
            prevSnake = new List<Point>(snake);

            currentDirection = Direction.Right;

            score = 0;
            level = 1;
            stepIntervalMs = CalculateStepInterval();
            stepAccumulatorMs = 0;
            gameOverTicks = 0;

            SpawnFood();

            state = startImmediately ? GameState.Playing : GameState.Start;
        }

        private double CalculateStepInterval()
        {
            double interval = BaseStepIntervalMs - (level - 1) * StepIntervalDecreasePerLevel;
            return Math.Max(interval, MinStepIntervalMs);
        }

        // ==========================================================
        //  Клавиатура
        // ==========================================================
        private void GameForm_KeyDown(object? sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    QueueDirection(Direction.Up);
                    break;
                case Keys.Down:
                    QueueDirection(Direction.Down);
                    break;
                case Keys.Left:
                    QueueDirection(Direction.Left);
                    break;
                case Keys.Right:
                    QueueDirection(Direction.Right);
                    break;

                case Keys.Space:
                    if (state == GameState.Start)
                    {
                        state = GameState.Playing;
                        stepAccumulatorMs = 0;
                    }
                    break;

                case Keys.R:
                    StartNewGame(true);
                    break;

                case Keys.Escape:
                    this.Close();
                    break;
            }

            e.Handled = true;
            e.SuppressKeyPress = true;
        }

        // --- Очередь направлений: запрещает разворот на 180° и не теряет быстрые нажатия ---
        private void QueueDirection(Direction newDirection)
        {
            if (state != GameState.Playing) return;

            Direction compareDirection = directionQueue.Count > 0
                ? directionQueue.Last()
                : currentDirection;

            if (newDirection == compareDirection) return;
            if (newDirection == GetOppositeDirection(compareDirection)) return;
            if (directionQueue.Count >= MaxQueuedDirections) return;

            directionQueue.Enqueue(newDirection);
        }

        private static Direction GetOppositeDirection(Direction direction)
        {
            switch (direction)
            {
                case Direction.Up: return Direction.Down;
                case Direction.Down: return Direction.Up;
                case Direction.Left: return Direction.Right;
                default: return Direction.Left;
            }
        }

        private static Point GetDirectionVector(Direction direction)
        {
            switch (direction)
            {
                case Direction.Up: return new Point(0, -1);
                case Direction.Down: return new Point(0, 1);
                case Direction.Left: return new Point(-1, 0);
                default: return new Point(1, 0);
            }
        }

        // ==========================================================
        //  Главный цикл: быстрый таймер для кадров + накопитель для шагов змейки
        // ==========================================================
        private void GameTimer_Tick(object? sender, EventArgs e)
        {
            long now = stopwatch.ElapsedMilliseconds;
            double dt = now - lastElapsedMs;
            lastElapsedMs = now;
            if (dt > 100) dt = 100; // защита от скачка после сворачивания окна

            tickCounter++;

            if (state == GameState.Playing)
            {
                stepAccumulatorMs += dt;
                while (stepAccumulatorMs >= stepIntervalMs && state == GameState.Playing)
                {
                    stepAccumulatorMs -= stepIntervalMs;
                    UpdateGame();
                }
            }

            UpdateEffects();

            if (state == GameState.GameOver && gameOverTicks < GameOverAnimTicks)
            {
                gameOverTicks++;
            }

            this.Invalidate();
        }

        // --- Один логический шаг змейки (по клеткам) ---
        private void UpdateGame()
        {
            if (directionQueue.Count > 0)
            {
                currentDirection = directionQueue.Dequeue();
            }

            prevSnake = new List<Point>(snake);
            MoveSnake();
        }

        private void MoveSnake()
        {
            Point head = snake[0];
            Point delta = GetDirectionVector(currentDirection);
            Point newHead = new Point(head.X + delta.X, head.Y + delta.Y);

            if (CheckCollisionWithWall(newHead))
            {
                EndGame();
                return;
            }

            bool willEat = foodActive && newHead == food;

            if (CheckCollisionWithSelf(newHead, willEat))
            {
                EndGame();
                return;
            }

            snake.Insert(0, newHead);

            if (willEat)
            {
                // хвост не удаляем — змейка растёт; для интерполяции новый сегмент "стоит" на месте хвоста
                prevSnake.Add(prevSnake[prevSnake.Count - 1]);

                OnAppleEaten();
            }
            else
            {
                snake.RemoveAt(snake.Count - 1);
            }
        }

        private bool CheckCollisionWithWall(Point cell)
        {
            return cell.X < 0 || cell.X >= Cols || cell.Y < 0 || cell.Y >= Rows;
        }

        private bool CheckCollisionWithSelf(Point newHead, bool willGrow)
        {
            // Если змейка не растёт, хвост на этом шаге уйдёт — его клетка считается свободной.
            int countToCheck = willGrow ? snake.Count : snake.Count - 1;
            for (int i = 0; i < countToCheck; i++)
            {
                if (snake[i] == newHead) return true;
            }
            return false;
        }

        // --- Яблоко съедено: эффекты, очки, уровень, скорость, новое яблоко ---
        private void OnAppleEaten()
        {
            SpawnEatEffect(food);

            score += PointsPerApple;
            level = score / PointsPerLevel + 1;
            stepIntervalMs = CalculateStepInterval();

            SpawnFood();
        }

        private void SpawnFood()
        {
            List<Point> freeCells = GetFreeCells();
            if (freeCells.Count == 0)
            {
                foodActive = false; // поле полностью занято — яблоко не создаём, цикла нет
                return;
            }

            food = freeCells[rng.Next(freeCells.Count)];
            foodActive = true;
        }

        private List<Point> GetFreeCells()
        {
            var occupied = new HashSet<Point>(snake);
            var free = new List<Point>(Cols * Rows);
            for (int x = 0; x < Cols; x++)
            {
                for (int y = 0; y < Rows; y++)
                {
                    var cell = new Point(x, y);
                    if (!occupied.Contains(cell)) free.Add(cell);
                }
            }
            return free;
        }

        private void EndGame()
        {
            state = GameState.GameOver;
            gameOverTicks = 0;
        }

        // ==========================================================
        //  Эффекты
        // ==========================================================
        private void SpawnEatEffect(Point cell)
        {
            float cx = PlayAreaLeft + cell.X * CellSize + CellSize / 2f;
            float cy = GridTop + cell.Y * CellSize + CellSize / 2f;

            for (int i = 0; i < 16; i++)
            {
                double angle = rng.NextDouble() * Math.PI * 2;
                float speed = 1.2f + (float)rng.NextDouble() * 2.6f;
                Color color;
                switch (i % 3)
                {
                    case 0: color = Color.FromArgb(255, 70, 70); break;
                    case 1: color = Color.FromArgb(140, 255, 90); break;
                    default: color = Color.FromArgb(255, 245, 200); break;
                }

                particles.Add(new Particle
                {
                    X = cx,
                    Y = cy,
                    VX = (float)Math.Cos(angle) * speed,
                    VY = (float)Math.Sin(angle) * speed - 0.8f,
                    Age = 0,
                    MaxAge = 24 + rng.Next(12),
                    Size = 3f + rng.Next(0, 3),
                    Color = color
                });
            }

            floatingTexts.Add(new FloatingText
            {
                X = cx,
                Y = cy - 10f,
                Age = 0,
                Text = "+" + PointsPerApple
            });
        }

        private void UpdateEffects()
        {
            for (int i = particles.Count - 1; i >= 0; i--)
            {
                Particle p = particles[i];
                p.X += p.VX;
                p.Y += p.VY;
                p.VY += 0.10f;
                p.Age++;
                if (p.Age >= p.MaxAge) particles.RemoveAt(i);
            }

            for (int i = floatingTexts.Count - 1; i >= 0; i--)
            {
                FloatingText t = floatingTexts[i];
                t.Y -= 0.7f;
                t.Age++;
                if (t.Age >= FloatingText.MaxAge) floatingTexts.RemoveAt(i);
            }
        }
    }
}
