﻿LODE RUNNER  -  C# / .NET 8 / Windows Forms / GDI+
=====================================================

© 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space

GAME
----
Collect all the gold in each of three hand-made levels, dig temporary holes to trap
the red guards, then reach the glowing EXIT door. Start with 3 lives. Score is kept
between levels (gold +100, trapped guard +200, level complete +500).

Levels: 1 Training Grounds, 2 Underground Vault, 3 Golden Maze.

CONTROLS
--------
Left / A        move left
Right / D       move right
Up / W          climb up a ladder (also climbs out of a hole)
Down / S        climb down a ladder / drop from a rope
Z / J           dig a hole to the left  (the brick left of you, one row down)
X / K           dig a hole to the right
Esc             pause / resume
R               restart the current level
Enter           start game / next level / restart after game over
F11 or Alt+Enter  fullscreen on/off
M               mute sound

Only the orange diggable bricks can be dug; grey steel blocks cannot. A hole stays open
about 3 seconds, then flashes and refills. A guard falls into a hole only where the floor
is at least two bricks thick (or the bottom floor); on a one-brick floor the hole is a
shortcut down. Guards trapped in a hole are taken out of play and return later elsewhere.

PROJECT FILES
-------------
LodeRunner.csproj   project file (net8.0-windows, self-contained single-file win-x64)
Program.cs          entry point
GameForm.cs         window, input, fixed 60 Hz loop, fullscreen
GameWorld.cs        game rules: digging, holes, enemies, scoring, lives, screens flow
GameLevel.cs        tile enum, the three level maps, level validation
GameObjects.cs      player/enemy movement and collision, holes, particles
GameRenderer.cs     all GDI+ drawing in 8-bit style (20x20 retro-pixel sprites and tiles,
                    NES-like palette, no smoothing, nearest-neighbour scaling)
Sfx.cs              sound effects generated in memory at start-up
build.bat           one-click build script
README.txt          this file

BUILDING (needs the .NET 8 SDK on the building PC)
--------------------------------------------------
1. Install the .NET 8 SDK (or any newer SDK, e.g. 9 or 10, which also builds this net8.0 project):
   https://dotnet.microsoft.com/download/dotnet/8.0
2. Extract LodeRunner.zip to a normal folder (for example C:\Games).
3. Double-click build.bat in the LodeRunner folder.
   The first build needs an internet connection so that NuGet can fetch the
   win-x64 runtime packs for the self-contained publish (they are cached afterwards).
4. The finished game is:
      bin\Release\net8.0-windows\win-x64\publish\LodeRunner.exe
   The publish folder contains only this one file.

The .NET SDK is needed only on the PC that builds the game. The published
LodeRunner.exe is self-contained: the PC that runs it does NOT need a separate
.NET Runtime. It still uses Windows components (GDI+, Windows Forms, winmm audio).
The game itself never uses the internet and loads no external files; graphics and
sounds are generated at run time.

WHAT HAS ACTUALLY BEEN CHECKED
------------------------------
Done:
 - The .csproj contains all required properties.
 - Manual source review for compile problems (scopes, types, signatures, brace balance).
 - All three maps checked by a separate script that models walking, climbing, ropes
   and falling: every map is 20x14, has one start, one exit, enemies, and every gold
   piece and the exit are reachable without digging. The game repeats this check
   itself on start-up (GameLevel.Load) and refuses to run on an invalid level.
 - The ZIP was created and its contents listed.

NOTE: the 8-bit graphics rewrite (GameRenderer.cs) was reviewed by hand only; it has not been compiled or run by the author.

NOT done (the authoring environment had no .NET SDK and no Windows):
 - dotnet publish was NOT run, so compilation is NOT confirmed. If the compiler reports
   an error on your PC, please send the message.
 - The executable was NOT built or launched, and no gameplay was played. Movement,
   ladders, digging, enemy behaviour and screens are untested in a running game.
 - Level solvability with enemies in play is not proven; only reachability is checked.

KNOWN LIMITATIONS
-----------------
 - Sound effects share one channel, so a new effect can cut off the previous one.
 - Enemy AI is deliberately simple (ladder/drop search toward the player).
 - Fonts used: Consolas, Arial, Segoe UI (standard on Windows 10/11).
