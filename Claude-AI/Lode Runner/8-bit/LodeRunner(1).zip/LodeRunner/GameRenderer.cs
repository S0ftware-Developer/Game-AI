using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace LodeRunner;

public enum HeroPose { Idle, Walk, Climb, Fall, Rope, Dig, Hurt, Victory }

public enum FoePose { Idle, Walk, Climb, Trapped }

/// <summary>
/// 8-bit style renderer. Every sprite and tile is a 20x20 grid of "retro pixels" drawn with flat colours
/// from a small NES-like palette (1 retro pixel = 2 screen pixels). No smoothing, no gradients.
/// The board is drawn into an 800x560 back buffer and scaled to the window with nearest-neighbour filtering.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    private const int T = Cfg.T;
    private const int PX = 2;

    // ---- palette
    private static readonly Color cInk = Color.FromArgb(12, 10, 24);
    private static readonly Color cWhite = Color.FromArgb(252, 252, 252);
    private static readonly Color cCap = Color.FromArgb(36, 88, 224);
    private static readonly Color cCapD = Color.FromArgb(20, 44, 150);
    private static readonly Color cSkin = Color.FromArgb(252, 188, 140);
    private static readonly Color cHair = Color.FromArgb(120, 64, 24);
    private static readonly Color cRed = Color.FromArgb(220, 36, 36);
    private static readonly Color cRedD = Color.FromArgb(150, 16, 28);
    private static readonly Color cRedL = Color.FromArgb(252, 124, 112);
    private static readonly Color cNavy = Color.FromArgb(32, 48, 150);
    private static readonly Color cShirt = Color.FromArgb(236, 236, 252);
    private static readonly Color cPants = Color.FromArgb(188, 200, 236);
    private static readonly Color cBelt = Color.FromArgb(140, 84, 24);
    private static readonly Color cGold = Color.FromArgb(252, 196, 24);
    private static readonly Color cGoldL = Color.FromArgb(252, 240, 120);
    private static readonly Color cGoldD = Color.FromArgb(176, 104, 8);
    private static readonly Color cSteel = Color.FromArgb(112, 124, 156);
    private static readonly Color cSteelL = Color.FromArgb(188, 200, 228);
    private static readonly Color cSteelD = Color.FromArgb(52, 58, 86);
    private static readonly Color cBrickL = Color.FromArgb(240, 152, 84);
    private static readonly Color cBrick = Color.FromArgb(200, 92, 36);
    private static readonly Color cBrickD = Color.FromArgb(132, 52, 20);
    private static readonly Color cMortar = Color.FromArgb(52, 22, 12);
    private static readonly Color cWood = Color.FromArgb(176, 116, 56);
    private static readonly Color cWoodD = Color.FromArgb(104, 62, 22);
    private static readonly Color cPit = Color.FromArgb(8, 4, 16);
    private static readonly Color cDark1 = Color.FromArgb(8, 8, 32);
    private static readonly Color cDark2 = Color.FromArgb(22, 22, 70);
    private static readonly Color cYellow = Color.FromArgb(252, 228, 64);
    private static readonly Color cOrange = Color.FromArgb(252, 140, 20);
    private static readonly Color cPanel = Color.FromArgb(0, 0, 72);
    private static readonly Color cGreen = Color.FromArgb(100, 252, 140);

    private readonly Bitmap board = new Bitmap(Cfg.LogicalW, Cfg.BoardH, PixelFormat.Format32bppPArgb);
    private readonly ImageAttributes boardAttrs = new ImageAttributes();
    private readonly SolidBrush pBrush = new SolidBrush(Color.Black);
    private readonly Bitmap bgCave;
    private readonly Bitmap tileBrick;
    private readonly Bitmap tileSolid;
    private readonly Bitmap tileLadder;
    private readonly Bitmap tileRope;
    private readonly Bitmap tileGold;
    private readonly Bitmap tileExitLocked;
    private readonly Bitmap tileExitOpenA;
    private readonly Bitmap tileExitOpenB;
    private readonly Bitmap titleBmp;

    private readonly Font fHud;
    private readonly Font fHudLabel;
    private readonly Font fBig;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fFooter;
    private readonly Font fFloat;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;

    // painter state (see Begin / R)
    private int pOx;
    private int pOy;
    private int pU = 1;
    private bool pFlip;

    private static readonly string[] HeartGrid =
    {
        ".11.11.",
        "1211111",
        "1111111",
        ".11111.",
        "..111..",
        "...1..."
    };

    private static readonly string[] FlameA =
    {
        "...1...",
        "..111..",
        ".11211.",
        ".11221.",
        "1122211",
        "1122211",
        ".11211.",
        "..111.."
    };

    private static readonly string[] FlameB =
    {
        "....1..",
        "..1111.",
        ".11211.",
        "112211.",
        "1122211",
        "1122211",
        ".11211.",
        "..111.."
    };

    public GameRenderer()
    {
        boardAttrs.SetWrapMode(WrapMode.TileFlipXY);

        fHud = new Font("Consolas", 20f, FontStyle.Bold, GraphicsUnit.Pixel);
        fHudLabel = new Font("Consolas", 12f, FontStyle.Bold, GraphicsUnit.Pixel);
        fBig = new Font("Consolas", 40f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Consolas", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Consolas", 18f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Consolas", 15f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fFloat = new Font("Consolas", 16f, FontStyle.Bold, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;

        bgCave = MakeCave();
        tileBrick = MakeBrick();
        tileSolid = MakeSolid();
        tileLadder = MakeLadder();
        tileRope = MakeRope();
        tileGold = MakeGold();
        tileExitLocked = MakeExit(0);
        tileExitOpenA = MakeExit(1);
        tileExitOpenB = MakeExit(2);
        titleBmp = MakeTitle();
    }

    public void Dispose()
    {
        board.Dispose();
        boardAttrs.Dispose();
        pBrush.Dispose();
        bgCave.Dispose();
        tileBrick.Dispose();
        tileSolid.Dispose();
        tileLadder.Dispose();
        tileRope.Dispose();
        tileGold.Dispose();
        tileExitLocked.Dispose();
        tileExitOpenA.Dispose();
        tileExitOpenB.Dispose();
        titleBmp.Dispose();
        fHud.Dispose();
        fHudLabel.Dispose();
        fBig.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fFooter.Dispose();
        fFloat.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
    }

    // ------------------------------------------------------------------ pixel painter

    /// <summary>Starts painting a 20x20 retro-pixel sprite at screen position (x,y), one retro pixel = u screen pixels.</summary>
    private void Begin(int x, int y, int u, bool flip)
    {
        pOx = x;
        pOy = y;
        pU = u;
        pFlip = flip;
    }

    /// <summary>Fills a rectangle given in retro pixels.</summary>
    private void R(Graphics g, int px, int py, int pw, int ph, Color c)
    {
        int x = pFlip ? 20 - px - pw : px;
        pBrush.Color = c;
        g.FillRectangle(pBrush, pOx + x * pU, pOy + py * pU, pw * pU, ph * pU);
    }

    /// <summary>Rectangle with a one-pixel dark outline.</summary>
    private void RO(Graphics g, int px, int py, int pw, int ph, Color c)
    {
        R(g, px - 1, py - 1, pw + 2, ph + 2, cInk);
        R(g, px, py, pw, ph, c);
    }

    private void Rect(Graphics g, int x, int y, int w, int h, Color c)
    {
        pBrush.Color = c;
        g.FillRectangle(pBrush, x, y, w, h);
    }

    private void Grid(Graphics g, string[] rows, int x, int y, int u, Color a, Color b)
    {
        for (int r = 0; r < rows.Length; r++)
        {
            string row = rows[r];
            for (int c = 0; c < row.Length; c++)
            {
                char ch = row[c];
                if (ch == '.') continue;
                pBrush.Color = ch == '1' ? a : b;
                g.FillRectangle(pBrush, x + c * u, y + r * u, u, u);
            }
        }
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameWorld w, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)Cfg.LogicalW, clientH / (float)Cfg.LogicalH);
        float offX = (clientW - Cfg.LogicalW * scale) / 2f;
        float offY = (clientH - Cfg.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, Cfg.LogicalW, Cfg.LogicalH));
            g.SmoothingMode = SmoothingMode.None;
            g.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (w.Mode == GameMode.Title)
            {
                DrawTitle(g, w);
            }
            else
            {
                DrawGameScreen(g, w);
                switch (w.Mode)
                {
                    case GameMode.Paused:
                        DrawPanel(g, w, "PAUSED", cYellow,
                            new[] { "The game is paused." },
                            "ESC - RESUME    R - RESTART LEVEL");
                        break;
                    case GameMode.LevelComplete:
                        DrawPanel(g, w, "LEVEL COMPLETE", cGreen,
                            new[]
                            {
                                "Gold collected: " + w.GoldCollected + " / " + w.Level.GoldTotal,
                                "Level bonus: +" + GameWorld.LevelBonus,
                                "Score: " + w.Score
                            },
                            "ENTER - NEXT LEVEL");
                        break;
                    case GameMode.GameOver:
                        DrawPanel(g, w, "GAME OVER", cRed,
                            new[] { "FINAL SCORE", w.Score.ToString("D6") },
                            "ENTER - RESTART");
                        break;
                    case GameMode.Victory:
                        DrawPanel(g, w, "ALL LEVELS COMPLETE", cYellow,
                            new[] { "You emptied every vault!", "FINAL SCORE", w.Score.ToString("D6") },
                            "ENTER - PLAY AGAIN");
                        break;
                }
            }

            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ text helpers

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow)
        {
            using (SolidBrush sb = new SolidBrush(Color.FromArgb(255, 0, 0, 0)))
            {
                g.DrawString(s, f, sb, x + 2f, y + 2f, sf);
            }
        }
        using (SolidBrush b = new SolidBrush(c))
        {
            g.DrawString(s, f, b, x, y, sf);
        }
    }

    private void DrawBox(Graphics g, Rectangle r)
    {
        Rect(g, r.X, r.Y, r.Width, r.Height, cWhite);
        Rect(g, r.X + 4, r.Y + 4, r.Width - 8, r.Height - 8, cPanel);
        Rect(g, r.X + 8, r.Y + 8, r.Width - 16, 2, cCapD);
        Rect(g, r.X + 8, r.Y + r.Height - 10, r.Width - 16, 2, cCapD);
        Rect(g, r.X, r.Y, 4, 4, Color.Black);
        Rect(g, r.X + r.Width - 4, r.Y, 4, 4, Color.Black);
        Rect(g, r.X, r.Y + r.Height - 4, 4, 4, Color.Black);
        Rect(g, r.X + r.Width - 4, r.Y + r.Height - 4, 4, 4, Color.Black);
    }

    // ------------------------------------------------------------------ game screen

    private void DrawGameScreen(Graphics g, GameWorld w)
    {
        using (Graphics bg = Graphics.FromImage(board))
        {
            bg.SmoothingMode = SmoothingMode.None;
            bg.PixelOffsetMode = PixelOffsetMode.Half;
            bg.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
            DrawBoard(bg, w);
        }

        g.DrawImage(board, new Rectangle(0, Cfg.HudH, Cfg.LogicalW, Cfg.BoardH),
            0, 0, Cfg.LogicalW, Cfg.BoardH, GraphicsUnit.Pixel, boardAttrs);

        DrawHud(g, w);

        if (w.HurtFlash > 0 && (w.HurtFlash / 3) % 2 == 0)
        {
            using (SolidBrush red = new SolidBrush(Color.FromArgb(90, 252, 20, 20)))
            {
                g.FillRectangle(red, 0, Cfg.HudH, Cfg.LogicalW, Cfg.BoardH);
            }
        }

        if (w.Mode == GameMode.Playing || w.Mode == GameMode.Paused)
        {
            if (w.BannerTimer > 0)
            {
                Txt(g, "LEVEL " + (w.LevelIndex + 1), fBig, cYellow, Cfg.LogicalW / 2f, Cfg.HudH + 150f, sfCenter, true);
                Txt(g, w.Level.Name.ToUpperInvariant(), fMid, cWhite, Cfg.LogicalW / 2f, Cfg.HudH + 200f, sfCenter, true);
            }
            else if (w.ExitBannerTimer > 0 && (w.ExitBannerTimer / 8) % 2 == 0)
            {
                Txt(g, "EXIT OPEN - REACH THE DOOR!", fMid, cGreen, Cfg.LogicalW / 2f, Cfg.HudH + 60f, sfCenter, true);
            }
        }
    }

    private void DrawHud(Graphics g, GameWorld w)
    {
        Rect(g, 0, 0, Cfg.LogicalW, Cfg.HudH, Color.Black);
        Rect(g, 0, Cfg.HudH - 4, Cfg.LogicalW, 4, cCap);
        Rect(g, 0, Cfg.HudH - 4, Cfg.LogicalW, 2, cSteelL);

        HudItem(g, "SCORE", w.Score.ToString("D6"), 20f);
        HudItem(g, "GOLD REMAINING", w.Level.GoldLeft + " / " + w.Level.GoldTotal, 230f);
        Txt(g, "LIVES", fHudLabel, cSteelL, 470f, 12f, sfLeft, false);
        int lives = Math.Max(0, Math.Min(6, w.Lives));
        for (int i = 0; i < lives; i++)
        {
            int hx = 470 + i * 28;
            Grid(g, HeartGrid, hx + 3, 24, 3, cInk, cInk);
            Grid(g, HeartGrid, hx, 21, 3, cRed, cRedL);
        }
        HudItem(g, "LEVEL", (w.LevelIndex + 1) + " / " + w.LevelCount, 660f);
    }

    private void HudItem(Graphics g, string label, string value, float x)
    {
        Txt(g, label, fHudLabel, cSteelL, x, 12f, sfLeft, false);
        Txt(g, value, fHud, cYellow, x, 30f, sfLeft, true);
    }

    private void DrawBoard(Graphics g, GameWorld w)
    {
        GameLevel lv = w.Level;
        bool exitOpen = w.ExitUnlocked;
        g.DrawImage(bgCave, new Rectangle(0, 0, Cfg.LogicalW, Cfg.BoardH), 0, Cfg.HudH, Cfg.LogicalW, Cfg.BoardH, GraphicsUnit.Pixel);

        for (int r = 0; r < Cfg.Rows; r++)
        {
            for (int c = 0; c < Cfg.Cols; c++)
            {
                int x = c * T;
                int y = r * T;
                switch (lv.Cells[c, r])
                {
                    case Tile.Brick: g.DrawImageUnscaled(tileBrick, x, y); break;
                    case Tile.Solid: g.DrawImageUnscaled(tileSolid, x, y); break;
                    case Tile.Ladder: g.DrawImageUnscaled(tileLadder, x, y); break;
                    case Tile.Rope: g.DrawImageUnscaled(tileRope, x, y); break;
                    case Tile.Exit:
                        if (!exitOpen) g.DrawImageUnscaled(tileExitLocked, x, y);
                        else g.DrawImageUnscaled(((w.Frame / 10) % 2 == 0) ? tileExitOpenA : tileExitOpenB, x, y);
                        break;
                    case Tile.Gold:
                        g.DrawImageUnscaled(tileGold, x, y);
                        DrawSparkle(g, x, y, c, r, w.Frame);
                        break;
                }
            }
        }

        foreach (Hole h in w.Holes)
        {
            DrawHole(g, h, w.Frame);
        }

        foreach (Enemy e in w.Enemies)
        {
            if (e.State == EnemyState.Respawning) continue;
            if (e.Grace > 0 && (w.Frame / 3) % 2 == 0) continue;
            FoePose pose = FoePose.Idle;
            if (e.State == EnemyState.Trapped) pose = FoePose.Trapped;
            else if (e.Climbing) pose = FoePose.Climb;
            else if (e.Moving) pose = FoePose.Walk;
            DrawFoe(g, e.X, e.Y, PX, e.Facing, pose, e.AnimTick, w.Frame);
        }

        Player p = w.Player;
        bool blink = p.Invuln > 0 && (w.Frame / 4) % 2 == 0;
        if (!blink)
        {
            HeroPose pose = HeroPose.Idle;
            int tick = p.AnimTick;
            if (p.State == PlayerState.Hurt) pose = HeroPose.Hurt;
            else if (p.State == PlayerState.Victory) pose = HeroPose.Victory;
            else if (p.State == PlayerState.Digging)
            {
                pose = HeroPose.Dig;
                tick = Math.Min(2, (GameWorld.DigFrames - p.StateTimer) * 3 / GameWorld.DigFrames);
            }
            else if (p.Escaping || p.Climbing) pose = HeroPose.Climb;
            else if (p.Falling) pose = HeroPose.Fall;
            else if (lv.Get(p.Col, p.Row) == Tile.Rope && p.Oy == 0)
            {
                pose = HeroPose.Rope;
                if (!p.Moving) tick = 0;
            }
            else if (p.Moving) pose = HeroPose.Walk;
            DrawHero(g, p.X, p.Y, PX, p.Facing, pose, tick, w.Frame);
        }

        foreach (Particle pt in w.Particles)
        {
            int sz = pt.Life * 3 < pt.MaxLife ? 2 : Math.Max(2, ((int)pt.Size / 2) * 2);
            Rect(g, ((int)pt.X / 2) * 2, ((int)pt.Y / 2) * 2, sz, sz, pt.Color);
        }

        foreach (FloatText t in w.Texts)
        {
            if (t.Life < 12 && (t.Life / 2) % 2 == 0) continue;
            Txt(g, t.Text, fFloat, t.Color, t.X, t.Y, sfLeft, true);
        }
    }

    private void DrawHole(Graphics g, Hole h, int frame)
    {
        int x = h.C * T;
        int y = h.R * T;
        int ph = h.Age < 10 ? (h.Age * T / 10) / 2 * 2 : T; // the brick crumbles away from the top

        if (ph < T)
        {
            g.DrawImage(tileBrick, new Rectangle(x, y + ph, T, T - ph), 0, ph, T, T - ph, GraphicsUnit.Pixel);
        }
        if (ph > 0)
        {
            Rect(g, x, y, T, ph, cPit);
            g.DrawImage(tileBrick, new Rectangle(x, y, 6, ph), 0, 0, 6, ph, GraphicsUnit.Pixel);
            g.DrawImage(tileBrick, new Rectangle(x + T - 6, y, 6, ph), T - 6, 0, 6, ph, GraphicsUnit.Pixel);
        }

        int warnStart = GameWorld.OpenFrames - GameWorld.WarnFrames;
        if (h.Age >= warnStart)
        {
            float prog = Math.Min(1f, (h.Age - warnStart) / (float)GameWorld.WarnFrames);
            int fill = ((int)(prog * T)) / 2 * 2; // the brick regrows from the bottom
            if (fill > 0)
            {
                g.DrawImage(tileBrick, new Rectangle(x, y + T - fill, T, fill), 0, T - fill, T, fill, GraphicsUnit.Pixel);
            }
            if ((frame / 4) % 2 == 0)
            {
                Rect(g, x, y, T, 2, cRed);
                Rect(g, x, y + T - 2, T, 2, cRed);
                Rect(g, x, y, 2, T, cRed);
                Rect(g, x + T - 2, y, 2, T, cRed);
            }
        }
    }

    private void DrawSparkle(Graphics g, int x, int y, int c, int r, int frame)
    {
        int t = (frame + c * 11 + r * 7) % 90;
        if (t >= 12) return;
        Begin(x, y, PX, false);
        if (t < 6)
        {
            R(g, 14, 6, 1, 1, cWhite);
        }
        else
        {
            R(g, 13, 6, 3, 1, cWhite);
            R(g, 14, 5, 1, 3, cWhite);
        }
    }

    // ------------------------------------------------------------------ sprites (20x20 retro pixels)

    private void Arm(Graphics g, int x, int top, int h, bool handAtTop, Color sleeve)
    {
        R(g, x, top, 2, h, sleeve);
        R(g, x, handAtTop ? top : top + h - 1, 2, 1, cSkin);
    }

    private void Plus(Graphics g, int cx, int cy, Color c)
    {
        R(g, cx - 1, cy, 3, 1, c);
        R(g, cx, cy - 1, 1, 3, c);
    }

    private void DrawHero(Graphics g, int x, int y, int u, int facing, HeroPose pose, int tick, int frame)
    {
        bool front = pose == HeroPose.Climb;
        int jump = pose == HeroPose.Victory ? ((tick / 5) % 2) * 2 : 0;
        Begin(x, y - jump * u, u, !front && facing < 0);

        bool flash = pose == HeroPose.Hurt && (frame / 3) % 2 == 0;
        Color shirt = flash ? cRedL : cShirt;
        Color pants = flash ? cRed : cPants;
        Color cap = flash ? cRedD : cCap;

        int k = (tick / 5) % 4;
        int legA = 0, legB = 0, liftA = 0, liftB = 0, by = 0;
        switch (pose)
        {
            case HeroPose.Idle: by = (tick / 20) % 2; break;
            case HeroPose.Walk:
                legA = k == 0 ? 1 : (k == 2 ? -1 : 0);
                legB = -legA;
                liftA = k == 1 ? 1 : 0;
                liftB = k == 3 ? 1 : 0;
                by = (k == 1 || k == 3) ? 1 : 0;
                break;
            case HeroPose.Climb:
                liftA = k < 2 ? 1 : 0;
                liftB = k < 2 ? 0 : 1;
                break;
            case HeroPose.Fall: legA = -2; legB = 2; break;
            case HeroPose.Rope:
                liftA = (tick / 8) % 2;
                liftB = 1 - liftA;
                break;
            case HeroPose.Dig: by = 2; break;
            case HeroPose.Hurt:
                legA = -1;
                legB = 1;
                by = (tick / 3) % 2;
                break;
        }

        // scarf tail (behind)
        if (!front) R(g, 2, 9 + by + (tick / 6) % 2, 4, 1, cRed);

        // back arm
        switch (pose)
        {
            case HeroPose.Climb: Arm(g, 4, k < 2 ? 4 : 9, 5, k < 2, cap); break;
            case HeroPose.Fall: Arm(g, 3, 3 + by, 6, true, cap); break;
            case HeroPose.Rope: Arm(g, 4, 2, 9, true, cap); break;
            case HeroPose.Victory: Arm(g, 3, 2, 6, true, cap); break;
            case HeroPose.Hurt: Arm(g, 3, (tick / 4) % 2 == 0 ? 3 : 8, 6, true, cap); break;
            case HeroPose.Walk: Arm(g, 4 + legB, 10 + by, 4, false, cap); break;
            default: Arm(g, 4, 10 + by, 4, false, cap); break;
        }

        // legs and shoes
        int topLeg = 15 + by;
        int bottomA = 19 - liftA;
        int bottomB = 19 - liftB;
        R(g, 6 + legA, topLeg, 3, bottomA - 1 - topLeg, pants);
        R(g, 6 + legA, bottomA - 1, 4, 1, cNavy);
        R(g, 11 + legB, topLeg, 3, bottomB - 1 - topLeg, pants);
        R(g, 11 + legB, bottomB - 1, 4, 1, cNavy);

        // torso
        RO(g, 6, 10 + by, 8, 5, shirt);
        R(g, 6, 12 + by, 8, 1, cap);
        R(g, 6, 14 + by, 8, 1, cBelt);

        // head
        if (front)
        {
            RO(g, 6, 3 + by, 8, 6, cHair);
            R(g, 6, 2 + by, 8, 4, cap);
            R(g, 7, 1 + by, 6, 1, cap);
        }
        else
        {
            R(g, 5, 4 + by, 2, 4, cHair);
            RO(g, 6, 3 + by, 8, 6, cSkin);
            R(g, 6, 2 + by, 8, 2, cap);
            R(g, 7, 1 + by, 6, 1, cap);
            R(g, 12, 4 + by, 4, 1, flash ? cRedD : cCapD);
            R(g, 9, 2 + by, 2, 1, cWhite);
            if (pose == HeroPose.Hurt)
            {
                R(g, 10, 5 + by, 1, 1, cInk);
                R(g, 12, 5 + by, 1, 1, cInk);
                R(g, 11, 6 + by, 1, 1, cInk);
                R(g, 10, 7 + by, 1, 1, cInk);
                R(g, 12, 7 + by, 1, 1, cInk);
            }
            else
            {
                R(g, 11, 5 + by, 1, 2, cInk);
            }
            if (pose == HeroPose.Victory) R(g, 10, 7 + by, 4, 1, cInk);
            else if (pose != HeroPose.Hurt) R(g, 12, 7 + by, 2, 1, cRedD);
        }
        R(g, 6, 9 + by, 8, 1, cRed); // scarf around the neck

        // front arm
        switch (pose)
        {
            case HeroPose.Climb: Arm(g, 14, k < 2 ? 9 : 4, 5, k >= 2, cap); break;
            case HeroPose.Fall: Arm(g, 15, 3 + by, 6, true, cap); break;
            case HeroPose.Rope: Arm(g, 14, 2, 9, true, cap); break;
            case HeroPose.Victory: Arm(g, 15, 2, 6, true, cap); break;
            case HeroPose.Hurt: Arm(g, 15, (tick / 4) % 2 == 0 ? 8 : 3, 6, true, cap); break;
            case HeroPose.Walk: Arm(g, 14 + legA, 10 + by, 4, false, cap); break;
            default: Arm(g, 14, 10 + by, 4, false, cap); break;
        }

        // digging tool (tick holds the swing stage 0..2)
        if (pose == HeroPose.Dig)
        {
            if (tick <= 0)
            {
                R(g, 15, 7 + by, 1, 6, cWood);
                R(g, 14, 6 + by, 3, 1, cSteelL);
            }
            else if (tick == 1)
            {
                R(g, 15, 12 + by, 5, 1, cWood);
                R(g, 19, 11 + by, 1, 3, cSteelL);
            }
            else
            {
                R(g, 16, 13 + by, 1, 4, cWood);
                R(g, 15, 17 + by, 3, 1, cSteelL);
            }
        }

        if (pose == HeroPose.Hurt)
        {
            for (int i = 0; i < 3; i++)
            {
                float a = tick * 0.3f + i * 2.09f;
                Plus(g, 10 + (int)(MathF.Cos(a) * 7f), (int)(MathF.Sin(a) * 2f), cYellow);
            }
        }
        else if (pose == HeroPose.Victory)
        {
            for (int i = 0; i < 3; i++)
            {
                float a = tick * 0.2f + i * 2.09f;
                Plus(g, 10 + (int)(MathF.Cos(a) * 9f), 8 + (int)(MathF.Sin(a) * 7f), cGoldL);
            }
        }
    }

    private void DrawFoe(Graphics g, int x, int y, int u, int facing, FoePose pose, int tick, int frame)
    {
        bool front = pose == FoePose.Climb;
        Begin(x, y, u, !front && facing < 0);

        int k = (tick / 5) % 4;
        int legA = 0, legB = 0, liftA = 0, liftB = 0, by = 0;
        int armA = 0, armB = 0;
        switch (pose)
        {
            case FoePose.Walk:
                legA = k == 0 ? 1 : (k == 2 ? -1 : 0);
                legB = -legA;
                liftA = k == 1 ? 1 : 0;
                liftB = k == 3 ? 1 : 0;
                by = (k == 1 || k == 3) ? 1 : 0;
                armA = legA;
                armB = legB;
                break;
            case FoePose.Climb:
                liftA = k < 2 ? 1 : 0;
                liftB = k < 2 ? 0 : 1;
                armA = k < 2 ? -2 : 0;
                armB = k < 2 ? 0 : -2;
                break;
            case FoePose.Trapped:
                by = 2;
                armA = (tick / 4) % 2 == 0 ? -3 : 0;
                armB = (tick / 4) % 2 == 0 ? 0 : -3;
                break;
        }

        // legs and shoes
        int topLeg = 15 + by;
        int bottomA = 19 - liftA;
        int bottomB = 19 - liftB;
        R(g, 6 + legA, topLeg, 3, bottomA - 1 - topLeg, cRedD);
        R(g, 5 + legA, bottomA - 1, 4, 1, cNavy);
        R(g, 11 + legB, topLeg, 3, bottomB - 1 - topLeg, cRedD);
        R(g, 11 + legB, bottomB - 1, 4, 1, cNavy);

        // arms
        R(g, 2, 11 + by + armA, 2, 4, cRed);
        R(g, 16, 11 + by + armB, 2, 4, cRed);

        // body and head
        RO(g, 4, 5 + by, 12, 11, cRed);
        R(g, 7, 12 + by, 6, 3, cRedL);

        // helmet
        RO(g, 5, 1 + by, 10, 4, cRedD);
        R(g, 3, 4 + by, 14, 1, cRedD);
        R(g, 7, 2 + by, 4, 1, cRedL);

        // eyes
        if (pose == FoePose.Climb)
        {
            R(g, 6, 6 + by, 3, 4, cWhite);
            R(g, 11, 6 + by, 3, 4, cWhite);
            R(g, 7, 7 + by, 2, 2, cInk);
            R(g, 12, 7 + by, 2, 2, cInk);
        }
        else if (pose == FoePose.Trapped)
        {
            R(g, 8, 6 + by, 5, 4, cWhite);
            R(g, 8, 6 + by, 1, 1, cInk);
            R(g, 12, 6 + by, 1, 1, cInk);
            R(g, 10, 7 + by, 1, 2, cInk);
            R(g, 8, 9 + by, 1, 1, cInk);
            R(g, 12, 9 + by, 1, 1, cInk);
        }
        else
        {
            R(g, 9, 6 + by, 5, 4, cWhite);
            R(g, 12, 7 + by, 2, 2, cInk);
            R(g, 8, 5 + by, 6, 1, cInk);
        }

        if (pose == FoePose.Trapped)
        {
            for (int i = 0; i < 3; i++)
            {
                float a = tick * 0.3f + i * 2.09f;
                Plus(g, 10 + (int)(MathF.Cos(a) * 7f), (int)(MathF.Sin(a) * 2f), cYellow);
            }
        }
    }

    // ------------------------------------------------------------------ title screen and panels

    private void DrawTitle(Graphics g, GameWorld w)
    {
        int f = w.Frame;
        int areaH = Cfg.HudH + Cfg.BoardH;
        g.DrawImage(bgCave, new Rectangle(0, 0, Cfg.LogicalW, areaH), 0, 0, Cfg.LogicalW, areaH, GraphicsUnit.Pixel);

        for (int c = 0; c < Cfg.Cols; c++)
        {
            g.DrawImageUnscaled(tileBrick, c * T, areaH - T);
        }
        for (int i = 0; i < 6; i++)
        {
            g.DrawImageUnscaled(tileGold, 310 + i * 24 + (i % 2) * 6, areaH - T - 22 - (i % 3) * 4);
        }
        for (int i = 0; i < 4; i++)
        {
            g.DrawImageUnscaled(tileGold, 340 + i * 26, areaH - T - 40 - (i % 2) * 4);
        }

        DrawTorch(g, 30, 240, f);
        DrawTorch(g, 750, 240, f);

        DrawHero(g, 40, areaH - T - 120, 6, 1, HeroPose.Walk, f, f);
        DrawFoe(g, 600, areaH - T - 80, 4, -1, FoePose.Walk, f, f);
        DrawFoe(g, 690, areaH - T - 80, 4, -1, FoePose.Walk, f + 10, f);

        g.DrawImage(titleBmp, new Rectangle(75, 14, 650, 120), 0, 0, titleBmp.Width, titleBmp.Height, GraphicsUnit.Pixel);

        Rectangle panel = new Rectangle(215, 150, 370, 232);
        DrawBox(g, panel);
        string[] lines =
        {
            "ARROWS / WASD  move and climb",
            "Z / J  dig left    X / K  dig right",
            "ESC  pause         R  restart level",
            "F11  fullscreen    M  mute",
            "Collect all gold, then reach EXIT.",
            "Trap guards in holes: +200 points.",
            "Holes refill after about 3 seconds!"
        };
        Txt(g, "HOW TO PLAY", fText, cYellow, panel.X + panel.Width / 2f, panel.Y + 26f, sfCenter, true);
        for (int i = 0; i < lines.Length; i++)
        {
            Txt(g, lines[i], fSmall, cWhite, panel.X + 18f, panel.Y + 58f + i * 24f, sfLeft, false);
        }

        Rectangle btn = new Rectangle(220, 405, 360, 46);
        DrawBox(g, btn);
        Color pc = ((f / 30) % 2 == 0) ? cWhite : cYellow;
        Txt(g, "PRESS ENTER TO START GAME", fText, pc, btn.X + btn.Width / 2f, btn.Y + btn.Height / 2f, sfCenter, true);
    }

    private void DrawTorch(Graphics g, int x, int y, int frame)
    {
        Rect(g, x - 2, y + 34, 8, 30, cWoodD);
        Rect(g, x - 6, y + 28, 16, 8, cWood);
        Rect(g, x - 6, y + 28, 16, 2, cBrickL);
        Grid(g, ((frame / 8) % 2 == 0) ? FlameA : FlameB, x - 12, y, 6, cOrange, cYellow);
    }

    private void DrawPanel(Graphics g, GameWorld w, string title, Color titleColor, string[] lines, string prompt)
    {
        using (SolidBrush dim = new SolidBrush(Color.FromArgb(160, 0, 0, 12)))
        {
            g.FillRectangle(dim, 0, 0, Cfg.LogicalW, Cfg.HudH + Cfg.BoardH);
        }
        Rectangle r = new Rectangle(130, 150, 540, 320);
        DrawBox(g, r);
        Txt(g, title, fBig, titleColor, r.X + r.Width / 2f, r.Y + 60f, sfCenter, true);
        for (int i = 0; i < lines.Length; i++)
        {
            Txt(g, lines[i], fMid, cWhite, r.X + r.Width / 2f, r.Y + 126f + i * 40f, sfCenter, true);
        }
        Color pc = ((w.Frame / 30) % 2 == 0) ? cWhite : cYellow;
        Txt(g, prompt, fText, pc, r.X + r.Width / 2f, r.Y + r.Height - 38f, sfCenter, true);
    }

    private void DrawFooter(Graphics g)
    {
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit; // the footer stays smooth and easy to read
        Rectangle r = new Rectangle(0, Cfg.LogicalH - Cfg.FooterH, Cfg.LogicalW, Cfg.FooterH);
        Rect(g, r.X, r.Y, r.Width, r.Height, Color.Black);
        Rect(g, 0, r.Y, Cfg.LogicalW, 2, cCap);
        using (SolidBrush tb = new SolidBrush(cWhite))
        {
            g.DrawString(FooterText, fFooter, tb, new RectangleF(0f, r.Y + 3f, Cfg.LogicalW, r.Height - 3f), sfCenter);
        }
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private Bitmap MakeTitle()
    {
        int tw = 130;
        int th = 24;
        Bitmap bmp = new Bitmap(tw, th, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        using (Font f = new Font("Consolas", 18f, FontStyle.Bold, GraphicsUnit.Pixel))
        using (StringFormat sf = new StringFormat())
        using (SolidBrush ink = new SolidBrush(cInk))
        using (SolidBrush top = new SolidBrush(cYellow))
        using (SolidBrush bottom = new SolidBrush(cOrange))
        {
            g.SmoothingMode = SmoothingMode.None;
            g.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            sf.FormatFlags = StringFormatFlags.NoWrap;
            string text = "LODE RUNNER";
            for (int dx = -1; dx <= 1; dx++)
            {
                for (int dy = -1; dy <= 2; dy++)
                {
                    if (dx == 0 && dy == 0) continue;
                    g.DrawString(text, f, ink, new RectangleF(dx, dy, tw, th), sf);
                }
            }
            g.SetClip(new Rectangle(0, 0, tw, 11));
            g.DrawString(text, f, top, new RectangleF(0, 0, tw, th), sf);
            g.SetClip(new Rectangle(0, 11, tw, th - 11));
            g.DrawString(text, f, bottom, new RectangleF(0, 0, tw, th), sf);
            g.ResetClip();
        }
        return bmp;
    }

    private Bitmap MakeCave()
    {
        int W = Cfg.LogicalW;
        int H = Cfg.HudH + Cfg.BoardH;
        Bitmap bmp = new Bitmap(W, H, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.None;
            Begin(0, 0, 1, false);
            R(g, 0, 0, W, H, cDark1);
            for (int y = 0; y < H; y += 20)
            {
                R(g, 0, y, W, 2, cDark2);
                int off = ((y / 20) % 2) * 20;
                for (int x = off; x < W; x += 40)
                {
                    R(g, x, y, 2, 20, cDark2);
                }
            }
            Random rnd = new Random(7);
            for (int i = 0; i < 90; i++)
            {
                int sx = (rnd.Next(W / 2)) * 2;
                int sy = (rnd.Next(H / 2)) * 2;
                R(g, sx, sy, 4, 4, Color.FromArgb(34, 34, 98));
            }
            for (int x = 0; x < W; x += 40)
            {
                int h = 20 + rnd.Next(5) * 8;
                for (int row = 0; row < h; row += 4)
                {
                    int w = (36 * (h - row) / h) / 2 * 2;
                    if (w < 2) w = 2;
                    R(g, x + (40 - w) / 2, row, w, 4, cInk);
                }
            }
        }
        return bmp;
    }

    private Bitmap MakeBrick()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            Begin(0, 0, PX, false);
            for (int py = 0; py < 20; py++)
            {
                int row = py / 5;
                int ry = py % 5;
                int off = (row % 2 == 0) ? 0 : 5;
                for (int px = 0; px < 20; px++)
                {
                    int bx = (px + off) % 10;
                    Color c;
                    if (ry == 0 || bx == 0) c = cMortar;
                    else if (ry == 1 || bx == 1) c = cBrickL;
                    else if (ry == 4 || bx == 9) c = cBrickD;
                    else c = cBrick;
                    R(g, px, py, 1, 1, c);
                }
            }
        }
        return bmp;
    }

    private Bitmap MakeSolid()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            Begin(0, 0, PX, false);
            for (int py = 0; py < 20; py++)
            {
                for (int px = 0; px < 20; px++)
                {
                    Color c = cSteel;
                    if (px == 0 || py == 0) c = cSteelL;
                    else if (px == 19 || py == 19) c = cSteelD;
                    else if (px == 18 || py == 18) c = cSteelD;
                    else if (px == 1 || py == 1) c = cSteelL;
                    else if ((px + py) % 6 == 0) c = cSteelD;
                    R(g, px, py, 1, 1, c);
                }
            }
            int[] rv = { 3, 15 };
            foreach (int ax in rv)
            {
                foreach (int ay in rv)
                {
                    R(g, ax, ay, 2, 2, cInk);
                    R(g, ax, ay, 1, 1, cWhite);
                }
            }
        }
        return bmp;
    }

    private Bitmap MakeLadder()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            Begin(0, 0, PX, false);
            int[] rungs = { 2, 7, 12, 17 };
            foreach (int ry in rungs)
            {
                R(g, 6, ry, 8, 1, cWhite);
                R(g, 6, ry + 1, 8, 1, cSteel);
            }
            int[] rails = { 4, 14 };
            foreach (int rx in rails)
            {
                R(g, rx, 0, 1, 20, cSteelL);
                R(g, rx + 1, 0, 1, 20, cSteelD);
            }
        }
        return bmp;
    }

    private Bitmap MakeRope()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            Begin(0, 0, PX, false);
            for (int px = 0; px < 20; px++)
            {
                bool even = (px / 2) % 2 == 0;
                R(g, px, 2, 1, 1, cInk);
                R(g, px, 3, 1, 1, even ? cWood : cWoodD);
                R(g, px, 4, 1, 1, even ? cWoodD : cWood);
                R(g, px, 5, 1, 1, cInk);
            }
        }
        return bmp;
    }

    private Bitmap MakeGold()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            Begin(0, 0, PX, false);
            R(g, 4, 17, 12, 1, cMortar);
            R(g, 3, 12, 14, 5, cInk);
            R(g, 4, 13, 12, 3, cGold);
            R(g, 4, 13, 12, 1, cGoldL);
            R(g, 4, 15, 12, 1, cGoldD);
            R(g, 5, 9, 10, 3, cInk);
            R(g, 6, 10, 8, 2, cGoldL);
            R(g, 6, 10, 3, 1, cWhite);
            R(g, 9, 14, 2, 1, cGoldL);
        }
        return bmp;
    }

    private Bitmap MakeExit(int variant)
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            Begin(0, 0, PX, false);
            for (int py = 1; py < 20; py++)
            {
                int left = py == 1 ? 6 : (py == 2 ? 5 : 4);
                int width = 20 - 2 * left;
                R(g, left, py, width, 1, cInk);
                if (py >= 2 && width > 2)
                {
                    Color c;
                    if (variant == 0) c = ((left + 1) % 1 == 0 && py % 3 == 0) ? cSteelD : cSteel;
                    else c = variant == 1 ? cYellow : cWhite;
                    R(g, left + 1, py, width - 2, 1, c);
                }
            }
            if (variant == 0)
            {
                R(g, 8, 7, 1, 3, cSteelL);
                R(g, 11, 7, 1, 3, cSteelL);
                R(g, 8, 7, 4, 1, cSteelL);
                R(g, 8, 10, 4, 4, cGold);
                R(g, 8, 10, 4, 1, cGoldL);
                R(g, 9, 12, 2, 1, cInk);
            }
            else
            {
                R(g, 9, 5, 2, 1, cInk);
                R(g, 8, 6, 4, 1, cInk);
                R(g, 7, 7, 6, 1, cInk);
                R(g, 9, 8, 2, 7, cInk);
                R(g, 7, 17, 6, 1, cGoldD);
            }
        }
        return bmp;
    }
}
