using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace LodeRunner;

public enum HeroPose { Idle, Walk, Climb, Fall, Rope, Dig, Hurt, Victory }

public enum FoePose { Idle, Walk, Climb, Trapped }

/// <summary>
/// 16-bit style renderer (Mega Drive / Genesis flavour): 3-tone shading on every part, bevelled tiles,
/// banded gradients and glow in the background, coloured outlines. Sprites are authored on a 20x20 grid
/// with an extra half-pixel (1 screen pixel) layer for highlights and shadows. No smoothing is used.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    private const int T = Cfg.T;
    private const int PX = 2;

    // ---- colour sets: {highlight, mid, shadow}
    private static readonly Color cInk = Color.FromArgb(14, 12, 40);
    private static readonly Color cWhite = Color.FromArgb(255, 255, 255);
    private static readonly Color cYellow = Color.FromArgb(255, 226, 70);
    private static readonly Color cOrange = Color.FromArgb(252, 140, 24);
    private static readonly Color cGreen = Color.FromArgb(110, 255, 150);
    private static readonly Color cRed = Color.FromArgb(226, 44, 52);
    private static readonly Color cGoldHi = Color.FromArgb(255, 238, 130);
    private static readonly Color cBlush = Color.FromArgb(255, 150, 136);
    private static readonly Color cPit = Color.FromArgb(10, 6, 22);

    private static readonly Color[] SetCap = { Color.FromArgb(120, 168, 255), Color.FromArgb(40, 92, 232), Color.FromArgb(18, 40, 140) };
    private static readonly Color[] SetCapDark = { Color.FromArgb(60, 110, 240), Color.FromArgb(24, 56, 170), Color.FromArgb(12, 24, 100) };
    private static readonly Color[] SetShirt = { Color.FromArgb(255, 255, 255), Color.FromArgb(218, 224, 248), Color.FromArgb(150, 160, 204) };
    private static readonly Color[] SetPants = { Color.FromArgb(226, 234, 255), Color.FromArgb(180, 194, 240), Color.FromArgb(120, 136, 204) };
    private static readonly Color[] SetSkin = { Color.FromArgb(255, 226, 190), Color.FromArgb(252, 188, 140), Color.FromArgb(200, 126, 86) };
    private static readonly Color[] SetHair = { Color.FromArgb(176, 106, 54), Color.FromArgb(120, 64, 24), Color.FromArgb(66, 32, 10) };
    private static readonly Color[] SetScarf = { Color.FromArgb(255, 110, 100), Color.FromArgb(226, 44, 52), Color.FromArgb(140, 14, 34) };
    private static readonly Color[] SetShoe = { Color.FromArgb(84, 112, 230), Color.FromArgb(34, 58, 172), Color.FromArgb(16, 28, 100) };
    private static readonly Color[] SetBelt = { Color.FromArgb(214, 144, 64), Color.FromArgb(150, 92, 32), Color.FromArgb(90, 50, 16) };
    private static readonly Color[] SetFoe = { Color.FromArgb(255, 104, 94), Color.FromArgb(214, 38, 48), Color.FromArgb(130, 14, 34) };
    private static readonly Color[] SetFoeDark = { Color.FromArgb(222, 56, 64), Color.FromArgb(150, 18, 38), Color.FromArgb(86, 8, 26) };
    private static readonly Color[] SetBelly = { Color.FromArgb(255, 190, 170), Color.FromArgb(255, 120, 108), Color.FromArgb(214, 60, 66) };
    private static readonly Color[] SetEye = { Color.FromArgb(255, 255, 255), Color.FromArgb(240, 244, 255), Color.FromArgb(180, 190, 232) };
    private static readonly Color[] SetSteel = { Color.FromArgb(240, 248, 255), Color.FromArgb(176, 192, 224), Color.FromArgb(96, 110, 156) };
    private static readonly Color[] SetWood = { Color.FromArgb(222, 164, 90), Color.FromArgb(166, 108, 50), Color.FromArgb(96, 56, 20) };
    private static readonly Color[] SetFlash = { Color.FromArgb(255, 200, 190), Color.FromArgb(255, 110, 100), Color.FromArgb(200, 40, 50) };

    private readonly Bitmap board = new Bitmap(Cfg.LogicalW, Cfg.BoardH, PixelFormat.Format32bppPArgb);
    private readonly ImageAttributes boardAttrs = new ImageAttributes();
    private readonly SolidBrush pBrush = new SolidBrush(Color.Black);
    private readonly Bitmap bgCave;
    private readonly Bitmap tileBrick;
    private readonly Bitmap tileSolid;
    private readonly Bitmap tileLadder;
    private readonly Bitmap tileRope;
    private readonly Bitmap tileGold;
    private readonly Bitmap tileExitLocked;
    private readonly Bitmap tileExitOpenA;
    private readonly Bitmap tileExitOpenB;
    private readonly Bitmap titleBmp;

    private readonly Font fHud;
    private readonly Font fHudLabel;
    private readonly Font fBig;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fFooter;
    private readonly Font fFloat;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;

    private int pOx;
    private int pOy;
    private int pU = 1;
    private bool pFlip;

    // heart: 1 = mid, 2 = highlight, 3 = shadow
    private static readonly string[] HeartGrid =
    {
        ".11.11.",
        "1211111",
        "1111113",
        ".11113.",
        "..113..",
        "...3..."
    };

    // flame: 1 = outer, 2 = middle, 3 = core
    private static readonly string[] FlameA =
    {
        "...1...",
        "..111..",
        ".11211.",
        ".12221.",
        "1123211",
        "1123211",
        ".11211.",
        "..111.."
    };

    private static readonly string[] FlameB =
    {
        "....1..",
        "..1111.",
        ".11211.",
        "112221.",
        "1123211",
        "1123211",
        ".11211.",
        "..111.."
    };

    public GameRenderer()
    {
        boardAttrs.SetWrapMode(WrapMode.TileFlipXY);

        fHud = new Font("Consolas", 20f, FontStyle.Bold, GraphicsUnit.Pixel);
        fHudLabel = new Font("Consolas", 12f, FontStyle.Bold, GraphicsUnit.Pixel);
        fBig = new Font("Consolas", 40f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Consolas", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Consolas", 18f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Consolas", 15f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fFloat = new Font("Consolas", 16f, FontStyle.Bold, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;

        bgCave = MakeCave();
        tileBrick = MakeBrick();
        tileSolid = MakeSolid();
        tileLadder = MakeLadder();
        tileRope = MakeRope();
        tileGold = MakeGold();
        tileExitLocked = MakeExit(0);
        tileExitOpenA = MakeExit(1);
        tileExitOpenB = MakeExit(2);
        titleBmp = MakeTitle();
    }

    public void Dispose()
    {
        board.Dispose();
        boardAttrs.Dispose();
        pBrush.Dispose();
        bgCave.Dispose();
        tileBrick.Dispose();
        tileSolid.Dispose();
        tileLadder.Dispose();
        tileRope.Dispose();
        tileGold.Dispose();
        tileExitLocked.Dispose();
        tileExitOpenA.Dispose();
        tileExitOpenB.Dispose();
        titleBmp.Dispose();
        fHud.Dispose();
        fHudLabel.Dispose();
        fBig.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fFooter.Dispose();
        fFloat.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
    }

    // ------------------------------------------------------------------ painter

    private void Begin(int x, int y, int u, bool flip)
    {
        pOx = x;
        pOy = y;
        pU = u;
        pFlip = flip;
    }

    /// <summary>Rectangle on the 20x20 sprite grid.</summary>
    private void R(Graphics g, int px, int py, int pw, int ph, Color c)
    {
        int x = pFlip ? 20 - px - pw : px;
        pBrush.Color = c;
        g.FillRectangle(pBrush, pOx + x * pU, pOy + py * pU, pw * pU, ph * pU);
    }

    /// <summary>Rectangle on the finer 40x40 half-pixel grid (used for highlights and shadows).</summary>
    private void H(Graphics g, int hx, int hy, int hw, int hh, Color c)
    {
        int hu = Math.Max(1, pU / 2);
        int x = pFlip ? 40 - hx - hw : hx;
        pBrush.Color = c;
        g.FillRectangle(pBrush, pOx + x * hu, pOy + hy * hu, hw * hu, hh * hu);
    }

    /// <summary>Shaded rectangle: mid colour plus a light top/left edge and a dark bottom/right edge.</summary>
    private void RS(Graphics g, int px, int py, int pw, int ph, Color[] s)
    {
        R(g, px, py, pw, ph, s[1]);
        int x0 = px * 2;
        int y0 = py * 2;
        int w2 = pw * 2;
        int h2 = ph * 2;
        Color left = pFlip ? s[2] : s[0];
        Color right = pFlip ? s[0] : s[2];
        H(g, x0, y0, 1, h2, left);
        H(g, x0 + w2 - 1, y0, 1, h2, right);
        H(g, x0, y0, w2, 1, s[0]);
        H(g, x0, y0 + h2 - 1, w2, 1, s[2]);
    }

    /// <summary>Shaded rectangle with a dark outline.</summary>
    private void ROS(Graphics g, int px, int py, int pw, int ph, Color[] s)
    {
        R(g, px - 1, py - 1, pw + 2, ph + 2, cInk);
        RS(g, px, py, pw, ph, s);
    }

    private void Rect(Graphics g, int x, int y, int w, int h, Color c)
    {
        pBrush.Color = c;
        g.FillRectangle(pBrush, x, y, w, h);
    }

    private void Grid(Graphics g, string[] rows, int x, int y, int u, Color a, Color b, Color c)
    {
        for (int r = 0; r < rows.Length; r++)
        {
            string row = rows[r];
            for (int col = 0; col < row.Length; col++)
            {
                char ch = row[col];
                if (ch == '.') continue;
                pBrush.Color = ch == '1' ? a : (ch == '2' ? b : c);
                g.FillRectangle(pBrush, x + col * u, y + r * u, u, u);
            }
        }
    }

    private static Color Lerp(Color a, Color b, float t)
    {
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        return Color.FromArgb(
            (int)(a.R + (b.R - a.R) * t),
            (int)(a.G + (b.G - a.G) * t),
            (int)(a.B + (b.B - a.B) * t));
    }

    private static int Hash(int a, int b)
    {
        unchecked
        {
            int h = a * 374761393 + b * 668265263;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameWorld w, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)Cfg.LogicalW, clientH / (float)Cfg.LogicalH);
        float offX = (clientW - Cfg.LogicalW * scale) / 2f;
        float offY = (clientH - Cfg.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, Cfg.LogicalW, Cfg.LogicalH));
            g.SmoothingMode = SmoothingMode.None;
            g.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (w.Mode == GameMode.Title)
            {
                DrawTitle(g, w);
            }
            else
            {
                DrawGameScreen(g, w);
                switch (w.Mode)
                {
                    case GameMode.Paused:
                        DrawPanel(g, w, "PAUSED", cYellow,
                            new[] { "The game is paused." },
                            "ESC - RESUME    R - RESTART LEVEL");
                        break;
                    case GameMode.LevelComplete:
                        DrawPanel(g, w, "LEVEL COMPLETE", cGreen,
                            new[]
                            {
                                "Gold collected: " + w.GoldCollected + " / " + w.Level.GoldTotal,
                                "Level bonus: +" + GameWorld.LevelBonus,
                                "Score: " + w.Score
                            },
                            "ENTER - NEXT LEVEL");
                        break;
                    case GameMode.GameOver:
                        DrawPanel(g, w, "GAME OVER", cRed,
                            new[] { "FINAL SCORE", w.Score.ToString("D6") },
                            "ENTER - RESTART");
                        break;
                    case GameMode.Victory:
                        DrawPanel(g, w, "ALL LEVELS COMPLETE", cYellow,
                            new[] { "You emptied every vault!", "FINAL SCORE", w.Score.ToString("D6") },
                            "ENTER - PLAY AGAIN");
                        break;
                }
            }

            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ text and panels

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow)
        {
            using (SolidBrush sb = new SolidBrush(cInk))
            {
                g.DrawString(s, f, sb, x + 2f, y + 2f, sf);
                g.DrawString(s, f, sb, x + 1f, y + 2f, sf);
                g.DrawString(s, f, sb, x + 2f, y + 1f, sf);
            }
        }
        using (SolidBrush b = new SolidBrush(c))
        {
            g.DrawString(s, f, b, x, y, sf);
        }
    }

    /// <summary>Banded vertical gradient filling a rectangle.</summary>
    private void Bands(Graphics g, int x, int y, int w, int h, Color top, Color bottom, int bandH)
    {
        for (int by = 0; by < h; by += bandH)
        {
            float t = h <= 1 ? 0f : by / (float)(h - 1);
            int bh = Math.Min(bandH, h - by);
            Rect(g, x, y + by, w, bh, Lerp(top, bottom, t));
        }
    }

    private void DrawBox(Graphics g, Rectangle r)
    {
        Rect(g, r.X, r.Y, r.Width, r.Height, cInk);
        Bands(g, r.X + 2, r.Y + 2, r.Width - 4, r.Height - 4, Color.FromArgb(214, 224, 255), Color.FromArgb(74, 90, 160), 4);
        Bands(g, r.X + 6, r.Y + 6, r.Width - 12, r.Height - 12, Color.FromArgb(40, 54, 132), Color.FromArgb(8, 10, 50), 4);
        Rect(g, r.X + 6, r.Y + 6, r.Width - 12, 1, Color.FromArgb(120, 150, 255));
        Rect(g, r.X + 6, r.Y + 6, 1, r.Height - 12, Color.FromArgb(120, 150, 255));
        Rect(g, r.X + 2, r.Y + 2, r.Width - 4, 1, cWhite);
        Rect(g, r.X + 2, r.Y + r.Height - 3, r.Width - 4, 1, Color.FromArgb(40, 48, 100));
    }

    // ------------------------------------------------------------------ game screen

    private void DrawGameScreen(Graphics g, GameWorld w)
    {
        using (Graphics bg = Graphics.FromImage(board))
        {
            bg.SmoothingMode = SmoothingMode.None;
            bg.PixelOffsetMode = PixelOffsetMode.Half;
            bg.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
            DrawBoard(bg, w);
        }

        g.DrawImage(board, new Rectangle(0, Cfg.HudH, Cfg.LogicalW, Cfg.BoardH),
            0, 0, Cfg.LogicalW, Cfg.BoardH, GraphicsUnit.Pixel, boardAttrs);

        DrawHud(g, w);

        if (w.HurtFlash > 0 && (w.HurtFlash / 3) % 2 == 0)
        {
            using (SolidBrush red = new SolidBrush(Color.FromArgb(90, 255, 24, 24)))
            {
                g.FillRectangle(red, 0, Cfg.HudH, Cfg.LogicalW, Cfg.BoardH);
            }
        }

        if (w.Mode == GameMode.Playing || w.Mode == GameMode.Paused)
        {
            if (w.BannerTimer > 0)
            {
                Txt(g, "LEVEL " + (w.LevelIndex + 1), fBig, cYellow, Cfg.LogicalW / 2f, Cfg.HudH + 150f, sfCenter, true);
                Txt(g, w.Level.Name.ToUpperInvariant(), fMid, cWhite, Cfg.LogicalW / 2f, Cfg.HudH + 200f, sfCenter, true);
            }
            else if (w.ExitBannerTimer > 0 && (w.ExitBannerTimer / 8) % 2 == 0)
            {
                Txt(g, "EXIT OPEN - REACH THE DOOR!", fMid, cGreen, Cfg.LogicalW / 2f, Cfg.HudH + 60f, sfCenter, true);
            }
        }
    }

    private void DrawInset(Graphics g, int x, int y, int w, int h)
    {
        Rect(g, x, y, w, h, cInk);
        Bands(g, x + 1, y + 1, w - 2, h - 2, Color.FromArgb(8, 10, 40), Color.FromArgb(26, 32, 84), 3);
        Rect(g, x, y + h - 1, w, 1, Color.FromArgb(120, 140, 220));
    }

    private void DrawHud(Graphics g, GameWorld w)
    {
        Bands(g, 0, 0, Cfg.LogicalW, Cfg.HudH - 4, Color.FromArgb(72, 84, 168), Color.FromArgb(18, 22, 70), 4);
        Rect(g, 0, 0, Cfg.LogicalW, 1, Color.FromArgb(190, 204, 255));
        Rect(g, 0, Cfg.HudH - 4, Cfg.LogicalW, 4, Color.FromArgb(214, 160, 40));
        Rect(g, 0, Cfg.HudH - 4, Cfg.LogicalW, 1, cGoldHi);
        Rect(g, 0, Cfg.HudH - 1, Cfg.LogicalW, 1, Color.FromArgb(120, 70, 10));

        DrawInset(g, 12, 6, 188, 34);
        DrawInset(g, 218, 6, 226, 34);
        DrawInset(g, 458, 6, 188, 34);
        DrawInset(g, 660, 6, 128, 34);

        HudItem(g, "SCORE", w.Score.ToString("D6"), 22f);
        HudItem(g, "GOLD REMAINING", w.Level.GoldLeft + " / " + w.Level.GoldTotal, 228f);
        Txt(g, "LIVES", fHudLabel, Color.FromArgb(160, 180, 255), 468f, 14f, sfLeft, false);
        int lives = Math.Max(0, Math.Min(6, w.Lives));
        for (int i = 0; i < lives; i++)
        {
            int hx = 468 + i * 28;
            Grid(g, HeartGrid, hx + 3, 21, 3, cInk, cInk, cInk);
            Grid(g, HeartGrid, hx, 18, 3, Color.FromArgb(240, 52, 66), Color.FromArgb(255, 180, 170), Color.FromArgb(150, 10, 40));
        }
        HudItem(g, "LEVEL", (w.LevelIndex + 1) + " / " + w.LevelCount, 670f);
    }

    private void HudItem(Graphics g, string label, string value, float x)
    {
        Txt(g, label, fHudLabel, Color.FromArgb(160, 180, 255), x, 14f, sfLeft, false);
        Txt(g, value, fHud, cYellow, x, 30f, sfLeft, true);
    }

    private void DrawBoard(Graphics g, GameWorld w)
    {
        GameLevel lv = w.Level;
        bool exitOpen = w.ExitUnlocked;
        g.DrawImage(bgCave, new Rectangle(0, 0, Cfg.LogicalW, Cfg.BoardH), 0, Cfg.HudH, Cfg.LogicalW, Cfg.BoardH, GraphicsUnit.Pixel);

        for (int r = 0; r < Cfg.Rows; r++)
        {
            for (int c = 0; c < Cfg.Cols; c++)
            {
                int x = c * T;
                int y = r * T;
                switch (lv.Cells[c, r])
                {
                    case Tile.Brick: g.DrawImageUnscaled(tileBrick, x, y); break;
                    case Tile.Solid: g.DrawImageUnscaled(tileSolid, x, y); break;
                    case Tile.Ladder: g.DrawImageUnscaled(tileLadder, x, y); break;
                    case Tile.Rope: g.DrawImageUnscaled(tileRope, x, y); break;
                    case Tile.Exit:
                        if (!exitOpen) g.DrawImageUnscaled(tileExitLocked, x, y);
                        else g.DrawImageUnscaled(((w.Frame / 10) % 2 == 0) ? tileExitOpenA : tileExitOpenB, x, y);
                        break;
                    case Tile.Gold:
                        g.DrawImageUnscaled(tileGold, x, y);
                        DrawSparkle(g, x, y, c, r, w.Frame);
                        break;
                }
            }
        }

        foreach (Hole h in w.Holes)
        {
            DrawHole(g, h, w.Frame);
        }

        foreach (Enemy e in w.Enemies)
        {
            if (e.State == EnemyState.Respawning) continue;
            if (e.Grace > 0 && (w.Frame / 3) % 2 == 0) continue;
            FoePose pose = FoePose.Idle;
            if (e.State == EnemyState.Trapped) pose = FoePose.Trapped;
            else if (e.Climbing) pose = FoePose.Climb;
            else if (e.Moving) pose = FoePose.Walk;
            DrawFoe(g, e.X, e.Y, PX, e.Facing, pose, e.AnimTick, w.Frame);
        }

        Player p = w.Player;
        bool blink = p.Invuln > 0 && (w.Frame / 4) % 2 == 0;
        if (!blink)
        {
            HeroPose pose = HeroPose.Idle;
            int tick = p.AnimTick;
            if (p.State == PlayerState.Hurt) pose = HeroPose.Hurt;
            else if (p.State == PlayerState.Victory) pose = HeroPose.Victory;
            else if (p.State == PlayerState.Digging)
            {
                pose = HeroPose.Dig;
                tick = Math.Min(2, (GameWorld.DigFrames - p.StateTimer) * 3 / GameWorld.DigFrames);
            }
            else if (p.Escaping || p.Climbing) pose = HeroPose.Climb;
            else if (p.Falling) pose = HeroPose.Fall;
            else if (lv.Get(p.Col, p.Row) == Tile.Rope && p.Oy == 0)
            {
                pose = HeroPose.Rope;
                if (!p.Moving) tick = 0;
            }
            else if (p.Moving) pose = HeroPose.Walk;
            DrawHero(g, p.X, p.Y, PX, p.Facing, pose, tick, w.Frame);
        }

        foreach (Particle pt in w.Particles)
        {
            int sz = pt.Life * 3 < pt.MaxLife ? 2 : Math.Max(2, ((int)pt.Size / 2) * 2);
            int px = ((int)pt.X / 2) * 2;
            int py = ((int)pt.Y / 2) * 2;
            Rect(g, px, py, sz, sz, pt.Color);
            Rect(g, px, py, 1, 1, Lerp(pt.Color, cWhite, 0.7f));
        }

        foreach (FloatText t in w.Texts)
        {
            if (t.Life < 12 && (t.Life / 2) % 2 == 0) continue;
            Txt(g, t.Text, fFloat, t.Color, t.X, t.Y, sfLeft, true);
        }
    }

    private void DrawHole(Graphics g, Hole h, int frame)
    {
        int x = h.C * T;
        int y = h.R * T;
        int ph = h.Age < 10 ? (h.Age * T / 10) / 2 * 2 : T;

        if (ph < T)
        {
            g.DrawImage(tileBrick, new Rectangle(x, y + ph, T, T - ph), 0, ph, T, T - ph, GraphicsUnit.Pixel);
        }
        if (ph > 0)
        {
            Bands(g, x, y, T, ph, Color.FromArgb(36, 22, 56), cPit, 4);
            g.DrawImage(tileBrick, new Rectangle(x, y, 6, ph), 0, 0, 6, ph, GraphicsUnit.Pixel);
            g.DrawImage(tileBrick, new Rectangle(x + T - 6, y, 6, ph), T - 6, 0, 6, ph, GraphicsUnit.Pixel);
            Rect(g, x + 6, y, 2, ph, Color.FromArgb(120, 0, 0, 0));
            Rect(g, x + T - 8, y, 2, ph, Color.FromArgb(90, 0, 0, 0));
        }

        int warnStart = GameWorld.OpenFrames - GameWorld.WarnFrames;
        if (h.Age >= warnStart)
        {
            float prog = Math.Min(1f, (h.Age - warnStart) / (float)GameWorld.WarnFrames);
            int fill = ((int)(prog * T)) / 2 * 2;
            if (fill > 0)
            {
                g.DrawImage(tileBrick, new Rectangle(x, y + T - fill, T, fill), 0, T - fill, T, fill, GraphicsUnit.Pixel);
            }
            if ((frame / 4) % 2 == 0)
            {
                Color warn = Color.FromArgb(255, 70, 50);
                Rect(g, x, y, T, 2, warn);
                Rect(g, x, y + T - 2, T, 2, warn);
                Rect(g, x, y, 2, T, warn);
                Rect(g, x + T - 2, y, 2, T, warn);
            }
        }
    }

    private void DrawSparkle(Graphics g, int x, int y, int c, int r, int frame)
    {
        int t = (frame + c * 11 + r * 7) % 90;
        if (t >= 16) return;
        Begin(x, y, PX, false);
        int s = t < 8 ? t / 2 : (16 - t) / 2; // grows and shrinks
        H(g, 27 - s, 12, s * 2 + 1, 1, cWhite);
        H(g, 27, 12 - s, 1, s * 2 + 1, cWhite);
        H(g, 27, 12, 1, 1, cGoldHi);
    }

    // ------------------------------------------------------------------ sprites

    private void Arm(Graphics g, int x, int top, int h, bool handAtTop, Color[] sleeve)
    {
        RS(g, x, top, 2, h, sleeve);
        RS(g, x, handAtTop ? top : top + h - 1, 2, 1, SetSkin);
    }

    private void Plus(Graphics g, int cx, int cy, Color c)
    {
        R(g, cx - 1, cy, 3, 1, c);
        R(g, cx, cy - 1, 1, 3, c);
        H(g, cx * 2, cy * 2, 1, 1, cWhite);
    }

    private void DrawHero(Graphics g, int x, int y, int u, int facing, HeroPose pose, int tick, int frame)
    {
        bool front = pose == HeroPose.Climb;
        int jump = pose == HeroPose.Victory ? ((tick / 5) % 2) * 2 : 0;
        Begin(x, y - jump * u, u, !front && facing < 0);

        bool flash = pose == HeroPose.Hurt && (frame / 3) % 2 == 0;
        Color[] shirt = flash ? SetFlash : SetShirt;
        Color[] pants = flash ? SetFoe : SetPants;
        Color[] cap = flash ? SetFoeDark : SetCap;

        int k = (tick / 5) % 4;
        int legA = 0, legB = 0, liftA = 0, liftB = 0, by = 0;
        switch (pose)
        {
            case HeroPose.Idle: by = (tick / 20) % 2; break;
            case HeroPose.Walk:
                legA = k == 0 ? 1 : (k == 2 ? -1 : 0);
                legB = -legA;
                liftA = k == 1 ? 1 : 0;
                liftB = k == 3 ? 1 : 0;
                by = (k == 1 || k == 3) ? 1 : 0;
                break;
            case HeroPose.Climb:
                liftA = k < 2 ? 1 : 0;
                liftB = k < 2 ? 0 : 1;
                break;
            case HeroPose.Fall: legA = -2; legB = 2; break;
            case HeroPose.Rope:
                liftA = (tick / 8) % 2;
                liftB = 1 - liftA;
                break;
            case HeroPose.Dig: by = 2; break;
            case HeroPose.Hurt:
                legA = -1;
                legB = 1;
                by = (tick / 3) % 2;
                break;
        }

        // soft ground shadow
        if (pose != HeroPose.Fall && pose != HeroPose.Rope && pose != HeroPose.Climb && pose != HeroPose.Victory)
        {
            H(g, 10, 38, 20, 2, Color.FromArgb(70, 0, 0, 20));
        }

        // scarf tail
        if (!front) RS(g, 2, 9 + by + (tick / 6) % 2, 4, 1, SetScarf);

        // back arm
        switch (pose)
        {
            case HeroPose.Climb: Arm(g, 4, k < 2 ? 4 : 9, 5, k < 2, cap); break;
            case HeroPose.Fall: Arm(g, 3, 3 + by, 6, true, cap); break;
            case HeroPose.Rope: Arm(g, 4, 2, 9, true, cap); break;
            case HeroPose.Victory: Arm(g, 3, 2, 6, true, cap); break;
            case HeroPose.Hurt: Arm(g, 3, (tick / 4) % 2 == 0 ? 3 : 8, 6, true, cap); break;
            case HeroPose.Walk: Arm(g, 4 + legB, 10 + by, 4, false, cap); break;
            default: Arm(g, 4, 10 + by, 4, false, cap); break;
        }

        // legs and shoes
        int topLeg = 15 + by;
        int bottomA = 19 - liftA;
        int bottomB = 19 - liftB;
        RS(g, 6 + legA, topLeg, 3, bottomA - 1 - topLeg, pants);
        RS(g, 6 + legA, bottomA - 1, 4, 1, SetShoe);
        RS(g, 11 + legB, topLeg, 3, bottomB - 1 - topLeg, pants);
        RS(g, 11 + legB, bottomB - 1, 4, 1, SetShoe);

        // torso, stripe, belt and buckle
        ROS(g, 6, 10 + by, 8, 5, shirt);
        RS(g, 6, 12 + by, 8, 1, cap);
        RS(g, 6, 14 + by, 8, 1, SetBelt);
        H(g, 18, (14 + by) * 2, 4, 2, cGoldHi);
        H(g, 14, (11 + by) * 2, 2, 1, Color.FromArgb(255, 255, 255));

        // head
        if (front)
        {
            ROS(g, 6, 3 + by, 8, 6, SetHair);
            RS(g, 6, 2 + by, 8, 4, cap);
            RS(g, 7, 1 + by, 6, 1, cap);
            H(g, 14, (2 + by) * 2, 4, 1, Color.FromArgb(190, 220, 255));
        }
        else
        {
            RS(g, 5, 4 + by, 2, 4, SetHair);
            ROS(g, 6, 3 + by, 8, 6, SetSkin);
            RS(g, 6, 2 + by, 8, 2, cap);
            RS(g, 7, 1 + by, 6, 1, cap);
            RS(g, 12, 4 + by, 4, 1, SetCapDark);
            R(g, 9, 2 + by, 2, 1, cWhite);
            H(g, 14, (1 + by) * 2, 4, 1, Color.FromArgb(190, 220, 255));
            if (pose == HeroPose.Hurt)
            {
                R(g, 10, 5 + by, 1, 1, cInk);
                R(g, 12, 5 + by, 1, 1, cInk);
                R(g, 11, 6 + by, 1, 1, cInk);
                R(g, 10, 7 + by, 1, 1, cInk);
                R(g, 12, 7 + by, 1, 1, cInk);
            }
            else
            {
                R(g, 11, 5 + by, 1, 2, cInk);
                H(g, 22, (5 + by) * 2, 1, 1, cWhite);
                H(g, 24, (7 + by) * 2 + 1, 3, 2, cBlush);
            }
            if (pose == HeroPose.Victory) R(g, 10, 7 + by, 4, 1, cInk);
            else if (pose != HeroPose.Hurt) R(g, 12, 7 + by, 2, 1, Color.FromArgb(150, 40, 40));
        }
        RS(g, 6, 9 + by, 8, 1, SetScarf);

        // front arm
        switch (pose)
        {
            case HeroPose.Climb: Arm(g, 14, k < 2 ? 9 : 4, 5, k >= 2, cap); break;
            case HeroPose.Fall: Arm(g, 15, 3 + by, 6, true, cap); break;
            case HeroPose.Rope: Arm(g, 14, 2, 9, true, cap); break;
            case HeroPose.Victory: Arm(g, 15, 2, 6, true, cap); break;
            case HeroPose.Hurt: Arm(g, 15, (tick / 4) % 2 == 0 ? 8 : 3, 6, true, cap); break;
            case HeroPose.Walk: Arm(g, 14 + legA, 10 + by, 4, false, cap); break;
            default: Arm(g, 14, 10 + by, 4, false, cap); break;
        }

        // pickaxe (tick holds the swing stage 0..2)
        if (pose == HeroPose.Dig)
        {
            if (tick <= 0)
            {
                RS(g, 15, 7 + by, 1, 6, SetWood);
                RS(g, 14, 6 + by, 3, 1, SetSteel);
            }
            else if (tick == 1)
            {
                RS(g, 15, 12 + by, 5, 1, SetWood);
                RS(g, 19, 11 + by, 1, 3, SetSteel);
            }
            else
            {
                RS(g, 16, 13 + by, 1, 4, SetWood);
                RS(g, 15, 17 + by, 3, 1, SetSteel);
            }
        }

        if (pose == HeroPose.Hurt)
        {
            for (int i = 0; i < 3; i++)
            {
                float a = tick * 0.3f + i * 2.09f;
                Plus(g, 10 + (int)(MathF.Cos(a) * 7f), (int)(MathF.Sin(a) * 2f), cYellow);
            }
        }
        else if (pose == HeroPose.Victory)
        {
            for (int i = 0; i < 3; i++)
            {
                float a = tick * 0.2f + i * 2.09f;
                Plus(g, 10 + (int)(MathF.Cos(a) * 9f), 8 + (int)(MathF.Sin(a) * 7f), cGoldHi);
            }
        }
    }

    private void DrawFoe(Graphics g, int x, int y, int u, int facing, FoePose pose, int tick, int frame)
    {
        bool front = pose == FoePose.Climb;
        Begin(x, y, u, !front && facing < 0);

        int k = (tick / 5) % 4;
        int legA = 0, legB = 0, liftA = 0, liftB = 0, by = 0;
        int armA = 0, armB = 0;
        switch (pose)
        {
            case FoePose.Walk:
                legA = k == 0 ? 1 : (k == 2 ? -1 : 0);
                legB = -legA;
                liftA = k == 1 ? 1 : 0;
                liftB = k == 3 ? 1 : 0;
                by = (k == 1 || k == 3) ? 1 : 0;
                armA = legA;
                armB = legB;
                break;
            case FoePose.Climb:
                liftA = k < 2 ? 1 : 0;
                liftB = k < 2 ? 0 : 1;
                armA = k < 2 ? -2 : 0;
                armB = k < 2 ? 0 : -2;
                break;
            case FoePose.Trapped:
                by = 2;
                armA = (tick / 4) % 2 == 0 ? -3 : 0;
                armB = (tick / 4) % 2 == 0 ? 0 : -3;
                break;
        }

        if (pose != FoePose.Climb && pose != FoePose.Trapped)
        {
            H(g, 10, 38, 20, 2, Color.FromArgb(70, 0, 0, 20));
        }

        int topLeg = 15 + by;
        int bottomA = 19 - liftA;
        int bottomB = 19 - liftB;
        RS(g, 6 + legA, topLeg, 3, bottomA - 1 - topLeg, SetFoeDark);
        RS(g, 5 + legA, bottomA - 1, 4, 1, SetShoe);
        RS(g, 11 + legB, topLeg, 3, bottomB - 1 - topLeg, SetFoeDark);
        RS(g, 11 + legB, bottomB - 1, 4, 1, SetShoe);

        RS(g, 2, 11 + by + armA, 2, 4, SetFoe);
        RS(g, 16, 11 + by + armB, 2, 4, SetFoe);

        ROS(g, 4, 5 + by, 12, 11, SetFoe);
        RS(g, 7, 12 + by, 6, 3, SetBelly);
        H(g, 10, (6 + by) * 2, 2, 4, Color.FromArgb(255, 170, 160));

        ROS(g, 5, 1 + by, 10, 4, SetFoeDark);
        RS(g, 3, 4 + by, 14, 1, SetFoeDark);
        RS(g, 7, 2 + by, 4, 1, SetFoe);
        H(g, 16, (2 + by) * 2, 3, 1, Color.FromArgb(255, 200, 190));

        if (pose == FoePose.Climb)
        {
            RS(g, 6, 6 + by, 3, 4, SetEye);
            RS(g, 11, 6 + by, 3, 4, SetEye);
            R(g, 7, 7 + by, 2, 2, cInk);
            R(g, 12, 7 + by, 2, 2, cInk);
            H(g, 14, (7 + by) * 2, 1, 1, cWhite);
            H(g, 24, (7 + by) * 2, 1, 1, cWhite);
        }
        else if (pose == FoePose.Trapped)
        {
            RS(g, 8, 6 + by, 5, 4, SetEye);
            R(g, 8, 6 + by, 1, 1, cInk);
            R(g, 12, 6 + by, 1, 1, cInk);
            R(g, 10, 7 + by, 1, 2, cInk);
            R(g, 8, 9 + by, 1, 1, cInk);
            R(g, 12, 9 + by, 1, 1, cInk);
        }
        else
        {
            RS(g, 9, 6 + by, 5, 4, SetEye);
            R(g, 12, 7 + by, 2, 2, cInk);
            H(g, 24, (7 + by) * 2, 1, 1, cWhite);
            R(g, 8, 5 + by, 6, 1, cInk);
        }

        if (pose == FoePose.Trapped)
        {
            for (int i = 0; i < 3; i++)
            {
                float a = tick * 0.3f + i * 2.09f;
                Plus(g, 10 + (int)(MathF.Cos(a) * 7f), (int)(MathF.Sin(a) * 2f), cYellow);
            }
        }
    }

    // ------------------------------------------------------------------ title screen

    private void DrawTitle(Graphics g, GameWorld w)
    {
        int f = w.Frame;
        int areaH = Cfg.HudH + Cfg.BoardH;
        g.DrawImage(bgCave, new Rectangle(0, 0, Cfg.LogicalW, areaH), 0, 0, Cfg.LogicalW, areaH, GraphicsUnit.Pixel);

        for (int c = 0; c < Cfg.Cols; c++)
        {
            g.DrawImageUnscaled(tileBrick, c * T, areaH - T);
        }
        for (int i = 0; i < 6; i++)
        {
            g.DrawImageUnscaled(tileGold, 310 + i * 24 + (i % 2) * 6, areaH - T - 22 - (i % 3) * 4);
        }
        for (int i = 0; i < 4; i++)
        {
            g.DrawImageUnscaled(tileGold, 340 + i * 26, areaH - T - 40 - (i % 2) * 4);
        }

        DrawTorch(g, 30, 240, f);
        DrawTorch(g, 750, 240, f);

        DrawHero(g, 40, areaH - T - 120, 6, 1, HeroPose.Walk, f, f);
        DrawFoe(g, 600, areaH - T - 80, 4, -1, FoePose.Walk, f, f);
        DrawFoe(g, 690, areaH - T - 80, 4, -1, FoePose.Walk, f + 10, f);

        g.DrawImage(titleBmp, new Rectangle(75, 14, 650, 120), 0, 0, titleBmp.Width, titleBmp.Height, GraphicsUnit.Pixel);

        Rectangle panel = new Rectangle(215, 150, 370, 232);
        DrawBox(g, panel);
        string[] lines =
        {
            "ARROWS / WASD  move and climb",
            "Z / J  dig left    X / K  dig right",
            "ESC  pause         R  restart level",
            "F11  fullscreen    M  mute",
            "Collect all gold, then reach EXIT.",
            "Trap guards in holes: +200 points.",
            "Holes refill after about 3 seconds!"
        };
        Txt(g, "HOW TO PLAY", fText, cYellow, panel.X + panel.Width / 2f, panel.Y + 26f, sfCenter, true);
        for (int i = 0; i < lines.Length; i++)
        {
            Txt(g, lines[i], fSmall, cWhite, panel.X + 18f, panel.Y + 58f + i * 24f, sfLeft, true);
        }

        Rectangle btn = new Rectangle(220, 405, 360, 46);
        DrawBox(g, btn);
        Color pc = ((f / 30) % 2 == 0) ? cWhite : cYellow;
        Txt(g, "PRESS ENTER TO START GAME", fText, pc, btn.X + btn.Width / 2f, btn.Y + btn.Height / 2f, sfCenter, true);
    }

    private void DrawTorch(Graphics g, int x, int y, int frame)
    {
        using (SolidBrush glow1 = new SolidBrush(Color.FromArgb(26, 255, 170, 40)))
        using (SolidBrush glow2 = new SolidBrush(Color.FromArgb(30, 255, 200, 80)))
        {
            g.FillEllipse(glow1, x - 60, y - 40, 120, 120);
            g.FillEllipse(glow2, x - 36, y - 16, 72, 72);
        }
        Rect(g, x - 2, y + 34, 8, 30, Color.FromArgb(104, 62, 22));
        Rect(g, x - 2, y + 34, 2, 30, Color.FromArgb(166, 108, 50));
        Rect(g, x - 6, y + 28, 16, 8, Color.FromArgb(166, 108, 50));
        Rect(g, x - 6, y + 28, 16, 2, Color.FromArgb(222, 164, 90));
        Rect(g, x - 6, y + 34, 16, 2, Color.FromArgb(96, 56, 20));
        Grid(g, ((frame / 8) % 2 == 0) ? FlameA : FlameB, x - 12, y, 6, cOrange, cYellow, cWhite);
    }

    private void DrawPanel(Graphics g, GameWorld w, string title, Color titleColor, string[] lines, string prompt)
    {
        using (SolidBrush dim = new SolidBrush(Color.FromArgb(160, 0, 0, 20)))
        {
            g.FillRectangle(dim, 0, 0, Cfg.LogicalW, Cfg.HudH + Cfg.BoardH);
        }
        Rectangle r = new Rectangle(130, 150, 540, 320);
        DrawBox(g, r);
        Txt(g, title, fBig, titleColor, r.X + r.Width / 2f, r.Y + 60f, sfCenter, true);
        for (int i = 0; i < lines.Length; i++)
        {
            Txt(g, lines[i], fMid, cWhite, r.X + r.Width / 2f, r.Y + 126f + i * 40f, sfCenter, true);
        }
        Color pc = ((w.Frame / 30) % 2 == 0) ? cWhite : cYellow;
        Txt(g, prompt, fText, pc, r.X + r.Width / 2f, r.Y + r.Height - 38f, sfCenter, true);
    }

    private void DrawFooter(Graphics g)
    {
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        Rectangle r = new Rectangle(0, Cfg.LogicalH - Cfg.FooterH, Cfg.LogicalW, Cfg.FooterH);
        Bands(g, r.X, r.Y, r.Width, r.Height, Color.FromArgb(26, 32, 84), Color.FromArgb(4, 4, 20), 4);
        Rect(g, 0, r.Y, Cfg.LogicalW, 1, Color.FromArgb(190, 204, 255));
        Rect(g, 0, r.Y + 1, Cfg.LogicalW, 2, Color.FromArgb(214, 160, 40));
        using (SolidBrush tb = new SolidBrush(cWhite))
        {
            g.DrawString(FooterText, fFooter, tb, new RectangleF(0f, r.Y + 3f, Cfg.LogicalW, r.Height - 3f), sfCenter);
        }
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private Bitmap MakeTitle()
    {
        int tw = 130;
        int th = 24;
        Bitmap bmp = new Bitmap(tw, th, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        using (Font f = new Font("Consolas", 18f, FontStyle.Bold, GraphicsUnit.Pixel))
        using (StringFormat sf = new StringFormat())
        using (SolidBrush ink = new SolidBrush(cInk))
        using (SolidBrush b1 = new SolidBrush(Color.FromArgb(255, 248, 170)))
        using (SolidBrush b2 = new SolidBrush(Color.FromArgb(255, 220, 60)))
        using (SolidBrush b3 = new SolidBrush(Color.FromArgb(250, 150, 24)))
        using (SolidBrush b4 = new SolidBrush(Color.FromArgb(190, 72, 12)))
        {
            g.SmoothingMode = SmoothingMode.None;
            g.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            sf.FormatFlags = StringFormatFlags.NoWrap;
            string text = "LODE RUNNER";
            for (int dx = -1; dx <= 1; dx++)
            {
                for (int dy = -1; dy <= 2; dy++)
                {
                    if (dx == 0 && dy == 0) continue;
                    g.DrawString(text, f, ink, new RectangleF(dx, dy, tw, th), sf);
                }
            }
            g.SetClip(new Rectangle(0, 0, tw, 8));
            g.DrawString(text, f, b1, new RectangleF(0, 0, tw, th), sf);
            g.SetClip(new Rectangle(0, 8, tw, 4));
            g.DrawString(text, f, b2, new RectangleF(0, 0, tw, th), sf);
            g.SetClip(new Rectangle(0, 12, tw, 4));
            g.DrawString(text, f, b3, new RectangleF(0, 0, tw, th), sf);
            g.SetClip(new Rectangle(0, 16, tw, th - 16));
            g.DrawString(text, f, b4, new RectangleF(0, 0, tw, th), sf);
            g.ResetClip();
        }
        return bmp;
    }

    private Bitmap MakeCave()
    {
        int W = Cfg.LogicalW;
        int H = Cfg.HudH + Cfg.BoardH;
        Bitmap bmp = new Bitmap(W, H, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.None;
            Bands(g, 0, 0, W, H, Color.FromArgb(10, 14, 52), Color.FromArgb(34, 20, 56), 8);

            Random rnd = new Random(7);

            // far columns
            for (int x = 40; x < W; x += 160)
            {
                int cw = 44;
                Bands(g, x, 0, cw, H, Color.FromArgb(20, 26, 84), Color.FromArgb(30, 22, 62), 8);
                Rect(g, x, 0, 3, H, Color.FromArgb(46, 58, 128));
                Rect(g, x + cw - 3, 0, 3, H, Color.FromArgb(8, 8, 30));
            }

            // brick wall texture
            for (int y = 0; y < H; y += 20)
            {
                int off = ((y / 20) % 2) * 20;
                for (int x = -off; x < W; x += 40)
                {
                    int shade = rnd.Next(3);
                    using (SolidBrush fill = new SolidBrush(Color.FromArgb(16 + shade * 6, 110, 130, 255)))
                    {
                        g.FillRectangle(fill, x + 1, y + 1, 38, 18);
                    }
                    Rect(g, x, y, 40, 1, Color.FromArgb(60, 150, 170, 255));
                    Rect(g, x, y, 1, 20, Color.FromArgb(44, 150, 170, 255));
                    Rect(g, x, y + 19, 40, 1, Color.FromArgb(120, 0, 0, 20));
                    Rect(g, x + 39, y, 1, 20, Color.FromArgb(100, 0, 0, 20));
                }
            }

            // cavern glow (banded)
            for (int i = 0; i < 6; i++)
            {
                int rx = 340 - i * 52;
                int ry = 230 - i * 36;
                using (SolidBrush glow = new SolidBrush(Color.FromArgb(14, 80, 130, 255)))
                {
                    g.FillEllipse(glow, W / 2 - rx, H / 2 + 10 - ry, rx * 2, ry * 2);
                }
            }

            // crystals
            for (int i = 0; i < 40; i++)
            {
                int sx = rnd.Next(W / 2) * 2;
                int sy = rnd.Next(H / 2) * 2;
                Rect(g, sx, sy, 2, 2, Color.FromArgb(90, 120, 220));
                Rect(g, sx, sy, 1, 1, Color.FromArgb(180, 200, 255));
            }

            // stalactites with a lit left edge
            for (int x = 0; x < W; x += 40)
            {
                int h = 20 + rnd.Next(5) * 8;
                for (int row = 0; row < h; row += 4)
                {
                    int w = (36 * (h - row) / h) / 2 * 2;
                    if (w < 2) w = 2;
                    int sx = x + (40 - w) / 2;
                    Rect(g, sx, row, w, 4, Color.FromArgb(8, 8, 28));
                    Rect(g, sx, row, 2, 4, Color.FromArgb(52, 64, 140));
                }
            }

            // vignette
            for (int i = 0; i < 5; i++)
            {
                using (SolidBrush v = new SolidBrush(Color.FromArgb(34, 0, 0, 14)))
                {
                    g.FillRectangle(v, 0, 0, 80 - i * 16, H);
                    g.FillRectangle(v, W - (80 - i * 16), 0, 80 - i * 16, H);
                }
            }
        }
        return bmp;
    }

    private Bitmap MakeBrick()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color[] ramp =
        {
            Color.FromArgb(44, 18, 14), Color.FromArgb(112, 48, 30), Color.FromArgb(160, 74, 38),
            Color.FromArgb(204, 106, 50), Color.FromArgb(238, 150, 86), Color.FromArgb(255, 200, 134)
        };
        for (int y = 0; y < T; y++)
        {
            for (int x = 0; x < T; x++)
            {
                int row = y / 10;
                int ry = y % 10;
                int xx = x + (row % 2) * 10;
                int bx = xx % 20;
                int brickId = (xx / 20) + row * 7;
                Color c;
                if (ry == 9 || bx == 19)
                {
                    c = ramp[0];
                }
                else
                {
                    int lvl;
                    if (ry == 0) lvl = 5;
                    else if (ry == 1) lvl = 4;
                    else if (ry <= 5) lvl = 3;
                    else if (ry <= 7) lvl = 2;
                    else lvl = 1;
                    if (bx == 0) lvl = Math.Min(5, lvl + 1);
                    else if (bx == 18) lvl = Math.Max(1, lvl - 1);
                    bool body = ry > 1 && ry < 8;
                    if (body) lvl = Math.Max(1, Math.Min(5, lvl + (Hash(brickId, 7) % 3) - 1));
                    int n = Hash(x, y) % 23;
                    if (body && n == 0) lvl = Math.Max(1, lvl - 1);
                    else if (body && n == 1) lvl = Math.Min(5, lvl + 1);
                    c = ramp[lvl];
                }
                bmp.SetPixel(x, y, c);
            }
        }
        return bmp;
    }

    private Bitmap MakeSolid()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color st0 = Color.FromArgb(26, 32, 56);
        Color st1 = Color.FromArgb(58, 68, 104);
        Color st2 = Color.FromArgb(96, 110, 152);
        Color st3 = Color.FromArgb(138, 154, 196);
        Color st4 = Color.FromArgb(190, 206, 238);
        Color st5 = Color.FromArgb(240, 248, 255);
        for (int y = 0; y < T; y++)
        {
            for (int x = 0; x < T; x++)
            {
                int d = Math.Min(Math.Min(x, y), Math.Min(T - 1 - x, T - 1 - y));
                bool topLeft;
                if (y == d) topLeft = true;
                else if (x == d) topLeft = true;
                else topLeft = false;
                Color c;
                if (d == 0) c = cInk;
                else if (d == 1) c = topLeft ? st5 : st0;
                else if (d == 2) c = topLeft ? st4 : st1;
                else if (d <= 5) c = Lerp(st3, st2, y / (float)T);
                else if (d == 6) c = topLeft ? st1 : st4;
                else
                {
                    c = Lerp(st2, st3, y / (float)T);
                    if (((x + y) % 2 == 0) && Hash(x / 2, y / 2) % 5 == 0) c = Lerp(c, st1, 0.35f);
                }
                bmp.SetPixel(x, y, c);
            }
        }
        // rivets
        int[] rc = { 8, 31 };
        foreach (int cx in rc)
        {
            foreach (int cy in rc)
            {
                for (int dy = -3; dy <= 3; dy++)
                {
                    for (int dx = -3; dx <= 3; dx++)
                    {
                        int dd = dx * dx + dy * dy;
                        if (dd > 10) continue;
                        Color c = st3;
                        if (dd > 7) c = st0;
                        else if (dx < 0 && dy < 0) c = st5;
                        else if (dx > 0 && dy > 0) c = st1;
                        bmp.SetPixel(cx + dx, cy + dy, c);
                    }
                }
            }
        }
        return bmp;
    }

    private Bitmap MakeLadder()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color[] rail = { Color.FromArgb(120, 136, 180), Color.FromArgb(240, 248, 255), Color.FromArgb(176, 192, 226), Color.FromArgb(62, 72, 112) };
        Color[] rung = { Color.FromArgb(240, 248, 255), Color.FromArgb(176, 192, 226), Color.FromArgb(110, 126, 170), Color.FromArgb(50, 58, 92) };
        int[] railX = { 8, 28 };
        foreach (int rx in railX)
        {
            for (int y = 0; y < T; y++)
            {
                bmp.SetPixel(rx - 1, y, cInk);
                bmp.SetPixel(rx + 4, y, cInk);
                for (int i = 0; i < 4; i++)
                {
                    bmp.SetPixel(rx + i, y, rail[i]);
                }
            }
        }
        int[] rungY = { 4, 14, 24, 34 };
        foreach (int ry in rungY)
        {
            for (int x = 12; x < 28; x++)
            {
                if (ry - 1 >= 0) bmp.SetPixel(x, ry - 1, cInk);
                if (ry + 4 < T) bmp.SetPixel(x, ry + 4, cInk);
                for (int i = 0; i < 4; i++)
                {
                    bmp.SetPixel(x, ry + i, rung[i]);
                }
            }
        }
        return bmp;
    }

    private Bitmap MakeRope()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color[] rope =
        {
            Color.FromArgb(70, 40, 16), Color.FromArgb(130, 84, 36), Color.FromArgb(192, 134, 66), Color.FromArgb(236, 188, 112)
        };
        for (int x = 0; x < T; x++)
        {
            bmp.SetPixel(x, 5, cInk);
            bmp.SetPixel(x, 11, cInk);
            for (int i = 0; i < 5; i++)
            {
                int y = 6 + i;
                int twist = ((x + i * 2) / 3) % 2;
                int idx = 3 - i;
                if (idx < 0) idx = 0;
                idx = twist == 0 ? idx : Math.Max(0, idx - 1);
                bmp.SetPixel(x, y, rope[Math.Min(3, idx)]);
            }
        }
        return bmp;
    }

    private Bitmap MakeGold()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color g0 = Color.FromArgb(120, 64, 0);
        Color g1 = Color.FromArgb(184, 110, 8);
        Color g2 = Color.FromArgb(236, 164, 18);
        Color g3 = Color.FromArgb(255, 208, 44);
        Color g4 = Color.FromArgb(255, 240, 130);

        Func<int, int, int> shape = (x, y) =>
        {
            if (y >= 24 && y <= 33 && x >= 7 && x <= 32) return 1;
            if (y >= 17 && y <= 23)
            {
                int left = 13 - (y - 17) * 4 / 6 + 0;
                left = 9 + (23 - y) * 4 / 6;
                int right = 30 - (23 - y) * 4 / 6;
                if (x >= left && x <= right) return 2;
            }
            return 0;
        };

        for (int y = 0; y < T; y++)
        {
            for (int x = 0; x < T; x++)
            {
                int s = shape(x, y);
                if (s == 0)
                {
                    bool edge = false;
                    if (shape(x + 1, y) != 0 || shape(x - 1, y) != 0 || shape(x, y + 1) != 0 || shape(x, y - 1) != 0) edge = true;
                    if (edge) bmp.SetPixel(x, y, cInk);
                    else
                    {
                        float ex = (x - 20f) / 15f;
                        float ey = (y - 36f) / 3f;
                        if (ex * ex + ey * ey < 1f) bmp.SetPixel(x, y, Color.FromArgb(100, 0, 0, 20));
                    }
                    continue;
                }
                Color c;
                if (s == 1)
                {
                    int ry = y - 24;
                    if (ry == 0) c = g4;
                    else if (ry <= 2) c = g3;
                    else if (ry <= 5) c = g2;
                    else if (ry <= 8) c = g1;
                    else c = g0;
                    if (x == 7) c = Lerp(c, g4, 0.5f);
                    if (x == 32) c = Lerp(c, g0, 0.5f);
                    if (ry == 3 && x > 10 && x < 30) c = g4;
                    if (ry == 6 && x > 9 && x < 31) c = g1;
                }
                else
                {
                    int ry = y - 17;
                    c = ry < 2 ? g4 : (ry < 5 ? Color.FromArgb(255, 226, 90) : g3);
                    if (x < 16 && ry < 4) c = Color.FromArgb(255, 252, 210);
                }
                bmp.SetPixel(x, y, c);
            }
        }
        return bmp;
    }

    private Bitmap MakeExit(int variant)
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        Color st0 = Color.FromArgb(26, 32, 56);
        Color st1 = Color.FromArgb(58, 68, 104);
        Color st2 = Color.FromArgb(96, 110, 152);
        Color st3 = Color.FromArgb(138, 154, 196);
        Color st4 = Color.FromArgb(190, 206, 238);
        Color g1 = Color.FromArgb(184, 110, 8);
        Color g2 = Color.FromArgb(236, 164, 18);
        Color g3 = Color.FromArgb(255, 208, 44);
        Color g4 = Color.FromArgb(255, 240, 130);

        Func<int, int, bool> outer = (x, y) =>
        {
            if (x < 7 || x > 32 || y > 39 || y < 1) return false;
            if (y >= 13) return true;
            float dx = x - 19.5f;
            float dy = y - 13f;
            return dx * dx + dy * dy <= 12.5f * 12.5f;
        };
        Func<int, int, bool> inner = (x, y) =>
        {
            if (x < 11 || x > 28 || y > 39) return false;
            if (y >= 13) return true;
            float dx = x - 19.5f;
            float dy = y - 13f;
            return dx * dx + dy * dy <= 8.5f * 8.5f;
        };

        for (int y = 0; y < T; y++)
        {
            for (int x = 0; x < T; x++)
            {
                if (!outer(x, y))
                {
                    if (outer(x + 1, y) || outer(x - 1, y) || outer(x, y + 1) || outer(x, y - 1)) bmp.SetPixel(x, y, cInk);
                    continue;
                }
                if (!inner(x, y))
                {
                    Color c = x < 19.5f ? st4 : st1;
                    if (y % 8 == 0) c = x < 19.5f ? st3 : st0;
                    if (!outer(x - 1, y - 1) || !outer(x, y - 1)) c = Color.FromArgb(240, 248, 255);
                    bmp.SetPixel(x, y, c);
                    continue;
                }

                Color ic;
                if (variant == 0)
                {
                    ic = ((x / 4) % 2 == 0) ? st1 : st2;
                    if (x % 4 == 0) ic = st0;
                    ic = Lerp(ic, st0, (y - 8) / 90f);
                    float lx = x - 19.5f;
                    if (x >= 16 && x <= 23 && y >= 23 && y <= 31)
                    {
                        ic = y < 25 ? g4 : (y < 28 ? g3 : g2);
                        if (x == 23 || y == 31) ic = g1;
                        if ((x == 19 || x == 20) && y >= 26 && y <= 28) ic = cInk;
                    }
                    else
                    {
                        float dd = MathF.Sqrt(lx * lx + (y - 23f) * (y - 23f));
                        if (y <= 23 && dd >= 3.2f && dd <= 5.2f) ic = st4;
                    }
                }
                else
                {
                    float dx = x - 19.5f;
                    float dy = y - 26f;
                    float d = MathF.Sqrt(dx * dx + dy * dy) / 16f;
                    ic = Lerp(g4, g2, d);
                    if (variant == 2) ic = Lerp(ic, Color.White, 0.4f);
                    bool arrow = false;
                    if (y >= 12 && y <= 20 && MathF.Abs(dx) <= (y - 12) * 0.8f) arrow = true;
                    if (y > 20 && y <= 31 && MathF.Abs(dx) <= 2.2f) arrow = true;
                    if (arrow) ic = Color.FromArgb(140, 70, 0);
                }
                bmp.SetPixel(x, y, ic);
            }
        }
        return bmp;
    }
}
