@echo off
rem Re-launch inside "cmd /k" so that any message stays visible if something goes wrong.
if not "%~1"=="child" cmd /k ""%~f0" child" & exit /b

setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "PUB=%~dp0bin\Release\net8.0-windows\win-x64\publish"
set "EXE=%PUB%\LodeRunner.exe"
set "RESULT=1"

echo ==============================================
echo   Lode Runner - build script
echo ==============================================
echo.

rem 1. dotnet available?
where dotnet >nul 2>&1
if errorlevel 1 goto :nodotnet

rem 2. SDK major version 8 or newer? (a newer SDK builds net8.0 projects fine)
set "SDKMAJOR=0"
for /f "tokens=1 delims=. " %%M in ('dotnet --version 2^>nul') do set "SDKMAJOR=%%M"
set /a SDKNUM=SDKMAJOR
if !SDKNUM! LSS 8 goto :nosdk
echo Using .NET SDK major version !SDKNUM!.
echo Note: the first build needs internet access to download the .NET 8 runtime packs.
echo.

if not exist "%~dp0LodeRunner.csproj" goto :noproject

rem 3. remove previous publish folder
if exist "%PUB%" echo Removing previous publish folder...
if exist "%PUB%" rmdir /s /q "%PUB%"
if exist "%PUB%" goto :cantremove

rem 4. publish
echo Publishing...
dotnet publish LodeRunner.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishTrimmed=false
set "RC=!errorlevel!"
if not "!RC!"=="0" goto :pubfail

rem 5. verify the executable
if not exist "%EXE%" goto :noexe
set "SIZE=0"
for %%F in ("%EXE%") do set "SIZE=%%~zF"
if "!SIZE!"=="0" goto :emptyexe

rem 6. keep only the executable
for %%F in ("%PUB%\*") do if /i not "%%~nxF"=="LodeRunner.exe" del /f /q "%%F" >nul 2>&1
for /d %%D in ("%PUB%\*") do rmdir /s /q "%%D" >nul 2>&1

rem 7. exactly one file, and it is LodeRunner.exe
set "COUNT=0"
set "ONLY="
for /f "delims=" %%F in ('dir /b /a "%PUB%"') do set /a COUNT+=1 & set "ONLY=%%F"
if not "!COUNT!"=="1" goto :badcount
if /i not "!ONLY!"=="LodeRunner.exe" goto :badfile

echo.
echo ==============================================
echo   BUILD SUCCEEDED
echo   Executable: %EXE%
echo   Size: !SIZE! bytes
echo ==============================================
set "RESULT=0"
goto :end

:nodotnet
echo ERROR: "dotnet" was not found. Install the .NET 8 SDK or newer:
echo https://dotnet.microsoft.com/download/dotnet/8.0
goto :fail
:nosdk
echo ERROR: the installed .NET SDK is older than version 8. Installed SDKs:
dotnet --list-sdks
echo Install the .NET 8 SDK or newer: https://dotnet.microsoft.com/download/dotnet/8.0
goto :fail
:noproject
echo ERROR: LodeRunner.csproj was not found next to build.bat.
goto :fail
:cantremove
echo ERROR: could not remove the old publish folder. Close LodeRunner.exe if it is running.
goto :fail
:pubfail
echo ERROR: dotnet publish failed with exit code !RC!. Read the messages above.
goto :fail
:noexe
echo ERROR: the expected executable was not produced.
goto :fail
:emptyexe
echo ERROR: LodeRunner.exe is empty.
goto :fail
:badcount
echo ERROR: the publish folder should contain exactly one file but contains !COUNT!.
goto :fail
:badfile
echo ERROR: the remaining file is "!ONLY!", expected LodeRunner.exe.
goto :fail

:fail
echo.
echo ==============================================
echo   BUILD FAILED
echo ==============================================

:end
echo.
pause
exit %RESULT%
