namespace LodeRunner;

/// <summary>Tile types used by the grid. Hole is a dug brick (temporary).</summary>
public enum Tile
{
    Empty,
    Brick,   // diggable brick
    Solid,   // indestructible block
    Ladder,
    Rope,
    Gold,
    Exit,
    Hole
}

/// <summary>Shared layout constants.</summary>
public static class Cfg
{
    public const int T = 40;            // tile size in pixels
    public const int Cols = 20;
    public const int Rows = 14;
    public const int LogicalW = 800;    // Cols * T
    public const int HudH = 48;
    public const int BoardH = 560;      // Rows * T
    public const int FooterH = 32;
    public const int LogicalH = 640;    // HudH + BoardH + FooterH
}

public sealed class LevelDef
{
    public string Name { get; }
    public double EnemyPace { get; }
    public string[] Map { get; }

    public LevelDef(string name, double enemyPace, string[] map)
    {
        Name = name;
        EnemyPace = enemyPace;
        Map = map;
    }
}

/// <summary>
/// Map legend:  . empty   # diggable brick   = solid block   H ladder   - rope
///              $ gold    E exit             P player start  X enemy start
/// Every map is exactly 20 columns x 14 rows.
/// </summary>
public static class LevelLibrary
{
    public static readonly LevelDef[] All =
    {
        new LevelDef("Training Grounds", 0.75, new[]
        {
            //01234567890123456789
            "====================", // 0
            "....................", // 1
            ".$..$.......$...E...", // 2
            "######H#######H#=###", // 3
            "......H.####..H.....", // 4
            "..$...H..X..$.H..$..", // 5
            "###H############H###", // 6
            "...H....####....H...", // 7
            ".$.H..$..X...$..H...", // 8
            "########H#########H#", // 9
            "........H..###....H.", // 10
            ".P.$....H.........H$", // 11
            "####################", // 12
            "===================="  // 13
        }),
        new LevelDef("Underground Vault", 0.85, new[]
        {
            //01234567890123456789
            "====================", // 0
            "....................", // 1
            ".$...-----...$...E.$", // 2
            "#####.....##H####=##", // 3
            "............H..####.", // 4
            "..$..X...$..H...$...", // 5
            "#####H###########H##", // 6
            ".....H..###......H..", // 7
            ".$...H..=$....X..H..", // 8
            "###########H########", // 9
            "..####.....H........", // 10
            ".P.$...$...H...$.X.$", // 11
            "######=#########=###", // 12
            "===================="  // 13
        }),
        new LevelDef("Golden Maze", 0.95, new[]
        {
            //01234567890123456789
            "====================", // 0
            "....................", // 1
            "$....$..-----.X.$..E", // 2
            "###H####.....###H##=", // 3
            "...H.###.....###H...", // 4
            "..$H..X.-----.$.H..$", // 5
            "######H#.....#H#####", // 6
            "..###.H.......H.###.", // 7
            "$.....H..$..$.H.X...", // 8
            "#H################H#", // 9
            ".H..###.....###...H.", // 10
            "$H.P..$...=.$.X$..H$", // 11
            "######=#####=#######", // 12
            "===================="  // 13
        })
    };
}

public sealed class GameLevel
{
    public readonly Tile[,] Cells = new Tile[Cfg.Cols, Cfg.Rows];
    public readonly List<Point> EnemyStarts = new List<Point>();
    public Point PlayerStart;
    public Point ExitCell;
    public int GoldTotal;
    public int GoldLeft;
    public string Name = "";
    public double EnemyPace = 0.75;

    /// <summary>Tile lookup. Anything outside the grid behaves like a solid wall.</summary>
    public Tile Get(int c, int r)
    {
        if (c < 0 || c >= Cfg.Cols || r < 0 || r >= Cfg.Rows) return Tile.Solid;
        return Cells[c, r];
    }

    public bool Blocks(int c, int r)
    {
        Tile t = Get(c, r);
        return t == Tile.Brick || t == Tile.Solid;
    }

    public bool Stands(int c, int r)
    {
        Tile t = Get(c, r);
        return t == Tile.Brick || t == Tile.Solid || t == Tile.Ladder;
    }

    private bool CellIsSupported(int c, int r)
    {
        Tile t = Get(c, r);
        return t == Tile.Ladder || t == Tile.Rope || Stands(c, r + 1);
    }

    /// <summary>Parses and validates a level definition. Throws InvalidDataException when the level is broken.</summary>
    public static GameLevel Load(LevelDef def)
    {
        if (def.Map.Length != Cfg.Rows)
            throw new InvalidDataException(def.Name + ": expected " + Cfg.Rows + " rows, found " + def.Map.Length + ".");

        GameLevel lv = new GameLevel();
        lv.Name = def.Name;
        lv.EnemyPace = def.EnemyPace;
        int starts = 0;
        int exits = 0;

        for (int r = 0; r < Cfg.Rows; r++)
        {
            string row = def.Map[r];
            if (row.Length != Cfg.Cols)
                throw new InvalidDataException(def.Name + ": row " + r + " has " + row.Length + " columns, expected " + Cfg.Cols + ".");

            for (int c = 0; c < Cfg.Cols; c++)
            {
                char ch = row[c];
                Tile t = Tile.Empty;
                switch (ch)
                {
                    case '.': break;
                    case '#': t = Tile.Brick; break;
                    case '=': t = Tile.Solid; break;
                    case 'H': t = Tile.Ladder; break;
                    case '-': t = Tile.Rope; break;
                    case '$': t = Tile.Gold; lv.GoldTotal++; break;
                    case 'E': t = Tile.Exit; lv.ExitCell = new Point(c, r); exits++; break;
                    case 'P': lv.PlayerStart = new Point(c, r); starts++; break;
                    case 'X': lv.EnemyStarts.Add(new Point(c, r)); break;
                    default:
                        throw new InvalidDataException(def.Name + ": unknown map character '" + ch + "' at column " + c + ", row " + r + ".");
                }
                lv.Cells[c, r] = t;
            }
        }

        if (starts != 1) throw new InvalidDataException(def.Name + ": needs exactly one player start (P).");
        if (exits != 1) throw new InvalidDataException(def.Name + ": needs exactly one exit (E).");
        if (lv.GoldTotal < 3) throw new InvalidDataException(def.Name + ": needs at least three gold pieces.");
        if (lv.EnemyStarts.Count < 1) throw new InvalidDataException(def.Name + ": needs at least one enemy start (X).");

        if (lv.Blocks(lv.PlayerStart.X, lv.PlayerStart.Y) || !lv.CellIsSupported(lv.PlayerStart.X, lv.PlayerStart.Y))
            throw new InvalidDataException(def.Name + ": invalid player start position.");
        if (lv.Blocks(lv.ExitCell.X, lv.ExitCell.Y) || !lv.CellIsSupported(lv.ExitCell.X, lv.ExitCell.Y))
            throw new InvalidDataException(def.Name + ": the exit has no floor under it.");
        foreach (Point e in lv.EnemyStarts)
        {
            if (lv.Blocks(e.X, e.Y) || !lv.CellIsSupported(e.X, e.Y))
                throw new InvalidDataException(def.Name + ": invalid enemy start at " + e.X + "," + e.Y + ".");
        }

        lv.ValidateReachability(def.Name);
        lv.GoldLeft = lv.GoldTotal;
        return lv;
    }

    /// <summary>
    /// Flood-fills every cell the player can reach by walking, climbing and falling (no digging needed)
    /// and checks that all gold and the exit are inside that region.
    /// </summary>
    private void ValidateReachability(string name)
    {
        bool[,] seen = new bool[Cfg.Cols, Cfg.Rows];
        Queue<Point> queue = new Queue<Point>();
        seen[PlayerStart.X, PlayerStart.Y] = true;
        queue.Enqueue(PlayerStart);

        void Visit(int c, int r)
        {
            if (Blocks(c, r) || seen[c, r]) return;
            seen[c, r] = true;
            queue.Enqueue(new Point(c, r));
        }

        while (queue.Count > 0)
        {
            Point p = queue.Dequeue();
            int c = p.X;
            int r = p.Y;
            Tile here = Get(c, r);

            if (!CellIsSupported(c, r))
            {
                Visit(c, r + 1); // free fall
                continue;
            }

            Visit(c - 1, r);
            Visit(c + 1, r);
            if (here == Tile.Ladder && !Blocks(c, r - 1)) Visit(c, r - 1);
            if (!Blocks(c, r + 1) && (here == Tile.Ladder || here == Tile.Rope || Get(c, r + 1) == Tile.Ladder))
                Visit(c, r + 1);
        }

        for (int r = 0; r < Cfg.Rows; r++)
        {
            for (int c = 0; c < Cfg.Cols; c++)
            {
                Tile t = Cells[c, r];
                if ((t == Tile.Gold || t == Tile.Exit) && !seen[c, r])
                    throw new InvalidDataException(name + ": " + t + " at column " + c + ", row " + r + " cannot be reached.");
            }
        }
    }
}
