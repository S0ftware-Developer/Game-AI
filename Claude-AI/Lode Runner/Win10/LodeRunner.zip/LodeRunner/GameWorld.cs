namespace LodeRunner;

public enum GameMode { Title, Playing, Paused, LevelComplete, GameOver, Victory }

/// <summary>All game rules and state. Updated at a fixed 60 steps per second.</summary>
public sealed class GameWorld
{
    public const int OpenFrames = 180;      // a hole stays open for about 3 seconds
    public const int WarnFrames = 50;       // closing animation at the end of that time
    public const int DigFrames = 14;
    public const int HurtFrames = 60;
    public const int VictoryFrames = 80;
    public const int LevelBonus = 500;
    private const int PlayerSpeed = 3;
    private const int EnemySpeed = 2;
    private const int TrapFrames = 150;

    public GameMode Mode = GameMode.Title;
    public int Score;
    public int Lives = 3;
    public int LevelIndex;
    public int Frame;
    public int LevelStartScore;
    public int BannerTimer;
    public int ExitBannerTimer;
    public int HurtFlash;
    public GameLevel Level;
    public readonly Player Player = new Player();
    public readonly List<Enemy> Enemies = new List<Enemy>();
    public readonly List<Hole> Holes = new List<Hole>();
    public readonly List<Particle> Particles = new List<Particle>();
    public readonly List<FloatText> Texts = new List<FloatText>();

    private readonly Random rng = new Random();
    private int pendingDig;
    private int digBuffer;

    public bool ExitUnlocked { get { return Level.GoldLeft <= 0; } }
    public int GoldCollected { get { return Level.GoldTotal - Level.GoldLeft; } }
    public int LevelCount { get { return LevelLibrary.All.Length; } }

    public GameWorld()
    {
        foreach (LevelDef def in LevelLibrary.All)
        {
            GameLevel.Load(def); // validates every level before the game can start
        }
        Level = GameLevel.Load(LevelLibrary.All[0]);
        ResetActors(true);
    }

    // ------------------------------------------------------------------ flow control

    public void StartGame()
    {
        Score = 0;
        Lives = 3;
        LevelIndex = 0;
        LoadLevel();
        Mode = GameMode.Playing;
        Sfx.Play(SfxId.Start);
    }

    private void LoadLevel()
    {
        Level = GameLevel.Load(LevelLibrary.All[LevelIndex]);
        LevelStartScore = Score;
        Holes.Clear();
        Particles.Clear();
        Texts.Clear();
        ResetActors(true);
        BannerTimer = 150;
        ExitBannerTimer = 0;
        HurtFlash = 0;
        pendingDig = 0;
        digBuffer = 0;
    }

    public void RestartLevel()
    {
        Score = LevelStartScore;
        LoadLevel();
        Mode = GameMode.Playing;
    }

    private void ResetActors(bool recreateEnemies)
    {
        Player.Reset(Level);
        if (recreateEnemies)
        {
            Enemies.Clear();
            for (int i = 0; i < Level.EnemyStarts.Count; i++)
            {
                Enemy e = new Enemy();
                e.Index = i;
                e.ResetTo(Level.EnemyStarts[i], 70);
                Enemies.Add(e);
            }
        }
        else
        {
            for (int i = 0; i < Enemies.Count; i++)
            {
                Enemies[i].ResetTo(Level.EnemyStarts[Enemies[i].Index], 70);
            }
        }
    }

    private void CloseAllHoles()
    {
        foreach (Hole h in Holes)
        {
            Level.Cells[h.C, h.R] = Tile.Brick;
        }
        Holes.Clear();
    }

    private void AdvanceLevel()
    {
        if (LevelIndex + 1 >= LevelLibrary.All.Length)
        {
            Mode = GameMode.Victory;
            Sfx.Play(SfxId.Complete);
            return;
        }
        LevelIndex++;
        LoadLevel();
        Mode = GameMode.Playing;
        Sfx.Play(SfxId.Start);
    }

    public void AutoPause()
    {
        if (Mode == GameMode.Playing) Mode = GameMode.Paused;
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                switch (Mode)
                {
                    case GameMode.Title: StartGame(); break;
                    case GameMode.Paused: Mode = GameMode.Playing; break;
                    case GameMode.LevelComplete: AdvanceLevel(); break;
                    case GameMode.GameOver: StartGame(); break;
                    case GameMode.Victory: StartGame(); break;
                }
                break;
            case Keys.Escape:
                if (Mode == GameMode.Playing) Mode = GameMode.Paused;
                else if (Mode == GameMode.Paused) Mode = GameMode.Playing;
                break;
            case Keys.R:
                if (Mode == GameMode.Playing || Mode == GameMode.Paused) RestartLevel();
                else if (Mode == GameMode.GameOver) StartGame();
                break;
            case Keys.Z:
            case Keys.J:
                QueueDig(-1);
                break;
            case Keys.X:
            case Keys.K:
                QueueDig(1);
                break;
            case Keys.M:
                Sfx.Muted = !Sfx.Muted;
                break;
        }
    }

    private void QueueDig(int dir)
    {
        if (Mode != GameMode.Playing) return;
        pendingDig = dir;
        digBuffer = 10;
    }

    // ------------------------------------------------------------------ main update

    public void Update(bool left, bool right, bool up, bool down)
    {
        Frame++;
        if (Mode != GameMode.Playing) return;

        UpdateParticles();
        if (BannerTimer > 0) BannerTimer--;
        if (ExitBannerTimer > 0) ExitBannerTimer--;
        if (digBuffer > 0)
        {
            digBuffer--;
            if (digBuffer == 0) pendingDig = 0;
        }
        UpdateHoles();

        if (Player.State == PlayerState.Hurt)
        {
            Player.AnimTick++;
            Player.StateTimer--;
            if (Player.StateTimer <= 0)
            {
                if (Lives <= 0)
                {
                    Mode = GameMode.GameOver;
                    Sfx.Play(SfxId.GameOver);
                }
                else
                {
                    CloseAllHoles();
                    ResetActors(false);
                }
            }
            return;
        }

        if (Player.State == PlayerState.Victory)
        {
            Player.AnimTick++;
            Player.StateTimer--;
            if (Player.StateTimer <= 0) Mode = GameMode.LevelComplete;
            return;
        }

        UpdatePlayer(left, right, up, down);
        for (int i = 0; i < Enemies.Count; i++)
        {
            UpdateEnemy(Enemies[i]);
        }
        CheckEnemyContact();
        CheckExit();
    }

    // ------------------------------------------------------------------ player

    private void UpdatePlayer(bool left, bool right, bool up, bool down)
    {
        Player p = Player;
        p.AnimTick++;
        p.Moving = false;
        p.Climbing = false;
        if (p.Invuln > 0) p.Invuln--;

        if (p.State == PlayerState.Digging)
        {
            int dox = p.Ox;
            if (dox > 0) p.X -= Math.Min(4, dox);
            else if (dox < 0) p.X += Math.Min(4, -dox);
            p.StateTimer--;
            if (p.StateTimer <= 0) p.State = PlayerState.Normal;
            return;
        }

        if (p.Escaping)
        {
            p.StepEscape(3);
            return;
        }

        if (!p.IsSupported(Level))
        {
            p.Fall(Level);
            p.Falling = true;
            CollectGold();
            return;
        }
        p.Falling = false;

        if (pendingDig != 0 && p.Oy == 0 && Level.Get(p.Col, p.Row) != Tile.Ladder)
        {
            int d = pendingDig;
            pendingDig = 0;
            if (TryDig(d)) return;
        }

        int ix = (right ? 1 : 0) - (left ? 1 : 0);
        int iy = (down ? 1 : 0) - (up ? 1 : 0);
        bool moved = false;
        if (iy != 0)
        {
            moved = p.MoveVertical(Level, iy, PlayerSpeed) > 0;
            if (!moved && iy < 0) moved = p.TryStartEscape(Level);
        }
        if (!moved && ix != 0)
        {
            p.MoveHorizontal(Level, ix, PlayerSpeed);
        }
        CollectGold();
    }

    private bool TryDig(int dir)
    {
        Player p = Player;
        int c = p.Col;
        int r = p.Row;
        int tc = c + dir;
        int tr = r + 1;
        p.Facing = dir;

        if (Level.Get(tc, tr) != Tile.Brick) return false;           // only diggable brick
        Tile above = Level.Get(tc, r);
        if (above != Tile.Empty && above != Tile.Rope) return false; // the space above the target must be free
        if (EnemyInCell(tc, r)) return false;

        Level.Cells[tc, tr] = Tile.Hole;
        Holes.Add(new Hole(tc, tr));
        p.State = PlayerState.Digging;
        p.StateTimer = DigFrames;
        p.DigDir = dir;
        Burst(tc * Cfg.T + 20f, tr * Cfg.T + 8f, 14, Color.FromArgb(176, 120, 78), Color.FromArgb(110, 72, 46), 2.6f, 0.22f, 26);
        Sfx.Play(SfxId.Dig);
        return true;
    }

    private bool EnemyInCell(int c, int r)
    {
        int cx = c * Cfg.T;
        int cy = r * Cfg.T;
        foreach (Enemy e in Enemies)
        {
            if (e.State == EnemyState.Respawning) continue;
            if (Math.Abs(e.X - cx) < Cfg.T && Math.Abs(e.Y - cy) < Cfg.T) return true;
        }
        return false;
    }

    private void CollectGold()
    {
        Player p = Player;
        int c = p.Col;
        int r = p.Row;
        if (Level.Get(c, r) != Tile.Gold) return;

        Level.Cells[c, r] = Tile.Empty; // removed first, so it can never be counted twice
        Level.GoldLeft--;
        Score += 100;
        Burst(c * Cfg.T + 20f, r * Cfg.T + 22f, 12, Color.FromArgb(255, 236, 120), Color.FromArgb(255, 190, 40), 2.4f, 0.05f, 28);
        AddText("+100", c * Cfg.T + 6f, r * Cfg.T, Color.FromArgb(255, 232, 110));
        Sfx.Play(SfxId.Gold);
        if (Level.GoldLeft <= 0)
        {
            ExitBannerTimer = 140;
            Sfx.Play(SfxId.Unlock);
        }
    }

    private void CheckExit()
    {
        Player p = Player;
        if (!ExitUnlocked || p.State != PlayerState.Normal) return;
        if (Level.Get(p.Col, p.Row) != Tile.Exit) return;
        if (Math.Abs(p.Ox) > 14 || Math.Abs(p.Oy) > 14) return;

        p.State = PlayerState.Victory;
        p.StateTimer = VictoryFrames;
        p.Escaping = false;
        Score += LevelBonus;
        AddText("+500", p.X + 4f, p.Y - 6f, Color.FromArgb(120, 255, 160));
        Sfx.Play(SfxId.Complete);
    }

    private void CheckEnemyContact()
    {
        Player p = Player;
        if (p.State != PlayerState.Normal || p.Invuln > 0) return;
        foreach (Enemy e in Enemies)
        {
            if (e.State != EnemyState.Active || e.Grace > 0) continue;
            if (Math.Abs(e.X - p.X) < 24 && Math.Abs(e.Y - p.Y) < 28)
            {
                HurtPlayer();
                return;
            }
        }
    }

    private void HurtPlayer()
    {
        Player p = Player;
        if (p.State != PlayerState.Normal) return;
        Lives--;
        p.State = PlayerState.Hurt;
        p.StateTimer = HurtFrames;
        p.Escaping = false;
        p.Invuln = 0;
        HurtFlash = 30;
        Burst(p.X + 20f, p.Y + 20f, 16, Color.FromArgb(255, 90, 70), Color.FromArgb(255, 220, 200), 3.0f, 0.12f, 26);
        Sfx.Play(SfxId.Hurt);
    }

    // ------------------------------------------------------------------ holes

    private void UpdateHoles()
    {
        for (int i = Holes.Count - 1; i >= 0; i--)
        {
            Hole h = Holes[i];
            h.Age++;
            if (h.Age < OpenFrames) continue;

            if (CellOccupied(h.C, h.R))
            {
                // never restore a brick on top of somebody
                h.Delay++;
                if (h.Delay > 360 && Player.State == PlayerState.Normal && PlayerOverlaps(h.C, h.R))
                {
                    HurtPlayer(); // safe resolution if the player is hopelessly stuck inside
                }
                continue;
            }

            Level.Cells[h.C, h.R] = Tile.Brick;
            Holes.RemoveAt(i);
            Burst(h.C * Cfg.T + 20f, h.R * Cfg.T + 20f, 8, Color.FromArgb(150, 150, 160), Color.FromArgb(100, 100, 110), 1.6f, 0.08f, 20);
            Sfx.Play(SfxId.Close);
        }
    }

    private bool PlayerOverlaps(int c, int r)
    {
        return Math.Abs(Player.X - c * Cfg.T) < Cfg.T && Math.Abs(Player.Y - r * Cfg.T) < Cfg.T;
    }

    private bool CellOccupied(int c, int r)
    {
        if (PlayerOverlaps(c, r)) return true;
        return EnemyInCell(c, r);
    }

    // ------------------------------------------------------------------ enemies

    private void UpdateEnemy(Enemy e)
    {
        e.AnimTick++;

        if (e.State == EnemyState.Respawning)
        {
            e.Timer--;
            if (e.Timer <= 0) FinishRespawn(e);
            return;
        }

        if (e.State == EnemyState.Trapped)
        {
            if (Level.Get(e.Col, e.Row) != Tile.Hole)
            {
                e.State = EnemyState.Active; // defensive: the hole is gone, resume normal behaviour
                return;
            }
            e.Timer--;
            if (e.Timer <= 0)
            {
                // the guard is taken out of play; the hole can close and the guard comes back elsewhere
                e.State = EnemyState.Respawning;
                e.Timer = 70;
            }
            return;
        }

        e.Moving = false;
        e.Climbing = false;

        if (!e.IsSupported(Level))
        {
            e.Fall(Level);
            e.Falling = true;
            return;
        }
        e.Falling = false;

        if (TryTrap(e)) return;

        if (e.Grace > 0)
        {
            e.Grace--;
            return;
        }

        e.Pace += Level.EnemyPace;
        if (e.Pace < 1.0) return;
        e.Pace -= 1.0;
        MoveEnemy(e);
    }

    private bool TryTrap(Enemy e)
    {
        int c = e.Col;
        int r = e.Row;
        if (e.Oy != 0) return false;
        if (Level.Get(c, r) != Tile.Hole) return false;
        if (!Level.Stands(c, r + 1)) return false; // falls through a one-brick floor instead of being trapped

        e.X = c * Cfg.T;
        e.State = EnemyState.Trapped;
        e.Timer = TrapFrames;
        Score += 200; // once per trap: the state change guarantees a single award
        AddText("+200", c * Cfg.T + 4f, r * Cfg.T - 10f, Color.FromArgb(255, 150, 90));
        Burst(c * Cfg.T + 20f, r * Cfg.T + 14f, 10, Color.FromArgb(255, 220, 90), Color.FromArgb(255, 255, 200), 2.2f, 0.06f, 24);
        Sfx.Play(SfxId.Trap);
        return true;
    }

    private void FinishRespawn(Enemy e)
    {
        Point best = Level.EnemyStarts[0];
        int bestDist = -1;
        foreach (Point sp in Level.EnemyStarts)
        {
            int dist = Math.Abs(sp.X - Player.Col) + Math.Abs(sp.Y - Player.Row);
            if (dist > bestDist)
            {
                bestDist = dist;
                best = sp;
            }
        }
        if (bestDist < 6)
        {
            e.Timer = 30; // the player is too close to every spawn point: wait a little longer
            return;
        }
        e.ResetTo(best, 60);
    }

    private void MoveEnemy(Enemy e)
    {
        if (e.X == e.LastX && e.Y == e.LastY)
        {
            e.Stuck++;
        }
        else
        {
            e.Stuck = 0;
            e.LastX = e.X;
            e.LastY = e.Y;
        }

        if (e.Stuck > 25 && e.WanderTimer <= 0)
        {
            e.WanderTimer = 45;
            e.WanderX = rng.Next(3) - 1;
            e.WanderY = rng.Next(3) - 1;
            e.Stuck = 0;
        }

        int ix = 0;
        int iy = 0;
        if (e.WanderTimer > 0)
        {
            e.WanderTimer--;
            ix = e.WanderX;
            iy = e.WanderY;
        }
        else
        {
            Think(e, out ix, out iy);
        }

        bool moved = false;
        if (iy != 0) moved = e.MoveVertical(Level, iy, EnemySpeed) > 0;
        if (!moved && ix != 0) e.MoveHorizontal(Level, ix, EnemySpeed);
    }

    private void Think(Enemy e, out int ix, out int iy)
    {
        ix = 0;
        iy = 0;
        Player p = Player;
        int ec = e.Col;
        int er = e.Row;
        int pc = p.Col;
        int pr = p.Row;

        bool wantUp = pr < er;
        if (er == pr)
        {
            int dx = p.X - e.X;
            int dir = dx > 0 ? 1 : (dx < 0 ? -1 : 0);
            if (dir == 0 || !Level.Blocks(ec + dir, er))
            {
                ix = dir;
                return;
            }
            // a wall is in the way on this row: look for a ladder to leave the row
            int cu = FindLadderColumn(e, true);
            int cd = FindLadderColumn(e, false);
            wantUp = cu >= 0 && (cd < 0 || Math.Abs(cu - ec) <= Math.Abs(cd - ec));
        }

        int dirV = wantUp ? -1 : 1;
        bool onLadder = Level.Get(ec, er) == Tile.Ladder || e.Oy != 0;
        if (onLadder && e.VerticalRoom(Level, dirV, 1) > 0)
        {
            iy = dirV;
            return;
        }

        int tc = FindLadderColumn(e, wantUp);
        if (tc >= 0)
        {
            if (tc == ec) iy = dirV;
            else ix = tc > ec ? 1 : -1;
            return;
        }

        ix = pc > ec ? 1 : (pc < ec ? -1 : (rng.Next(2) == 0 ? -1 : 1));
    }

    /// <summary>Nearest column on the enemy's row where it can climb up (wantUp) or get down (ladder, drop or rope).</summary>
    private int FindLadderColumn(Enemy e, bool wantUp)
    {
        int ec = e.Col;
        int er = e.Row;
        int best = -1;
        int bestDist = int.MaxValue;

        for (int dir = -1; dir <= 1; dir += 2)
        {
            for (int d = 0; d < Cfg.Cols; d++)
            {
                int c = ec + dir * d;
                if (c < 0 || c >= Cfg.Cols) break;
                if (Level.Blocks(c, er)) break;

                Tile here = Level.Get(c, er);
                bool good;
                if (wantUp)
                {
                    good = here == Tile.Ladder && !Level.Blocks(c, er - 1);
                }
                else
                {
                    good = Level.Get(c, er + 1) == Tile.Ladder
                        || (!Level.Stands(c, er + 1) && !Level.Blocks(c, er + 1));
                }

                if (good)
                {
                    if (d < bestDist)
                    {
                        bestDist = d;
                        best = c;
                    }
                    break;
                }

                bool footing = Level.Stands(c, er + 1) || here == Tile.Ladder || here == Tile.Rope;
                if (!footing) break;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ effects

    private void UpdateParticles()
    {
        for (int i = Particles.Count - 1; i >= 0; i--)
        {
            Particle p = Particles[i];
            p.VY += p.Gravity;
            p.X += p.VX;
            p.Y += p.VY;
            p.Life--;
            if (p.Life <= 0) Particles.RemoveAt(i);
        }
        for (int i = Texts.Count - 1; i >= 0; i--)
        {
            FloatText t = Texts[i];
            t.Y -= 0.7f;
            t.Life--;
            if (t.Life <= 0) Texts.RemoveAt(i);
        }
        if (HurtFlash > 0) HurtFlash--;
    }

    private void Burst(float x, float y, int count, Color c1, Color c2, float speed, float gravity, int life)
    {
        for (int i = 0; i < count; i++)
        {
            double a = rng.NextDouble() * Math.PI * 2.0;
            float sp = (float)(rng.NextDouble() * speed + speed * 0.3);
            Particle p = new Particle();
            p.X = x;
            p.Y = y;
            p.VX = (float)Math.Cos(a) * sp;
            p.VY = (float)Math.Sin(a) * sp - 1f;
            p.Gravity = gravity;
            p.Life = life + rng.Next(10);
            p.MaxLife = life + 10;
            p.Size = 2f + (float)rng.NextDouble() * 3f;
            p.Color = (i % 2 == 0) ? c1 : c2;
            Particles.Add(p);
        }
    }

    private void AddText(string text, float x, float y, Color color)
    {
        FloatText t = new FloatText();
        t.Text = text;
        t.X = x;
        t.Y = y;
        t.Life = 50;
        t.Color = color;
        Texts.Add(t);
    }
}
