namespace LodeRunner;

public enum PlayerState { Normal, Digging, Hurt, Victory }

public enum EnemyState { Active, Trapped, Respawning }

/// <summary>
/// Shared tile-based movement for the player and the enemies.
/// X/Y are the pixel position of the 40x40 body box. The "nearest cell" (Col/Row) is the cell that
/// contains the body centre; Ox/Oy are the pixel offsets from that cell's top-left corner (-20..19).
/// </summary>
public abstract class Actor
{
    public int X;
    public int Y;
    public int Facing = 1;
    public bool Falling;
    public bool Moving;
    public bool Climbing;
    public int AnimTick;

    // Climbing out of a hole: first straight up, then sideways onto the neighbouring floor.
    public bool Escaping;
    public int EscTx;
    public int EscTy;

    public static int CellOf(int v)
    {
        return (int)Math.Floor((v + Cfg.T / 2) / (double)Cfg.T);
    }

    public int Col { get { return CellOf(X); } }
    public int Row { get { return CellOf(Y); } }
    public int Ox { get { return X - Col * Cfg.T; } }
    public int Oy { get { return Y - Row * Cfg.T; } }

    public void PlaceAtCell(int c, int r)
    {
        X = c * Cfg.T;
        Y = r * Cfg.T;
        Falling = false;
        Moving = false;
        Climbing = false;
        Escaping = false;
    }

    /// <summary>True when the actor stands on something, hangs on a rope or is on a ladder.</summary>
    public bool IsSupported(GameLevel lv)
    {
        int c = Col;
        int r = Row;
        int oy = Oy;
        Tile t = lv.Get(c, r);
        if (t == Tile.Ladder) return true;
        if (oy > 0 && lv.Get(c, r + 1) == Tile.Ladder) return true;
        if (oy == 0 && t == Tile.Rope) return true;
        if (oy == 0 && lv.Stands(c, r + 1)) return true;
        return false;
    }

    /// <summary>How many pixels (0..amt) the actor may move vertically in the given direction (-1 up, +1 down).</summary>
    public int VerticalRoom(GameLevel lv, int dir, int amt)
    {
        int c = Col;
        int r = Row;
        int oy = Oy;
        Tile t = lv.Get(c, r);

        if (dir < 0)
        {
            bool ladderHere = t == Tile.Ladder || (oy > 0 && lv.Get(c, r + 1) == Tile.Ladder);
            if (!ladderHere) return 0;
            if (oy > 0)
            {
                if (t != Tile.Ladder || lv.Blocks(c, r - 1)) return Math.Min(amt, oy);
                return amt;
            }
            if (lv.Blocks(c, r - 1)) return 0;
            return amt;
        }

        if (oy < 0)
        {
            bool beyond = !lv.Blocks(c, r + 1) && (t == Tile.Ladder || lv.Get(c, r + 1) == Tile.Ladder);
            return beyond ? amt : Math.Min(amt, -oy);
        }
        if (lv.Blocks(c, r + 1)) return 0;
        bool can = t == Tile.Ladder || lv.Get(c, r + 1) == Tile.Ladder || (t == Tile.Rope && oy == 0);
        return can ? amt : 0;
    }

    public int MoveVertical(GameLevel lv, int dir, int amt)
    {
        int a = VerticalRoom(lv, dir, amt);
        if (a <= 0) return 0;
        int ox = Ox;
        if (ox > 0) X -= Math.Min(a, ox);
        else if (ox < 0) X += Math.Min(a, -ox);
        Y += dir * a;
        Climbing = true;
        return a;
    }

    public int MoveHorizontal(GameLevel lv, int dir, int amt)
    {
        Facing = dir;
        if (Oy != 0) return 0;
        int c = Col;
        int r = Row;
        int ox = X - c * Cfg.T;
        int a = amt;
        if (lv.Blocks(c + dir, r))
        {
            if (dir > 0 && ox > 0) { X = c * Cfg.T; ox = 0; }
            if (dir < 0 && ox < 0) { X = c * Cfg.T; ox = 0; }
            a = dir > 0 ? Math.Min(amt, Math.Max(0, -ox)) : Math.Min(amt, Math.Max(0, ox));
        }
        if (a <= 0) return 0;
        X += dir * a;
        Moving = true;
        return a;
    }

    /// <summary>One frame of gravity. Never lets the body enter a blocking tile.</summary>
    public void Fall(GameLevel lv)
    {
        int c = Col;
        int r = Row;
        int oy = Oy;
        int ox = X - c * Cfg.T;
        if (ox > 0) X -= Math.Min(4, ox);
        else if (ox < 0) X += Math.Min(4, -ox);

        int d = 4;
        if (lv.Blocks(c, r + 1))
        {
            if (oy > 0) { Y = r * Cfg.T; d = 0; }
            else d = Math.Min(d, -oy);
        }
        if (d > 0) Y += d;
    }

    /// <summary>Starts climbing out of the hole the actor is standing in. Returns false when there is no way out.</summary>
    public bool TryStartEscape(GameLevel lv)
    {
        int c = Col;
        int r = Row;
        if (lv.Get(c, r) != Tile.Hole || Oy != 0) return false;
        if (lv.Blocks(c, r - 1)) return false;
        int[] dirs = { Facing, -Facing };
        foreach (int d in dirs)
        {
            if (lv.Blocks(c + d, r) && !lv.Blocks(c + d, r - 1))
            {
                X = c * Cfg.T;
                EscTx = (c + d) * Cfg.T;
                EscTy = (r - 1) * Cfg.T;
                Escaping = true;
                Facing = d;
                return true;
            }
        }
        return false;
    }

    public void StepEscape(int speed)
    {
        Moving = false;
        Climbing = false;
        if (Y != EscTy)
        {
            int d = Math.Min(speed, Math.Abs(Y - EscTy));
            Y += Y > EscTy ? -d : d;
            Climbing = true;
        }
        else if (X != EscTx)
        {
            int d = Math.Min(speed, Math.Abs(X - EscTx));
            X += X > EscTx ? -d : d;
            Moving = true;
        }
        if (X == EscTx && Y == EscTy) Escaping = false;
    }
}

public sealed class Player : Actor
{
    public PlayerState State = PlayerState.Normal;
    public int StateTimer;
    public int Invuln;
    public int DigDir = 1;

    public void Reset(GameLevel lv)
    {
        PlaceAtCell(lv.PlayerStart.X, lv.PlayerStart.Y);
        State = PlayerState.Normal;
        StateTimer = 0;
        Invuln = 150;
        Facing = 1;
        DigDir = 1;
    }
}

public sealed class Enemy : Actor
{
    public EnemyState State = EnemyState.Active;
    public int Timer;
    public int Grace;
    public double Pace;
    public int Stuck;
    public int LastX;
    public int LastY;
    public int WanderTimer;
    public int WanderX;
    public int WanderY;
    public int Index;

    public void ResetTo(Point cell, int grace)
    {
        PlaceAtCell(cell.X, cell.Y);
        State = EnemyState.Active;
        Timer = 0;
        Grace = grace;
        Pace = 0.0;
        Stuck = 0;
        LastX = X;
        LastY = Y;
        WanderTimer = 0;
        WanderX = 0;
        WanderY = 0;
        Facing = -1;
    }
}

public sealed class Hole
{
    public readonly int C;
    public readonly int R;
    public int Age;
    public int Delay;

    public Hole(int c, int r)
    {
        C = c;
        R = r;
    }
}

public sealed class Particle
{
    public float X;
    public float Y;
    public float VX;
    public float VY;
    public float Gravity;
    public float Size;
    public int Life;
    public int MaxLife;
    public Color Color;
}

public sealed class FloatText
{
    public string Text = "";
    public float X;
    public float Y;
    public int Life;
    public Color Color;
}
