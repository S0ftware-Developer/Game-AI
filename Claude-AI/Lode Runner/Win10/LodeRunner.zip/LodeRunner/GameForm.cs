using System.Diagnostics;

namespace LodeRunner;

public sealed class GameForm : Form
{
    private const double StepSeconds = 1.0 / 60.0;

    private readonly GameWorld world;
    private readonly GameRenderer renderer;
    private readonly System.Windows.Forms.Timer timer;
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private readonly HashSet<Keys> held = new HashSet<Keys>();
    private double lastTime;
    private double accumulator;
    private bool fullscreen;
    private FormBorderStyle savedBorder = FormBorderStyle.Sizable;
    private FormWindowState savedState = FormWindowState.Normal;
    private bool failed;

    public GameForm()
    {
        Text = "Lode Runner";
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.Black;
        DoubleBuffered = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        KeyPreview = true;
        StartPosition = FormStartPosition.CenterScreen;

        Rectangle area = Screen.PrimaryScreen != null ? Screen.PrimaryScreen.WorkingArea : new Rectangle(0, 0, 1280, 720);
        double scale = Math.Max(1.0, DeviceDpi / 96.0);
        double maxScale = Math.Min((area.Width - 40) / (double)Cfg.LogicalW, (area.Height - 90) / (double)Cfg.LogicalH);
        scale = Math.Max(0.6, Math.Min(scale, maxScale));
        ClientSize = new Size((int)(Cfg.LogicalW * scale), (int)(Cfg.LogicalH * scale));
        MinimumSize = new Size(420, 380);

        Sfx.Init();
        world = new GameWorld();     // throws if a level is invalid (reported by Program.Main)
        renderer = new GameRenderer();

        timer = new System.Windows.Forms.Timer();
        timer.Interval = 8;
        timer.Tick += OnTick;
        lastTime = clock.Elapsed.TotalSeconds;
        timer.Start();
    }

    private void OnTick(object? sender, EventArgs e)
    {
        if (failed) return;
        try
        {
            double now = clock.Elapsed.TotalSeconds;
            double dt = now - lastTime;
            lastTime = now;
            if (dt > 0.1) dt = 0.1;
            accumulator += dt;

            bool left = held.Contains(Keys.Left) || held.Contains(Keys.A);
            bool right = held.Contains(Keys.Right) || held.Contains(Keys.D);
            bool up = held.Contains(Keys.Up) || held.Contains(Keys.W);
            bool down = held.Contains(Keys.Down) || held.Contains(Keys.S);

            int steps = 0;
            while (accumulator >= StepSeconds && steps < 5)
            {
                world.Update(left, right, up, down);
                accumulator -= StepSeconds;
                steps++;
            }
            if (steps >= 5) accumulator = 0.0;
            Invalidate();
        }
        catch (Exception ex)
        {
            Fatal(ex);
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        if (failed) return;
        try
        {
            renderer.Render(e.Graphics, world, ClientSize.Width, ClientSize.Height);
        }
        catch (Exception ex)
        {
            Fatal(ex);
        }
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        bool first = held.Add(e.KeyCode);
        if (first)
        {
            if (e.KeyCode == Keys.F11 || (e.KeyCode == Keys.Enter && e.Alt))
            {
                ToggleFullscreen();
            }
            else
            {
                try
                {
                    world.HandleKey(e.KeyCode);
                }
                catch (Exception ex)
                {
                    Fatal(ex);
                }
            }
        }
        e.Handled = true;
        e.SuppressKeyPress = true;
    }

    protected override void OnKeyUp(KeyEventArgs e)
    {
        held.Remove(e.KeyCode);
        e.Handled = true;
    }

    protected override void OnDeactivate(EventArgs e)
    {
        held.Clear();
        world.AutoPause();
        base.OnDeactivate(e);
    }

    private void ToggleFullscreen()
    {
        if (!fullscreen)
        {
            savedBorder = FormBorderStyle;
            savedState = WindowState;
            if (WindowState == FormWindowState.Maximized) WindowState = FormWindowState.Normal;
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            fullscreen = true;
        }
        else
        {
            FormBorderStyle = savedBorder;
            WindowState = savedState;
            fullscreen = false;
        }
        Invalidate();
    }

    private void Fatal(Exception ex)
    {
        if (failed) return;
        failed = true;
        timer.Stop();
        MessageBox.Show(ex.ToString(), "Lode Runner - unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        Close();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Dispose();
            renderer.Dispose();
        }
        base.Dispose(disposing);
    }
}
