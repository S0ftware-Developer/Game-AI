using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace LodeRunner;

public enum HeroPose { Idle, Walk, Climb, Fall, Rope, Dig, Hurt, Victory }

public enum FoePose { Idle, Walk, Climb, Trapped }

/// <summary>
/// Draws everything with GDI+. The game board is rendered into a 800x560 back buffer at logical size,
/// then scaled to the window together with the HUD, screens and the footer (which always keeps its own strip).
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    private const int T = Cfg.T;

    private readonly Bitmap board = new Bitmap(Cfg.LogicalW, Cfg.BoardH, PixelFormat.Format32bppPArgb);
    private readonly Bitmap bgCave;
    private readonly Bitmap tileBrick;
    private readonly Bitmap tileSolid;
    private readonly Bitmap tileLadder;
    private readonly Bitmap tileRope;
    private readonly Bitmap tileGold;
    private readonly Bitmap tileExitLocked;
    private readonly Bitmap tileExitOpen;
    private readonly ImageAttributes boardAttrs = new ImageAttributes();

    private readonly Font fHud;
    private readonly Font fHudLabel;
    private readonly Font fBig;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fFooter;
    private readonly Font fFloat;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;

    private readonly Pen penHeroLegDark;
    private readonly Pen penHeroLeg;
    private readonly Pen penHeroArmDark;
    private readonly Pen penHeroArm;
    private readonly Pen penFoeLegDark;
    private readonly Pen penFoeLeg;
    private readonly Pen penThin;
    private readonly Pen penToolHandle;

    public GameRenderer()
    {
        boardAttrs.SetWrapMode(WrapMode.TileFlipXY);

        fHud = new Font("Consolas", 20f, FontStyle.Bold, GraphicsUnit.Pixel);
        fHudLabel = new Font("Consolas", 12f, FontStyle.Bold, GraphicsUnit.Pixel);
        fBig = new Font("Arial", 48f, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Pixel);
        fMid = new Font("Arial", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Segoe UI", 17f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Segoe UI", 15f, FontStyle.Regular, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fFloat = new Font("Consolas", 16f, FontStyle.Bold, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;

        penHeroLegDark = RoundPen(Color.FromArgb(30, 36, 70), 6.6f);
        penHeroLeg = RoundPen(Color.FromArgb(238, 242, 252), 4.2f);
        penHeroArmDark = RoundPen(Color.FromArgb(30, 36, 70), 5.8f);
        penHeroArm = RoundPen(Color.FromArgb(64, 116, 226), 3.6f);
        penFoeLegDark = RoundPen(Color.FromArgb(70, 8, 20), 6.2f);
        penFoeLeg = RoundPen(Color.FromArgb(206, 36, 48), 4.0f);
        penThin = new Pen(Color.FromArgb(24, 20, 40), 1.2f);
        penToolHandle = RoundPen(Color.FromArgb(150, 100, 52), 2.6f);

        bgCave = MakeCave();
        tileBrick = MakeBrick();
        tileSolid = MakeSolid();
        tileLadder = MakeLadder();
        tileRope = MakeRope();
        tileGold = MakeGold();
        tileExitLocked = MakeExit(false);
        tileExitOpen = MakeExit(true);
    }

    public void Dispose()
    {
        board.Dispose();
        bgCave.Dispose();
        tileBrick.Dispose();
        tileSolid.Dispose();
        tileLadder.Dispose();
        tileRope.Dispose();
        tileGold.Dispose();
        tileExitLocked.Dispose();
        tileExitOpen.Dispose();
        boardAttrs.Dispose();
        fHud.Dispose();
        fHudLabel.Dispose();
        fBig.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fFooter.Dispose();
        fFloat.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        penHeroLegDark.Dispose();
        penHeroLeg.Dispose();
        penHeroArmDark.Dispose();
        penHeroArm.Dispose();
        penFoeLegDark.Dispose();
        penFoeLeg.Dispose();
        penThin.Dispose();
        penToolHandle.Dispose();
    }

    private static Pen RoundPen(Color color, float width)
    {
        Pen p = new Pen(color, width);
        p.StartCap = LineCap.Round;
        p.EndCap = LineCap.Round;
        p.LineJoin = LineJoin.Round;
        return p;
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameWorld w, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)Cfg.LogicalW, clientH / (float)Cfg.LogicalH);
        float offX = (clientW - Cfg.LogicalW * scale) / 2f;
        float offY = (clientH - Cfg.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, Cfg.LogicalW, Cfg.LogicalH));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (w.Mode == GameMode.Title)
            {
                DrawTitle(g, w);
            }
            else
            {
                DrawGameScreen(g, w);
                switch (w.Mode)
                {
                    case GameMode.Paused:
                        DrawPanel(g, w, "PAUSED", Color.FromArgb(255, 226, 110),
                            new[] { "The game is paused." },
                            "ESC - RESUME      R - RESTART LEVEL");
                        break;
                    case GameMode.LevelComplete:
                        DrawPanel(g, w, "LEVEL COMPLETE", Color.FromArgb(120, 255, 160),
                            new[]
                            {
                                "Gold collected: " + w.GoldCollected + " / " + w.Level.GoldTotal,
                                "Level bonus: +" + GameWorld.LevelBonus,
                                "Score: " + w.Score
                            },
                            "ENTER - NEXT LEVEL");
                        break;
                    case GameMode.GameOver:
                        DrawPanel(g, w, "GAME OVER", Color.FromArgb(255, 90, 80),
                            new[] { "FINAL SCORE", w.Score.ToString("D6") },
                            "ENTER - RESTART");
                        break;
                    case GameMode.Victory:
                        DrawPanel(g, w, "ALL LEVELS COMPLETE", Color.FromArgb(255, 226, 110),
                            new[] { "You emptied every vault!", "FINAL SCORE", w.Score.ToString("D6") },
                            "ENTER - PLAY AGAIN");
                        break;
                }
            }

            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ text helpers

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow)
        {
            using (SolidBrush sb = new SolidBrush(Color.FromArgb(210, 0, 0, 0)))
            {
                g.DrawString(s, f, sb, x + 2f, y + 2f, sf);
            }
        }
        using (SolidBrush b = new SolidBrush(c))
        {
            g.DrawString(s, f, b, x, y, sf);
        }
    }

    private static GraphicsPath RoundRect(float x, float y, float w, float h, float r)
    {
        GraphicsPath p = new GraphicsPath();
        float d = r * 2f;
        p.AddArc(x, y, d, d, 180f, 90f);
        p.AddArc(x + w - d, y, d, d, 270f, 90f);
        p.AddArc(x + w - d, y + h - d, d, d, 0f, 90f);
        p.AddArc(x, y + h - d, d, d, 90f, 90f);
        p.CloseFigure();
        return p;
    }

    private static void DrawStar(Graphics g, Brush b, float cx, float cy, float r)
    {
        PointF[] pts =
        {
            new PointF(cx, cy - r), new PointF(cx + r * 0.3f, cy - r * 0.3f),
            new PointF(cx + r, cy), new PointF(cx + r * 0.3f, cy + r * 0.3f),
            new PointF(cx, cy + r), new PointF(cx - r * 0.3f, cy + r * 0.3f),
            new PointF(cx - r, cy), new PointF(cx - r * 0.3f, cy - r * 0.3f)
        };
        g.FillPolygon(b, pts);
    }

    private static void DrawHeart(Graphics g, float cx, float cy, float s, Color fill)
    {
        using (SolidBrush b = new SolidBrush(fill))
        using (Pen outline = new Pen(Color.FromArgb(70, 0, 10), 1.5f))
        {
            PointF[] tri =
            {
                new PointF(cx - s * 0.95f, cy - s * 0.2f),
                new PointF(cx + s * 0.95f, cy - s * 0.2f),
                new PointF(cx, cy + s * 0.95f)
            };
            g.FillPolygon(b, tri);
            g.FillEllipse(b, cx - s, cy - s * 0.9f, s, s);
            g.FillEllipse(b, cx, cy - s * 0.9f, s, s);
            g.DrawPolygon(outline, tri);
        }
    }

    // ------------------------------------------------------------------ game screen

    private void DrawGameScreen(Graphics g, GameWorld w)
    {
        using (Graphics bg = Graphics.FromImage(board))
        {
            bg.SmoothingMode = SmoothingMode.AntiAlias;
            bg.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            DrawBoard(bg, w);
        }

        g.DrawImage(board, new Rectangle(0, Cfg.HudH, Cfg.LogicalW, Cfg.BoardH),
            0, 0, Cfg.LogicalW, Cfg.BoardH, GraphicsUnit.Pixel, boardAttrs);

        DrawHud(g, w);

        if (w.HurtFlash > 0)
        {
            int a = Math.Min(120, w.HurtFlash * 5);
            using (SolidBrush red = new SolidBrush(Color.FromArgb(a, 255, 20, 20)))
            {
                g.FillRectangle(red, 0, Cfg.HudH, Cfg.LogicalW, Cfg.BoardH);
            }
        }

        if (w.Mode == GameMode.Playing || w.Mode == GameMode.Paused)
        {
            if (w.BannerTimer > 0)
            {
                int a = Math.Min(255, w.BannerTimer * 5);
                Txt(g, "LEVEL " + (w.LevelIndex + 1), fBig, Color.FromArgb(a, 255, 226, 110), Cfg.LogicalW / 2f, Cfg.HudH + 150f, sfCenter, true);
                Txt(g, w.Level.Name.ToUpperInvariant(), fMid, Color.FromArgb(a, 255, 255, 255), Cfg.LogicalW / 2f, Cfg.HudH + 200f, sfCenter, true);
            }
            if (w.ExitBannerTimer > 0 && w.BannerTimer <= 0)
            {
                int a = Math.Min(255, w.ExitBannerTimer * 5);
                Txt(g, "EXIT OPEN - REACH THE DOOR!", fMid, Color.FromArgb(a, 120, 255, 160), Cfg.LogicalW / 2f, Cfg.HudH + 60f, sfCenter, true);
            }
        }
    }

    private void DrawHud(Graphics g, GameWorld w)
    {
        Rectangle r = new Rectangle(0, 0, Cfg.LogicalW, Cfg.HudH);
        using (LinearGradientBrush bg = new LinearGradientBrush(r, Color.FromArgb(38, 42, 70), Color.FromArgb(12, 14, 28), 90f))
        {
            g.FillRectangle(bg, r);
        }
        using (Pen line = new Pen(Color.FromArgb(214, 168, 60), 2f))
        {
            g.DrawLine(line, 0, Cfg.HudH - 1, Cfg.LogicalW, Cfg.HudH - 1);
        }

        HudItem(g, "SCORE", w.Score.ToString("D6"), 20f);
        HudItem(g, "GOLD REMAINING", w.Level.GoldLeft + " / " + w.Level.GoldTotal, 230f);
        Txt(g, "LIVES", fHudLabel, Color.FromArgb(150, 170, 220), 470f, 13f, sfLeft, false);
        int lives = Math.Max(0, Math.Min(6, w.Lives));
        for (int i = 0; i < lives; i++)
        {
            DrawHeart(g, 482f + i * 26f, 31f, 10f, Color.FromArgb(240, 60, 70));
        }
        HudItem(g, "LEVEL", (w.LevelIndex + 1) + " / " + w.LevelCount, 660f);
    }

    private void HudItem(Graphics g, string label, string value, float x)
    {
        Txt(g, label, fHudLabel, Color.FromArgb(150, 170, 220), x, 13f, sfLeft, false);
        Txt(g, value, fHud, Color.FromArgb(255, 224, 110), x, 32f, sfLeft, true);
    }

    private void DrawBoard(Graphics g, GameWorld w)
    {
        GameLevel lv = w.Level;
        bool exitOpen = w.ExitUnlocked;
        g.DrawImageUnscaled(bgCave, 0, 0);

        for (int r = 0; r < Cfg.Rows; r++)
        {
            for (int c = 0; c < Cfg.Cols; c++)
            {
                int x = c * T;
                int y = r * T;
                switch (lv.Cells[c, r])
                {
                    case Tile.Brick: g.DrawImageUnscaled(tileBrick, x, y); break;
                    case Tile.Solid: g.DrawImageUnscaled(tileSolid, x, y); break;
                    case Tile.Ladder: g.DrawImageUnscaled(tileLadder, x, y); break;
                    case Tile.Rope: g.DrawImageUnscaled(tileRope, x, y); break;
                    case Tile.Exit:
                        if (exitOpen) DrawExitGlow(g, x, y, w.Frame);
                        g.DrawImageUnscaled(exitOpen ? tileExitOpen : tileExitLocked, x, y);
                        break;
                    case Tile.Gold:
                        g.DrawImageUnscaled(tileGold, x, y);
                        DrawSparkle(g, x, y, c, r, w.Frame);
                        break;
                }
            }
        }

        foreach (Hole h in w.Holes)
        {
            DrawHole(g, h, w.Frame);
        }

        foreach (Enemy e in w.Enemies)
        {
            if (e.State == EnemyState.Respawning) continue;
            if (e.Grace > 0 && (w.Frame / 3) % 2 == 0) continue;
            FoePose pose = FoePose.Idle;
            if (e.State == EnemyState.Trapped) pose = FoePose.Trapped;
            else if (e.Climbing) pose = FoePose.Climb;
            else if (e.Moving) pose = FoePose.Walk;
            DrawFoeSprite(g, e.X, e.Y, 1f, e.Facing, pose, e.AnimTick * 0.32f, w.Frame);
        }

        Player p = w.Player;
        bool blink = p.Invuln > 0 && (w.Frame / 4) % 2 == 0;
        if (!blink)
        {
            HeroPose pose = HeroPose.Idle;
            float phase = p.AnimTick * 0.34f;
            if (p.State == PlayerState.Hurt) { pose = HeroPose.Hurt; phase = p.AnimTick * 0.5f; }
            else if (p.State == PlayerState.Victory) { pose = HeroPose.Victory; phase = p.AnimTick * 0.45f; }
            else if (p.State == PlayerState.Digging)
            {
                pose = HeroPose.Dig;
                phase = (GameWorld.DigFrames - p.StateTimer) / (float)GameWorld.DigFrames * 3.14159f;
            }
            else if (p.Escaping || p.Climbing) pose = HeroPose.Climb;
            else if (p.Falling) pose = HeroPose.Fall;
            else if (lv.Get(p.Col, p.Row) == Tile.Rope && p.Oy == 0) { pose = HeroPose.Rope; if (!p.Moving) phase = 0.8f; }
            else if (p.Moving) pose = HeroPose.Walk;
            DrawHeroSprite(g, p.X, p.Y, 1f, p.Facing, pose, phase, w.Frame);
        }

        using (SolidBrush pb = new SolidBrush(Color.White))
        {
            foreach (Particle pt in w.Particles)
            {
                int alpha = Math.Max(0, Math.Min(255, 255 * pt.Life / pt.MaxLife));
                pb.Color = Color.FromArgb(alpha, pt.Color);
                g.FillEllipse(pb, pt.X - pt.Size / 2f, pt.Y - pt.Size / 2f, pt.Size, pt.Size);
            }
        }

        foreach (FloatText t in w.Texts)
        {
            int alpha = Math.Max(0, Math.Min(255, t.Life * 8));
            Txt(g, t.Text, fFloat, Color.FromArgb(alpha, t.Color), t.X, t.Y, sfLeft, true);
        }
    }

    private void DrawHole(Graphics g, Hole h, int frame)
    {
        int x = h.C * T;
        int y = h.R * T;
        int ph = h.Age < 10 ? h.Age * T / 10 : T; // the brick crumbles away from the top

        if (ph < T)
        {
            g.DrawImage(tileBrick, new Rectangle(x, y + ph, T, T - ph), 0, ph, T, T - ph, GraphicsUnit.Pixel);
        }
        if (ph > 0)
        {
            using (LinearGradientBrush pit = new LinearGradientBrush(new Rectangle(x, y, T, T), Color.FromArgb(40, 28, 48), Color.FromArgb(8, 6, 14), 90f))
            {
                g.FillRectangle(pit, x, y, T, ph);
            }
            g.DrawImage(tileBrick, new Rectangle(x, y, 5, ph), 0, 0, 5, ph, GraphicsUnit.Pixel);
            g.DrawImage(tileBrick, new Rectangle(x + T - 5, y, 5, ph), T - 5, 0, 5, ph, GraphicsUnit.Pixel);
        }

        int warnStart = GameWorld.OpenFrames - GameWorld.WarnFrames;
        if (h.Age >= warnStart)
        {
            float prog = Math.Min(1f, (h.Age - warnStart) / (float)GameWorld.WarnFrames);
            int fill = (int)(prog * T); // the brick regrows from the bottom
            if (fill > 0)
            {
                g.DrawImage(tileBrick, new Rectangle(x, y + T - fill, T, fill), 0, T - fill, T, fill, GraphicsUnit.Pixel);
            }
            if ((frame / 4) % 2 == 0)
            {
                using (Pen warn = new Pen(Color.FromArgb(220, 255, 90, 60), 2f))
                {
                    g.DrawRectangle(warn, x + 1, y + 1, T - 2, T - 2);
                }
            }
        }
    }

    private void DrawExitGlow(Graphics g, int x, int y, int frame)
    {
        float pulse = 0.5f + 0.5f * MathF.Sin(frame * 0.12f);
        for (int i = 0; i < 3; i++)
        {
            float rad = 24f + i * 8f + pulse * 4f;
            int alpha = (int)(46f - i * 12f + pulse * 14f);
            using (SolidBrush b = new SolidBrush(Color.FromArgb(Math.Max(4, alpha), 255, 220, 90)))
            {
                g.FillEllipse(b, x + 20f - rad, y + 22f - rad, rad * 2f, rad * 2f);
            }
        }
    }

    private void DrawSparkle(Graphics g, int x, int y, int c, int r, int frame)
    {
        int t = (frame + c * 11 + r * 7) % 90;
        if (t >= 14) return;
        float s = 2f + (t < 7 ? t : 14 - t) * 0.7f;
        float cx = x + 27f;
        float cy = y + 17f;
        using (SolidBrush b = new SolidBrush(Color.FromArgb(235, 255, 255, 235)))
        {
            DrawStar(g, b, cx, cy, s);
        }
    }

    // ------------------------------------------------------------------ sprites

    private void DrawHeroSprite(Graphics g, float x, float y, float scale, int facing, HeroPose pose, float ph, int frame)
    {
        GraphicsState st = g.Save();
        try
        {
            g.TranslateTransform(x + 20f * scale, y);
            float sx = pose == HeroPose.Climb ? scale : scale * (facing < 0 ? -1f : 1f);
            g.ScaleTransform(sx, scale);

            float s = MathF.Sin(ph);
            float c = MathF.Cos(ph);
            float dy = 0f;
            float fax = -3f, fay = 38f, fbx = 3f, fby = 38f;
            float hax = -6f, hay = 27f, hbx = 6f, hby = 27f;

            switch (pose)
            {
                case HeroPose.Idle:
                    dy = MathF.Sin(ph * 0.25f) * 0.8f;
                    hay = 27f + dy;
                    hby = 27f + dy;
                    break;
                case HeroPose.Walk:
                    dy = -MathF.Abs(c) * 1.5f;
                    fax = s * 8f - 1f;
                    fbx = -s * 8f + 1f;
                    fay = 38f - MathF.Max(0f, c) * 3f;
                    fby = 38f - MathF.Max(0f, -c) * 3f;
                    hax = -s * 7f;
                    hay = 26f;
                    hbx = s * 7f + 2f;
                    hby = 26f;
                    break;
                case HeroPose.Climb:
                    fax = -4f; fbx = 4f;
                    fay = 38f + s * 3f;
                    fby = 38f - s * 3f;
                    hax = -6f; hay = 9f + s * 4f;
                    hbx = 6f; hby = 9f - s * 4f;
                    break;
                case HeroPose.Fall:
                    fax = -7f; fay = 37f;
                    fbx = 7f; fby = 36f;
                    hax = -10f; hay = 6f;
                    hbx = 10f; hby = 4f;
                    break;
                case HeroPose.Rope:
                    fax = -3f; fay = 38f + s * 1.5f;
                    fbx = 3f; fby = 38f - s * 1.5f;
                    hax = -3f; hay = 3f;
                    hbx = 4f; hby = 3f;
                    dy = 2f;
                    break;
                case HeroPose.Dig:
                    dy = 3f;
                    fax = -5f; fbx = 6f;
                    hax = 4f; hay = 25f;
                    hbx = 8f; hby = 24f;
                    break;
                case HeroPose.Hurt:
                    dy = MathF.Sin(ph * 2f) * 1.2f;
                    fax = -6f; fbx = 6f;
                    hax = -9f; hay = 10f + s * 4f;
                    hbx = 9f; hby = 10f - s * 4f;
                    break;
                case HeroPose.Victory:
                    dy = -MathF.Abs(MathF.Sin(ph * 0.5f)) * 5f;
                    fax = -4f; fbx = 4f;
                    hax = -10f; hay = 3f + dy;
                    hbx = 10f; hby = 3f + dy;
                    break;
            }

            float hipY = 26f + dy;
            float shoulderY = 19f + dy;

            // back arm and legs
            g.DrawLine(penHeroArmDark, -5f, shoulderY, hax, hay);
            g.DrawLine(penHeroArm, -5f, shoulderY, hax, hay);
            g.DrawLine(penHeroLegDark, -2.5f, hipY, fax, fay - 2f);
            g.DrawLine(penHeroLeg, -2.5f, hipY, fax, fay - 2f);
            g.DrawLine(penHeroLegDark, 2.5f, hipY, fbx, fby - 2f);
            g.DrawLine(penHeroLeg, 2.5f, hipY, fbx, fby - 2f);

            using (SolidBrush shoe = new SolidBrush(Color.FromArgb(52, 92, 196)))
            {
                g.FillEllipse(shoe, fax - 2f, fay - 3.5f, 8f, 5f);
                g.FillEllipse(shoe, fbx - 2f, fby - 3.5f, 8f, 5f);
                g.DrawEllipse(penThin, fax - 2f, fay - 3.5f, 8f, 5f);
                g.DrawEllipse(penThin, fbx - 2f, fby - 3.5f, 8f, 5f);
            }

            // scarf tail (flutters behind the hero)
            float fl = MathF.Sin(ph * 1.3f) * 2f;
            PointF[] tail =
            {
                new PointF(-4f, 16.5f + dy), new PointF(-14f, 13f + dy + fl),
                new PointF(-11f, 19f + dy + fl), new PointF(-4f, 19.5f + dy)
            };
            using (SolidBrush red = new SolidBrush(Color.FromArgb(216, 44, 48)))
            {
                g.FillPolygon(red, tail);
                g.DrawPolygon(penThin, tail);
            }

            // torso
            using (GraphicsPath torso = RoundRect(-6.5f, 17f + dy, 13f, 11f, 3f))
            using (SolidBrush shirt = new SolidBrush(Color.FromArgb(238, 242, 252)))
            using (SolidBrush stripe = new SolidBrush(Color.FromArgb(64, 116, 226)))
            using (SolidBrush belt = new SolidBrush(Color.FromArgb(120, 76, 42)))
            using (SolidBrush neck = new SolidBrush(Color.FromArgb(216, 44, 48)))
            {
                g.FillPath(shirt, torso);
                g.FillRectangle(stripe, -6f, 21f + dy, 12f, 3f);
                g.FillRectangle(belt, -6.5f, 25f + dy, 13f, 3f);
                g.DrawPath(penThin, torso);
                g.FillRectangle(neck, -5f, 15.5f + dy, 10f, 3f);
            }

            // head
            bool front = pose == HeroPose.Climb;
            float hx = front ? 0f : 1f;
            using (SolidBrush hair = new SolidBrush(Color.FromArgb(104, 62, 36)))
            using (SolidBrush skin = new SolidBrush(Color.FromArgb(255, 216, 172)))
            using (SolidBrush cap = new SolidBrush(Color.FromArgb(48, 104, 226)))
            using (SolidBrush capDark = new SolidBrush(Color.FromArgb(30, 70, 168)))
            using (SolidBrush white = new SolidBrush(Color.White))
            using (SolidBrush black = new SolidBrush(Color.FromArgb(24, 20, 40)))
            {
                if (!front) g.FillEllipse(hair, -8f, 5f + dy, 9f, 10f);
                g.FillEllipse(skin, hx - 7f, 2f + dy, 14f, 14f);
                g.DrawEllipse(penThin, hx - 7f, 2f + dy, 14f, 14f);
                if (front)
                {
                    g.FillEllipse(cap, -7.5f, 0.5f + dy, 15f, 11f);
                    g.FillEllipse(hair, -5f, 9f + dy, 10f, 5f);
                }
                else
                {
                    g.FillPie(cap, -7f, 0.5f + dy, 16f, 14f, 180f, 180f);
                    g.FillEllipse(capDark, 3f, 6.5f + dy, 9f, 3.5f);
                    g.FillEllipse(white, 1f, 3.4f + dy, 2.6f, 2.6f);
                    if (pose == HeroPose.Hurt)
                    {
                        g.DrawLine(penThin, 3.5f, 9f + dy, 7f, 12f + dy);
                        g.DrawLine(penThin, 7f, 9f + dy, 3.5f, 12f + dy);
                    }
                    else
                    {
                        g.FillEllipse(black, 4f, 9f + dy, 2.4f, 3.4f);
                    }
                    if (pose == HeroPose.Victory)
                        g.DrawArc(penThin, 2.5f, 10.5f + dy, 6f, 4f, 0f, 180f);
                    else
                        g.DrawLine(penThin, 4f, 14f + dy, 7f, 14f + dy);
                }
            }

            // front arm and hands
            g.DrawLine(penHeroArmDark, 5f, shoulderY, hbx, hby);
            g.DrawLine(penHeroArm, 5f, shoulderY, hbx, hby);
            using (SolidBrush skinHand = new SolidBrush(Color.FromArgb(255, 216, 172)))
            {
                g.FillEllipse(skinHand, hax - 2.4f, hay - 2.4f, 4.8f, 4.8f);
                g.FillEllipse(skinHand, hbx - 2.4f, hby - 2.4f, 4.8f, 4.8f);
            }

            if (pose == HeroPose.Dig)
            {
                float ang = (-65f + ph / 3.14159f * 135f) * 0.0174533f;
                float tx = hbx + MathF.Cos(ang) * 15f;
                float ty = hby + MathF.Sin(ang) * 15f;
                g.DrawLine(penToolHandle, hbx, hby, tx, ty);
                using (SolidBrush steel = new SolidBrush(Color.FromArgb(190, 196, 210)))
                {
                    g.FillEllipse(steel, tx - 3.5f, ty - 3f, 7f, 6f);
                    g.DrawEllipse(penThin, tx - 3.5f, ty - 3f, 7f, 6f);
                }
            }

            if (pose == HeroPose.Hurt)
            {
                using (SolidBrush gold = new SolidBrush(Color.FromArgb(255, 226, 90)))
                {
                    for (int i = 0; i < 3; i++)
                    {
                        float a = ph * 1.4f + i * 2.09f;
                        DrawStar(g, gold, MathF.Cos(a) * 11f, 1f + MathF.Sin(a) * 3f, 3f);
                    }
                }
                if ((frame / 3) % 2 == 0)
                {
                    using (SolidBrush flash = new SolidBrush(Color.FromArgb(110, 255, 40, 40)))
                    {
                        g.FillEllipse(flash, -13f, 0f, 26f, 40f);
                    }
                }
            }
            else if (pose == HeroPose.Victory)
            {
                using (SolidBrush gold = new SolidBrush(Color.FromArgb(255, 236, 110)))
                {
                    for (int i = 0; i < 3; i++)
                    {
                        float a = ph * 0.9f + i * 2.09f;
                        DrawStar(g, gold, MathF.Cos(a) * 15f, 14f + MathF.Sin(a) * 12f, 2.6f);
                    }
                }
            }
        }
        finally
        {
            g.Restore(st);
        }
    }

    private void DrawFoeSprite(Graphics g, float x, float y, float scale, int facing, FoePose pose, float ph, int frame)
    {
        GraphicsState st = g.Save();
        try
        {
            g.TranslateTransform(x + 20f * scale, y);
            float sx = pose == FoePose.Climb ? scale : scale * (facing < 0 ? -1f : 1f);
            g.ScaleTransform(sx, scale);

            float s = MathF.Sin(ph);
            float c = MathF.Cos(ph);
            float dy = 0f;
            float fax = -4f, fay = 38f, fbx = 4f, fby = 38f;

            switch (pose)
            {
                case FoePose.Walk:
                    dy = -MathF.Abs(c) * 1.2f;
                    fax = s * 7f - 2f;
                    fbx = -s * 7f + 2f;
                    fay = 38f - MathF.Max(0f, c) * 3f;
                    fby = 38f - MathF.Max(0f, -c) * 3f;
                    break;
                case FoePose.Climb:
                    fay = 38f + s * 3f;
                    fby = 38f - s * 3f;
                    break;
                case FoePose.Trapped:
                    dy = 2f + MathF.Sin(ph * 2f) * 0.6f;
                    break;
            }

            g.DrawLine(penFoeLegDark, -4f, 30f + dy, fax, fay - 2f);
            g.DrawLine(penFoeLeg, -4f, 30f + dy, fax, fay - 2f);
            g.DrawLine(penFoeLegDark, 4f, 30f + dy, fbx, fby - 2f);
            g.DrawLine(penFoeLeg, 4f, 30f + dy, fbx, fby - 2f);

            using (SolidBrush shoe = new SolidBrush(Color.FromArgb(40, 52, 120)))
            {
                g.FillEllipse(shoe, fax - 3f, fay - 3.5f, 9f, 5f);
                g.FillEllipse(shoe, fbx - 3f, fby - 3.5f, 9f, 5f);
            }

            float armA = pose == FoePose.Walk ? s * 4f : 0f;
            g.DrawLine(penFoeLegDark, -8f, 20f + dy, -12f, 26f + dy + armA);
            g.DrawLine(penFoeLeg, -8f, 20f + dy, -12f, 26f + dy + armA);
            g.DrawLine(penFoeLegDark, 8f, 20f + dy, 12f, 26f + dy - armA);
            g.DrawLine(penFoeLeg, 8f, 20f + dy, 12f, 26f + dy - armA);

            using (GraphicsPath body = RoundRect(-9.5f, 13f + dy, 19f, 18f, 6f))
            using (SolidBrush red = new SolidBrush(Color.FromArgb(214, 40, 50)))
            using (SolidBrush belly = new SolidBrush(Color.FromArgb(240, 96, 90)))
            using (SolidBrush helmet = new SolidBrush(Color.FromArgb(150, 20, 34)))
            using (SolidBrush shine = new SolidBrush(Color.FromArgb(255, 150, 140)))
            using (SolidBrush white = new SolidBrush(Color.White))
            using (SolidBrush black = new SolidBrush(Color.FromArgb(20, 16, 30)))
            {
                g.FillPath(red, body);
                g.FillEllipse(belly, -5f, 20f + dy, 10f, 8f);
                g.DrawPath(penThin, body);

                g.FillPie(helmet, -11f, 3f + dy, 22f, 20f, 180f, 180f);
                g.DrawArc(penThin, -11f, 3f + dy, 22f, 20f, 180f, 180f);
                g.FillEllipse(shine, -6f, 5.5f + dy, 6f, 3f);

                if (pose == FoePose.Climb)
                {
                    g.FillEllipse(white, -8f, 12f + dy, 7f, 8f);
                    g.FillEllipse(white, 1f, 12f + dy, 7f, 8f);
                    g.FillEllipse(black, -5.5f, 15f + dy, 3f, 4f);
                    g.FillEllipse(black, 2.5f, 15f + dy, 3f, 4f);
                }
                else if (pose == FoePose.Trapped)
                {
                    g.FillEllipse(white, -2f, 12f + dy, 10f, 9f);
                    g.DrawEllipse(penThin, 0.5f, 14.5f + dy, 5f, 4f);
                    g.DrawEllipse(penThin, 2f, 16f + dy, 2f, 1.6f);
                }
                else
                {
                    g.FillEllipse(white, -1f, 12f + dy, 10f, 9f);
                    g.FillEllipse(black, 4f, 14.5f + dy, 4f, 5f);
                    g.DrawLine(penThin, -1f, 11.5f + dy, 8f, 13.5f + dy);
                }
            }

            if (pose == FoePose.Trapped)
            {
                using (SolidBrush gold = new SolidBrush(Color.FromArgb(255, 226, 90)))
                {
                    for (int i = 0; i < 3; i++)
                    {
                        float a = ph * 1.2f + i * 2.09f;
                        DrawStar(g, gold, MathF.Cos(a) * 11f, 1f + MathF.Sin(a) * 3f, 3f);
                    }
                }
            }
        }
        finally
        {
            g.Restore(st);
        }
    }

    // ------------------------------------------------------------------ title screen and panels

    private void DrawTitle(Graphics g, GameWorld w)
    {
        int f = w.Frame;
        int areaH = Cfg.HudH + Cfg.BoardH;
        g.DrawImage(bgCave, new Rectangle(0, 0, Cfg.LogicalW, areaH));

        // ground row
        for (int c = 0; c < Cfg.Cols; c++)
        {
            g.DrawImageUnscaled(tileBrick, c * T, areaH - T);
        }
        // little gold hoard
        for (int i = 0; i < 6; i++)
        {
            g.DrawImageUnscaled(tileGold, 310 + i * 24 + (i % 2) * 6, areaH - T - 22 - (i % 3) * 3);
        }
        for (int i = 0; i < 4; i++)
        {
            g.DrawImageUnscaled(tileGold, 340 + i * 26, areaH - T - 40 - (i % 2) * 4);
        }

        DrawTorch(g, 36f, 250f, f);
        DrawTorch(g, 764f, 250f, f);

        DrawHeroSprite(g, 40f, areaH - T - 120f, 3f, 1, HeroPose.Walk, f * 0.22f, f);
        DrawFoeSprite(g, 600f, areaH - T - 80f, 2f, -1, FoePose.Walk, f * 0.2f, f);
        DrawFoeSprite(g, 676f, areaH - T - 80f, 2f, -1, FoePose.Walk, f * 0.2f + 1.5f, f);

        // title
        using (GraphicsPath gp = new GraphicsPath())
        {
            gp.AddString("LODE RUNNER", fBig.FontFamily, (int)(FontStyle.Bold | FontStyle.Italic), 86f,
                new RectangleF(0f, 22f, Cfg.LogicalW, 110f), sfCenter);
            using (Pen outline = new Pen(Color.FromArgb(70, 30, 0), 11f))
            {
                outline.LineJoin = LineJoin.Round;
                g.DrawPath(outline, gp);
            }
            using (LinearGradientBrush fill = new LinearGradientBrush(new RectangleF(0f, 30f, Cfg.LogicalW, 100f),
                Color.FromArgb(255, 244, 110), Color.FromArgb(255, 130, 20), 90f))
            {
                g.FillPath(fill, gp);
            }
        }

        // controls panel
        Rectangle panel = new Rectangle(215, 150, 370, 232);
        DrawBox(g, panel);
        string[] lines =
        {
            "ARROWS / WASD   move and climb",
            "Z / J   dig left        X / K   dig right",
            "ESC   pause        R   restart level",
            "F11   fullscreen        M   mute",
            "Collect all gold, then reach the EXIT.",
            "Trap guards in holes for +200 points.",
            "Holes close again after about 3 seconds!"
        };
        Txt(g, "HOW TO PLAY", fText, Color.FromArgb(255, 226, 110), panel.X + panel.Width / 2f, panel.Y + 22f, sfCenter, true);
        for (int i = 0; i < lines.Length; i++)
        {
            Txt(g, lines[i], fSmall, Color.FromArgb(230, 236, 250), panel.X + 16f, panel.Y + 54f + i * 24f, sfLeft, false);
        }

        if ((f / 30) % 2 == 0)
        {
            Rectangle btn = new Rectangle(240, 405, 320, 46);
            DrawBox(g, btn);
            Txt(g, "PRESS ENTER TO START GAME", fText, Color.White, btn.X + btn.Width / 2f, btn.Y + btn.Height / 2f, sfCenter, true);
        }
        else
        {
            Rectangle btn = new Rectangle(240, 405, 320, 46);
            DrawBox(g, btn);
            Txt(g, "PRESS ENTER TO START GAME", fText, Color.FromArgb(255, 226, 110), btn.X + btn.Width / 2f, btn.Y + btn.Height / 2f, sfCenter, true);
        }
    }

    private static void DrawBox(Graphics g, Rectangle r)
    {
        using (GraphicsPath path = RoundRect(r.X, r.Y, r.Width, r.Height, 8f))
        using (SolidBrush fill = new SolidBrush(Color.FromArgb(215, 10, 14, 40)))
        using (Pen border = new Pen(Color.FromArgb(214, 168, 60), 3f))
        using (Pen inner = new Pen(Color.FromArgb(120, 150, 190, 255), 1f))
        {
            g.FillPath(fill, path);
            g.DrawPath(border, path);
            g.DrawRectangle(inner, r.X + 5, r.Y + 5, r.Width - 10, r.Height - 10);
        }
    }

    private void DrawTorch(Graphics g, float x, float y, int frame)
    {
        float fl = MathF.Sin(frame * 0.3f + x) * 2f;
        using (SolidBrush glow = new SolidBrush(Color.FromArgb(34, 255, 170, 40)))
        {
            g.FillEllipse(glow, x - 46f, y - 40f, 92f, 92f);
        }
        using (SolidBrush holder = new SolidBrush(Color.FromArgb(96, 64, 40)))
        {
            g.FillRectangle(holder, x - 4f, y + 14f, 8f, 26f);
            g.FillRectangle(holder, x - 8f, y + 10f, 16f, 6f);
        }
        using (SolidBrush outer = new SolidBrush(Color.FromArgb(255, 150, 30)))
        using (SolidBrush inner = new SolidBrush(Color.FromArgb(255, 230, 110)))
        {
            g.FillEllipse(outer, x - 8f, y - 12f + fl, 16f, 26f);
            g.FillEllipse(inner, x - 4f, y - 2f + fl, 8f, 14f);
        }
    }

    private void DrawPanel(Graphics g, GameWorld w, string title, Color titleColor, string[] lines, string prompt)
    {
        using (SolidBrush dim = new SolidBrush(Color.FromArgb(150, 0, 0, 12)))
        {
            g.FillRectangle(dim, 0, 0, Cfg.LogicalW, Cfg.HudH + Cfg.BoardH);
        }
        Rectangle r = new Rectangle(130, 150, 540, 320);
        DrawBox(g, r);
        Txt(g, title, fBig, titleColor, r.X + r.Width / 2f, r.Y + 56f, sfCenter, true);
        for (int i = 0; i < lines.Length; i++)
        {
            Txt(g, lines[i], fMid, Color.FromArgb(235, 240, 255), r.X + r.Width / 2f, r.Y + 122f + i * 40f, sfCenter, true);
        }
        Color pc = ((w.Frame / 30) % 2 == 0) ? Color.White : Color.FromArgb(255, 226, 110);
        Txt(g, prompt, fText, pc, r.X + r.Width / 2f, r.Y + r.Height - 36f, sfCenter, true);
    }

    private void DrawFooter(Graphics g)
    {
        Rectangle r = new Rectangle(0, Cfg.LogicalH - Cfg.FooterH, Cfg.LogicalW, Cfg.FooterH);
        using (SolidBrush bg = new SolidBrush(Color.FromArgb(10, 12, 24)))
        {
            g.FillRectangle(bg, r);
        }
        using (Pen line = new Pen(Color.FromArgb(214, 168, 60), 2f))
        {
            g.DrawLine(line, 0, r.Y + 1, Cfg.LogicalW, r.Y + 1);
        }
        using (SolidBrush tb = new SolidBrush(Color.FromArgb(255, 232, 160)))
        {
            g.DrawString(FooterText, fFooter, tb, new RectangleF(0f, r.Y + 3f, Cfg.LogicalW, r.Height - 3f), sfCenter);
        }
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private static Bitmap MakeCave()
    {
        int W = Cfg.LogicalW;
        int H = Cfg.BoardH;
        Bitmap bmp = new Bitmap(W, H, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush lg = new LinearGradientBrush(new Rectangle(0, 0, W, H), Color.FromArgb(14, 22, 52), Color.FromArgb(30, 24, 44), 90f))
            {
                g.FillRectangle(lg, 0, 0, W, H);
            }
            using (Pen mortar = new Pen(Color.FromArgb(26, 130, 150, 220), 1f))
            {
                for (int y = 0; y < H; y += 20)
                {
                    g.DrawLine(mortar, 0, y, W, y);
                    int off = ((y / 20) % 2) * 20;
                    for (int x = off; x < W; x += 40)
                    {
                        g.DrawLine(mortar, x, y, x, y + 20);
                    }
                }
            }
            using (SolidBrush glow = new SolidBrush(Color.FromArgb(16, 90, 150, 255)))
            {
                g.FillEllipse(glow, W / 2f - 280f, H / 2f - 190f, 560f, 380f);
                g.FillEllipse(glow, W / 2f - 190f, H / 2f - 130f, 380f, 260f);
                g.FillEllipse(glow, W / 2f - 100f, H / 2f - 70f, 200f, 140f);
            }
            Random rnd = new Random(7);
            using (SolidBrush rock = new SolidBrush(Color.FromArgb(120, 6, 8, 18)))
            {
                for (int x = 0; x < W; x += 40)
                {
                    int h = 14 + rnd.Next(34);
                    PointF[] tri = { new PointF(x, 0f), new PointF(x + 40f, 0f), new PointF(x + 12f + rnd.Next(16), h) };
                    g.FillPolygon(rock, tri);
                }
            }
            using (LinearGradientBrush shade = new LinearGradientBrush(new Rectangle(0, 0, W, H), Color.FromArgb(0, 0, 0, 0), Color.FromArgb(110, 0, 0, 0), 0f))
            {
                ColorBlend cb = new ColorBlend(3);
                cb.Colors = new[] { Color.FromArgb(120, 0, 0, 10), Color.FromArgb(0, 0, 0, 0), Color.FromArgb(120, 0, 0, 10) };
                cb.Positions = new[] { 0f, 0.5f, 1f };
                shade.InterpolationColors = cb;
                g.FillRectangle(shade, 0, 0, W, H);
            }
        }
        return bmp;
    }

    private static void BrickRect(Graphics g, Rectangle r, Random rnd)
    {
        int d = rnd.Next(-12, 13);
        Color baseColor = Color.FromArgb(Clamp(158 + d), Clamp(100 + d / 2), Clamp(64 + d / 3));
        using (SolidBrush b = new SolidBrush(baseColor))
        using (Pen light = new Pen(Color.FromArgb(208, 150, 104), 1f))
        using (Pen dark = new Pen(Color.FromArgb(96, 58, 36), 1f))
        {
            g.FillRectangle(b, r);
            g.DrawLine(light, r.Left, r.Top, r.Right - 1, r.Top);
            g.DrawLine(light, r.Left, r.Top, r.Left, r.Bottom - 1);
            g.DrawLine(dark, r.Left, r.Bottom - 1, r.Right - 1, r.Bottom - 1);
            g.DrawLine(dark, r.Right - 1, r.Top, r.Right - 1, r.Bottom - 1);
        }
    }

    private static int Clamp(int v)
    {
        return Math.Max(0, Math.Min(255, v));
    }

    private static Bitmap MakeBrick()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.None;
            Random rnd = new Random(11);
            using (SolidBrush mortar = new SolidBrush(Color.FromArgb(52, 32, 24)))
            {
                g.FillRectangle(mortar, 0, 0, T, T);
            }
            for (int row = 0; row < 2; row++)
            {
                int y = row * 20;
                int off = row == 0 ? 0 : -10;
                for (int bx = off; bx < T; bx += 20)
                {
                    int x0 = Math.Max(bx + 1, 0);
                    int x1 = Math.Min(bx + 19, T);
                    if (x1 <= x0) continue;
                    BrickRect(g, new Rectangle(x0, y + 1, x1 - x0, 18), rnd);
                }
            }
            using (SolidBrush top = new SolidBrush(Color.FromArgb(70, 255, 232, 190)))
            {
                g.FillRectangle(top, 0, 0, T, 2);
            }
        }
        return bmp;
    }

    private static Bitmap MakeSolid()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush fill = new LinearGradientBrush(new Rectangle(0, 0, T, T), Color.FromArgb(94, 106, 134), Color.FromArgb(52, 60, 82), 90f))
            {
                g.FillRectangle(fill, 0, 0, T, T);
            }
            using (Pen dark = new Pen(Color.FromArgb(24, 28, 44), 2f))
            using (Pen light = new Pen(Color.FromArgb(150, 166, 200), 1f))
            using (Pen seam = new Pen(Color.FromArgb(34, 40, 60), 1f))
            {
                g.DrawRectangle(dark, 1, 1, T - 2, T - 2);
                g.DrawLine(light, 3, 3, T - 4, 3);
                g.DrawLine(light, 3, 3, 3, T - 4);
                g.DrawRectangle(seam, 8, 8, T - 17, T - 17);
            }
            using (SolidBrush rivet = new SolidBrush(Color.FromArgb(188, 200, 224)))
            using (SolidBrush rivetDark = new SolidBrush(Color.FromArgb(30, 34, 52)))
            {
                float[] pos = { 5f, T - 9f };
                foreach (float px in pos)
                {
                    foreach (float py in pos)
                    {
                        g.FillEllipse(rivetDark, px - 0.5f, py - 0.5f, 5f, 5f);
                        g.FillEllipse(rivet, px, py, 3.6f, 3.6f);
                    }
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeLadder()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.None;
            using (Pen outline = new Pen(Color.FromArgb(28, 34, 52), 1f))
            {
                int[] rungs = { 3, 13, 23, 33 };
                foreach (int ry in rungs)
                {
                    Rectangle rr = new Rectangle(12, ry, 16, 4);
                    using (LinearGradientBrush lg = new LinearGradientBrush(rr, Color.FromArgb(214, 222, 238), Color.FromArgb(112, 124, 150), 90f))
                    {
                        g.FillRectangle(lg, rr);
                    }
                    g.DrawRectangle(outline, rr.X, rr.Y, rr.Width - 1, rr.Height - 1);
                }
                int[] rails = { 8, 28 };
                foreach (int rx in rails)
                {
                    Rectangle rr = new Rectangle(rx, 0, 5, T);
                    using (LinearGradientBrush lg = new LinearGradientBrush(rr, Color.FromArgb(226, 232, 246), Color.FromArgb(96, 108, 134), 0f))
                    {
                        g.FillRectangle(lg, rr);
                    }
                    g.DrawLine(outline, rx, 0, rx, T);
                    g.DrawLine(outline, rx + 4, 0, rx + 4, T);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeRope()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.None;
            using (Pen dark = new Pen(Color.FromArgb(60, 38, 18), 5f))
            using (Pen mid = new Pen(Color.FromArgb(178, 134, 80), 3f))
            using (Pen twist = new Pen(Color.FromArgb(226, 190, 126), 1f))
            {
                g.DrawLine(dark, 0, 8, T, 8);
                g.DrawLine(mid, 0, 8, T, 8);
                for (int x = -4; x < T; x += 5)
                {
                    g.DrawLine(twist, x, 10, x + 4, 6);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeGold()
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (SolidBrush shadow = new SolidBrush(Color.FromArgb(70, 0, 0, 0)))
            {
                g.FillEllipse(shadow, 5f, 33f, 30f, 6f);
            }
            PointF[] front = { new PointF(6f, 35f), new PointF(34f, 35f), new PointF(31f, 25f), new PointF(9f, 25f) };
            PointF[] top = { new PointF(9f, 25f), new PointF(31f, 25f), new PointF(28f, 19f), new PointF(12f, 19f) };
            using (SolidBrush fb = new SolidBrush(Color.FromArgb(238, 172, 26)))
            using (SolidBrush tb = new SolidBrush(Color.FromArgb(255, 238, 140)))
            using (Pen edge = new Pen(Color.FromArgb(112, 66, 0), 1.6f))
            using (Pen sheen = new Pen(Color.FromArgb(200, 255, 250, 210), 1.6f))
            using (Pen groove = new Pen(Color.FromArgb(150, 176, 108, 8), 1.2f))
            {
                g.FillPolygon(fb, front);
                g.FillPolygon(tb, top);
                g.DrawPolygon(edge, front);
                g.DrawPolygon(edge, top);
                g.DrawLine(sheen, 11f, 28f, 27f, 28f);
                g.DrawLine(groove, 9f, 32f, 31f, 32f);
            }
        }
        return bmp;
    }

    private static Bitmap MakeExit(bool open)
    {
        Bitmap bmp = new Bitmap(T, T, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (GraphicsPath frame = new GraphicsPath())
            using (GraphicsPath inner = new GraphicsPath())
            {
                frame.AddArc(5f, 2f, 30f, 20f, 180f, 180f);
                frame.AddLine(35f, 12f, 35f, 40f);
                frame.AddLine(35f, 40f, 5f, 40f);
                frame.CloseFigure();
                inner.AddArc(9f, 6f, 22f, 16f, 180f, 180f);
                inner.AddLine(31f, 14f, 31f, 40f);
                inner.AddLine(31f, 40f, 9f, 40f);
                inner.CloseFigure();

                using (SolidBrush fb = new SolidBrush(Color.FromArgb(70, 62, 86)))
                using (Pen fp = new Pen(Color.FromArgb(20, 18, 34), 2f))
                {
                    g.FillPath(fb, frame);
                    g.DrawPath(fp, frame);
                }

                if (open)
                {
                    using (LinearGradientBrush lg = new LinearGradientBrush(new Rectangle(9, 6, 22, 34), Color.FromArgb(255, 248, 180), Color.FromArgb(255, 176, 40), 90f))
                    using (Font tf = new Font("Arial", 8f, FontStyle.Bold, GraphicsUnit.Pixel))
                    using (StringFormat sf = new StringFormat())
                    using (SolidBrush tb = new SolidBrush(Color.FromArgb(120, 56, 0)))
                    {
                        g.FillPath(lg, inner);
                        sf.Alignment = StringAlignment.Center;
                        sf.LineAlignment = StringAlignment.Center;
                        g.DrawString("EXIT", tf, tb, new RectangleF(9f, 16f, 22f, 12f), sf);
                    }
                }
                else
                {
                    using (SolidBrush ib = new SolidBrush(Color.FromArgb(54, 60, 78)))
                    using (Pen lines = new Pen(Color.FromArgb(34, 38, 52), 1f))
                    using (SolidBrush lockBody = new SolidBrush(Color.FromArgb(226, 172, 40)))
                    using (Pen lockEdge = new Pen(Color.FromArgb(90, 52, 0), 1f))
                    using (Pen shackle = new Pen(Color.FromArgb(205, 205, 218), 2f))
                    {
                        g.FillPath(ib, inner);
                        g.DrawLine(lines, 20, 8, 20, 40);
                        g.DrawLine(lines, 9, 20, 31, 20);
                        g.DrawArc(shackle, 16f, 17f, 8f, 10f, 180f, 180f);
                        g.FillRectangle(lockBody, 14, 23, 12, 10);
                        g.DrawRectangle(lockEdge, 14, 23, 12, 10);
                    }
                }
            }
        }
        return bmp;
    }
}
