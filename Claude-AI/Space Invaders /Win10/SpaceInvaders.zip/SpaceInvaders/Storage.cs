using System;
using System.IO;

namespace SpaceInvaders
{
    /// <summary>Hi-score persistence: one integer in %LocalAppData%\SpaceInvaders\highscore.txt.</summary>
    internal static class HighScoreStore
    {
        private static readonly string FilePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SpaceInvaders", "highscore.txt");

        public static int Load()
        {
            try
            {
                int v;
                if (File.Exists(FilePath) && int.TryParse(File.ReadAllText(FilePath).Trim(), out v) && v > 0)
                    return v;
            }
            catch { /* missing or broken file -> 0 */ }
            return 0;
        }

        public static void Save(int value)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
                File.WriteAllText(FilePath, value.ToString());
            }
            catch { /* ignore */ }
        }
    }
}
