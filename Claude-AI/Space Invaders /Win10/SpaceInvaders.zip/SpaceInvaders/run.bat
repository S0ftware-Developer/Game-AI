@echo off
rem Quick developer run (needs the .NET 8 SDK or Desktop Runtime installed).
cd /d "%~dp0"
dotnet run -c Release
