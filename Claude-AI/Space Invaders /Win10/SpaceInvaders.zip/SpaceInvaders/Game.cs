using System;
using System.Collections.Generic;
using System.Drawing;

namespace SpaceInvaders
{
    internal enum Phase { Menu, Playing, Paused, ConfirmMenu, GameOver, Victory }

    internal sealed class Alien { public int Row, Col; public bool Alive = true; }

    internal sealed class Shot { public float X, Y, VY; public bool Dead; }

    /// <summary>An alien that broke away from the formation and zigzags towards the planet.</summary>
    internal sealed class Diver
    {
        public float X, Y, VX, VY;
        public bool Dead;
        public float TrailTimer;
        public readonly List<PointF> Trail = new List<PointF>();
    }

    internal sealed class Particle
    {
        public float X, Y, VX, VY, Life, MaxLife;
        public int Size;
        public Color Color;
    }

    /// <summary>
    /// Pure game logic (no drawing). Coordinates are playfield-local: 0..PW x 0..PH.
    /// </summary>
    internal sealed class Game
    {
        // ---------- Geometry ----------
        public const int PW = 704, PH = 700;
        public const int Cols = 9, Rows = 5;
        public const int AlienW = 33, AlienH = 24, CellW = 62, CellH = 48;
        public const int PlayerW = 39, PlayerH = 36;
        public const float PlayerTop = PH - 92;
        public const float InvasionY = PH - 115;

        // ---------- Tuning (all difficulty knobs live here) ----------
        public const int MaxLevel = 5;
        public const int MaxPlanetHp = 5;
        public const int StartLives = 3;
        private const float PlayerSpeed = 340f;
        private const float PlayerShotSpeed = 640f;
        private const float FireInterval = 0.25f;
        private const int MaxPlayerShots = 3;
        private const int PointsAlien = 10;
        private const int PointsDiver = 25;
        private const float InvulnTime = 2.2f;
        private const float EdgeMargin = 8f;
        private const float DropStep = 20f;

        /// <summary>Planet surface height at playfield x (gentle curve, higher in the middle).</summary>
        public static float SurfaceY(float x)
        {
            float d = x - PW / 2f;
            return PH - 70 + 0.0004f * d * d;
        }

        // ---------- Public state read by the renderer ----------
        public Phase Phase = Phase.Menu;
        public int Score, HiScore, Level = 1, Lives = StartLives, PlanetHp = MaxPlanetHp;
        public float PlayerX = PW / 2f;
        public float Invuln, MuzzleFlash, BannerTimer, Time, FormX, FormY;
        public int AnimFrame;
        public readonly List<Alien> Aliens = new List<Alien>();
        public readonly List<Diver> Divers = new List<Diver>();
        public readonly List<Shot> PlayerShots = new List<Shot>();
        public readonly List<Shot> EnemyShots = new List<Shot>();
        public readonly List<Particle> Particles = new List<Particle>();
        public readonly List<float> CrashXs = new List<float>();

        // ---------- Input (set by the window) ----------
        public int MoveDir;
        public bool FireHeld;
        private bool firePending;

        public Action<string> Sound;

        private readonly Random rng = new Random();
        private int dir = 1;
        private float animPhase, fireCooldown, enemyFireTimer, diveTimer, endTimer, fireworkTimer;
        private Phase confirmFrom = Phase.Playing;

        public Game()
        {
            HiScore = HighScoreStore.Load();
        }

        public int AliensAlive
        {
            get { int n = 0; foreach (var a in Aliens) if (a.Alive) n++; return n; }
        }

        public bool CanRestart { get { return endTimer <= 0f; } }

        public void QueueFire() { firePending = true; }

        // =====================================================================
        //  Flow control
        // =====================================================================
        public void NewGame()
        {
            Score = 0; Level = 1; Lives = StartLives; PlanetHp = MaxPlanetHp;
            PlayerX = PW / 2f; Invuln = 0; MuzzleFlash = 0; BannerTimer = 0; Time = 0;
            fireCooldown = 0; firePending = false; endTimer = 0;
            PlayerShots.Clear(); EnemyShots.Clear(); Divers.Clear(); Particles.Clear(); CrashXs.Clear();
            SpawnFormation();
            Phase = Phase.Playing;
        }

        public void GoMenu()
        {
            SaveHi();
            Phase = Phase.Menu;
        }

        public void TogglePause()
        {
            if (Phase == Phase.Playing) Phase = Phase.Paused;
            else if (Phase == Phase.Paused) Phase = Phase.Playing;
        }

        public void RequestMenu()
        {
            if (Phase == Phase.Playing || Phase == Phase.Paused)
            {
                confirmFrom = Phase;
                Phase = Phase.ConfirmMenu;
            }
        }

        public void ConfirmMenuYes() { if (Phase == Phase.ConfirmMenu) GoMenu(); }
        public void ConfirmMenuNo() { if (Phase == Phase.ConfirmMenu) Phase = confirmFrom; }

        public void SaveHi()
        {
            if (Score > HiScore) HiScore = Score;
            HighScoreStore.Save(HiScore);
        }

        private void EndGame(bool win)
        {
            if (Phase != Phase.Playing) return;   // victory and defeat can never both happen
            Phase = win ? Phase.Victory : Phase.GameOver;
            endTimer = 0.8f;                       // protects against accidental instant restart
            fireworkTimer = 0f;
            SaveHi();
            Sound?.Invoke(win ? "win" : "lose");
        }

        private void SpawnFormation()
        {
            Aliens.Clear();
            for (int r = 0; r < Rows; r++)
                for (int c = 0; c < Cols; c++)
                    Aliens.Add(new Alien { Row = r, Col = c });
            FormX = (PW - ((Cols - 1) * CellW + AlienW)) / 2f;
            FormY = 60 + (Level - 1) * 14;
            dir = 1;
            animPhase = 0;
            enemyFireTimer = 1.2f;
            diveTimer = 4f;
            EnemyShots.Clear();
        }

        // =====================================================================
        //  Update
        // =====================================================================
        public void Update(float dt)
        {
            switch (Phase)
            {
                case Phase.Playing:
                    UpdatePlaying(dt);
                    break;
                case Phase.GameOver:
                case Phase.Victory:
                    if (endTimer > 0f) endTimer -= dt;
                    UpdateParticles(dt);
                    if (Phase == Phase.Victory)
                    {
                        fireworkTimer -= dt;
                        if (fireworkTimer <= 0f)
                        {
                            fireworkTimer = 0.35f;
                            Color[] pal = { Color.Cyan, Color.Yellow, Color.Lime, Color.Orange, Color.Magenta };
                            Explode(80 + rng.Next(PW - 160), 80 + rng.Next(280), pal[rng.Next(pal.Length)], 30);
                        }
                    }
                    break;
            }
        }

        private void UpdatePlaying(float dt)
        {
            Time += dt;
            UpdateParticles(dt);
            if (Invuln > 0) Invuln -= dt;
            if (MuzzleFlash > 0) MuzzleFlash -= dt;

            // player
            PlayerX += MoveDir * PlayerSpeed * dt;
            PlayerX = Math.Max(PlayerW / 2f + 4, Math.Min(PW - PlayerW / 2f - 4, PlayerX));
            HandleFire(dt);
            MoveShots(PlayerShots, dt);

            // between waves only the player and the particles stay active
            if (BannerTimer > 0)
            {
                BannerTimer -= dt;
                if (BannerTimer <= 0) { Level++; SpawnFormation(); }
                return;
            }

            MoveFormation(dt);
            UpdateEnemyFire(dt);
            UpdateDivers(dt);
            MoveShots(EnemyShots, dt);
            ResolvePlayerShots();
            ResolveEnemyShots();

            if (Lives <= 0 || PlanetHp <= 0 || InvasionReached())
            {
                EndGame(false);
                return;
            }

            if (AliensAlive == 0 && Divers.Count == 0)
            {
                EnemyShots.Clear();
                if (Level >= MaxLevel) EndGame(true);
                else BannerTimer = 2.2f;
            }
        }

        private void HandleFire(float dt)
        {
            fireCooldown -= dt;
            if ((firePending || FireHeld) && fireCooldown <= 0f && PlayerShots.Count < MaxPlayerShots)
            {
                PlayerShots.Add(new Shot { X = PlayerX, Y = PlayerTop - 4, VY = -PlayerShotSpeed });
                fireCooldown = FireInterval;
                MuzzleFlash = 0.08f;
                Sound?.Invoke("shoot");
            }
            firePending = false;
        }

        private static void MoveShots(List<Shot> shots, float dt)
        {
            foreach (var s in shots)
            {
                s.Y += s.VY * dt;
                if (s.Y < -30 || s.Y > PH + 30) s.Dead = true;
            }
            shots.RemoveAll(s => s.Dead);
        }

        // ---------- Formation ----------
        private float FormSpeed()
        {
            float baseSpeed = 34f + 9f * (Level - 1);
            float frac = 1f - AliensAlive / (float)(Rows * Cols);
            return baseSpeed * (1f + 2.2f * frac);
        }

        private void MoveFormation(float dt)
        {
            int minCol = int.MaxValue, maxCol = -1;
            foreach (var a in Aliens)
            {
                if (!a.Alive) continue;
                if (a.Col < minCol) minCol = a.Col;
                if (a.Col > maxCol) maxCol = a.Col;
            }
            if (maxCol < 0) return;

            float speed = FormSpeed();
            animPhase += speed * dt / 14f;
            AnimFrame = ((int)animPhase) & 1;

            float left = FormX + minCol * CellW;
            float right = FormX + maxCol * CellW + AlienW;
            float dx = dir * speed * dt;

            if (dir > 0 && right + dx >= PW - EdgeMargin)
            {
                FormX += (PW - EdgeMargin) - right;   // clamp: never sticks to the wall
                dir = -1;
                FormY += DropStep;
            }
            else if (dir < 0 && left + dx <= EdgeMargin)
            {
                FormX += EdgeMargin - left;
                dir = 1;
                FormY += DropStep;
            }
            else FormX += dx;
        }

        private RectangleF AlienRect(Alien a)
        {
            return new RectangleF(FormX + a.Col * CellW, FormY + a.Row * CellH, AlienW, AlienH);
        }

        private bool InvasionReached()
        {
            foreach (var a in Aliens)
                if (a.Alive && AlienRect(a).Bottom >= InvasionY) return true;
            return false;
        }

        // ---------- Enemy fire ----------
        private void UpdateEnemyFire(float dt)
        {
            enemyFireTimer -= dt;
            if (enemyFireTimer > 0f) return;

            float interval = Math.Max(0.45f, 1.5f - 0.18f * (Level - 1));
            enemyFireTimer = interval * (0.6f + 0.8f * (float)rng.NextDouble());
            if (EnemyShots.Count >= 3 + Level) return;

            var cols = new List<int>();
            foreach (var a in Aliens) if (a.Alive && !cols.Contains(a.Col)) cols.Add(a.Col);
            if (cols.Count == 0) return;

            int col = cols[rng.Next(cols.Count)];
            Alien shooter = null;
            foreach (var a in Aliens)
                if (a.Alive && a.Col == col && (shooter == null || a.Row > shooter.Row)) shooter = a;
            if (shooter == null) return;

            var r = AlienRect(shooter);
            EnemyShots.Add(new Shot { X = r.X + r.Width / 2f, Y = r.Bottom, VY = 240f + 25f * Level });
        }

        // ---------- Breakaway aliens ----------
        private void UpdateDivers(float dt)
        {
            diveTimer -= dt;
            if (diveTimer <= 0f)
            {
                diveTimer = Math.Max(3.5f, 5f + 4f * (float)rng.NextDouble() - 0.6f * (Level - 1));
                TrySpawnDivers();
            }

            float speed = 120f + 12f * (Level - 1);
            foreach (var d in Divers)
            {
                d.X += d.VX * dt;
                d.Y += d.VY * dt;

                // bounce off the side walls while continuing to descend (zigzag)
                if (d.X < AlienW / 2f) { d.X = AlienW / 2f; d.VX = speed; }
                else if (d.X > PW - AlienW / 2f) { d.X = PW - AlienW / 2f; d.VX = -speed; }

                d.TrailTimer -= dt;
                if (d.TrailTimer <= 0f)
                {
                    d.TrailTimer = 0.03f;
                    d.Trail.Add(new PointF(d.X, d.Y));
                    if (d.Trail.Count > 10) d.Trail.RemoveAt(0);
                }

                if (!d.Dead && d.Y + AlienH / 2f >= SurfaceY(d.X))
                {
                    d.Dead = true;                       // removed below: can only crash once
                    PlanetHp--;
                    CrashXs.Add(d.X);
                    Explode(d.X, SurfaceY(d.X), Color.OrangeRed, 40);
                    Explode(d.X, SurfaceY(d.X), Color.Yellow, 15);
                    Sound?.Invoke("crash");
                }
            }
            Divers.RemoveAll(d => d.Dead);
        }

        private void TrySpawnDivers()
        {
            int free = 2 - Divers.Count;               // never more than two at once
            if (free <= 0 || AliensAlive <= 2) return;
            int want = Math.Min(free, rng.Next(1, 3));
            float speed = 120f + 12f * (Level - 1);

            for (int i = 0; i < want; i++)
            {
                var alive = new List<Alien>();
                foreach (var a in Aliens) if (a.Alive) alive.Add(a);
                if (alive.Count <= 2) break;
                var pick = alive[rng.Next(alive.Count)];
                pick.Alive = false;
                var r = AlienRect(pick);
                Divers.Add(new Diver
                {
                    X = r.X + r.Width / 2f,
                    Y = r.Y + r.Height / 2f,
                    VX = rng.Next(2) == 0 ? -speed : speed,
                    VY = speed                           // |vx| == |vy| -> 45 degrees
                });
            }
            Sound?.Invoke("dive");
        }

        // ---------- Collisions ----------
        private void AddScore(int n)
        {
            Score += n;
            if (Score > HiScore) HiScore = Score;
        }

        private void ResolvePlayerShots()
        {
            foreach (var s in PlayerShots)
            {
                if (s.Dead) continue;
                var sr = new RectangleF(s.X - 2, s.Y - 9, 4, 18);

                foreach (var d in Divers)
                {
                    if (d.Dead) continue;
                    var dr = new RectangleF(d.X - AlienW / 2f, d.Y - AlienH / 2f, AlienW, AlienH);
                    if (sr.IntersectsWith(dr))
                    {
                        d.Dead = true; s.Dead = true;
                        AddScore(PointsDiver);
                        Explode(d.X, d.Y, Color.Magenta, 24);
                        Sound?.Invoke("boom");
                        break;
                    }
                }
                if (s.Dead) continue;

                foreach (var a in Aliens)
                {
                    if (!a.Alive) continue;
                    var ar = AlienRect(a);
                    if (sr.IntersectsWith(ar))
                    {
                        a.Alive = false; s.Dead = true;   // one bullet kills exactly one alien
                        AddScore(PointsAlien);
                        Explode(ar.X + ar.Width / 2f, ar.Y + ar.Height / 2f, RowColor(a.Row), 18);
                        Sound?.Invoke("boom");
                        break;
                    }
                }
            }
            PlayerShots.RemoveAll(s => s.Dead);
            Divers.RemoveAll(d => d.Dead);
        }

        public static Color RowColor(int row)
        {
            Color[] c =
            {
                Color.FromArgb(60, 255, 60), Color.FromArgb(255, 215, 30), Color.FromArgb(255, 140, 20),
                Color.FromArgb(255, 50, 40), Color.FromArgb(180, 70, 255)
            };
            return c[row % c.Length];
        }

        private void ResolveEnemyShots()
        {
            var pr = new RectangleF(PlayerX - PlayerW / 2f + 5, PlayerTop + 4, PlayerW - 10, PlayerH - 6);
            foreach (var s in EnemyShots)
            {
                if (s.Dead) continue;
                var sr = new RectangleF(s.X - 3, s.Y - 8, 6, 16);
                if (Invuln <= 0f && sr.IntersectsWith(pr))
                {
                    s.Dead = true;
                    Lives--;
                    Invuln = InvulnTime;
                    Explode(PlayerX, PlayerTop + PlayerH / 2f, Color.Cyan, 30);
                    Sound?.Invoke("hurt");
                }
            }
            EnemyShots.RemoveAll(s => s.Dead);
        }

        // ---------- Particles ----------
        private void Explode(float x, float y, Color c, int count)
        {
            for (int i = 0; i < count && Particles.Count < 500; i++)
            {
                double ang = rng.NextDouble() * Math.PI * 2;
                float sp = 40f + (float)rng.NextDouble() * 170f;
                float life = 0.4f + (float)rng.NextDouble() * 0.5f;
                Particles.Add(new Particle
                {
                    X = x, Y = y,
                    VX = (float)Math.Cos(ang) * sp, VY = (float)Math.Sin(ang) * sp,
                    Life = life, MaxLife = life, Size = 3 + rng.Next(3), Color = c
                });
            }
        }

        private void UpdateParticles(float dt)
        {
            foreach (var p in Particles)
            {
                p.X += p.VX * dt;
                p.Y += p.VY * dt;
                p.Life -= dt;
            }
            Particles.RemoveAll(p => p.Life <= 0f);
        }
    }
}
