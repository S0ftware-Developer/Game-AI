using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace SpaceInvaders
{
    /// <summary>
    /// Draws one frame of the game into a 960x720 logical bitmap. Reads game state only;
    /// never changes gameplay.
    /// </summary>
    internal sealed class Renderer
    {
        public const int LW = 960, LH = 720;
        public static readonly Rectangle PF = new Rectangle(246, 10, Game.PW, Game.PH);

        // Clickable areas (logical coordinates)
        public static readonly Rectangle BtnStart = new Rectangle(468, 420, 260, 50);
        public static readonly Rectangle BtnMenuSound = new Rectangle(488, 486, 220, 36);
        public static readonly Rectangle BtnSound = new Rectangle(256, 20, 150, 24);
        public static readonly Rectangle BtnRestart = new Rectangle(398, 440, 190, 46);
        public static readonly Rectangle BtnToMenu = new Rectangle(608, 440, 190, 46);

        private static readonly Color Cyan = Color.FromArgb(80, 224, 255);
        private static readonly Color Yellow = Color.FromArgb(255, 204, 30);
        private static readonly Color Green = Color.FromArgb(90, 255, 90);
        private static readonly Color Orange = Color.FromArgb(255, 150, 20);
        private static readonly Color Brown = Color.FromArgb(110, 40, 0);
        private static readonly Color Navy = Color.FromArgb(6, 16, 50);
        private static readonly Color DiverColor = Color.FromArgb(255, 90, 215);

        private sealed class Star { public float X, Y, Speed, Phase; public int Size; public Color C; }

        private readonly List<Star> stars = new List<Star>();
        private readonly Random rng = new Random(5);
        private readonly Bitmap bgPlay;
        private float anim;

        private readonly Font f12 = MakeFont(12), f16 = MakeFont(16), f18 = MakeFont(18), f20 = MakeFont(20),
            f28 = MakeFont(28), f32 = MakeFont(32), f36 = MakeFont(36), f40 = MakeFont(40),
            f56 = MakeFont(56), f72 = MakeFont(72);
        private readonly StringFormat sf = new StringFormat(StringFormatFlags.NoWrap);
        private readonly SolidBrush tmp = new SolidBrush(Color.White);

        private static Font MakeFont(float px)
        {
            return new Font("Consolas", px, FontStyle.Bold, GraphicsUnit.Pixel);
        }

        public Renderer()
        {
            for (int i = 0; i < 140; i++)
            {
                Color[] pal = { Color.White, Color.FromArgb(160, 220, 255), Color.FromArgb(255, 240, 180) };
                stars.Add(new Star
                {
                    X = rng.Next(Game.PW), Y = rng.Next(Game.PH),
                    Speed = 6 + rng.Next(14), Phase = (float)(rng.NextDouble() * 6.28),
                    Size = rng.Next(5) == 0 ? 3 : 2, C = pal[rng.Next(pal.Length)]
                });
            }
            bgPlay = BuildBackground();
        }

        /// <summary>Advance purely visual animation (stars, twinkle).</summary>
        public void Tick(float dt)
        {
            anim += dt;
            foreach (var s in stars)
            {
                s.Y += s.Speed * dt;
                if (s.Y > Game.PH) { s.Y = 0; s.X = rng.Next(Game.PW); }
            }
        }

        // =====================================================================
        //  Pre-baked background: space, nebulae, planets, Earth
        // =====================================================================
        private Bitmap BuildBackground()
        {
            var bmp = new Bitmap(Game.PW, Game.PH, PixelFormat.Format32bppPArgb);
            using (var g = Graphics.FromImage(bmp))
            {
                var rect = new Rectangle(0, 0, Game.PW, Game.PH);
                using (var br = new LinearGradientBrush(rect, Color.FromArgb(2, 4, 16), Color.FromArgb(6, 12, 46), 90f))
                    g.FillRectangle(br, rect);

                Nebula(g, 140, 520, 230, Color.FromArgb(160, 60, 230), 80);
                Nebula(g, 560, 500, 260, Color.FromArgb(90, 50, 220), 70);
                Nebula(g, 360, 280, 220, Color.FromArgb(30, 70, 220), 45);
                Nebula(g, 600, 200, 160, Color.FromArgb(120, 40, 200), 35);

                Planet(g, 6, 330, 46, Color.FromArgb(70, 120, 210), Color.FromArgb(8, 14, 40));
                Planet(g, Game.PW - 6, 470, 112, Color.FromArgb(90, 130, 200), Color.FromArgb(10, 16, 44));

                BuildEarth(g);
            }
            return bmp;
        }

        private static void Nebula(Graphics g, float cx, float cy, float r, Color c, int alpha)
        {
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(cx - r, cy - r * 0.7f, r * 2, r * 1.4f);
                using (var pb = new PathGradientBrush(path))
                {
                    pb.CenterColor = Color.FromArgb(alpha, c);
                    pb.SurroundColors = new[] { Color.FromArgb(0, c) };
                    g.FillPath(pb, path);
                }
            }
        }

        private void Planet(Graphics g, float cx, float cy, float r, Color lit, Color dark)
        {
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(cx - r, cy - r, r * 2, r * 2);
                using (var pb = new PathGradientBrush(path))
                {
                    pb.CenterPoint = new PointF(cx - r * 0.45f, cy - r * 0.3f);
                    pb.CenterColor = lit;
                    pb.SurroundColors = new[] { dark };
                    g.FillPath(pb, path);
                }
                using (var rim = new Pen(Color.FromArgb(120, 120, 200, 255), 2))
                    g.DrawEllipse(rim, cx - r, cy - r, r * 2, r * 2);
                var rr = new Random((int)r);
                for (int i = 0; i < 10; i++)
                {
                    float a = (float)(rr.NextDouble() * 6.28), d = (float)(rr.NextDouble() * r * 0.8);
                    float px = cx + (float)Math.Cos(a) * d, py = cy + (float)Math.Sin(a) * d;
                    float cr = 4 + rr.Next((int)(r / 6));
                    using (var cb = new SolidBrush(Color.FromArgb(50, 0, 0, 20)))
                        g.FillEllipse(cb, px - cr, py - cr, cr * 2, cr * 2);
                }
            }
        }

        private void BuildEarth(Graphics g)
        {
            const int B = 6;
            var r = new Random(11);
            for (int y = 0; y < Game.PH; y += B)
            {
                for (int x = 0; x < Game.PW; x += B)
                {
                    float sy = Game.SurfaceY(x + B / 2f);
                    if (y + B / 2f < sy) continue;
                    float depth = Math.Min(1f, (y - sy) / 90f);
                    Color c = Sprites.Blend(Color.FromArgb(40, 120, 225), Color.FromArgb(6, 18, 60), depth);
                    int n = r.Next(100);
                    if (n < 16) c = Sprites.Blend(c, Color.FromArgb(20, 90, 80), 0.6f);
                    else if (n < 28) c = Sprites.Blend(c, Color.White, 0.12f);
                    if (depth > 0.25f && n > 96) c = Color.FromArgb(255, 190, 80);
                    using (var b = new SolidBrush(c)) g.FillRectangle(b, x, y, B, B);
                }
            }

            var pts = new List<PointF>();
            for (int x = 0; x <= Game.PW; x += 4) pts.Add(new PointF(x, Game.SurfaceY(x)));
            var arr = pts.ToArray();
            using (var p1 = new Pen(Color.FromArgb(50, 0, 140, 255), 12)) g.DrawLines(p1, arr);
            using (var p2 = new Pen(Color.FromArgb(110, 0, 170, 255), 6)) g.DrawLines(p2, arr);
            using (var p3 = new Pen(Color.FromArgb(230, 150, 235, 255), 2)) g.DrawLines(p3, arr);

            float sx = Game.PW - 60, sY = Game.SurfaceY(sx) - 4;
            Nebula(g, sx, sY, 60, Color.FromArgb(255, 170, 60), 150);
            using (var sb = new SolidBrush(Color.White)) g.FillRectangle(sb, sx - 3, sY - 3, 6, 6);
        }

        // =====================================================================
        //  Text / panel helpers
        // =====================================================================
        private void DrawTxt(Graphics g, string s, Font f, float x, float y, Color fill, Color outline, int th,
            StringAlignment al)
        {
            sf.Alignment = al;
            if (th > 0)
            {
                using (var ob = new SolidBrush(outline))
                    for (int dx = -th; dx <= th; dx += th)
                        for (int dy = -th; dy <= th; dy += th)
                            if (dx != 0 || dy != 0) g.DrawString(s, f, ob, x + dx, y + dy, sf);
            }
            using (var fb = new SolidBrush(fill)) g.DrawString(s, f, fb, x, y, sf);
        }

        private void Ctr(Graphics g, string s, Font f, float x, float y, Color fill, Color outline, int th)
        {
            DrawTxt(g, s, f, x, y, fill, outline, th, StringAlignment.Center);
        }

        private static Point[] Chamfer(Rectangle r, int c)
        {
            return new[]
            {
                new Point(r.Left + c, r.Top), new Point(r.Right - c, r.Top),
                new Point(r.Right, r.Top + c), new Point(r.Right, r.Bottom - c),
                new Point(r.Right - c, r.Bottom), new Point(r.Left + c, r.Bottom),
                new Point(r.Left, r.Bottom - c), new Point(r.Left, r.Top + c)
            };
        }

        private void Panel(Graphics g, Rectangle r, Color border, int alpha)
        {
            var poly = Chamfer(r, 6);
            using (var fill = new SolidBrush(Color.FromArgb(alpha, 8, 22, 64))) g.FillPolygon(fill, poly);
            using (var glow = new Pen(Color.FromArgb(60, border), 4)) g.DrawPolygon(glow, poly);
            using (var pen = new Pen(border, 2)) g.DrawPolygon(pen, poly);
        }

        private void Button(Graphics g, Rectangle r, string label)
        {
            var poly = Chamfer(r, 6);
            using (var fill = new SolidBrush(Color.FromArgb(14, 100, 36))) g.FillPolygon(fill, poly);
            using (var glow = new Pen(Color.FromArgb(70, 90, 255, 90), 4)) g.DrawPolygon(glow, poly);
            using (var pen = new Pen(Color.FromArgb(90, 255, 90), 2)) g.DrawPolygon(pen, poly);
            Ctr(g, label, f28, r.X + r.Width / 2f, r.Y + (r.Height - 28) / 2f - 1, Green, Color.FromArgb(0, 50, 10), 1);
        }

        // =====================================================================
        //  Frame
        // =====================================================================
        public void Render(Graphics g, Game game, bool muted)
        {
            g.Clear(Color.FromArgb(3, 6, 20));
            DrawSidebar(g, game);

            GraphicsState st = g.Save();
            g.SetClip(PF);
            g.TranslateTransform(PF.X, PF.Y);
            g.DrawImage(bgPlay, 0, 0, Game.PW, Game.PH);
            DrawStars(g);
            if (game.Phase == Phase.Menu) DrawMenuScene(g);
            else DrawWorld(g, game);
            g.Restore(st);

            DrawPlayfieldFrame(g);

            if (game.Phase == Phase.Menu)
            {
                Button(g, BtnStart, "START GAME");
                Button(g, BtnMenuSound, muted ? "SOUND: OFF" : "SOUND: ON");
                Ctr(g, "HI-SCORE " + game.HiScore.ToString("D6"), f20, PF.X + Game.PW / 2f, 540, Yellow, Brown, 1);
                return;
            }

            DrawPlayfieldHud(g, game, muted);

            switch (game.Phase)
            {
                case Phase.Paused: DrawPaused(g); break;
                case Phase.ConfirmMenu: DrawConfirm(g); break;
                case Phase.GameOver: DrawResult(g, game, false); break;
                case Phase.Victory: DrawResult(g, game, true); break;
            }
        }

        private void DrawPlayfieldFrame(Graphics g)
        {
            using (var p1 = new Pen(Color.FromArgb(70, 0, 120, 255), 8))
                g.DrawRectangle(p1, Rectangle.Inflate(PF, 2, 2));
            using (var p2 = new Pen(Color.FromArgb(0, 150, 255), 3))
                g.DrawRectangle(p2, Rectangle.Inflate(PF, 1, 1));
            using (var p3 = new Pen(Color.FromArgb(150, 235, 255), 1))
                g.DrawRectangle(p3, PF.X - 3, PF.Y - 3, PF.Width + 5, PF.Height + 5);
        }

        private void DrawStars(Graphics g)
        {
            foreach (var s in stars)
            {
                int a = Math.Max(30, 120 + (int)(110 * Math.Sin(anim * 2 + s.Phase)));
                tmp.Color = Color.FromArgb(a, s.C);
                g.FillRectangle(tmp, (int)s.X, (int)s.Y, s.Size, s.Size);
            }
        }

        // =====================================================================
        //  Sidebar
        // =====================================================================
        private void DrawSidebar(Graphics g, Game game)
        {
            var alien = Sprites.Get("alienA", Sprites.AlienA, Color.FromArgb(60, 255, 60), 4);
            g.DrawImage(alien, 98, 8, alien.Width, alien.Height);
            Ctr(g, "SPACE", f40, 120, 44, Orange, Brown, 2);
            Ctr(g, "INVADERS", f40, 120, 84, Orange, Brown, 2);

            Panel(g, new Rectangle(8, 134, 224, 72), Color.FromArgb(0, 170, 255), 235);
            Ctr(g, "SCORE", f20, 120, 140, Cyan, Navy, 0);
            Ctr(g, game.Score.ToString("D6"), f36, 120, 164, Cyan, Navy, 1);

            Panel(g, new Rectangle(8, 210, 224, 60), Color.FromArgb(0, 170, 255), 235);
            Ctr(g, "HI-SCORE", f16, 120, 215, Yellow, Navy, 0);
            Ctr(g, game.HiScore.ToString("D6"), f28, 120, 235, Color.White, Navy, 0);

            Panel(g, new Rectangle(8, 274, 224, 62), Color.FromArgb(0, 170, 255), 235);
            Ctr(g, "LEVEL", f16, 120, 279, Green, Navy, 0);
            Ctr(g, game.Level.ToString("D2"), f32, 120, 297, Green, Navy, 0);

            Panel(g, new Rectangle(8, 340, 224, 64), Color.FromArgb(0, 170, 255), 235);
            Ctr(g, "LIVES", f16, 120, 345, Yellow, Navy, 0);
            var ship = Sprites.Get("ship", Sprites.Ship, Cyan, 2);
            int lives = Math.Max(0, game.Lives);
            float total = lives * 40 - 14;
            for (int i = 0; i < lives; i++)
                g.DrawImage(ship, (int)(120 - total / 2 + i * 40), 372, ship.Width, ship.Height);

            Panel(g, new Rectangle(8, 410, 224, 232), Color.FromArgb(0, 170, 255), 235);
            Ctr(g, "CONTROLS", f20, 120, 416, Cyan, Navy, 0);
            string[] keys = { "\u2190 A", "\u2192 D", "SPACE", "P", "M", "ESC" };
            string[] acts = { "Move Left", "Move Right", "Fire", "Pause", "Sound", "Menu" };
            for (int i = 0; i < keys.Length; i++)
            {
                int y = 446 + i * 30;
                var kr = new Rectangle(20, y, 64, 24);
                using (var kb = new SolidBrush(Color.FromArgb(24, 44, 100))) g.FillRectangle(kb, kr);
                using (var kp = new Pen(Color.FromArgb(110, 150, 220), 1)) g.DrawRectangle(kp, kr);
                Ctr(g, keys[i], f16, kr.X + kr.Width / 2f, y + 4, Color.White, Navy, 0);
                DrawTxt(g, acts[i], f16, 98, y + 4, Cyan, Navy, 0, StringAlignment.Near);
            }

            Panel(g, new Rectangle(8, 648, 224, 60), Color.FromArgb(60, 255, 90), 235);
            Ctr(g, "GOOD LUCK!", f28, 120, 664, Green, Color.FromArgb(0, 50, 10), 0);
        }

        // =====================================================================
        //  Playfield contents (drawn with PF translation active)
        // =====================================================================
        private void DrawMenuScene(Graphics g)
        {
            Ctr(g, "SPACE", f72, Game.PW / 2f, 40, Orange, Brown, 3);
            Ctr(g, "INVADERS", f72, Game.PW / 2f, 112, Orange, Brown, 3);

            for (int i = 0; i < 5; i++)
            {
                var bmp = Sprites.Get(((int)(anim * 2) & 1) == 0 ? "alienA" : "alienB",
                    ((int)(anim * 2) & 1) == 0 ? Sprites.AlienA : Sprites.AlienB, Game.RowColor(i), 3);
                int x = (Game.PW - (4 * 90 + Game.AlienW)) / 2 + i * 90;
                g.DrawImage(bmp, x, 222, bmp.Width, bmp.Height);
            }

            float cx = Game.PW / 2f;
            Ctr(g, "LEFT / RIGHT  or  A / D : MOVE", f18, cx, 290, Color.White, Navy, 1);
            Ctr(g, "SPACE : FIRE  (HOLD = AUTO-FIRE)", f18, cx, 316, Color.White, Navy, 1);
            Ctr(g, "P : PAUSE    M : SOUND    ESC : MENU / QUIT", f18, cx, 342, Color.White, Navy, 1);
            Ctr(g, "DESTROY ALL 5 WAVES AND PROTECT EARTH!", f18, cx, 372, Yellow, Brown, 1);
        }

        private void DrawWorld(Graphics g, Game game)
        {
            // Earth damage: burning craters where aliens crashed
            foreach (float cx in game.CrashXs)
            {
                float sy = Game.SurfaceY(cx);
                int f = (int)(anim * 10) % 3;
                using (var dk = new SolidBrush(Color.FromArgb(200, 40, 10, 0)))
                    g.FillRectangle(dk, cx - 12, sy, 24, 8);
                using (var fl = new SolidBrush(f == 0 ? Color.OrangeRed : (f == 1 ? Color.Orange : Color.Yellow)))
                {
                    g.FillRectangle(fl, cx - 8, sy - 4 - f * 2, 5, 8 + f * 2);
                    g.FillRectangle(fl, cx + 2, sy - 6 + f, 5, 10 - f);
                }
            }

            DrawAliens(g, game);
            DrawDivers(g, game);
            DrawShots(g, game);
            DrawPlayer(g, game);

            foreach (var p in game.Particles)
            {
                int a = (int)(255 * Math.Max(0f, p.Life / p.MaxLife));
                tmp.Color = Color.FromArgb(a, p.Color);
                g.FillRectangle(tmp, (int)p.X, (int)p.Y, p.Size, p.Size);
            }

            if (game.BannerTimer > 0)
                Ctr(g, "WAVE " + game.Level + " CLEARED!", f56, Game.PW / 2f, 240, Yellow, Brown, 3);
        }

        private void DrawAliens(Graphics g, Game game)
        {
            string key = game.AnimFrame == 0 ? "alienA" : "alienB";
            string[] rows = game.AnimFrame == 0 ? Sprites.AlienA : Sprites.AlienB;
            foreach (var a in game.Aliens)
            {
                if (!a.Alive) continue;
                var bmp = Sprites.Get(key, rows, Game.RowColor(a.Row), 3);
                g.DrawImage(bmp, (int)Math.Round(game.FormX + a.Col * Game.CellW),
                    (int)Math.Round(game.FormY + a.Row * Game.CellH), bmp.Width, bmp.Height);
            }
        }

        private void DrawDivers(Graphics g, Game game)
        {
            bool frameA = ((int)(game.Time * 8) & 1) == 0;
            foreach (var d in game.Divers)
            {
                for (int i = 0; i < d.Trail.Count; i++)
                {
                    int a = 25 + i * 14;
                    int sz = 4 + i / 2;
                    tmp.Color = Color.FromArgb(Math.Min(200, a), 255, 90, 215);
                    g.FillRectangle(tmp, d.Trail[i].X - sz / 2f, d.Trail[i].Y - sz / 2f, sz, sz);
                }
                int pulse = 60 + (int)(40 * Math.Sin(game.Time * 14));
                tmp.Color = Color.FromArgb(pulse, 255, 60, 200);
                g.FillEllipse(tmp, d.X - 28, d.Y - 24, 56, 48);

                var bmp = Sprites.Get(frameA ? "alienA" : "alienB", frameA ? Sprites.AlienA : Sprites.AlienB,
                    DiverColor, 3);
                g.DrawImage(bmp, (int)(d.X - Game.AlienW / 2f), (int)(d.Y - Game.AlienH / 2f), bmp.Width, bmp.Height);
            }
        }

        private void DrawShots(Graphics g, Game game)
        {
            using (var core = new SolidBrush(Color.White))
            using (var cy = new SolidBrush(Color.FromArgb(40, 220, 255)))
            {
                foreach (var s in game.PlayerShots)
                {
                    g.FillRectangle(cy, s.X - 2, s.Y - 9, 4, 11);
                    g.FillRectangle(core, s.X - 1, s.Y - 9, 2, 8);
                    g.FillRectangle(cy, s.X - 2, s.Y + 5, 4, 4);
                }
            }
            using (var red = new SolidBrush(Color.FromArgb(255, 70, 40)))
            using (var yel = new SolidBrush(Color.FromArgb(255, 220, 80)))
            {
                foreach (var s in game.EnemyShots)
                {
                    int w = ((int)(s.Y / 6) & 1) == 0 ? -2 : 2;   // zig-zag look
                    g.FillRectangle(red, s.X - 3 + w, s.Y - 8, 6, 5);
                    g.FillRectangle(yel, s.X - 3 - w, s.Y - 3, 6, 5);
                    g.FillRectangle(red, s.X - 3 + w, s.Y + 2, 6, 5);
                }
            }
        }

        private void DrawPlayer(Graphics g, Game game)
        {
            bool visible = game.Invuln <= 0f || ((int)(game.Time * 12) & 1) == 0;
            if (!visible) return;

            var ship = Sprites.Get("ship", Sprites.Ship, Cyan, 3);
            int x = (int)Math.Round(game.PlayerX - Game.PlayerW / 2f);
            int y = (int)Game.PlayerTop;

            // thruster flame
            int fl = 6 + (int)(Math.Abs(Math.Sin(anim * 30)) * 8);
            using (var o = new SolidBrush(Color.FromArgb(255, 140, 20))) g.FillRectangle(o, x + 16, y + Game.PlayerH, 7, fl);
            using (var yw = new SolidBrush(Color.FromArgb(255, 230, 90))) g.FillRectangle(yw, x + 18, y + Game.PlayerH, 3, fl - 3);

            g.DrawImage(ship, x, y, ship.Width, ship.Height);

            if (game.MuzzleFlash > 0f)
            {
                using (var c = new SolidBrush(Color.FromArgb(40, 220, 255))) g.FillRectangle(c, x + 14, y - 10, 11, 11);
                using (var w = new SolidBrush(Color.White)) g.FillRectangle(w, x + 17, y - 7, 5, 6);
            }
        }

        // =====================================================================
        //  HUD over the playfield (absolute coordinates) and overlays
        // =====================================================================
        private void DrawPlayfieldHud(Graphics g, Game game, bool muted)
        {
            Panel(g, BtnSound, muted ? Color.FromArgb(255, 110, 110) : Color.FromArgb(0, 170, 255), 200);
            Ctr(g, muted ? "[M] SOUND OFF" : "[M] SOUND ON", f12, BtnSound.X + BtnSound.Width / 2f, BtnSound.Y + 5,
                muted ? Color.FromArgb(255, 140, 140) : Color.White, Navy, 0);

            DrawTxt(g, "EARTH", f12, 258, 52, Cyan, Navy, 1, StringAlignment.Near);
            for (int i = 0; i < Game.MaxPlanetHp; i++)
            {
                var seg = new Rectangle(306 + i * 18, 51, 14, 12);
                bool on = i < game.PlanetHp;
                using (var b = new SolidBrush(on ? (game.PlanetHp <= 2 ? Color.FromArgb(255, 80, 60) : Color.FromArgb(70, 230, 120))
                    : Color.FromArgb(60, 30, 40, 70)))
                    g.FillRectangle(b, seg);
                using (var p = new Pen(Color.FromArgb(150, 150, 200, 255), 1)) g.DrawRectangle(p, seg);
            }

            int left = game.AliensAlive + game.Divers.Count;
            DrawTxt(g, "WAVE " + game.Level + " / " + Game.MaxLevel, f32, PF.Right - 14, PF.Y + 8, Color.White,
                Navy, 2, StringAlignment.Far);
            DrawTxt(g, "INVADERS: " + left, f16, PF.Right - 14, PF.Y + 46, Cyan, Navy, 1, StringAlignment.Far);
        }

        private void Dim(Graphics g, int alpha)
        {
            using (var b = new SolidBrush(Color.FromArgb(alpha, 0, 0, 20))) g.FillRectangle(b, PF);
        }

        private void DrawPaused(Graphics g)
        {
            Dim(g, 140);
            var r = new Rectangle(PF.X + 152, PF.Y + 250, 400, 150);
            Panel(g, r, Color.FromArgb(0, 190, 255), 240);
            Ctr(g, "PAUSED", f56, r.X + r.Width / 2f, r.Y + 16, Yellow, Brown, 2);
            Ctr(g, "PRESS P TO RESUME", f20, r.X + r.Width / 2f, r.Y + 96, Color.White, Navy, 1);
            Ctr(g, "ESC = MENU", f16, r.X + r.Width / 2f, r.Y + 122, Cyan, Navy, 0);
        }

        private void DrawConfirm(Graphics g)
        {
            Dim(g, 160);
            var r = new Rectangle(PF.X + 152, PF.Y + 250, 400, 150);
            Panel(g, r, Color.FromArgb(255, 170, 40), 240);
            Ctr(g, "RETURN TO MENU?", f32, r.X + r.Width / 2f, r.Y + 28, Yellow, Brown, 2);
            Ctr(g, "Y = YES      N = NO", f28, r.X + r.Width / 2f, r.Y + 84, Color.White, Navy, 1);
        }

        private void DrawResult(Graphics g, Game game, bool win)
        {
            Dim(g, 150);
            var r = new Rectangle(358, 180, 480, 360);
            Panel(g, r, win ? Color.FromArgb(90, 255, 90) : Color.FromArgb(255, 80, 70), 242);
            float cx = r.X + r.Width / 2f;
            if (win) Ctr(g, "YOU WIN!", f56, cx, r.Y + 18, Green, Color.FromArgb(0, 60, 10), 3);
            else Ctr(g, "GAME OVER", f56, cx, r.Y + 18, Color.FromArgb(255, 80, 60), Color.FromArgb(70, 0, 0), 3);

            Ctr(g, "SCORE", f20, cx, r.Y + 90, Cyan, Navy, 0);
            Ctr(g, game.Score.ToString("D6"), f40, cx, r.Y + 112, Color.White, Navy, 1);
            Ctr(g, "HI-SCORE", f20, cx, r.Y + 168, Yellow, Brown, 0);
            Ctr(g, game.HiScore.ToString("D6"), f28, cx, r.Y + 190, Color.White, Navy, 0);

            Button(g, BtnRestart, "RESTART");
            Button(g, BtnToMenu, "MENU");
            Ctr(g, "R = RESTART      ESC = MENU", f16, cx, r.Y + 316, Cyan, Navy, 0);
        }
    }
}
