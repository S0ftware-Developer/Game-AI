@echo off
rem Builds and publishes Space Invaders as a self-contained Windows x64 app (no .NET install needed to play).
rem Needs the .NET 8 SDK; self-contained publishing also downloads the runtime pack from NuGet once.
setlocal
cd /d "%~dp0"

dotnet --version >nul 2>&1
if errorlevel 1 (
  echo .NET SDK not found. Install .NET 8 SDK from https://dotnet.microsoft.com/download
  pause
  exit /b 1
)

if exist publish rmdir /s /q publish
dotnet publish SpaceInvaders.csproj -c Release -r win-x64 --self-contained true -o publish
if errorlevel 1 (
  echo.
  echo BUILD FAILED - see the messages above.
  pause
  exit /b 1
)

if exist SpaceInvaders-win-x64.zip del SpaceInvaders-win-x64.zip
powershell -NoProfile -Command "Compress-Archive -Path 'publish\*' -DestinationPath 'SpaceInvaders-win-x64.zip'"

echo.
echo OK. Game folder: %~dp0publish\SpaceInvaders.exe
echo Distributable archive: %~dp0SpaceInvaders-win-x64.zip
pause
