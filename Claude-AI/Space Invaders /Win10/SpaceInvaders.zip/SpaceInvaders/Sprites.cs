using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;

namespace SpaceInvaders
{
    /// <summary>Pixel-art sprite definitions and a cache that renders them to crisp bitmaps.</summary>
    internal static class Sprites
    {
        public static readonly string[] AlienA =
        {
            "..X.....X..",
            "...X...X...",
            "..XXXXXXX..",
            ".XX.XXX.XX.",
            "XXXXXXXXXXX",
            "X.XXXXXXX.X",
            "X.X.....X.X",
            "...XX.XX..."
        };

        public static readonly string[] AlienB =
        {
            "..X.....X..",
            "X..X...X..X",
            "X.XXXXXXX.X",
            "XXX.XXX.XXX",
            "XXXXXXXXXXX",
            ".XXXXXXXXX.",
            "..X.....X..",
            ".X.......X."
        };

        public static readonly string[] Ship =
        {
            "......X......",
            ".....XXX.....",
            ".....XoX.....",
            "....XXoXX....",
            "....XXXXX....",
            ".X..XXXXX..X.",
            ".XX.XXXXX.XX.",
            "XXXXXXXXXXXXX",
            "XXXXXXXXXXXXX",
            "XXX.XXXXX.XXX",
            "X.X..XXX..X.X",
            "......X......"
        };

        private static readonly Dictionary<string, Bitmap> cache = new Dictionary<string, Bitmap>();

        public static Color Blend(Color a, Color b, float t)
        {
            return Color.FromArgb(
                (int)(a.R + (b.R - a.R) * t),
                (int)(a.G + (b.G - a.G) * t),
                (int)(a.B + (b.B - a.B) * t));
        }

        /// <summary>'X' = main colour, 'o' = highlight, anything else = transparent.</summary>
        public static Bitmap Get(string key, string[] rows, Color c, int scale)
        {
            string k = key + "_" + c.ToArgb() + "_" + scale;
            Bitmap bmp;
            if (cache.TryGetValue(k, out bmp)) return bmp;

            int h = rows.Length, w = rows[0].Length;
            bmp = new Bitmap(w * scale, h * scale, PixelFormat.Format32bppPArgb);
            using (var g = Graphics.FromImage(bmp))
            using (var main = new SolidBrush(c))
            using (var light = new SolidBrush(Blend(c, Color.White, 0.6f)))
            {
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                    {
                        char ch = rows[y][x];
                        if (ch == 'X') g.FillRectangle(main, x * scale, y * scale, scale, scale);
                        else if (ch == 'o') g.FillRectangle(light, x * scale, y * scale, scale, scale);
                    }
            }
            cache[k] = bmp;
            return bmp;
        }
    }
}
