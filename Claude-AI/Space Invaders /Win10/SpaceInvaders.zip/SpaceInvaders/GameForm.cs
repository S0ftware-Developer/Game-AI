using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Windows.Forms;

namespace SpaceInvaders
{
    /// <summary>Window, input and the fixed-timestep game loop. No gameplay rules live here.</summary>
    internal sealed class GameForm : Form
    {
        private const int FooterH = 30;
        private const float StepDt = 1f / 120f;

        private readonly Game game = new Game();
        private readonly Sfx sfx = new Sfx();
        private readonly Renderer renderer = new Renderer();
        private readonly Bitmap frame = new Bitmap(Renderer.LW, Renderer.LH, PixelFormat.Format32bppPArgb);
        private readonly Graphics fg;
        private Rectangle gameRect;

        private bool left, right, spaceHeld;
        private readonly Stopwatch clock = Stopwatch.StartNew();
        private double lastTime, acc;

        public GameForm()
        {
            Text = "Space Invaders";
            DoubleBuffered = true;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(3, 6, 20);
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(640, 520);

            // Default window = 1:1 logical size, shrunk if the screen is too small.
            var wa = Screen.PrimaryScreen.WorkingArea;
            float s = Math.Min(1f, Math.Min((wa.Width - 40) / (float)Renderer.LW,
                (wa.Height - 100 - FooterH) / (float)Renderer.LH));
            ClientSize = new Size((int)(Renderer.LW * s), (int)(Renderer.LH * s) + FooterH);

            fg = Graphics.FromImage(frame);
            fg.SmoothingMode = SmoothingMode.None;
            fg.InterpolationMode = InterpolationMode.NearestNeighbor;
            fg.PixelOffsetMode = PixelOffsetMode.Half;
            fg.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;

            game.Sound = name => sfx.Play(name);
            RecalcLayout();

            var timer = new System.Windows.Forms.Timer { Interval = 8 };
            timer.Tick += (o, e) => Tick();
            timer.Start();
            lastTime = clock.Elapsed.TotalSeconds;
        }

        // ---------- layout ----------
        private void RecalcLayout()
        {
            int availW = Math.Max(1, ClientSize.Width);
            int availH = Math.Max(1, ClientSize.Height - FooterH);
            float s = Math.Min(availW / (float)Renderer.LW, availH / (float)Renderer.LH);
            int w = Math.Max(1, (int)(Renderer.LW * s));
            int h = Math.Max(1, (int)(Renderer.LH * s));
            gameRect = new Rectangle((availW - w) / 2, (availH - h) / 2, w, h);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            RecalcLayout();
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        // ---------- loop ----------
        private void Tick()
        {
            double now = clock.Elapsed.TotalSeconds;
            double dt = now - lastTime;
            lastTime = now;
            if (dt > 0.1) dt = 0.1;
            acc += dt;

            while (acc >= StepDt)
            {
                game.MoveDir = (right ? 1 : 0) - (left ? 1 : 0);
                game.FireHeld = spaceHeld;
                game.Update(StepDt);
                // decorative animation stops whenever gameplay is frozen
                if (game.Phase == Phase.Playing || game.Phase == Phase.Menu) renderer.Tick(StepDt);
                acc -= StepDt;
            }
            Invalidate();
        }

        // ---------- input ----------
        private void StartOrRestart()
        {
            if (game.Phase == Phase.Menu) game.NewGame();
            else if ((game.Phase == Phase.GameOver || game.Phase == Phase.Victory) && game.CanRestart) game.NewGame();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.A:
                    left = true; break;
                case Keys.Right:
                case Keys.D:
                    right = true; break;
                case Keys.Space:
                    if (game.Phase == Phase.Menu) StartOrRestart();
                    else if (game.Phase == Phase.Playing && !spaceHeld) game.QueueFire();
                    spaceHeld = true;
                    break;
                case Keys.Enter:
                    StartOrRestart(); break;
                case Keys.P:
                    game.TogglePause(); break;
                case Keys.R:
                    if (game.Phase == Phase.GameOver || game.Phase == Phase.Victory) StartOrRestart();
                    break;
                case Keys.M:
                    sfx.Muted = !sfx.Muted; break;
                case Keys.Y:
                    game.ConfirmMenuYes(); break;
                case Keys.N:
                    game.ConfirmMenuNo(); break;
                case Keys.Escape:
                    switch (game.Phase)
                    {
                        case Phase.Menu: Close(); break;
                        case Phase.Playing:
                        case Phase.Paused: game.RequestMenu(); break;
                        case Phase.ConfirmMenu: game.ConfirmMenuNo(); break;
                        case Phase.GameOver:
                        case Phase.Victory: game.GoMenu(); break;
                    }
                    break;
            }
            e.SuppressKeyPress = true;
            base.OnKeyDown(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.A: left = false; break;
                case Keys.Right:
                case Keys.D: right = false; break;
                case Keys.Space: spaceHeld = false; break;
            }
            base.OnKeyUp(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left || !gameRect.Contains(e.Location)) return;
            var p = new Point(
                (int)((e.X - gameRect.X) * Renderer.LW / (float)gameRect.Width),
                (int)((e.Y - gameRect.Y) * Renderer.LH / (float)gameRect.Height));

            switch (game.Phase)
            {
                case Phase.Menu:
                    if (Renderer.BtnStart.Contains(p)) game.NewGame();
                    else if (Renderer.BtnMenuSound.Contains(p)) sfx.Muted = !sfx.Muted;
                    break;
                case Phase.GameOver:
                case Phase.Victory:
                    if (Renderer.BtnRestart.Contains(p)) StartOrRestart();
                    else if (Renderer.BtnToMenu.Contains(p)) game.GoMenu();
                    break;
                default:
                    if (Renderer.BtnSound.Contains(p)) sfx.Muted = !sfx.Muted;
                    break;
            }
        }

        protected override void OnDeactivate(EventArgs e)
        {
            base.OnDeactivate(e);
            left = right = spaceHeld = false;
            if (game.Phase == Phase.Playing) game.TogglePause();   // auto-pause when focus is lost
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            game.SaveHi();
            base.OnFormClosing(e);
        }

        // ---------- painting ----------
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Color.FromArgb(3, 6, 20));

            renderer.Render(fg, game, sfx.Muted);

            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.DrawImage(frame, gameRect, 0, 0, Renderer.LW, Renderer.LH, GraphicsUnit.Pixel);

            DrawFooter(g);
        }

        private void DrawFooter(Graphics g)
        {
            int cw = ClientSize.Width;
            int top = ClientSize.Height - FooterH;
            using (var b = new SolidBrush(Color.FromArgb(5, 14, 48))) g.FillRectangle(b, 0, top, cw, FooterH);
            using (var pen = new Pen(Color.FromArgb(0, 150, 230), 2)) g.DrawLine(pen, 0, top, cw, top);

            string a = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: ";
            string c = "orlovandrei.space";

            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            var fmt = StringFormat.GenericTypographic;
            float size = 14f;
            Font f = null;
            float wa = 0, wc = 0;
            while (true)
            {
                if (f != null) f.Dispose();
                f = new Font("Consolas", size, FontStyle.Regular, GraphicsUnit.Pixel);
                wa = g.MeasureString(a, f, 2000, fmt).Width;
                wc = g.MeasureString(c, f, 2000, fmt).Width;
                if (wa + wc <= cw - 12 || size <= 7f) break;
                size -= 0.5f;
            }
            float x = (cw - (wa + wc)) / 2f;
            float y = top + (FooterH - f.Height) / 2f;
            using (var b1 = new SolidBrush(Color.White)) g.DrawString(a, f, b1, x, y, fmt);
            using (var b2 = new SolidBrush(Color.FromArgb(90, 255, 90))) g.DrawString(c, f, b2, x + wa, y, fmt);
            f.Dispose();
        }
    }
}
