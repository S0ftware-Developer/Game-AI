using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace PingPong
{
    public partial class GameForm
    {
        // Цвета логотипа в стиле референса
        private static readonly Color LogoTop = Color.FromArgb(255, 240, 70);
        private static readonly Color LogoBottom = Color.FromArgb(255, 110, 25);
        private static readonly Color LogoOutline = Color.FromArgb(150, 20, 50);

        private static readonly Color NeonBlue = Color.FromArgb(48, 145, 255);
        private static readonly Color RedTeam = Color.FromArgb(235, 40, 50);
        private static readonly Color GreenTeam = Color.FromArgb(60, 220, 50);

        // Панели HUD (логические координаты)
        private static readonly RectangleF HudLeftPanel = new RectangleF(24f, 12f, 280f, 110f);
        private static readonly RectangleF HudLeftIcon = new RectangleF(312f, 12f, 136f, 110f);
        private static readonly RectangleF HudCenterPanel = new RectangleF(454f, 12f, 372f, 110f);
        private static readonly RectangleF HudRightIcon = new RectangleF(832f, 12f, 136f, 110f);
        private static readonly RectangleF HudRightPanel = new RectangleF(976f, 12f, 280f, 110f);

        // ==========================================================
        //  Сборка статического фона (один раз при запуске)
        // ==========================================================
        private Bitmap BuildBackground()
        {
            var bmp = new Bitmap(DesignWidth, DesignHeight, PixelFormat.Format32bppPArgb);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

                DrawBackdrop(g);
                DrawCrowd(g);
                DrawFloodlights(g);
                DrawArena(g);
                DrawBarrierAndFloor(g);
                DrawNetPosts(g);
                DrawHudFrames(g);
                DrawTitleText(g, "PING-PONG", 640f, 50f, 330f, 56f, LogoTop, LogoBottom, LogoOutline, true, 1f);
                DrawRacketIcon(g, HudLeftIcon.X + HudLeftIcon.Width / 2f, 50f, false,
                    Color.FromArgb(255, 110, 100), Color.FromArgb(190, 12, 28));
                DrawRacketIcon(g, HudRightIcon.X + HudRightIcon.Width / 2f, 50f, true,
                    Color.FromArgb(130, 255, 100), Color.FromArgb(20, 150, 35));
                DrawFooter(g);
            }
            return bmp;
        }

        private static Color Shade(Color c, float k)
        {
            return Color.FromArgb(255,
                Math.Clamp((int)(c.R * k), 0, 255),
                Math.Clamp((int)(c.G * k), 0, 255),
                Math.Clamp((int)(c.B * k), 0, 255));
        }

        // --- Тёмно-синий атмосферный фон арены ---
        private void DrawBackdrop(Graphics g)
        {
            var rect = new RectangleF(0, 0, DesignWidth, DesignHeight);
            using (var brush = new LinearGradientBrush(rect, Color.Black, Color.Black, LinearGradientMode.Vertical))
            {
                brush.InterpolationColors = new ColorBlend
                {
                    Positions = new[] { 0f, 0.30f, 0.62f, 0.85f, 1f },
                    Colors = new[]
                    {
                        Color.FromArgb(2, 5, 26),
                        Color.FromArgb(6, 18, 80),
                        Color.FromArgb(12, 40, 150),
                        Color.FromArgb(8, 28, 110),
                        Color.FromArgb(4, 12, 50)
                    }
                };
                g.FillRectangle(brush, rect);
            }
        }

        // --- Трибуны со зрителями-силуэтами (болельщики в красных и зелёных кепках) ---
        private void DrawCrowd(Graphics g)
        {
            var r = new Random(20260101);
            Color[] shirts =
            {
                Color.FromArgb(30, 56, 160), Color.FromArgb(48, 42, 134), Color.FromArgb(36, 90, 178),
                Color.FromArgb(64, 50, 146), Color.FromArgb(26, 74, 138), Color.FromArgb(76, 64, 168)
            };
            Color[] skins =
            {
                Color.FromArgb(104, 98, 178), Color.FromArgb(118, 106, 186),
                Color.FromArgb(90, 102, 166), Color.FromArgb(126, 110, 176)
            };

            for (int row = 0; row < 7; row++)
            {
                float s = 0.82f + row * 0.035f;
                float baseY = 232f + row * 47f;
                float step = 38f * s + 6f;
                float shade = 0.50f + row * 0.075f;
                float x = -20f + ((row % 2 == 0) ? 0f : step / 2f);

                while (x < DesignWidth + 20f)
                {
                    Color shirt = Shade(shirts[r.Next(shirts.Length)], shade);
                    Color skin = Shade(skins[r.Next(skins.Length)], shade);

                    float bodyW = 34f * s, bodyH = 30f * s, headW = 16f * s, headH = 17f * s;

                    using (var shirtBrush = new SolidBrush(shirt))
                    using (var bodyPath = RoundedRect(new RectangleF(x, baseY + 16f * s, bodyW, bodyH), 8f * s))
                    {
                        g.FillPath(shirtBrush, bodyPath);
                    }

                    using (var skinBrush = new SolidBrush(skin))
                    using (var headPath = RoundedRect(new RectangleF(x + 9f * s, baseY, headW, headH), 6f * s))
                    {
                        g.FillPath(skinBrush, headPath);
                    }

                    int cap = r.Next(9);
                    if (cap <= 1)
                    {
                        Color capColor = cap == 0
                            ? Shade(Color.FromArgb(190, 50, 70), shade)
                            : Shade(Color.FromArgb(50, 150, 80), shade);
                        using (var capBrush = new SolidBrush(capColor))
                        {
                            g.FillRectangle(capBrush, x + 8f * s, baseY, headW + 2f * s, 6f * s);
                        }
                    }

                    x += step + r.Next(-3, 4);
                }
            }
        }

        // --- Кластеры прожекторов 2x3 в верхних углах ---
        private void DrawFloodlights(Graphics g)
        {
            DrawLightCluster(g, 96f, 172f, 1.0f);
            DrawLightCluster(g, 258f, 198f, 0.82f);
            DrawLightCluster(g, 1184f, 172f, 1.0f);
            DrawLightCluster(g, 1022f, 198f, 0.82f);
        }

        private void DrawLightCluster(Graphics g, float cx, float cy, float scale)
        {
            float glowR = 78f * scale;
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(cx - glowR, cy - glowR, glowR * 2f, glowR * 2f);
                using (var glow = new PathGradientBrush(path))
                {
                    glow.CenterColor = Color.FromArgb(110, 190, 220, 255);
                    glow.SurroundColors = new[] { Color.FromArgb(0, 120, 170, 255) };
                    g.FillPath(glow, path);
                }
            }

            float[] dx = { -24f, 0f, 24f };
            float[] dy = { -10f, 10f };
            foreach (float oy in dy)
            {
                foreach (float ox in dx)
                {
                    float lx = cx + ox * scale;
                    float ly = cy + oy * scale;
                    float halo = 12f * scale;
                    float lamp = 6.5f * scale;

                    using (Brush haloBrush = new SolidBrush(Color.FromArgb(70, 170, 210, 255)))
                    {
                        g.FillEllipse(haloBrush, lx - halo, ly - halo, halo * 2f, halo * 2f);
                    }
                    using (Brush lampBrush = new SolidBrush(Color.FromArgb(255, 252, 255)))
                    {
                        g.FillEllipse(lampBrush, lx - lamp, ly - lamp, lamp * 2f, lamp * 2f);
                    }
                }
            }
        }

        // --- Корт: затемнение трибун, линии, центральная пунктирная линия, неоновая рамка ---
        private void DrawArena(Graphics g)
        {
            float w = CourtRight - CourtLeft;
            float h = CourtBottom - CourtTop;
            var arena = new RectangleF(CourtLeft, CourtTop, w, h);

            // Затемнение, чтобы мяч и ракетки читались на фоне зрителей
            using (var dim = new LinearGradientBrush(arena, Color.FromArgb(120, 4, 10, 52), Color.FromArgb(150, 3, 8, 40), LinearGradientMode.Vertical))
            {
                g.FillRectangle(dim, arena);
            }

            // Мягкое свечение торцевых линий в цветах команд
            using (var leftGlow = new LinearGradientBrush(new RectangleF(CourtLeft, CourtTop, 70f, h),
                       Color.FromArgb(80, 255, 60, 70), Color.FromArgb(0, 255, 60, 70), LinearGradientMode.Horizontal))
            {
                g.FillRectangle(leftGlow, CourtLeft, CourtTop, 70f, h);
            }
            using (var rightGlow = new LinearGradientBrush(new RectangleF(CourtRight - 70f, CourtTop, 70f, h),
                       Color.FromArgb(0, 70, 235, 60), Color.FromArgb(80, 70, 235, 60), LinearGradientMode.Horizontal))
            {
                g.FillRectangle(rightGlow, CourtRight - 70f, CourtTop, 70f, h);
            }

            // Свечение верхней и нижней границ
            using (var topGlow = new LinearGradientBrush(new RectangleF(CourtLeft, CourtTop, w, 22f),
                       Color.FromArgb(90, 70, 170, 255), Color.FromArgb(0, 70, 170, 255), LinearGradientMode.Vertical))
            {
                g.FillRectangle(topGlow, CourtLeft, CourtTop, w, 22f);
            }
            using (var bottomGlow = new LinearGradientBrush(new RectangleF(CourtLeft, CourtBottom - 22f, w, 22f),
                       Color.FromArgb(0, 70, 170, 255), Color.FromArgb(90, 70, 170, 255), LinearGradientMode.Vertical))
            {
                g.FillRectangle(bottomGlow, CourtLeft, CourtBottom - 22f, w, 22f);
            }

            // Центральный круг
            using (var circlePen = new Pen(Color.FromArgb(55, 130, 200, 255), 3f))
            {
                g.DrawEllipse(circlePen, CourtCenterX - 58f, CourtCenterY - 58f, 116f, 116f);
            }

            // Пунктирная линия сетки по центру
            using (Brush glowBrush = new SolidBrush(Color.FromArgb(38, 110, 190, 255)))
            using (Brush dashBrush = new SolidBrush(Color.FromArgb(225, 125, 205, 255)))
            {
                for (float y = CourtTop + 10f; y < CourtBottom - 18f; y += 26f)
                {
                    g.FillRectangle(glowBrush, CourtCenterX - 5f, y - 2f, 10f, 18f);
                    g.FillRectangle(dashBrush, CourtCenterX - 2f, y, 4f, 14f);
                }
            }

            // Неоновая рамка: внутренний край точно по границам, где отскакивает мяч
            var frame = new RectangleF(CourtLeft - 3f, CourtTop - 3f, w + 6f, h + 6f);
            for (int i = 4; i >= 1; i--)
            {
                using (var glowPen = new Pen(Color.FromArgb(16 + (5 - i) * 5, NeonBlue), 6f + i * 5f) { LineJoin = LineJoin.Round })
                using (var glowPath = RoundedRect(frame, 14f))
                {
                    g.DrawPath(glowPen, glowPath);
                }
            }
            using (var mainPen = new Pen(NeonBlue, 6f) { LineJoin = LineJoin.Round })
            using (var mainPath = RoundedRect(frame, 14f))
            {
                g.DrawPath(mainPen, mainPath);
            }
            using (var hiPen = new Pen(Color.FromArgb(190, 175, 225, 255), 1.5f) { LineJoin = LineJoin.Round })
            using (var hiPath = RoundedRect(RectangleF.Inflate(frame, -2.5f, -2.5f), 12f))
            {
                g.DrawPath(hiPen, hiPath);
            }
        }

        // --- Синий бортик, зелёный пол в полоску, нижняя тёмная панель ---
        private void DrawBarrierAndFloor(Graphics g)
        {
            // Бортик
            var barrier = new RectangleF(0f, 608f, DesignWidth, 30f);
            using (var brush = new LinearGradientBrush(barrier, Color.FromArgb(40, 108, 245), Color.FromArgb(18, 56, 162), LinearGradientMode.Vertical))
            {
                g.FillRectangle(brush, barrier);
            }
            using (Brush seam = new SolidBrush(Color.FromArgb(50, 0, 10, 60)))
            {
                for (float x = 0f; x < DesignWidth; x += 160f)
                {
                    g.FillRectangle(seam, x, 608f, 2f, 30f);
                }
            }
            using (Brush edge = new SolidBrush(Color.FromArgb(215, 235, 245, 255)))
            {
                g.FillRectangle(edge, 0f, 608f, DesignWidth, 2f);
            }

            // Пол в полоску
            Color stripeA = Color.FromArgb(22, 142, 52);
            Color stripeB = Color.FromArgb(30, 170, 62);
            for (int i = 0; i * 64 < DesignWidth; i++)
            {
                using (Brush stripe = new SolidBrush(i % 2 == 0 ? stripeA : stripeB))
                {
                    g.FillRectangle(stripe, i * 64f, 638f, 64f, 50f);
                }
            }
            using (var shadeBrush = new LinearGradientBrush(new RectangleF(0f, 638f, DesignWidth, 50f),
                       Color.FromArgb(0, 0, 20, 10), Color.FromArgb(90, 0, 20, 10), LinearGradientMode.Vertical))
            {
                g.FillRectangle(shadeBrush, 0f, 638f, DesignWidth, 50f);
            }
            using (Brush whiteLine = new SolidBrush(Color.FromArgb(240, 245, 250)))
            {
                g.FillRectangle(whiteLine, 0f, 638f, DesignWidth, 3f);
            }

            // Нижние линии и тёмная панель под футер
            using (Brush dark = new SolidBrush(Color.FromArgb(4, 10, 40)))
            {
                g.FillRectangle(dark, 0f, 688f, DesignWidth, 4f);
            }
            using (Brush neon = new SolidBrush(Color.FromArgb(60, 150, 255)))
            {
                g.FillRectangle(neon, 0f, 692f, DesignWidth, 3f);
            }
            using (Brush footerBg = new SolidBrush(Color.FromArgb(5, 10, 36)))
            {
                g.FillRectangle(footerBg, 0f, 695f, DesignWidth, DesignHeight - 695f);
            }
        }

        // --- Синие стойки и сетки по краям, как на референсе ---
        private void DrawNetPosts(Graphics g)
        {
            DrawPostAndNet(g, 22f, false);
            DrawPostAndNet(g, DesignWidth - 22f - 22f, true);
        }

        private void DrawPostAndNet(Graphics g, float postX, bool right)
        {
            float top = 548f, bottom = 664f;

            // Сетка с внешней стороны стойки
            float netX0 = right ? postX + 22f : 0f;
            float netX1 = right ? DesignWidth : postX;
            using (Brush netBg = new SolidBrush(Color.FromArgb(8, 20, 72)))
            {
                g.FillRectangle(netBg, netX0, 562f, netX1 - netX0, 88f);
            }
            using (var gridPen = new Pen(Color.FromArgb(120, 90, 150, 235), 1f))
            {
                for (float x = netX0; x <= netX1; x += 8f)
                {
                    g.DrawLine(gridPen, x, 562f, x, 650f);
                }
                for (float y = 562f; y <= 650f; y += 8f)
                {
                    g.DrawLine(gridPen, netX0, y, netX1, y);
                }
            }
            using (var ropePen = new Pen(Color.FromArgb(240, 245, 250), 3f))
            {
                g.DrawLine(ropePen, netX0, right ? 556f : 562f, netX1, right ? 562f : 556f);
            }

            // Стойка
            var post = new RectangleF(postX, top, 22f, bottom - top);
            using (var brush = new LinearGradientBrush(post, Color.FromArgb(70, 150, 255), Color.FromArgb(14, 52, 160), LinearGradientMode.Horizontal))
            {
                g.FillRectangle(brush, post);
            }
            using (Brush hi = new SolidBrush(Color.FromArgb(170, 150, 210, 255)))
            {
                g.FillRectangle(hi, postX + 3f, top + 4f, 3f, bottom - top - 8f);
            }
            using (var outline = new Pen(Color.FromArgb(6, 24, 90), 2f))
            {
                g.DrawRectangle(outline, post.X, post.Y, post.Width, post.Height);
            }
            using (Brush cap = new SolidBrush(Color.FromArgb(150, 205, 255)))
            {
                g.FillRectangle(cap, postX, top, 22f, 5f);
            }
        }

        // --- Рамки панелей HUD ---
        private void DrawHudFrames(Graphics g)
        {
            DrawNeonPanel(g, HudLeftPanel, 10f, NeonBlue, 1f);
            DrawNeonPanel(g, HudLeftIcon, 10f, NeonBlue, 1f);
            DrawNeonPanel(g, HudCenterPanel, 10f, NeonBlue, 1f);
            DrawNeonPanel(g, HudRightIcon, 10f, NeonBlue, 1f);
            DrawNeonPanel(g, HudRightPanel, 10f, NeonBlue, 1f);
        }

        // --- Иконка ракетки для панелей HUD ---
        private static void DrawRacketIcon(Graphics g, float cx, float cy, bool mirror, Color light, Color dark)
        {
            float sx = mirror ? -1f : 1f;
            float hx = cx + 7f * sx;
            float hy = cy - 8f;
            const float r = 21f;

            float dx = -0.55f * sx;
            float dy = 0.84f;
            float len = MathF.Sqrt(dx * dx + dy * dy);
            dx /= len;
            dy /= len;

            float sx0 = hx + dx * (r - 4f);
            float sy0 = hy + dy * (r - 4f);
            float ex = hx + dx * (r + 30f);
            float ey = hy + dy * (r + 30f);
            float nx = -dy;
            float ny = dx;

            PointF[] handle =
            {
                new PointF(sx0 + nx * 5f, sy0 + ny * 5f),
                new PointF(ex + nx * 6.5f, ey + ny * 6.5f),
                new PointF(ex - nx * 6.5f, ey - ny * 6.5f),
                new PointF(sx0 - nx * 5f, sy0 - ny * 5f)
            };
            using (Brush wood = new SolidBrush(Color.FromArgb(205, 130, 56)))
            using (var woodPen = new Pen(Color.FromArgb(60, 30, 10), 2.5f) { LineJoin = LineJoin.Round })
            {
                g.FillPolygon(wood, handle);
                g.DrawPolygon(woodPen, handle);
            }

            var headRect = new RectangleF(hx - r, hy - r, r * 2f, r * 2f);
            using (var headBrush = new LinearGradientBrush(headRect, light, dark, LinearGradientMode.ForwardDiagonal))
            using (var headPen = new Pen(Color.FromArgb(50, 0, 10), 2.5f))
            {
                g.FillEllipse(headBrush, headRect);
                g.DrawEllipse(headPen, headRect);
            }
            using (Brush glint = new SolidBrush(Color.FromArgb(160, 255, 255, 255)))
            {
                g.FillEllipse(glint, hx - r * 0.58f, hy - r * 0.66f, r * 0.5f, r * 0.34f);
            }
        }

        // --- Нижняя авторская подпись (статичная часть футера) ---
        private void DrawFooter(Graphics g)
        {
            const string before = "© 2026 Андрей Орлов (совместно с Claude AI). Сайт: ";
            const string site = "orlovandrei.space";

            using (StringFormat sf = CreateTypographicFormat())
            {
                Font font = fontFooter;
                bool ownsFont = false;

                float w1 = MeasureTextWidth(g, before, font, sf);
                float w2 = MeasureTextWidth(g, site, font, sf);
                float maxWidth = DesignWidth - 40f;

                // Если текст не помещается — уменьшаем шрифт, чтобы подпись была видна целиком
                if (w1 + w2 > maxWidth)
                {
                    float k = maxWidth / (w1 + w2);
                    font = new Font(fontFooter.FontFamily, fontFooter.Size * k, fontFooter.Style, GraphicsUnit.Pixel);
                    ownsFont = true;
                    w1 = MeasureTextWidth(g, before, font, sf);
                    w2 = MeasureTextWidth(g, site, font, sf);
                }

                float x = (DesignWidth - (w1 + w2)) / 2f;
                float y = 695f + (DesignHeight - 695f - font.Height) / 2f;

                using (Brush white = new SolidBrush(Color.FromArgb(235, 240, 250)))
                using (Brush green = new SolidBrush(Color.FromArgb(70, 235, 50)))
                {
                    g.DrawString(before, font, white, x, y, sf);
                    g.DrawString(site, font, green, x + w1, y, sf);
                }

                if (ownsFont) font.Dispose();
            }
        }
    }
}
