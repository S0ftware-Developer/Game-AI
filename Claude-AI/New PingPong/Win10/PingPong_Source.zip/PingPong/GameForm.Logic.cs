using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace PingPong
{
    public partial class GameForm
    {
        // ==========================================================
        //  Профили сложности ИИ (настраиваются здесь)
        // ==========================================================
        private void InitAiProfiles()
        {
            aiProfiles[(int)Difficulty.Easy] = new AiProfile
            {
                MaxSpeed = 270f, ReactDelay = 0.22f, Error = 80f,
                MistakeChance = 0.38f, DeadZone = 14f, AlwaysPredict = false
            };
            aiProfiles[(int)Difficulty.Normal] = new AiProfile
            {
                MaxSpeed = 400f, ReactDelay = 0.12f, Error = 46f,
                MistakeChance = 0.16f, DeadZone = 8f, AlwaysPredict = false
            };
            aiProfiles[(int)Difficulty.Hard] = new AiProfile
            {
                MaxSpeed = 500f, ReactDelay = 0.08f, Error = 28f,
                MistakeChance = 0.10f, DeadZone = 4f, AlwaysPredict = true
            };
        }

        private AiProfile CurrentAi => aiProfiles[(int)difficulty];

        // ==========================================================
        //  Сброс матча / смена состояний
        // ==========================================================
        private void ResetMatchState()
        {
            scoreL = 0;
            scoreR = 0;
            gamesL = 0;
            gamesR = 0;
            rally = 0;

            leftY = (CourtTop + CourtBottom) / 2f - PaddleHeight / 2f;
            rightY = leftY;
            leftVel = 0f;
            rightVel = 0f;

            pulseL = 0f;
            pulseR = 0f;
            flashTimer = 0f;
            leftHitFlash = 0f;
            rightHitFlash = 0f;

            aiError = 0f;
            aiThinkTimer = 0f;
            aiTargetY = leftY + PaddleHeight / 2f;

            particles.Clear();
            trail.Clear();

            PrepareServe(rng.Next(2) == 0 ? -1 : 1);
        }

        private void EnterState(GameState newState)
        {
            state = newState;
            stateTime = 0.0;
        }

        private void StartMatch()
        {
            ResetMatchState();
            EnterState(GameState.Playing);
            Play(sndStart);
        }

        private void StartNextGame()
        {
            scoreL = 0;
            scoreR = 0;
            // подаём тому, кто проиграл последнюю партию
            PrepareServe(lastGameWonByLeft ? 1 : -1);
            EnterState(GameState.Playing);
            Play(sndStart);
        }

        private void PrepareServe(int dir)
        {
            serveDir = dir;
            phase = RallyPhase.Serving;
            serveTimer = ServeDelay;

            ballX = CourtCenterX;
            ballY = CourtCenterY + ((float)rng.NextDouble() * 2f - 1f) * 90f;
            ballVX = 0f;
            ballVY = 0f;
            ballSpeed = BallBaseSpeed;
            rally = 0;
            trail.Clear();
        }

        private void LaunchBall()
        {
            float angle = ((float)rng.NextDouble() * 2f - 1f) * 0.4f;
            ballSpeed = BallBaseSpeed;
            ballVX = serveDir * ballSpeed * MathF.Cos(angle);
            ballVY = ballSpeed * MathF.Sin(angle);
            phase = RallyPhase.Live;

            if (serveDir > 0)
            {
                AiRollError();
            }
        }

        // ==========================================================
        //  Клавиатура
        // ==========================================================
        private void GameForm_KeyDown(object? sender, KeyEventArgs e)
        {
            // Повтор автонажатия не должен многократно срабатывать для P / Space / R
            bool isRepeat = !keysDown.Add(e.KeyCode);
            if (!isRepeat)
            {
                HandleKeyPressed(e.KeyCode);
            }

            if (IsGameKey(e.KeyCode))
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        private void GameForm_KeyUp(object? sender, KeyEventArgs e)
        {
            keysDown.Remove(e.KeyCode);
        }

        private static bool IsGameKey(Keys key)
        {
            switch (key)
            {
                case Keys.W:
                case Keys.S:
                case Keys.Up:
                case Keys.Down:
                case Keys.Space:
                case Keys.P:
                case Keys.R:
                case Keys.M:
                case Keys.Escape:
                case Keys.D1:
                case Keys.D2:
                case Keys.D3:
                case Keys.NumPad1:
                case Keys.NumPad2:
                case Keys.NumPad3:
                    return true;
                default:
                    return false;
            }
        }

        private void HandleKeyPressed(Keys key)
        {
            switch (key)
            {
                case Keys.Space:
                    if (state == GameState.Start)
                    {
                        StartMatch();
                    }
                    else if (state == GameState.GameBreak)
                    {
                        StartNextGame();
                    }
                    break;

                case Keys.P:
                    if (state == GameState.Playing)
                    {
                        EnterState(GameState.Paused);
                        Play(sndPause);
                    }
                    else if (state == GameState.Paused)
                    {
                        EnterState(GameState.Playing);
                        Play(sndPause);
                    }
                    break;

                case Keys.R:
                    StartMatch();
                    break;

                case Keys.M:
                    soundEnabled = !soundEnabled;
                    break;

                case Keys.Escape:
                    this.Close();
                    break;

                case Keys.D1:
                case Keys.NumPad1:
                    difficulty = Difficulty.Easy;
                    break;
                case Keys.D2:
                case Keys.NumPad2:
                    difficulty = Difficulty.Normal;
                    break;
                case Keys.D3:
                case Keys.NumPad3:
                    difficulty = Difficulty.Hard;
                    break;
            }
        }

        private bool IsUpHeld => keysDown.Contains(Keys.W) || keysDown.Contains(Keys.Up);
        private bool IsDownHeld => keysDown.Contains(Keys.S) || keysDown.Contains(Keys.Down);

        // ==========================================================
        //  Главный цикл
        // ==========================================================
        private void GameTimer_Tick(object? sender, EventArgs e)
        {
            long now = stopwatch.ElapsedMilliseconds;
            double dt = (now - lastElapsedMs) / 1000.0;
            lastElapsedMs = now;
            if (dt > 0.05) dt = 0.05; // защита от скачка после сворачивания окна
            if (dt < 0.0) dt = 0.0;

            Tick((float)dt);
            this.Invalidate();
        }

        private void Tick(float dt)
        {
            stateTime += dt;
            globalTime += dt;

            if (state == GameState.Paused)
            {
                return; // на паузе всё замирает
            }

            UpdateEffects(dt);

            if (state == GameState.Playing)
            {
                UpdateMatch(dt);
            }
        }

        private void UpdateMatch(float dt)
        {
            UpdatePlayerPaddle(dt);
            UpdateAiPaddle(dt);

            switch (phase)
            {
                case RallyPhase.Serving:
                    serveTimer -= dt;
                    if (serveTimer <= 0f)
                    {
                        LaunchBall();
                    }
                    break;

                case RallyPhase.Live:
                    MoveBall(dt);
                    break;

                case RallyPhase.PointScored:
                    pointTimer -= dt;
                    if (pointTimer <= 0f)
                    {
                        FinishPoint();
                    }
                    break;
            }
        }

        // ==========================================================
        //  Ракетки
        // ==========================================================
        private static float Approach(float current, float target, float maxDelta)
        {
            if (current < target) return MathF.Min(current + maxDelta, target);
            return MathF.Max(current - maxDelta, target);
        }

        private void UpdatePlayerPaddle(float dt)
        {
            float targetVel = 0f;
            if (IsUpHeld) targetVel -= PaddleMaxSpeed;
            if (IsDownHeld) targetVel += PaddleMaxSpeed;

            leftVel = Approach(leftVel, targetVel, PaddleAccel * dt);
            leftY += leftVel * dt;

            if (leftY < PaddleMinY) { leftY = PaddleMinY; leftVel = 0f; }
            if (leftY > PaddleMaxY) { leftY = PaddleMaxY; leftVel = 0f; }
        }

        private void UpdateAiPaddle(float dt)
        {
            AiProfile ai = CurrentAi;

            aiThinkTimer -= dt;
            if (aiThinkTimer <= 0f)
            {
                aiThinkTimer = ai.ReactDelay;
                float center = (CourtTop + CourtBottom) / 2f;

                if (phase == RallyPhase.Live && ballVX > 0f)
                {
                    bool predict = ai.AlwaysPredict || ballX > CourtCenterX - 100f;
                    float baseTarget = predict ? PredictBallYAtX(RightPaddleX) : ballY;
                    aiTargetY = baseTarget + aiError;
                }
                else
                {
                    // мяч летит от ИИ — медленно возвращаемся к центру
                    aiTargetY = center;
                }
            }

            float paddleCenter = rightY + PaddleHeight / 2f;
            float diff = aiTargetY - paddleCenter;
            float targetVel = 0f;
            if (MathF.Abs(diff) > ai.DeadZone)
            {
                targetVel = MathF.Sign(diff) * MathF.Min(ai.MaxSpeed, MathF.Abs(diff) * 8f);
            }

            rightVel = Approach(rightVel, targetVel, PaddleAccel * dt);
            rightY += rightVel * dt;

            if (rightY < PaddleMinY) { rightY = PaddleMinY; rightVel = 0f; }
            if (rightY > PaddleMaxY) { rightY = PaddleMaxY; rightVel = 0f; }
        }

        // Выбор точки перехвата с ошибкой; иногда ИИ намеренно «промахивается»
        private void AiRollError()
        {
            AiProfile ai = CurrentAi;
            float err = ((float)rng.NextDouble() * 2f - 1f) * ai.Error;

            // «Усталость»: чем длиннее розыгрыш (и выше скорость мяча), тем чаще ИИ ошибается.
            // Это гарантирует, что розыгрыши не тянутся бесконечно даже при идеальной игре соперника.
            float fatigue = MathF.Min(AiFatigueCap, rally * AiFatiguePerHit);

            if (rng.NextDouble() < ai.MistakeChance + fatigue)
            {
                float sign = rng.Next(2) == 0 ? -1f : 1f;
                err = sign * (PaddleHeight / 2f + BallRadius + 18f + (float)rng.NextDouble() * 60f);
            }

            aiError = err;
            aiThinkTimer = MathF.Min(aiThinkTimer, ai.ReactDelay);
        }

        // Предсказание Y мяча на вертикали x с учётом отскоков от верхней и нижней границ
        private float PredictBallYAtX(float targetX)
        {
            if (ballVX <= 0.01f) return ballY;

            float t = (targetX - ballX) / ballVX;
            if (t < 0f) return ballY;

            float y = ballY + ballVY * t;
            float top = CourtTop + BallRadius;
            float bottom = CourtBottom - BallRadius;
            float h = bottom - top;
            float period = 2f * h;

            float rel = (y - top) % period;
            if (rel < 0f) rel += period;
            if (rel > h) rel = period - rel;
            return top + rel;
        }

        // ==========================================================
        //  Движение мяча и столкновения (шагами по ≤ 4 px: без «туннелирования»)
        // ==========================================================
        private void MoveBall(float dt)
        {
            float dist = ballSpeed * dt;
            int steps = (int)MathF.Ceiling(dist / MaxStepPx);
            if (steps < 1) steps = 1;
            if (steps > 64) steps = 64;
            float h = dt / steps;

            for (int i = 0; i < steps; i++)
            {
                ballX += ballVX * h;
                ballY += ballVY * h;

                ResolveWalls();
                ResolvePaddles();

                if (CheckGoal())
                {
                    return;
                }
            }

            AddTrailPoint();
        }

        private void ResolveWalls()
        {
            if (ballY - BallRadius < CourtTop)
            {
                ballY = CourtTop + BallRadius;
                if (ballVY < 0f)
                {
                    ballVY = -ballVY;
                    OnWallHit(ballX, CourtTop);
                }
            }
            else if (ballY + BallRadius > CourtBottom)
            {
                ballY = CourtBottom - BallRadius;
                if (ballVY > 0f)
                {
                    ballVY = -ballVY;
                    OnWallHit(ballX, CourtBottom);
                }
            }
        }

        private void ResolvePaddles()
        {
            if (ballVX < 0f)
            {
                TryPaddleHit(true);
            }
            else if (ballVX > 0f)
            {
                TryPaddleHit(false);
            }
        }

        private void TryPaddleHit(bool isLeft)
        {
            float px = isLeft ? LeftPaddleX : RightPaddleX;
            float py = isLeft ? leftY : rightY;
            float pvel = isLeft ? leftVel : rightVel;

            // Пересечение круга (мяч) с прямоугольником (ракетка)
            float cx = Math.Clamp(ballX, px, px + PaddleWidth);
            float cy = Math.Clamp(ballY, py, py + PaddleHeight);
            float dx = ballX - cx;
            float dy = ballY - cy;
            if (dx * dx + dy * dy > BallRadius * BallRadius)
            {
                return;
            }

            // Центр мяча дальше «бьющей» грани ракетки?
            bool inFront = isLeft ? ballX > px + PaddleWidth : ballX < px;

            if (!inFront)
            {
                bool insideThickness = ballX >= px && ballX <= px + PaddleWidth;
                if (!insideThickness)
                {
                    return; // мяч уже за ракеткой — промах, пусть летит
                }

                // Касание верхнего/нижнего торца ракетки: отскок по вертикали
                float paddleMid = py + PaddleHeight / 2f;
                float minVy = 0.35f * ballSpeed;
                if (ballY < paddleMid)
                {
                    ballY = py - BallRadius;
                    ballVY = -MathF.Max(MathF.Abs(ballVY), minVy);
                }
                else
                {
                    ballY = py + PaddleHeight + BallRadius;
                    ballVY = MathF.Max(MathF.Abs(ballVY), minVy);
                }
                RenormalizeBall();
                return;
            }

            // Основной случай: удар по рабочей грани ракетки
            ballX = isLeft ? px + PaddleWidth + BallRadius : px - BallRadius;

            float rel = (ballY - (py + PaddleHeight / 2f)) / (PaddleHeight / 2f + BallRadius * 0.5f);
            rel = Math.Clamp(rel, -1f, 1f);

            float angle = rel * MaxBounceAngle
                        + Math.Clamp(pvel / PaddleMaxSpeed, -1f, 1f) * PaddleVelInfluence;
            angle = Math.Clamp(angle, -MaxBounceAngle, MaxBounceAngle);

            ballSpeed = MathF.Min(ballSpeed + BallSpeedStep, BallMaxSpeed);
            float dir = isLeft ? 1f : -1f;
            ballVX = dir * ballSpeed * MathF.Cos(angle);
            ballVY = ballSpeed * MathF.Sin(angle);

            rally++;
            OnPaddleHit(isLeft);

            if (isLeft)
            {
                AiRollError();
            }
        }

        private void RenormalizeBall()
        {
            float mag = MathF.Sqrt(ballVX * ballVX + ballVY * ballVY);
            if (mag < 0.0001f)
            {
                ballVX = serveDir * ballSpeed;
                ballVY = 0f;
                return;
            }
            float k = ballSpeed / mag;
            ballVX *= k;
            ballVY *= k;
        }

        private bool CheckGoal()
        {
            if (ballX < CourtLeft + 6f)
            {
                OnPoint(false);
                return true;
            }
            if (ballX > CourtRight - 6f)
            {
                OnPoint(true);
                return true;
            }
            return false;
        }

        // ==========================================================
        //  Очки, партии, матч
        // ==========================================================
        private void OnPoint(bool leftScored)
        {
            phase = RallyPhase.PointScored;
            pointTimer = PointDelay;
            lastPointLeftScored = leftScored;

            if (leftScored)
            {
                scoreL++;
                pulseL = 1f;
            }
            else
            {
                scoreR++;
                pulseR = 1f;
            }

            if (rally > bestRally) bestRally = rally;
            rally = 0;

            Color teamColor = leftScored ? Color.FromArgb(255, 70, 70) : Color.FromArgb(80, 235, 70);
            float exitX = leftScored ? CourtRight : CourtLeft;
            SpawnBurst(exitX, Math.Clamp(ballY, CourtTop, CourtBottom), teamColor, 26, 140f, 460f);
            SpawnRing(exitX, Math.Clamp(ballY, CourtTop, CourtBottom), teamColor, 120f);
            SpawnCrowdFlashes(14);

            flashColor = teamColor;
            flashTimer = 0.35f;

            Play(leftScored ? sndScore : sndLose);
        }

        private void FinishPoint()
        {
            bool gameWon = scoreL >= PointsToWinGame || scoreR >= PointsToWinGame;
            if (!gameWon)
            {
                // подача — тому, кто проиграл очко
                PrepareServe(lastPointLeftScored ? 1 : -1);
                return;
            }

            bool leftWonGame = scoreL > scoreR;
            lastGameWonByLeft = leftWonGame;
            if (leftWonGame) gamesL++; else gamesR++;

            if (gamesL >= GamesToWinMatch || gamesR >= GamesToWinMatch)
            {
                matchWonByLeft = gamesL > gamesR;
                EnterState(GameState.MatchOver);
                Play(matchWonByLeft ? sndWin : sndLose);
            }
            else
            {
                EnterState(GameState.GameBreak);
                Play(leftWonGame ? sndWin : sndLose);
            }
        }

        // ==========================================================
        //  Эффекты
        // ==========================================================
        private void OnPaddleHit(bool isLeft)
        {
            float x = isLeft ? LeftPaddleX + PaddleWidth : RightPaddleX;
            Color c = isLeft ? Color.FromArgb(255, 110, 100) : Color.FromArgb(120, 255, 100);
            SpawnBurst(x, ballY, c, 10, 80f, 260f);
            SpawnBurst(x, ballY, Color.White, 5, 60f, 200f);
            SpawnRing(x, ballY, Color.FromArgb(200, 230, 255), 46f);

            if (isLeft) leftHitFlash = 1f; else rightHitFlash = 1f;
            Play(sndHit);
        }

        private void OnWallHit(float x, float y)
        {
            SpawnBurst(x, y, Color.FromArgb(150, 210, 255), 5, 50f, 160f);
            Play(sndWall);
        }

        private void SpawnBurst(float x, float y, Color color, int count, float minSpeed, float maxSpeed)
        {
            for (int i = 0; i < count; i++)
            {
                double angle = rng.NextDouble() * Math.PI * 2.0;
                float speed = minSpeed + (float)rng.NextDouble() * (maxSpeed - minSpeed);
                float life = 0.28f + (float)rng.NextDouble() * 0.3f;
                particles.Add(new Particle
                {
                    X = x,
                    Y = y,
                    VX = MathF.Cos((float)angle) * speed,
                    VY = MathF.Sin((float)angle) * speed,
                    Life = life,
                    MaxLife = life,
                    Size = 3f + rng.Next(0, 3),
                    Color = color,
                    IsRing = false
                });
            }
        }

        private void SpawnRing(float x, float y, Color color, float maxSize)
        {
            particles.Add(new Particle
            {
                X = x,
                Y = y,
                Life = 0.32f,
                MaxLife = 0.32f,
                Size = maxSize,
                Color = color,
                IsRing = true
            });
        }

        // Вспышки фотокамер на трибунах при забитом очке
        private void SpawnCrowdFlashes(int count)
        {
            for (int i = 0; i < count; i++)
            {
                float x = 40f + (float)rng.NextDouble() * (DesignWidth - 80f);
                float y = 250f + (float)rng.NextDouble() * 280f;
                float life = 0.15f + (float)rng.NextDouble() * 0.45f;
                particles.Add(new Particle
                {
                    X = x,
                    Y = y,
                    Life = life,
                    MaxLife = life,
                    Size = 4f + rng.Next(0, 3),
                    Color = Color.FromArgb(255, 255, 235),
                    IsRing = false
                });
            }
        }

        private void AddTrailPoint()
        {
            trail.Add(new TrailPoint { X = ballX, Y = ballY, Age = 0f });
            if (trail.Count > 22)
            {
                trail.RemoveAt(0);
            }
        }

        private void UpdateEffects(float dt)
        {
            for (int i = particles.Count - 1; i >= 0; i--)
            {
                Particle p = particles[i];
                p.X += p.VX * dt;
                p.Y += p.VY * dt;
                p.VX *= 0.96f;
                p.VY *= 0.96f;
                p.Life -= dt;
                if (p.Life <= 0f)
                {
                    particles.RemoveAt(i);
                }
            }

            for (int i = trail.Count - 1; i >= 0; i--)
            {
                trail[i].Age += dt;
                if (trail[i].Age > 0.24f)
                {
                    trail.RemoveAt(i);
                }
            }

            pulseL = MathF.Max(0f, pulseL - dt * 2.2f);
            pulseR = MathF.Max(0f, pulseR - dt * 2.2f);
            flashTimer = MathF.Max(0f, flashTimer - dt);
            leftHitFlash = MathF.Max(0f, leftHitFlash - dt * 6f);
            rightHitFlash = MathF.Max(0f, rightHitFlash - dt * 6f);
        }
    }
}
