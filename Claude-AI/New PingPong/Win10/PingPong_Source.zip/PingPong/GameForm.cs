using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Media;
using System.Windows.Forms;

namespace PingPong
{
    // Состояния игры
    public enum GameState
    {
        Start,      // стартовый экран
        Playing,    // идёт матч
        Paused,     // пауза
        GameBreak,  // конец партии (матч продолжается)
        MatchOver   // конец матча: WIN / LOSE
    }

    // Фаза розыгрыша внутри состояния Playing
    public enum RallyPhase
    {
        Serving,     // мяч стоит в центре, короткая задержка перед подачей
        Live,        // мяч в игре
        PointScored  // очко забито, короткая пауза с эффектами
    }

    public enum Difficulty
    {
        Easy = 0,
        Normal = 1,
        Hard = 2
    }

    // Частица эффекта (искра или расширяющееся кольцо)
    public class Particle
    {
        public float X, Y, VX, VY;
        public float Life, MaxLife;
        public float Size;
        public Color Color;
        public bool IsRing;
    }

    // Точка шлейфа за мячом
    public class TrailPoint
    {
        public float X, Y, Age;
    }

    // Параметры «характера» компьютерного соперника
    public class AiProfile
    {
        public float MaxSpeed;       // максимальная скорость ракетки, px/с
        public float ReactDelay;     // период «обдумывания», с
        public float Error;          // разброс точки перехвата, px
        public float MistakeChance;  // вероятность намеренной ошибки на каждый удар игрока
        public float DeadZone;       // зона нечувствительности, px
        public bool AlwaysPredict;   // предсказывать траекторию с самого начала полёта мяча
    }

    // Главное окно игры Ping-Pong
    public partial class GameForm : Form
    {
        // ==========================================================
        //  Логический размер холста (16:9); окно масштабируется под него
        // ==========================================================
        private const int DesignWidth = 1280;
        private const int DesignHeight = 720;

        // ==========================================================
        //  Корт (границы, в которых летает мяч)
        // ==========================================================
        private const float CourtLeft = 60f;
        private const float CourtRight = 1220f;
        private const float CourtTop = 146f;
        private const float CourtBottom = 596f;
        private const float CourtCenterX = 640f;
        private const float CourtCenterY = 371f;

        // ==========================================================
        //  Ракетки
        // ==========================================================
        private const float PaddleWidth = 16f;
        private const float PaddleHeight = 104f;
        private const float PaddleInset = 44f;
        private const float LeftPaddleX = CourtLeft + PaddleInset;                          // 104
        private const float RightPaddleX = CourtRight - PaddleInset - PaddleWidth;          // 1160
        private const float PaddleMinY = CourtTop + 4f;
        private const float PaddleMaxY = CourtBottom - 4f - PaddleHeight;
        private const float PaddleMaxSpeed = 540f;   // px/с
        private const float PaddleAccel = 7000f;     // px/с²  (плавный разгон и торможение)

        // ==========================================================
        //  Мяч
        // ==========================================================
        private const float BallRadius = 10f;
        private const float BallBaseSpeed = 430f;    // скорость подачи, px/с
        private const float BallSpeedStep = 28f;     // прибавка скорости за каждый удар по мячу
        private const float BallMaxSpeed = 980f;
        private const float MaxBounceAngle = 1.05f;  // ~60°: максимальный угол отскока от ракетки
        private const float PaddleVelInfluence = 0.12f;
        private const float MaxStepPx = 4f;          // шаг физики: мяч за раз сдвигается не более чем на 4 px

        // ==========================================================
        //  «Усталость» ИИ в длинных розыгрышах
        // ==========================================================
        private const float AiFatiguePerHit = 0.012f; // +1.2% шанса ошибки за каждый удар в розыгрыше
        private const float AiFatigueCap = 0.35f;     // но не больше +35%

        // ==========================================================
        //  Формат матча
        // ==========================================================
        private const int PointsToWinGame = 5;       // очков для победы в партии
        private const int GamesToWinMatch = 3;       // партий для победы в матче
        private const float ServeDelay = 1.1f;       // задержка перед подачей, с
        private const float PointDelay = 0.95f;      // пауза после забитого очка, с

        // ==========================================================
        //  Состояние игры
        // ==========================================================
        private GameState state = GameState.Start;
        private RallyPhase phase = RallyPhase.Serving;
        private Difficulty difficulty = Difficulty.Normal;
        private double stateTime;   // время в текущем состоянии (для плавных переходов)
        private double globalTime;  // общее время (для миганий и пульсаций)

        private float ballX, ballY, ballVX, ballVY, ballSpeed;
        private float leftY, leftVel, rightY, rightVel;

        private int scoreL, scoreR;      // очки в текущей партии (слева — игрок)
        private int gamesL, gamesR;      // выигранные партии
        private int rally, bestRally;    // текущий розыгрыш и лучший за сессию (в ударах)

        private float serveTimer, pointTimer;
        private int serveDir = 1;        // +1 — подача вправо (к компьютеру), -1 — влево (к игроку)
        private bool lastPointLeftScored;
        private bool lastGameWonByLeft;
        private bool matchWonByLeft;

        // Визуальные эффекты
        private float pulseL, pulseR;            // «пульс» цифры счёта
        private float flashTimer;                // вспышка экрана при очке
        private Color flashColor = Color.White;
        private float leftHitFlash, rightHitFlash;

        // ИИ
        private float aiTargetY, aiError, aiThinkTimer;
        private AiProfile[] aiProfiles = new AiProfile[3];

        private readonly List<Particle> particles = new List<Particle>();
        private readonly List<TrailPoint> trail = new List<TrailPoint>();
        private readonly HashSet<Keys> keysDown = new HashSet<Keys>();
        private readonly Random rng = new Random();

        private readonly Stopwatch stopwatch = new Stopwatch();
        private readonly System.Windows.Forms.Timer gameTimer;
        private long lastElapsedMs;

        private Bitmap? backgroundBitmap;

        public GameForm()
        {
            this.Text = "Ping-Pong";
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.MaximizeBox = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Black;
            this.KeyPreview = true;
            this.AutoScaleMode = AutoScaleMode.None;

            // Начальный размер 1280x720, но не больше доступной области экрана
            Rectangle workArea = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
            double fit = Math.Min(1.0, Math.Min((workArea.Width - 40) / (double)DesignWidth,
                                                (workArea.Height - 80) / (double)DesignHeight));
            fit = Math.Max(fit, 0.5);
            this.ClientSize = new Size((int)(DesignWidth * fit), (int)(DesignHeight * fit));
            this.MinimumSize = new Size(640, 400);

            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw,
                true);

            InitAiProfiles();
            InitFonts();
            backgroundBitmap = BuildBackground();
            InitSounds();

            ResetMatchState();

            this.KeyDown += GameForm_KeyDown;
            this.KeyUp += GameForm_KeyUp;
            this.Paint += GameForm_Paint;
            this.Deactivate += (s, e) => keysDown.Clear(); // потеря фокуса не должна «залипать» клавиши

            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 10; // реальная частота ~64 Гц; время считается по Stopwatch
            gameTimer.Tick += GameTimer_Tick;

            stopwatch.Start();
            lastElapsedMs = 0;
            gameTimer.Start();
        }

        // ==========================================================
        //  Освобождение ресурсов
        // ==========================================================
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                gameTimer?.Stop();
                gameTimer?.Dispose();
                backgroundBitmap?.Dispose();
                DisposeFonts();
                DisposeSounds();
            }
            base.Dispose(disposing);
        }
    }
}
