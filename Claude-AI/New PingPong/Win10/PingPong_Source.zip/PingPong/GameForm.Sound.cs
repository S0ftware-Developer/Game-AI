using System;
using System.Collections.Generic;
using System.IO;
using System.Media;

namespace PingPong
{
    public partial class GameForm
    {
        private SoundPlayer? sndHit;
        private SoundPlayer? sndWall;
        private SoundPlayer? sndScore;
        private SoundPlayer? sndLose;
        private SoundPlayer? sndWin;
        private SoundPlayer? sndStart;
        private SoundPlayer? sndPause;
        private bool soundEnabled = true;

        // Все звуки генерируются кодом (квадратная волна, как в аркадных автоматах).
        // Если звуковая подсистема недоступна — игра просто работает без звука.
        private void InitSounds()
        {
            try
            {
                sndHit = CreateSound(new[] { (880.0, 45) }, 0.30);
                sndWall = CreateSound(new[] { (440.0, 35) }, 0.25);
                sndScore = CreateSound(new[] { (660.0, 70), (880.0, 70), (1175.0, 120) }, 0.30);
                sndLose = CreateSound(new[] { (330.0, 90), (262.0, 90), (196.0, 180) }, 0.30);
                sndWin = CreateSound(new[] { (523.0, 90), (659.0, 90), (784.0, 90), (1047.0, 240) }, 0.30);
                sndStart = CreateSound(new[] { (523.0, 60), (784.0, 110) }, 0.28);
                sndPause = CreateSound(new[] { (600.0, 40), (450.0, 50) }, 0.22);
            }
            catch (Exception)
            {
                sndHit = sndWall = sndScore = sndLose = sndWin = sndStart = sndPause = null;
            }
        }

        private void Play(SoundPlayer? player)
        {
            if (!soundEnabled || player == null) return;
            try
            {
                player.Play(); // асинхронно, не блокирует игровой цикл
            }
            catch (Exception)
            {
                // звук не критичен для игры
            }
        }

        private void DisposeSounds()
        {
            sndHit?.Dispose();
            sndWall?.Dispose();
            sndScore?.Dispose();
            sndLose?.Dispose();
            sndWin?.Dispose();
            sndStart?.Dispose();
            sndPause?.Dispose();
        }

        // Собирает WAV (16 бит, моно, 22050 Гц) из последовательности нот (частота Гц, длительность мс)
        private static SoundPlayer CreateSound((double Freq, int Ms)[] notes, double volume)
        {
            const int sampleRate = 22050;
            var samples = new List<short>();

            foreach (var note in notes)
            {
                int count = sampleRate * note.Ms / 1000;
                for (int i = 0; i < count; i++)
                {
                    double t = i / (double)sampleRate;
                    double attack = Math.Min(1.0, i / (sampleRate * 0.004));
                    double release = Math.Min(1.0, (count - i) / (sampleRate * 0.015));
                    double env = attack * release;

                    double sine = Math.Sin(2.0 * Math.PI * note.Freq * t);
                    double square = sine >= 0 ? 1.0 : -1.0;
                    double v = (0.65 * square + 0.35 * sine) * env * volume;

                    samples.Add((short)(v * short.MaxValue));
                }
            }

            int dataLength = samples.Count * 2;
            var stream = new MemoryStream();
            using (var writer = new BinaryWriter(stream, System.Text.Encoding.ASCII, true))
            {
                writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
                writer.Write(36 + dataLength);
                writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"));
                writer.Write(System.Text.Encoding.ASCII.GetBytes("fmt "));
                writer.Write(16);                 // размер блока fmt
                writer.Write((short)1);           // PCM
                writer.Write((short)1);           // моно
                writer.Write(sampleRate);
                writer.Write(sampleRate * 2);     // байт в секунду
                writer.Write((short)2);           // выравнивание блока
                writer.Write((short)16);          // бит на сэмпл
                writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));
                writer.Write(dataLength);
                foreach (short s in samples)
                {
                    writer.Write(s);
                }
            }

            stream.Position = 0;
            var player = new SoundPlayer(stream);
            player.Load();
            return player;
        }
    }
}
