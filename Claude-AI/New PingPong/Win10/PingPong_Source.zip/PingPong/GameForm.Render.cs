using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PingPong
{
    public partial class GameForm
    {
        // ==========================================================
        //  Шрифты
        // ==========================================================
        private FontFamily titleFamily = null!;
        private FontFamily monoFamily = null!;
        private Font fontLabel = null!;
        private Font fontText = null!;
        private Font fontSmall = null!;
        private Font fontFooter = null!;

        private void InitFonts()
        {
            titleFamily = PickFamily("Arial Black", "Impact", "Segoe UI Black", "Consolas");
            monoFamily = PickFamily("Consolas", "Courier New", "Lucida Console");

            fontLabel = new Font(monoFamily, 24f, SafeStyle(monoFamily), GraphicsUnit.Pixel);
            fontText = new Font(monoFamily, 21f, SafeStyle(monoFamily), GraphicsUnit.Pixel);
            fontSmall = new Font(monoFamily, 16f, SafeStyle(monoFamily), GraphicsUnit.Pixel);
            fontFooter = new Font(monoFamily, 18f, SafeStyle(monoFamily), GraphicsUnit.Pixel);
        }

        private void DisposeFonts()
        {
            fontLabel?.Dispose();
            fontText?.Dispose();
            fontSmall?.Dispose();
            fontFooter?.Dispose();
            titleFamily?.Dispose();
            monoFamily?.Dispose();
        }

        private static FontFamily PickFamily(params string[] names)
        {
            FontFamily[] installed = FontFamily.Families;
            foreach (string name in names)
            {
                foreach (FontFamily family in installed)
                {
                    if (string.Equals(family.Name, name, StringComparison.OrdinalIgnoreCase))
                    {
                        return new FontFamily(name);
                    }
                }
            }
            return FontFamily.GenericMonospace;
        }

        // Некоторые гарнитуры (например, Arial Black) не имеют отдельного Bold — выбираем доступный стиль
        private static FontStyle SafeStyle(FontFamily family)
        {
            FontStyle[] candidates = { FontStyle.Bold, FontStyle.Regular, FontStyle.Italic, FontStyle.Bold | FontStyle.Italic };
            foreach (FontStyle style in candidates)
            {
                if (family.IsStyleAvailable(style)) return style;
            }
            return FontStyle.Regular;
        }

        // ==========================================================
        //  Вспомогательные функции рисования
        // ==========================================================
        private static Color Ac(Color c, float alpha)
        {
            return Color.FromArgb(Math.Clamp((int)(c.A * alpha), 0, 255), c);
        }

        private static float Smooth(float t)
        {
            t = Math.Clamp(t, 0f, 1f);
            return t * t * (3f - 2f * t);
        }

        private static GraphicsPath RoundedRect(RectangleF rect, float radius)
        {
            var path = new GraphicsPath();
            float d = Math.Min(radius * 2f, Math.Min(rect.Width, rect.Height));
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        private static StringFormat CreateTypographicFormat()
        {
            var sf = new StringFormat(StringFormat.GenericTypographic);
            sf.FormatFlags |= StringFormatFlags.MeasureTrailingSpaces | StringFormatFlags.NoWrap;
            return sf;
        }

        private static float MeasureTextWidth(Graphics g, string text, Font font, StringFormat sf)
        {
            return g.MeasureString(text, font, PointF.Empty, sf).Width;
        }

        private static GraphicsPath BuildTextPath(FontFamily family, string text, float pixelSize)
        {
            var path = new GraphicsPath();
            path.AddString(text, family, (int)SafeStyle(family), pixelSize, PointF.Empty, StringFormat.GenericTypographic);
            return path;
        }

        // Неоновая панель HUD: свечение, градиентная заливка, двойная рамка
        private static void DrawNeonPanel(Graphics g, RectangleF r, float radius, Color border, float alpha)
        {
            for (int i = 3; i >= 1; i--)
            {
                using (var pen = new Pen(Ac(Color.FromArgb(14 + (4 - i) * 6, border), alpha), 4f + i * 4f) { LineJoin = LineJoin.Round })
                using (var path = RoundedRect(r, radius))
                {
                    g.DrawPath(pen, path);
                }
            }

            using (var path = RoundedRect(r, radius))
            using (var fill = new LinearGradientBrush(r, Ac(Color.FromArgb(235, 10, 26, 84), alpha),
                       Ac(Color.FromArgb(240, 4, 10, 46), alpha), LinearGradientMode.Vertical))
            using (var pen = new Pen(Ac(border, alpha), 4f) { LineJoin = LineJoin.Round })
            {
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
            }

            using (var hiPath = RoundedRect(RectangleF.Inflate(r, -5f, -5f), Math.Max(2f, radius - 4f)))
            using (var hiPen = new Pen(Ac(Color.FromArgb(120, 160, 210, 255), alpha), 1.2f))
            {
                g.DrawPath(hiPen, hiPath);
            }
        }

        // Крупный логотип/заголовок с градиентом, обводкой и тенью; вписывается в maxW x maxH
        private void DrawTitleText(Graphics g, string text, float cx, float cy, float maxW, float maxH,
            Color top, Color bottom, Color outline, bool shadow, float alpha)
        {
            using (GraphicsPath path = BuildTextPath(titleFamily, text, 100f))
            {
                RectangleF b = path.GetBounds();
                if (b.Width <= 0f || b.Height <= 0f) return;

                float k = MathF.Min(maxW / b.Width, maxH / b.Height);
                using (var m = new Matrix())
                {
                    m.Translate(-(b.X + b.Width / 2f), -(b.Y + b.Height / 2f));
                    m.Scale(k, k, MatrixOrder.Append);
                    m.Translate(cx, cy, MatrixOrder.Append);
                    path.Transform(m);
                }
                RectangleF nb = path.GetBounds();

                if (shadow)
                {
                    using (var shadowPath = (GraphicsPath)path.Clone())
                    using (var sm = new Matrix())
                    using (Brush shadowBrush = new SolidBrush(Ac(Color.FromArgb(200, 0, 0, 30), alpha)))
                    {
                        sm.Translate(3f, 4f);
                        shadowPath.Transform(sm);
                        g.FillPath(shadowBrush, shadowPath);
                    }
                }

                using (var pen = new Pen(Ac(outline, alpha), MathF.Max(3f, k * 9f)) { LineJoin = LineJoin.Round })
                {
                    g.DrawPath(pen, path);
                }
                using (var fill = new LinearGradientBrush(nb, Ac(top, alpha), Ac(bottom, alpha), LinearGradientMode.Vertical))
                {
                    g.FillPath(fill, path);
                }
            }
        }

        // Текст с обводкой, выровненный по центру точки (cx, cy)
        private static void DrawOutlinedText(Graphics g, FontFamily family, string text, float pixelSize,
            float cx, float cy, Color fill, Color outline, float outlineWidth)
        {
            using (GraphicsPath path = BuildTextPath(family, text, pixelSize))
            {
                RectangleF b = path.GetBounds();
                using (var m = new Matrix())
                {
                    m.Translate(cx - (b.X + b.Width / 2f), cy - (b.Y + b.Height / 2f));
                    path.Transform(m);
                }

                using (var pen = new Pen(outline, outlineWidth) { LineJoin = LineJoin.Round })
                using (Brush brush = new SolidBrush(fill))
                {
                    g.DrawPath(pen, path);
                    g.FillPath(brush, path);
                }
            }
        }

        private static void DrawCenteredText(Graphics g, string text, Font font, Color color, float cx, float cy)
        {
            using (StringFormat sf = CreateTypographicFormat())
            using (Brush shadow = new SolidBrush(Color.FromArgb((int)(color.A * 0.6f), 0, 6, 30)))
            using (Brush brush = new SolidBrush(color))
            {
                float w = MeasureTextWidth(g, text, font, sf);
                float x = cx - w / 2f;
                float y = cy - font.Height / 2f;
                g.DrawString(text, font, shadow, x + 1.5f, y + 1.5f, sf);
                g.DrawString(text, font, brush, x, y, sf);
            }
        }

        private static void DrawLeftText(Graphics g, string text, Font font, Color color, float x, float cy)
        {
            using (StringFormat sf = CreateTypographicFormat())
            using (Brush shadow = new SolidBrush(Color.FromArgb((int)(color.A * 0.6f), 0, 6, 30)))
            using (Brush brush = new SolidBrush(color))
            {
                float y = cy - font.Height / 2f;
                g.DrawString(text, font, shadow, x + 1.5f, y + 1.5f, sf);
                g.DrawString(text, font, brush, x, y, sf);
            }
        }

        private static void DrawRightText(Graphics g, string text, Font font, Color color, float rightX, float cy)
        {
            using (StringFormat sf = CreateTypographicFormat())
            {
                float w = MeasureTextWidth(g, text, font, sf);
                DrawLeftText(g, text, font, color, rightX - w, cy);
            }
        }

        // ==========================================================
        //  Главный обработчик отрисовки (масштабирование с сохранением 16:9)
        // ==========================================================
        private void GameForm_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.Black);

            float scale = Math.Min(
                this.ClientSize.Width / (float)DesignWidth,
                this.ClientSize.Height / (float)DesignHeight);
            if (scale <= 0f) return;

            float offX = (this.ClientSize.Width - DesignWidth * scale) / 2f;
            float offY = (this.ClientSize.Height - DesignHeight * scale) / 2f;
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);

            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

            if (backgroundBitmap != null)
            {
                g.DrawImage(backgroundBitmap, 0, 0, DesignWidth, DesignHeight);
            }

            DrawFloodlightPulse(g);
            DrawHudDynamic(g);
            DrawBarrierText(g);
            DrawCourtObjects(g);
            DrawStateOverlay(g);
            DrawScoreFlash(g);
        }

        // Лёгкая пульсация света прожекторов поверх статического фона
        private void DrawFloodlightPulse(Graphics g)
        {
            int alpha = (int)(16 + 10 * Math.Sin(globalTime * 2.2));
            float[,] centers = { { 96f, 172f }, { 258f, 198f }, { 1184f, 172f }, { 1022f, 198f } };
            using (Brush brush = new SolidBrush(Color.FromArgb(alpha, 190, 220, 255)))
            {
                for (int i = 0; i < 4; i++)
                {
                    g.FillEllipse(brush, centers[i, 0] - 52f, centers[i, 1] - 40f, 104f, 80f);
                }
            }
        }

        // ==========================================================
        //  Динамическая часть HUD: счёт, партии, лучший розыгрыш
        // ==========================================================
        private void DrawHudDynamic(Graphics g)
        {
            float leftCx = HudLeftPanel.X + HudLeftPanel.Width / 2f;
            float rightCx = HudRightPanel.X + HudRightPanel.Width / 2f;

            DrawCenteredText(g, "PLAYER 1", fontLabel, Color.White, leftCx, 36f);
            DrawCenteredText(g, "COMPUTER", fontLabel, Color.White, rightCx, 36f);

            DrawScoreNumber(g, scoreL, leftCx, 84f, Color.FromArgb(25, 205, 255), pulseL);
            DrawScoreNumber(g, scoreR, rightCx, 84f, Color.FromArgb(70, 235, 40), pulseR);

            DrawGameDots(g, HudLeftIcon.X + HudLeftIcon.Width / 2f, 104f, gamesL, RedTeam);
            DrawGameDots(g, HudRightIcon.X + HudRightIcon.Width / 2f, 104f, gamesR, GreenTeam);

            DrawCenteredText(g, "BEST: " + bestRally, fontText, Color.FromArgb(200, 222, 255), CourtCenterX, 106f);
        }

        private void DrawScoreNumber(Graphics g, int value, float cx, float cy, Color color, float pulse)
        {
            float size = 62f * (1f + 0.35f * Smooth(pulse));
            DrawOutlinedText(g, monoFamily, value.ToString("00"), size, cx, cy, color, Color.FromArgb(0, 36, 84), 7f);
        }

        // Три точки под иконкой ракетки: выигранные партии
        private void DrawGameDots(Graphics g, float cx, float cy, int won, Color teamColor)
        {
            for (int i = 0; i < GamesToWinMatch; i++)
            {
                float x = cx + (i - (GamesToWinMatch - 1) / 2f) * 28f;
                bool filled = i < won;
                using (Brush brush = new SolidBrush(filled ? teamColor : Color.FromArgb(60, 66, 92)))
                using (var pen = new Pen(filled ? Color.FromArgb(255, 255, 255, 255) : Color.FromArgb(110, 120, 150), 1.6f))
                {
                    g.FillEllipse(brush, x - 7f, cy - 7f, 14f, 14f);
                    g.DrawEllipse(pen, x - 7f, cy - 7f, 14f, 14f);
                }
                if (filled)
                {
                    using (Brush glint = new SolidBrush(Color.FromArgb(150, 255, 255, 255)))
                    {
                        g.FillEllipse(glint, x - 4f, cy - 5f, 5f, 4f);
                    }
                }
            }
        }

        // Подсказки на синем бортике (ненавязчивые)
        private void DrawBarrierText(Graphics g)
        {
            Color c = Color.FromArgb(205, 220, 238, 255);
            DrawLeftText(g, "W / S или стрелки — движение   ·   P — пауза   ·   R — рестарт   ·   M — звук",
                fontSmall, c, 70f, 623f);
            DrawRightText(g, "Сложность ИИ: " + DifficultyName(difficulty) + "  [1/2/3]", fontSmall, c, 1210f, 623f);
        }

        private static string DifficultyName(Difficulty d)
        {
            switch (d)
            {
                case Difficulty.Easy: return "ЛЕГКО";
                case Difficulty.Hard: return "СЛОЖНО";
                default: return "СРЕДНЕ";
            }
        }

        // ==========================================================
        //  Ракетки, мяч, шлейф, эффекты
        // ==========================================================
        private void DrawCourtObjects(Graphics g)
        {
            DrawPaddle(g, LeftPaddleX, leftY, true, leftHitFlash);
            DrawPaddle(g, RightPaddleX, rightY, false, rightHitFlash);

            bool ballVisible = phase != RallyPhase.PointScored;
            if (ballVisible)
            {
                DrawTrail(g);
                DrawBall(g);
                if (state == GameState.Playing && phase == RallyPhase.Serving)
                {
                    DrawServeIndicator(g);
                }
            }

            DrawParticles(g);
        }

        private void DrawPaddle(Graphics g, float x, float y, bool isLeft, float flash)
        {
            Color light = isLeft ? Color.FromArgb(255, 100, 90) : Color.FromArgb(125, 255, 100);
            Color dark = isLeft ? Color.FromArgb(185, 10, 24) : Color.FromArgb(22, 150, 32);
            Color glow = isLeft ? Color.FromArgb(255, 60, 70) : Color.FromArgb(70, 235, 60);

            var bar = new RectangleF(x, y, PaddleWidth, PaddleHeight);

            // Свечение вокруг ракетки (усиливается при ударе)
            for (int i = 3; i >= 1; i--)
            {
                int alpha = (int)(14 + flash * 26) ;
                using (Brush glowBrush = new SolidBrush(Color.FromArgb(alpha, glow)))
                using (var glowPath = RoundedRect(RectangleF.Inflate(bar, i * 4f, i * 4f), 7f + i * 3f))
                {
                    g.FillPath(glowBrush, glowPath);
                }
            }

            // Деревянная ручка с внешней стороны
            float handleY = y + PaddleHeight / 2f - 8f;
            var handle = isLeft
                ? new RectangleF(x - 13f, handleY, 15f, 16f)
                : new RectangleF(x + PaddleWidth - 2f, handleY, 15f, 16f);
            using (var woodBrush = new LinearGradientBrush(handle, Color.FromArgb(220, 150, 70), Color.FromArgb(150, 90, 36), LinearGradientMode.Vertical))
            using (var woodPen = new Pen(Color.FromArgb(60, 30, 10), 2f))
            {
                g.FillRectangle(woodBrush, handle);
                g.DrawRectangle(woodPen, handle.X, handle.Y, handle.Width, handle.Height);
            }

            // Красная/зелёная резиновая накладка
            using (var path = RoundedRect(bar, 7f))
            using (var brush = new LinearGradientBrush(bar, light, dark, LinearGradientMode.Horizontal))
            using (var pen = new Pen(Color.FromArgb(40, 0, 10), 2.2f) { LineJoin = LineJoin.Round })
            {
                g.FillPath(brush, path);
                g.DrawPath(pen, path);

                if (flash > 0f)
                {
                    using (Brush flashBrush = new SolidBrush(Color.FromArgb((int)(150 * flash), 255, 255, 255)))
                    {
                        g.FillPath(flashBrush, path);
                    }
                }
            }

            using (Brush glint = new SolidBrush(Color.FromArgb(120, 255, 255, 255)))
            using (var glintPath = RoundedRect(new RectangleF(x + 3f, y + 9f, 3f, PaddleHeight - 30f), 1.5f))
            {
                g.FillPath(glint, glintPath);
            }
        }

        private void DrawTrail(Graphics g)
        {
            foreach (TrailPoint tp in trail)
            {
                float k = 1f - tp.Age / 0.24f;
                if (k <= 0f) continue;
                float r = BallRadius * (0.35f + 0.6f * k);
                using (Brush brush = new SolidBrush(Color.FromArgb((int)(120 * k), 130, 185, 255)))
                {
                    g.FillEllipse(brush, tp.X - r, tp.Y - r, r * 2f, r * 2f);
                }
            }
        }

        private void DrawBall(Graphics g)
        {
            float pulse = phase == RallyPhase.Serving ? 1f + 0.12f * MathF.Sin((float)globalTime * 10f) : 1f;
            float r = BallRadius * pulse;
            var rect = new RectangleF(ballX - r, ballY - r, r * 2f, r * 2f);

            float glowR = 30f;
            using (var glowPath = new GraphicsPath())
            {
                glowPath.AddEllipse(ballX - glowR, ballY - glowR, glowR * 2f, glowR * 2f);
                using (var glow = new PathGradientBrush(glowPath))
                {
                    glow.CenterColor = Color.FromArgb(120, 190, 220, 255);
                    glow.SurroundColors = new[] { Color.FromArgb(0, 150, 200, 255) };
                    g.FillPath(glow, glowPath);
                }
            }

            using (var body = new LinearGradientBrush(rect, Color.White, Color.FromArgb(160, 198, 255), LinearGradientMode.ForwardDiagonal))
            using (var outline = new Pen(Color.FromArgb(18, 40, 120), 2f))
            {
                g.FillEllipse(body, rect);
                g.DrawEllipse(outline, rect);
            }
            using (Brush glint = new SolidBrush(Color.FromArgb(210, 255, 255, 255)))
            {
                g.FillEllipse(glint, ballX - r * 0.55f, ballY - r * 0.62f, r * 0.55f, r * 0.4f);
            }
        }

        // Кольцо и стрелки, показывающие, куда будет подан мяч
        private void DrawServeIndicator(Graphics g)
        {
            float progress = Math.Clamp(serveTimer / ServeDelay, 0f, 1f);
            float ringR = BallRadius + 8f + 34f * progress;
            using (var ringPen = new Pen(Color.FromArgb((int)(210 * (1f - 0.5f * progress)), 160, 210, 255), 2.5f))
            {
                g.DrawEllipse(ringPen, ballX - ringR, ballY - ringR, ringR * 2f, ringR * 2f);
            }

            for (int k = 0; k < 2; k++)
            {
                float px = ballX + serveDir * (34f + k * 18f);
                int alpha = (int)(Math.Clamp(110 + 110 * Math.Sin(globalTime * 8.0 - k * 1.2), 0, 255));
                PointF[] chevron =
                {
                    new PointF(px + serveDir * 8f, ballY),
                    new PointF(px - serveDir * 3f, ballY - 9f),
                    new PointF(px - serveDir * 3f, ballY + 9f)
                };
                using (Brush brush = new SolidBrush(Color.FromArgb(alpha, 190, 225, 255)))
                {
                    g.FillPolygon(brush, chevron);
                }
            }
        }

        private void DrawParticles(Graphics g)
        {
            foreach (Particle p in particles)
            {
                float life = Math.Clamp(p.Life / p.MaxLife, 0f, 1f);
                if (p.IsRing)
                {
                    float prog = 1f - life;
                    float rad = p.Size * prog;
                    if (rad < 1f) continue;
                    using (var pen = new Pen(Color.FromArgb((int)(200 * life), p.Color), 1f + 3f * life))
                    {
                        g.DrawEllipse(pen, p.X - rad, p.Y - rad, rad * 2f, rad * 2f);
                    }
                }
                else
                {
                    float size = p.Size * (0.5f + 0.5f * life);
                    using (Brush brush = new SolidBrush(Color.FromArgb((int)(255 * life), p.Color)))
                    {
                        g.FillRectangle(brush, p.X - size / 2f, p.Y - size / 2f, size, size);
                    }
                }
            }
        }

        private void DrawScoreFlash(Graphics g)
        {
            if (flashTimer <= 0f) return;
            float k = flashTimer / 0.35f;
            using (Brush brush = new SolidBrush(Color.FromArgb((int)(80 * k), flashColor)))
            {
                g.FillRectangle(brush, CourtLeft, CourtTop, CourtRight - CourtLeft, CourtBottom - CourtTop);
            }
        }

        // ==========================================================
        //  Экраны состояний (плавное появление)
        // ==========================================================
        private void DrawDim(Graphics g, float alpha)
        {
            using (Brush brush = new SolidBrush(Color.FromArgb((int)(150 * alpha), 3, 6, 28)))
            {
                g.FillRectangle(brush, CourtLeft, CourtTop, CourtRight - CourtLeft, CourtBottom - CourtTop);
            }
        }

        private float BlinkFactor()
        {
            return 0.62f + 0.38f * MathF.Sin((float)globalTime * 5f);
        }

        private void DrawStateOverlay(Graphics g)
        {
            float a = Smooth((float)(stateTime / 0.35));
            float blink = BlinkFactor();
            Color white = Color.White;
            Color dark = Color.FromArgb(8, 24, 70);

            switch (state)
            {
                case GameState.Start:
                    DrawDim(g, a);
                    DrawTitleText(g, "PING-PONG", CourtCenterX, 224f, 720f, 116f, LogoTop, LogoBottom, LogoOutline, true, a);
                    DrawOutlinedText(g, monoFamily, "PRESS SPACE TO START", 36f, CourtCenterX, 312f,
                        Ac(white, a * blink), Ac(dark, a * blink), 6f);
                    DrawCenteredText(g, "Матч: до " + GamesToWinMatch + " побед в партиях  ·  партия до " + PointsToWinGame + " очков",
                        fontSmall, Ac(Color.FromArgb(200, 222, 255), a), CourtCenterX, 346f);
                    DrawControlsPanel(g, new RectangleF(390f, 366f, 500f, 152f), a);
                    DrawDifficultySelector(g, 568f, a);
                    break;

                case GameState.Paused:
                    DrawDim(g, a);
                    DrawTitleText(g, "PAUSED", CourtCenterX, 214f, 520f, 104f,
                        Color.FromArgb(245, 250, 255), Color.FromArgb(150, 200, 255), Color.FromArgb(20, 60, 140), true, a);
                    DrawOutlinedText(g, monoFamily, "PRESS P TO RESUME", 34f, CourtCenterX, 300f,
                        Ac(white, a * blink), Ac(dark, a * blink), 6f);
                    DrawControlsPanel(g, new RectangleF(390f, 340f, 500f, 152f), a);
                    DrawDifficultySelector(g, 568f, a);
                    break;

                case GameState.GameBreak:
                    DrawDim(g, a);
                    if (lastGameWonByLeft)
                    {
                        DrawTitleText(g, "GAME WON!", CourtCenterX, 236f, 640f, 110f,
                            Color.FromArgb(150, 255, 120), Color.FromArgb(30, 170, 50), Color.FromArgb(10, 70, 20), true, a);
                    }
                    else
                    {
                        DrawTitleText(g, "GAME LOST", CourtCenterX, 236f, 640f, 110f,
                            Color.FromArgb(255, 120, 110), Color.FromArgb(200, 20, 40), Color.FromArgb(80, 0, 10), true, a);
                    }
                    DrawOutlinedText(g, monoFamily, "GAMES  " + gamesL + " : " + gamesR, 54f, CourtCenterX, 336f,
                        Ac(white, a), Ac(dark, a), 8f);
                    DrawOutlinedText(g, monoFamily, "PRESS SPACE FOR NEXT GAME", 32f, CourtCenterX, 430f,
                        Ac(white, a * blink), Ac(dark, a * blink), 6f);
                    break;

                case GameState.MatchOver:
                    DrawDim(g, a);
                    if (matchWonByLeft)
                    {
                        DrawTitleText(g, "YOU WIN!", CourtCenterX, 226f, 640f, 124f,
                            Color.FromArgb(255, 240, 120), Color.FromArgb(255, 170, 30), Color.FromArgb(130, 70, 0), true, a);
                    }
                    else
                    {
                        DrawTitleText(g, "YOU LOSE", CourtCenterX, 226f, 640f, 124f,
                            Color.FromArgb(255, 120, 110), Color.FromArgb(200, 20, 40), Color.FromArgb(80, 0, 10), true, a);
                    }
                    DrawOutlinedText(g, monoFamily, "GAMES  " + gamesL + " : " + gamesR, 54f, CourtCenterX, 324f,
                        Ac(white, a), Ac(dark, a), 8f);
                    DrawOutlinedText(g, monoFamily, "BEST RALLY: " + bestRally, 26f, CourtCenterX, 378f,
                        Ac(Color.FromArgb(200, 222, 255), a), Ac(dark, a), 5f);
                    DrawOutlinedText(g, monoFamily, "PRESS R TO RESTART", 36f, CourtCenterX, 448f,
                        Ac(white, a * blink), Ac(dark, a * blink), 6f);
                    break;
            }
        }

        // Панель «Управление:» в стиле референса (с клавишами и стрелками)
        private void DrawControlsPanel(Graphics g, RectangleF r, float a)
        {
            DrawNeonPanel(g, r, 12f, NeonBlue, a);

            Color textColor = Ac(Color.White, a);
            DrawLeftText(g, "Управление:", fontLabel, textColor, r.X + 28f, r.Y + 26f);

            DrawKeyCap(g, r.X + 62f, r.Y + 66f, "W", a);
            DrawArrowCap(g, r.X + 106f, r.Y + 66f, true, a);
            DrawLeftText(g, "Ракетка вверх", fontText, textColor, r.X + 150f, r.Y + 66f);

            DrawKeyCap(g, r.X + 62f, r.Y + 104f, "S", a);
            DrawArrowCap(g, r.X + 106f, r.Y + 104f, false, a);
            DrawLeftText(g, "Ракетка вниз", fontText, textColor, r.X + 150f, r.Y + 104f);

            DrawLeftText(g, "P — пауза     R — рестарт     Esc — выход", fontSmall,
                Ac(Color.FromArgb(200, 222, 255), a), r.X + 28f, r.Y + 136f);
        }

        private void DrawKeyCap(Graphics g, float cx, float cy, string label, float a)
        {
            DrawCapBase(g, cx, cy, a);
            DrawCenteredText(g, label, fontText, Ac(Color.White, a), cx, cy);
        }

        private void DrawArrowCap(Graphics g, float cx, float cy, bool up, float a)
        {
            DrawCapBase(g, cx, cy, a);

            float s = up ? -1f : 1f;
            PointF[] head =
            {
                new PointF(cx, cy + s * 10f),
                new PointF(cx - 9f, cy + s * 0f),
                new PointF(cx + 9f, cy + s * 0f)
            };
            using (Brush brush = new SolidBrush(Ac(Color.White, a)))
            {
                g.FillPolygon(brush, head);
                g.FillRectangle(brush, cx - 3f, up ? cy : cy - 9f, 6f, 9f);
            }
        }

        private static void DrawCapBase(Graphics g, float cx, float cy, float a)
        {
            var rect = new RectangleF(cx - 18f, cy - 16f, 36f, 32f);
            using (var path = RoundedRect(rect, 7f))
            using (var fill = new LinearGradientBrush(rect, Ac(Color.FromArgb(40, 78, 170), a), Ac(Color.FromArgb(14, 30, 94), a), LinearGradientMode.Vertical))
            using (var pen = new Pen(Ac(Color.FromArgb(140, 195, 255), a), 2f))
            {
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
            }
        }

        // Выбор сложности ИИ (клавиши 1/2/3)
        private void DrawDifficultySelector(Graphics g, float cy, float a)
        {
            DrawCenteredText(g, "Сложность ИИ — клавиши 1 / 2 / 3", fontSmall,
                Ac(Color.FromArgb(200, 222, 255), a), CourtCenterX, cy - 26f);

            string[] names = { "1  ЛЕГКО", "2  СРЕДНЕ", "3  СЛОЖНО" };
            const float w = 150f;
            const float gap = 14f;
            float x0 = CourtCenterX - (3f * w + 2f * gap) / 2f;

            for (int i = 0; i < 3; i++)
            {
                bool selected = (int)difficulty == i;
                var rect = new RectangleF(x0 + i * (w + gap), cy - 16f, w, 32f);

                Color topColor = selected ? Color.FromArgb(70, 168, 255) : Color.FromArgb(12, 28, 78);
                Color bottomColor = selected ? Color.FromArgb(30, 100, 222) : Color.FromArgb(8, 18, 54);
                Color borderColor = selected ? Color.White : Color.FromArgb(70, 125, 205);

                using (var path = RoundedRect(rect, 9f))
                using (var fill = new LinearGradientBrush(rect, Ac(topColor, a), Ac(bottomColor, a), LinearGradientMode.Vertical))
                using (var pen = new Pen(Ac(borderColor, a), 2f))
                {
                    g.FillPath(fill, path);
                    g.DrawPath(pen, path);
                }

                DrawCenteredText(g, names[i], fontSmall,
                    Ac(selected ? Color.White : Color.FromArgb(160, 195, 240), a),
                    rect.X + rect.Width / 2f, rect.Y + rect.Height / 2f);
            }
        }
    }
}
