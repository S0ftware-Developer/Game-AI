namespace DoodleJump;

internal readonly record struct ScoreEntry(int Score, string Date);

/// <summary>
/// Top-10 table: %LocalAppData%\DoodleJump\highscores.txt, one "score|date" line per entry.
/// The file is never next to the .exe and is not needed to start the game. The single-number file of the
/// previous version (highscore.txt) is imported once if the new table does not exist yet.
/// </summary>
internal static class HighScoreStore
{
    public const int MaxEntries = 10;

    private static readonly string Dir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DoodleJump");
    private static readonly string TablePath = Path.Combine(Dir, "highscores.txt");
    private static readonly string LegacyPath = Path.Combine(Dir, "highscore.txt");

    public static List<ScoreEntry> Load()
    {
        var list = new List<ScoreEntry>();
        try
        {
            if (File.Exists(TablePath))
            {
                foreach (string line in File.ReadAllLines(TablePath))
                {
                    string[] parts = line.Split('|');
                    if (parts.Length >= 1 && int.TryParse(parts[0].Trim(), out int s) && s > 0)
                        list.Add(new ScoreEntry(s, parts.Length > 1 ? parts[1].Trim() : ""));
                }
            }
            else if (File.Exists(LegacyPath) && int.TryParse(File.ReadAllText(LegacyPath).Trim(), out int old) && old > 0)
            {
                list.Add(new ScoreEntry(old, ""));
            }
        }
        catch { /* missing or broken file -> empty table */ }

        list.Sort((a, b) => b.Score.CompareTo(a.Score));
        if (list.Count > MaxEntries) list.RemoveRange(MaxEntries, list.Count - MaxEntries);
        return list;
    }

    public static void Save(List<ScoreEntry> list)
    {
        try
        {
            Directory.CreateDirectory(Dir);
            File.WriteAllLines(TablePath, list.Select(e => e.Score + "|" + e.Date));
        }
        catch { /* the game works without the file */ }
    }
}
