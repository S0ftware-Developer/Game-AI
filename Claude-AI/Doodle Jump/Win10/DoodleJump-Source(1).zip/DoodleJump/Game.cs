using System.Drawing;

namespace DoodleJump;

internal enum GameState { Menu, Playing, Paused, GameOver, Scores }
internal enum PlatformType { Normal, Break, Move, Vanish, Explode, Teleport }
internal enum BonusKind { Propeller, Jetpack, Rocket }

internal sealed class Platform
{
    public float X, Y, W;                      // X = left edge, Y = top surface (world coordinates, Y grows upwards)
    public PlatformType Type;
    public float BaseX, Amp, Omega, Phase;     // moving platforms: X = BaseX + Amp * sin(Time * Omega + Phase)
    public bool Broken, Gone;
    public float BreakT;                       // seconds since it broke
    public bool HasSpring;                     // trampoline on top
    public float SpringT = 1f;                 // spring animation 0..1
    public float VanishT = -1f;                // >= 0: fading away after a jump
    public float FuseT = -1f;                  // >= 0: explosive platform is burning
}

internal sealed class Pickup { public float X, Y; public BonusKind Kind; public bool Taken; }

internal sealed class Monster
{
    public float X, Y, BaseX, Amp, Omega, Phase, Hit;
    public int Kind, Hp;
    public bool Dead;
}

internal sealed class Ufo
{
    public float X, Y, BaseX, Amp, Omega, Phase, Hit, Grab;
    public int Hp = 4;
    public bool Dead;
}

internal sealed class BlackHole { public float X, Y, R; }

internal sealed class Bullet
{
    public float X, Y, VX, VY, Life;
    public bool Dead;
}

internal sealed class Particle
{
    public float X, Y, VX, VY, Life, MaxLife, Size;
    public int Kind;                           // 0 dot, 1 sparkle, 2 chip of a broken platform
    public Color Color;
}

/// <summary>
/// Pure game logic (no drawing). ONE world coordinate system: Y grows upwards, the start platform is at StartY.
/// The camera only stores CamY = world Y of the bottom edge of the view; the renderer converts world -> screen with
/// screenY = H - (worldY - CamY). Platforms and enemies never move because of the camera.
/// </summary>
internal sealed class Game
{
    public const float W = 480f, H = 800f;          // logical view size
    public const float PlatH = 16f;
    public const float StartY = 120f;
    public const float MaxVX = 340f;
    public const float HalfBody = 22f;
    public const float FootHalf = 14f;
    public const float WorldHeight = 4500f;         // a new "world" (theme, monsters, costume) every 4500 px of height
    public const float DeathDur = 1.1f;

    private const float Gravity = 1900f;            // px/s^2
    private const float JumpV = 930f;               // jump height = JumpV^2 / (2 G) ~ 228 px
    private const float SpringV = 1500f;            // trampoline: ~590 px
    private const float MaxJumpH = JumpV * JumpV / (2f * Gravity);
    private const float Accel = 2600f, Friction = 2000f;
    private const float SquashTime = 0.16f;
    private const float BulletSpeed = 900f, ShotInterval = 0.2f;
    private const int MaxParticles = 170;

    // ---------- state read by the renderer ----------
    public GameState State = GameState.Menu;
    public int Score, BonusScore, Rank = -1;
    public bool NewBest;
    public float Time, CamY, MaxY = StartY;
    public float PX = W / 2f, PY = StartY, VX, VY, Squash, ShootT;
    public int Face = 1;
    public bool Dead;
    public int DeathKind;                          // 1 fell, 2 monster, 3 black hole, 4 UFO, 5 explosion
    public float DeathTimer, DeathX, DeathY;
    public BonusKind? Bonus;
    public float BonusT, BonusTotal;
    public string BannerText = "";
    public float BannerTimer;

    public readonly List<Platform> Platforms = new();
    public readonly List<Pickup> Pickups = new();
    public readonly List<Monster> Monsters = new();
    public readonly List<Ufo> Ufos = new();
    public readonly List<BlackHole> Holes = new();
    public readonly List<Bullet> Bullets = new();
    public readonly List<Particle> Particles = new();
    public readonly List<ScoreEntry> Scores;
    public Action<string>? Sound;

    public int Best { get { return Scores.Count > 0 ? Scores[0].Score : 0; } }
    public int WorldIndex { get { return (int)(Math.Max(0f, MaxY - StartY) / WorldHeight); } }
    public float WorldBlend                         // 0..1 during the last 10% of a world: colours fade to the next one
    {
        get
        {
            float pos = Math.Max(0f, MaxY - StartY) / WorldHeight;
            float frac = pos - (float)Math.Floor(pos);
            return frac > 0.9f ? (frac - 0.9f) / 0.1f : 0f;
        }
    }

    // ---------- input (set by the window) ----------
    public bool Left, Right, FireUp;

    private readonly Random rng = new();
    private float genY, prevCX, shotCooldown, camBoost, exhaustT;
    private float hazardNextY, ufoNextY, holeNextY;
    private bool prevSpecial, recordPlayed, committed;
    private int startBest, lastWorld;

    public Game()
    {
        Scores = HighScoreStore.Load();
        SetupMenu();
    }

    private float Rand() { return (float)rng.NextDouble(); }
    private static float Lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float Clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
    public static float Mod(float a, float b) { return a - b * (float)Math.Floor(a / b); }

    // =====================================================================
    //  Flow
    // =====================================================================
    private void ClearWorld()
    {
        Platforms.Clear(); Pickups.Clear(); Monsters.Clear(); Ufos.Clear(); Holes.Clear(); Bullets.Clear(); Particles.Clear();
    }

    private void SetupMenu()
    {
        ClearWorld();
        CamY = 0; VX = 0; Squash = 0; Dead = false; Bonus = null; MaxY = StartY;
        // the hero bounces on the middle platform; the others are decoration
        Platforms.Add(new Platform { X = 195, Y = 280, W = 90, Type = PlatformType.Normal });
        Platforms.Add(new Platform { X = 46, Y = 370, W = 84, Type = PlatformType.Normal, HasSpring = true });
        Platforms.Add(new Platform { X = 340, Y = 430, W = 84, Type = PlatformType.Move, BaseX = 340, Amp = 40, Omega = 1.4f });
        Platforms.Add(new Platform { X = 60, Y = 480, W = 84, Type = PlatformType.Vanish });
        Platforms.Add(new Platform { X = 330, Y = 320, W = 84, Type = PlatformType.Break });
        PX = W / 2f; PY = 280; VY = JumpV;
    }

    public void StartNewGame()
    {
        ClearWorld();
        Score = 0; BonusScore = 0; NewBest = false; Rank = -1; recordPlayed = false; committed = false; startBest = Best;
        CamY = 0; MaxY = StartY; Squash = 0; ShootT = 0; Dead = false; DeathKind = 0; Bonus = null;
        PX = W / 2f; PY = StartY; VX = 0; VY = JumpV; Face = 1;
        shotCooldown = 0; camBoost = 0; exhaustT = 0;
        hazardNextY = 1400f; ufoNextY = 3000f; holeNextY = 2200f; prevSpecial = false;
        lastWorld = 0; BannerText = "WORLD 1"; BannerTimer = 1.8f;
        Platforms.Add(new Platform { X = W / 2f - 60f, Y = StartY, W = 120f, Type = PlatformType.Normal });
        genY = StartY; prevCX = W / 2f;
        GenerateUpTo(CamY + H + 850f);
        State = GameState.Playing;
    }

    public void GoMenu()
    {
        CommitScore();
        SetupMenu();
        State = GameState.Menu;
    }

    public void ShowScores() { State = GameState.Scores; }

    public void TogglePause()
    {
        if (State == GameState.Playing) State = GameState.Paused;
        else if (State == GameState.Paused) State = GameState.Playing;
    }

    public void ClearInput() { Left = Right = FireUp = false; }

    /// <summary>Puts the current score into the Top-10 table (once per game).</summary>
    public int CommitScore()
    {
        if (committed || Score <= 0) return Rank;
        committed = true;
        var entry = new ScoreEntry(Score, DateTime.Now.ToString("yyyy-MM-dd"));
        int idx = Scores.FindIndex(s => Score > s.Score);
        if (idx < 0) idx = Scores.Count;
        if (idx >= HighScoreStore.MaxEntries) { Rank = -1; return Rank; }
        Scores.Insert(idx, entry);
        if (Scores.Count > HighScoreStore.MaxEntries) Scores.RemoveAt(HighScoreStore.MaxEntries);
        HighScoreStore.Save(Scores);
        Rank = idx;
        return Rank;
    }

    private void EndGame(int kind)
    {
        DeathKind = kind;
        State = GameState.GameOver;
        NewBest = Score > startBest && Score > 0;
        CommitScore();
        Sound?.Invoke("over");
    }

    // =====================================================================
    //  Update
    // =====================================================================
    public void Update(float dt)
    {
        switch (State)
        {
            case GameState.Menu:
                Time += dt;
                UpdatePlatforms(dt);
                StepPlayer(dt, false);
                UpdateParticles(dt);
                break;
            case GameState.Playing:
                UpdatePlaying(dt);
                break;
            case GameState.GameOver:
                Time += dt;
                UpdateParticles(dt);
                break;
        }
    }

    private void UpdatePlaying(float dt)
    {
        Time += dt;
        if (BannerTimer > 0f) BannerTimer -= dt;
        if (shotCooldown > 0f) shotCooldown -= dt;
        if (ShootT > 0f) ShootT -= dt;
        if (camBoost > 0f) camBoost -= dt;
        UpdatePlatforms(dt);
        UpdateParticles(dt);

        if (Dead) { UpdateDying(dt); return; }

        if (FireUp) ShootDirection(0f, 1f);
        StepPlayer(dt, true);
        UpdateBullets(dt);
        UpdateEnemies(dt);
        if (!Dead) UpdatePickups();
        UpdateScore();
        UpdateCamera(dt);
        GenerateUpTo(CamY + H + 850f);
        Cull();

        if (!Dead && PY < CamY - 50f) EndGame(1);           // fell below the bottom of the view
    }

    private void Cull()
    {
        // forget everything that is far below the camera (keeps memory and CPU flat)
        Platforms.RemoveAll(p => p.Gone || p.Y < CamY - 140f || (p.Broken && p.BreakT > 2f) || p.VanishT > 0.45f);
        Pickups.RemoveAll(p => p.Taken || p.Y < CamY - 200f);
        Monsters.RemoveAll(m => m.Dead || m.Y < CamY - 200f);
        Ufos.RemoveAll(u => u.Dead || u.Y < CamY - 260f);
        Holes.RemoveAll(h => h.Y < CamY - 200f);
    }

    private void UpdatePlatforms(float dt)
    {
        foreach (var p in Platforms)
        {
            if (p.Type == PlatformType.Move && !p.Broken)
                p.X = p.BaseX + p.Amp * (float)Math.Sin(Time * p.Omega + p.Phase);
            if (p.Broken) p.BreakT += dt;
            if (p.SpringT < 1f) p.SpringT = Math.Min(1f, p.SpringT + dt * 4f);
            if (p.VanishT >= 0f) p.VanishT += dt;
            if (p.FuseT >= 0f && !p.Gone)
            {
                p.FuseT += dt;
                if (p.FuseT >= 0.85f && State == GameState.Playing) Detonate(p);
            }
        }
    }

    private void Detonate(Platform p)
    {
        p.Gone = true;
        float cx = p.X + p.W / 2f;
        for (int i = 0; i < 16; i++)
            AddParticle(0, cx + (Rand() - 0.5f) * p.W, p.Y, (Rand() - 0.5f) * 420f, Rand() * 320f, 0.5f + Rand() * 0.4f,
                5f + Rand() * 6f, i % 2 == 0 ? Color.FromArgb(255, 120, 40) : Color.FromArgb(255, 210, 70));
        Sound?.Invoke("boom");
        if (!Dead && Bonus == null)
        {
            float dx = PX - cx, dy = (PY + 30f) - p.Y;
            if (dx * dx + dy * dy < 75f * 75f) Die(5, PX, PY);          // lingering next to a bomb is dangerous
        }
    }

    // =====================================================================
    //  Hero
    // =====================================================================
    private void StepPlayer(float dt, bool control)
    {
        // ----- horizontal: smooth acceleration towards the wanted speed -----
        int dir = control ? (Right ? 1 : 0) - (Left ? 1 : 0) : 0;
        float target = dir * MaxVX;
        float acc = (dir != 0 ? Accel : Friction) * dt;
        if (VX < target) VX = Math.Min(target, VX + acc);
        else if (VX > target) VX = Math.Max(target, VX - acc);
        if (dir != 0) Face = dir;
        else if (Math.Abs(VX) > 25f) Face = VX > 0 ? 1 : -1;

        PX += VX * dt;
        if (PX < -HalfBody) PX += W + 2f * HalfBody;            // fully gone left  -> appears right
        else if (PX > W + HalfBody) PX -= W + 2f * HalfBody;     // fully gone right -> appears left

        if (Squash > 0f) Squash -= dt;

        // ----- bonus flight: no gravity, no platform collisions -----
        if (Bonus != null)
        {
            float speed = Bonus == BonusKind.Propeller ? 460f : (Bonus == BonusKind.Jetpack ? 760f : 1050f);
            float k = BonusT < 0.7f ? BonusT / 0.7f : 1f;       // ease out in the last 0.7 s
            VY += (speed * k - VY) * Math.Min(1f, 8f * dt);
            PY += VY * dt;
            BonusT -= dt;
            EmitExhaust(dt);
            if (BonusT <= 0f) { Bonus = null; VY = Math.Min(VY, 300f); }
            return;
        }

        // ----- vertical: gravity + landing check against the top surface only while falling -----
        float prevFeet = PY;
        VY -= Gravity * dt;
        PY += VY * dt;

        if (VY <= 0f)
        {
            Platform? hit = null;
            foreach (var p in Platforms)
            {
                if (p.Broken || p.Gone || p.VanishT >= 0f) continue;
                if (prevFeet >= p.Y - 1f && PY <= p.Y && PX >= p.X - FootHalf && PX <= p.X + p.W + FootHalf)
                    if (hit == null || p.Y > hit.Y) hit = p;      // the highest surface we crossed
            }
            if (hit != null) Land(hit);
        }
    }

    private void Land(Platform p)
    {
        if (p.Type == PlatformType.Break)
        {
            p.Broken = true;                    // the platform crumbles, the hero keeps falling
            p.BreakT = 0f;
            for (int i = 0; i < 8; i++)
                AddParticle(2, p.X + Rand() * p.W, p.Y, (Rand() - 0.5f) * 220f, Rand() * 160f, 0.9f, 4f + Rand() * 4f,
                    Color.FromArgb(176, 112, 60));
            Sound?.Invoke("break");
            return;
        }

        PY = p.Y;
        VY = p.HasSpring ? SpringV : JumpV;     // VY > 0 now: this contact can never trigger a second bounce
        Squash = SquashTime;
        for (int i = 0; i < 7; i++)
            AddParticle(0, PX + (Rand() - 0.5f) * 24f, p.Y, (Rand() - 0.5f) * 280f, 30f + Rand() * 90f, 0.35f + Rand() * 0.25f,
                3f + Rand() * 3f, Color.FromArgb(205, 195, 170));
        for (int i = 0; i < 3; i++)
            AddParticle(1, PX + (Rand() - 0.5f) * 30f, p.Y + 6f, (Rand() - 0.5f) * 120f, 60f + Rand() * 90f, 0.55f, 6f + Rand() * 4f,
                Color.FromArgb(255, 200, 40));

        if (p.HasSpring) { p.SpringT = 0f; Sound?.Invoke("spring"); }
        else { Sound?.Invoke("jump"); Sound?.Invoke("land"); }

        switch (p.Type)
        {
            case PlatformType.Vanish: p.VanishT = 0f; break;                  // disappears after the jump
            case PlatformType.Explode: if (p.FuseT < 0f) p.FuseT = 0f; break; // light the fuse
            case PlatformType.Teleport: if (State == GameState.Playing) Teleport(p); break;
        }
    }

    /// <summary>Teleport platform: the hero reappears on a normal platform 380..800 px higher.</summary>
    private void Teleport(Platform from)
    {
        Platform? target = null;
        foreach (var q in Platforms)
        {
            if (q.Broken || q.Gone || (q.Type != PlatformType.Normal && q.Type != PlatformType.Move)) continue;
            if (q.Y < from.Y + 380f || q.Y > from.Y + 800f) continue;
            if (target == null || q.Y < target.Y) target = q;
        }
        if (target == null) return;                                           // no target yet: ordinary bounce

        for (int i = 0; i < 8; i++)
            AddParticle(1, PX + (Rand() - 0.5f) * 40f, PY + Rand() * 50f, (Rand() - 0.5f) * 160f, 40f + Rand() * 120f, 0.6f, 7f + Rand() * 4f,
                Color.FromArgb(190, 110, 255));
        PX = Clamp(target.X + target.W / 2f, HalfBody, W - HalfBody);
        PY = target.Y;
        VY = JumpV;
        camBoost = 0.6f;
        for (int i = 0; i < 8; i++)
            AddParticle(1, PX + (Rand() - 0.5f) * 40f, PY + Rand() * 50f, (Rand() - 0.5f) * 160f, 40f + Rand() * 120f, 0.6f, 7f + Rand() * 4f,
                Color.FromArgb(190, 110, 255));
        Sound?.Invoke("teleport");
    }

    private void UpdateScore()
    {
        if (PY > MaxY) MaxY = PY;
        Score = (int)((MaxY - StartY) / 4f) + BonusScore;     // height points (new maximum only) + kill bonuses
        if (Score > Best && startBest > 0 && !recordPlayed) { recordPlayed = true; Sound?.Invoke("record"); }

        if (WorldIndex != lastWorld)
        {
            lastWorld = WorldIndex;
            BannerText = "WORLD " + (WorldIndex + 1);
            BannerTimer = 2.2f;
        }
    }

    private void UpdateCamera(float dt)
    {
        // follow upwards only; keep the hero slightly above the middle of the view; never jerk downwards
        float desired = PY - H * 0.5f;
        float rate = camBoost > 0f ? 28f : 12f;
        if (desired > CamY) CamY += (desired - CamY) * (1f - (float)Math.Exp(-rate * dt));
    }

    // ---------- death ----------
    private void Die(int kind, float tx, float ty)
    {
        if (Dead) return;
        Dead = true;
        DeathKind = kind;
        DeathTimer = DeathDur;
        DeathX = tx; DeathY = ty;
        Bonus = null;
        if (kind == 2) { VY = 520f; Sound?.Invoke("kill"); }
        else if (kind == 3) Sound?.Invoke("hole");
        else if (kind == 4) Sound?.Invoke("ufo");
        else { VY = 400f; Sound?.Invoke("boom"); }
    }

    private void UpdateDying(float dt)
    {
        DeathTimer -= dt;
        float k = Math.Min(1f, 7f * dt);
        switch (DeathKind)
        {
            case 3:     // sucked into the black hole
                PX += (DeathX - PX) * k;
                PY += (DeathY - 30f - PY) * k;
                break;
            case 4:     // pulled up into the UFO
                PX += (DeathX - PX) * k;
                PY += (DeathY - 44f - PY) * k;
                break;
            default:    // tumbles down
                VY -= Gravity * dt;
                PY += VY * dt;
                break;
        }
        if (DeathTimer <= 0f) EndGame(DeathKind);
    }

    // =====================================================================
    //  Shooting
    // =====================================================================
    /// <summary>Shoot towards a point on the screen (logical coordinates), e.g. the mouse cursor.</summary>
    public void ShootAt(float screenX, float screenY)
    {
        float wx = screenX, wy = CamY + (H - screenY);
        float dx = wx - PX, dy = wy - (PY + 34f);
        float len = (float)Math.Sqrt(dx * dx + dy * dy);
        if (len < 1f) { dx = 0f; dy = 1f; len = 1f; }
        ShootDirection(dx / len, dy / len);
    }

    private void ShootDirection(float dx, float dy)
    {
        if (State != GameState.Playing || Dead || shotCooldown > 0f || Bullets.Count >= 8) return;
        Bullets.Add(new Bullet { X = PX + dx * 16f, Y = PY + 34f + dy * 16f, VX = dx * BulletSpeed, VY = dy * BulletSpeed, Life = 1.1f });
        shotCooldown = ShotInterval;
        ShootT = 0.14f;
        if (Math.Abs(dx) > 0.2f) Face = dx > 0 ? 1 : -1;
        Sound?.Invoke("shoot");
    }

    private void UpdateBullets(float dt)
    {
        foreach (var b in Bullets)
        {
            b.X += b.VX * dt;
            b.Y += b.VY * dt;
            b.Life -= dt;
            if (b.Life <= 0f || b.X < -40f || b.X > W + 40f || b.Y > CamY + H + 60f || b.Y < CamY - 60f) { b.Dead = true; continue; }

            foreach (var m in Monsters)
            {
                if (m.Dead) continue;
                float dx = b.X - m.X, dy = b.Y - m.Y;
                if (dx * dx + dy * dy > 28f * 28f) continue;
                b.Dead = true;
                m.Hit = 0.15f;
                if (--m.Hp <= 0) KillMonster(m);
                break;
            }
            if (b.Dead) continue;
            foreach (var u in Ufos)
            {
                if (u.Dead) continue;
                if (Math.Abs(b.X - u.X) > 48f || Math.Abs(b.Y - u.Y) > 22f) continue;
                b.Dead = true;
                u.Hit = 0.15f;
                if (--u.Hp <= 0) KillUfo(u);
                break;
            }
        }
        Bullets.RemoveAll(b => b.Dead);
    }

    private void KillMonster(Monster m)
    {
        m.Dead = true;
        BonusScore += 25;
        for (int i = 0; i < 10; i++)
            AddParticle(0, m.X, m.Y, (Rand() - 0.5f) * 360f, (Rand() - 0.3f) * 300f, 0.5f + Rand() * 0.3f, 5f + Rand() * 5f,
                Color.FromArgb(230, 230, 245));
        for (int i = 0; i < 3; i++)
            AddParticle(1, m.X + (Rand() - 0.5f) * 30f, m.Y + (Rand() - 0.5f) * 30f, (Rand() - 0.5f) * 140f, 40f + Rand() * 100f, 0.6f, 8f,
                Color.FromArgb(255, 200, 40));
        Sound?.Invoke("kill");
    }

    private void KillUfo(Ufo u)
    {
        u.Dead = true;
        BonusScore += 100;
        for (int i = 0; i < 24; i++)
            AddParticle(0, u.X + (Rand() - 0.5f) * 60f, u.Y, (Rand() - 0.5f) * 460f, (Rand() - 0.4f) * 380f, 0.5f + Rand() * 0.5f,
                5f + Rand() * 6f, i % 3 == 0 ? Color.FromArgb(120, 230, 120) : Color.FromArgb(190, 196, 215));
        Sound?.Invoke("boom");
    }

    // =====================================================================
    //  Enemies and pickups
    // =====================================================================
    /// <summary>Is the tractor beam of this UFO currently switched on? (1.6 s on, 1.4 s off)</summary>
    public bool BeamOn(Ufo u) { return Mod(Time + u.Phase, 3f) < 1.6f; }

    private void UpdateEnemies(float dt)
    {
        foreach (var m in Monsters)
        {
            m.X = m.BaseX + m.Amp * (float)Math.Sin(Time * m.Omega + m.Phase);
            if (m.Hit > 0f) m.Hit -= dt;
        }
        foreach (var u in Ufos)
        {
            u.X = u.BaseX + u.Amp * (float)Math.Sin(Time * u.Omega + u.Phase);
            if (u.Hit > 0f) u.Hit -= dt;
        }
        if (Dead) return;

        bool protectedHero = Bonus != null;                    // flying with a bonus: nothing can hurt the hero
        float cx = PX, cy = PY + 30f;

        foreach (var m in Monsters)
        {
            if (m.Dead || protectedHero) continue;
            float dx = cx - m.X, dy = cy - m.Y;
            bool above = VY < -80f && PY > m.Y - 4f && PY < m.Y + 44f && Math.Abs(PX - m.X) < 34f;
            if (above)                                         // jumped on its head
            {
                KillMonster(m);
                VY = JumpV * 1.1f;
                Squash = SquashTime;
            }
            else if (dx * dx + dy * dy < 40f * 40f)            // any other contact is fatal
            {
                Die(2, PX, PY);
                return;
            }
        }

        foreach (var u in Ufos)
        {
            if (u.Dead) continue;
            float dyb = u.Y - cy;                              // > 0: the hero is below the UFO
            bool inBeam = !protectedHero && BeamOn(u) && dyb > 6f && dyb < 200f && Math.Abs(cx - u.X) < 18f + dyb * 0.22f;
            if (inBeam)
            {
                u.Grab += dt;
                VY += 3400f * dt;                              // tractor beam pulls the hero up
                if (u.Grab > 0.55f) { Die(4, u.X, u.Y); return; }
            }
            else u.Grab = Math.Max(0f, u.Grab - dt * 1.5f);

            if (!protectedHero && Math.Abs(cx - u.X) < 46f && Math.Abs(cy - u.Y) < 26f) { Die(4, u.X, u.Y); return; }
        }

        foreach (var h in Holes)
        {
            if (protectedHero) break;
            float dx = cx - h.X, dy = cy - h.Y;
            if (dx * dx + dy * dy < (h.R + 6f) * (h.R + 6f)) { Die(3, h.X, h.Y); return; }
        }
    }

    private void UpdatePickups()
    {
        float cx = PX, cy = PY + 30f;
        foreach (var p in Pickups)
        {
            if (p.Taken) continue;
            float dx = cx - p.X, dy = cy - p.Y;
            if (dx * dx + dy * dy > 36f * 36f) continue;
            p.Taken = true;
            Bonus = p.Kind;
            BonusTotal = BonusT = p.Kind == BonusKind.Propeller ? 3.2f : (p.Kind == BonusKind.Jetpack ? 4.2f : 5.5f);
            VY = Math.Max(VY, 200f);
            for (int i = 0; i < 6; i++)
                AddParticle(1, p.X + (Rand() - 0.5f) * 30f, p.Y + (Rand() - 0.5f) * 30f, (Rand() - 0.5f) * 200f, (Rand() - 0.3f) * 200f,
                    0.6f, 8f, Color.FromArgb(255, 200, 40));
            Sound?.Invoke("bonus");
            break;
        }
    }

    private void EmitExhaust(float dt)
    {
        exhaustT -= dt;
        while (exhaustT <= 0f)
        {
            exhaustT += 0.03f;
            if (Bonus == BonusKind.Propeller) continue;
            AddParticle(0, PX - Face * 28f + (Rand() - 0.5f) * 8f, PY + 10f, (Rand() - 0.5f) * 60f, -160f - Rand() * 120f,
                0.3f + Rand() * 0.2f, 6f + Rand() * 4f, Rand() < 0.5f ? Color.FromArgb(255, 150, 40) : Color.FromArgb(255, 220, 90));
        }
    }

    // =====================================================================
    //  Procedural level generation
    // =====================================================================
    /// <summary>
    /// The "main chain" (normal / moving / special platforms) is always reachable: the vertical gap stays under 85% of
    /// the jump height and the horizontal offset under what the hero can fly in the available time. Breakable platforms,
    /// monsters and black holes are placed outside the straight path between two chain platforms, and two special
    /// (single-use) platforms never follow each other, so a route never depends on them.
    /// </summary>
    private void GenerateUpTo(float limit)
    {
        while (genY < limit) AddChainPlatform();
    }

    private void AddChainPlatform()
    {
        float d = Math.Min(1f, genY / 12000f);                   // difficulty 0..1 by height
        float minGap = 70f + 40f * d, maxGap = 110f + 80f * d;   // at most 190 px (< 228 px jump height)
        float gap = minGap + Rand() * (maxGap - minGap);
        float newY = genY + gap;
        float w = Lerp(92f, 66f, d) + Rand() * 14f;
        bool moving = newY > 1500f && Rand() < 0.10f + 0.22f * d;

        float airTime = JumpV / Gravity + (float)Math.Sqrt(Math.Max(0f, 2f * (MaxJumpH * 0.97f - gap) / Gravity));
        float maxDx = MaxVX * airTime * 0.65f * (moving ? 0.7f : 1f);
        float cx = Clamp(prevCX + (Rand() * 2f - 1f) * maxDx, w / 2f + 6f, W - w / 2f - 6f);

        // platform type
        var type = PlatformType.Normal;
        if (moving) type = PlatformType.Move;
        else if (!prevSpecial)
        {
            float r = Rand();
            if (newY > 2600f && r < 0.04f) type = PlatformType.Teleport;
            else if (newY > 2000f && r < 0.09f) type = PlatformType.Explode;
            else if (newY > 1000f && r < 0.16f) type = PlatformType.Vanish;
        }
        prevSpecial = type == PlatformType.Vanish || type == PlatformType.Explode || type == PlatformType.Teleport;

        var p = new Platform { X = cx - w / 2f, Y = newY, W = w, Type = type };
        if (type == PlatformType.Move)
        {
            p.Amp = 55f + Rand() * 30f;
            float baseCX = Clamp(cx, w / 2f + 6f + p.Amp, W - w / 2f - 6f - p.Amp);
            p.BaseX = baseCX - w / 2f;
            p.Omega = (70f + Rand() * 40f) / p.Amp;              // px/s = Amp * Omega
            p.Phase = Rand() * 6.2832f;
            p.X = p.BaseX;
            cx = baseCX;
        }
        if (type == PlatformType.Normal && newY > 500f && Rand() < 0.06f) p.HasSpring = true;
        Platforms.Add(p);

        // propeller hat / jetpack / rocket hovering over the platform
        if (newY > 1800f && Rand() < 0.012f + 0.010f * d)
        {
            float r = Rand();
            var kind = r < 0.5f ? BonusKind.Propeller : (r < 0.85f ? BonusKind.Jetpack : BonusKind.Rocket);
            Pickups.Add(new Pickup { X = cx, Y = newY + 40f, Kind = kind });
        }

        // occasional breakable lure between the previous and the new chain platform
        float pBreak = newY > 800f ? 0.08f + 0.20f * d : 0f;
        if (Rand() < pBreak)
        {
            float bw = 68f + Rand() * 16f;
            Platforms.Add(new Platform
            {
                X = Rand() * (W - bw), Y = genY + gap * (0.35f + Rand() * 0.3f), W = bw, Type = PlatformType.Break
            });
        }

        MaybeAddHazard(newY, gap, cx, d);

        genY = newY;
        prevCX = cx;
    }

    /// <summary>Finds a free vertical strip next to the straight path between two chain platforms.</summary>
    private bool FreeStrip(float a, float b, float margin, out float centre, out float halfWidth)
    {
        float lo = Math.Min(a, b) - margin, hi = Math.Max(a, b) + margin;
        float leftW = lo - 30f, rightW = (W - 30f) - hi;
        bool left = leftW >= 44f, right = rightW >= 44f;
        centre = 0; halfWidth = 0;
        if (!left && !right) return false;
        bool useLeft = left && (!right || Rand() < 0.5f);
        if (useLeft) { centre = 30f + leftW / 2f; halfWidth = leftW / 2f; }
        else { centre = hi + rightW / 2f; halfWidth = rightW / 2f; }
        return true;
    }

    private void MaybeAddHazard(float newY, float gap, float cx, float d)
    {
        if (newY < hazardNextY) return;
        float midY = genY + gap * 0.5f;

        if (newY > ufoNextY && Rand() < 0.10f + 0.10f * d)
        {
            var u = new Ufo { Y = newY + 150f + Rand() * 60f, BaseX = 110f + Rand() * 260f, Amp = 50f + Rand() * 60f,
                Omega = 0.6f + Rand() * 0.4f, Phase = Rand() * 6.2832f };
            u.X = u.BaseX;
            Ufos.Add(u);
            ufoNextY = newY + 2600f; hazardNextY = newY + 500f;
            return;
        }
        if (newY > holeNextY && Rand() < 0.12f + 0.10f * d)
        {
            if (FreeStrip(prevCX, cx, 110f, out float hx, out float hw))
            {
                Holes.Add(new BlackHole { X = hx + (Rand() - 0.5f) * hw * 0.6f, Y = midY, R = 34f });
                holeNextY = newY + 1500f; hazardNextY = newY + 450f;
                return;
            }
        }
        if (newY > 1400f && Rand() < 0.09f + 0.10f * d)
        {
            if (FreeStrip(prevCX, cx, 70f, out float mx, out float mw))
            {
                var m = new Monster
                {
                    Kind = Rand() < 0.5f ? 0 : 1, Hp = newY > 7000f ? 2 : 1, Y = midY, BaseX = mx,
                    Amp = Clamp(mw - 8f, 0f, 45f), Omega = 0.8f + Rand() * 0.8f, Phase = Rand() * 6.2832f
                };
                m.X = m.BaseX;
                Monsters.Add(m);
                hazardNextY = newY + 400f;
            }
        }
    }

    // =====================================================================
    //  Particles
    // =====================================================================
    private void AddParticle(int kind, float x, float y, float vx, float vy, float life, float size, Color c)
    {
        if (Particles.Count >= MaxParticles) return;
        Particles.Add(new Particle { Kind = kind, X = x, Y = y, VX = vx, VY = vy, Life = life, MaxLife = life, Size = size, Color = c });
    }

    private void UpdateParticles(float dt)
    {
        foreach (var p in Particles)
        {
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            if (p.Kind == 2) p.VY -= 900f * dt;                  // chips fall
            else { p.VX *= 0.96f; p.VY *= 0.96f; }
            p.Life -= dt;
        }
        Particles.RemoveAll(p => p.Life <= 0f);
    }
}
