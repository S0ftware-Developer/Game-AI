using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace DoodleJump;

/// <summary>
/// Draws one frame in logical coordinates (480 x 800) in a hand-drawn "notebook page" style.
/// World -> screen: screenY = H - (worldY - CamY). All pens, brushes and fonts are created once.
/// </summary>
internal sealed class Renderer : IDisposable
{
    public const float LW = Game.W, LH = Game.H;
    public static readonly RectangleF BtnPlay = new(127, 650, 226, 66);

    /// <summary>Mouse position in logical coordinates (set by the window) for the aiming cross.</summary>
    public PointF Aim;
    public bool AimVisible;

    private sealed class Cloud { public float X, BaseY, Scale, Parallax; }

    /// <summary>Colours of one "world": page, grid, clouds, hero scarf, monster colours, night sky.</summary>
    private sealed class Theme
    {
        public Color Paper, Grid, Ink, CloudFill, CloudLine, Scarf, Mon1, Mon2;
        public float Night;
        public Theme(Color paper, Color grid, Color ink, Color cloudFill, Color cloudLine, Color scarf, Color mon1, Color mon2, float night)
        { Paper = paper; Grid = grid; Ink = ink; CloudFill = cloudFill; CloudLine = cloudLine; Scarf = scarf; Mon1 = mon1; Mon2 = mon2; Night = night; }
    }

    private static readonly Color InkColor = Color.FromArgb(38, 36, 56);

    private static readonly Theme[] Themes =
    {
        new(Color.FromArgb(252, 244, 226), Color.FromArgb(110, 140, 190), InkColor, Color.FromArgb(244, 249, 255), Color.FromArgb(128, 174, 232), Color.FromArgb(214, 52, 52), Color.FromArgb(70, 130, 230), Color.FromArgb(220, 70, 80), 0f),
        new(Color.FromArgb(214, 238, 246), Color.FromArgb(90, 150, 190), InkColor, Color.FromArgb(255, 255, 255), Color.FromArgb(110, 170, 220), Color.FromArgb(250, 200, 40), Color.FromArgb(40, 180, 170), Color.FromArgb(250, 150, 50), 0f),
        new(Color.FromArgb(255, 226, 200), Color.FromArgb(210, 140, 110), InkColor, Color.FromArgb(255, 244, 232), Color.FromArgb(235, 150, 120), Color.FromArgb(40, 170, 170), Color.FromArgb(150, 80, 200), Color.FromArgb(90, 190, 90), 0f),
        new(Color.FromArgb(26, 32, 68), Color.FromArgb(80, 100, 170), Color.FromArgb(225, 232, 255), Color.FromArgb(60, 72, 130), Color.FromArgb(130, 150, 220), Color.FromArgb(90, 220, 240), Color.FromArgb(240, 100, 170), Color.FromArgb(250, 210, 60), 1f),
        new(Color.FromArgb(255, 230, 244), Color.FromArgb(230, 150, 200), InkColor, Color.FromArgb(255, 250, 255), Color.FromArgb(240, 150, 210), Color.FromArgb(150, 80, 210), Color.FromArgb(90, 200, 110), Color.FromArgb(80, 160, 240), 0f),
        new(Color.FromArgb(226, 246, 236), Color.FromArgb(110, 180, 150), InkColor, Color.FromArgb(250, 255, 252), Color.FromArgb(120, 200, 170), Color.FromArgb(240, 110, 160), Color.FromArgb(230, 80, 60), Color.FromArgb(250, 170, 40), 0f),
    };

    private readonly List<Cloud> clouds = new();
    private readonly float[] starX = new float[70], starY = new float[70];
    private float cam;
    private Color curPaper, curGrid, curInk, curScarf, curMon1, curMon2;
    private float curNight;

    private readonly SolidBrush tmp = new(Color.White);
    private readonly SolidBrush cloudBlue = new(Color.FromArgb(128, 174, 232));
    private readonly SolidBrush cloudWhite = new(Color.FromArgb(244, 249, 255));
    private readonly SolidBrush monBrush = new(Color.White);
    private readonly Pen gridPen = new(Color.FromArgb(70, 110, 140, 190), 1f);
    private readonly Pen ink = new(InkColor, 3.5f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
    private readonly Pen inkThin = new(InkColor, 2.4f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen aimPen = new(Color.FromArgb(200, 214, 52, 52), 2.2f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platOutline = new(Color.FromArgb(40, 44, 36), 20f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platGreen = new(Color.FromArgb(118, 205, 58), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platGreenHi = new(Color.FromArgb(195, 242, 125), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platBrown = new(Color.FromArgb(178, 112, 58), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platBrownHi = new(Color.FromArgb(222, 168, 108), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platBlue = new(Color.FromArgb(78, 168, 240), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platBlueHi = new(Color.FromArgb(180, 224, 255), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platRed = new(Color.FromArgb(226, 72, 62), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platRedHi = new(Color.FromArgb(255, 160, 140), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platPurple = new(Color.FromArgb(152, 92, 222), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platPurpleHi = new(Color.FromArgb(214, 176, 255), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platWhite = new(Color.FromArgb(236, 240, 250), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platWhiteHi = new(Color.FromArgb(255, 255, 255), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platWhiteFade = new(Color.FromArgb(236, 240, 250), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platWhiteHiFade = new(Color.FromArgb(255, 255, 255), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platOutlineFade = new(Color.FromArgb(40, 44, 36), 20f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen crack = new(Color.FromArgb(70, 36, 16), 2.4f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen springPen = new(Color.FromArgb(214, 52, 52), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
    private readonly Pen springPad = new(Color.FromArgb(232, 70, 70), 6f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen hatch = new(Color.FromArgb(150, 128, 176, 232), 1.5f);
    private readonly Pen speedLine = new(Color.FromArgb(120, 90, 96, 130), 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen sparkPen = new(Color.Gold, 2.6f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen hillOutline = new(Color.FromArgb(120, 150, 205), 3f);
    private readonly Pen panelPen = new(InkColor, 4f) { LineJoin = LineJoin.Round };
    private readonly Pen btnOutline = new(InkColor, 4f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen btnFill = new(Color.FromArgb(255, 222, 70), 4f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen scarfPen = new(Color.FromArgb(214, 52, 52), 8f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen flameOuter = new(Color.FromArgb(255, 150, 40), 9f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen flameInner = new(Color.FromArgb(255, 230, 110), 4.5f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen rocketPen = new(Color.FromArgb(222, 60, 60), 16f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen jetPen = new(Color.FromArgb(150, 158, 178), 12f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen toothPen = new(Color.White, 4f) { StartCap = LineCap.Flat, EndCap = LineCap.Flat };
    private readonly Pen holeArc = new(Color.FromArgb(150, 120, 120, 170), 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen helmetPen = new(Color.FromArgb(200, 170, 215, 255), 2.4f);

    private readonly Brush heroBody = new SolidBrush(Color.FromArgb(250, 140, 56));
    private readonly Brush heroBelly = new SolidBrush(Color.FromArgb(255, 210, 152));
    private readonly Brush heroCheek = new SolidBrush(Color.FromArgb(150, 255, 110, 110));
    private readonly Brush leaf = new SolidBrush(Color.FromArgb(96, 196, 72));
    private readonly Brush white = new SolidBrush(Color.White);
    private readonly Brush inkBrush = new SolidBrush(InkColor);
    private readonly Brush yellowBrush = new SolidBrush(Color.FromArgb(255, 214, 60));
    private readonly Brush pinkBrush = new SolidBrush(Color.FromArgb(250, 130, 180));
    private readonly Brush helmetBrush = new SolidBrush(Color.FromArgb(46, 170, 215, 255));
    private readonly Brush partyBrush = new SolidBrush(Color.FromArgb(240, 90, 150));
    private readonly Brush hillFill = new SolidBrush(Color.FromArgb(168, 190, 228));
    private readonly Brush buildFill = new SolidBrush(Color.FromArgb(150, 176, 222));
    private readonly Brush windowBrush = new SolidBrush(Color.FromArgb(110, 138, 196));
    private readonly Brush panelFill = new SolidBrush(Color.FromArgb(255, 252, 240));
    private readonly Brush ufoBody = new SolidBrush(Color.FromArgb(150, 158, 180));
    private readonly Brush ufoDome = new SolidBrush(Color.FromArgb(140, 190, 235, 255));
    private readonly Brush alienBrush = new SolidBrush(Color.FromArgb(110, 210, 90));
    private readonly Brush beamBrush = new SolidBrush(Color.FromArgb(70, 130, 230, 110));
    private readonly Brush holeOuter = new SolidBrush(Color.FromArgb(70, 40, 40, 80));
    private readonly Brush holeMid = new SolidBrush(Color.FromArgb(230, 26, 26, 52));
    private readonly Brush holeCore = new SolidBrush(Color.FromArgb(10, 10, 20));
    private readonly Brush grayBrush = new SolidBrush(Color.FromArgb(160, 166, 186));
    private readonly Brush redBrush = new SolidBrush(Color.FromArgb(222, 60, 60));
    private readonly Brush bombBrush = new SolidBrush(Color.FromArgb(40, 40, 52));

    private static readonly PointF[] PartyHat = { new(-10, -63), new(12, -63), new(1, -94) };
    private readonly PointF[] beamPoly = new PointF[4];

    private readonly Font fScore, fLabel, fTitle, fMid, fSmall, fBtn, fBig, fHead;
    private readonly StringFormat center = new() { Alignment = StringAlignment.Center, FormatFlags = StringFormatFlags.NoWrap };
    private readonly StringFormat near = new() { Alignment = StringAlignment.Near, FormatFlags = StringFormatFlags.NoWrap };
    private readonly StringFormat far = new() { Alignment = StringAlignment.Far, FormatFlags = StringFormatFlags.NoWrap };

    public Renderer()
    {
        string family = PickFamily("Segoe Print", "Comic Sans MS", "Segoe UI", "Arial");
        fScore = MakeFont(family, 38, FontStyle.Bold);
        fLabel = MakeFont(family, 15, FontStyle.Bold);
        fTitle = MakeFont(family, 84, FontStyle.Bold);
        fMid = MakeFont(family, 30, FontStyle.Bold);
        fSmall = MakeFont(family, 18, FontStyle.Regular);
        fBtn = MakeFont(family, 34, FontStyle.Bold);
        fBig = MakeFont(family, 54, FontStyle.Bold);
        fHead = MakeFont(family, 42, FontStyle.Bold);

        var rnd = new Random(9);
        for (int i = 0; i < 9; i++)
            clouds.Add(new Cloud
            {
                X = rnd.Next((int)LW), BaseY = rnd.Next((int)LH + 240), Scale = 0.7f + (float)rnd.NextDouble() * 0.7f,
                Parallax = 0.12f + (float)rnd.NextDouble() * 0.33f
            });
        for (int i = 0; i < starX.Length; i++) { starX[i] = rnd.Next((int)LW); starY[i] = rnd.Next((int)LH); }
    }

    private static string PickFamily(params string[] names)
    {
        foreach (string n in names)
            foreach (var f in FontFamily.Families)
                if (string.Equals(f.Name, n, StringComparison.OrdinalIgnoreCase)) return n;
        return "Arial";
    }

    private static Font MakeFont(string family, float px, FontStyle style)
    {
        try { return new Font(family, px, style, GraphicsUnit.Pixel); }
        catch { return new Font("Arial", px, style, GraphicsUnit.Pixel); }
    }

    public void Dispose()
    {
        foreach (var d in new IDisposable[]
        {
            tmp, cloudBlue, cloudWhite, monBrush, gridPen, ink, inkThin, aimPen, platOutline, platGreen, platGreenHi, platBrown,
            platBrownHi, platBlue, platBlueHi, platRed, platRedHi, platPurple, platPurpleHi, platWhite, platWhiteHi, platWhiteFade, platWhiteHiFade, platOutlineFade,
            crack, springPen, springPad, hatch, speedLine, sparkPen, hillOutline, panelPen, btnOutline, btnFill, scarfPen, flameOuter,
            flameInner, rocketPen, jetPen, toothPen, holeArc, helmetPen, heroBody, heroBelly, heroCheek, leaf, white, inkBrush,
            yellowBrush, pinkBrush, helmetBrush, partyBrush, hillFill, buildFill, windowBrush, panelFill, ufoBody, ufoDome, alienBrush,
            beamBrush, holeOuter, holeMid, holeCore, grayBrush, redBrush, bombBrush,
            fScore, fLabel, fTitle, fMid, fSmall, fBtn, fBig, fHead, center, near, far
        }) d.Dispose();
    }

    private float SY(float worldY) { return LH - (worldY - cam); }

    private static Color Mix(Color a, Color b, float t)
    {
        return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }

    private static float Mod(float a, float b) { return a - b * (float)Math.Floor(a / b); }

    private void ApplyTheme(Game game)
    {
        int w = game.WorldIndex;
        float b = game.WorldBlend;
        Theme a = Themes[w % Themes.Length], c = Themes[(w + 1) % Themes.Length];
        curPaper = Mix(a.Paper, c.Paper, b);
        curGrid = Mix(a.Grid, c.Grid, b);
        curInk = Mix(a.Ink, c.Ink, b);
        curScarf = Mix(a.Scarf, c.Scarf, b);
        curMon1 = Mix(a.Mon1, c.Mon1, b);
        curMon2 = Mix(a.Mon2, c.Mon2, b);
        curNight = a.Night + (c.Night - a.Night) * b;
        cloudWhite.Color = Mix(a.CloudFill, c.CloudFill, b);
        cloudBlue.Color = Mix(a.CloudLine, c.CloudLine, b);
        gridPen.Color = Color.FromArgb(70, curGrid);
        scarfPen.Color = curScarf;
    }

    // =====================================================================
    //  Frame
    // =====================================================================
    public void Render(Graphics g, Game game, bool muted)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.AntiAlias;
        cam = game.CamY;
        ApplyTheme(game);

        DrawPaper(g);
        DrawGroundScenery(g);
        DrawClouds(g, game.Time);
        foreach (var h in game.Holes) DrawHole(g, h, game.Time);
        foreach (var p in game.Platforms) DrawPlatform(g, p, game.Time);
        foreach (var p in game.Pickups) DrawPickup(g, p, game.Time);
        foreach (var m in game.Monsters) DrawMonster(g, m, game);
        foreach (var u in game.Ufos) DrawUfo(g, u, game);
        foreach (var b in game.Bullets) DrawBullet(g, b);
        foreach (var p in game.Particles) DrawParticle(g, p);
        if (game.State != GameState.GameOver || game.PY > cam - 60f) DrawHero(g, game);

        switch (game.State)
        {
            case GameState.Menu:
                DrawMenu(g, game, muted);
                break;
            case GameState.Playing:
                DrawHud(g, game, muted);
                DrawAim(g, game);
                break;
            case GameState.Paused:
                DrawHud(g, game, muted);
                DrawPaused(g);
                break;
            case GameState.GameOver:
                DrawHud(g, game, muted);
                DrawGameOver(g, game);
                break;
            case GameState.Scores:
                DrawScores(g, game);
                break;
        }
    }

    // ---------- background ----------
    private void DrawPaper(Graphics g)
    {
        tmp.Color = curPaper;
        g.FillRectangle(tmp, 0, 0, LW, LH);

        if (curNight > 0.02f)                                    // night world: twinkling stars with parallax
        {
            for (int i = 0; i < starX.Length; i++)
            {
                float y = Mod(starY[i] + cam * 0.25f, LH);
                int a = (int)(curNight * (120 + 100 * Math.Sin(i * 1.7 + cam * 0.004)));
                tmp.Color = Color.FromArgb(Math.Max(0, Math.Min(255, a)), 255, 250, 220);
                g.FillEllipse(tmp, starX[i], y, 3f, 3f);
            }
        }

        for (float x = 0; x <= LW; x += 24f) g.DrawLine(gridPen, x, 0, x, LH);
        float first = (float)Math.Floor(cam / 24f) * 24f;
        for (float wy = first; wy <= cam + LH + 24f; wy += 24f)
        {
            float y = SY(wy);
            g.DrawLine(gridPen, 0, y, LW, y);
        }
    }

    /// <summary>Hills and little towers fixed to the ground: they scroll away as the camera rises.</summary>
    private void DrawGroundScenery(Graphics g)
    {
        float baseY = SY(0f);
        if (baseY > LH + 260f) return;
        void Hill(float cx, float w, float h)
        {
            g.FillEllipse(hillFill, cx - w / 2f, baseY - h, w, h * 2f);
            g.DrawEllipse(hillOutline, cx - w / 2f, baseY - h, w, h * 2f);
        }
        void Tower(float x, float h, float w)
        {
            g.FillRectangle(buildFill, x, baseY - h, w, h);
            g.DrawRectangle(hillOutline, x, baseY - h, w, h);
            g.FillRectangle(windowBrush, x + w * 0.25f, baseY - h + 14, 6, 9);
            g.FillRectangle(windowBrush, x + w * 0.60f, baseY - h + 14, 6, 9);
            g.FillRectangle(windowBrush, x + w * 0.25f, baseY - h + 34, 6, 9);
            g.FillRectangle(windowBrush, x + w * 0.60f, baseY - h + 34, 6, 9);
            g.DrawLine(hillOutline, x + w / 2f, baseY - h, x + w / 2f, baseY - h - 16);
        }
        Tower(18, 150, 52);
        Tower(74, 96, 38);
        Hill(60, 300, 80);
        Hill(250, 360, 54);
        Tower(404, 170, 44);
        Hill(430, 280, 90);
        Hill(330, 220, 40);
    }

    private void DrawClouds(Graphics g, float time)
    {
        foreach (var c in clouds)
        {
            float y = Mod(c.BaseY + cam * c.Parallax, LH + 240f) - 120f;     // layers move at different speeds
            float x = Mod(c.X + time * (4f + c.Parallax * 10f), LW + 240f) - 120f;
            float s = c.Scale;
            for (int pass = 0; pass < 2; pass++)
            {
                Brush b = pass == 0 ? cloudBlue : cloudWhite;
                float k = pass == 0 ? 4f : 0f;
                g.FillEllipse(b, x - 4f - k, y - 4f - k, 46f * s + 2 * k, 34f * s + 2 * k);
                g.FillEllipse(b, x + 28f * s - k, y - 20f * s - k, 52f * s + 2 * k, 44f * s + 2 * k);
                g.FillEllipse(b, x + 66f * s - k, y - 6f * s - k, 44f * s + 2 * k, 34f * s + 2 * k);
                g.FillRectangle(b, x + 12f * s - k, y + 4f * s - k * 0.2f, 76f * s + 2 * k, 24f * s + k);
            }
            g.DrawLine(hatch, x + 14f * s, y + 24f * s, x + 28f * s, y + 8f * s);
            g.DrawLine(hatch, x + 26f * s, y + 24f * s, x + 40f * s, y + 8f * s);
            g.DrawLine(hatch, x + 38f * s, y + 24f * s, x + 52f * s, y + 8f * s);
        }
    }

    // ---------- platforms ----------
    private void DrawPlatform(Graphics g, Platform p, float time)
    {
        float top = SY(p.Y);
        if (top < -60f || top > LH + 60f) return;
        float yc = top + 8f;

        if (p.Broken) { DrawBrokenPlatform(g, p, yc); return; }

        Pen body, hi;
        switch (p.Type)
        {
            case PlatformType.Move: body = platBlue; hi = platBlueHi; break;
            case PlatformType.Break: body = platBrown; hi = platBrownHi; break;
            case PlatformType.Vanish: body = platWhite; hi = platWhiteHi; break;
            case PlatformType.Explode:
                bool blink = p.FuseT >= 0f && (((int)(p.FuseT * 10f)) & 1) == 0;   // flashes faster and faster while burning
                body = blink ? platWhite : platRed; hi = blink ? platWhiteHi : platRedHi; break;
            case PlatformType.Teleport: body = platPurple; hi = platPurpleHi; break;
            default: body = platGreen; hi = platGreenHi; break;
        }

        Pen outline = platOutline;
        if (p.Type == PlatformType.Vanish && p.VanishT >= 0f)                       // fades out after the jump
        {
            int a = (int)(255 * Math.Max(0f, 1f - p.VanishT / 0.45f));
            platOutlineFade.Color = Color.FromArgb(a, 40, 44, 36);
            platWhiteFade.Color = Color.FromArgb(a, 236, 240, 250);
            platWhiteHiFade.Color = Color.FromArgb(a, 255, 255, 255);
            outline = platOutlineFade;
            body = platWhiteFade;
            hi = platWhiteHiFade;
        }

        g.DrawLine(outline, p.X + 10f, yc, p.X + p.W - 10f, yc);
        g.DrawLine(body, p.X + 10f, yc, p.X + p.W - 10f, yc);
        g.DrawLine(hi, p.X + 14f, yc - 3f, p.X + p.W - 26f, yc - 3f);

        float cx = p.X + p.W / 2f;
        switch (p.Type)
        {
            case PlatformType.Break:
                g.DrawLine(crack, cx - 4f, yc - 8f, cx + 3f, yc - 2f);
                g.DrawLine(crack, cx + 3f, yc - 2f, cx - 2f, yc + 2f);
                g.DrawLine(crack, cx - 2f, yc + 2f, cx + 4f, yc + 8f);
                break;
            case PlatformType.Move:
                g.DrawLine(hi, cx - 12f, yc + 3f, cx + 12f, yc + 3f);
                break;
            case PlatformType.Vanish:                                               // dashed "ghost" marks
                for (int i = -1; i <= 1; i++) g.DrawLine(inkThin, cx + i * 16f - 4f, yc + 1f, cx + i * 16f + 4f, yc + 1f);
                break;
            case PlatformType.Explode:                                              // little bomb with a fuse
                g.FillEllipse(bombBrush, cx - 7f, yc - 14f, 14f, 14f);
                g.DrawLine(inkThin, cx + 3f, yc - 14f, cx + 8f, yc - 19f);
                tmp.Color = Color.FromArgb(255, 200, 50);
                g.FillEllipse(tmp, cx + 6f, yc - 22f, 6f, 6f);
                break;
            case PlatformType.Teleport:                                             // swirl
                g.DrawArc(inkThin, cx - 9f, yc - 9f, 18f, 18f, time * 200f, 250f);
                g.DrawArc(inkThin, cx - 4f, yc - 4f, 8f, 8f, -time * 260f, 250f);
                break;
        }

        if (p.HasSpring) DrawSpring(g, p, top);
    }

    private void DrawSpring(Graphics g, Platform p, float top)
    {
        float cx = p.X + p.W / 2f;
        float h = 6f + 14f * Math.Min(1f, p.SpringT);            // compressed right after landing, then extends
        float y0 = top - 1f;
        g.DrawLine(springPen, cx - 8f, y0, cx + 8f, y0 - h * 0.25f);
        g.DrawLine(springPen, cx + 8f, y0 - h * 0.25f, cx - 8f, y0 - h * 0.5f);
        g.DrawLine(springPen, cx - 8f, y0 - h * 0.5f, cx + 8f, y0 - h * 0.75f);
        g.DrawLine(springPad, cx - 12f, y0 - h - 2f, cx + 12f, y0 - h - 2f);
    }

    private void DrawBrokenPlatform(Graphics g, Platform p, float yc)
    {
        float t = p.BreakT;
        float half = p.W / 2f;
        for (int side = 0; side < 2; side++)
        {
            float x0 = side == 0 ? p.X : p.X + half + 3f;
            float x1 = side == 0 ? p.X + half - 3f : p.X + p.W;
            GraphicsState st = g.Save();
            g.TranslateTransform((x0 + x1) / 2f, yc + 260f * t * t);
            g.RotateTransform((side == 0 ? -1f : 1f) * 70f * t);
            float hw = (x1 - x0) / 2f;
            g.DrawLine(platOutline, -hw + 10f, 0, hw - 10f, 0);
            g.DrawLine(platBrown, -hw + 10f, 0, hw - 10f, 0);
            g.Restore(st);
        }
    }

    // ---------- pickups ----------
    private void DrawPickup(Graphics g, Pickup p, float time)
    {
        float x = p.X, y = SY(p.Y) + (float)Math.Sin(time * 3f + p.X) * 4f;
        if (y < -40f || y > LH + 40f) return;
        switch (p.Kind)
        {
            case BonusKind.Propeller:
                g.FillEllipse(redBrush, x - 10f, y - 4f, 20f, 12f);
                g.DrawEllipse(inkThin, x - 10f, y - 4f, 20f, 12f);
                g.DrawLine(inkThin, x, y - 4f, x, y - 10f);
                float bw = 26f * Math.Abs((float)Math.Cos(time * 30f));
                g.FillEllipse(yellowBrush, x - bw / 2f, y - 13f, bw, 5f);
                g.DrawEllipse(inkThin, x - bw / 2f, y - 13f, bw, 5f);
                break;
            case BonusKind.Jetpack:
                g.DrawLine(platOutline, x - 6f, y - 8f, x - 6f, y + 8f);
                g.DrawLine(jetPen, x - 6f, y - 8f, x - 6f, y + 8f);
                g.DrawLine(platOutline, x + 7f, y - 8f, x + 7f, y + 8f);
                g.DrawLine(jetPen, x + 7f, y - 8f, x + 7f, y + 8f);
                g.DrawLine(flameInner, x - 6f, y + 14f, x - 6f, y + 18f);
                g.DrawLine(flameInner, x + 7f, y + 14f, x + 7f, y + 18f);
                break;
            default:    // rocket
                g.DrawLine(platOutline, x, y + 10f, x, y - 12f);
                g.DrawLine(rocketPen, x, y + 10f, x, y - 12f);
                g.FillEllipse(white, x - 4f, y - 6f, 8f, 8f);
                g.DrawEllipse(inkThin, x - 4f, y - 6f, 8f, 8f);
                g.DrawLine(ink, x - 8f, y + 12f, x - 13f, y + 20f);
                g.DrawLine(ink, x + 8f, y + 12f, x + 13f, y + 20f);
                g.DrawLine(flameOuter, x, y + 20f, x, y + 28f);
                break;
        }
    }

    // ---------- enemies ----------
    private void DrawMonster(Graphics g, Monster m, Game game)
    {
        float x = m.X, y = SY(m.Y);
        if (y < -60f || y > LH + 60f) return;
        float look = Math.Max(-1f, Math.Min(1f, (game.PX - x) / 80f)) * 3f;       // pupils follow the hero
        float lookY = game.PY + 30f > m.Y ? -2f : 2f;
        monBrush.Color = m.Kind == 0 ? curMon1 : curMon2;

        if (m.Kind == 0)    // fuzzy blob: spiky body, two big eyes, toothy grin
        {
            for (int i = 0; i < 10; i++)
            {
                double a = i * Math.PI / 5.0;
                float cx = (float)Math.Cos(a), cy = (float)Math.Sin(a);
                g.DrawLine(ink, x + cx * 22f, y + cy * 20f, x + cx * 29f, y + cy * 26f);
            }
            g.FillEllipse(monBrush, x - 24f, y - 22f, 48f, 44f);
            g.DrawEllipse(ink, x - 24f, y - 22f, 48f, 44f);
            g.FillEllipse(white, x - 16f, y - 14f, 15f, 17f);
            g.FillEllipse(white, x + 1f, y - 14f, 15f, 17f);
            g.DrawEllipse(inkThin, x - 16f, y - 14f, 15f, 17f);
            g.DrawEllipse(inkThin, x + 1f, y - 14f, 15f, 17f);
            g.FillEllipse(inkBrush, x - 11f + look, y - 8f + lookY, 6f, 8f);
            g.FillEllipse(inkBrush, x + 6f + look, y - 8f + lookY, 6f, 8f);
            g.DrawLine(inkThin, x - 10f, y + 10f, x + 10f, y + 10f);
            g.DrawLine(toothPen, x - 6f, y + 10f, x - 6f, y + 15f);
            g.DrawLine(toothPen, x + 6f, y + 10f, x + 6f, y + 15f);
        }
        else                // eye-stalk monster
        {
            g.DrawLine(ink, x - 10f, y - 12f, x - 15f, y - 32f);
            g.DrawLine(ink, x + 10f, y - 12f, x + 15f, y - 32f);
            g.FillEllipse(monBrush, x - 28f, y - 16f, 56f, 36f);
            g.DrawEllipse(ink, x - 28f, y - 16f, 56f, 36f);
            g.FillEllipse(white, x - 23f, y - 44f, 16f, 16f);
            g.FillEllipse(white, x + 7f, y - 44f, 16f, 16f);
            g.DrawEllipse(inkThin, x - 23f, y - 44f, 16f, 16f);
            g.DrawEllipse(inkThin, x + 7f, y - 44f, 16f, 16f);
            g.FillEllipse(inkBrush, x - 18f + look, y - 40f + lookY, 6f, 7f);
            g.FillEllipse(inkBrush, x + 12f + look, y - 40f + lookY, 6f, 7f);
            g.DrawArc(inkThin, x - 12f, y - 2f, 24f, 14f, 10f, 160f);
            g.DrawLine(toothPen, x - 6f, y + 8f, x - 6f, y + 11f);
            g.DrawLine(toothPen, x + 6f, y + 8f, x + 6f, y + 11f);
        }
        if (m.Hit > 0f)
        {
            tmp.Color = Color.FromArgb(150, 255, 255, 255);
            g.FillEllipse(tmp, x - 26f, y - 24f, 52f, 46f);
        }
    }

    private void DrawUfo(Graphics g, Ufo u, Game game)
    {
        float x = u.X, y = SY(u.Y);
        if (y < -240f || y > LH + 60f) return;

        if (game.BeamOn(u))                                                        // tractor beam
        {
            beamPoly[0] = new PointF(x - 16f, y + 14f);
            beamPoly[1] = new PointF(x + 16f, y + 14f);
            beamPoly[2] = new PointF(x + 62f, y + 214f);
            beamPoly[3] = new PointF(x - 62f, y + 214f);
            g.FillPolygon(beamBrush, beamPoly);
        }
        g.FillEllipse(alienBrush, x - 11f, y - 26f, 22f, 26f);                     // little green pilot
        g.DrawEllipse(inkThin, x - 11f, y - 26f, 22f, 26f);
        g.FillEllipse(white, x - 5f, y - 19f, 10f, 10f);
        g.FillEllipse(inkBrush, x - 2f, y - 16f, 4f, 4f);
        g.FillEllipse(ufoDome, x - 20f, y - 32f, 40f, 34f);
        g.DrawEllipse(inkThin, x - 20f, y - 32f, 40f, 34f);
        g.FillEllipse(ufoBody, x - 46f, y - 8f, 92f, 28f);
        g.DrawEllipse(ink, x - 46f, y - 8f, 92f, 28f);
        for (int i = -1; i <= 1; i++) g.FillEllipse(yellowBrush, x + i * 26f - 4f, y + 4f, 8f, 8f);
        if (u.Hit > 0f)
        {
            tmp.Color = Color.FromArgb(150, 255, 255, 255);
            g.FillEllipse(tmp, x - 46f, y - 8f, 92f, 28f);
        }
    }

    private void DrawHole(Graphics g, BlackHole h, float time)
    {
        float x = h.X, y = SY(h.Y);
        if (y < -80f || y > LH + 80f) return;
        float r = h.R;
        g.FillEllipse(holeOuter, x - r * 1.6f, y - r * 1.1f, r * 3.2f, r * 2.2f);
        g.FillEllipse(holeMid, x - r, y - r * 0.7f, r * 2f, r * 1.4f);
        g.FillEllipse(holeCore, x - r * 0.55f, y - r * 0.38f, r * 1.1f, r * 0.76f);
        for (int i = 0; i < 3; i++)                                                // swirling arcs
        {
            float k = 1.15f + i * 0.22f;
            g.DrawArc(holeArc, x - r * k * 1.4f, y - r * k * 0.95f, r * k * 2.8f, r * k * 1.9f, time * (90f + i * 30f) + i * 110f, 70f);
        }
    }

    private void DrawBullet(Graphics g, Bullet b)
    {
        float x = b.X, y = SY(b.Y);
        g.DrawLine(inkThin, x - b.VX * 0.02f, SY(b.Y - b.VY * 0.02f), x, y);
        g.FillEllipse(inkBrush, x - 4.5f, y - 4.5f, 9f, 9f);
        g.FillEllipse(white, x - 2f, y - 3f, 3f, 3f);
    }

    // ---------- particles ----------
    private void DrawParticle(Graphics g, Particle p)
    {
        float k = Math.Max(0f, p.Life / p.MaxLife);
        int a = (int)(255 * k);
        float x = p.X, y = SY(p.Y);
        if (y < -20f || y > LH + 20f) return;
        if (p.Kind == 1)                                          // sparkle: a small "+" star
        {
            sparkPen.Color = Color.FromArgb(a, p.Color);
            float r = p.Size * (0.5f + 0.5f * k);
            g.DrawLine(sparkPen, x - r, y, x + r, y);
            g.DrawLine(sparkPen, x, y - r, x, y + r);
        }
        else
        {
            tmp.Color = Color.FromArgb(a, p.Color);
            float s = p.Size * (p.Kind == 2 ? 1f : 0.5f + 0.5f * k);
            g.FillEllipse(tmp, x - s / 2f, y - s / 2f, s, s);
        }
    }

    // ---------- hero ----------
    private void DrawHero(Graphics g, Game game)
    {
        float sx = game.PX, feet = SY(game.PY);
        float vy = game.VY;
        bool flying = game.Bonus != null;
        bool dead = game.Dead;
        float prog = dead ? 1f - Math.Max(0f, game.DeathTimer) / Game.DeathDur : 0f;

        if (!dead && !flying && vy > 650f && game.State != GameState.Menu)      // speed lines under a fast climbing hero
        {
            float len = Math.Min(60f, (vy - 650f) * 0.2f + 14f);
            g.DrawLine(speedLine, sx - 12f, feet + 10f, sx - 12f, feet + 10f + len);
            g.DrawLine(speedLine, sx + 2f, feet + 22f, sx + 2f, feet + 22f + len * 0.8f);
            g.DrawLine(speedLine, sx + 14f, feet + 6f, sx + 14f, feet + 6f + len * 0.6f);
        }

        float sq = game.Squash > 0f ? game.Squash / 0.16f : 0f;      // 1 -> 0 right after landing
        float scX = 1f + 0.26f * sq, scY = 1f - 0.30f * sq;
        if (vy > 500f) { scX = 0.93f; scY = 1.08f; }                 // slight stretch while shooting up
        float tilt = game.VX / Game.MaxVX * 7f;

        float spin = 0f, shrink = 1f;
        if (dead)
        {
            if (game.DeathKind == 3 || game.DeathKind == 4) { shrink = Math.Max(0.05f, 1f - prog); spin = prog * 720f; }
            else spin = prog * 420f * game.Face;
        }

        bool rising = vy > 120f || flying, falling = vy < -120f && !flying;
        if (dead) { rising = false; falling = true; }

        GraphicsState st = g.Save();
        g.TranslateTransform(sx, feet);
        g.RotateTransform(tilt);
        g.TranslateTransform(0f, -30f);                               // spin and shrink around the middle of the body
        g.RotateTransform(spin);
        g.ScaleTransform(game.Face * scX * shrink, scY * shrink);     // face = +1 right, -1 left (mirror)
        g.TranslateTransform(0f, 30f);

        // back items first
        if (game.Bonus == BonusKind.Jetpack)
        {
            g.DrawLine(platOutline, -30f, -58f, -30f, -34f);
            g.DrawLine(jetPen, -30f, -58f, -30f, -34f);
            float fl = 16f + 10f * (float)Math.Abs(Math.Sin(game.Time * 40f));
            g.DrawLine(flameOuter, -30f, -30f, -30f, -30f + fl);
            g.DrawLine(flameInner, -30f, -30f, -30f, -30f + fl * 0.6f);
        }
        else if (game.Bonus == BonusKind.Rocket)
        {
            g.DrawLine(platOutline, -32f, -66f, -32f, -24f);
            g.DrawLine(rocketPen, -32f, -66f, -32f, -24f);
            g.FillEllipse(white, -36f, -56f, 8f, 8f);
            g.DrawEllipse(inkThin, -36f, -56f, 8f, 8f);
            g.DrawLine(ink, -40f, -26f, -46f, -16f);
            g.DrawLine(ink, -24f, -26f, -18f, -16f);
            float fl = 30f + 22f * (float)Math.Abs(Math.Sin(game.Time * 36f));
            g.DrawLine(flameOuter, -32f, -18f, -32f, -18f + fl);
            g.DrawLine(flameInner, -32f, -18f, -32f, -18f + fl * 0.6f);
        }

        // legs
        float spread = falling ? 5f : (rising ? -3f : 0f);
        float lowY = rising ? -4f : -1f;
        g.DrawLine(ink, -9f, -9f, -9f - spread, lowY);
        g.DrawLine(ink, 9f, -9f, 9f + spread, lowY);
        g.FillEllipse(inkBrush, -9f - spread - 6f, lowY - 2f, 12f, 5f);
        g.FillEllipse(inkBrush, 9f + spread - 6f, lowY - 2f, 12f, 5f);

        // arms
        if (rising)
        {
            g.DrawLine(ink, -20f, -34f, -28f, -46f);
            g.DrawLine(ink, 20f, -34f, 28f, -46f);
        }
        else if (falling)
        {
            g.DrawLine(ink, -20f, -34f, -31f, -36f);
            g.DrawLine(ink, 20f, -34f, 31f, -36f);
        }
        else
        {
            g.DrawLine(ink, -20f, -30f, -27f, -22f);
            g.DrawLine(ink, 20f, -30f, 27f, -22f);
        }

        // body
        g.FillEllipse(heroBody, -22f, -66f, 44f, 60f);
        g.FillEllipse(heroBelly, -12f, -42f, 24f, 30f);
        g.DrawEllipse(ink, -22f, -66f, 44f, 60f);

        // costume: scarf + a hat that changes with the world
        g.DrawLine(scarfPen, -17f, -38f, 17f, -38f);
        g.DrawLine(scarfPen, 13f, -36f, 20f, -26f);
        if (game.Bonus == BonusKind.Propeller) DrawPropellerHat(g, game.Time);
        else DrawHat(g, game.WorldIndex % 5);

        // eyes (look forward; up when rising, down when falling)
        float lookY = rising ? -2f : (falling ? 2f : 0f);
        g.FillEllipse(white, -13f, -57f, 14f, 17f);
        g.FillEllipse(white, 1f, -57f, 14f, 17f);
        g.DrawEllipse(inkThin, -13f, -57f, 14f, 17f);
        g.DrawEllipse(inkThin, 1f, -57f, 14f, 17f);
        g.FillEllipse(inkBrush, -8f, -52f + lookY, 6f, 8f);
        g.FillEllipse(inkBrush, 6f, -52f + lookY, 6f, 8f);

        // cheeks and mouth
        g.FillEllipse(heroCheek, -19f, -42f, 8f, 5f);
        g.FillEllipse(heroCheek, 11f, -42f, 8f, 5f);
        if (falling || game.ShootT > 0f) g.FillEllipse(inkBrush, -1f, -36f, 8f, 9f);   // surprised / shooting "o"
        else g.DrawArc(inkThin, -5f, -38f, 14f, 9f, 15f, 150f);                        // smile
        g.Restore(st);
    }

    private void DrawHat(Graphics g, int style)
    {
        switch (style)
        {
            case 0:     // leaf
                g.DrawLine(ink, 1f, -64f, 1f, -72f);
                g.FillEllipse(leaf, -4f, -82f, 11f, 17f);
                g.DrawEllipse(inkThin, -4f, -82f, 11f, 17f);
                break;
            case 1:     // flower
                g.DrawLine(ink, 1f, -64f, 1f, -74f);
                g.FillEllipse(pinkBrush, -5f, -83f, 8f, 8f);
                g.FillEllipse(pinkBrush, 3f, -83f, 8f, 8f);
                g.FillEllipse(pinkBrush, -5f, -77f, 8f, 8f);
                g.FillEllipse(pinkBrush, 3f, -77f, 8f, 8f);
                g.FillEllipse(yellowBrush, -2f, -80f, 7f, 7f);
                break;
            case 2:     // antenna with a ball
                g.DrawLine(ink, 1f, -64f, 1f, -80f);
                g.FillEllipse(yellowBrush, -4f, -88f, 10f, 10f);
                g.DrawEllipse(inkThin, -4f, -88f, 10f, 10f);
                break;
            case 3:     // space helmet
                g.FillEllipse(helmetBrush, -26f, -86f, 52f, 58f);
                g.DrawEllipse(helmetPen, -26f, -86f, 52f, 58f);
                break;
            default:    // party hat
                g.FillPolygon(partyBrush, PartyHat);
                g.DrawPolygon(inkThin, PartyHat);
                g.FillEllipse(yellowBrush, -2f, -98f, 7f, 7f);
                break;
        }
    }

    private void DrawPropellerHat(Graphics g, float time)
    {
        g.FillEllipse(redBrush, -10f, -72f, 20f, 12f);
        g.DrawEllipse(inkThin, -10f, -72f, 20f, 12f);
        g.DrawLine(inkThin, 0f, -72f, 0f, -80f);
        float bw = 44f * Math.Abs((float)Math.Cos(time * 32f));               // spinning blades
        g.FillEllipse(yellowBrush, -bw / 2f, -84f, bw, 6f);
        g.DrawEllipse(inkThin, -bw / 2f, -84f, bw, 6f);
    }

    private void DrawAim(Graphics g, Game game)
    {
        if (!AimVisible || game.Dead) return;
        g.DrawEllipse(aimPen, Aim.X - 9f, Aim.Y - 9f, 18f, 18f);
        g.DrawLine(aimPen, Aim.X - 14f, Aim.Y, Aim.X - 5f, Aim.Y);
        g.DrawLine(aimPen, Aim.X + 5f, Aim.Y, Aim.X + 14f, Aim.Y);
        g.DrawLine(aimPen, Aim.X, Aim.Y - 14f, Aim.X, Aim.Y - 5f);
        g.DrawLine(aimPen, Aim.X, Aim.Y + 5f, Aim.X, Aim.Y + 14f);
    }

    // =====================================================================
    //  Text helpers
    // =====================================================================
    private void Text(Graphics g, string s, Font f, float x, float y, Color c, StringFormat fmt)
    {
        tmp.Color = c;
        g.DrawString(s, f, tmp, x, y, fmt);
    }

    private void Tilted(Graphics g, string s, Font f, float cx, float y, float angle, Color c)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(cx, y);
        g.RotateTransform(angle);
        Text(g, s, f, 3f, 3f, Color.FromArgb(60, 90, 20, 20), center);      // crayon-like soft shadow
        Text(g, s, f, 0f, 0f, c, center);
        g.Restore(st);
    }

    private void Note(Graphics g, RectangleF r, float angle)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(r.X + r.Width / 2f, r.Y + r.Height / 2f);
        g.RotateTransform(angle);
        tmp.Color = Color.FromArgb(70, 0, 0, 0);
        g.FillRectangle(tmp, -r.Width / 2f + 6f, -r.Height / 2f + 6f, r.Width, r.Height);
        g.FillRectangle(panelFill, -r.Width / 2f, -r.Height / 2f, r.Width, r.Height);
        g.DrawRectangle(panelPen, -r.Width / 2f, -r.Height / 2f, r.Width, r.Height);
        g.Restore(st);
    }

    private static string DeathText(int kind)
    {
        switch (kind)
        {
            case 2: return "A monster got you!";
            case 3: return "Swallowed by a black hole!";
            case 4: return "Abducted by a UFO!";
            case 5: return "Blown up by a bomb!";
            default: return "You fell down!";
        }
    }

    // =====================================================================
    //  HUD and screens
    // =====================================================================
    private void DrawHud(Graphics g, Game game, bool muted)
    {
        Color label = Mix(curInk, curPaper, 0.45f);
        Text(g, "SCORE", fLabel, 16, 8, label, near);
        Text(g, game.Score.ToString(), fScore, 16, 22, curInk, near);
        Text(g, "BEST", fLabel, LW - 16, 8, label, far);
        Text(g, Math.Max(game.Best, game.Score).ToString(), fScore, LW - 16, 22, curInk, far);
        Text(g, muted ? "[M] sound off" : "[M] sound on", fLabel, LW - 16, 66, label, far);
        Text(g, "WORLD " + (game.WorldIndex + 1), fLabel, 16, 66, label, near);

        if (game.Bonus != null && game.BonusTotal > 0f)                       // remaining bonus time
        {
            string name = game.Bonus == BonusKind.Propeller ? "PROPELLER" : (game.Bonus == BonusKind.Jetpack ? "JETPACK" : "ROCKET");
            Text(g, name, fLabel, LW / 2f, 8, label, center);
            tmp.Color = Color.FromArgb(70, 0, 0, 0);
            g.FillRectangle(tmp, LW / 2f - 60f, 28f, 120f, 10f);
            tmp.Color = Color.FromArgb(240, 150, 40);
            g.FillRectangle(tmp, LW / 2f - 59f, 29f, 118f * Math.Max(0f, game.BonusT / game.BonusTotal), 8f);
        }

        if (game.State == GameState.Playing && game.BannerTimer > 0f)       // "WORLD n" banner
        {
            int a = (int)(255 * Math.Min(1f, game.BannerTimer / 0.6f));
            Text(g, game.BannerText, fBig, LW / 2f + 3f, 143f, Color.FromArgb(a / 3, 0, 0, 0), center);
            Text(g, game.BannerText, fBig, LW / 2f, 140f, Color.FromArgb(a, 204, 28, 34), center);
        }
    }

    private void DrawMenu(Graphics g, Game game, bool muted)
    {
        Tilted(g, "DOODLE", fTitle, LW / 2f - 8f, 28f, -5f, Color.FromArgb(204, 28, 34));
        Tilted(g, "JUMP", fTitle, LW / 2f + 44f, 108f, -5f, Color.FromArgb(204, 28, 34));

        // "Play" button: a thick rounded stroke
        float cx = BtnPlay.X + BtnPlay.Width / 2f, cy = BtnPlay.Y + BtnPlay.Height / 2f;
        btnOutline.Width = BtnPlay.Height; btnFill.Width = BtnPlay.Height - 8f;
        g.DrawLine(btnOutline, BtnPlay.X + BtnPlay.Height / 2f, cy, BtnPlay.Right - BtnPlay.Height / 2f, cy);
        g.DrawLine(btnFill, BtnPlay.X + BtnPlay.Height / 2f, cy, BtnPlay.Right - BtnPlay.Height / 2f, cy);
        Text(g, "PLAY", fBtn, cx, cy - 25f, InkColor, center);

        Text(g, "press ENTER to start", fSmall, LW / 2f, 728f, InkColor, center);
        Color hint = Color.FromArgb(70, 76, 110);
        Text(g, "LEFT / RIGHT  or  A / D : move", fSmall, LW / 2f, 522f, hint, center);
        Text(g, "mouse click / SPACE : shoot", fSmall, LW / 2f, 544f, hint, center);
        Text(g, "P / ESC : pause    M : sound " + (muted ? "off" : "on") + "    H : high scores", fSmall, LW / 2f, 566f, hint, center);
        Text(g, "BEST  " + game.Best, fMid, LW / 2f, 598f, Color.FromArgb(204, 28, 34), center);
    }

    private void Dim(Graphics g, int alpha)
    {
        tmp.Color = Color.FromArgb(alpha, 30, 28, 50);
        g.FillRectangle(tmp, 0, 0, LW, LH);
    }

    private void DrawPaused(Graphics g)
    {
        Dim(g, 90);
        var r = new RectangleF(LW / 2f - 190f, 270f, 380f, 210f);
        Note(g, r, -1.5f);
        Text(g, "PAUSED", fBig, LW / 2f, 292f, Color.FromArgb(204, 28, 34), center);
        Text(g, "press P or ESC", fMid, LW / 2f, 376f, InkColor, center);
        Text(g, "to continue", fMid, LW / 2f, 412f, InkColor, center);
    }

    private void DrawGameOver(Graphics g, Game game)
    {
        Dim(g, 110);
        var r = new RectangleF(LW / 2f - 200f, 180f, 400f, 450f);
        Note(g, r, 1.2f);
        Text(g, "GAME OVER", fBig, LW / 2f, 198f, Color.FromArgb(204, 28, 34), center);
        Text(g, DeathText(game.DeathKind), fSmall, LW / 2f, 268f, Color.FromArgb(90, 96, 130), center);
        Text(g, "SCORE", fLabel, LW / 2f, 308f, Color.FromArgb(90, 96, 130), center);
        Text(g, game.Score.ToString(), fBig, LW / 2f, 326f, InkColor, center);
        Text(g, "BEST", fLabel, LW / 2f, 398f, Color.FromArgb(90, 96, 130), center);
        Text(g, game.Best.ToString(), fMid, LW / 2f, 416f, InkColor, center);
        if (game.NewBest && ((int)(game.Time * 3f) & 1) == 0)
            Text(g, "NEW BEST!", fMid, LW / 2f, 462f, Color.FromArgb(40, 150, 70), center);
        else if (!game.NewBest && game.Rank >= 0)
            Text(g, "You are #" + (game.Rank + 1) + " in the top 10", fSmall, LW / 2f, 470f, Color.FromArgb(40, 150, 70), center);
        Text(g, "H : high scores", fSmall, LW / 2f, 520f, Color.FromArgb(90, 96, 130), center);
        Text(g, "press ENTER to play again", fSmall, LW / 2f, 560f, InkColor, center);
    }

    private void DrawScores(Graphics g, Game game)
    {
        Dim(g, 90);
        var r = new RectangleF(40f, 60f, 400f, 690f);
        Note(g, r, -0.8f);
        Text(g, "HIGH SCORES", fHead, LW / 2f, 76f, Color.FromArgb(204, 28, 34), center);
        for (int i = 0; i < HighScoreStore.MaxEntries; i++)
        {
            float y = 150f + i * 52f;
            Color c = i < game.Scores.Count ? InkColor : Color.FromArgb(170, 170, 185);
            Text(g, (i + 1) + ".", fMid, 78f, y, c, near);
            if (i < game.Scores.Count)
            {
                Text(g, game.Scores[i].Score.ToString(), fMid, 140f, y, c, near);
                Text(g, game.Scores[i].Date, fSmall, 410f, y + 8f, Color.FromArgb(110, 116, 150), far);
            }
            else Text(g, "- - -", fMid, 140f, y, c, near);
        }
        Text(g, "press ENTER, H or ESC to go back", fSmall, LW / 2f, 690f, InkColor, center);
    }
}
