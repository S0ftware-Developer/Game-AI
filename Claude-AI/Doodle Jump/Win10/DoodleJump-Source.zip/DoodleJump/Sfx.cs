using System.Media;

namespace DoodleJump;

/// <summary>Synthesised sound effects (no files). Every call is guarded: no audio device = silent game.</summary>
internal sealed class Sfx : IDisposable
{
    private readonly Dictionary<string, SoundPlayer> players = new();
    public bool Muted;

    public Sfx()
    {
        // segment: (startHz, endHz, ms, wave 0=square 1=sine 2=noise, volume)
        Add("jump", MakeWav((260, 720, 110, 1, 0.45)));                 // springy "boing"
        Add("land", MakeWav((170, 70, 70, 1, 0.55)));                   // soft thud, played together with the boing
        Add("break", MakeWav((0, 0, 70, 2, 0.35), (0, 0, 60, 2, 0.30), (0, 0, 90, 2, 0.22)));   // crackle
        Add("record", MakeWav((660, 660, 80, 1, 0.4), (880, 880, 80, 1, 0.4), (1175, 1175, 220, 1, 0.4)));
        Add("over", MakeWav((420, 120, 750, 0, 0.22)));
    }

    public void Play(string name)
    {
        if (Muted) return;
        if (players.TryGetValue(name, out var p))
        {
            try { p.Play(); } catch { /* audio unavailable - ignore */ }
        }
    }

    private void Add(string name, byte[] wav)
    {
        try
        {
            var p = new SoundPlayer(new MemoryStream(wav));
            p.Load();
            players[name] = p;
        }
        catch { /* audio unavailable - ignore */ }
    }

    public void Dispose()
    {
        foreach (var p in players.Values)
        {
            try { p.Stop(); p.Dispose(); } catch { }
        }
        players.Clear();
    }

    private static byte[] MakeWav(params (double f0, double f1, int ms, int wave, double vol)[] segs)
    {
        const int sr = 22050;
        var samples = new List<short>();
        var rnd = new Random(5);
        double phase = 0;

        foreach (var s in segs)
        {
            int n = sr * s.ms / 1000;
            for (int i = 0; i < n; i++)
            {
                double t = (double)i / n;
                double f = s.f0 + (s.f1 - s.f0) * t;
                phase += 2 * Math.PI * f / sr;
                double v = s.wave switch
                {
                    0 => Math.Sin(phase) >= 0 ? 1.0 : -1.0,
                    1 => Math.Sin(phase),
                    _ => rnd.NextDouble() * 2 - 1
                };
                double env = Math.Min(1.0, i / (sr * 0.004)) * (1.0 - t);
                samples.Add((short)(v * env * s.vol * short.MaxValue));
            }
        }

        var ms2 = new MemoryStream();
        var w = new BinaryWriter(ms2);
        int dataLen = samples.Count * 2;
        w.Write(new[] { 'R', 'I', 'F', 'F' });
        w.Write(36 + dataLen);
        w.Write(new[] { 'W', 'A', 'V', 'E' });
        w.Write(new[] { 'f', 'm', 't', ' ' });
        w.Write(16);
        w.Write((short)1);
        w.Write((short)1);
        w.Write(sr);
        w.Write(sr * 2);
        w.Write((short)2);
        w.Write((short)16);
        w.Write(new[] { 'd', 'a', 't', 'a' });
        w.Write(dataLen);
        foreach (short sm in samples) w.Write(sm);
        w.Flush();
        return ms2.ToArray();
    }
}
