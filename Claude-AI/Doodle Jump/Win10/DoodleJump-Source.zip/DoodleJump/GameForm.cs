using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace DoodleJump;

/// <summary>Window, input and the fixed-timestep loop. No gameplay rules live here.</summary>
internal sealed class GameForm : Form
{
    private const int FooterH = 32;
    private const float StepDt = 1f / 120f;

    private readonly Game game = new();
    private readonly Sfx sfx = new();
    private readonly Renderer renderer = new();
    private readonly System.Windows.Forms.Timer timer = new();
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private double lastTime, acc;
    private float scale = 1f, offX, offY;
    private bool fullscreen;

    // the copyright line is drawn in its own strip under the playfield; resources are created once
    private const string FooterA = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: ";
    private const string FooterC = "orlovandrei.space";
    private readonly SolidBrush footBg = new(Color.FromArgb(34, 32, 48));
    private readonly SolidBrush footWhite = new(Color.FromArgb(238, 238, 245));
    private readonly SolidBrush footGreen = new(Color.FromArgb(130, 235, 140));
    private readonly Pen footLine = new(Color.FromArgb(120, 190, 120), 2f);
    private readonly Pen viewPen = new(Color.FromArgb(38, 36, 56), 2f);
    private Font? footFont;
    private int footForWidth = -1;
    private float footWa, footX;

    public GameForm()
    {
        Text = "Doodle Jump";
        DoubleBuffered = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.FromArgb(214, 202, 176);
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(300, 480);

        // default size = 1:1 logical size, shrunk if the screen is too small
        var wa = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        float s = Math.Min(1f, Math.Min((wa.Width - 40) / Renderer.LW, (wa.Height - 110 - FooterH) / Renderer.LH));
        ClientSize = new Size((int)(Renderer.LW * s), (int)(Renderer.LH * s) + FooterH);

        game.Sound = name => sfx.Play(name);
        RecalcLayout();

        timer.Interval = 10;
        timer.Tick += (_, _) => Tick();
        timer.Start();
        lastTime = clock.Elapsed.TotalSeconds;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Stop();
            timer.Dispose();
            renderer.Dispose();
            sfx.Dispose();
            footFont?.Dispose();
            footBg.Dispose(); footWhite.Dispose(); footGreen.Dispose(); footLine.Dispose(); viewPen.Dispose();
        }
        base.Dispose(disposing);
    }

    // ---------- layout ----------
    private void RecalcLayout()
    {
        float availW = Math.Max(1, ClientSize.Width);
        float availH = Math.Max(1, ClientSize.Height - FooterH);
        scale = Math.Min(availW / Renderer.LW, availH / Renderer.LH);
        offX = (availW - Renderer.LW * scale) / 2f;
        offY = (availH - Renderer.LH * scale) / 2f;
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        RecalcLayout();
        Invalidate();
    }

    protected override void OnPaintBackground(PaintEventArgs e) { }

    private void ToggleFullscreen()
    {
        fullscreen = !fullscreen;
        if (fullscreen)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
        }
        else
        {
            WindowState = FormWindowState.Normal;
            FormBorderStyle = FormBorderStyle.Sizable;
        }
    }

    // ---------- game loop ----------
    private void Tick()
    {
        double now = clock.Elapsed.TotalSeconds;
        double dt = now - lastTime;
        lastTime = now;
        if (dt > 0.1) dt = 0.1;                 // never try to "catch up" after a long stall
        acc += dt;
        while (acc >= StepDt)
        {
            game.Update(StepDt);                // does nothing while paused
            acc -= StepDt;
        }
        Invalidate();
    }

    // ---------- input ----------
    protected override void OnKeyDown(KeyEventArgs e)
    {
        switch (e.KeyCode)
        {
            case Keys.Left:
            case Keys.A: game.Left = true; break;
            case Keys.Right:
            case Keys.D: game.Right = true; break;
            case Keys.Enter:
                if (game.State == GameState.Menu || game.State == GameState.GameOver) game.StartNewGame();
                break;
            case Keys.P: game.TogglePause(); break;
            case Keys.M: sfx.Muted = !sfx.Muted; break;
            case Keys.F11: ToggleFullscreen(); break;
            case Keys.Escape:
                switch (game.State)
                {
                    case GameState.Menu: Close(); break;
                    case GameState.Playing:
                    case GameState.Paused: game.TogglePause(); break;
                    case GameState.GameOver: game.GoMenu(); break;
                }
                break;
        }
        e.SuppressKeyPress = true;
        e.Handled = true;
        base.OnKeyDown(e);
    }

    protected override void OnKeyUp(KeyEventArgs e)
    {
        switch (e.KeyCode)
        {
            case Keys.Left:
            case Keys.A: game.Left = false; break;
            case Keys.Right:
            case Keys.D: game.Right = false; break;
        }
        base.OnKeyUp(e);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left || game.State != GameState.Menu) return;
        var p = new PointF((e.X - offX) / scale, (e.Y - offY) / scale);
        if (Renderer.BtnPlay.Contains(p)) game.StartNewGame();
    }

    protected override void OnDeactivate(EventArgs e)
    {
        base.OnDeactivate(e);
        game.ClearInput();                                          // no stuck keys after Alt+Tab
        if (game.State == GameState.Playing) game.TogglePause();    // and never play on in the background
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        timer.Stop();
        game.SaveBest();
        base.OnFormClosing(e);
    }

    // ---------- painting ----------
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Color.FromArgb(214, 202, 176));

        var view = new RectangleF(offX, offY, Renderer.LW * scale, Renderer.LH * scale);
        g.SetClip(view);
        g.TranslateTransform(offX, offY);
        g.ScaleTransform(scale, scale);
        renderer.Render(g, game, sfx.Muted);
        g.ResetTransform();
        g.ResetClip();
        g.DrawRectangle(viewPen, view.X, view.Y, view.Width, view.Height);

        DrawFooter(g);
    }

    private void RebuildFooterFont(Graphics g, int cw)
    {
        var fmt = StringFormat.GenericTypographic;
        float size = 15f;
        footFont?.Dispose();
        footFont = new Font("Consolas", size, FontStyle.Regular, GraphicsUnit.Pixel);
        footWa = g.MeasureString(FooterA, footFont, 3000, fmt).Width;
        float wc = g.MeasureString(FooterC, footFont, 3000, fmt).Width;
        while (footWa + wc > cw - 12 && size > 7f)       // shrink until the whole line fits the window width
        {
            footFont.Dispose();
            size -= 0.5f;
            footFont = new Font("Consolas", size, FontStyle.Regular, GraphicsUnit.Pixel);
            footWa = g.MeasureString(FooterA, footFont, 3000, fmt).Width;
            wc = g.MeasureString(FooterC, footFont, 3000, fmt).Width;
        }
        footX = (cw - (footWa + wc)) / 2f;
        footForWidth = cw;
    }

    private void DrawFooter(Graphics g)
    {
        int cw = ClientSize.Width;
        int top = ClientSize.Height - FooterH;
        g.SmoothingMode = SmoothingMode.None;
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        if (footFont == null || footForWidth != cw) RebuildFooterFont(g, cw);

        g.FillRectangle(footBg, 0, top, cw, FooterH);
        g.DrawLine(footLine, 0, top, cw, top);
        var fmt = StringFormat.GenericTypographic;
        float y = top + (FooterH - footFont!.Height) / 2f;
        g.DrawString(FooterA, footFont, footWhite, footX, y, fmt);
        g.DrawString(FooterC, footFont, footGreen, footX + footWa, y, fmt);
    }
}
