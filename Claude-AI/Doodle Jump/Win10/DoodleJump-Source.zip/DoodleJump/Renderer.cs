using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace DoodleJump;

/// <summary>
/// Draws one frame in logical coordinates (480 x 800) in a hand-drawn "notebook page" style.
/// World -> screen: screenY = H - (worldY - CamY). All pens, brushes and fonts are created once.
/// </summary>
internal sealed class Renderer : IDisposable
{
    public const float LW = Game.W, LH = Game.H;
    public static readonly RectangleF BtnPlay = new(127, 650, 226, 66);

    private sealed class Cloud { public float X, BaseY, Scale, Parallax; }

    private readonly List<Cloud> clouds = new();
    private float cam;

    private static readonly Color InkColor = Color.FromArgb(38, 36, 56);

    private readonly SolidBrush tmp = new(Color.White);
    private readonly Pen gridPen = new(Color.FromArgb(70, 110, 140, 190), 1f);
    private readonly Pen ink = new(InkColor, 3.5f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
    private readonly Pen inkThin = new(InkColor, 2.4f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platOutline = new(Color.FromArgb(40, 44, 36), 20f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platGreen = new(Color.FromArgb(118, 205, 58), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platGreenHi = new(Color.FromArgb(195, 242, 125), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platBrown = new(Color.FromArgb(178, 112, 58), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platBrownHi = new(Color.FromArgb(222, 168, 108), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platBlue = new(Color.FromArgb(78, 168, 240), 13f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen platBlueHi = new(Color.FromArgb(180, 224, 255), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen crack = new(Color.FromArgb(70, 36, 16), 2.4f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen hatch = new(Color.FromArgb(150, 128, 176, 232), 1.5f);
    private readonly Pen speedLine = new(Color.FromArgb(120, 90, 96, 130), 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen sparkPen = new(Color.Gold, 2.6f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen hillOutline = new(Color.FromArgb(120, 150, 205), 3f);
    private readonly Pen panelPen = new(InkColor, 4f) { LineJoin = LineJoin.Round };
    private readonly Pen btnOutline = new(InkColor, 4f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
    private readonly Pen btnFill = new(Color.FromArgb(255, 222, 70), 4f) { StartCap = LineCap.Round, EndCap = LineCap.Round };

    private readonly Brush heroBody = new SolidBrush(Color.FromArgb(250, 140, 56));
    private readonly Brush heroBelly = new SolidBrush(Color.FromArgb(255, 210, 152));
    private readonly Brush heroCheek = new SolidBrush(Color.FromArgb(150, 255, 110, 110));
    private readonly Brush leaf = new SolidBrush(Color.FromArgb(96, 196, 72));
    private readonly Brush white = new SolidBrush(Color.White);
    private readonly Brush inkBrush = new SolidBrush(InkColor);
    private readonly Brush cloudBlue = new SolidBrush(Color.FromArgb(128, 174, 232));
    private readonly Brush cloudWhite = new SolidBrush(Color.FromArgb(244, 249, 255));
    private readonly Brush hillFill = new SolidBrush(Color.FromArgb(168, 190, 228));
    private readonly Brush buildFill = new SolidBrush(Color.FromArgb(150, 176, 222));
    private readonly Brush windowBrush = new SolidBrush(Color.FromArgb(110, 138, 196));
    private readonly Brush panelFill = new SolidBrush(Color.FromArgb(255, 252, 240));

    private readonly Font fScore, fLabel, fTitle, fMid, fSmall, fBtn, fBig;
    private readonly StringFormat center = new() { Alignment = StringAlignment.Center, FormatFlags = StringFormatFlags.NoWrap };
    private readonly StringFormat near = new() { Alignment = StringAlignment.Near, FormatFlags = StringFormatFlags.NoWrap };
    private readonly StringFormat far = new() { Alignment = StringAlignment.Far, FormatFlags = StringFormatFlags.NoWrap };

    public Renderer()
    {
        string family = PickFamily("Segoe Print", "Comic Sans MS", "Segoe UI", "Arial");
        fScore = MakeFont(family, 38, FontStyle.Bold);
        fLabel = MakeFont(family, 15, FontStyle.Bold);
        fTitle = MakeFont(family, 84, FontStyle.Bold);
        fMid = MakeFont(family, 30, FontStyle.Bold);
        fSmall = MakeFont(family, 18, FontStyle.Regular);
        fBtn = MakeFont(family, 34, FontStyle.Bold);
        fBig = MakeFont(family, 54, FontStyle.Bold);

        var rnd = new Random(9);
        for (int i = 0; i < 9; i++)
            clouds.Add(new Cloud
            {
                X = rnd.Next((int)LW), BaseY = rnd.Next((int)LH + 240), Scale = 0.7f + (float)rnd.NextDouble() * 0.7f,
                Parallax = 0.12f + (float)rnd.NextDouble() * 0.33f
            });
    }

    private static string PickFamily(params string[] names)
    {
        foreach (string n in names)
            foreach (var f in FontFamily.Families)
                if (string.Equals(f.Name, n, StringComparison.OrdinalIgnoreCase)) return n;
        return "Arial";
    }

    private static Font MakeFont(string family, float px, FontStyle style)
    {
        try { return new Font(family, px, style, GraphicsUnit.Pixel); }
        catch { return new Font("Arial", px, style, GraphicsUnit.Pixel); }
    }

    public void Dispose()
    {
        tmp.Dispose(); gridPen.Dispose(); ink.Dispose(); inkThin.Dispose(); platOutline.Dispose();
        platGreen.Dispose(); platGreenHi.Dispose(); platBrown.Dispose(); platBrownHi.Dispose(); platBlue.Dispose();
        platBlueHi.Dispose(); crack.Dispose(); hatch.Dispose(); speedLine.Dispose(); sparkPen.Dispose();
        hillOutline.Dispose(); panelPen.Dispose(); btnOutline.Dispose(); btnFill.Dispose();
        heroBody.Dispose(); heroBelly.Dispose(); heroCheek.Dispose(); leaf.Dispose(); white.Dispose(); inkBrush.Dispose();
        cloudBlue.Dispose(); cloudWhite.Dispose(); hillFill.Dispose(); buildFill.Dispose(); windowBrush.Dispose(); panelFill.Dispose();
        fScore.Dispose(); fLabel.Dispose(); fTitle.Dispose(); fMid.Dispose(); fSmall.Dispose(); fBtn.Dispose(); fBig.Dispose();
        center.Dispose(); near.Dispose(); far.Dispose();
    }

    private float SY(float worldY) { return LH - (worldY - cam); }

    private static Color Mix(Color a, Color b, float t)
    {
        return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }

    private static float Mod(float a, float b) { return a - b * (float)Math.Floor(a / b); }

    // =====================================================================
    //  Frame
    // =====================================================================
    public void Render(Graphics g, Game game, bool muted)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.AntiAlias;
        cam = game.CamY;

        DrawPaper(g, game);
        DrawGroundScenery(g);
        DrawClouds(g, game.Time);
        foreach (var p in game.Platforms) DrawPlatform(g, p);
        foreach (var p in game.Particles) DrawParticle(g, p);
        if (game.State != GameState.GameOver || game.PY > cam - 60f) DrawHero(g, game);

        switch (game.State)
        {
            case GameState.Menu:
                DrawMenu(g, game, muted);
                break;
            case GameState.Playing:
                DrawHud(g, game, muted);
                break;
            case GameState.Paused:
                DrawHud(g, game, muted);
                DrawPaused(g);
                break;
            case GameState.GameOver:
                DrawHud(g, game, muted);
                DrawGameOver(g, game);
                break;
        }
    }

    // ---------- background ----------
    private void DrawPaper(Graphics g, Game game)
    {
        float t = Math.Min(1f, game.MaxY / 14000f);          // the page slowly turns sky-blue as you climb
        tmp.Color = Mix(Color.FromArgb(252, 244, 226), Color.FromArgb(206, 234, 250), t);
        g.FillRectangle(tmp, 0, 0, LW, LH);

        for (float x = 0; x <= LW; x += 24f) g.DrawLine(gridPen, x, 0, x, LH);
        float first = (float)Math.Floor(cam / 24f) * 24f;
        for (float wy = first; wy <= cam + LH + 24f; wy += 24f)
        {
            float y = SY(wy);
            g.DrawLine(gridPen, 0, y, LW, y);
        }
    }

    /// <summary>Hills and little towers fixed to the ground: they scroll away as the camera rises.</summary>
    private void DrawGroundScenery(Graphics g)
    {
        float baseY = SY(0f);
        if (baseY > LH + 260f) return;
        void Hill(float cx, float w, float h)
        {
            g.FillEllipse(hillFill, cx - w / 2f, baseY - h, w, h * 2f);
            g.DrawEllipse(hillOutline, cx - w / 2f, baseY - h, w, h * 2f);
        }
        void Tower(float x, float h, float w)
        {
            g.FillRectangle(buildFill, x, baseY - h, w, h);
            g.DrawRectangle(hillOutline, x, baseY - h, w, h);
            g.FillRectangle(windowBrush, x + w * 0.25f, baseY - h + 14, 6, 9);
            g.FillRectangle(windowBrush, x + w * 0.60f, baseY - h + 14, 6, 9);
            g.FillRectangle(windowBrush, x + w * 0.25f, baseY - h + 34, 6, 9);
            g.FillRectangle(windowBrush, x + w * 0.60f, baseY - h + 34, 6, 9);
            g.DrawLine(hillOutline, x + w / 2f, baseY - h, x + w / 2f, baseY - h - 16);
        }
        Tower(18, 150, 52);
        Tower(74, 96, 38);
        Hill(60, 300, 80);
        Hill(250, 360, 54);
        Tower(404, 170, 44);
        Hill(430, 280, 90);
        Hill(330, 220, 40);
    }

    private void DrawClouds(Graphics g, float time)
    {
        foreach (var c in clouds)
        {
            float y = Mod(c.BaseY + cam * c.Parallax, LH + 240f) - 120f;     // layers move at different speeds
            float x = Mod(c.X + time * (4f + c.Parallax * 10f), LW + 240f) - 120f;
            float s = c.Scale;
            // outline first (slightly bigger blue blobs), then the white fill on top -> clean single outline
            for (int pass = 0; pass < 2; pass++)
            {
                Brush b = pass == 0 ? cloudBlue : cloudWhite;
                float k = pass == 0 ? 4f : 0f;
                g.FillEllipse(b, x - 4f - k, y - 4f - k, 46f * s + 2 * k, 34f * s + 2 * k);
                g.FillEllipse(b, x + 28f * s - k, y - 20f * s - k, 52f * s + 2 * k, 44f * s + 2 * k);
                g.FillEllipse(b, x + 66f * s - k, y - 6f * s - k, 44f * s + 2 * k, 34f * s + 2 * k);
                g.FillRectangle(b, x + 12f * s - k, y + 4f * s - k * 0.2f, 76f * s + 2 * k, 24f * s + k);
            }
            g.DrawLine(hatch, x + 14f * s, y + 24f * s, x + 28f * s, y + 8f * s);
            g.DrawLine(hatch, x + 26f * s, y + 24f * s, x + 40f * s, y + 8f * s);
            g.DrawLine(hatch, x + 38f * s, y + 24f * s, x + 52f * s, y + 8f * s);
        }
    }

    // ---------- platforms ----------
    private void DrawPlatform(Graphics g, Platform p)
    {
        float top = SY(p.Y);
        if (top < -40f || top > LH + 60f) return;
        float yc = top + 8f;
        Pen body = p.Type == PlatformType.Normal ? platGreen : (p.Type == PlatformType.Move ? platBlue : platBrown);
        Pen hi = p.Type == PlatformType.Normal ? platGreenHi : (p.Type == PlatformType.Move ? platBlueHi : platBrownHi);

        if (!p.Broken)
        {
            g.DrawLine(platOutline, p.X + 10f, yc, p.X + p.W - 10f, yc);
            g.DrawLine(body, p.X + 10f, yc, p.X + p.W - 10f, yc);
            g.DrawLine(hi, p.X + 14f, yc - 3f, p.X + p.W - 26f, yc - 3f);
            if (p.Type == PlatformType.Break)
            {
                float cx = p.X + p.W / 2f;
                g.DrawLine(crack, cx - 4f, yc - 8f, cx + 3f, yc - 2f);
                g.DrawLine(crack, cx + 3f, yc - 2f, cx - 2f, yc + 2f);
                g.DrawLine(crack, cx - 2f, yc + 2f, cx + 4f, yc + 8f);
            }
            else if (p.Type == PlatformType.Move)
            {
                g.DrawLine(hi, p.X + p.W / 2f - 12f, yc + 3f, p.X + p.W / 2f + 12f, yc + 3f);   // little "slider" mark
            }
            return;
        }

        // broken: two halves fall apart and tumble
        float t = p.BreakT;
        float half = p.W / 2f;
        for (int side = 0; side < 2; side++)
        {
            float x0 = side == 0 ? p.X : p.X + half + 3f;
            float x1 = side == 0 ? p.X + half - 3f : p.X + p.W;
            GraphicsState st = g.Save();
            g.TranslateTransform((x0 + x1) / 2f, yc + 260f * t * t);
            g.RotateTransform((side == 0 ? -1f : 1f) * 70f * t);
            float hw = (x1 - x0) / 2f;
            g.DrawLine(platOutline, -hw + 10f, 0, hw - 10f, 0);
            g.DrawLine(platBrown, -hw + 10f, 0, hw - 10f, 0);
            g.Restore(st);
        }
    }

    // ---------- particles ----------
    private void DrawParticle(Graphics g, Particle p)
    {
        float k = Math.Max(0f, p.Life / p.MaxLife);
        int a = (int)(255 * k);
        float x = p.X, y = SY(p.Y);
        if (y < -20f || y > LH + 20f) return;
        if (p.Kind == 1)                                          // sparkle: a small "+" star
        {
            sparkPen.Color = Color.FromArgb(a, p.Color);
            float r = p.Size * (0.5f + 0.5f * k);
            g.DrawLine(sparkPen, x - r, y, x + r, y);
            g.DrawLine(sparkPen, x, y - r, x, y + r);
        }
        else
        {
            tmp.Color = Color.FromArgb(a, p.Color);
            float s = p.Size * (p.Kind == 2 ? 1f : 0.5f + 0.5f * k);
            g.FillEllipse(tmp, x - s / 2f, y - s / 2f, s, s);
        }
    }

    // ---------- hero ----------
    private void DrawHero(Graphics g, Game game)
    {
        float sx = game.PX, feet = SY(game.PY);
        float vy = game.VY;

        if (vy > 650f && game.State != GameState.Menu)               // speed lines under a fast climbing hero
        {
            float len = Math.Min(60f, (vy - 650f) * 0.2f + 14f);
            g.DrawLine(speedLine, sx - 12f, feet + 10f, sx - 12f, feet + 10f + len);
            g.DrawLine(speedLine, sx + 2f, feet + 22f, sx + 2f, feet + 22f + len * 0.8f);
            g.DrawLine(speedLine, sx + 14f, feet + 6f, sx + 14f, feet + 6f + len * 0.6f);
        }

        float sq = game.Squash > 0f ? game.Squash / 0.16f : 0f;      // 1 -> 0 right after landing
        float scX = 1f + 0.26f * sq, scY = 1f - 0.30f * sq;
        if (vy > 500f) { scX = 0.93f; scY = 1.08f; }                 // slight stretch while shooting up
        float tilt = game.VX / Game.MaxVX * 7f;

        bool rising = vy > 120f, falling = vy < -120f;

        GraphicsState st = g.Save();
        g.TranslateTransform(sx, feet);
        g.RotateTransform(tilt);
        g.ScaleTransform(game.Face * scX, scY);                       // face = +1 right, -1 left (mirror)

        // legs
        float spread = falling ? 5f : (rising ? -3f : 0f);
        float lowY = rising ? -4f : -1f;
        g.DrawLine(ink, -9f, -9f, -9f - spread, lowY);
        g.DrawLine(ink, 9f, -9f, 9f + spread, lowY);
        g.FillEllipse(inkBrush, -9f - spread - 6f, lowY - 2f, 12f, 5f);
        g.FillEllipse(inkBrush, 9f + spread - 6f, lowY - 2f, 12f, 5f);

        // arms
        if (rising)
        {
            g.DrawLine(ink, -20f, -34f, -28f, -46f);
            g.DrawLine(ink, 20f, -34f, 28f, -46f);
        }
        else if (falling)
        {
            g.DrawLine(ink, -20f, -34f, -31f, -36f);
            g.DrawLine(ink, 20f, -34f, 31f, -36f);
        }
        else
        {
            g.DrawLine(ink, -20f, -30f, -27f, -22f);
            g.DrawLine(ink, 20f, -30f, 27f, -22f);
        }

        // leafy tuft on the head
        g.DrawLine(ink, 1f, -64f, 1f, -72f);
        g.FillEllipse(leaf, -4f, -82f, 11f, 17f);
        g.DrawEllipse(inkThin, -4f, -82f, 11f, 17f);

        // body
        g.FillEllipse(heroBody, -22f, -66f, 44f, 60f);
        g.FillEllipse(heroBelly, -12f, -42f, 24f, 30f);
        g.DrawEllipse(ink, -22f, -66f, 44f, 60f);

        // eyes (look forward; up when rising, down when falling)
        float lookY = rising ? -2f : (falling ? 2f : 0f);
        g.FillEllipse(white, -13f, -57f, 14f, 17f);
        g.FillEllipse(white, 1f, -57f, 14f, 17f);
        g.DrawEllipse(inkThin, -13f, -57f, 14f, 17f);
        g.DrawEllipse(inkThin, 1f, -57f, 14f, 17f);
        g.FillEllipse(inkBrush, -8f, -52f + lookY, 6f, 8f);
        g.FillEllipse(inkBrush, 6f, -52f + lookY, 6f, 8f);

        // cheeks and mouth
        g.FillEllipse(heroCheek, -19f, -40f, 8f, 5f);
        g.FillEllipse(heroCheek, 11f, -40f, 8f, 5f);
        if (falling) g.FillEllipse(inkBrush, -1f, -36f, 8f, 9f);                 // surprised "o"
        else g.DrawArc(inkThin, -5f, -38f, 14f, 9f, 15f, 150f);                  // smile
        g.Restore(st);
    }

    // =====================================================================
    //  Text helpers
    // =====================================================================
    private void Text(Graphics g, string s, Font f, float x, float y, Color c, StringFormat fmt)
    {
        tmp.Color = c;
        g.DrawString(s, f, tmp, x, y, fmt);
    }

    private void Tilted(Graphics g, string s, Font f, float cx, float y, float angle, Color c)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(cx, y);
        g.RotateTransform(angle);
        Text(g, s, f, 3f, 3f, Color.FromArgb(60, 90, 20, 20), center);      // crayon-like soft shadow
        Text(g, s, f, 0f, 0f, c, center);
        g.Restore(st);
    }

    private void Note(Graphics g, RectangleF r, float angle)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(r.X + r.Width / 2f, r.Y + r.Height / 2f);
        g.RotateTransform(angle);
        tmp.Color = Color.FromArgb(70, 0, 0, 0);
        g.FillRectangle(tmp, -r.Width / 2f + 6f, -r.Height / 2f + 6f, r.Width, r.Height);
        g.FillRectangle(panelFill, -r.Width / 2f, -r.Height / 2f, r.Width, r.Height);
        g.DrawRectangle(panelPen, -r.Width / 2f, -r.Height / 2f, r.Width, r.Height);
        g.Restore(st);
    }

    // =====================================================================
    //  HUD and screens
    // =====================================================================
    private void DrawHud(Graphics g, Game game, bool muted)
    {
        Color label = Color.FromArgb(90, 96, 130);
        Text(g, "SCORE", fLabel, 16, 8, label, near);
        Text(g, game.Score.ToString(), fScore, 16, 22, InkColor, near);
        Text(g, "BEST", fLabel, LW - 16, 8, label, far);
        Text(g, Math.Max(game.Best, game.Score).ToString(), fScore, LW - 16, 22, InkColor, far);
        Text(g, muted ? "[M] sound off" : "[M] sound on", fLabel, LW - 16, 66, label, far);
    }

    private void DrawMenu(Graphics g, Game game, bool muted)
    {
        Tilted(g, "DOODLE", fTitle, LW / 2f - 8f, 28f, -5f, Color.FromArgb(204, 28, 34));
        Tilted(g, "JUMP", fTitle, LW / 2f + 44f, 108f, -5f, Color.FromArgb(204, 28, 34));

        // "Play" button: a thick rounded stroke
        float cx = BtnPlay.X + BtnPlay.Width / 2f, cy = BtnPlay.Y + BtnPlay.Height / 2f;
        btnOutline.Width = BtnPlay.Height; btnFill.Width = BtnPlay.Height - 8f;
        g.DrawLine(btnOutline, BtnPlay.X + BtnPlay.Height / 2f, cy, BtnPlay.Right - BtnPlay.Height / 2f, cy);
        g.DrawLine(btnFill, BtnPlay.X + BtnPlay.Height / 2f, cy, BtnPlay.Right - BtnPlay.Height / 2f, cy);
        Text(g, "PLAY", fBtn, cx, cy - 25f, InkColor, center);

        Text(g, "press ENTER to start", fSmall, LW / 2f, 728f, InkColor, center);
        Text(g, "LEFT / RIGHT  or  A / D : move", fSmall, LW / 2f, 540f, Color.FromArgb(70, 76, 110), center);
        Text(g, "P / ESC : pause     M : sound " + (muted ? "off" : "on"), fSmall, LW / 2f, 564f, Color.FromArgb(70, 76, 110), center);
        Text(g, "BEST  " + game.Best, fMid, LW / 2f, 598f, Color.FromArgb(204, 28, 34), center);
    }

    private void Dim(Graphics g, int alpha)
    {
        tmp.Color = Color.FromArgb(alpha, 30, 28, 50);
        g.FillRectangle(tmp, 0, 0, LW, LH);
    }

    private void DrawPaused(Graphics g)
    {
        Dim(g, 90);
        var r = new RectangleF(LW / 2f - 190f, 270f, 380f, 210f);
        Note(g, r, -1.5f);
        Text(g, "PAUSED", fBig, LW / 2f, 292f, Color.FromArgb(204, 28, 34), center);
        Text(g, "press P or ESC", fMid, LW / 2f, 376f, InkColor, center);
        Text(g, "to continue", fMid, LW / 2f, 412f, InkColor, center);
    }

    private void DrawGameOver(Graphics g, Game game)
    {
        Dim(g, 110);
        var r = new RectangleF(LW / 2f - 200f, 210f, 400f, 380f);
        Note(g, r, 1.2f);
        Text(g, "GAME OVER", fBig, LW / 2f, 232f, Color.FromArgb(204, 28, 34), center);
        Text(g, "SCORE", fLabel, LW / 2f, 318f, Color.FromArgb(90, 96, 130), center);
        Text(g, game.Score.ToString(), fBig, LW / 2f, 336f, InkColor, center);
        Text(g, "BEST", fLabel, LW / 2f, 410f, Color.FromArgb(90, 96, 130), center);
        Text(g, game.Best.ToString(), fMid, LW / 2f, 428f, InkColor, center);
        if (game.NewBest && ((int)(game.Time * 3f) & 1) == 0)
            Text(g, "NEW BEST!", fMid, LW / 2f, 476f, Color.FromArgb(40, 150, 70), center);
        Text(g, "press ENTER to play again", fSmall, LW / 2f, 534f, InkColor, center);
    }
}
