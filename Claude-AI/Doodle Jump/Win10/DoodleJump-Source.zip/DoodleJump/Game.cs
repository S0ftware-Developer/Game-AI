using System.Drawing;

namespace DoodleJump;

internal enum GameState { Menu, Playing, Paused, GameOver }
internal enum PlatformType { Normal, Break, Move }

internal sealed class Platform
{
    public float X, Y, W;                      // X = left edge, Y = top surface (world coordinates, Y grows upwards)
    public PlatformType Type;
    public float BaseX, Amp, Omega, Phase;     // moving platforms: X = BaseX + Amp * sin(Time * Omega + Phase)
    public bool Broken;
    public float BreakT;                       // seconds since it broke
}

internal sealed class Particle
{
    public float X, Y, VX, VY, Life, MaxLife, Size;
    public int Kind;                           // 0 dust, 1 sparkle, 2 chip of a broken platform
    public Color Color;
}

/// <summary>
/// Pure game logic (no drawing). Everything lives in ONE world coordinate system: Y grows upwards, the start
/// platform is at StartY. The camera only stores CamY = world Y of the bottom edge of the view; the renderer
/// converts world -> screen with  screenY = H - (worldY - CamY).  Platforms never move because of the camera.
/// </summary>
internal sealed class Game
{
    public const float W = 480f, H = 800f;          // logical view size
    public const float PlatH = 16f;
    public const float StartY = 120f;
    public const float MaxVX = 340f;
    public const float HalfBody = 22f;
    public const float FootHalf = 14f;

    private const float Gravity = 1900f;            // px/s^2
    private const float JumpV = 930f;               // jump height = JumpV^2 / (2 G) ~ 228 px
    private const float MaxJumpH = JumpV * JumpV / (2f * Gravity);
    private const float Accel = 2600f, Friction = 2000f;
    private const float SquashTime = 0.16f;
    private const int MaxParticles = 140;

    // ---------- state read by the renderer ----------
    public GameState State = GameState.Menu;
    public int Score, Best;
    public bool NewBest;
    public float Time, CamY, MaxY = StartY;
    public float PX = W / 2f, PY = StartY, VX, VY, Squash;     // PY = feet height
    public int Face = 1;
    public readonly List<Platform> Platforms = new();
    public readonly List<Particle> Particles = new();
    public Action<string>? Sound;

    // ---------- input (set by the window) ----------
    public bool Left, Right;

    private readonly Random rng = new();
    private float genY, prevCX;
    private int startBest;
    private bool recordPlayed;

    public Game()
    {
        Best = HighScoreStore.Load();
        SetupMenu();
    }

    private float Rand() { return (float)rng.NextDouble(); }
    private static float Lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float Clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

    // =====================================================================
    //  Flow
    // =====================================================================
    private void SetupMenu()
    {
        Platforms.Clear(); Particles.Clear();
        CamY = 0; VX = 0; Squash = 0;
        // the hero bounces on the middle platform; the others are decoration
        Platforms.Add(new Platform { X = 195, Y = 280, W = 90, Type = PlatformType.Normal });
        Platforms.Add(new Platform { X = 46, Y = 370, W = 84, Type = PlatformType.Normal });
        Platforms.Add(new Platform { X = 340, Y = 430, W = 84, Type = PlatformType.Move, BaseX = 340, Amp = 40, Omega = 1.4f });
        Platforms.Add(new Platform { X = 60, Y = 480, W = 84, Type = PlatformType.Normal });
        Platforms.Add(new Platform { X = 330, Y = 320, W = 84, Type = PlatformType.Break });
        PX = W / 2f; PY = 280; VY = JumpV;
    }

    public void StartNewGame()
    {
        Platforms.Clear(); Particles.Clear();
        Score = 0; NewBest = false; recordPlayed = false; startBest = Best;
        CamY = 0; MaxY = StartY; Squash = 0;
        PX = W / 2f; PY = StartY; VX = 0; VY = JumpV; Face = 1;
        Platforms.Add(new Platform { X = W / 2f - 60f, Y = StartY, W = 120f, Type = PlatformType.Normal });
        genY = StartY; prevCX = W / 2f;
        GenerateUpTo(CamY + H + 300f);
        State = GameState.Playing;
    }

    public void GoMenu()
    {
        SaveBest();
        SetupMenu();
        State = GameState.Menu;
    }

    public void TogglePause()
    {
        if (State == GameState.Playing) State = GameState.Paused;
        else if (State == GameState.Paused) State = GameState.Playing;
    }

    public void ClearInput() { Left = Right = false; }

    public void SaveBest()
    {
        if (Score > Best) Best = Score;
        HighScoreStore.Save(Best);
    }

    private void EndGame()
    {
        State = GameState.GameOver;
        NewBest = Score > startBest && Score > 0;
        SaveBest();
        Sound?.Invoke("over");
    }

    // =====================================================================
    //  Update
    // =====================================================================
    public void Update(float dt)
    {
        switch (State)
        {
            case GameState.Menu:
                Time += dt;
                UpdatePlatforms();
                StepPlayer(dt, false);
                UpdateParticles(dt);
                break;
            case GameState.Playing:
                UpdatePlaying(dt);
                break;
            case GameState.GameOver:
                Time += dt;
                UpdateParticles(dt);
                break;
        }
    }

    private void UpdatePlaying(float dt)
    {
        Time += dt;
        UpdatePlatforms();
        foreach (var p in Platforms) if (p.Broken) p.BreakT += dt;

        StepPlayer(dt, true);
        UpdateScore();
        UpdateCamera(dt);
        GenerateUpTo(CamY + H + 300f);
        Platforms.RemoveAll(p => p.Y < CamY - 140f || (p.Broken && p.BreakT > 2f));   // forget what is far below
        UpdateParticles(dt);

        if (PY < CamY - 50f) EndGame();           // fell below the bottom of the view
    }

    private void UpdatePlatforms()
    {
        foreach (var p in Platforms)
            if (p.Type == PlatformType.Move && !p.Broken)
                p.X = p.BaseX + p.Amp * (float)Math.Sin(Time * p.Omega + p.Phase);
    }

    private void StepPlayer(float dt, bool control)
    {
        // ----- horizontal: smooth acceleration towards the wanted speed -----
        int dir = control ? (Right ? 1 : 0) - (Left ? 1 : 0) : 0;
        float target = dir * MaxVX;
        float acc = (dir != 0 ? Accel : Friction) * dt;
        if (VX < target) VX = Math.Min(target, VX + acc);
        else if (VX > target) VX = Math.Max(target, VX - acc);
        if (dir != 0) Face = dir;
        else if (Math.Abs(VX) > 25f) Face = VX > 0 ? 1 : -1;

        PX += VX * dt;
        if (PX < -HalfBody) PX += W + 2f * HalfBody;            // fully gone left  -> appears right
        else if (PX > W + HalfBody) PX -= W + 2f * HalfBody;     // fully gone right -> appears left

        // ----- vertical: gravity + landing check against the top surface only while falling -----
        float prevFeet = PY;
        VY -= Gravity * dt;
        PY += VY * dt;
        if (Squash > 0f) Squash -= dt;

        if (VY <= 0f)
        {
            Platform? hit = null;
            foreach (var p in Platforms)
            {
                if (p.Broken) continue;
                if (prevFeet >= p.Y - 1f && PY <= p.Y && PX >= p.X - FootHalf && PX <= p.X + p.W + FootHalf)
                    if (hit == null || p.Y > hit.Y) hit = p;      // the highest surface we crossed
            }
            if (hit != null) Land(hit);
        }
    }

    private void Land(Platform p)
    {
        if (p.Type == PlatformType.Break)
        {
            p.Broken = true;                    // the platform crumbles, the hero keeps falling
            p.BreakT = 0f;
            for (int i = 0; i < 8; i++)
                AddParticle(2, p.X + Rand() * p.W, p.Y, (Rand() - 0.5f) * 220f, Rand() * 160f, 0.9f, 4f + Rand() * 4f,
                    Color.FromArgb(176, 112, 60));
            Sound?.Invoke("break");
            return;
        }

        PY = p.Y;
        VY = JumpV;                             // VY > 0 now: this contact can never trigger a second bounce
        Squash = SquashTime;
        for (int i = 0; i < 7; i++)
            AddParticle(0, PX + (Rand() - 0.5f) * 24f, p.Y, (Rand() - 0.5f) * 280f, 30f + Rand() * 90f, 0.35f + Rand() * 0.25f,
                3f + Rand() * 3f, Color.FromArgb(205, 195, 170));
        for (int i = 0; i < 3; i++)
            AddParticle(1, PX + (Rand() - 0.5f) * 30f, p.Y + 6f, (Rand() - 0.5f) * 120f, 60f + Rand() * 90f, 0.55f, 6f + Rand() * 4f,
                Color.FromArgb(255, 200, 40));
        Sound?.Invoke("jump");
        Sound?.Invoke("land");
    }

    private void UpdateScore()
    {
        if (PY > MaxY) MaxY = PY;
        Score = (int)((MaxY - StartY) / 4f);        // points only for a NEW maximum height
        if (Score > Best)
        {
            Best = Score;
            if (startBest > 0 && !recordPlayed) { recordPlayed = true; Sound?.Invoke("record"); }
        }
    }

    private void UpdateCamera(float dt)
    {
        // follow upwards only; keep the hero slightly above the middle of the view; never jerk downwards
        float desired = PY - H * 0.5f;
        if (desired > CamY) CamY += (desired - CamY) * (1f - (float)Math.Exp(-12f * dt));
    }

    // =====================================================================
    //  Procedural level generation
    // =====================================================================
    /// <summary>
    /// The "main chain" (normal / moving platforms) is always reachable: the vertical gap stays under 85% of the
    /// jump height and the horizontal offset under what the hero can fly in the available time. Breakable platforms
    /// are only extra lures placed between chain platforms, so a route never depends on them.
    /// </summary>
    private void GenerateUpTo(float limit)
    {
        while (genY < limit) AddChainPlatform();
    }

    private void AddChainPlatform()
    {
        float d = Math.Min(1f, genY / 12000f);                   // difficulty 0..1 by height
        float minGap = 70f + 40f * d, maxGap = 110f + 80f * d;   // at most 190 px (< 228 px jump height)
        float gap = minGap + Rand() * (maxGap - minGap);
        float newY = genY + gap;
        float w = Lerp(92f, 66f, d) + Rand() * 14f;
        bool moving = newY > 1500f && Rand() < 0.10f + 0.22f * d;

        float airTime = JumpV / Gravity + (float)Math.Sqrt(Math.Max(0f, 2f * (MaxJumpH * 0.97f - gap) / Gravity));
        float maxDx = MaxVX * airTime * 0.65f * (moving ? 0.7f : 1f);
        float cx = Clamp(prevCX + (Rand() * 2f - 1f) * maxDx, w / 2f + 6f, W - w / 2f - 6f);

        var p = new Platform { X = cx - w / 2f, Y = newY, W = w, Type = PlatformType.Normal };
        if (moving)
        {
            p.Type = PlatformType.Move;
            p.Amp = 55f + Rand() * 30f;
            float baseCX = Clamp(cx, w / 2f + 6f + p.Amp, W - w / 2f - 6f - p.Amp);
            p.BaseX = baseCX - w / 2f;
            p.Omega = (70f + Rand() * 40f) / p.Amp;              // px/s = Amp * Omega
            p.Phase = Rand() * 6.2832f;
            p.X = p.BaseX;
            cx = baseCX;
        }
        Platforms.Add(p);

        // occasional breakable lure between the previous and the new chain platform
        float pBreak = newY > 800f ? 0.08f + 0.20f * d : 0f;
        if (Rand() < pBreak)
        {
            float bw = 68f + Rand() * 16f;
            Platforms.Add(new Platform
            {
                X = Rand() * (W - bw), Y = genY + gap * (0.35f + Rand() * 0.3f), W = bw, Type = PlatformType.Break
            });
        }

        genY = newY;
        prevCX = cx;
    }

    // =====================================================================
    //  Particles
    // =====================================================================
    private void AddParticle(int kind, float x, float y, float vx, float vy, float life, float size, Color c)
    {
        if (Particles.Count >= MaxParticles) return;
        Particles.Add(new Particle { Kind = kind, X = x, Y = y, VX = vx, VY = vy, Life = life, MaxLife = life, Size = size, Color = c });
    }

    private void UpdateParticles(float dt)
    {
        foreach (var p in Particles)
        {
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            if (p.Kind == 2) p.VY -= 900f * dt;                  // chips fall
            else { p.VX *= 0.96f; p.VY *= 0.96f; }
            p.Life -= dt;
        }
        Particles.RemoveAll(p => p.Life <= 0f);
    }
}
