namespace MetalSlug;

/// <summary>An explosive shot that ended: where, how big and who fired it.</summary>
public struct Detonation
{
    public float X, Y, Radius, Damage;
    public bool FromPlayer;
    public ShotKind Kind;
}

/// <summary>Owns all bullets and shells, moves them and reports explosive shots that detonate.</summary>
public sealed class ProjectileManager
{
    public readonly List<Projectile> Items = new List<Projectile>(256);
    public readonly List<Detonation> Detonated = new List<Detonation>(16);   // explosive shots that ended this step
    private readonly Stack<Projectile> pool = new Stack<Projectile>(256);

    public void Clear()
    {
        foreach (Projectile p in Items) pool.Push(p);
        Items.Clear();
        Detonated.Clear();
    }

    public Projectile Spawn(ShotKind kind, float x, float y, float vx, float vy, float damage, float life)
    {
        Projectile p = pool.Count > 0 ? pool.Pop() : new Projectile();
        p.Kind = kind;
        p.X = x; p.Y = y; p.VX = vx; p.VY = vy;
        p.Damage = damage;
        p.Life = life;
        p.AY = 0f;
        p.ExplodeRadius = 0f;
        p.Alive = true;
        switch (kind)
        {
            case ShotKind.Bullet: p.Radius = 3f; break;
            case ShotKind.Heavy: p.Radius = 4f; break;
            case ShotKind.Pellet: p.Radius = 3f; break;
            case ShotKind.Rocket: p.Radius = 6f; p.ExplodeRadius = 75f; break;
            case ShotKind.TankMG: p.Radius = 3.5f; break;
            case ShotKind.TankShell: p.Radius = 7f; p.ExplodeRadius = 70f; break;
            case ShotKind.EBullet: p.Radius = 4f; break;
            case ShotKind.EHeavy: p.Radius = 5f; break;
            case ShotKind.ESniper: p.Radius = 4f; break;
            case ShotKind.EShell: p.Radius = 7f; p.ExplodeRadius = 55f; break;
            default: p.Radius = 8f; p.ExplodeRadius = 60f; p.AY = 900f; break;     // mortar
        }
        Items.Add(p);
        return p;
    }

    /// <summary>Ends a shot; explosive ones are reported so the engine can blow them up.</summary>
    public void End(Projectile p)
    {
        if (!p.Alive) return;
        p.Alive = false;
        if (p.Explosive)
        {
            Detonation d = new Detonation();
            d.X = p.X; d.Y = p.Y; d.Radius = p.ExplodeRadius; d.Damage = p.Damage; d.FromPlayer = p.FromPlayer; d.Kind = p.Kind;
            Detonated.Add(d);
        }
    }

    public void Update(float dt, Level level)
    {
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Projectile p = Items[i];
            if (p.Alive)
            {
                p.VY += p.AY * dt;
                p.X += p.VX * dt;
                p.Y += p.VY * dt;
                p.Life -= dt;
                if (p.Life <= 0f) End(p);
                else if (p.Y >= GameConfig.GroundY + 4f) End(p);
                else if (p.X < -100f || p.X > GameConfig.LevelWidth + 100f || p.Y < -400f) p.Alive = false;
                else if (level.SolidAt(p.X, p.Y)) End(p);
            }
            if (!p.Alive)
            {
                Items[i] = Items[Items.Count - 1];
                Items.RemoveAt(Items.Count - 1);
                pool.Push(p);
            }
        }
    }
}
