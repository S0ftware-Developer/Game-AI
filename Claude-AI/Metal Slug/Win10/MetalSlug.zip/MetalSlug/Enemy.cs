namespace MetalSlug;

public enum EnemyType { Infantry, Grenadier, Heavy, Sniper, Elite }

/// <summary>
/// An enemy soldier. Infantry patrol and fire in pairs; grenadiers lob grenades in an arc; heavy soldiers advance and
/// fire long bursts; snipers on elevated spots show a laser sight before a powerful shot; elites run, jump and fire
/// bursts aggressively. They stay dormant until the camera approaches.
/// </summary>
public sealed class Enemy
{
    private static int nextId = 1;

    public int Id;
    public EnemyType Type;
    public float X, Y, VX, VY;             // X is the centre, Y the feet
    public int Facing = -1;
    public float HalfW, Height;
    public float Hp, MaxHp;
    public int Score;
    public bool Active, Dying, Grounded;
    public float DeathTimer, HitFlash, Age, Walk, ShootAnim, ThrowAnim;
    public float AimTimer, AimX, AimY;      // the sniper's laser sight
    public float Min, Max;

    private int state, shotsLeft;
    private float stateTimer, shotTimer, jumpTimer;
    private float patrolDir = 1f;
    private float throwWind;

    public RectangleF Rect
    {
        get { return new RectangleF(X - HalfW, Y - Height, HalfW * 2f, Height); }
    }

    public bool Hittable { get { return Active && !Dying; } }

    public float MuzzleX { get { return X + Facing * 20f; } }

    public float MuzzleY
    {
        get
        {
            switch (Type)
            {
                case EnemyType.Heavy: return Y - 36f;
                case EnemyType.Sniper: return Y - 22f;
                default: return Y - 30f;
            }
        }
    }

    public void Init(EnemySpawn s, Random rng)
    {
        Id = nextId++;
        Type = s.Type;
        X = s.X;
        Y = s.Y;
        Min = s.Min;
        Max = s.Max;
        VX = 0f;
        VY = 0f;
        Active = false;
        Dying = false;
        stateTimer = 0.6f + (float)rng.NextDouble() * 1.5f;
        patrolDir = rng.Next(2) == 0 ? -1f : 1f;
        switch (Type)
        {
            case EnemyType.Infantry: HalfW = 12f; Height = 44f; Hp = 3f; Score = GameConfig.ScoreInfantry; break;
            case EnemyType.Grenadier: HalfW = 12f; Height = 44f; Hp = 3f; Score = GameConfig.ScoreGrenadier; break;
            case EnemyType.Heavy: HalfW = 17f; Height = 56f; Hp = 14f; Score = GameConfig.ScoreHeavy; break;
            case EnemyType.Sniper: HalfW = 12f; Height = 38f; Hp = 3f; Score = GameConfig.ScoreSniper; break;
            default: HalfW = 12f; Height = 46f; Hp = 10f; Score = GameConfig.ScoreElite; break;
        }
        MaxHp = Hp;
    }

    public void Damage(float amount)
    {
        Hp -= amount;
        HitFlash = 0.1f;
    }

    public void StartDying()
    {
        Dying = true;
        DeathTimer = 0.65f;
        VX = -Facing * 130f;
        VY = -260f;
    }

    private static float Clamp(float v, float lo, float hi)
    {
        return Math.Max(lo, Math.Min(hi, v));
    }

    private void Aimed(ProjectileManager shots, ShotKind kind, float speed, float tx, float ty, float spread, float dmg)
    {
        float mx = MuzzleX;
        float my = MuzzleY;
        float a = MathF.Atan2(ty - my, tx - mx) + spread;
        shots.Spawn(kind, mx, my, MathF.Cos(a) * speed, MathF.Sin(a) * speed, dmg, 3f);
        ShootAnim = 0.2f;
    }

    public void Update(float dt, float tx, float ty, bool canAct, Level lv, ProjectileManager shots, GrenadeManager grenades, Random rng, out bool fired, out bool threw)
    {
        fired = false;
        threw = false;
        Age += dt;
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        if (ShootAnim > 0f) ShootAnim = Math.Max(0f, ShootAnim - dt);
        if (ThrowAnim > 0f) ThrowAnim = Math.Max(0f, ThrowAnim - dt);

        if (Dying)
        {
            DeathTimer -= dt;
            VX = VX * (1f - 2f * dt);
            VY = Math.Min(900f, VY + GameConfig.Gravity * dt);
            float dx = X, dy = Y, dvx = VX, dvy = VY;
            CollisionManager.MoveBody(lv, ref dx, ref dy, ref dvx, ref dvy, 8f, 10f, dt);
            X = dx; Y = dy; VX = dvx; VY = dvy;
            return;
        }

        float distX = Math.Abs(tx - X);
        float dir = tx >= X ? 1f : -1f;
        float walk = 0f;
        stateTimer -= dt;

        switch (Type)
        {
            case EnemyType.Infantry:
                if (state == 0)
                {
                    if (Max > Min + 1f)
                    {
                        walk = patrolDir * 50f;
                        if (X <= Min) patrolDir = 1f;
                        if (X >= Max) patrolDir = -1f;
                        Facing = patrolDir > 0f ? 1 : -1;
                    }
                    if (canAct && distX < 620f)
                    {
                        Facing = (int)dir;
                        if (stateTimer <= 0f)
                        {
                            state = 1;
                            shotsLeft = 2;
                            shotTimer = 0.2f;
                        }
                    }
                }
                else
                {
                    Facing = (int)dir;
                    shotTimer -= dt;
                    if (shotTimer <= 0f)
                    {
                        Aimed(shots, ShotKind.EBullet, 330f, tx, ty, ((float)rng.NextDouble() - 0.5f) * 0.1f, 1f);
                        fired = true;
                        shotsLeft--;
                        shotTimer = 0.28f;
                        if (shotsLeft <= 0)
                        {
                            state = 0;
                            stateTimer = 1.3f + (float)rng.NextDouble() * 1.2f;
                        }
                    }
                }
                break;

            case EnemyType.Grenadier:
                Facing = (int)dir;
                if (throwWind > 0f)
                {
                    throwWind -= dt;
                    if (throwWind <= 0f)
                    {
                        float dx = tx - X;
                        float dyT = ty - (Y - 36f);
                        float t = Clamp(Math.Abs(dx) / 250f, 0.7f, 1.5f);
                        float gvx = dx / t;
                        float gvy = Math.Max(-820f, (dyT - 0.5f * 900f * t * t) / t);
                        grenades.Throw(X + Facing * 10f, Y - 40f, gvx, gvy, false);
                        threw = true;
                        stateTimer = 2.4f + (float)rng.NextDouble() * 1.2f;
                    }
                }
                else if (canAct && stateTimer <= 0f && distX < 600f && distX > 110f)
                {
                    throwWind = 0.4f;
                    ThrowAnim = 0.5f;
                }
                break;

            case EnemyType.Heavy:
                Facing = (int)dir;
                if (canAct && distX > 260f && distX < 700f)
                {
                    walk = dir * 38f;
                    if (Max > Min + 1f && ((dir > 0f && X >= Max) || (dir < 0f && X <= Min))) walk = 0f;
                }
                if (state == 0)
                {
                    if (canAct && distX < 640f && stateTimer <= 0f)
                    {
                        state = 1;
                        shotsLeft = 7;
                        shotTimer = 0.2f;
                    }
                }
                else
                {
                    walk = 0f;
                    shotTimer -= dt;
                    if (shotTimer <= 0f)
                    {
                        Aimed(shots, ShotKind.EHeavy, 380f, tx, ty, ((float)rng.NextDouble() - 0.5f) * 0.14f, 1f);
                        fired = true;
                        shotsLeft--;
                        shotTimer = 0.09f;
                        if (shotsLeft <= 0)
                        {
                            state = 0;
                            stateTimer = 1.6f + (float)rng.NextDouble();
                        }
                    }
                }
                break;

            case EnemyType.Sniper:
                Facing = (int)dir;
                if (state == 0)
                {
                    AimTimer = 0f;
                    if (canAct && distX < 760f && stateTimer <= 0f)
                    {
                        state = 1;
                        AimTimer = 1.15f;
                    }
                }
                else
                {
                    AimTimer -= dt;
                    if (AimTimer > 0.25f)
                    {
                        AimX = tx;
                        AimY = ty;           // the laser follows the target until the last moment
                    }
                    else if (AimTimer <= 0f)
                    {
                        float mx = MuzzleX;
                        float my = MuzzleY;
                        float a = MathF.Atan2(AimY - my, AimX - mx);
                        shots.Spawn(ShotKind.ESniper, mx, my, MathF.Cos(a) * 780f, MathF.Sin(a) * 780f, 2f, 2f);
                        ShootAnim = 0.3f;
                        fired = true;
                        state = 0;
                        stateTimer = 2f + (float)rng.NextDouble() * 1.2f;
                    }
                }
                break;

            default:    // Elite
                Facing = (int)dir;
                jumpTimer -= dt;
                if (canAct)
                {
                    if (distX > 230f) walk = dir * 125f;
                    else if (distX < 120f) walk = -dir * 80f;
                    if (jumpTimer <= 0f && Grounded && distX < 420f)
                    {
                        VY = -540f;
                        Grounded = false;
                        jumpTimer = 2f + (float)rng.NextDouble() * 1.5f;
                    }
                }
                if (state == 0)
                {
                    if (canAct && distX < 600f && stateTimer <= 0f)
                    {
                        state = 1;
                        shotsLeft = 3;
                        shotTimer = 0.1f;
                    }
                }
                else
                {
                    shotTimer -= dt;
                    if (shotTimer <= 0f)
                    {
                        Aimed(shots, ShotKind.EBullet, 370f, tx, ty, ((float)rng.NextDouble() - 0.5f) * 0.08f, 1f);
                        fired = true;
                        shotsLeft--;
                        shotTimer = 0.14f;
                        if (shotsLeft <= 0)
                        {
                            state = 0;
                            stateTimer = 1.0f + (float)rng.NextDouble() * 0.7f;
                        }
                    }
                }
                break;
        }

        float spd = Type == EnemyType.Elite ? 0.1f : 0.06f;
        VX = Clamp(walk, -190f, 190f);
        Walk += Math.Abs(VX) * dt * spd * 0.8f;
        VY = Math.Min(900f, VY + GameConfig.Gravity * dt);
        float x = X, y = Y, vx = VX, vy = VY;
        Grounded = CollisionManager.MoveBody(lv, ref x, ref y, ref vx, ref vy, HalfW, Height, dt);
        X = x; Y = y; VY = vy;
        if (Type == EnemyType.Infantry && Max > Min + 1f) X = Clamp(X, Min, Max);
    }
}
