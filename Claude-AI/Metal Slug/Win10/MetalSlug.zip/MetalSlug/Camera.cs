namespace MetalSlug;

/// <summary>
/// A smooth horizontal follow camera. It only ever moves forward (the left limit ratchets), stops at the end of the
/// level and therefore also locks onto the boss arena.
/// </summary>
public sealed class Camera
{
    public float X;
    public float Limit;           // the left edge can never go below this (the camera does not scroll back)
    public float Shake;

    public void Reset()
    {
        X = 0f;
        Limit = 0f;
        Shake = 0f;
    }

    public void Update(float dt, float targetX, int facing, float maxX)
    {
        float want = targetX - GameConfig.LogicalW * 0.42f + facing * 50f;
        want = Math.Max(Limit, Math.Min(maxX, want));
        X += (want - X) * (1f - MathF.Exp(-6f * dt));
        if (X > maxX) X = maxX;
        if (X < Limit) X = Limit;
        Limit = Math.Max(Limit, X);
        if (Shake > 0f) Shake = Math.Max(0f, Shake - dt);
    }
}
