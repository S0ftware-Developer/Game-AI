namespace MetalSlug;

/// <summary>All tunable numbers of the game in one place (pixels and seconds).</summary>
public static class GameConfig
{
    // ---- layout (logical pixels, landscape)
    public const int LogicalW = 960;
    public const int LogicalH = 572;
    public const int FooterH = 32;
    public const int ViewH = LogicalH - FooterH;     // height of the battlefield: 540

    // ---- world
    public const float GroundY = 440f;
    public const float LevelWidth = 8200f;
    public const float ArenaStartX = LevelWidth - LogicalW;   // the camera stops here for the boss
    public const float BossTriggerX = 7480f;
    public const float Gravity = 1500f;

    // ---- soldier
    public const float PlayerHalfW = 12f;
    public const float PlayerH = 46f;
    public const float PlayerCrouchH = 30f;
    public const float PlayerSpeed = 190f;
    public const float PlayerAccel = 2400f;
    public const float PlayerDecel = 2800f;
    public const float JumpSpeed = 620f;
    public const float JumpCutSpeed = 240f;
    public const int StartHealth = 3;
    public const int MaxHealth = 5;
    public const int StartLives = 3;
    public const int MaxLives = 9;
    public const int StartGrenades = 6;
    public const int MaxGrenades = 15;
    public const float HitInvulnerability = 1.2f;
    public const float RespawnInvulnerability = 2.5f;
    public const float DeathTime = 1.1f;

    // ---- player tank
    public const int TankMaxHp = 12;
    public const float TankSpeed = 160f;
    public const float TankHopSpeed = 430f;

    // ---- grenades
    public const float GrenadeFuse = 1.3f;
    public const float GrenadeRadius = 85f;
    public const float GrenadeDamage = 10f;

    // ---- score
    public const int ScoreInfantry = 100;
    public const int ScoreGrenadier = 150;
    public const int ScoreSniper = 200;
    public const int ScoreHeavy = 300;
    public const int ScoreElite = 400;
    public const int ScoreArmored = 800;
    public const int ScoreTank = 1500;
    public const int ScoreBoss = 10000;
    public const int ScorePickup = 250;
    public const int ScoreMedal = 1000;

    // ---- boss
    public const float BossMaxHp = 300f;
}
