using System.Drawing.Drawing2D;

namespace MetalSlug;

/// <summary>
/// All character, vehicle, boss, pickup, projectile and effect drawing. Soldiers share one articulated humanoid routine
/// (run cycle, jump, crouch, aiming arm and weapon, grenade throw, death fall) with a different style per type; the
/// tanks share a tank routine; the armored car and the boss have their own drawings. Everything faces right in local
/// coordinates and is mirrored for the facing direction.
/// </summary>
public sealed class Sprites : IDisposable
{
    private sealed class HumanStyle
    {
        public Color Shirt, ShirtDark, Pants, Boots, Skin, Hat, Accent;
        public int HatKind;                 // 0 helmet, 1 floppy cap, 2 heavy helmet, 3 hood, 4 beret, 5 headband and hair
        public bool Pack, Sleeveless;
        public float Scale = 1f;
        public float Bulk = 1f;
    }

    private static readonly HumanStyle PlayerStyle = new HumanStyle
    {
        Shirt = Color.FromArgb(222, 204, 160), ShirtDark = Color.FromArgb(188, 168, 124), Pants = Color.FromArgb(98, 114, 66),
        Boots = Color.FromArgb(70, 48, 30), Skin = Color.FromArgb(236, 188, 146), Hat = Color.FromArgb(244, 208, 84),
        Accent = Color.FromArgb(214, 40, 44), HatKind = 5, Pack = true, Sleeveless = true
    };
    private static readonly HumanStyle InfantryStyle = new HumanStyle
    {
        Shirt = Color.FromArgb(98, 128, 72), ShirtDark = Color.FromArgb(70, 96, 52), Pants = Color.FromArgb(84, 100, 60),
        Boots = Color.FromArgb(50, 38, 28), Skin = Color.FromArgb(226, 180, 138), Hat = Color.FromArgb(94, 118, 64),
        Accent = Color.FromArgb(60, 70, 40), HatKind = 0, Pack = true
    };
    private static readonly HumanStyle GrenadierStyle = new HumanStyle
    {
        Shirt = Color.FromArgb(156, 116, 72), ShirtDark = Color.FromArgb(116, 84, 52), Pants = Color.FromArgb(98, 86, 60),
        Boots = Color.FromArgb(54, 40, 30), Skin = Color.FromArgb(224, 176, 134), Hat = Color.FromArgb(132, 102, 66),
        Accent = Color.FromArgb(50, 50, 44), HatKind = 1, Pack = false
    };
    private static readonly HumanStyle HeavyStyle = new HumanStyle
    {
        Shirt = Color.FromArgb(128, 72, 54), ShirtDark = Color.FromArgb(90, 48, 36), Pants = Color.FromArgb(72, 68, 58),
        Boots = Color.FromArgb(40, 34, 30), Skin = Color.FromArgb(214, 168, 128), Hat = Color.FromArgb(112, 114, 124),
        Accent = Color.FromArgb(200, 170, 60), HatKind = 2, Pack = true, Scale = 1.28f, Bulk = 1.3f
    };
    private static readonly HumanStyle SniperStyle = new HumanStyle
    {
        Shirt = Color.FromArgb(114, 102, 66), ShirtDark = Color.FromArgb(82, 74, 46), Pants = Color.FromArgb(98, 90, 60),
        Boots = Color.FromArgb(52, 42, 30), Skin = Color.FromArgb(222, 176, 134), Hat = Color.FromArgb(106, 94, 58),
        Accent = Color.FromArgb(70, 80, 46), HatKind = 3, Pack = true
    };
    private static readonly HumanStyle EliteStyle = new HumanStyle
    {
        Shirt = Color.FromArgb(46, 46, 60), ShirtDark = Color.FromArgb(28, 28, 40), Pants = Color.FromArgb(38, 38, 48),
        Boots = Color.FromArgb(24, 22, 24), Skin = Color.FromArgb(222, 176, 134), Hat = Color.FromArgb(188, 36, 42),
        Accent = Color.FromArgb(204, 44, 48), HatKind = 4, Pack = false, Scale = 1.05f
    };

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fText = new Font("Segoe UI", 13f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly Font fPick = new Font("Segoe UI", 15f, FontStyle.Bold, GraphicsUnit.Pixel);
    private readonly StringFormat sfCenter = new StringFormat();
    private readonly PointF[] quad = new PointF[4];
    private readonly PointF[] tri = new PointF[3];
    private readonly PointF[] starPts = new PointF[10];

    public Sprites()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fText.Dispose();
        fPick.Dispose();
        sfCenter.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private static Color T(Color c, float flash, float alpha)
    {
        int r = (int)(c.R + (255 - c.R) * flash);
        int g = (int)(c.G + (255 - c.G) * flash);
        int b = (int)(c.B + (255 - c.B) * flash);
        return Color.FromArgb(A(c.A * alpha), r, g, b);
    }

    private static Color C(int r, int g, int b, float flash, float alpha)
    {
        return T(Color.FromArgb(255, r, g, b), flash, alpha);
    }

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private void Rect(Graphics g, Color c, float x, float y, float w, float h)
    {
        g.FillRectangle(B(c), x, y, w, h);
    }

    private void Star(Graphics g, float cx, float cy, float r, Color c)
    {
        for (int i = 0; i < 10; i++)
        {
            float a = -MathF.PI / 2f + i * MathF.PI / 5f;
            float rr = (i % 2 == 0) ? r : r * 0.42f;
            starPts[i] = new PointF(cx + MathF.Cos(a) * rr, cy + MathF.Sin(a) * rr);
        }
        g.FillPolygon(B(c), starPts);
    }

    private void MuzzleFlash(Graphics g, float x, float y, float size, float alpha)
    {
        g.FillEllipse(B(Color.FromArgb(A(220 * alpha), 255, 200, 70)), x - size, y - size * 0.55f, size * 2f, size * 1.1f);
        g.FillEllipse(B(Color.FromArgb(A(255 * alpha), 255, 250, 200)), x - size * 0.55f, y - size * 0.3f, size * 1.1f, size * 0.6f);
    }

    // ------------------------------------------------------------------ the soldiers

    public void DrawPlayer(Graphics g, Player p, float time)
    {
        if (p.InTank) return;
        if (p.Dead)
        {
            float fall = Math.Min(1.45f, (GameConfig.DeathTime - p.DeathTimer) * 3.2f);
            float alpha = Math.Max(0f, Math.Min(1f, p.DeathTimer / 0.5f));
            DrawHuman(g, PlayerStyle, p.X, p.Y, p.Facing, 0f, false, false, true, 0f, 0f, 0f, alpha, fall, 0f, GunOf(p));
            return;
        }
        if (p.Invuln > 0f && ((int)(time * 16f) & 1) == 0) return;
        float a;
        switch (p.Aim)
        {
            case 1: a = -MathF.PI / 2f; break;
            case 2: a = MathF.PI / 2f; break;
            case 3: a = -MathF.PI / 4f; break;
            case 4: a = MathF.PI / 4f; break;
            default: a = 0f; break;
        }
        bool moving = p.Grounded && Math.Abs(p.VX) > 20f;
        DrawHuman(g, PlayerStyle, p.X, p.Y, p.Facing, p.RunPhase, moving, p.Crouching, !p.Grounded, p.Weapon.MuzzleTimer > 0f ? 1f : p.ShootAnim, p.ThrowAnim, p.HitFlash > 0f ? 0.5f : 0f, 1f, 0f, a, GunOf(p));
        if (p.PickupAnim > 0f)
        {
            float k = p.PickupAnim / 0.5f;
            for (int i = 0; i < 4; i++)
            {
                float ang = time * 6f + i * 1.57f;
                Star(g, p.X + MathF.Cos(ang) * 16f, p.Y - 62f - (1f - k) * 14f + MathF.Sin(ang) * 6f, 4f, Color.FromArgb(A(255 * k), 255, 240, 120));
            }
        }
    }

    private static int GunOf(Player p)
    {
        switch (p.Weapon.Type)
        {
            case WeaponType.Heavy: return 1;
            case WeaponType.Shotgun: return 5;
            case WeaponType.Rocket: return 6;
            default: return 0;
        }
    }

    public void DrawEnemy(Graphics g, Enemy e, float time)
    {
        if (!e.Active) return;
        HumanStyle s;
        int gun;
        switch (e.Type)
        {
            case EnemyType.Grenadier: s = GrenadierStyle; gun = 4; break;
            case EnemyType.Heavy: s = HeavyStyle; gun = 1; break;
            case EnemyType.Sniper: s = SniperStyle; gun = 2; break;
            case EnemyType.Elite: s = EliteStyle; gun = 3; break;
            default: s = InfantryStyle; gun = 0; break;
        }
        float flash = e.HitFlash > 0f ? 0.7f : 0f;
        float alpha = 1f;
        float fall = 0f;
        if (e.Dying)
        {
            fall = Math.Min(1.4f, (0.65f - e.DeathTimer) * 3.6f);
            alpha = Math.Max(0f, Math.Min(1f, e.DeathTimer / 0.3f));
        }
        bool moving = Math.Abs(e.VX) > 15f;
        bool crouch = e.Type == EnemyType.Sniper;
        float aim = 0.12f;
        if (e.Type == EnemyType.Sniper && e.AimTimer > 0f)
        {
            aim = MathF.Atan2(e.AimY - e.MuzzleY, Math.Abs(e.AimX - e.X));
            aim = Math.Max(-0.9f, Math.Min(0.9f, aim));
        }
        else if (e.Type == EnemyType.Infantry || e.Type == EnemyType.Elite || e.Type == EnemyType.Heavy)
        {
            aim = e.ShootAnim > 0f ? 0.05f : 0.35f;
        }
        DrawHuman(g, s, e.X, e.Y, e.Facing, e.Walk, moving, crouch, !e.Grounded && !e.Dying, e.ShootAnim, e.ThrowAnim, flash, alpha, fall, aim, gun);

        // the sniper's laser sight
        if (e.Type == EnemyType.Sniper && e.AimTimer > 0f && !e.Dying)
        {
            float k = 1f - Math.Max(0f, e.AimTimer) / 1.15f;
            g.DrawLine(P(Color.FromArgb(A(70 + 150 * k), 255, 40, 40), 1.5f), e.MuzzleX, e.MuzzleY, e.AimX, e.AimY);
            g.FillEllipse(B(Color.FromArgb(A(120 + 130 * k), 255, 60, 60)), e.AimX - 3f, e.AimY - 3f, 6f, 6f);
        }
    }

    private void DrawGun(Graphics g, int gun, float alpha, float flash)
    {
        Color dark = C(58, 62, 70, flash, alpha);
        Color mid = C(96, 100, 108, flash, alpha);
        Color wood = C(112, 76, 40, flash, alpha);
        switch (gun)
        {
            case 1:     // heavy machine gun with an ammunition box and belt
                Rect(g, dark, -6f, -4f, 28f, 8f);
                Rect(g, mid, 22f, -2f, 14f, 4f);
                Rect(g, C(94, 104, 62, flash, alpha), 0f, 3f, 12f, 9f);
                for (int i = 0; i < 4; i++) Rect(g, C(230, 190, 60, flash, alpha), 12f + i * 3f, 3f + i * 1.2f, 2.5f, 3f);
                Rect(g, wood, -12f, -3f, 8f, 5f);
                break;
            case 2:     // sniper rifle with a scope
                Rect(g, wood, -12f, -2f, 10f, 4f);
                Rect(g, dark, -4f, -2f, 28f, 4f);
                Rect(g, mid, 24f, -1.2f, 20f, 2.4f);
                Rect(g, C(40, 44, 50, flash, alpha), 2f, -6.5f, 13f, 4f);
                g.FillEllipse(B(C(140, 200, 255, flash, alpha)), 13f, -6.2f, 3.4f, 3.4f);
                break;
            case 3:     // sub-machine gun
                Rect(g, dark, -2f, -3f, 16f, 6f);
                Rect(g, mid, 14f, -1.5f, 9f, 3f);
                Rect(g, dark, 3f, 3f, 5f, 9f);
                Rect(g, wood, -8f, -2f, 6f, 4f);
                break;
            case 5:     // shotgun
                Rect(g, wood, -12f, -2.5f, 12f, 5f);
                Rect(g, dark, 0f, -2.5f, 18f, 5f);
                Rect(g, mid, 18f, -2f, 14f, 4f);
                Rect(g, wood, 12f, 2.5f, 9f, 4f);
                break;
            case 6:     // rocket launcher tube
                Rect(g, C(90, 106, 70, flash, alpha), -12f, -5f, 38f, 10f);
                Rect(g, dark, -14f, -6f, 4f, 12f);
                Rect(g, C(200, 60, 50, flash, alpha), 24f, -5.5f, 5f, 11f);
                Rect(g, dark, 4f, -8f, 8f, 3f);
                break;
            case 4:     // none: the grenadier carries grenades instead
                break;
            default:    // rifle
                Rect(g, wood, -12f, -2f, 12f, 5f);
                Rect(g, dark, 0f, -3f, 20f, 5f);
                Rect(g, mid, 20f, -1.5f, 10f, 3f);
                Rect(g, dark, 6f, 2f, 5f, 7f);
                break;
        }
    }

    private static float GunLength(int gun)
    {
        switch (gun)
        {
            case 1: return 36f;
            case 2: return 44f;
            case 3: return 23f;
            case 5: return 32f;
            case 6: return 28f;
            case 4: return 0f;
            default: return 30f;
        }
    }

    /// <summary>An articulated soldier: legs, torso, backpack, head gear, arms and the weapon along the aim angle.</summary>
    private void DrawHuman(Graphics g, HumanStyle s, float x, float y, int facing, float walk, bool moving, bool crouch, bool air,
        float shootAnim, float throwAnim, float flash, float alpha, float fall, float aim, int gun)
    {
        g.FillEllipse(B(Color.FromArgb(A(55 * alpha), 0, 0, 0)), x - 14f * s.Scale, y - 3f, 28f * s.Scale, 6f);
        GraphicsState st = g.Save();
        g.TranslateTransform(x, y);
        if (fall != 0f) g.RotateTransform(-facing * fall * 57.3f);
        g.ScaleTransform(facing * s.Scale, s.Scale);

        float bulk = s.Bulk;
        float hipY = crouch ? -14f : -22f;
        Color pants = T(s.Pants, flash, alpha);
        Color pantsDark = T(Color.FromArgb(255, s.Pants.R * 7 / 10, s.Pants.G * 7 / 10, s.Pants.B * 7 / 10), flash, alpha);
        Color boots = T(s.Boots, flash, alpha);
        Color skin = T(s.Skin, flash, alpha);
        Color shirt = T(s.Shirt, flash, alpha);
        Color shirtDark = T(s.ShirtDark, flash, alpha);
        Color outline = Color.FromArgb(A(255 * alpha), 28, 24, 20);

        // legs (the back leg first)
        for (int i = 0; i < 2; i++)
        {
            float ph = walk + i * MathF.PI;
            float sw = moving ? MathF.Sin(ph) : 0f;
            float lift = moving ? Math.Max(0f, MathF.Cos(ph)) * 4f : 0f;
            PointF hip = new PointF(-1f + i * 3f, hipY);
            PointF knee;
            PointF foot;
            if (crouch)
            {
                foot = new PointF(-5f + i * 11f, 0f);
                knee = new PointF(6f + i * 4f, -7f);
            }
            else if (air)
            {
                foot = new PointF(i == 0 ? -7f : 7f, -9f);
                knee = new PointF(i == 0 ? 3f : 10f, -15f);
            }
            else
            {
                foot = new PointF(sw * 11f, -lift);
                knee = new PointF(sw * 5f + 3f, (hipY - lift) / 2f);
            }
            Color lc = i == 0 ? pantsDark : pants;
            float lw = 7f * bulk;
            g.DrawLine(P(outline, lw + 2f), hip, knee);
            g.DrawLine(P(outline, lw + 2f), knee, foot);
            g.DrawLine(P(lc, lw), hip, knee);
            g.DrawLine(P(lc, lw), knee, foot);
            g.FillRectangle(B(boots), foot.X - 3f, foot.Y - 4f, 10f, 5f);
        }

        // backpack with a bedroll
        if (s.Pack)
        {
            g.FillRectangle(B(T(Color.FromArgb(255, 74, 90, 56), flash, alpha)), -13f * bulk, hipY - 17f, 7f, 15f);
            g.FillEllipse(B(T(Color.FromArgb(255, 150, 130, 90), flash, alpha)), -15f * bulk, hipY - 20f, 12f, 6f);
            g.DrawRectangle(P(outline, 1.2f), -13f * bulk, hipY - 17f, 7f, 15f);
        }

        // torso
        float tw = 14f * bulk;
        g.FillRectangle(B(shirt), -tw / 2f, hipY - 17f, tw, 18f);
        g.FillRectangle(B(shirtDark), -tw / 2f, hipY - 17f, 4f, 18f);
        g.FillRectangle(B(T(Color.FromArgb(255, 56, 44, 32), flash, alpha)), -tw / 2f, hipY - 1.5f, tw, 3.5f);
        g.DrawRectangle(P(outline, 1.2f), -tw / 2f, hipY - 17f, tw, 18f);
        if (s.HatKind == 4)
        {
            g.DrawLine(P(T(s.Accent, flash, alpha), 2.4f), -tw / 2f + 2f, hipY - 16f, tw / 2f - 1f, hipY - 3f);    // bandolier
        }
        if (s.HatKind == 1)
        {
            for (int i = 0; i < 3; i++) g.FillEllipse(B(T(Color.FromArgb(255, 80, 96, 60), flash, alpha)), -tw / 2f + 1f + i * 4.5f, hipY - 8f, 4f, 5f);   // grenade belt
        }

        // head and head gear
        float hx = 2f;
        float hy = hipY - 25f;
        g.FillEllipse(B(skin), hx - 6f, hy - 6f, 12f, 13f);
        g.DrawEllipse(P(outline, 1.2f), hx - 6f, hy - 6f, 12f, 13f);
        if (s.HatKind == 4)
        {
            g.FillRectangle(B(Color.FromArgb(A(255 * alpha), 20, 20, 24)), hx + 0f, hy - 2.5f, 8f, 3f);          // sunglasses
        }
        else
        {
            g.FillEllipse(B(Color.FromArgb(A(255 * alpha), 30, 24, 20)), hx + 2.5f, hy - 1.5f, 2.6f, 3f);
        }
        g.FillRectangle(B(T(Color.FromArgb(255, 190, 130, 100), flash, alpha)), hx + 5f, hy + 1f, 2f, 2f);
        Color hat = T(s.Hat, flash, alpha);
        switch (s.HatKind)
        {
            case 0:
                g.FillEllipse(B(hat), hx - 7.5f, hy - 10f, 15f, 11f);
                g.FillRectangle(B(hat), hx - 7.5f, hy - 5f, 16f, 2.5f);
                g.DrawEllipse(P(outline, 1.2f), hx - 7.5f, hy - 10f, 15f, 11f);
                break;
            case 1:
                g.FillEllipse(B(hat), hx - 7f, hy - 9f, 14f, 9f);
                g.FillRectangle(B(T(Color.FromArgb(255, 100, 76, 48), flash, alpha)), hx - 2f, hy - 3.5f, 11f, 2.5f);
                g.DrawEllipse(P(outline, 1.2f), hx - 7f, hy - 9f, 14f, 9f);
                break;
            case 2:
                g.FillEllipse(B(hat), hx - 9f, hy - 12f, 18f, 14f);
                g.FillRectangle(B(Color.FromArgb(A(255 * alpha), 30, 30, 36)), hx - 1f, hy - 5f, 10f, 3.5f);
                g.DrawEllipse(P(outline, 1.4f), hx - 9f, hy - 12f, 18f, 14f);
                break;
            case 3:
                g.FillEllipse(B(hat), hx - 9f, hy - 10f, 17f, 15f);
                g.FillEllipse(B(skin), hx - 1f, hy - 5f, 8f, 8f);
                g.FillEllipse(B(Color.FromArgb(A(255 * alpha), 30, 24, 20)), hx + 2.5f, hy - 2f, 2.4f, 2.8f);
                for (int i = 0; i < 4; i++) g.DrawLine(P(T(Color.FromArgb(255, 80, 96, 56), flash, alpha), 2f), hx - 8f + i * 4f, hy - 8f, hx - 10f + i * 4f, hy + 1f);
                break;
            case 4:
                g.FillEllipse(B(hat), hx - 8f, hy - 10f, 17f, 8f);
                g.FillEllipse(B(T(Color.FromArgb(255, 150, 24, 30), flash, alpha)), hx - 8f, hy - 6f, 13f, 3f);
                g.DrawEllipse(P(outline, 1.2f), hx - 8f, hy - 10f, 17f, 8f);
                g.FillRectangle(B(T(s.Accent, flash, alpha)), hx - 4f, hipY - 20f, 8f, 3.5f);                      // scarf
                break;
            default:
                {
                    // blond hair, a red headband with flapping tails
                    g.FillEllipse(B(hat), hx - 7.5f, hy - 9f, 15f, 8f);
                    quad[0] = new PointF(hx - 6f, hy - 6f);
                    quad[1] = new PointF(hx + 2f, hy - 13f);
                    quad[2] = new PointF(hx + 8f, hy - 7f);
                    quad[3] = new PointF(hx + 7f, hy - 4f);
                    g.FillPolygon(B(hat), quad);
                    g.FillRectangle(B(T(s.Accent, flash, alpha)), hx - 6.5f, hy - 4.5f, 14f, 3.4f);
                    float flap = MathF.Sin(walk * 1.5f + 1f) * 2.5f;
                    tri[0] = new PointF(hx - 6f, hy - 4.5f);
                    tri[1] = new PointF(hx - 15f, hy - 8f + flap);
                    tri[2] = new PointF(hx - 14f, hy - 2f + flap);
                    g.FillPolygon(B(T(s.Accent, flash, alpha)), tri);
                    break;
                }
        }

        // arms and weapon
        PointF shoulder = new PointF(2f, hipY - 14f);
        Color armColor = s.Sleeveless ? skin : shirt;
        if (throwAnim > 0f)
        {
            float t = 1f - throwAnim / 0.5f;
            float ang = -2.3f + t * 2.7f;
            PointF hand = new PointF(shoulder.X + MathF.Cos(ang) * 13f, shoulder.Y + MathF.Sin(ang) * 13f);
            g.DrawLine(P(outline, 6.5f), shoulder, hand);
            g.DrawLine(P(armColor, 5f), shoulder, hand);
            if (t < 0.62f) g.FillEllipse(B(T(Color.FromArgb(255, 70, 84, 50), flash, alpha)), hand.X - 3.5f, hand.Y - 5f, 7f, 9f);
            g.FillEllipse(B(skin), hand.X - 2.5f, hand.Y - 2.5f, 5f, 5f);
        }
        else
        {
            PointF hand = new PointF(shoulder.X + MathF.Cos(aim) * 10f + 2f, shoulder.Y + MathF.Sin(aim) * 10f + 1f);
            float cs = MathF.Cos(aim);
            float sn = MathF.Sin(aim);
            if (gun != 4)
            {
                GraphicsState gs = g.Save();
                g.TranslateTransform(hand.X, hand.Y);
                g.RotateTransform(aim * 57.3f);
                DrawGun(g, gun, alpha, flash);
                g.Restore(gs);
                PointF rear = new PointF(hand.X + cs * 9f, hand.Y + sn * 9f + 1f);
                g.DrawLine(P(outline, 6f), shoulder, rear);
                g.DrawLine(P(armColor, 4.5f), shoulder, rear);
                g.FillEllipse(B(skin), rear.X - 2.4f, rear.Y - 2.4f, 5f, 5f);
                if (shootAnim > 0f)
                {
                    float len = GunLength(gun);
                    MuzzleFlash(g, hand.X + cs * (len + 6f), hand.Y + sn * (len + 6f), gun == 6 ? 12f : (gun == 5 ? 11f : 8f), alpha);
                }
            }
            g.DrawLine(P(outline, 6.5f), shoulder, hand);
            g.DrawLine(P(armColor, 5f), shoulder, hand);
            g.FillEllipse(B(skin), hand.X - 2.6f, hand.Y - 2.6f, 5.2f, 5.2f);
        }
        g.Restore(st);
    }

    // ------------------------------------------------------------------ tanks

    public void DrawPlayerTank(Graphics g, PlayerTank t, float time)
    {
        float flash = t.HitFlash > 0f ? 0.55f : 0f;
        if (t.Destroyed)
        {
            DrawWreck(g, t.X, t.Y, 1f, time);
            return;
        }
        if (t.Invuln > 0f && t.Occupied && ((int)(time * 20f) & 1) == 0 && t.HitFlash > 0f) flash = 0.7f;
        DrawTankShape(g, t.X, t.Y, t.Facing, 1f, t.TurretAngle, t.Recoil, t.TrackPhase, Color.FromArgb(255, 112, 124, 62), Color.FromArgb(255, 150, 160, 86), Color.FromArgb(255, 70, 78, 40), Color.FromArgb(255, 232, 192, 60), flash, t.Occupied, true);
        if (t.Hp <= 6)
        {
            float k = t.Hp <= 3 ? 1f : 0.6f;
            for (int i = 0; i < 4; i++)
            {
                float u = (time * 0.9f + i * 0.25f) % 1f;
                g.FillEllipse(B(Color.FromArgb(A(130 * (1f - u) * k), 50, 48, 50)), t.X - t.Facing * 20f + i * 4f - 8f * u, t.Y - 56f - u * 44f, 12f + u * 16f, 12f + u * 16f);
            }
            if (t.Hp <= 3)
            {
                float f = 0.6f + 0.4f * MathF.Sin(time * 30f);
                g.FillEllipse(B(Color.FromArgb(A(220 * f), 255, 150, 40)), t.X - 14f, t.Y - 58f, 18f, 18f * f);
                g.FillEllipse(B(Color.FromArgb(A(240 * f), 255, 240, 140)), t.X - 9f, t.Y - 54f, 8f, 10f * f);
            }
        }
    }

    private void DrawTankShape(Graphics g, float x, float y, int facing, float scale, float turret, float recoil, float trackPhase,
        Color hull, Color hullLight, Color hullDark, Color accent, float flash, bool pilot, bool star)
    {
        g.FillEllipse(B(Color.FromArgb(55, 0, 0, 0)), x - 52f * scale, y - 4f, 104f * scale, 8f);
        GraphicsState st = g.Save();
        g.TranslateTransform(x, y);
        g.ScaleTransform(facing * scale, scale);
        Color outline = Color.FromArgb(255, 24, 26, 18);
        Color h = T(hull, flash, 1f);
        Color hl = T(hullLight, flash, 1f);
        Color hd = T(hullDark, flash, 1f);

        // tracks with road wheels and moving tread blocks
        using (GraphicsPath tr = new GraphicsPath())
        {
            tr.AddArc(-50f, -24f, 24f, 24f, 90f, 180f);
            tr.AddArc(26f, -24f, 24f, 24f, 270f, 180f);
            tr.CloseFigure();
            g.FillPath(B(Color.FromArgb(255, 44, 44, 48)), tr);
            g.DrawPath(P(outline, 2f), tr);
        }
        for (int i = 0; i < 12; i++)
        {
            float u = ((i / 12f) + trackPhase * 0.08f) % 1f;
            if (u < 0f) u += 1f;
            float tx = -38f + u * 76f;
            g.FillRectangle(B(Color.FromArgb(255, 78, 78, 84)), tx - 2.5f, -3f, 5f, 3f);
            g.FillRectangle(B(Color.FromArgb(255, 78, 78, 84)), tx - 2.5f, -24f, 5f, 3f);
        }
        for (int i = 0; i < 5; i++)
        {
            float wx = -36f + i * 18f;
            g.FillEllipse(B(Color.FromArgb(255, 86, 88, 96)), wx - 8f, -20f, 16f, 16f);
            g.DrawEllipse(P(outline, 1.6f), wx - 8f, -20f, 16f, 16f);
            float a = trackPhase * 0.5f + i;
            g.DrawLine(P(Color.FromArgb(255, 150, 152, 160), 2f), wx, -12f, wx + MathF.Cos(a) * 5f, -12f + MathF.Sin(a) * 5f);
        }

        // hull
        PointF[] body = { new PointF(-46f, -24f), new PointF(-52f, -36f), new PointF(-38f, -46f), new PointF(36f, -46f), new PointF(50f, -34f), new PointF(46f, -24f) };
        g.FillPolygon(B(h), body);
        g.FillRectangle(B(hl), -38f, -46f, 74f, 5f);
        g.FillRectangle(B(hd), -46f, -29f, 92f, 5f);
        g.DrawPolygon(P(outline, 2.2f), body);
        g.FillRectangle(B(T(accent, flash, 1f)), -48f, -36f, 6f, 8f);
        if (star)
        {
            g.FillEllipse(B(Color.FromArgb(255, 240, 240, 230)), -30f, -42f, 16f, 16f);
            Star(g, -22f, -34f, 7f, Color.FromArgb(255, 200, 40, 40));
        }
        g.DrawLine(P(hd, 2f), 30f, -44f, 30f, -26f);
        g.FillEllipse(B(T(accent, flash, 1f)), 40f, -34f, 7f, 7f);                 // headlight

        // the pilot's head in the hatch
        if (pilot)
        {
            g.FillEllipse(B(Color.FromArgb(255, 236, 188, 146)), -14f, -58f, 12f, 13f);
            g.FillEllipse(B(Color.FromArgb(255, 244, 208, 84)), -15f, -60f, 14f, 8f);
            g.FillRectangle(B(Color.FromArgb(255, 214, 40, 44)), -15f, -54f, 14f, 3f);
        }

        // turret with a machine gun and the cannon
        GraphicsState ts = g.Save();
        g.TranslateTransform(6f, -40f);
        g.RotateTransform(turret * 57.3f);
        float rc = -recoil * 8f;
        g.FillRectangle(B(Color.FromArgb(255, 56, 58, 50)), 12f + rc, -5f, 56f, 10f);
        g.FillRectangle(B(Color.FromArgb(255, 110, 112, 100)), 12f + rc, -5f, 56f, 3f);
        g.FillRectangle(B(Color.FromArgb(255, 36, 38, 32)), 64f + rc, -6.5f, 6f, 13f);
        g.FillRectangle(B(Color.FromArgb(255, 70, 72, 64)), 12f, -13f, 30f, 3.5f);
        PointF[] tp = { new PointF(-16f, -12f), new PointF(20f, -12f), new PointF(26f, 0f), new PointF(-14f, 4f) };
        g.FillPolygon(B(h), tp);
        g.FillRectangle(B(hl), -14f, -12f, 34f, 3f);
        g.DrawPolygon(P(outline, 2f), tp);
        g.Restore(ts);
        g.Restore(st);
    }

    private void DrawWreck(Graphics g, float x, float y, float scale, float time)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(x, y);
        g.ScaleTransform(scale, scale);
        g.FillRectangle(B(Color.FromArgb(255, 36, 34, 34)), -46f, -26f, 92f, 24f);
        g.FillRectangle(B(Color.FromArgb(255, 52, 50, 48)), -34f, -42f, 64f, 18f);
        g.FillRectangle(B(Color.FromArgb(255, 28, 28, 28)), -40f, -6f, 80f, 8f);
        g.DrawLine(P(Color.FromArgb(255, 40, 40, 40), 6f), 10f, -36f, 52f, -26f);
        g.Restore(st);
        float f = 0.6f + 0.4f * MathF.Sin(time * 25f + x);
        g.FillEllipse(B(Color.FromArgb(A(200 * f), 255, 130, 30)), x - 10f, y - 50f, 20f, 22f * f);
        for (int i = 0; i < 3; i++)
        {
            float u = (time * 0.7f + i * 0.33f) % 1f;
            g.FillEllipse(B(Color.FromArgb(A(110 * (1f - u)), 40, 40, 42)), x - 8f + u * 14f, y - 54f - u * 50f, 14f + u * 14f, 14f + u * 14f);
        }
    }

    public void DrawEnemyTank(Graphics g, Vehicle v, float time)
    {
        float flash = v.HitFlash > 0f ? 0.6f : 0f;
        if (v.Dying)
        {
            DrawWreck(g, v.X, v.Y, 1.7f, time);
            return;
        }
        DrawTankShape(g, v.X, v.Y, v.Facing, 1.75f, v.TurretAngle, v.Recoil, v.TrackPhase,
            Color.FromArgb(255, 176, 150, 98), Color.FromArgb(255, 206, 182, 128), Color.FromArgb(255, 120, 98, 62), Color.FromArgb(255, 190, 50, 44), flash, false, false);
        g.FillRectangle(B(Color.FromArgb(255, 150, 36, 36)), v.X - 20f, v.Y - 90f, 6f, 6f);
    }

    // ------------------------------------------------------------------ the armored car

    public void DrawArmored(Graphics g, Vehicle v, float time)
    {
        float flash = v.HitFlash > 0f ? 0.6f : 0f;
        if (v.Dying)
        {
            DrawWreck(g, v.X, v.Y, 1.15f, time);
            return;
        }
        g.FillEllipse(B(Color.FromArgb(55, 0, 0, 0)), v.X - 60f, v.Y - 4f, 120f, 8f);
        GraphicsState st = g.Save();
        g.TranslateTransform(v.X, v.Y);
        g.ScaleTransform(v.Facing, 1f);
        Color outline = Color.FromArgb(255, 24, 28, 18);
        Color body = C(92, 108, 62, flash, 1f);
        Color dark = C(64, 78, 44, flash, 1f);
        Color light = C(124, 142, 84, flash, 1f);

        g.FillRectangle(B(dark), -56f, -28f, 112f, 20f);                                  // chassis
        PointF[] hood = { new PointF(14f, -28f), new PointF(58f, -28f), new PointF(58f, -40f), new PointF(22f, -46f) };
        g.FillPolygon(B(body), hood);
        g.DrawPolygon(P(outline, 2f), hood);
        PointF[] cabin = { new PointF(-52f, -28f), new PointF(-52f, -50f), new PointF(-2f, -54f), new PointF(14f, -46f), new PointF(14f, -28f) };
        g.FillPolygon(B(body), cabin);
        g.FillRectangle(B(light), -52f, -52f, 56f, 4f);
        g.DrawPolygon(P(outline, 2f), cabin);
        PointF[] glass = { new PointF(0f, -48f), new PointF(12f, -44f), new PointF(12f, -32f), new PointF(0f, -32f) };
        g.FillPolygon(B(Color.FromArgb(255, 150, 200, 232)), glass);
        g.DrawPolygon(P(outline, 1.6f), glass);
        // the grille of the front like a classic jeep
        g.FillRectangle(B(Color.FromArgb(255, 54, 58, 44)), 52f, -40f, 8f, 14f);
        for (int i = 0; i < 4; i++) g.DrawLine(P(Color.FromArgb(255, 150, 156, 140), 1.2f), 53f + i * 1.6f, -39f, 53f + i * 1.6f, -27f);
        g.FillEllipse(B(Color.FromArgb(255, 250, 230, 140)), 46f, -37f, 7f, 7f);
        // the door with an emblem
        g.FillEllipse(B(Color.FromArgb(255, 238, 238, 228)), -30f, -46f, 16f, 16f);
        Star(g, -22f, -38f, 7f, Color.FromArgb(255, 200, 40, 40));
        // the wheels
        for (int i = 0; i < 2; i++)
        {
            float wx = i == 0 ? -32f : 34f;
            g.FillEllipse(B(Color.FromArgb(255, 30, 30, 32)), wx - 15f, -30f, 30f, 30f);
            g.FillEllipse(B(Color.FromArgb(255, 124, 128, 134)), wx - 8f, -23f, 16f, 16f);
            float a = v.TrackPhase * 1.2f + i;
            g.DrawLine(P(Color.FromArgb(255, 60, 62, 68), 2f), wx, -15f, wx + MathF.Cos(a) * 7f, -15f + MathF.Sin(a) * 7f);
            g.DrawEllipse(P(outline, 2f), wx - 15f, -30f, 30f, 30f);
        }
        // roll bar, the mounted gun and its gunner
        g.DrawLine(P(Color.FromArgb(255, 56, 62, 48), 3f), -40f, -52f, -40f, -66f);
        g.DrawLine(P(Color.FromArgb(255, 56, 62, 48), 3f), -40f, -66f, -6f, -66f);
        float rc = v.Recoil * 4f;
        g.FillRectangle(B(Color.FromArgb(255, 44, 46, 40)), -4f - rc, -70f, 40f, 6f);
        g.FillRectangle(B(Color.FromArgb(255, 100, 102, 94)), -4f - rc, -70f, 40f, 2f);
        g.FillRectangle(B(Color.FromArgb(255, 36, 38, 32)), -12f, -74f, 12f, 12f);
        g.FillEllipse(B(Color.FromArgb(255, 226, 180, 138)), -26f, -66f, 10f, 11f);
        g.FillEllipse(B(Color.FromArgb(255, 94, 118, 64)), -28f, -72f, 14f, 9f);
        g.FillRectangle(B(Color.FromArgb(255, 98, 128, 72)), -28f, -56f, 14f, 8f);
        if (v.Recoil > 0.3f) MuzzleFlash(g, 42f, -67f, 9f, 1f);
        g.Restore(st);
    }

    // ------------------------------------------------------------------ the boss

    public void DrawBoss(Graphics g, Boss b, float time)
    {
        float flash = b.HitFlash > 0f ? 0.6f : 0f;
        float shake = b.Dying ? MathF.Sin(time * 50f) * 3f : 0f;
        g.FillEllipse(B(Color.FromArgb(60, 0, 0, 0)), b.X - 190f, GameConfig.GroundY - 5f, 380f, 10f);

        GraphicsState st = g.Save();
        g.TranslateTransform(b.X + shake, b.Y);
        Color outline = Color.FromArgb(255, 20, 22, 26);
        Color steel = C(92, 100, 114, flash, 1f);
        Color steelLight = C(130, 140, 156, flash, 1f);
        Color steelDark = C(58, 64, 76, flash, 1f);
        Color warn = Color.FromArgb(255, 226, 184, 40);

        // the giant tracks with road wheels
        g.FillRectangle(B(Color.FromArgb(255, 40, 40, 44)), -172f, -50f, 344f, 50f);
        g.DrawRectangle(P(outline, 3f), -172f, -50f, 344f, 50f);
        for (int i = 0; i < 24; i++)
        {
            float u = ((i / 24f) + b.TrackPhase * 0.04f) % 1f;
            if (u < 0f) u += 1f;
            float tx = -164f + u * 328f;
            g.FillRectangle(B(Color.FromArgb(255, 72, 72, 78)), tx - 4f, -6f, 8f, 5f);
            g.FillRectangle(B(Color.FromArgb(255, 72, 72, 78)), tx - 4f, -49f, 8f, 5f);
        }
        for (int i = 0; i < 9; i++)
        {
            float wx = -146f + i * 36.5f;
            g.FillEllipse(B(Color.FromArgb(255, 88, 90, 100)), wx - 17f, -43f, 34f, 34f);
            g.DrawEllipse(P(outline, 2.5f), wx - 17f, -43f, 34f, 34f);
            g.FillEllipse(B(Color.FromArgb(255, 150, 152, 162)), wx - 7f, -33f, 14f, 14f);
        }

        // the hull
        PointF[] hull = { new PointF(-162f, -50f), new PointF(-170f, -102f), new PointF(-150f, -142f), new PointF(-100f, -152f), new PointF(110f, -152f), new PointF(154f, -128f), new PointF(166f, -50f) };
        g.FillPolygon(B(steel), hull);
        g.FillRectangle(B(steelLight), -100f, -152f, 210f, 6f);
        g.FillRectangle(B(steelDark), -166f, -66f, 332f, 16f);
        g.DrawPolygon(P(outline, 3.5f), hull);
        for (float x = -140f; x < 150f; x += 38f)
        {
            g.DrawLine(P(Color.FromArgb(255, 44, 50, 60), 2f), x, -146f, x, -68f);
            g.FillEllipse(B(Color.FromArgb(255, 150, 156, 168)), x - 3f, -140f, 6f, 6f);
            g.FillEllipse(B(Color.FromArgb(255, 150, 156, 168)), x - 3f, -78f, 6f, 6f);
        }
        // red warning stripes along the lower hull
        for (float x = -160f; x < 150f; x += 28f)
        {
            quad[0] = new PointF(x, -66f);
            quad[1] = new PointF(x + 14f, -66f);
            quad[2] = new PointF(x + 6f, -52f);
            quad[3] = new PointF(x - 8f, -52f);
            g.FillPolygon(B(warn), quad);
        }
        // the enemy emblem
        g.FillEllipse(B(Color.FromArgb(255, 238, 238, 228)), 60f, -132f, 40f, 40f);
        Star(g, 80f, -112f, 17f, Color.FromArgb(255, 200, 40, 40));

        // the command bunker on the roof with lit windows and an antenna
        g.FillRectangle(B(steel), -50f, -192f, 150f, 42f);
        g.FillRectangle(B(steelLight), -50f, -192f, 150f, 5f);
        g.DrawRectangle(P(outline, 3f), -50f, -192f, 150f, 42f);
        for (int i = 0; i < 4; i++) g.FillRectangle(B(Color.FromArgb(255, 255, 214, 100)), -40f + i * 34f, -180f, 22f, 12f);
        g.DrawLine(P(Color.FromArgb(255, 60, 62, 70), 2f), 90f, -192f, 90f, -228f);
        bool blink = ((int)(time * 3f) & 1) == 0;
        g.FillEllipse(B(blink ? Color.FromArgb(255, 255, 70, 60) : Color.FromArgb(255, 120, 30, 30)), 87f, -232f, 7f, 7f);

        // the roof mortar and two smoke stacks
        g.FillRectangle(B(Color.FromArgb(255, 48, 52, 60)), 14f, -206f, 12f, 16f);
        g.DrawRectangle(P(outline, 2f), 14f, -206f, 12f, 16f);
        for (int s = 0; s < 2; s++)
        {
            float sx = 40f + s * 36f;
            g.FillRectangle(B(Color.FromArgb(255, 70, 74, 84)), sx, -176f, 14f, 28f);
            for (int k = 0; k < 4; k++)
            {
                float u = (time * 0.5f + k * 0.25f + s * 0.13f) % 1f;
                g.FillEllipse(B(Color.FromArgb(A(120 * (1f - u)), 50, 50, 54)), sx + u * 26f - 4f, -200f - u * 60f, 12f + u * 22f, 12f + u * 22f);
            }
        }

        // the main cannon at the front and the two machine guns
        float rc = b.Recoil * 14f;
        g.FillRectangle(B(Color.FromArgb(255, 58, 62, 72)), -178f - 70f + rc, -104f, 90f, 16f);
        g.FillRectangle(B(Color.FromArgb(255, 120, 126, 140)), -178f - 70f + rc, -104f, 90f, 4f);
        g.FillRectangle(B(Color.FromArgb(255, 36, 38, 44)), -250f + rc, -107f, 10f, 22f);
        g.DrawRectangle(P(outline, 2f), -248f + rc, -104f, 90f, 16f);
        float gunAngle = Math.Max(-0.4f, Math.Min(0.7f, b.TurretAngle));
        for (int k = 0; k < 2; k++)
        {
            float gx = b.Gun1X - b.X + k * 50f;
            float gy = b.Gun1Y - b.Y - k * 26f;
            GraphicsState gs = g.Save();
            g.TranslateTransform(gx, gy);
            g.RotateTransform(180f - gunAngle * 57.3f);
            g.FillRectangle(B(Color.FromArgb(255, 50, 54, 62)), 0f, -4f, 42f, 8f);
            g.FillRectangle(B(Color.FromArgb(255, 116, 122, 134)), 0f, -4f, 42f, 2.5f);
            g.Restore(gs);
            g.FillEllipse(B(Color.FromArgb(255, 70, 74, 84)), gx - 9f, gy - 9f, 18f, 18f);
            g.DrawEllipse(P(outline, 2f), gx - 9f, gy - 9f, 18f, 18f);
        }

        // later damage: scorch marks, glowing vents and flames
        if (b.Phase >= 2)
        {
            g.FillEllipse(B(Color.FromArgb(150, 20, 20, 20)), -120f, -140f, 70f, 40f);
            float f = 0.6f + 0.4f * MathF.Sin(time * 14f);
            g.FillEllipse(B(Color.FromArgb(A(210 * f), 255, 140, 40)), -100f, -128f, 26f, 22f * f);
            g.FillRectangle(B(Color.FromArgb(A(120 + 100 * f), 255, 80, 40)), 120f, -130f, 30f, 6f);
            g.FillRectangle(B(Color.FromArgb(A(120 + 100 * f), 255, 80, 40)), 120f, -116f, 30f, 6f);
        }
        if (flash > 0f) g.FillPolygon(B(Color.FromArgb(A(120 * flash / 0.6f), 255, 255, 255)), hull);
        if (b.Dying) g.FillPolygon(B(Color.FromArgb(A(Math.Min(170f, b.DeathTimer * 45f)), 30, 10, 0)), hull);
        g.Restore(st);
    }

    // ------------------------------------------------------------------ pickups, shots, grenades

    public void DrawPickup(Graphics g, Pickup p, float time)
    {
        float bob = MathF.Sin(p.Age * 3f) * 3f;
        float x = p.X;
        float y = p.Y - 2f + bob;
        float pulse = 0.5f + 0.5f * MathF.Sin(p.Age * 5f);
        g.FillEllipse(B(Color.FromArgb(A(40 + 40 * pulse), 255, 240, 140)), x - 26f, y - 44f, 52f, 52f);
        Color face;
        string label;
        switch (p.Type)
        {
            case PickupType.HeavyMG: face = Color.FromArgb(255, 220, 170, 40); label = "H"; break;
            case PickupType.Shotgun: face = Color.FromArgb(255, 204, 60, 50); label = "S"; break;
            case PickupType.Rocket: face = Color.FromArgb(255, 70, 140, 70); label = "R"; break;
            case PickupType.Grenades: face = Color.FromArgb(255, 110, 120, 70); label = "G"; break;
            case PickupType.Life: face = Color.FromArgb(255, 50, 170, 80); label = "1UP"; break;
            case PickupType.Health: face = Color.FromArgb(255, 240, 240, 236); label = "+"; break;
            case PickupType.Armor: face = Color.FromArgb(255, 70, 120, 220); label = "A"; break;
            default: face = Color.FromArgb(255, 230, 190, 60); label = "$"; break;
        }
        float w = Pickup.Size;
        g.FillRectangle(B(Color.FromArgb(255, 150, 104, 56)), x - w / 2f, y - w, w, w);
        g.FillRectangle(B(face), x - w / 2f + 3f, y - w + 3f, w - 6f, w - 6f);
        g.DrawRectangle(P(Color.FromArgb(255, 60, 40, 20), 2.5f), x - w / 2f, y - w, w, w);
        g.FillRectangle(B(Color.FromArgb(255, 200, 204, 210)), x - w / 2f, y - w, 5f, 5f);
        g.FillRectangle(B(Color.FromArgb(255, 200, 204, 210)), x + w / 2f - 5f, y - w, 5f, 5f);
        if (p.Type == PickupType.Health)
        {
            g.FillRectangle(B(Color.FromArgb(255, 210, 40, 40)), x - 3f, y - w + 6f, 6f, w - 12f);
            g.FillRectangle(B(Color.FromArgb(255, 210, 40, 40)), x - w / 2f + 6f, y - w / 2f - 3f, w - 12f, 6f);
        }
        else if (p.Type == PickupType.Grenades)
        {
            g.FillEllipse(B(Color.FromArgb(255, 50, 62, 36)), x - 7f, y - w + 8f, 14f, 15f);
            g.FillRectangle(B(Color.FromArgb(255, 180, 184, 190)), x - 2f, y - w + 5f, 4f, 4f);
        }
        else
        {
            g.DrawString(label, fPick, B(p.Type == PickupType.Life ? Color.White : Color.FromArgb(255, 30, 24, 20)), x, y - w / 2f + 1f, sfCenter);
        }
    }

    public void DrawProjectile(Graphics g, Projectile p)
    {
        float sp = MathF.Sqrt(p.VX * p.VX + p.VY * p.VY);
        float nx = sp > 0.01f ? p.VX / sp : 1f;
        float ny = sp > 0.01f ? p.VY / sp : 0f;
        switch (p.Kind)
        {
            case ShotKind.Bullet:
                g.DrawLine(P(Color.FromArgb(120, 255, 200, 60), 5f), p.X - nx * 14f, p.Y - ny * 14f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.FromArgb(255, 255, 240, 140), 2.5f), p.X - nx * 12f, p.Y - ny * 12f, p.X + nx * 4f, p.Y + ny * 4f);
                break;
            case ShotKind.Heavy:
                g.DrawLine(P(Color.FromArgb(130, 255, 150, 40), 7f), p.X - nx * 18f, p.Y - ny * 18f, p.X + nx * 5f, p.Y + ny * 5f);
                g.DrawLine(P(Color.FromArgb(255, 255, 230, 120), 3.5f), p.X - nx * 15f, p.Y - ny * 15f, p.X + nx * 5f, p.Y + ny * 5f);
                break;
            case ShotKind.Pellet:
                g.FillEllipse(B(Color.FromArgb(255, 255, 230, 130)), p.X - 2.5f, p.Y - 2.5f, 5f, 5f);
                g.FillEllipse(B(Color.FromArgb(110, 255, 180, 60)), p.X - 4.5f, p.Y - 4.5f, 9f, 9f);
                break;
            case ShotKind.Rocket:
                {
                    float fl = 0.7f + 0.3f * MathF.Sin(p.Life * 80f);
                    g.FillEllipse(B(Color.FromArgb(200, 255, 160, 40)), p.X - nx * 26f - 10f * fl, p.Y - ny * 26f - 7f, 22f * fl, 14f);
                    g.FillEllipse(B(Color.FromArgb(255, 255, 240, 160)), p.X - nx * 18f - 6f, p.Y - ny * 18f - 4f, 12f, 8f);
                    g.DrawLine(P(Color.FromArgb(255, 70, 80, 60), 7f), p.X - nx * 12f, p.Y - ny * 12f, p.X + nx * 8f, p.Y + ny * 8f);
                    g.DrawLine(P(Color.FromArgb(255, 140, 150, 130), 3f), p.X - nx * 12f, p.Y - ny * 12f, p.X + nx * 8f, p.Y + ny * 8f);
                    g.FillEllipse(B(Color.FromArgb(255, 210, 50, 44)), p.X + nx * 8f - 4f, p.Y + ny * 8f - 4f, 8f, 8f);
                    break;
                }
            case ShotKind.TankMG:
                g.DrawLine(P(Color.FromArgb(130, 255, 220, 80), 6f), p.X - nx * 14f, p.Y - ny * 14f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.FromArgb(255, 255, 255, 200), 3f), p.X - nx * 12f, p.Y - ny * 12f, p.X + nx * 4f, p.Y + ny * 4f);
                break;
            case ShotKind.TankShell:
                g.FillEllipse(B(Color.FromArgb(150, 255, 150, 40)), p.X - nx * 22f - 12f, p.Y - ny * 22f - 8f, 26f, 16f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 220, 100)), p.X - 9f, p.Y - 9f, 18f, 18f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 250, 210)), p.X - 5f, p.Y - 5f, 10f, 10f);
                break;
            case ShotKind.EBullet:
                g.DrawLine(P(Color.FromArgb(120, 255, 80, 40), 6f), p.X - nx * 9f, p.Y - ny * 9f, p.X + nx * 3f, p.Y + ny * 3f);
                g.DrawLine(P(Color.FromArgb(255, 255, 150, 60), 3.5f), p.X - nx * 8f, p.Y - ny * 8f, p.X + nx * 3f, p.Y + ny * 3f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 240, 170)), p.X - 2f, p.Y - 2f, 4f, 4f);
                break;
            case ShotKind.EHeavy:
                g.FillEllipse(B(Color.FromArgb(110, 255, 60, 40)), p.X - 8f, p.Y - 8f, 16f, 16f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 90, 50)), p.X - 5f, p.Y - 5f, 10f, 10f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 230, 160)), p.X - 2.5f, p.Y - 2.5f, 5f, 5f);
                break;
            case ShotKind.ESniper:
                g.DrawLine(P(Color.FromArgb(110, 120, 200, 255), 6f), p.X - nx * 34f, p.Y - ny * 34f, p.X + nx * 4f, p.Y + ny * 4f);
                g.DrawLine(P(Color.FromArgb(255, 235, 248, 255), 2.4f), p.X - nx * 30f, p.Y - ny * 30f, p.X + nx * 4f, p.Y + ny * 4f);
                break;
            case ShotKind.EShell:
                g.FillEllipse(B(Color.FromArgb(150, 255, 130, 30)), p.X - nx * 20f - 10f, p.Y - ny * 20f - 7f, 22f, 14f);
                g.FillEllipse(B(Color.FromArgb(255, 60, 56, 52)), p.X - 8f, p.Y - 8f, 16f, 16f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 160, 60)), p.X - 4f, p.Y - 4f, 8f, 8f);
                break;
            default:    // mortar bomb
                g.FillEllipse(B(Color.FromArgb(255, 44, 44, 48)), p.X - 8f, p.Y - 8f, 16f, 16f);
                g.FillEllipse(B(Color.FromArgb(255, 110, 112, 120)), p.X - 5f, p.Y - 6f, 6f, 5f);
                g.FillEllipse(B(Color.FromArgb(255, 255, 220, 90)), p.X - 2f, p.Y - 13f, 5f, 5f);
                break;
        }
    }

    public void DrawGrenade(Graphics g, Grenade gr, float time)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(gr.X, gr.Y);
        g.RotateTransform(gr.Rot * 57.3f);
        Color body = gr.FromPlayer ? Color.FromArgb(255, 84, 104, 58) : Color.FromArgb(255, 110, 70, 50);
        g.FillEllipse(B(body), -5.5f, -7f, 11f, 14f);
        g.FillEllipse(B(Color.FromArgb(120, 255, 255, 255)), -3.5f, -5.5f, 4f, 5f);
        g.DrawEllipse(P(Color.FromArgb(255, 30, 36, 24), 1.5f), -5.5f, -7f, 11f, 14f);
        g.FillRectangle(B(Color.FromArgb(255, 180, 184, 190)), -2.5f, -10f, 5f, 4f);
        g.Restore(st);
        if (gr.Fuse < 0.45f && ((int)(time * 24f) & 1) == 0)
            g.FillEllipse(B(Color.FromArgb(200, 255, 80, 40)), gr.X - 10f, gr.Y - 10f, 20f, 20f);
    }

    // ------------------------------------------------------------------ explosions and particles

    public void DrawExplosion(Graphics g, Explosion e)
    {
        if (e.Age < 0f) return;
        float t = e.Progress;
        float ease = 1f - (1f - t) * (1f - t);
        float r = e.Size * (0.3f + 0.7f * ease);
        float fade = 1f - t;
        if (t > 0.4f)
        {
            float s = (t - 0.4f) / 0.6f;
            g.FillEllipse(B(Color.FromArgb(A(150 * (1f - s)), 40, 38, 40)), e.X - r * 1.1f, e.Y - r * 1.25f - 10f * s, r * 2.2f, r * 2.2f);
        }
        g.FillEllipse(B(Color.FromArgb(A(235 * fade), 255, 90, 24)), e.X - r, e.Y - r, r * 2f, r * 2f);
        g.FillEllipse(B(Color.FromArgb(A(245 * fade), 255, 176, 40)), e.X - r * 0.74f, e.Y - r * 0.74f, r * 1.48f, r * 1.48f);
        float core = r * 0.5f * fade;
        g.FillEllipse(B(Color.FromArgb(A(255 * fade * fade + 20), 255, 250, 200)), e.X - core, e.Y - core, core * 2f, core * 2f);
        if (e.Kind != ExplosionKind.Small)
        {
            float rr = e.Size * (0.4f + 1.2f * t);
            g.DrawEllipse(P(Color.FromArgb(A(200 * fade), 255, 230, 170), 3f), e.X - rr, e.Y - rr, rr * 2f, rr * 2f);
        }
    }

    public void DrawParticles(Graphics g, ParticleSystem ps)
    {
        for (int i = 0; i < ps.Count; i++)
        {
            Particle p = ps.Items[i];
            float k = p.Life / p.MaxLife;
            switch (p.Kind)
            {
                case 0:
                    {
                        float r = p.Size * (1f + (1f - k) * 1.4f);
                        g.FillEllipse(B(Color.FromArgb(A(130 * k), p.R, p.G, p.B)), p.X - r, p.Y - r, r * 2f, r * 2f);
                        break;
                    }
                case 1:
                    {
                        float vx = p.VX * 0.03f;
                        float vy = p.VY * 0.03f;
                        g.DrawLine(P(Color.FromArgb(A(255 * k), p.R, p.G, p.B), p.Size), p.X, p.Y, p.X - vx, p.Y - vy);
                        break;
                    }
                case 2:
                    {
                        float c = MathF.Cos(p.Rot) * p.Size;
                        float s = MathF.Sin(p.Rot) * p.Size;
                        quad[0] = new PointF(p.X - c - s * 0.5f, p.Y - s + c * 0.5f);
                        quad[1] = new PointF(p.X + c - s * 0.5f, p.Y + s + c * 0.5f);
                        quad[2] = new PointF(p.X + c + s * 0.5f, p.Y + s - c * 0.5f);
                        quad[3] = new PointF(p.X - c + s * 0.5f, p.Y - s - c * 0.5f);
                        g.FillPolygon(B(Color.FromArgb(A(255 * Math.Min(1f, k * 2f)), p.R, p.G, p.B)), quad);
                        break;
                    }
                case 3:
                    {
                        float r = p.Size * (1f - k);
                        g.DrawEllipse(P(Color.FromArgb(A(220 * k), p.R, p.G, p.B), 3f), p.X - r, p.Y - r, r * 2f, r * 2f);
                        break;
                    }
                default:
                    {
                        float r = p.Size * k;
                        g.FillEllipse(B(Color.FromArgb(A(220 * k), p.R, p.G, p.B)), p.X - r, p.Y - r, r * 2f, r * 2f);
                        break;
                    }
            }
        }
        foreach (FloatText t in ps.Texts)
        {
            float a = Math.Min(1f, t.Life * 2f);
            g.DrawString(t.Text, fText, B(Color.FromArgb(A(200 * a), 0, 0, 0)), t.X + 1f, t.Y + 1f, sfCenter);
            g.DrawString(t.Text, fText, B(Color.FromArgb(A(255 * a), t.Color.R, t.Color.G, t.Color.B)), t.X, t.Y, sfCenter);
        }
    }
}
