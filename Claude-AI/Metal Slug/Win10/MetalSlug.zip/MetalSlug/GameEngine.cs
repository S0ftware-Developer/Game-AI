namespace MetalSlug;

public enum GameState { Menu, Playing, Paused, GameOver, Victory }

/// <summary>Game rules and the fixed-step simulation (1/120 s): the battlefield, the soldier and his tank, enemies, boss.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;

    public GameState State = GameState.Menu;
    public Level Level;
    public readonly Player Player = new Player();
    public readonly PlayerTank Tank = new PlayerTank();
    public readonly ProjectileManager Shots = new ProjectileManager();
    public readonly GrenadeManager Grenades = new GrenadeManager();
    public readonly EnemyManager Enemies = new EnemyManager();
    public readonly Boss Boss = new Boss();
    public readonly PickupManager Pickups = new PickupManager();
    public readonly ExplosionManager Explosions = new ExplosionManager();
    public readonly ParticleSystem Particles = new ParticleSystem();
    public readonly Camera Camera = new Camera();
    public readonly ScoreManager Scores = new ScoreManager();

    // input set by the window
    public bool Left, Right, Up, Down, Fire, JumpHeld, GrenadeHeld;

    public float Clock;                  // keeps running for menu animations
    public float PlayTime;
    public int Score;
    public int Kills;
    public bool NewRecord;
    public float Flash;
    public string Banner = "";
    public float BannerTimer;
    public string Note = "";
    public float NoteTimer;

    private bool jumpQ, grenadeQ, enterQ;
    private bool bossSpawned;
    private float endTimer;
    private readonly Random rng = new Random();

    public GameEngine()
    {
        Scores.Load();
        Level = Level.Build();
        Enemies.EnemyKilled = OnEnemyKilled;
        Enemies.VehicleKilled = OnVehicleKilled;
        ResetWorld();
    }

    private void ResetWorld()
    {
        Level = Level.Build();
        Enemies.Reset(Level);
        Pickups.Reset(Level);
        Shots.Clear();
        Grenades.Clear();
        Explosions.Clear();
        Particles.Clear();
        Boss.Reset();
        Camera.Reset();
        Player.Reset(80f, GameConfig.GroundY);
        Tank.Reset(Level.TankX);
        Score = 0;
        Kills = 0;
        PlayTime = 0f;
        NewRecord = false;
        Flash = 0f;
        Note = "";
        NoteTimer = 0f;
        bossSpawned = false;
        endTimer = 0f;
        jumpQ = false;
        grenadeQ = false;
        enterQ = false;
    }

    // ------------------------------------------------------------------ flow

    public void StartGame()
    {
        ResetWorld();
        State = GameState.Playing;
        Sfx.Play(SfxId.Click);
        Banner = "MISSION START";
        BannerTimer = 2.2f;
    }

    public void Resume()
    {
        if (State != GameState.Paused) return;
        Sfx.Play(SfxId.Click);
        State = GameState.Playing;
    }

    public void Pause()
    {
        if (State != GameState.Playing) return;
        ClearInput();
        Sfx.Play(SfxId.Click);
        State = GameState.Paused;
    }

    public void GoToMenu()
    {
        ClearInput();
        Sfx.Play(SfxId.Click);
        State = GameState.Menu;
    }

    public void AutoPause()
    {
        ClearInput();
        if (State == GameState.Playing) State = GameState.Paused;
    }

    private void ClearInput()
    {
        Left = false; Right = false; Up = false; Down = false; Fire = false; JumpHeld = false; GrenadeHeld = false;
        jumpQ = false; grenadeQ = false; enterQ = false;
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                if (State == GameState.Menu || State == GameState.GameOver || State == GameState.Victory) StartGame();
                else if (State == GameState.Paused) Resume();
                break;
            case Keys.Space:
                if (State == GameState.Menu) StartGame();
                else if (State == GameState.Playing) jumpQ = true;
                break;
            case Keys.K:
            case Keys.X:
                if (State == GameState.Playing) grenadeQ = true;
                break;
            case Keys.E:
                if (State == GameState.Playing) enterQ = true;
                break;
            case Keys.Escape:
            case Keys.P:
                if (State == GameState.Playing) Pause();
                else if (State == GameState.Paused) Resume();
                else if ((State == GameState.GameOver || State == GameState.Victory) && key == Keys.Escape) GoToMenu();
                break;
            case Keys.R:
                if (State != GameState.Menu) StartGame();
                break;
            case Keys.M:
                if (State == GameState.Paused || State == GameState.GameOver || State == GameState.Victory) GoToMenu();
                break;
            case Keys.N:
                Sfx.SetMuted(!Sfx.Muted);
                break;
        }
    }

    // ------------------------------------------------------------------ simulation

    public void Update()
    {
        Clock += Dt;
        if (State == GameState.Menu || State == GameState.Paused) return;

        if (State == GameState.GameOver || State == GameState.Victory)
        {
            Shots.Update(Dt, Level);
            ProcessExplosions();
            UpdateEffects();
            return;
        }

        PlayTime += Dt;
        PlayerInput inp = new PlayerInput();
        inp.Left = Left; inp.Right = Right; inp.Up = Up; inp.Down = Down; inp.Fire = Fire;
        inp.JumpHeld = JumpHeld; inp.GrenadeHeld = GrenadeHeld;
        inp.JumpPressed = jumpQ; inp.GrenadePressed = grenadeQ; inp.EnterPressed = enterQ;
        jumpQ = false;
        grenadeQ = false;
        enterQ = false;

        float camLeft = Camera.X;
        float camRight = Camera.X + GameConfig.LogicalW;

        if (inp.EnterPressed) HandleEnter();

        Player.Update(Dt, inp, Level, Shots, camLeft, camRight);
        PlayerInput tankInp = Player.InTank ? inp : new PlayerInput();
        Tank.Update(Dt, tankInp, Level, Shots, camLeft, camRight);
        if (Player.InTank)
        {
            Player.X = Tank.X;
            Player.Y = Tank.Y;
            Player.Facing = Tank.Facing;
            Player.Grounded = Tank.Grounded;
            Player.Crouching = false;
        }
        HandlePlayerEvents();

        float tx = Player.InTank ? Tank.X : Player.X;
        float ty = (Player.InTank ? Tank.Y - 30f : Player.Y - 24f);

        bool fired, threw;
        Enemies.Update(Dt, camLeft, camRight, tx, ty, Level, Shots, Grenades, out fired, out threw);
        if (fired) Sfx.Play(SfxId.EnemyShoot);
        if (threw) Sfx.Play(SfxId.GrenadeThrow);

        UpdateBoss(tx, ty);

        Shots.Update(Dt, Level);
        Grenades.Update(Dt, Level);
        Pickups.Update(Dt);

        CollisionManager.Resolve(this);
        ProcessExplosions();

        // death, respawn and the end of the game
        if (Player.Dead && Player.DeathTimer <= 0f)
        {
            if (Player.Lives > 0)
            {
                Player.Respawn(Camera.X + 90f, 120f);
                Particles.Ring(Player.X, Player.Y - 20f, 60f, Color.White);
            }
            else
            {
                endTimer += Dt;
                if (endTimer >= 0.6f) EndGame(false);
            }
        }

        float focus = Player.InTank ? Tank.X : Player.X;
        Camera.Update(Dt, focus, Player.Facing, GameConfig.ArenaStartX);
        UpdateEffects();
    }

    private void UpdateEffects()
    {
        Particles.Update(Dt);
        Explosions.Update(Dt);
        if (Flash > 0f) Flash = Math.Max(0f, Flash - Dt);
        if (BannerTimer > 0f) BannerTimer -= Dt;
        if (NoteTimer > 0f) NoteTimer -= Dt;
    }

    private void HandleEnter()
    {
        if (Player.Dead) return;
        if (!Player.InTank)
        {
            if (!Tank.Destroyed && !Tank.Occupied && Math.Abs(Player.X - Tank.X) < 80f && Math.Abs(Player.Y - Tank.Y) < 70f)
            {
                Player.InTank = true;
                Tank.Occupied = true;
                Player.VX = 0f;
                Player.VY = 0f;
                Notify("TANK READY!  J: MACHINE GUN   K: CANNON   E: EXIT");
                Sfx.Play(SfxId.Pickup);
                Particles.Ring(Tank.X, Tank.Y - 30f, 60f, Color.FromArgb(255, 255, 220, 120));
            }
        }
        else
        {
            ExitTank();
        }
    }

    private void ExitTank()
    {
        Player.InTank = false;
        Tank.Occupied = false;
        Player.X = Tank.X - Tank.Facing * 62f;
        Player.Y = Tank.Y;
        Player.VY = -320f;
        Player.VX = 0f;
        Player.Invuln = Math.Max(Player.Invuln, 0.5f);
        Sfx.Play(SfxId.Click);
    }

    private void Notify(string text)
    {
        Note = text;
        NoteTimer = 2.6f;
    }

    private void HandlePlayerEvents()
    {
        if (Player.EvJump)
        {
            Sfx.Play(SfxId.Jump);
            Dust(Player.X, Player.Y);
        }
        if (Player.EvLand) Dust(Player.X, Player.Y);
        if (Player.EvThrow)
        {
            Grenades.Throw(Player.ThrowX, Player.ThrowY, Player.ThrowVX, Player.ThrowVY, true);
            Sfx.Play(SfxId.GrenadeThrow);
        }
        WeaponSystem w = Player.Weapon;
        if (w.EvShot)
        {
            w.EvShot = false;
            switch (w.EvType)
            {
                case WeaponType.Heavy: Sfx.Play(SfxId.HeavyGun); break;
                case WeaponType.Shotgun: Sfx.Play(SfxId.Shotgun); break;
                case WeaponType.Rocket: Sfx.Play(SfxId.Rocket); break;
                default: Sfx.Play(SfxId.MachineGun); break;
            }
            Particles.Sparks(Player.MuzzleX, Player.MuzzleY, 90f, 2, Color.FromArgb(255, 235, 150));
        }
        if (Tank.EvMg)
        {
            Sfx.Play(SfxId.MachineGun);
            Particles.Sparks(Tank.MuzzleX, Tank.MuzzleY, 80f, 1, Color.FromArgb(255, 235, 150));
        }
        if (Tank.EvCannon)
        {
            Sfx.Play(SfxId.TankCannon);
            Particles.Sparks(Tank.MuzzleX, Tank.MuzzleY, 160f, 6, Color.FromArgb(255, 200, 100));
            Particles.Smoke(Tank.MuzzleX, Tank.MuzzleY, Tank.AimX * 30f, Tank.AimY * 30f, 10f, 0.7f, 150);
            Camera.Shake = Math.Max(Camera.Shake, 0.1f);
        }
    }

    private void Dust(float x, float y)
    {
        for (int i = 0; i < 4; i++)
            Particles.Smoke(x + (float)(rng.NextDouble() * 12.0 - 6.0), y - 2f, (float)(rng.NextDouble() * 80.0 - 40.0), -20f, 5f, 0.4f, 190);
    }

    private void UpdateBoss(float tx, float ty)
    {
        if (!bossSpawned && tx > GameConfig.BossTriggerX)
        {
            bossSpawned = true;
            Boss.Spawn();
            Banner = "WARNING!";
            BannerTimer = 3.6f;
            Sfx.Play(SfxId.BossArrive);
        }

        Boss.Update(Dt, tx, ty, Shots, Explosions, Particles);
        if (Boss.EvFired) Sfx.Play(SfxId.EnemyShoot);
        if (Boss.EvPhaseChanged)
        {
            foreach (Projectile p in Shots.Items)
            {
                if (!p.FromPlayer) p.Alive = false;
            }
            Banner = "PHASE 2";
            BannerTimer = 2f;
            Sfx.Play(SfxId.VehicleBoom);
            Camera.Shake = 0.4f;
            Flash = 0.25f;
            Explosions.Add(Boss.X - 100f, Boss.Y - 120f, ExplosionKind.Large);
            Explosions.Add(Boss.X + 60f, Boss.Y - 150f, ExplosionKind.Large, 0.12f);
        }
        if (Boss.Dying)
        {
            if (Boss.DeathTimer < 0.05f)
            {
                foreach (Projectile p in Shots.Items)
                {
                    if (!p.FromPlayer) p.Alive = false;
                }
                Sfx.Play(SfxId.BossDie);
            }
            Camera.Shake = Math.Max(Camera.Shake, 0.12f);
        }
        if (Boss.EvDeathBlast) Sfx.Play(SfxId.VehicleBoom);
        if (Boss.EvDefeated)
        {
            Score += GameConfig.ScoreBoss;
            Camera.Shake = 0.8f;
            Flash = 0.6f;
            Sfx.Play(SfxId.BossDie);
            EndGame(true);
        }
    }

    private void EndGame(bool victory)
    {
        NewRecord = Scores.Submit(Score);
        ClearInput();
        State = victory ? GameState.Victory : GameState.GameOver;
        if (victory) Sfx.Play(SfxId.Victory);
    }

    // ------------------------------------------------------------------ explosions

    private void ProcessExplosions()
    {
        for (int i = 0; i < Shots.Detonated.Count; i++)
        {
            Detonation d = Shots.Detonated[i];
            bool tankShell = d.Kind == ShotKind.TankShell || d.Kind == ShotKind.Rocket;
            Explode(d.X, d.Y, d.Radius, d.Damage, d.FromPlayer, tankShell ? SfxId.GrenadeBoom : SfxId.GrenadeBoom);
        }
        Shots.Detonated.Clear();
        for (int i = 0; i < Grenades.Exploded.Count; i++)
        {
            Grenade gr = Grenades.Exploded[i];
            Explode(gr.X, gr.Y, GameConfig.GrenadeRadius, GameConfig.GrenadeDamage, gr.FromPlayer, SfxId.GrenadeBoom);
        }
        Grenades.Exploded.Clear();
    }

    /// <summary>An explosion with a visible blast ring that damages everything inside its radius.</summary>
    private void Explode(float x, float y, float radius, float dmg, bool fromPlayer, SfxId sound)
    {
        Explosions.Add(x, y, radius >= 70f ? ExplosionKind.Large : ExplosionKind.Small);
        Particles.Ring(x, y, radius * 1.5f, Color.FromArgb(255, 220, 140));
        Particles.Debris(x, y, 6, Color.FromArgb(120, 100, 80));
        Particles.Smoke(x, y - 8f, 0f, -30f, radius * 0.25f, 0.9f, 80);
        Sfx.Play(sound);
        Camera.Shake = Math.Max(Camera.Shake, radius >= 70f ? 0.18f : 0.1f);

        if (fromPlayer)
        {
            foreach (Enemy e in Enemies.Enemies)
            {
                if (e.Hittable && CollisionManager.CircleRect(x, y, radius, e.Rect)) Enemies.DamageEnemy(e, dmg);
            }
            foreach (Vehicle v in Enemies.Vehicles)
            {
                if (v.Hittable && CollisionManager.CircleRect(x, y, radius, v.Rect)) Enemies.DamageVehicle(v, dmg);
            }
            if (Boss.Vulnerable && CollisionManager.CircleRect(x, y, radius, Boss.Rect)) Boss.Damage(dmg);
        }
        else
        {
            if (Player.InTank)
            {
                if (!Tank.Destroyed && CollisionManager.CircleRect(x, y, radius, Tank.Rect)) TankHit((int)Math.Max(1f, dmg));
            }
            else if (CollisionManager.CircleRect(x, y, radius, Player.Rect))
            {
                PlayerHurt((int)Math.Max(1f, dmg));
            }
        }
    }

    // ------------------------------------------------------------------ damage

    public void PlayerHurt(int dmg)
    {
        if (!Player.Vulnerable) return;
        Player.Hp -= dmg;
        Player.HitFlash = 0.3f;
        Player.Invuln = GameConfig.HitInvulnerability;
        Camera.Shake = Math.Max(Camera.Shake, 0.12f);
        if (Player.Hp > 0)
        {
            Sfx.Play(SfxId.Hurt);
            Particles.Sparks(Player.X, Player.Y - 24f, 150f, 6, Color.FromArgb(255, 80, 60));
            return;
        }
        // a life is lost
        Player.Hp = 0;
        Player.Dead = true;
        Player.DeathTimer = GameConfig.DeathTime;
        Player.Lives--;
        Player.VY = -380f;
        Player.VX = -Player.Facing * 150f;
        Player.Grounded = false;
        Sfx.Play(SfxId.Hurt);
        Sfx.Play(SfxId.EnemyDie);
        Particles.Debris(Player.X, Player.Y - 24f, 10, Color.FromArgb(220, 60, 50));
        Particles.Sparks(Player.X, Player.Y - 24f, 220f, 10, Color.FromArgb(255, 90, 60));
    }

    public void TankHit(int dmg)
    {
        if (Tank.Hit(dmg))
        {
            Explosions.Add(Tank.X, Tank.Y - 30f, ExplosionKind.Boss);
            Explosions.Add(Tank.X - 40f, Tank.Y - 20f, ExplosionKind.Large, 0.12f);
            Particles.Debris(Tank.X, Tank.Y - 30f, 24, Color.FromArgb(120, 130, 90));
            Particles.Flames(Tank.X, Tank.Y - 30f, 28f, 14);
            Sfx.Play(SfxId.VehicleBoom);
            Camera.Shake = 0.5f;
            Flash = 0.3f;
            Player.InTank = false;
            Player.X = Tank.X;
            Player.Y = Tank.Y - 20f;
            Player.VY = -420f;
            Player.VX = -Tank.Facing * 120f;
            Player.Invuln = 1.8f;
            Banner = "TANK DESTROYED";
            BannerTimer = 1.8f;
        }
        else
        {
            Sfx.Play(SfxId.Hurt);
        }
    }

    // ------------------------------------------------------------------ events from the enemy and pickup code

    private void OnEnemyKilled(Enemy e)
    {
        Score += e.Score;
        Kills++;
        Sfx.Play(SfxId.EnemyDie);
        Particles.Debris(e.X, e.Y - 24f, 7, e.Type == EnemyType.Elite ? Color.FromArgb(120, 30, 40) : Color.FromArgb(110, 130, 70));
        Particles.Sparks(e.X, e.Y - 24f, 140f, 5, Color.FromArgb(255, 200, 120));
        Particles.Text(e.X, e.Y - 56f, e.Score.ToString(), Color.FromArgb(255, 255, 230, 120));
        if (rng.NextDouble() < 0.13)
        {
            PickupType[] pool = { PickupType.Grenades, PickupType.Health, PickupType.Score, PickupType.HeavyMG };
            Pickups.Spawn(e.X, e.Y, pool[rng.Next(pool.Length)]);
        }
    }

    private void OnVehicleKilled(Vehicle v)
    {
        Score += v.Score;
        Kills++;
        ExplosionKind big = v.Type == VehicleType.Tank ? ExplosionKind.Boss : ExplosionKind.Large;
        Explosions.Add(v.X, v.Y - v.Height / 2f, big);
        Explosions.Add(v.X - 30f, v.Y - 20f, ExplosionKind.Large, 0.15f);
        Explosions.Add(v.X + 30f, v.Y - v.Height + 10f, ExplosionKind.Large, 0.3f);
        Particles.Debris(v.X, v.Y - v.Height / 2f, 22, Color.FromArgb(100, 110, 80));
        Particles.Flames(v.X, v.Y - v.Height / 2f, 24f, 12);
        Particles.Text(v.X, v.Y - v.Height - 10f, v.Score.ToString(), Color.FromArgb(255, 255, 230, 120));
        Sfx.Play(SfxId.VehicleBoom);
        Camera.Shake = 0.4f;
    }

    public void CollectPickup(Pickup p)
    {
        p.Alive = false;
        Score += GameConfig.ScorePickup;
        bool tank = Player.InTank;
        switch (p.Type)
        {
            case PickupType.HeavyMG: Player.Weapon.Give(WeaponType.Heavy); Sfx.Play(SfxId.Pickup); break;
            case PickupType.Shotgun: Player.Weapon.Give(WeaponType.Shotgun); Sfx.Play(SfxId.Pickup); break;
            case PickupType.Rocket: Player.Weapon.Give(WeaponType.Rocket); Sfx.Play(SfxId.Pickup); break;
            case PickupType.Grenades:
                Player.Grenades = Math.Min(GameConfig.MaxGrenades, Player.Grenades + 6);
                Sfx.Play(SfxId.Pickup);
                break;
            case PickupType.Life:
                Player.Lives = Math.Min(GameConfig.MaxLives, Player.Lives + 1);
                Sfx.Play(SfxId.OneUp);
                break;
            case PickupType.Health:
                if (tank) Tank.Hp = Math.Min(GameConfig.TankMaxHp, Tank.Hp + 2);
                else Player.Hp = Math.Min(Math.Max(GameConfig.StartHealth, Player.Hp), Player.Hp + 1);
                Sfx.Play(SfxId.Pickup);
                break;
            case PickupType.Armor:
                if (tank) Tank.Hp = Math.Min(GameConfig.TankMaxHp, Tank.Hp + 4);
                else Player.Hp = Math.Min(GameConfig.MaxHealth, Player.Hp + 2);
                Sfx.Play(SfxId.Pickup);
                break;
            default:
                Score += GameConfig.ScoreMedal - GameConfig.ScorePickup;
                Sfx.Play(SfxId.Pickup);
                break;
        }
        Player.PickupAnim = 0.5f;
        Notify(Pickup.Label(p.Type));
        Particles.Ring(p.X, p.Y - 15f, 44f, Color.FromArgb(255, 240, 150));
        Particles.Sparks(p.X, p.Y - 15f, 180f, 8, Color.FromArgb(255, 240, 150));
        Particles.Text(p.X, p.Y - 44f, Pickup.Label(p.Type), Color.White);
    }
}
