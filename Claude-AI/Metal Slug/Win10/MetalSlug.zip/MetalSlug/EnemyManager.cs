namespace MetalSlug;

/// <summary>Owns all enemy soldiers and vehicles: creates them from the level, wakes them up when the camera nears.</summary>
public sealed class EnemyManager
{
    public readonly List<Enemy> Enemies = new List<Enemy>(64);
    public readonly List<Vehicle> Vehicles = new List<Vehicle>(8);
    public Action<Enemy>? EnemyKilled;
    public Action<Vehicle>? VehicleKilled;
    private readonly Random rng = new Random();

    public void Reset(Level level)
    {
        Enemies.Clear();
        Vehicles.Clear();
        foreach (EnemySpawn s in level.Enemies)
        {
            Enemy e = new Enemy();
            e.Init(s, rng);
            Enemies.Add(e);
        }
        foreach (VehicleSpawn s in level.Vehicles)
        {
            Vehicle v = new Vehicle();
            v.Init(s);
            Vehicles.Add(v);
        }
    }

    public void Update(float dt, float camLeft, float camRight, float tx, float ty, Level level, ProjectileManager shots, GrenadeManager grenades, out bool fired, out bool threw)
    {
        fired = false;
        threw = false;
        for (int i = Enemies.Count - 1; i >= 0; i--)
        {
            Enemy e = Enemies[i];
            if (!e.Active && e.X < camRight + 120f) e.Active = true;
            if (!e.Active) continue;
            bool visible = e.X > camLeft - 40f && e.X < camRight + 40f;
            bool f, t;
            e.Update(dt, tx, ty, visible, level, shots, grenades, rng, out f, out t);
            if (f) fired = true;
            if (t) threw = true;
            if ((e.Dying && e.DeathTimer <= 0f) || e.Y > GameConfig.ViewH + 100f) Enemies.RemoveAt(i);
        }
        for (int i = Vehicles.Count - 1; i >= 0; i--)
        {
            Vehicle v = Vehicles[i];
            if (!v.Active && v.X < camRight + 160f) v.Active = true;
            if (!v.Active) continue;
            bool visible = v.X > camLeft - 60f && v.X < camRight + 60f;
            bool f;
            v.Update(dt, tx, ty, visible, shots, rng, out f);
            if (f) fired = true;
            if (v.Dying && v.DeathTimer <= 0f) Vehicles.RemoveAt(i);
        }
    }

    public void DamageEnemy(Enemy e, float amount)
    {
        if (!e.Hittable) return;
        e.Damage(amount);
        if (e.Hp <= 0f)
        {
            e.StartDying();
            EnemyKilled?.Invoke(e);
        }
    }

    public void DamageVehicle(Vehicle v, float amount)
    {
        if (!v.Hittable) return;
        v.Damage(amount);
        if (v.Hp <= 0f)
        {
            v.Dying = true;
            v.DeathTimer = 1.4f;
            VehicleKilled?.Invoke(v);
        }
    }
}
