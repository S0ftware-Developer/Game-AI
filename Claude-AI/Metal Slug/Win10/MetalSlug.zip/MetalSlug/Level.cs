namespace MetalSlug;

public enum SolidStyle { Ground, Sandbag, Crate, Container, Ruin, Wood, Pipe }

/// <summary>A solid rectangle (ground, barricades, crates) or a one-way platform that can be jumped through from below.</summary>
public sealed class Solid
{
    public RectangleF Rect;
    public bool OneWay;
    public SolidStyle Style;
}

public enum DecorType { Palm, Tree, RuinBuilding, Barbed, WreckJeep, Barrel, Hut, Tower, FortWall, FortGate, Flag, Smoke, Sign, Crane, PipeLine }

public sealed class Decor
{
    public DecorType Type;
    public float X, Y, W, H;              // Y is the bottom
    public int Variant;
}

public struct EnemySpawn
{
    public EnemyType Type;
    public float X, Y, Min, Max;           // Y is where the feet stand
}

public struct VehicleSpawn
{
    public VehicleType Type;
    public float X, Min, Max;
}

public struct PickupSpawn
{
    public PickupType Type;
    public float X, Y;
}

/// <summary>
/// The one hand-made battlefield: five connected sections (jungle outpost, ruined town, industrial yard with the
/// player's tank, the defensive line and the fortress with the boss arena). All platforms are at most about 100 px
/// above the ground (a jump reaches 125 px) and every barricade is 80 px or lower, so nothing blocks the way.
/// </summary>
public sealed class Level
{
    public readonly List<Solid> Solids = new List<Solid>(64);
    public readonly List<Decor> Decors = new List<Decor>(128);
    public readonly List<EnemySpawn> Enemies = new List<EnemySpawn>(64);
    public readonly List<VehicleSpawn> Vehicles = new List<VehicleSpawn>(8);
    public readonly List<PickupSpawn> Pickups = new List<PickupSpawn>(48);
    public float TankX = 3930f;

    public bool SolidAt(float x, float y)
    {
        foreach (Solid s in Solids)
        {
            if (!s.OneWay && s.Rect.Contains(x, y)) return true;
        }
        return false;
    }

    private void Block(float x, float top, float w, float h, SolidStyle style, bool oneWay = false)
    {
        Solid s = new Solid();
        s.Rect = new RectangleF(x, top, w, h);
        s.Style = style;
        s.OneWay = oneWay;
        Solids.Add(s);
    }

    private void Dec(DecorType type, float x, float bottom, float w, float h, int variant = 0)
    {
        Decor d = new Decor();
        d.Type = type; d.X = x; d.Y = bottom; d.W = w; d.H = h; d.Variant = variant;
        Decors.Add(d);
    }

    private void En(EnemyType type, float x, float y, float min = 0f, float max = 0f)
    {
        EnemySpawn s = new EnemySpawn();
        s.Type = type; s.X = x; s.Y = y; s.Min = min == 0f ? x : min; s.Max = max == 0f ? x : max;
        Enemies.Add(s);
    }

    private void Veh(VehicleType type, float x, float min, float max)
    {
        VehicleSpawn v = new VehicleSpawn();
        v.Type = type; v.X = x; v.Min = min; v.Max = max;
        Vehicles.Add(v);
    }

    private void Pick(PickupType type, float x, float y = GameConfig.GroundY)
    {
        PickupSpawn p = new PickupSpawn();
        p.Type = type; p.X = x; p.Y = y;
        Pickups.Add(p);
    }

    public static Level Build()
    {
        Level lv = new Level();
        float g = GameConfig.GroundY;

        // ---- ground
        lv.Block(0f, g, GameConfig.LevelWidth, 300f, SolidStyle.Ground);

        // ---- section 1: the jungle outpost (0 - 1500)
        lv.Block(620f, 400f, 90f, 40f, SolidStyle.Sandbag);
        lv.Block(940f, 400f, 120f, 40f, SolidStyle.Sandbag);
        lv.Block(1000f, 340f, 170f, 12f, SolidStyle.Wood, true);
        lv.Block(1230f, 380f, 60f, 60f, SolidStyle.Crate);
        lv.Block(1400f, 380f, 60f, 60f, SolidStyle.Crate);

        // ---- section 2: the ruined town (1500 - 3000)
        lv.Block(1650f, 364f, 150f, 76f, SolidStyle.Ruin);
        lv.Block(1900f, 390f, 100f, 50f, SolidStyle.Ruin);
        lv.Block(2100f, 340f, 170f, 14f, SolidStyle.Ruin, true);
        lv.Block(2380f, 380f, 60f, 60f, SolidStyle.Crate);
        lv.Block(2560f, 370f, 150f, 70f, SolidStyle.Container);
        lv.Block(2800f, 400f, 90f, 40f, SolidStyle.Ruin);

        // ---- section 3: the industrial yard (3000 - 4500)
        lv.Block(3100f, 370f, 150f, 70f, SolidStyle.Container);
        lv.Block(3260f, 350f, 220f, 12f, SolidStyle.Pipe, true);
        lv.Block(3560f, 370f, 150f, 70f, SolidStyle.Container);
        lv.Block(3700f, 340f, 160f, 12f, SolidStyle.Wood, true);
        lv.Block(4050f, 380f, 60f, 60f, SolidStyle.Crate);
        lv.Block(4150f, 340f, 200f, 12f, SolidStyle.Pipe, true);
        lv.Block(4400f, 370f, 150f, 70f, SolidStyle.Container);

        // ---- section 4: the defensive line (4500 - 6400)
        lv.Block(4700f, 400f, 110f, 40f, SolidStyle.Sandbag);
        lv.Block(4950f, 400f, 110f, 40f, SolidStyle.Sandbag);
        lv.Block(5120f, 330f, 220f, 12f, SolidStyle.Wood, true);
        lv.Block(5400f, 400f, 110f, 40f, SolidStyle.Sandbag);
        lv.Block(5600f, 340f, 160f, 12f, SolidStyle.Ruin, true);
        lv.Block(5800f, 400f, 110f, 40f, SolidStyle.Sandbag);
        lv.Block(6000f, 380f, 120f, 60f, SolidStyle.Crate);

        // ---- section 5: the fortress (6400 - 8200)
        lv.Block(6500f, 400f, 110f, 40f, SolidStyle.Sandbag);
        lv.Block(6750f, 380f, 60f, 60f, SolidStyle.Crate);
        lv.Block(6900f, 340f, 180f, 12f, SolidStyle.Wood, true);
        lv.Block(7050f, 400f, 110f, 40f, SolidStyle.Sandbag);

        // ---- scenery
        foreach (float px in new[] { 90f, 520f, 860f, 1330f, 1560f, 2060f, 2700f, 2980f })
            lv.Dec(DecorType.Palm, px, g, 90f, 150f + (px % 40f), (int)(px / 10f) % 3);
        foreach (float px in new[] { 200f, 700f, 1120f, 1500f, 2300f, 6350f })
            lv.Dec(DecorType.Tree, px, g, 70f, 60f, (int)(px / 10f) % 3);
        lv.Dec(DecorType.Hut, 300f, g, 150f, 110f, 0);
        lv.Dec(DecorType.Hut, 1100f, g, 120f, 90f, 1);
        lv.Dec(DecorType.RuinBuilding, 1500f, g, 220f, 270f, 0);
        lv.Dec(DecorType.RuinBuilding, 2000f, g, 200f, 220f, 1);
        lv.Dec(DecorType.RuinBuilding, 2450f, g, 210f, 250f, 2);
        lv.Dec(DecorType.RuinBuilding, 2900f, g, 190f, 200f, 0);
        foreach (float bx in new[] { 760f, 2960f, 4800f, 5620f, 6300f })
            lv.Dec(DecorType.Barbed, bx, g, 130f, 36f);
        lv.Dec(DecorType.WreckJeep, 480f, g, 120f, 60f);
        lv.Dec(DecorType.WreckJeep, 3350f, g, 120f, 60f);
        foreach (float bx in new[] { 560f, 1180f, 1880f, 3040f, 3480f, 4600f, 5380f })
            lv.Dec(DecorType.Barrel, bx, g, 26f, 36f);
        lv.Dec(DecorType.Tower, 1000f, g, 170f, 100f);
        lv.Dec(DecorType.Tower, 3700f, g, 160f, 100f);
        lv.Dec(DecorType.Tower, 5120f, g, 220f, 110f);
        lv.Dec(DecorType.Tower, 6900f, g, 180f, 100f);
        lv.Dec(DecorType.Flag, 1450f, g, 50f, 120f);
        lv.Dec(DecorType.Flag, 6420f, g, 60f, 200f);
        lv.Dec(DecorType.Sign, 200f, g, 60f, 70f);
        lv.Dec(DecorType.PipeLine, 3000f, 300f, 1500f, 22f);
        lv.Dec(DecorType.Crane, 3420f, g, 120f, 300f);
        lv.Dec(DecorType.Crane, 4280f, g, 120f, 280f);
        lv.Dec(DecorType.FortWall, 6400f, g, 1800f, 280f);
        lv.Dec(DecorType.FortGate, 7600f, g, 360f, 300f);
        foreach (float sx in new[] { 1300f, 2000f, 3000f, 4000f, 5000f, 6200f, 7000f })
            lv.Dec(DecorType.Smoke, sx, g, 60f, 200f);

        // ---- section 1 enemies
        lv.En(EnemyType.Infantry, 700f, g, 650f, 820f);
        lv.En(EnemyType.Infantry, 990f, 400f);
        lv.En(EnemyType.Sniper, 1070f, 340f);
        lv.En(EnemyType.Infantry, 1140f, 340f);
        lv.En(EnemyType.Infantry, 1300f, g, 1250f, 1380f);
        lv.En(EnemyType.Grenadier, 1480f, g);
        // ---- section 2
        lv.En(EnemyType.Grenadier, 1720f, 364f);
        lv.En(EnemyType.Infantry, 1850f, g, 1800f, 1950f);
        lv.En(EnemyType.Infantry, 1950f, 390f);
        lv.En(EnemyType.Sniper, 2200f, 340f);
        lv.En(EnemyType.Infantry, 2300f, g, 2250f, 2370f);
        lv.En(EnemyType.Infantry, 2630f, 370f);
        lv.En(EnemyType.Grenadier, 2460f, g);
        lv.En(EnemyType.Heavy, 2780f, g, 2740f, 2900f);
        // ---- section 3
        lv.En(EnemyType.Infantry, 3030f, g, 2980f, 3090f);
        lv.En(EnemyType.Sniper, 3380f, 350f);
        lv.En(EnemyType.Heavy, 3500f, g, 3470f, 3550f);
        lv.En(EnemyType.Infantry, 3620f, 370f);
        lv.En(EnemyType.Grenadier, 4010f, g);
        lv.En(EnemyType.Infantry, 4080f, 380f);
        lv.En(EnemyType.Sniper, 4260f, 340f);
        lv.En(EnemyType.Elite, 4500f, g, 4440f, 4640f);
        // ---- section 4
        lv.En(EnemyType.Infantry, 4650f, g, 4600f, 4690f);
        lv.En(EnemyType.Infantry, 4750f, 400f);
        lv.En(EnemyType.Heavy, 4880f, g, 4830f, 4940f);
        lv.En(EnemyType.Infantry, 5000f, 400f);
        lv.En(EnemyType.Sniper, 5180f, 330f);
        lv.En(EnemyType.Sniper, 5300f, 330f);
        lv.En(EnemyType.Elite, 5350f, g, 5300f, 5390f);
        lv.En(EnemyType.Grenadier, 5450f, 400f);
        lv.En(EnemyType.Sniper, 5680f, 340f);
        lv.En(EnemyType.Elite, 5700f, g, 5650f, 5790f);
        lv.En(EnemyType.Heavy, 5900f, g, 5920f, 5990f);
        lv.En(EnemyType.Elite, 6050f, 380f);
        // ---- section 5
        lv.En(EnemyType.Elite, 6450f, g, 6420f, 6490f);
        lv.En(EnemyType.Heavy, 6560f, 400f);
        lv.En(EnemyType.Grenadier, 6700f, g);
        lv.En(EnemyType.Elite, 6800f, 380f);
        lv.En(EnemyType.Sniper, 6950f, 340f);
        lv.En(EnemyType.Elite, 7000f, g, 6960f, 7040f);
        lv.En(EnemyType.Heavy, 7100f, 400f);
        lv.En(EnemyType.Elite, 7200f, g, 7170f, 7300f);

        // ---- vehicles
        lv.Veh(VehicleType.Armored, 3000f, 2900f, 3060f);
        lv.Veh(VehicleType.Armored, 5600f, 5530f, 5770f);
        lv.Veh(VehicleType.Tank, 6280f, 6160f, 6400f);

        // ---- pickups
        lv.Pick(PickupType.Grenades, 450f);
        lv.Pick(PickupType.HeavyMG, 800f);
        lv.Pick(PickupType.Score, 1100f, 340f);
        lv.Pick(PickupType.Shotgun, 1550f);
        lv.Pick(PickupType.Grenades, 1750f);
        lv.Pick(PickupType.Health, 2000f);
        lv.Pick(PickupType.Life, 2250f, 340f);
        lv.Pick(PickupType.Rocket, 2850f);
        lv.Pick(PickupType.Grenades, 3200f);
        lv.Pick(PickupType.Score, 3520f, 350f);
        lv.Pick(PickupType.HeavyMG, 3750f);
        lv.Pick(PickupType.Rocket, 3840f);
        lv.Pick(PickupType.Armor, 4000f);
        lv.Pick(PickupType.Shotgun, 4200f);
        lv.Pick(PickupType.Grenades, 4620f);
        lv.Pick(PickupType.HeavyMG, 4660f);
        lv.Pick(PickupType.Health, 5000f);
        lv.Pick(PickupType.Life, 5250f, 330f);
        lv.Pick(PickupType.Grenades, 5450f);
        lv.Pick(PickupType.Score, 5650f, 340f);
        lv.Pick(PickupType.Shotgun, 5900f);
        lv.Pick(PickupType.Rocket, 6200f);
        lv.Pick(PickupType.Armor, 6400f);
        lv.Pick(PickupType.Grenades, 6700f);
        lv.Pick(PickupType.Score, 6900f, 340f);
        lv.Pick(PickupType.HeavyMG, 7050f);
        lv.Pick(PickupType.Rocket, 7120f);
        lv.Pick(PickupType.Health, 7160f);
        lv.Pick(PickupType.Grenades, 7300f);
        return lv;
    }
}
