namespace MetalSlug;

/// <summary>A thrown grenade following a ballistic arc; it bounces and explodes when its fuse runs out.</summary>
public sealed class Grenade
{
    public float X, Y, VX, VY, Fuse, Rot;
    public bool FromPlayer;
    public bool Alive;
}

public sealed class GrenadeManager
{
    public readonly List<Grenade> Items = new List<Grenade>(16);
    public readonly List<Grenade> Exploded = new List<Grenade>(8);     // grenades that blew up this step

    public void Clear()
    {
        Items.Clear();
        Exploded.Clear();
    }

    public void Throw(float x, float y, float vx, float vy, bool fromPlayer)
    {
        Grenade g = new Grenade();
        g.X = x; g.Y = y; g.VX = vx; g.VY = vy;
        g.FromPlayer = fromPlayer;
        g.Fuse = fromPlayer ? GameConfig.GrenadeFuse : 1.5f;
        g.Alive = true;
        Items.Add(g);
    }

    public void Update(float dt, Level level)
    {
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Grenade g = Items[i];
            g.VY += 900f * dt;
            float vxBefore = g.VX;
            float vyBefore = g.VY;
            float x = g.X;
            float y = g.Y + 5f;               // the body's bottom
            float vx = g.VX;
            float vy = g.VY;
            CollisionManager.MoveBody(level, ref x, ref y, ref vx, ref vy, 5f, 10f, dt);
            g.X = x;
            g.Y = y - 5f;
            g.VX = vx;
            g.VY = vy;
            if (vyBefore > 60f && vy == 0f)
            {
                g.VY = -vyBefore * 0.42f;     // bounce off the ground
                g.VX = vxBefore * 0.7f;
                if (Math.Abs(g.VY) < 40f) g.VY = 0f;
            }
            else if (Math.Abs(vxBefore) > 1f && vx == 0f)
            {
                g.VX = -vxBefore * 0.5f;      // bounce off a wall
            }
            g.Rot += (g.VX > 0f ? 1f : -1f) * 9f * dt;
            g.Fuse -= dt;
            if (g.Fuse <= 0f || g.Y > GameConfig.ViewH + 50f)
            {
                g.Alive = false;
                Exploded.Add(g);
                Items.RemoveAt(i);
            }
        }
    }
}
