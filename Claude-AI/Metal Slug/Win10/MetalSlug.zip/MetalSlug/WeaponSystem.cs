namespace MetalSlug;

public enum WeaponType { Machine, Heavy, Shotgun, Rocket }

/// <summary>
/// The soldier's weapons: the unlimited machine gun and three collectible special weapons (heavy machine gun, shotgun,
/// rocket launcher) with limited ammunition. Picking up a special weapon replaces the current one.
/// </summary>
public sealed class WeaponSystem
{
    public WeaponType Type = WeaponType.Machine;
    public int Ammo;
    public float Cooldown;
    public float MuzzleTimer;
    public bool EvShot;                       // set for one step when a shot was fired (sound)
    public WeaponType EvType;
    private readonly Random rng = new Random();

    public string Name
    {
        get
        {
            switch (Type)
            {
                case WeaponType.Heavy: return "HEAVY MACHINE GUN";
                case WeaponType.Shotgun: return "SHOTGUN";
                case WeaponType.Rocket: return "ROCKET LAUNCHER";
                default: return "MACHINE GUN";
            }
        }
    }

    public void Reset()
    {
        Type = WeaponType.Machine;
        Ammo = 0;
        Cooldown = 0f;
        MuzzleTimer = 0f;
    }

    public static int PickupAmmo(WeaponType t)
    {
        switch (t)
        {
            case WeaponType.Heavy: return 200;
            case WeaponType.Shotgun: return 24;
            case WeaponType.Rocket: return 14;
            default: return 0;
        }
    }

    public void Give(WeaponType t)
    {
        if (Type == t) Ammo += PickupAmmo(t);
        else
        {
            Type = t;
            Ammo = PickupAmmo(t);
        }
    }

    public void Update(float dt, Player p, bool fire, ProjectileManager shots)
    {
        if (Cooldown > 0f) Cooldown -= dt;
        if (MuzzleTimer > 0f) MuzzleTimer = Math.Max(0f, MuzzleTimer - dt);
        if (!fire || Cooldown > 0f || p.Dead) return;

        WeaponType fired = Type;
        float x = p.MuzzleX;
        float y = p.MuzzleY;
        float dx = p.AimX;
        float dy = p.AimY;
        switch (Type)
        {
            case WeaponType.Machine:
                Shoot(shots, ShotKind.Bullet, x, y, dx, dy, 820f, 1f, 0.9f, 0.02f);
                Cooldown = 0.1f;
                break;
            case WeaponType.Heavy:
                Shoot(shots, ShotKind.Heavy, x, y, dx, dy, 920f, 2f, 0.9f, 0.04f);
                Cooldown = 0.065f;
                break;
            case WeaponType.Shotgun:
                for (int i = -3; i <= 3; i++)
                {
                    float spread = i * 0.085f + ((float)rng.NextDouble() - 0.5f) * 0.05f;
                    Shoot(shots, ShotKind.Pellet, x, y, dx, dy, 720f + (float)rng.NextDouble() * 80f, 1.4f, 0.34f, spread);
                }
                Cooldown = 0.55f;
                break;
            default:
                {
                    Projectile r = Shoot(shots, ShotKind.Rocket, x, y, dx, dy, 540f, 10f, 2.2f, 0f);
                    r.AY = 0f;
                    Cooldown = 0.6f;
                    break;
                }
        }
        if (Type != WeaponType.Machine)
        {
            Ammo--;
            if (Ammo <= 0) Reset();
        }
        MuzzleTimer = 0.06f;
        p.ShootAnim = 0.18f;
        EvShot = true;
        EvType = fired;
    }

    private Projectile Shoot(ProjectileManager shots, ShotKind kind, float x, float y, float dx, float dy, float speed, float damage, float life, float angleJitter)
    {
        float jit = angleJitter == 0f ? 0f : (kind == ShotKind.Pellet ? angleJitter : ((float)rng.NextDouble() - 0.5f) * angleJitter * 2f);
        float a = MathF.Atan2(dy, dx) + jit;
        return shots.Spawn(kind, x, y, MathF.Cos(a) * speed, MathF.Sin(a) * speed, damage, life);
    }
}
