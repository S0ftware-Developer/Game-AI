namespace MetalSlug;

public enum BossPattern { MG, Cannon, Mortar, Rest }

/// <summary>
/// The final boss "Iron Fortress": a huge armoured mobile weapons platform with twin machine guns, a main cannon and a
/// roof mortar. Phase one uses machine-gun bursts and single shells; at half health phase two adds mortar barrages that
/// rain down around the player, double shells and faster fire.
/// </summary>
public sealed class Boss
{
    public const float HalfW = 170f;
    public const float Height = 190f;

    public bool Active, Entering, Dying;
    public float X, Y = GameConfig.GroundY, Hp, MaxHp = GameConfig.BossMaxHp;
    public int Phase = 1;
    public BossPattern Current = BossPattern.Rest;
    public float Age, HitFlash, DeathTimer, TrackPhase, Recoil, TurretAngle;
    public bool EvFired, EvPhaseChanged, EvDeathBlast, EvDefeated;

    private float patternAge, patternDur, attackTimer;
    private int seqIndex, burstLeft;
    private readonly Random rng = new Random();
    private float vx;

    private static readonly BossPattern[][] Sequences =
    {
        new[] { BossPattern.MG, BossPattern.Cannon, BossPattern.MG, BossPattern.Rest },
        new[] { BossPattern.Mortar, BossPattern.MG, BossPattern.Cannon, BossPattern.Mortar, BossPattern.Rest }
    };

    public RectangleF Rect
    {
        get { return new RectangleF(X - HalfW, Y - Height, HalfW * 2f, Height); }
    }

    public bool Vulnerable { get { return Active && !Entering && !Dying; } }
    public float HealthFraction { get { return Math.Max(0f, Hp) / MaxHp; } }

    // gun positions on the machine (the boss faces left)
    public float Gun1X { get { return X - 150f; } }
    public float Gun1Y { get { return Y - 150f; } }
    public float Gun2X { get { return X - 100f; } }
    public float Gun2Y { get { return Y - 176f; } }
    public float CannonX { get { return X - 172f; } }
    public float CannonY { get { return Y - 96f; } }
    public float MortarX { get { return X + 20f; } }
    public float MortarY { get { return Y - 196f; } }

    public void Reset()
    {
        Active = false;
        Entering = false;
        Dying = false;
        Phase = 1;
        HitFlash = 0f;
    }

    public void Spawn()
    {
        Active = true;
        Entering = true;
        Dying = false;
        Hp = MaxHp;
        X = GameConfig.LevelWidth + 340f;
        Age = 0f;
        Phase = 1;
        seqIndex = -1;
        Current = BossPattern.Rest;
        patternAge = 0f;
        patternDur = 1f;
        DeathTimer = 0f;
        burstLeft = 0;
    }

    public void Damage(float amount)
    {
        if (!Vulnerable) return;
        Hp -= amount;
        HitFlash = 0.07f;
        if (Hp <= 0f)
        {
            Hp = 0f;
            Dying = true;
            DeathTimer = 0f;
        }
    }

    private void NextPattern()
    {
        BossPattern[] seq = Sequences[Phase - 1];
        seqIndex = (seqIndex + 1) % seq.Length;
        Current = seq[seqIndex];
        patternAge = 0f;
        attackTimer = 0.3f;
        burstLeft = 0;
        switch (Current)
        {
            case BossPattern.MG: patternDur = 2.6f; break;
            case BossPattern.Cannon: patternDur = 3.0f; break;
            case BossPattern.Mortar: patternDur = 3.2f; break;
            default: patternDur = 1.3f; break;
        }
    }

    public void Update(float dt, float tx, float ty, ProjectileManager shots, ExplosionManager expl, ParticleSystem parts)
    {
        EvFired = false;
        EvPhaseChanged = false;
        EvDeathBlast = false;
        EvDefeated = false;
        if (!Active) return;

        Age += dt;
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        if (Recoil > 0f) Recoil = Math.Max(0f, Recoil - dt * 4f);
        TrackPhase += vx * dt * 0.08f;

        if (Dying)
        {
            vx = 0f;
            DeathTimer += dt;
            if (((int)(DeathTimer * 10f)) != ((int)((DeathTimer - dt) * 10f)))
            {
                float ex = X + (float)(rng.NextDouble() * 320.0 - 160.0);
                float ey = Y - (float)(rng.NextDouble() * 180.0);
                bool large = rng.Next(3) == 0;
                expl.Add(ex, ey, large ? ExplosionKind.Large : ExplosionKind.Small);
                parts.Flames(ex, ey, 12f, 3);
                parts.Smoke(ex, ey, 0f, -40f, 16f, 1.4f, 45);
                if (large) EvDeathBlast = true;
            }
            if (DeathTimer >= 4.5f)
            {
                expl.Add(X - 60f, Y - 90f, ExplosionKind.Boss);
                expl.Add(X + 80f, Y - 120f, ExplosionKind.Large, 0.15f);
                expl.Add(X - 120f, Y - 40f, ExplosionKind.Large, 0.25f);
                parts.Debris(X, Y - 90f, 70, Color.FromArgb(90, 96, 80));
                Active = false;
                EvDefeated = true;
            }
            return;
        }

        if (Entering)
        {
            float target = GameConfig.LevelWidth - 200f;
            X -= 150f * dt;
            vx = -150f;
            if (X <= target)
            {
                X = target;
                Entering = false;
                vx = 0f;
                NextPattern();
            }
            return;
        }

        // movement: it patrols the arena and presses toward the player while it rests
        float minX = GameConfig.ArenaStartX + HalfW + 40f;
        float maxX = GameConfig.LevelWidth - HalfW - 10f;
        float speed = Phase == 1 ? 38f : 62f;
        float dirToPlayer = tx < X ? -1f : 1f;
        vx = Current == BossPattern.Rest ? dirToPlayer * speed : (MathF.Sin(Age * 0.7f) * speed * 0.6f);
        X = Math.Max(minX, Math.Min(maxX, X + vx * dt));

        if (Phase == 1 && HealthFraction <= 0.5f)
        {
            Phase = 2;
            EvPhaseChanged = true;
            seqIndex = -1;
            Current = BossPattern.Rest;
            patternAge = 0f;
            patternDur = 1.5f;
            attackTimer = 1f;
            return;
        }

        patternAge += dt;
        if (patternAge >= patternDur) NextPattern();
        attackTimer -= dt;
        TurretAngle = MathF.Atan2(ty - Gun1Y, Math.Abs(tx - Gun1X));

        switch (Current)
        {
            case BossPattern.MG:
                if (attackTimer <= 0f)
                {
                    float a1 = MathF.Atan2(ty - Gun1Y, tx - Gun1X) + ((float)rng.NextDouble() - 0.5f) * 0.12f;
                    float a2 = MathF.Atan2(ty - Gun2Y, tx - Gun2X) + ((float)rng.NextDouble() - 0.5f) * 0.12f;
                    shots.Spawn(ShotKind.EBullet, Gun1X, Gun1Y, MathF.Cos(a1) * 360f, MathF.Sin(a1) * 360f, 1f, 3f);
                    shots.Spawn(ShotKind.EBullet, Gun2X, Gun2Y, MathF.Cos(a2) * 360f, MathF.Sin(a2) * 360f, 1f, 3f);
                    attackTimer = Phase == 1 ? 0.2f : 0.13f;
                    EvFired = true;
                }
                break;
            case BossPattern.Cannon:
                if (attackTimer <= 0f)
                {
                    float a = MathF.Atan2(ty - CannonY, tx - CannonX);
                    int count = Phase == 1 ? 1 : 2;
                    for (int k = 0; k < count; k++)
                    {
                        float aa = a + (count == 1 ? 0f : (k == 0 ? -0.1f : 0.1f));
                        Projectile s = shots.Spawn(ShotKind.EShell, CannonX, CannonY, MathF.Cos(aa) * 400f, MathF.Sin(aa) * 400f, 2f, 4f);
                        s.AY = 120f;
                    }
                    Recoil = 1f;
                    attackTimer = Phase == 1 ? 1.4f : 1.1f;
                    EvFired = true;
                }
                break;
            case BossPattern.Mortar:
                if (attackTimer <= 0f && burstLeft < 4)
                {
                    // lobbed shells that come down around the player's current position
                    float flight = 1.25f;
                    float aimX = tx + ((float)rng.NextDouble() - 0.5f) * 200f;
                    float mvx = (aimX - MortarX) / flight;
                    float mvy = (GameConfig.GroundY - 20f - MortarY - 0.5f * 900f * flight * flight) / flight;
                    shots.Spawn(ShotKind.EMortar, MortarX, MortarY, mvx, mvy, 2f, 4f);
                    burstLeft++;
                    attackTimer = 0.42f;
                    EvFired = true;
                }
                break;
        }
    }
}
