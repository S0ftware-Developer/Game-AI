namespace MetalSlug;

/// <summary>
/// The Metal-Slug-style combat tank. While the player sits in it, it drives, hops, aims its turret up and down, fires a
/// machine gun and a powerful cannon, and absorbs hits as durability instead of killing the soldier.
/// </summary>
public sealed class PlayerTank
{
    public const float HalfW = 48f;
    public const float Height = 54f;

    public float X, Y, VX, VY;              // X is the centre, Y the bottom of the tracks
    public int Facing = 1;
    public bool Occupied, Destroyed, Grounded;
    public int Hp = GameConfig.TankMaxHp;
    public float Invuln, HitFlash, TrackPhase, TurretAngle, Recoil, MgTimer, CannonTimer, Age;
    public float MuzzleX, MuzzleY, AimX = 1f, AimY;
    public bool EvMg, EvCannon;

    public RectangleF Rect
    {
        get { return new RectangleF(X - HalfW, Y - Height, HalfW * 2f, Height); }
    }

    public void Reset(float x)
    {
        X = x;
        Y = GameConfig.GroundY;
        VX = 0f;
        VY = 0f;
        Facing = 1;
        Occupied = false;
        Destroyed = false;
        Hp = GameConfig.TankMaxHp;
        Invuln = 0f;
        HitFlash = 0f;
        TurretAngle = 0f;
        Recoil = 0f;
        MgTimer = 0f;
        CannonTimer = 0f;
    }

    private static float Approach(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    public void Update(float dt, PlayerInput inp, Level lv, ProjectileManager shots, float minX, float maxX)
    {
        EvMg = false;
        EvCannon = false;
        Age += dt;
        if (Invuln > 0f) Invuln = Math.Max(0f, Invuln - dt);
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        if (Recoil > 0f) Recoil = Math.Max(0f, Recoil - dt * 6f);
        if (MgTimer > 0f) MgTimer -= dt;
        if (CannonTimer > 0f) CannonTimer -= dt;
        if (Destroyed) return;

        if (Occupied)
        {
            int dir = (inp.Right ? 1 : 0) - (inp.Left ? 1 : 0);
            if (dir != 0) Facing = dir;
            VX = Approach(VX, dir * GameConfig.TankSpeed, (dir != 0 ? 1100f : 1400f) * dt);

            // the turret: W raises it, S lowers it, and it returns to horizontal when released
            if (inp.Up) TurretAngle = Math.Max(-1.35f, TurretAngle - 2.2f * dt);
            else if (inp.Down) TurretAngle = Math.Min(0.3f, TurretAngle + 2.2f * dt);
            else TurretAngle = Approach(TurretAngle, 0f, 1.4f * dt);

            if (inp.JumpPressed && Grounded) VY = -GameConfig.TankHopSpeed;
        }
        else
        {
            VX = Approach(VX, 0f, 1400f * dt);
        }
        VY = Math.Min(900f, VY + GameConfig.Gravity * 0.8f * dt);

        float x = X, y = Y, vx = VX, vy = VY;
        Grounded = CollisionManager.MoveBody(lv, ref x, ref y, ref vx, ref vy, HalfW, Height, dt);
        X = x; Y = y; VX = vx; VY = vy;
        if (X < minX + HalfW) { X = minX + HalfW; if (VX < 0f) VX = 0f; }
        if (X > maxX - HalfW) { X = maxX - HalfW; if (VX > 0f) VX = 0f; }
        TrackPhase += VX * dt * 0.09f;

        // aim direction and muzzle positions
        AimX = Facing * MathF.Cos(TurretAngle);
        AimY = MathF.Sin(TurretAngle);
        float px = X + Facing * 6f;
        float py = Y - 40f;
        MuzzleX = px + AimX * (62f - Recoil * 8f);
        MuzzleY = py + AimY * (62f - Recoil * 8f);

        if (!Occupied) return;

        if (inp.Fire && MgTimer <= 0f)
        {
            float jitter = (float)(Random.Shared.NextDouble() - 0.5) * 0.05f;
            float a = MathF.Atan2(AimY, AimX) + jitter;
            float mx = px + AimX * 34f;
            float my = py + AimY * 34f - 6f;
            shots.Spawn(ShotKind.TankMG, mx, my, MathF.Cos(a) * 820f, MathF.Sin(a) * 820f, 1.5f, 0.9f);
            MgTimer = 0.09f;
            EvMg = true;
        }
        if (inp.GrenadeHeld && CannonTimer <= 0f)
        {
            Projectile s = shots.Spawn(ShotKind.TankShell, MuzzleX, MuzzleY, AimX * 720f, AimY * 720f, 9f, 1.6f);
            s.AY = 120f;
            CannonTimer = 0.9f;
            Recoil = 1f;
            EvCannon = true;
        }
    }

    /// <summary>Damage reduces the tank's durability. Returns true when the tank was just destroyed.</summary>
    public bool Hit(int dmg)
    {
        if (Destroyed || Invuln > 0f) return false;
        Hp -= dmg;
        HitFlash = 0.12f;
        Invuln = 0.25f;
        if (Hp <= 0)
        {
            Hp = 0;
            Destroyed = true;
            Occupied = false;
            return true;
        }
        return false;
    }
}
