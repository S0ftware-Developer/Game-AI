namespace MetalSlug;

public enum ExplosionKind { Small, Large, Boss }

/// <summary>A fireball animation. Progress goes 0..1 over its duration; Delay lets chains of explosions be queued.</summary>
public sealed class Explosion
{
    public float X, Y, Size, Age, Duration, Delay;
    public ExplosionKind Kind;

    public float Progress
    {
        get { return Math.Max(0f, Math.Min(1f, Age / Duration)); }
    }
}

public sealed class ExplosionManager
{
    public readonly List<Explosion> Items = new List<Explosion>(64);
    private readonly Stack<Explosion> pool = new Stack<Explosion>();

    public void Clear()
    {
        foreach (Explosion e in Items) pool.Push(e);
        Items.Clear();
    }

    public void Add(float x, float y, ExplosionKind kind, float delay = 0f)
    {
        Explosion e = pool.Count > 0 ? pool.Pop() : new Explosion();
        e.X = x;
        e.Y = y;
        e.Kind = kind;
        e.Age = -delay;
        e.Delay = delay;
        switch (kind)
        {
            case ExplosionKind.Small: e.Size = 34f; e.Duration = 0.45f; break;
            case ExplosionKind.Large: e.Size = 70f; e.Duration = 0.7f; break;
            default: e.Size = 130f; e.Duration = 1.1f; break;
        }
        Items.Add(e);
    }

    public void Update(float dt)
    {
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Explosion e = Items[i];
            e.Age += dt;
            if (e.Age >= e.Duration)
            {
                Items[i] = Items[Items.Count - 1];
                Items.RemoveAt(Items.Count - 1);
                pool.Push(e);
            }
        }
    }
}
