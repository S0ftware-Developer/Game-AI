using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace MetalSlug;

/// <summary>
/// The colourful retro battlefield: a gradient sky with clouds, three parallax layers (mountains, forested hills with
/// a distant fortress, dense jungle), the stone-faced ground with grass, and all level scenery and solids (sandbags,
/// crates, containers, ruins, wooden platforms, palms, ruined houses, the fortress wall and gate, smoke columns).
/// </summary>
public sealed class BackgroundRenderer : IDisposable
{
    private const int W = GameConfig.LogicalW;
    private const int ViewH = GameConfig.ViewH;
    private const int LayerW = 1920;

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Bitmap skyBmp;
    private readonly Bitmap[] clouds = new Bitmap[4];
    private readonly Bitmap mountains;
    private readonly Bitmap hills;
    private readonly Bitmap jungle;
    private readonly Bitmap stoneTile;
    private readonly TextureBrush stoneBrush;
    private readonly PointF[] poly = new PointF[12];
    private readonly PointF[] tri3 = new PointF[3];
    private readonly PointF[] leafPts = new PointF[12];

    public BackgroundRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;
        skyBmp = MakeSky();
        for (int i = 0; i < clouds.Length; i++) clouds[i] = MakeCloud(i);
        mountains = MakeMountains();
        hills = MakeHills();
        jungle = MakeJungle();
        stoneTile = MakeStoneTile();
        stoneBrush = new TextureBrush(stoneTile, WrapMode.Tile);
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        skyBmp.Dispose();
        foreach (Bitmap b in clouds) b.Dispose();
        mountains.Dispose();
        hills.Dispose();
        jungle.Dispose();
        stoneTile.Dispose();
        stoneBrush.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static int Hash(int c)
    {
        unchecked
        {
            int h = c * 374761393;
            h = (h ^ (h >> 13)) * 1274126177;
            return (h ^ (h >> 16)) & 0x7fffffff;
        }
    }

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private void DrawLayer(Graphics g, Bitmap bmp, float offset, float y)
    {
        float x = -(((offset % LayerW) + LayerW) % LayerW);
        while (x < W)
        {
            g.DrawImageUnscaled(bmp, (int)x, (int)y);
            x += LayerW;
        }
    }

    // ------------------------------------------------------------------ sky and parallax

    public void DrawSky(Graphics g, float camX, float time)
    {
        g.DrawImageUnscaled(skyBmp, 0, 0);

        // slow clouds
        float cs = camX * 0.05f + time * 6f;
        const int cell = 420;
        int i0 = (int)Math.Floor((cs - 120f) / cell);
        int i1 = (int)Math.Floor((cs + W + 120f) / cell);
        for (int i = i0; i <= i1; i++)
        {
            int h = Hash(i * 37 + 5);
            if (h % 100 > 75) continue;
            Bitmap c = clouds[h % clouds.Length];
            float x = i * cell + (h >> 6) % 160 - cs;
            float y = 18f + (h >> 12) % 150;
            g.DrawImageUnscaled(c, (int)x, (int)y);
        }

        DrawLayer(g, mountains, camX * 0.08f, 120f);
        DrawLayer(g, hills, camX * 0.2f, 214f);
        DrawLayer(g, jungle, camX * 0.45f, 300f);
    }

    // ------------------------------------------------------------------ the world

    public void DrawWorld(Graphics g, Level lv, float camX, float time)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(-camX, 0f);
        float x0 = camX - 320f;
        float x1 = camX + W + 320f;

        // scenery that stands behind everything
        foreach (Decor d in lv.Decors)
        {
            if (d.X + d.W < x0 || d.X > x1) continue;
            if (IsFront(d.Type)) continue;
            DrawDecor(g, d, time);
        }

        DrawGround(g, camX, time);

        foreach (Solid s in lv.Solids)
        {
            if (s.Style == SolidStyle.Ground) continue;
            if (s.Rect.Right < x0 || s.Rect.Left > x1) continue;
            DrawSolid(g, s);
        }

        // scenery in front of the platforms
        foreach (Decor d in lv.Decors)
        {
            if (d.X + d.W < x0 || d.X > x1) continue;
            if (!IsFront(d.Type)) continue;
            DrawDecor(g, d, time);
        }
        g.Restore(st);
    }

    private static bool IsFront(DecorType t)
    {
        return t == DecorType.Barbed || t == DecorType.Barrel || t == DecorType.WreckJeep || t == DecorType.Smoke || t == DecorType.Sign;
    }

    private void DrawGround(Graphics g, float camX, float time)
    {
        float gy = GameConfig.GroundY;
        float xa = (float)Math.Floor((camX - 20f) / 8f) * 8f;
        float xb = camX + W + 20f;
        stoneBrush.ResetTransform();
        g.FillRectangle(stoneBrush, xa, gy + 6f, xb - xa, ViewH - gy);
        g.FillRectangle(B(Color.FromArgb(255, 86, 66, 40)), xa, gy, xb - xa, 8f);          // dark soil under the grass
        g.FillRectangle(B(Color.FromArgb(255, 70, 128, 44)), xa, gy - 2f, xb - xa, 8f);
        // grass blades along the edge
        for (float x = xa; x < xb; x += 6f)
        {
            int h = Hash((int)(x / 6f) * 7 + 3);
            float bh = 6f + h % 9;
            bool light = (h & 4) != 0;
            tri3[0] = new PointF(x, gy);
            tri3[1] = new PointF(x + 3f, gy - bh);
            tri3[2] = new PointF(x + 6f, gy);
            g.FillPolygon(B(light ? Color.FromArgb(255, 118, 176, 50) : Color.FromArgb(255, 74, 140, 44)), tri3);
        }
        for (float x = xa; x < xb; x += 6f)
        {
            int h = Hash((int)(x / 6f) * 11 + 1);
            if (h % 17 == 0)
            {
                g.FillEllipse(B(Color.FromArgb(255, 255, 220, 80)), x, gy - 9f, 4f, 4f);
            }
        }
        g.DrawLine(P(Color.FromArgb(255, 48, 80, 30), 2f), xa, gy + 6f, xb, gy + 6f);
    }

    private void DrawSolid(Graphics g, Solid s)
    {
        RectangleF r = s.Rect;
        switch (s.Style)
        {
            case SolidStyle.Sandbag: DrawSandbags(g, r); break;
            case SolidStyle.Crate: DrawCrates(g, r); break;
            case SolidStyle.Container: DrawContainer(g, r); break;
            case SolidStyle.Ruin: DrawRuinBlock(g, r); break;
            case SolidStyle.Wood: DrawWoodPlatform(g, r); break;
            default: DrawPipePlatform(g, r); break;
        }
    }

    private void DrawSandbags(Graphics g, RectangleF r)
    {
        float rowH = 20f;
        int rows = Math.Max(1, (int)(r.Height / rowH));
        for (int row = 0; row < rows; row++)
        {
            float y = r.Bottom - (row + 1) * rowH;
            float off = (row % 2) * 14f;
            for (float x = r.Left - off; x < r.Right; x += 28f)
            {
                float bx = Math.Max(x, r.Left);
                float bw = Math.Min(x + 28f, r.Right) - bx;
                if (bw < 6f) continue;
                int h = Hash((int)(x * 3f + row * 17f));
                Color c = (h & 1) == 0 ? Color.FromArgb(255, 196, 166, 104) : Color.FromArgb(255, 182, 150, 92);
                g.FillEllipse(B(c), bx, y, bw, rowH + 2f);
                g.DrawEllipse(P(Color.FromArgb(255, 110, 84, 46), 1.5f), bx, y, bw, rowH + 2f);
                g.DrawLine(P(Color.FromArgb(120, 110, 84, 46), 1f), bx + bw * 0.3f, y + 6f, bx + bw * 0.7f, y + 6f);
            }
        }
    }

    private void DrawCrates(Graphics g, RectangleF r)
    {
        for (float x = r.Left; x < r.Right - 1f; x += 60f)
        {
            float w = Math.Min(60f, r.Right - x);
            g.FillRectangle(B(Color.FromArgb(255, 160, 112, 58)), x, r.Top, w, r.Height);
            for (float py = r.Top + 10f; py < r.Bottom; py += 14f)
                g.DrawLine(P(Color.FromArgb(150, 96, 62, 28), 1.5f), x, py, x + w, py);
            g.DrawRectangle(P(Color.FromArgb(255, 74, 48, 22), 3f), x + 1.5f, r.Top + 1.5f, w - 3f, r.Height - 3f);
            g.DrawLine(P(Color.FromArgb(255, 90, 60, 28), 3f), x + 3f, r.Top + 3f, x + w - 3f, r.Bottom - 3f);
            g.DrawLine(P(Color.FromArgb(255, 90, 60, 28), 3f), x + w - 3f, r.Top + 3f, x + 3f, r.Bottom - 3f);
            g.FillRectangle(B(Color.FromArgb(255, 120, 124, 130)), x, r.Top, 7f, 7f);
            g.FillRectangle(B(Color.FromArgb(255, 120, 124, 130)), x + w - 7f, r.Top, 7f, 7f);
        }
    }

    private void DrawContainer(Graphics g, RectangleF r)
    {
        int h = Hash((int)r.X);
        Color[] pal = { Color.FromArgb(255, 70, 104, 78), Color.FromArgb(255, 150, 70, 56), Color.FromArgb(255, 70, 92, 132) };
        Color c = pal[h % pal.Length];
        g.FillRectangle(B(c), r.X, r.Y, r.Width, r.Height);
        for (float x = r.X + 6f; x < r.Right - 4f; x += 9f)
            g.DrawLine(P(Color.FromArgb(70, 0, 0, 0), 2f), x, r.Y + 4f, x, r.Bottom - 4f);
        g.FillRectangle(B(Color.FromArgb(70, 255, 255, 255)), r.X, r.Y, r.Width, 5f);
        g.DrawRectangle(P(Color.FromArgb(255, 30, 36, 34), 3f), r.X + 1.5f, r.Y + 1.5f, r.Width - 3f, r.Height - 3f);
        g.FillRectangle(B(Color.FromArgb(255, 210, 210, 200)), r.Right - 48f, r.Y + 12f, 36f, 8f);
        g.DrawLine(P(Color.FromArgb(255, 30, 36, 34), 2f), r.X + r.Width / 2f, r.Y + 3f, r.X + r.Width / 2f, r.Bottom - 3f);
    }

    private void DrawRuinBlock(Graphics g, RectangleF r)
    {
        g.FillRectangle(B(Color.FromArgb(255, 164, 96, 72)), r.X, r.Y, r.Width, r.Height);
        float rowH = 10f;
        for (float y = r.Y; y < r.Bottom; y += rowH)
        {
            int row = (int)((y - r.Y) / rowH);
            g.DrawLine(P(Color.FromArgb(160, 100, 56, 40), 1.2f), r.X, y, r.Right, y);
            for (float x = r.X + (row % 2) * 12f; x < r.Right; x += 24f)
                g.DrawLine(P(Color.FromArgb(160, 100, 56, 40), 1.2f), x, y, x, Math.Min(y + rowH, r.Bottom));
        }
        g.FillRectangle(B(Color.FromArgb(80, 0, 0, 0)), r.X, r.Bottom - 8f, r.Width, 8f);
        g.FillRectangle(B(Color.FromArgb(255, 206, 170, 120)), r.X, r.Y, r.Width, 5f);
        g.DrawRectangle(P(Color.FromArgb(255, 62, 36, 28), 2.5f), r.X + 1f, r.Y + 1f, r.Width - 2f, r.Height - 2f);
        // a chipped top edge
        for (float x = r.X + 8f; x < r.Right - 8f; x += 26f)
            g.FillRectangle(B(Color.FromArgb(255, 164, 96, 72)), x, r.Y - 4f, 10f, 5f);
    }

    private void DrawWoodPlatform(Graphics g, RectangleF r)
    {
        g.FillRectangle(B(Color.FromArgb(255, 150, 104, 56)), r.X - 4f, r.Y, r.Width + 8f, r.Height);
        g.FillRectangle(B(Color.FromArgb(255, 196, 150, 90)), r.X - 4f, r.Y, r.Width + 8f, 4f);
        for (float x = r.X; x < r.Right; x += 22f)
            g.DrawLine(P(Color.FromArgb(200, 80, 52, 24), 1.5f), x, r.Y, x, r.Bottom);
        g.DrawRectangle(P(Color.FromArgb(255, 70, 44, 20), 2f), r.X - 4f, r.Y, r.Width + 8f, r.Height);
    }

    private void DrawPipePlatform(Graphics g, RectangleF r)
    {
        g.FillRectangle(B(Color.FromArgb(255, 112, 120, 134)), r.X, r.Y, r.Width, r.Height);
        g.FillRectangle(B(Color.FromArgb(255, 170, 178, 192)), r.X, r.Y, r.Width, 4f);
        g.FillRectangle(B(Color.FromArgb(255, 70, 76, 90)), r.X, r.Bottom - 3f, r.Width, 3f);
        for (float x = r.X + 10f; x < r.Right - 4f; x += 32f)
        {
            g.FillEllipse(B(Color.FromArgb(255, 56, 62, 74)), x, r.Y + 4f, 4f, 4f);
            g.DrawLine(P(Color.FromArgb(255, 80, 86, 100), 3f), x + 12f, r.Y, x + 12f, r.Bottom);
        }
        g.DrawRectangle(P(Color.FromArgb(255, 38, 42, 52), 2f), r.X, r.Y, r.Width, r.Height);
    }

    // ------------------------------------------------------------------ scenery

    private void DrawDecor(Graphics g, Decor d, float time)
    {
        switch (d.Type)
        {
            case DecorType.Palm: DrawPalm(g, d, time); break;
            case DecorType.Tree: DrawBush(g, d); break;
            case DecorType.RuinBuilding: DrawRuinBuilding(g, d); break;
            case DecorType.Barbed: DrawBarbed(g, d); break;
            case DecorType.WreckJeep: DrawWreck(g, d); break;
            case DecorType.Barrel: DrawBarrel(g, d); break;
            case DecorType.Hut: DrawHut(g, d); break;
            case DecorType.Tower: DrawTowerSupports(g, d); break;
            case DecorType.FortWall: DrawFortWall(g, d); break;
            case DecorType.FortGate: DrawFortGate(g, d); break;
            case DecorType.Flag: DrawFlag(g, d, time); break;
            case DecorType.Smoke: DrawSmoke(g, d, time); break;
            case DecorType.Sign: DrawSign(g, d); break;
            case DecorType.Crane: DrawCrane(g, d); break;
            default: DrawPipeLine(g, d); break;
        }
    }

    private void DrawLeaf(Graphics g, float x, float y, float angle, float len, float droop, Color c)
    {
        int n = 5;
        PointF[] pts = leafPts;
        for (int i = 0; i <= n; i++)
        {
            float t = i / (float)n;
            float px = x + MathF.Cos(angle) * len * t;
            float py = y + MathF.Sin(angle) * len * t + droop * t * t;
            float wd = MathF.Sin(t * MathF.PI) * 9f;
            pts[i] = new PointF(px, py - wd);
            pts[11 - i] = new PointF(px, py + wd);
        }
        g.FillPolygon(B(c), pts);
        g.DrawPolygon(P(Color.FromArgb(180, 24, 70, 28), 1.2f), pts);
    }

    private void DrawPalm(Graphics g, Decor d, float time)
    {
        float sway = MathF.Sin(time * 0.9f + d.X) * 4f;
        float tx = d.X + 16f + sway;
        float ty = d.Y - d.H;
        PointF[] trunk = { new PointF(d.X + 6f, d.Y), new PointF(d.X + 20f - sway * 0.3f, d.Y - d.H * 0.55f), new PointF(tx, ty) };
        g.DrawCurve(P(Color.FromArgb(255, 70, 46, 24), 14f), trunk);
        g.DrawCurve(P(Color.FromArgb(255, 132, 92, 52), 9f), trunk);
        for (int k = 1; k < 7; k++)
        {
            float t = k / 7f;
            float rx = d.X + 6f + (tx - d.X - 6f) * t + MathF.Sin(t * 3f) * 4f;
            float ry = d.Y - d.H * t;
            g.DrawLine(P(Color.FromArgb(120, 60, 40, 20), 2f), rx - 6f, ry, rx + 6f, ry + 2f);
        }
        Color l1 = Color.FromArgb(255, 64, 140, 54);
        Color l2 = Color.FromArgb(255, 94, 170, 62);
        for (int k = 0; k < 7; k++)
        {
            float a = -3.1f + k * 0.52f + MathF.Sin(time * 1.3f + k + d.X) * 0.05f;
            DrawLeaf(g, tx, ty, a, 52f + (k % 2) * 12f, 26f + (k % 3) * 8f, (k & 1) == 0 ? l1 : l2);
        }
        g.FillEllipse(B(Color.FromArgb(255, 110, 72, 36)), tx - 5f, ty - 3f, 10f, 10f);
    }

    private void DrawBush(Graphics g, Decor d)
    {
        for (int i = 0; i < 5; i++)
        {
            int h = Hash((int)d.X + i * 13);
            float r = 14f + h % 9;
            float x = d.X + i * 12f;
            float y = d.Y - r * 0.8f - (h >> 5) % 8;
            g.FillEllipse(B(Color.FromArgb(255, 44, 104, 46)), x - r, y - r, r * 2f, r * 1.7f);
            g.FillEllipse(B(Color.FromArgb(255, 80, 150, 58)), x - r * 0.7f, y - r * 0.9f, r * 1.2f, r * 0.9f);
        }
    }

    private void DrawRuinBuilding(Graphics g, Decor d)
    {
        Color[] wall = { Color.FromArgb(255, 210, 178, 126), Color.FromArgb(255, 192, 152, 112), Color.FromArgb(255, 176, 138, 104) };
        Color c = wall[d.Variant % wall.Length];
        float x = d.X;
        float top = d.Y - d.H;
        // body with a jagged, broken top
        int n = 8;
        PointF[] pts = new PointF[n + 3];
        pts[0] = new PointF(x, d.Y);
        for (int i = 0; i <= n; i++)
        {
            int h = Hash((int)x + i * 31 + d.Variant);
            float jag = (i % 2 == 0) ? (h % 40) : (h % 14);
            pts[i + 1] = new PointF(x + d.W * i / n, top + jag);
        }
        pts[n + 2] = new PointF(x + d.W, d.Y);
        g.FillPolygon(B(c), pts);
        g.FillRectangle(B(Color.FromArgb(70, 40, 20, 0)), x + d.W * 0.72f, top + 30f, d.W * 0.28f, d.H - 30f);
        g.DrawPolygon(P(Color.FromArgb(255, 90, 66, 44), 2.5f), pts);
        // windows and holes
        for (int r = 0; r < 2; r++)
        {
            for (int k = 0; k < 2; k++)
            {
                float wx = x + 28f + k * (d.W - 90f);
                float wy = top + 50f + r * 80f;
                if (wy + 40f > d.Y - 40f) continue;
                g.FillRectangle(B(Color.FromArgb(255, 40, 30, 28)), wx, wy, 34f, 42f);
                g.FillEllipse(B(Color.FromArgb(255, 40, 30, 28)), wx, wy - 10f, 34f, 22f);
                g.DrawRectangle(P(Color.FromArgb(255, 110, 70, 44), 3f), wx - 1f, wy - 1f, 36f, 44f);
            }
        }
        // exposed bricks and a door
        g.FillRectangle(B(Color.FromArgb(255, 164, 96, 72)), x + 10f, d.Y - 70f, 50f, 40f);
        g.FillRectangle(B(Color.FromArgb(255, 56, 38, 28)), x + d.W * 0.55f, d.Y - 56f, 38f, 56f);
        g.FillEllipse(B(Color.FromArgb(255, 56, 38, 28)), x + d.W * 0.55f, d.Y - 66f, 38f, 22f);
        for (int i = 0; i < 4; i++) g.FillRectangle(B(Color.FromArgb(255, 126, 90, 56)), x + d.W * 0.2f + i * 7f, d.Y - 10f - (i % 2) * 5f, 12f, 8f);
    }

    private void DrawBarbed(Graphics g, Decor d)
    {
        for (float px = d.X; px <= d.X + d.W + 1f; px += d.W / 3f)
        {
            g.DrawLine(P(Color.FromArgb(255, 90, 66, 40), 4f), px, d.Y, px, d.Y - d.H);
        }
        for (int row = 0; row < 3; row++)
        {
            float y = d.Y - 8f - row * 11f;
            for (float x = d.X; x < d.X + d.W; x += 10f)
            {
                float y1 = y + ((int)(x / 10f) % 2 == 0 ? -5f : 5f);
                float y2 = y + ((int)(x / 10f) % 2 == 0 ? 5f : -5f);
                g.DrawLine(P(Color.FromArgb(255, 70, 74, 80), 1.6f), x, y1, x + 10f, y2);
            }
            for (float x = d.X + 4f; x < d.X + d.W; x += 18f) g.DrawLine(P(Color.FromArgb(255, 150, 154, 160), 1.4f), x, y - 4f, x + 3f, y + 4f);
        }
    }

    private void DrawWreck(Graphics g, Decor d)
    {
        Color dark = Color.FromArgb(255, 54, 46, 40);
        g.FillRectangle(B(dark), d.X + 10f, d.Y - 34f, d.W - 20f, 22f);
        g.FillRectangle(B(Color.FromArgb(255, 74, 60, 50)), d.X + 26f, d.Y - 52f, 50f, 22f);
        g.FillRectangle(B(Color.FromArgb(255, 110, 62, 40)), d.X + 16f, d.Y - 30f, 40f, 8f);
        g.FillEllipse(B(Color.FromArgb(255, 30, 28, 28)), d.X + 14f, d.Y - 22f, 26f, 26f);
        g.FillEllipse(B(Color.FromArgb(255, 30, 28, 28)), d.X + d.W - 42f, d.Y - 22f, 26f, 26f);
        g.FillEllipse(B(Color.FromArgb(255, 90, 90, 90)), d.X + 22f, d.Y - 14f, 10f, 10f);
        g.DrawRectangle(P(Color.FromArgb(255, 20, 18, 18), 2f), d.X + 10f, d.Y - 34f, d.W - 20f, 22f);
    }

    private void DrawBarrel(Graphics g, Decor d)
    {
        bool red = (Hash((int)d.X) & 1) == 0;
        g.FillRectangle(B(red ? Color.FromArgb(255, 190, 50, 40) : Color.FromArgb(255, 90, 100, 90)), d.X, d.Y - d.H, d.W, d.H);
        g.FillRectangle(B(Color.FromArgb(90, 255, 255, 255)), d.X + 3f, d.Y - d.H, 5f, d.H);
        g.DrawLine(P(Color.FromArgb(255, 50, 30, 26), 2f), d.X, d.Y - d.H + 8f, d.X + d.W, d.Y - d.H + 8f);
        g.DrawLine(P(Color.FromArgb(255, 50, 30, 26), 2f), d.X, d.Y - 8f, d.X + d.W, d.Y - 8f);
        g.DrawRectangle(P(Color.FromArgb(255, 40, 24, 20), 2f), d.X, d.Y - d.H, d.W, d.H);
        g.FillEllipse(B(Color.FromArgb(255, 255, 220, 60)), d.X + d.W / 2f - 3f, d.Y - d.H / 2f - 3f, 6f, 6f);
    }

    private void DrawHut(Graphics g, Decor d)
    {
        float top = d.Y - d.H;
        g.FillRectangle(B(Color.FromArgb(255, 214, 190, 142)), d.X, top + 28f, d.W, d.H - 28f);
        g.FillRectangle(B(Color.FromArgb(70, 60, 30, 0)), d.X + d.W * 0.7f, top + 28f, d.W * 0.3f, d.H - 28f);
        // terracotta roof
        PointF[] roof = { new PointF(d.X - 10f, top + 34f), new PointF(d.X + 20f, top), new PointF(d.X + d.W - 20f, top), new PointF(d.X + d.W + 10f, top + 34f) };
        g.FillPolygon(B(Color.FromArgb(255, 200, 100, 62)), roof);
        for (float x = d.X; x < d.X + d.W; x += 14f) g.DrawLine(P(Color.FromArgb(160, 130, 60, 36), 1.4f), x, top + 4f, x - 4f, top + 32f);
        g.DrawPolygon(P(Color.FromArgb(255, 100, 50, 34), 2.5f), roof);
        g.FillRectangle(B(Color.FromArgb(255, 56, 42, 34)), d.X + 18f, top + 44f, 26f, 32f);
        g.FillRectangle(B(Color.FromArgb(255, 56, 42, 34)), d.X + d.W - 48f, d.Y - 50f, 24f, 50f);
        g.DrawRectangle(P(Color.FromArgb(255, 120, 86, 56), 3f), d.X + 17f, top + 43f, 28f, 34f);
        g.DrawLine(P(Color.FromArgb(255, 120, 86, 56), 2f), d.X + 31f, top + 43f, d.X + 31f, top + 77f);
        g.DrawRectangle(P(Color.FromArgb(255, 110, 90, 64), 2f), d.X, top + 28f, d.W, d.H - 28f);
    }

    private void DrawTowerSupports(Graphics g, Decor d)
    {
        float top = d.Y - d.H + 12f;
        Color wood = Color.FromArgb(255, 120, 82, 44);
        for (int i = 0; i < 3; i++)
        {
            float px = d.X + 8f + i * (d.W - 24f) / 2f;
            g.FillRectangle(B(wood), px, top, 8f, d.H - 12f);
        }
        g.DrawLine(P(Color.FromArgb(255, 96, 64, 34), 4f), d.X + 10f, top + 6f, d.X + d.W / 2f, d.Y - 6f);
        g.DrawLine(P(Color.FromArgb(255, 96, 64, 34), 4f), d.X + d.W - 10f, top + 6f, d.X + d.W / 2f, d.Y - 6f);
        g.DrawLine(P(Color.FromArgb(255, 96, 64, 34), 4f), d.X + 10f, top + 50f, d.X + d.W - 10f, top + 6f);
    }

    private void DrawFortWall(Graphics g, Decor d)
    {
        float top = d.Y - d.H;
        Color stone = Color.FromArgb(255, 158, 142, 116);
        g.FillRectangle(B(stone), d.X, top + 30f, d.W, d.H - 30f);
        for (float y = top + 36f; y < d.Y; y += 20f)
        {
            int row = (int)((y - top) / 20f);
            g.DrawLine(P(Color.FromArgb(140, 90, 80, 64), 1.5f), d.X, y, d.X + d.W, y);
            for (float x = d.X + (row % 2) * 20f; x < d.X + d.W; x += 40f)
                g.DrawLine(P(Color.FromArgb(120, 90, 80, 64), 1.5f), x, y, x, y + 20f);
        }
        // battlements and towers
        for (float x = d.X; x < d.X + d.W; x += 44f)
            g.FillRectangle(B(stone), x, top + 12f, 28f, 22f);
        for (float x = d.X + 200f; x < d.X + d.W - 200f; x += 420f)
        {
            g.FillRectangle(B(Color.FromArgb(255, 146, 130, 104)), x, top - 50f, 110f, 90f);
            for (float cx = x; cx < x + 110f; cx += 30f) g.FillRectangle(B(Color.FromArgb(255, 146, 130, 104)), cx, top - 64f, 18f, 16f);
            g.FillRectangle(B(Color.FromArgb(255, 40, 34, 30)), x + 46f, top - 20f, 16f, 34f);
            // banner
            g.FillRectangle(B(Color.FromArgb(255, 196, 40, 44)), x + 78f, top + 40f, 30f, 70f);
            g.FillRectangle(B(Color.FromArgb(255, 240, 240, 230)), x + 90f, top + 56f, 6f, 26f);
            g.FillRectangle(B(Color.FromArgb(255, 240, 240, 230)), x + 82f, top + 66f, 22f, 6f);
        }
        g.FillRectangle(B(Color.FromArgb(60, 0, 0, 0)), d.X, d.Y - 18f, d.W, 18f);
        g.DrawRectangle(P(Color.FromArgb(255, 70, 60, 46), 2.5f), d.X, top + 30f, d.W, d.H - 30f);
        for (float x = d.X + 80f; x < d.X + d.W; x += 130f) g.FillRectangle(B(Color.FromArgb(255, 36, 30, 26)), x, top + 70f, 10f, 28f);
    }

    private void DrawFortGate(Graphics g, Decor d)
    {
        float top = d.Y - d.H;
        g.FillRectangle(B(Color.FromArgb(255, 170, 152, 120)), d.X, top, d.W, d.H);
        g.DrawRectangle(P(Color.FromArgb(255, 70, 60, 46), 3f), d.X, top, d.W, d.H);
        // the archway with a steel door
        float ax = d.X + d.W / 2f - 100f;
        g.FillRectangle(B(Color.FromArgb(255, 30, 26, 24)), ax, d.Y - 190f, 200f, 190f);
        g.FillEllipse(B(Color.FromArgb(255, 30, 26, 24)), ax, d.Y - 240f, 200f, 100f);
        g.FillRectangle(B(Color.FromArgb(255, 96, 102, 112)), ax + 6f, d.Y - 190f, 86f, 190f);
        for (float y = d.Y - 180f; y < d.Y; y += 24f) g.DrawLine(P(Color.FromArgb(255, 60, 66, 76), 2f), ax + 6f, y, ax + 92f, y);
        g.FillRectangle(B(Color.FromArgb(255, 96, 102, 112)), ax + 108f, d.Y - 190f, 86f, 190f);
        for (float y = d.Y - 180f; y < d.Y; y += 24f) g.DrawLine(P(Color.FromArgb(255, 60, 66, 76), 2f), ax + 108f, y, ax + 194f, y);
        g.DrawArc(P(Color.FromArgb(255, 120, 106, 84), 8f), ax - 4f, d.Y - 244f, 208f, 108f, 180f, 180f);
        g.FillRectangle(B(Color.FromArgb(255, 196, 40, 44)), d.X + 24f, top + 20f, 36f, 100f);
        g.FillRectangle(B(Color.FromArgb(255, 196, 40, 44)), d.X + d.W - 60f, top + 20f, 36f, 100f);
    }

    private void DrawFlag(Graphics g, Decor d, float time)
    {
        g.DrawLine(P(Color.FromArgb(255, 70, 54, 40), 4f), d.X, d.Y, d.X, d.Y - d.H);
        float wave = MathF.Sin(time * 4f + d.X) * 5f;
        PointF[] pts = { new PointF(d.X, d.Y - d.H), new PointF(d.X + d.W * 0.6f, d.Y - d.H + wave), new PointF(d.X + d.W, d.Y - d.H + 14f), new PointF(d.X + d.W * 0.6f, d.Y - d.H + 34f + wave), new PointF(d.X, d.Y - d.H + 30f) };
        g.FillPolygon(B(Color.FromArgb(255, 196, 40, 44)), pts);
        g.FillRectangle(B(Color.FromArgb(255, 240, 240, 230)), d.X + d.W * 0.3f, d.Y - d.H + 8f + wave * 0.4f, 5f, 18f);
        g.FillRectangle(B(Color.FromArgb(255, 240, 240, 230)), d.X + d.W * 0.2f, d.Y - d.H + 14f + wave * 0.4f, 16f, 5f);
        g.DrawPolygon(P(Color.FromArgb(255, 90, 20, 24), 1.5f), pts);
    }

    private void DrawSmoke(Graphics g, Decor d, float time)
    {
        for (int k = 0; k < 8; k++)
        {
            float t = (time * 0.35f + k / 8f) % 1f;
            float y = d.Y - t * d.H - 20f;
            float x = d.X + MathF.Sin(t * 7f + k) * 14f + t * 30f;
            float r = 8f + 26f * t;
            g.FillEllipse(B(Color.FromArgb(A(150 * (1f - t)), 58, 56, 60)), x - r, y - r, r * 2f, r * 2f);
        }
    }

    private void DrawSign(Graphics g, Decor d)
    {
        g.FillRectangle(B(Color.FromArgb(255, 110, 76, 40)), d.X + d.W / 2f - 3f, d.Y - d.H, 6f, d.H);
        PointF[] pts = { new PointF(d.X + 4f, d.Y - d.H + 6f), new PointF(d.X + d.W - 14f, d.Y - d.H + 6f), new PointF(d.X + d.W, d.Y - d.H + 18f), new PointF(d.X + d.W - 14f, d.Y - d.H + 30f), new PointF(d.X + 4f, d.Y - d.H + 30f) };
        g.FillPolygon(B(Color.FromArgb(255, 196, 150, 88)), pts);
        g.DrawPolygon(P(Color.FromArgb(255, 80, 52, 26), 2f), pts);
        g.DrawLine(P(Color.FromArgb(255, 196, 40, 44), 3f), d.X + 12f, d.Y - d.H + 18f, d.X + d.W - 22f, d.Y - d.H + 18f);
    }

    private void DrawCrane(Graphics g, Decor d)
    {
        float top = d.Y - d.H;
        Color steel = Color.FromArgb(255, 200, 150, 50);
        g.DrawLine(P(steel, 6f), d.X + 20f, d.Y, d.X + 20f, top);
        g.DrawLine(P(steel, 6f), d.X + 60f, d.Y, d.X + 60f, top);
        for (float y = d.Y; y > top + 20f; y -= 40f)
        {
            g.DrawLine(P(Color.FromArgb(255, 150, 110, 36), 3f), d.X + 20f, y, d.X + 60f, y - 40f);
            g.DrawLine(P(Color.FromArgb(255, 150, 110, 36), 3f), d.X + 60f, y, d.X + 20f, y - 40f);
        }
        g.DrawLine(P(steel, 7f), d.X - 40f, top, d.X + 130f, top);
        g.DrawLine(P(Color.FromArgb(255, 60, 60, 66), 2f), d.X + 110f, top, d.X + 110f, top + 90f);
        g.FillRectangle(B(Color.FromArgb(255, 70, 74, 82)), d.X + 98f, top + 90f, 24f, 14f);
    }

    private void DrawPipeLine(Graphics g, Decor d)
    {
        g.FillRectangle(B(Color.FromArgb(255, 96, 104, 118)), d.X, d.Y, d.W, d.H);
        g.FillRectangle(B(Color.FromArgb(110, 255, 255, 255)), d.X, d.Y + 2f, d.W, 4f);
        g.FillRectangle(B(Color.FromArgb(90, 0, 0, 0)), d.X, d.Y + d.H - 5f, d.W, 5f);
        for (float x = d.X; x < d.X + d.W; x += 120f)
        {
            g.FillRectangle(B(Color.FromArgb(255, 70, 76, 88)), x, d.Y - 3f, 10f, d.H + 6f);
            g.FillRectangle(B(Color.FromArgb(255, 60, 64, 74)), x + 3f, d.Y + d.H, 5f, GameConfig.GroundY - d.Y - d.H);
        }
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private static Bitmap MakeSky()
    {
        Bitmap bmp = new Bitmap(W, ViewH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        using (LinearGradientBrush lg = new LinearGradientBrush(new Rectangle(0, 0, W, ViewH), Color.FromArgb(70, 150, 232), Color.FromArgb(214, 236, 250), 90f))
        {
            g.FillRectangle(lg, 0, 0, W, ViewH);
        }
        return bmp;
    }

    private static Bitmap MakeCloud(int variant)
    {
        Bitmap bmp = new Bitmap(240, 100, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(60 + variant * 9);
            using (SolidBrush shade = new SolidBrush(Color.FromArgb(120, 170, 200, 236)))
            using (SolidBrush body = new SolidBrush(Color.FromArgb(235, 255, 255, 255)))
            {
                for (int i = 0; i < 7; i++)
                {
                    float x = 30 + rnd.Next(150);
                    float y = 40 + rnd.Next(24);
                    float r = 18 + rnd.Next(20);
                    g.FillEllipse(shade, x - r, y - r * 0.5f + 8f, r * 2f, r * 1.2f);
                }
                for (int i = 0; i < 7; i++)
                {
                    float x = 30 + rnd.Next(150);
                    float y = 40 + rnd.Next(24);
                    float r = 18 + rnd.Next(20);
                    g.FillEllipse(body, x - r, y - r * 0.8f, r * 2f, r * 1.4f);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeMountains()
    {
        Bitmap bmp = new Bitmap(LayerW, 330, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(31);
            int count = 12;
            PointF[] pts = new PointF[count + 3];
            pts[0] = new PointF(0f, 330f);
            for (int i = 0; i <= count; i++)
            {
                float peak = (i % 2 == 0) ? 40 + rnd.Next(110) : 130 + rnd.Next(70);
                if (i == 0 || i == count) peak = 150f;
                pts[i + 1] = new PointF(i * (LayerW / (float)count), peak);
            }
            pts[count + 2] = new PointF(LayerW, 330f);
            using (SolidBrush far = new SolidBrush(Color.FromArgb(255, 98, 138, 196)))
            using (SolidBrush light = new SolidBrush(Color.FromArgb(110, 214, 232, 255)))
            {
                g.FillPolygon(far, pts);
                for (int i = 1; i <= count; i += 2)
                {
                    PointF p = pts[i + 1];
                    g.FillPolygon(light, new[] { new PointF(p.X, p.Y), new PointF(p.X - 34f, p.Y + 60f), new PointF(p.X - 6f, p.Y + 40f), new PointF(p.X + 18f, p.Y + 70f) });
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeHills()
    {
        Bitmap bmp = new Bitmap(LayerW, 250, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(52);
            using (SolidBrush hill = new SolidBrush(Color.FromArgb(255, 74, 134, 92)))
            using (SolidBrush dark = new SolidBrush(Color.FromArgb(255, 46, 100, 70)))
            using (SolidBrush stone = new SolidBrush(Color.FromArgb(255, 126, 126, 134)))
            {
                for (int i = 0; i < 12; i++)
                {
                    float cx = i * 170 + rnd.Next(60);
                    float w = 240 + rnd.Next(160);
                    float h = 80 + rnd.Next(90);
                    g.FillEllipse(hill, cx - w / 2f, 250f - h, w, h * 2f);
                }
                // distant ruined fortress towers
                for (int k = 0; k < 3; k++)
                {
                    float fx = 260 + k * 620 + rnd.Next(80);
                    g.FillRectangle(stone, fx, 110, 70, 100);
                    for (int c = 0; c < 4; c++) g.FillRectangle(stone, fx + c * 20, 98, 12, 14);
                    g.FillRectangle(stone, fx + 80, 140, 120, 70);
                    for (int c = 0; c < 6; c++) g.FillRectangle(stone, fx + 80 + c * 22, 130, 12, 12);
                    g.FillRectangle(dark, fx + 28, 150, 14, 26);
                }
                for (int i = 0; i < 30; i++)
                {
                    float px = rnd.Next(LayerW);
                    float ph = 40 + rnd.Next(30);
                    using (Pen trunk = new Pen(Color.FromArgb(255, 56, 70, 50), 4f))
                    {
                        g.DrawLine(trunk, px, 240, px + 4, 240 - ph);
                    }
                    for (int l = 0; l < 5; l++)
                    {
                        float a = -3f + l * 0.55f;
                        using (Pen leaf = new Pen(Color.FromArgb(255, 36, 94, 56), 5f))
                        {
                            g.DrawLine(leaf, px + 4, 240 - ph, px + 4 + MathF.Cos(a) * 24, 240 - ph + MathF.Sin(a) * 14 + 8);
                        }
                    }
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeJungle()
    {
        Bitmap bmp = new Bitmap(LayerW, 190, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Random rnd = new Random(77);
            using (SolidBrush a = new SolidBrush(Color.FromArgb(255, 34, 92, 52)))
            using (SolidBrush b = new SolidBrush(Color.FromArgb(255, 52, 122, 60)))
            using (SolidBrush c = new SolidBrush(Color.FromArgb(255, 78, 150, 66)))
            {
                for (int i = 0; i < 70; i++)
                {
                    float cx = rnd.Next(LayerW);
                    float r = 20 + rnd.Next(34);
                    float cy = 190 - rnd.Next(60);
                    g.FillEllipse(a, cx - r, cy - r, r * 2f, r * 1.7f);
                    g.FillEllipse(b, cx - r * 0.75f, cy - r * 1.05f, r * 1.5f, r * 1.1f);
                    g.FillEllipse(c, cx - r * 0.4f, cy - r * 1.15f, r * 0.8f, r * 0.55f);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeStoneTile()
    {
        Bitmap bmp = new Bitmap(128, 100, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.FromArgb(255, 104, 80, 54));
            Random rnd = new Random(14);
            using (Pen mortar = new Pen(Color.FromArgb(255, 54, 40, 26), 3f))
            {
                for (int row = 0; row < 4; row++)
                {
                    int y = row * 25;
                    int x = (row % 2) * 24 - 10;
                    while (x < 128)
                    {
                        int w = 40 + rnd.Next(30);
                        int shade = rnd.Next(3);
                        Color c = shade == 0 ? Color.FromArgb(255, 132, 104, 72) : (shade == 1 ? Color.FromArgb(255, 116, 90, 62) : Color.FromArgb(255, 146, 118, 82));
                        using (SolidBrush b = new SolidBrush(c))
                        {
                            g.FillRectangle(b, x + 1, y + 1, w - 2, 23);
                        }
                        using (SolidBrush hi = new SolidBrush(Color.FromArgb(90, 255, 230, 180)))
                        {
                            g.FillRectangle(hi, x + 3, y + 3, w - 8, 3);
                        }
                        g.DrawRectangle(mortar, x, y, w, 25);
                        x += w;
                    }
                }
            }
        }
        return bmp;
    }
}
