namespace MetalSlug;

public enum VehicleType { Armored, Tank }

/// <summary>
/// An enemy vehicle. The armored car drives back and forth and rakes the player with machine-gun bursts; the tank is
/// large and slow, aims its turret and fires powerful explosive shells.
/// </summary>
public sealed class Vehicle
{
    public VehicleType Type;
    public float X, Y, VX;                 // X is the centre, Y the bottom
    public float HalfW, Height;
    public float Hp, MaxHp;
    public int Facing = -1;
    public int Score;
    public bool Active, Dying;
    public float DeathTimer, HitFlash, TrackPhase, TurretAngle, Recoil, Age;
    public float Min, Max;

    private float fireTimer = 1.5f;
    private int burstLeft, cycle;
    private float burstTimer;

    public RectangleF Rect
    {
        get { return new RectangleF(X - HalfW, Y - Height, HalfW * 2f, Height); }
    }

    public bool Hittable { get { return Active && !Dying; } }

    public float GunX { get { return X + Facing * (Type == VehicleType.Tank ? 40f : 26f); } }
    public float GunY { get { return Y - (Type == VehicleType.Tank ? 66f : 50f); } }

    public void Init(VehicleSpawn s)
    {
        Type = s.Type;
        X = s.X;
        Y = GameConfig.GroundY;
        Min = s.Min;
        Max = s.Max;
        Active = false;
        Dying = false;
        if (Type == VehicleType.Tank)
        {
            HalfW = 86f; Height = 84f; Hp = 48f; Score = GameConfig.ScoreTank;
        }
        else
        {
            HalfW = 58f; Height = 56f; Hp = 22f; Score = GameConfig.ScoreArmored;
        }
        MaxHp = Hp;
    }

    public void Damage(float amount)
    {
        Hp -= amount;
        HitFlash = 0.1f;
    }

    public void Update(float dt, float tx, float ty, bool canAct, ProjectileManager shots, Random rng, out bool fired)
    {
        fired = false;
        Age += dt;
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        if (Recoil > 0f) Recoil = Math.Max(0f, Recoil - dt * 5f);
        if (Dying)
        {
            DeathTimer -= dt;
            VX = 0f;
            return;
        }

        float dx = tx - X;
        float dir = dx >= 0f ? 1f : -1f;
        if (Math.Abs(dx) > 40f) Facing = (int)dir;
        float speed = Type == VehicleType.Tank ? 32f : 62f;
        float vx = 0f;
        if (canAct)
        {
            if (Math.Abs(dx) > 340f) vx = dir * speed;
            else if (Math.Abs(dx) < 200f) vx = -dir * speed * 0.6f;
        }
        if ((vx > 0f && X >= Max) || (vx < 0f && X <= Min)) vx = 0f;
        VX = vx;
        X += VX * dt;
        TrackPhase += VX * dt * 0.1f;

        // the tank turret follows the target
        if (Type == VehicleType.Tank)
        {
            float want = MathF.Atan2(ty - GunY, Math.Abs(dx));
            want = Math.Max(-0.7f, Math.Min(0.35f, want));
            TurretAngle += (want - TurretAngle) * Math.Min(1f, 3f * dt);
        }

        if (!canAct) return;
        fireTimer -= dt;
        if (Type == VehicleType.Armored)
        {
            if (burstLeft > 0)
            {
                burstTimer -= dt;
                if (burstTimer <= 0f)
                {
                    float a = MathF.Atan2(ty - GunY, tx - GunX) + ((float)rng.NextDouble() - 0.5f) * 0.1f;
                    shots.Spawn(ShotKind.EBullet, GunX, GunY, MathF.Cos(a) * 350f, MathF.Sin(a) * 350f, 1f, 3f);
                    burstLeft--;
                    burstTimer = 0.12f;
                    Recoil = 0.5f;
                    fired = true;
                }
            }
            else if (fireTimer <= 0f && Math.Abs(dx) < 700f)
            {
                burstLeft = 5;
                burstTimer = 0.1f;
                fireTimer = 2.4f;
            }
        }
        else
        {
            if (burstLeft > 0)
            {
                burstTimer -= dt;
                if (burstTimer <= 0f)
                {
                    float a = MathF.Atan2(ty - GunY, tx - GunX) + ((float)rng.NextDouble() - 0.5f) * 0.12f;
                    shots.Spawn(ShotKind.EBullet, GunX, GunY - 12f, MathF.Cos(a) * 340f, MathF.Sin(a) * 340f, 1f, 3f);
                    burstLeft--;
                    burstTimer = 0.14f;
                    fired = true;
                }
            }
            if (fireTimer <= 0f && Math.Abs(dx) < 760f)
            {
                float a = MathF.Atan2(ty - GunY, tx - GunX);
                float mx = GunX + MathF.Cos(a) * 60f;
                float my = GunY + MathF.Sin(a) * 60f;
                Projectile s = shots.Spawn(ShotKind.EShell, mx, my, MathF.Cos(a) * 370f, MathF.Sin(a) * 370f, 2f, 4f);
                s.AY = 140f;
                Recoil = 1f;
                fired = true;
                cycle++;
                fireTimer = 3f;
                if (cycle % 2 == 0)
                {
                    burstLeft = 4;
                    burstTimer = 0.4f;
                }
            }
        }
    }
}
