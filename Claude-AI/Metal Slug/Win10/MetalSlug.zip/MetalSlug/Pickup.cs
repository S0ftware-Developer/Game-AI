namespace MetalSlug;

public enum PickupType { HeavyMG, Shotgun, Rocket, Grenades, Life, Health, Armor, Score }

/// <summary>A collectible crate lying on the battlefield.</summary>
public sealed class Pickup
{
    public float X, Y;                    // Y is the bottom of the crate
    public float Age;
    public PickupType Type;
    public bool Alive = true;

    public const float HalfW = 16f;
    public const float Size = 30f;

    public static string Label(PickupType t)
    {
        switch (t)
        {
            case PickupType.HeavyMG: return "HEAVY MACHINE GUN!";
            case PickupType.Shotgun: return "SHOTGUN!";
            case PickupType.Rocket: return "ROCKET LAUNCHER!";
            case PickupType.Grenades: return "GRENADES +6";
            case PickupType.Life: return "1UP!";
            case PickupType.Health: return "HEALTH +1";
            case PickupType.Armor: return "ARMOR +2";
            default: return "MEDAL +" + GameConfig.ScoreMedal;
        }
    }
}

public sealed class PickupManager
{
    public readonly List<Pickup> Items = new List<Pickup>(48);

    public void Reset(Level level)
    {
        Items.Clear();
        foreach (PickupSpawn s in level.Pickups) Spawn(s.X, s.Y, s.Type);
    }

    public void Spawn(float x, float bottomY, PickupType type)
    {
        Pickup p = new Pickup();
        p.X = x;
        p.Y = bottomY;
        p.Type = type;
        Items.Add(p);
    }

    public void Update(float dt)
    {
        for (int i = Items.Count - 1; i >= 0; i--)
        {
            Pickup p = Items[i];
            p.Age += dt;
            if (!p.Alive) Items.RemoveAt(i);
        }
    }
}
