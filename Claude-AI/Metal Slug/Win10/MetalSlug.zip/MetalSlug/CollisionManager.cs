namespace MetalSlug;

/// <summary>Body-versus-level physics and all hit tests between shots, soldiers, vehicles, the boss and pickups.</summary>
public static class CollisionManager
{
    public static bool CircleRect(float cx, float cy, float r, RectangleF rc)
    {
        float nx = Math.Max(rc.Left, Math.Min(cx, rc.Right));
        float ny = Math.Max(rc.Top, Math.Min(cy, rc.Bottom));
        float dx = cx - nx;
        float dy = cy - ny;
        return dx * dx + dy * dy <= r * r;
    }

    /// <summary>
    /// Moves a box (centre x, bottom y, half width hw, height h) by its velocity against the solids of the level, one axis
    /// at a time. Thin platforms can only be landed on from above. Returns true when the box stands on something.
    /// </summary>
    public static bool MoveBody(Level lv, ref float x, ref float y, ref float vx, ref float vy, float hw, float h, float dt)
    {
        // horizontal
        x += vx * dt;
        float top = y - h;
        float bottom = y;
        foreach (Solid s in lv.Solids)
        {
            if (s.OneWay) continue;
            RectangleF r = s.Rect;
            if (x + hw > r.Left && x - hw < r.Right && bottom > r.Top + 2f && top < r.Bottom)
            {
                if (vx > 0f) x = r.Left - hw;
                else if (vx < 0f) x = r.Right + hw;
                else x += (x < r.Left + r.Width / 2f) ? -1f : 1f;
                vx = 0f;
            }
        }

        // vertical
        float prevBottom = y;
        y += vy * dt;
        bool grounded = false;
        foreach (Solid s in lv.Solids)
        {
            RectangleF r = s.Rect;
            if (x + hw <= r.Left || x - hw >= r.Right) continue;
            if (vy >= 0f)
            {
                if (y >= r.Top && prevBottom <= r.Top + 1f)
                {
                    y = r.Top;
                    vy = 0f;
                    grounded = true;
                }
            }
            else if (!s.OneWay)
            {
                if (y - h < r.Bottom && prevBottom - h >= r.Bottom - 1f)
                {
                    y = r.Bottom + h;
                    vy = 0f;
                }
            }
        }
        return grounded;
    }

    public static void Resolve(GameEngine g)
    {
        PlayerShots(g);
        EnemyShots(g);
        Contacts(g);
        PickupsVsPlayer(g);
    }

    // ------------------------------------------------------------------ the player's weapons

    private static void HitPlayerShot(GameEngine g, Projectile p, float x, float y)
    {
        g.Particles.Sparks(x, y, 130f, 3, Color.FromArgb(255, 230, 140));
        if (p.Explosive) g.Shots.End(p);
        else p.Alive = false;
    }

    private static void PlayerShots(GameEngine g)
    {
        List<Projectile> items = g.Shots.Items;
        for (int i = 0; i < items.Count; i++)
        {
            Projectile p = items[i];
            if (!p.Alive || !p.FromPlayer) continue;
            bool done = false;

            foreach (Enemy e in g.Enemies.Enemies)
            {
                if (!e.Hittable || !CircleRect(p.X, p.Y, p.Radius, e.Rect)) continue;
                if (!p.Explosive) g.Enemies.DamageEnemy(e, p.Damage);
                HitPlayerShot(g, p, p.X, p.Y);
                done = true;
                break;
            }
            if (done) continue;

            foreach (Vehicle v in g.Enemies.Vehicles)
            {
                if (!v.Hittable || !CircleRect(p.X, p.Y, p.Radius, v.Rect)) continue;
                if (!p.Explosive) g.Enemies.DamageVehicle(v, p.Damage);
                HitPlayerShot(g, p, p.X, p.Y);
                done = true;
                break;
            }
            if (done) continue;

            if (g.Boss.Vulnerable && CircleRect(p.X, p.Y, p.Radius, g.Boss.Rect))
            {
                if (!p.Explosive) g.Boss.Damage(p.Damage);
                HitPlayerShot(g, p, p.X, p.Y);
            }
        }
    }

    // ------------------------------------------------------------------ enemy fire

    private static void EnemyShots(GameEngine g)
    {
        List<Projectile> items = g.Shots.Items;
        for (int i = 0; i < items.Count; i++)
        {
            Projectile p = items[i];
            if (!p.Alive || p.FromPlayer) continue;

            if (g.Player.InTank)
            {
                if (!g.Tank.Destroyed && CircleRect(p.X, p.Y, p.Radius, g.Tank.Rect))
                {
                    if (g.Tank.Invuln > 0f && !p.Explosive) { p.Alive = false; continue; }
                    g.Particles.Sparks(p.X, p.Y, 120f, 3, Color.FromArgb(255, 200, 120));
                    if (p.Explosive) g.Shots.End(p);
                    else
                    {
                        p.Alive = false;
                        g.TankHit((int)Math.Max(1f, p.Damage));
                    }
                }
            }
            else if (g.Player.Vulnerable && CircleRect(p.X, p.Y, p.Radius, g.Player.Rect))
            {
                if (p.Explosive) g.Shots.End(p);
                else
                {
                    p.Alive = false;
                    g.PlayerHurt((int)Math.Max(1f, p.Damage));
                }
            }
        }
    }

    // ------------------------------------------------------------------ bodies touching

    private static void Contacts(GameEngine g)
    {
        if (g.Player.InTank || !g.Player.Vulnerable) return;
        RectangleF body = g.Player.Rect;
        foreach (Vehicle v in g.Enemies.Vehicles)
        {
            if (v.Hittable && v.Rect.IntersectsWith(body))
            {
                g.PlayerHurt(1);
                return;
            }
        }
        if (g.Boss.Vulnerable && g.Boss.Rect.IntersectsWith(body)) g.PlayerHurt(1);
    }

    private static void PickupsVsPlayer(GameEngine g)
    {
        if (g.Player.Dead) return;
        RectangleF body = g.Player.InTank ? g.Tank.Rect : g.Player.Rect;
        List<Pickup> items = g.Pickups.Items;
        for (int i = 0; i < items.Count; i++)
        {
            Pickup p = items[i];
            if (!p.Alive) continue;
            RectangleF r = new RectangleF(p.X - Pickup.HalfW, p.Y - Pickup.Size, Pickup.HalfW * 2f, Pickup.Size);
            if (r.IntersectsWith(body)) g.CollectPickup(p);
        }
    }
}
