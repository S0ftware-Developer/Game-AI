namespace MetalSlug;

public enum ShotKind { Bullet, Heavy, Pellet, Rocket, TankMG, TankShell, EBullet, EHeavy, ESniper, EShell, EMortar }

/// <summary>A bullet, shell or rocket. Instances are pooled by <see cref="ProjectileManager"/>.</summary>
public sealed class Projectile
{
    public float X, Y, VX, VY, AY;
    public float Life;
    public float Damage;
    public float Radius;
    public float ExplodeRadius;          // > 0 for explosive shots
    public ShotKind Kind;
    public bool Alive;

    public bool FromPlayer { get { return Kind <= ShotKind.TankShell; } }
    public bool Explosive { get { return ExplodeRadius > 0f; } }
}
