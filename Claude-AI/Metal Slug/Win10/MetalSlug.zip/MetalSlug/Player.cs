namespace MetalSlug;

public struct PlayerInput
{
    public bool Left, Right, Up, Down, Fire, JumpPressed, JumpHeld, GrenadePressed, GrenadeHeld, EnterPressed;
}

/// <summary>
/// The commando: acceleration, variable-height jumps, crouching, five aiming directions (forward, up, down, and the
/// two diagonals), shooting while moving or jumping, grenades, health and lives.
/// </summary>
public sealed class Player
{
    public float X, Y, VX, VY;             // X is the centre, Y the feet
    public int Facing = 1;
    public bool Grounded, Crouching, Dead, InTank;
    public int Hp = GameConfig.StartHealth;
    public int Lives = GameConfig.StartLives;
    public int Grenades = GameConfig.StartGrenades;
    public float Invuln, DeathTimer, ShootAnim, ThrowAnim, PickupAnim, RunPhase, Age, HitFlash, ThrowCooldown;
    public int Aim;                        // 0 forward, 1 up, 2 down, 3 diagonal up, 4 diagonal down
    public float MuzzleX, MuzzleY, AimX = 1f, AimY;
    public readonly WeaponSystem Weapon = new WeaponSystem();

    public bool EvJump, EvLand, EvThrow;
    public float ThrowX, ThrowY, ThrowVX, ThrowVY;

    private float coyote, buffer;

    public float Height { get { return Crouching ? GameConfig.PlayerCrouchH : GameConfig.PlayerH; } }

    public RectangleF Rect
    {
        get { return new RectangleF(X - GameConfig.PlayerHalfW, Y - Height, GameConfig.PlayerHalfW * 2f, Height); }
    }

    public bool Vulnerable { get { return !Dead && Invuln <= 0f && !InTank; } }

    public void Reset(float x, float y)
    {
        Lives = GameConfig.StartLives;
        Grenades = GameConfig.StartGrenades;
        Weapon.Reset();
        InTank = false;
        Respawn(x, y);
        Invuln = 1.5f;
    }

    public void Respawn(float x, float y)
    {
        X = x;
        Y = y;
        VX = 0f;
        VY = 0f;
        Dead = false;
        Hp = GameConfig.StartHealth;
        Invuln = GameConfig.RespawnInvulnerability;
        Crouching = false;
        Grounded = false;
        ThrowAnim = 0f;
        ShootAnim = 0f;
        HitFlash = 0f;
        Weapon.Reset();
    }

    private static float Approach(float v, float target, float delta)
    {
        if (v < target) return Math.Min(target, v + delta);
        return Math.Max(target, v - delta);
    }

    public void Update(float dt, PlayerInput inp, Level lv, ProjectileManager shots, float minX, float maxX)
    {
        EvJump = false;
        EvLand = false;
        EvThrow = false;
        Age += dt;
        if (Invuln > 0f) Invuln = Math.Max(0f, Invuln - dt);
        if (HitFlash > 0f) HitFlash = Math.Max(0f, HitFlash - dt);
        if (ShootAnim > 0f) ShootAnim = Math.Max(0f, ShootAnim - dt);
        if (ThrowAnim > 0f) ThrowAnim = Math.Max(0f, ThrowAnim - dt);
        if (PickupAnim > 0f) PickupAnim = Math.Max(0f, PickupAnim - dt);
        if (ThrowCooldown > 0f) ThrowCooldown -= dt;

        if (Dead)
        {
            DeathTimer -= dt;
            VX = Approach(VX, 0f, 500f * dt);
            VY = Math.Min(900f, VY + GameConfig.Gravity * dt);
            float dx = X, dy = Y, dvx = VX, dvy = VY;
            CollisionManager.MoveBody(lv, ref dx, ref dy, ref dvx, ref dvy, 10f, 10f, dt);
            X = dx; Y = dy; VX = dvx; VY = dvy;
            return;
        }
        if (InTank) return;                 // the engine moves the soldier together with the tank

        int dir = (inp.Right ? 1 : 0) - (inp.Left ? 1 : 0);
        Crouching = inp.Down && Grounded;
        bool aimDown = inp.Down && !Grounded;
        if (inp.Up) Aim = dir != 0 ? 3 : 1;
        else if (aimDown) Aim = dir != 0 ? 4 : 2;
        else Aim = 0;
        if (dir != 0) Facing = dir;

        // horizontal movement
        float target = Crouching ? 0f : dir * GameConfig.PlayerSpeed;
        float accel = dir != 0 ? GameConfig.PlayerAccel : GameConfig.PlayerDecel;
        if (!Grounded) accel *= 0.75f;
        VX = Approach(VX, target, accel * dt);

        // jumping with a short grace time (coyote) and input buffering; releasing the key cuts the jump
        coyote = Grounded ? 0.09f : Math.Max(0f, coyote - dt);
        buffer = inp.JumpPressed ? 0.11f : Math.Max(0f, buffer - dt);
        if (buffer > 0f && coyote > 0f && !Crouching)
        {
            VY = -GameConfig.JumpSpeed;
            Grounded = false;
            coyote = 0f;
            buffer = 0f;
            EvJump = true;
        }
        if (!inp.JumpHeld && VY < -GameConfig.JumpCutSpeed) VY = -GameConfig.JumpCutSpeed;
        VY = Math.Min(900f, VY + GameConfig.Gravity * dt);

        bool wasGrounded = Grounded;
        float fallSpeed = VY;
        float x = X, y = Y, vx = VX, vy = VY;
        Grounded = CollisionManager.MoveBody(lv, ref x, ref y, ref vx, ref vy, GameConfig.PlayerHalfW, Height, dt);
        X = x; Y = y; VX = vx; VY = vy;
        if (Grounded && !wasGrounded && fallSpeed > 250f) EvLand = true;
        if (X < minX + 16f) { X = minX + 16f; if (VX < 0f) VX = 0f; }
        if (X > maxX - 16f) { X = maxX - 16f; if (VX > 0f) VX = 0f; }
        if (Grounded) RunPhase += Math.Abs(VX) * dt * 0.05f;

        UpdateAim();

        Weapon.Update(dt, this, inp.Fire, shots);

        if (inp.GrenadePressed && Grenades > 0 && ThrowCooldown <= 0f)
        {
            Grenades--;
            ThrowAnim = 0.35f;
            ThrowCooldown = 0.45f;
            EvThrow = true;
            ThrowX = X + Facing * 10f;
            ThrowY = Y - Height + 10f;
            bool up = Aim == 1 || Aim == 3;
            ThrowVX = Facing * (up ? 130f : 290f) + VX * 0.4f;
            ThrowVY = up ? -600f : -430f;
        }
    }

    /// <summary>Computes the aim direction and the muzzle position from the pose.</summary>
    private void UpdateAim()
    {
        float f = Facing;
        const float s = 0.7071f;
        switch (Aim)
        {
            case 1: AimX = 0f; AimY = -1f; break;
            case 2: AimX = 0f; AimY = 1f; break;
            case 3: AimX = f * s; AimY = -s; break;
            case 4: AimX = f * s; AimY = s; break;
            default: AimX = f; AimY = 0f; break;
        }
        float hx, hy;
        switch (Aim)
        {
            case 1: hx = f * 4f; hy = -34f; break;
            case 2: hx = f * 6f; hy = -18f; break;
            case 3: hx = f * 10f; hy = -32f; break;
            case 4: hx = f * 10f; hy = -22f; break;
            default: hx = f * 14f; hy = Crouching ? -17f : -28f; break;
        }
        float barrel = Weapon.Type == WeaponType.Machine ? 20f : (Weapon.Type == WeaponType.Rocket ? 14f : 26f);
        MuzzleX = X + hx + AimX * barrel;
        MuzzleY = Y + hy + AimY * barrel;
    }
}
