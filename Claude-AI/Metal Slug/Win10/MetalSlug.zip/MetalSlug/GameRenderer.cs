using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace MetalSlug;

/// <summary>
/// Draws the whole screen in logical 960x572 coordinates scaled to the window: the layered battlefield
/// (<see cref="BackgroundRenderer"/>), all sprites (<see cref="Sprites"/>), the arcade HUD and the menu screens.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    public static readonly Rectangle PlayButton = new Rectangle(330, 322, 300, 54);
    public static readonly Rectangle ResumeButton = new Rectangle(360, 200, 240, 46);
    public static readonly Rectangle PauseRestartButton = new Rectangle(360, 256, 240, 46);
    public static readonly Rectangle PauseMenuButton = new Rectangle(360, 312, 240, 46);
    public static readonly Rectangle EndRestartButton = new Rectangle(240, 440, 210, 52);
    public static readonly Rectangle EndMenuButton = new Rectangle(510, 440, 210, 52);

    private const int W = GameConfig.LogicalW;
    private const int ViewH = GameConfig.ViewH;

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly BackgroundRenderer bg = new BackgroundRenderer();
    private readonly Sprites sprites = new Sprites();
    private readonly Font fHud;
    private readonly Font fLabel;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fBig;
    private readonly Font fFooter;
    private readonly Font fTitleA;
    private readonly Font fTitleB;
    private readonly Font fSub;
    private readonly Font fBanner;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;
    private readonly StringFormat sfRight;
    private readonly GraphicsPath titleMetal;
    private readonly GraphicsPath titleSlug;
    private readonly LinearGradientBrush titleFill;
    private readonly PointF[] heart = new PointF[3];

    // the animated menu scene
    private readonly Level menuLevel = Level.Build();
    private readonly Player menuPlayer = new Player();
    private readonly PlayerTank menuTank = new PlayerTank();
    private readonly Enemy[] menuEnemies = new Enemy[4];
    private readonly Vehicle menuJeep = new Vehicle();
    private readonly Projectile[] menuShots = new Projectile[8];
    private readonly Explosion menuExp = new Explosion();

    public GameRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;

        fHud = new Font("Segoe UI", 22f, FontStyle.Bold, GraphicsUnit.Pixel);
        fLabel = new Font("Segoe UI", 11f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Segoe UI", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Segoe UI", 17f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBig = new Font("Segoe UI", 44f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitleA = new Font("Impact", 112f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitleB = new Font("Impact", 138f, FontStyle.Regular, GraphicsUnit.Pixel);
        fSub = new Font("Impact", 34f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBanner = new Font("Impact", 58f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;
        sfRight = new StringFormat();
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfRight.FormatFlags = StringFormatFlags.NoWrap;

        titleMetal = MakeTitle("METAL", fTitleA, 112f, W / 2f, 92f, 0.2f);
        titleSlug = MakeTitle("SLUG", fTitleB, 138f, W / 2f + 30f, 196f, 0.2f);
        RectangleF all = RectangleF.Union(titleMetal.GetBounds(), titleSlug.GetBounds());
        titleFill = new LinearGradientBrush(new RectangleF(all.X, all.Y, all.Width, all.Height), Color.FromArgb(255, 255, 226, 70), Color.FromArgb(255, 224, 56, 18), 90f);

        // the pieces of the menu scene
        menuPlayer.Facing = 1;
        menuPlayer.Grounded = true;
        menuPlayer.Weapon.Type = WeaponType.Heavy;
        menuPlayer.Weapon.Ammo = 99;
        menuTank.Facing = -1;
        menuTank.Destroyed = false;
        Random rnd = new Random(3);
        EnemyType[] types = { EnemyType.Infantry, EnemyType.Heavy, EnemyType.Grenadier, EnemyType.Elite };
        for (int i = 0; i < menuEnemies.Length; i++)
        {
            Enemy e = new Enemy();
            EnemySpawn s = new EnemySpawn();
            s.Type = types[i]; s.X = 0f; s.Y = GameConfig.GroundY; s.Min = 0f; s.Max = 0f;
            e.Init(s, rnd);
            e.Active = true;
            e.Facing = -1;
            e.Grounded = true;
            menuEnemies[i] = e;
        }
        VehicleSpawn vs = new VehicleSpawn();
        vs.Type = VehicleType.Armored; vs.X = 0f; vs.Min = 0f; vs.Max = 0f;
        menuJeep.Init(vs);
        menuJeep.Active = true;
        menuJeep.Facing = 1;
        for (int i = 0; i < menuShots.Length; i++)
        {
            Projectile p = new Projectile();
            p.Kind = ShotKind.Heavy;
            p.VX = 900f;
            menuShots[i] = p;
        }
        menuExp.Kind = ExplosionKind.Boss;
        menuExp.Size = 120f;
        menuExp.Duration = 1.1f;
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        bg.Dispose();
        sprites.Dispose();
        fHud.Dispose();
        fLabel.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fBig.Dispose();
        fFooter.Dispose();
        fTitleA.Dispose();
        fTitleB.Dispose();
        fSub.Dispose();
        fBanner.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        sfRight.Dispose();
        titleMetal.Dispose();
        titleSlug.Dispose();
        titleFill.Dispose();
    }

    private static GraphicsPath MakeTitle(string text, Font font, float size, float cx, float cy, float shear)
    {
        GraphicsPath path = new GraphicsPath();
        path.AddString(text, font.FontFamily, (int)FontStyle.Regular, size, new PointF(0f, 0f), StringFormat.GenericTypographic);
        RectangleF b = path.GetBounds();
        using (Matrix m = new Matrix())
        {
            m.Translate(cx - (b.X + b.Width / 2f), cy - (b.Y + b.Height / 2f));
            path.Transform(m);
        }
        using (Matrix sh = new Matrix(1f, 0f, -shear, 1f, cy * shear, 0f))
        {
            path.Transform(sh);
        }
        return path;
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow) g.DrawString(s, f, B(Color.FromArgb(Math.Min((int)c.A, 210), 20, 10, 0)), x + 2f, y + 2f, sf);
        g.DrawString(s, f, B(c), x, y, sf);
    }

    private static GraphicsPath RoundRect(float x, float y, float w, float h, float r)
    {
        GraphicsPath p = new GraphicsPath();
        float d = r * 2f;
        p.AddArc(x, y, d, d, 180f, 90f);
        p.AddArc(x + w - d, y, d, d, 270f, 90f);
        p.AddArc(x + w - d, y + h - d, d, d, 0f, 90f);
        p.AddArc(x, y + h - d, d, d, 90f, 90f);
        p.CloseFigure();
        return p;
    }

    private void Panel(Graphics g, float x, float y, float w, float h, int alpha)
    {
        using (GraphicsPath p = RoundRect(x, y, w, h, 8f))
        {
            g.FillPath(B(Color.FromArgb(alpha, 24, 22, 14)), p);
            g.DrawPath(P(Color.FromArgb(255, 226, 170, 50), 2f), p);
        }
    }

    private void Button(Graphics g, Rectangle r, string text, bool primary, float clock)
    {
        using (GraphicsPath p = RoundRect(r.X, r.Y, r.Width, r.Height, 8f))
        {
            g.FillPath(B(primary ? Color.FromArgb(255, 38, 34, 20) : Color.FromArgb(255, 30, 28, 20)), p);
            float k = primary ? 0.5f + 0.5f * MathF.Sin(clock * 4f) : 1f;
            g.DrawPath(P(Color.FromArgb(A(170 + 85 * k), 255, 190, 50), 3f), p);
        }
        Txt(g, text, fText, Color.White, r.X + r.Width / 2f, r.Y + r.Height / 2f, sfCenter, true);
    }

    private static string FormatTime(float seconds)
    {
        int total = (int)seconds;
        return (total / 60).ToString("D2") + ":" + (total % 60).ToString("D2");
    }

    private void DrawHeart(Graphics g, float x, float y, float s, Color c)
    {
        g.FillEllipse(B(c), x, y, s * 0.55f, s * 0.55f);
        g.FillEllipse(B(c), x + s * 0.45f, y, s * 0.55f, s * 0.55f);
        heart[0] = new PointF(x + 0.02f * s, y + s * 0.34f);
        heart[1] = new PointF(x + s * 0.98f, y + s * 0.34f);
        heart[2] = new PointF(x + s * 0.5f, y + s * 0.98f);
        g.FillPolygon(B(c), heart);
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)GameConfig.LogicalW, clientH / (float)GameConfig.LogicalH);
        float offX = (clientW - GameConfig.LogicalW * scale) / 2f;
        float offY = (clientH - GameConfig.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, GameConfig.LogicalW, GameConfig.LogicalH));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (e.State == GameState.Menu) DrawMenu(g, e);
            else
            {
                DrawGame(g, e);
                if (e.State == GameState.Paused) DrawPause(g, e);
                else if (e.State == GameState.GameOver) DrawEnd(g, e, false);
                else if (e.State == GameState.Victory) DrawEnd(g, e, true);
            }
            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ battlefield

    private void DrawGame(Graphics g, GameEngine e)
    {
        GraphicsState outer = g.Save();
        g.SetClip(new Rectangle(0, 0, W, ViewH));
        float camX = (float)Math.Round(e.Camera.X);
        float shx = 0f;
        float shy = 0f;
        if (e.Camera.Shake > 0f)
        {
            shx = MathF.Sin(e.Clock * 140f) * e.Camera.Shake * 22f;
            shy = MathF.Cos(e.Clock * 120f) * e.Camera.Shake * 16f;
        }
        bg.DrawSky(g, camX, e.Clock);
        g.TranslateTransform(shx, shy);
        bg.DrawWorld(g, e.Level, camX, e.Clock);

        GraphicsState actors = g.Save();
        g.TranslateTransform(-camX, 0f);
        float x0 = camX - 200f;
        float x1 = camX + W + 200f;

        foreach (Pickup p in e.Pickups.Items)
        {
            if (p.X > x0 && p.X < x1) sprites.DrawPickup(g, p, e.Clock);
        }
        foreach (Vehicle v in e.Enemies.Vehicles)
        {
            if (!v.Active || v.X < x0 - 100f || v.X > x1 + 100f) continue;
            if (v.Type == VehicleType.Tank) sprites.DrawEnemyTank(g, v, e.Clock);
            else sprites.DrawArmored(g, v, e.Clock);
        }
        foreach (Enemy en in e.Enemies.Enemies)
        {
            if (!en.Active || en.X < x0 || en.X > x1) continue;
            sprites.DrawEnemy(g, en, e.Clock);
        }
        sprites.DrawPlayerTank(g, e.Tank, e.Clock);
        if (e.Boss.Active) sprites.DrawBoss(g, e.Boss, e.Clock);
        sprites.DrawPlayer(g, e.Player, e.Clock);
        foreach (Projectile p in e.Shots.Items) sprites.DrawProjectile(g, p);
        foreach (Grenade gr in e.Grenades.Items) sprites.DrawGrenade(g, gr, e.Clock);
        foreach (Explosion x in e.Explosions.Items) sprites.DrawExplosion(g, x);
        sprites.DrawParticles(g, e.Particles);

        // the prompt above the parked tank
        if (!e.Player.InTank && !e.Tank.Destroyed && !e.Tank.Occupied && !e.Player.Dead && Math.Abs(e.Player.X - e.Tank.X) < 160f)
        {
            float bob = MathF.Sin(e.Clock * 6f) * 4f;
            bool near = Math.Abs(e.Player.X - e.Tank.X) < 80f;
            Txt(g, near ? "PRESS E" : "TANK", fText, Color.FromArgb(255, 255, 240, 120), e.Tank.X, e.Tank.Y - 98f + bob, sfCenter, true);
            g.FillPolygon(B(Color.FromArgb(255, 255, 240, 120)), new[] { new PointF(e.Tank.X - 7f, e.Tank.Y - 84f + bob), new PointF(e.Tank.X + 7f, e.Tank.Y - 84f + bob), new PointF(e.Tank.X, e.Tank.Y - 74f + bob) });
        }
        g.Restore(actors);
        g.Restore(outer);

        if (e.Flash > 0f) g.FillRectangle(B(Color.FromArgb(A(150 * e.Flash / 0.5f), 255, 245, 210)), 0, 0, W, ViewH);
        DrawHud(g, e);
    }

    private void DrawHud(Graphics g, GameEngine e)
    {
        Player pl = e.Player;

        // top-left: score, lives and health
        Panel(g, 8f, 8f, 300f, 74f, 170);
        Txt(g, "1UP", fLabel, Color.FromArgb(255, 255, 200, 70), 22f, 22f, sfLeft, false);
        Txt(g, e.Score.ToString("D7"), fHud, Color.White, 22f, 44f, sfLeft, true);
        Txt(g, "LIVES", fLabel, Color.FromArgb(255, 255, 200, 70), 180f, 22f, sfLeft, false);
        for (int i = 0; i < Math.Min(pl.Lives, 6); i++)
        {
            g.FillEllipse(B(Color.FromArgb(255, 236, 188, 146)), 180f + i * 20f, 34f, 12f, 13f);
            g.FillEllipse(B(Color.FromArgb(255, 244, 208, 84)), 179f + i * 20f, 32f, 14f, 8f);
            g.FillRectangle(B(Color.FromArgb(255, 214, 40, 44)), 179f + i * 20f, 38f, 14f, 3f);
        }
        if (pl.Lives > 6) Txt(g, "+" + (pl.Lives - 6), fSmall, Color.White, 180f + 6 * 20f, 42f, sfLeft, true);
        if (pl.Lives <= 0) Txt(g, "0", fText, Color.FromArgb(255, 255, 110, 100), 180f, 42f, sfLeft, true);
        for (int i = 0; i < GameConfig.MaxHealth; i++)
        {
            bool full = i < pl.Hp;
            Color hc = i >= GameConfig.StartHealth ? Color.FromArgb(255, 90, 160, 255) : Color.FromArgb(255, 235, 60, 60);
            if (full) DrawHeart(g, 180f + i * 20f, 56f, 16f, hc);
            else if (i < GameConfig.StartHealth) DrawHeart(g, 180f + i * 20f, 56f, 16f, Color.FromArgb(110, 90, 40, 40));
        }

        // top-right: weapon, ammunition and grenades
        Panel(g, W - 308f, 8f, 300f, 74f, 170);
        WeaponSystem w = pl.Weapon;
        Txt(g, "WEAPON", fLabel, Color.FromArgb(255, 255, 200, 70), W - 294f, 22f, sfLeft, false);
        Txt(g, w.Name, fText, Color.White, W - 294f, 42f, sfLeft, true);
        string ammo = w.Type == WeaponType.Machine ? "AMMO  \u221E" : "AMMO  " + w.Ammo;
        Txt(g, ammo, fSmall, Color.FromArgb(255, 255, 240, 160), W - 294f, 64f, sfLeft, true);
        Txt(g, "BOMB", fLabel, Color.FromArgb(255, 255, 200, 70), W - 110f, 22f, sfLeft, false);
        Txt(g, "x " + pl.Grenades, fHud, Color.White, W - 110f, 46f, sfLeft, true);
        g.FillEllipse(B(Color.FromArgb(255, 84, 104, 58)), W - 150f, 36f, 16f, 20f);
        g.FillRectangle(B(Color.FromArgb(255, 180, 184, 190)), W - 145f, 31f, 6f, 6f);
        Txt(g, "BEST " + e.Scores.Best.ToString("D7"), fSmall, Color.FromArgb(255, 255, 224, 100), W / 2f, 18f, sfCenter, true);

        // tank durability
        if (pl.InTank)
        {
            Panel(g, W / 2f - 150f, 34f, 300f, 36f, 170);
            Txt(g, "TANK", fLabel, Color.FromArgb(255, 255, 200, 70), W / 2f - 138f, 52f, sfLeft, false);
            for (int i = 0; i < GameConfig.TankMaxHp; i++)
            {
                bool on = i < e.Tank.Hp;
                Color c = e.Tank.Hp <= 4 ? Color.FromArgb(255, 235, 70, 50) : Color.FromArgb(255, 110, 220, 90);
                g.FillRectangle(B(on ? c : Color.FromArgb(120, 70, 70, 60)), W / 2f - 98f + i * 20f, 44f, 16f, 16f);
            }
        }

        // boss health
        if (e.Boss.Active)
        {
            Txt(g, "IRON FORTRESS", fLabel, Color.FromArgb(255, 255, 160, 120), W / 2f, 84f, sfCenter, true);
            float hx = 250f;
            float hw = W - 500f;
            g.FillRectangle(B(Color.FromArgb(200, 12, 10, 8)), hx, 94f, hw, 14f);
            g.FillRectangle(B(e.Boss.HitFlash > 0f ? Color.White : Color.FromArgb(255, 226, 44, 40)), hx + 1f, 95f, (hw - 2f) * e.Boss.HealthFraction, 12f);
            g.DrawRectangle(P(Color.FromArgb(255, 226, 170, 50), 1.5f), hx, 94f, hw, 14f);
            g.DrawLine(P(Color.White, 1.5f), hx + hw * 0.5f, 94f, hx + hw * 0.5f, 108f);
        }

        // notifications and banners
        if (e.NoteTimer > 0f && e.Note.Length > 0)
        {
            float a = Math.Min(1f, e.NoteTimer * 1.5f);
            Txt(g, e.Note, fText, Color.FromArgb(A(255 * a), 255, 244, 150), W / 2f, 132f, sfCenter, true);
        }
        if (e.BannerTimer > 0f && e.Banner.Length > 0)
        {
            float a = Math.Min(1f, e.BannerTimer * 1.5f);
            bool warn = e.Banner == "WARNING!";
            bool blink = !warn || ((int)(e.Clock * 6f) & 1) == 0;
            Color c = warn ? Color.FromArgb(A(255 * a), 255, blink ? 70 : 255, blink ? 60 : 255) : Color.FromArgb(A(255 * a), 255, 255, 255);
            Txt(g, e.Banner, fBanner, c, W / 2f, 210f, sfCenter, true);
            if (warn) Txt(g, "A HEAVILY ARMED WAR MACHINE IS APPROACHING", fText, Color.FromArgb(A(255 * a), 255, 220, 190), W / 2f, 256f, sfCenter, true);
        }
        if (pl.Dead && pl.Lives > 0)
        {
            Txt(g, "GET READY", fMid, Color.FromArgb(220, 255, 255, 255), W / 2f, 250f, sfCenter, true);
        }
    }

    // ------------------------------------------------------------------ menu

    private void DrawMenu(Graphics g, GameEngine e)
    {
        float clock = e.Clock;
        float camX = (float)Math.Round(200f + (clock * 45f) % 2600f);
        GraphicsState outer = g.Save();
        g.SetClip(new Rectangle(0, 0, W, ViewH));
        bg.DrawSky(g, camX, clock);
        bg.DrawWorld(g, menuLevel, camX, clock);

        GraphicsState actors = g.Save();
        g.TranslateTransform(-camX, 0f);

        // an armored car and a tank on the right, soldiers in the middle
        menuJeep.X = camX + 120f;
        menuJeep.Facing = 1;
        menuJeep.TrackPhase = clock * 3f;
        menuJeep.Recoil = ((int)(clock * 6f) & 1) == 0 ? 0.6f : 0f;
        sprites.DrawArmored(g, menuJeep, clock);

        for (int i = 0; i < menuEnemies.Length; i++)
        {
            Enemy en = menuEnemies[i];
            en.X = camX + 640f + i * 70f;
            en.ShootAnim = ((int)(clock * 5f + i) & 3) == 0 ? 0.2f : 0f;
            en.Walk = clock * 3f;
            sprites.DrawEnemy(g, en, clock);
        }
        menuTank.X = camX + 840f;
        menuTank.Y = GameConfig.GroundY;
        menuTank.TrackPhase = clock * 2f;
        menuTank.TurretAngle = -0.2f + MathF.Sin(clock * 1.5f) * 0.12f;
        menuTank.Recoil = (clock % 1.6f) < 0.25f ? 1f - (clock % 1.6f) * 4f : 0f;
        menuTank.Occupied = false;
        sprites.DrawPlayerTank(g, menuTank, clock);

        // the commando running and firing his heavy machine gun
        menuPlayer.X = camX + 330f;
        menuPlayer.Y = GameConfig.GroundY;
        menuPlayer.VX = 150f;
        menuPlayer.RunPhase = clock * 9f;
        menuPlayer.Invuln = 0f;
        menuPlayer.ShootAnim = 0.1f;
        menuPlayer.Weapon.MuzzleTimer = ((int)(clock * 14f) & 1) == 0 ? 0.05f : 0f;
        sprites.DrawPlayer(g, menuPlayer, clock);
        for (int i = 0; i < menuShots.Length; i++)
        {
            Projectile p = menuShots[i];
            p.X = camX + 366f + ((clock * 700f + i * 70f) % 520f);
            p.Y = GameConfig.GroundY - 28f;
            sprites.DrawProjectile(g, p);
        }
        float ea = clock % 3.4f;
        if (ea < menuExp.Duration)
        {
            menuExp.X = camX + 610f;
            menuExp.Y = GameConfig.GroundY - 60f;
            menuExp.Age = ea;
            sprites.DrawExplosion(g, menuExp);
        }
        g.Restore(actors);
        g.Restore(outer);

        // the title on riveted steel plates
        DrawPlates(g);
        g.DrawPath(P(Color.FromArgb(255, 70, 26, 8), 16f), titleMetal);
        g.DrawPath(P(Color.FromArgb(255, 70, 26, 8), 18f), titleSlug);
        g.FillPath(titleFill, titleMetal);
        g.FillPath(titleFill, titleSlug);
        g.DrawPath(P(Color.FromArgb(150, 255, 245, 190), 2f), titleMetal);
        g.DrawPath(P(Color.FromArgb(150, 255, 245, 190), 2f), titleSlug);
        Txt(g, "RUN AND GUN", fSub, Color.White, W / 2f, 288f, sfCenter, true);

        Button(g, PlayButton, "PLAY  [ENTER]", true, clock);
        Txt(g, "BEST SCORE  " + e.Scores.Best.ToString("D7"), fText, Color.FromArgb(255, 255, 224, 100), W / 2f, 398f, sfCenter, true);
        Txt(g, "A / D or \u2190 \u2192 - run      W / \u2191 - aim up      S / \u2193 - crouch / aim down      SPACE - jump", fSmall, Color.White, W / 2f, 428f, sfCenter, true);
        Txt(g, "J / CTRL - shoot      K / X - throw a grenade      E - enter / exit the tank      ESC / P - pause", fSmall, Color.FromArgb(255, 250, 240, 200), W / 2f, 450f, sfCenter, true);
        Txt(g, "Collect H / S / R weapon crates, grenades, health and 1UP.  Reach the fortress and destroy the Iron Fortress!", fSmall, Color.FromArgb(255, 250, 240, 200), W / 2f, 472f, sfCenter, true);
    }

    private void DrawPlates(Graphics g)
    {
        for (int side = -1; side <= 1; side += 2)
        {
            for (int k = 0; k < 3; k++)
            {
                float y = 60f + k * 34f;
                float x0 = W / 2f + side * 80f;
                float x1 = W / 2f + side * (400f - k * 22f);
                PointF[] plate =
                {
                    new PointF(x0, y), new PointF(x1, y + 18f), new PointF(x1 - side * 8f, y + 40f), new PointF(x0, y + 28f)
                };
                int shade = 188 - k * 24;
                g.FillPolygon(B(Color.FromArgb(255, shade, shade + 4, shade + 12)), plate);
                g.DrawPolygon(P(Color.FromArgb(255, 40, 44, 52), 2.5f), plate);
                for (int r = 0; r < 4; r++)
                    g.FillEllipse(B(Color.FromArgb(255, 70, 74, 84)), x0 + side * (60f + r * 70f) - 3f, y + 14f + r * 3f, 6f, 6f);
            }
        }
    }

    // ------------------------------------------------------------------ overlays

    private void DrawPause(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(170, 14, 10, 4)), 0, 0, W, ViewH);
        Txt(g, "PAUSED", fBig, Color.White, W / 2f, 140f, sfCenter, true);
        Button(g, ResumeButton, "RESUME  [ESC]", true, e.Clock);
        Button(g, PauseRestartButton, "RESTART  [R]", false, e.Clock);
        Button(g, PauseMenuButton, "MAIN MENU  [M]", false, e.Clock);
    }

    private void DrawEnd(Graphics g, GameEngine e, bool victory)
    {
        g.FillRectangle(B(Color.FromArgb(180, 14, 10, 4)), 0, 0, W, ViewH);
        Panel(g, 180f, 50f, 600f, 460f, 244);
        if (victory)
        {
            Txt(g, "MISSION COMPLETED!", fBig, Color.FromArgb(255, 255, 220, 80), W / 2f, 100f, sfCenter, true);
            Txt(g, "BOSS DEFEATED", fMid, Color.FromArgb(255, 120, 255, 160), W / 2f, 150f, sfCenter, true);
        }
        else
        {
            Txt(g, "GAME OVER", fBig, Color.FromArgb(255, 255, 90, 80), W / 2f, 110f, sfCenter, true);
        }
        float y0 = victory ? 190f : 170f;
        Txt(g, "FINAL SCORE", fLabel, Color.FromArgb(255, 255, 200, 70), W / 2f, y0, sfCenter, false);
        Txt(g, e.Score.ToString("D7"), fBig, Color.White, W / 2f, y0 + 36f, sfCenter, true);
        if (e.NewRecord) Txt(g, "NEW RECORD!", fText, Color.FromArgb(255, 255, 230, 90), W / 2f, y0 + 78f, sfCenter, true);
        float y = y0 + 108f;
        Txt(g, "BEST SCORE  " + e.Scores.Best.ToString("D7"), fText, Color.FromArgb(255, 255, 224, 100), W / 2f, y, sfCenter, true);
        Txt(g, "ENEMIES DEFEATED  " + e.Kills, fText, Color.White, W / 2f, y + 30f, sfCenter, true);
        if (victory) Txt(g, "COMPLETION TIME  " + FormatTime(e.PlayTime), fText, Color.White, W / 2f, y + 60f, sfCenter, true);
        Button(g, EndRestartButton, "RESTART  [R]", true, e.Clock);
        Button(g, EndMenuButton, "MAIN MENU  [M]", false, e.Clock);
    }

    private void DrawFooter(Graphics g)
    {
        Rectangle r = new Rectangle(0, GameConfig.LogicalH - GameConfig.FooterH, W, GameConfig.FooterH);
        g.FillRectangle(B(Color.FromArgb(255, 22, 18, 10)), r);
        g.FillRectangle(B(Color.FromArgb(255, 226, 170, 50)), 0, r.Y, W, 2);
        g.DrawString(FooterText, fFooter, B(Color.FromArgb(255, 245, 236, 210)),
            new RectangleF(0f, r.Y + 3f, W, r.Height - 3f), sfCenter);
    }
}
