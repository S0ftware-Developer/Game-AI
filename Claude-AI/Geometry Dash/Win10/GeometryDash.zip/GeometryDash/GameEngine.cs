namespace GeometryDash;

public enum GameState { Menu, Playing, Paused, Victory }

public struct Particle
{
    public float X, Y, VX, VY, Gravity, Size, Rot, Spin;
    public float Life, MaxLife;
    public Color Color;
}

/// <summary>Game rules, state machine, progress and effects. Advanced on a fixed 1/120 s step.</summary>
public sealed class GameEngine
{
    public const float Dt = 1f / 120f;
    public const float DeathDelay = 0.55f;
    public const float CompleteDelay = 1.5f;

    public GameState State = GameState.Menu;
    public int LevelIndex;
    public Level Level;
    public readonly Player Player = new Player();
    public readonly List<Particle> Particles = new List<Particle>();

    public float Clock;
    public int Attempt = 1;
    public int TotalDeaths;
    public int Unlocked;
    public int MenuSelect;
    public readonly double[] Best = new double[LevelLibrary.All.Length];
    public bool Completing;
    public float CompleteTimer;
    public float DeathTimer;
    public string DeathReason = "";
    public float FlashTimer;

    private readonly Random rng = new Random();
    private bool jumpRequest;

    public int LevelCount { get { return LevelLibrary.All.Length; } }

    /// <summary>Distance covered as a fraction of the level (0..1), not elapsed time.</summary>
    public double Progress
    {
        get { return Math.Max(0.0, Math.Min(1.0, Player.X / Level.FinishX)); }
    }

    public GameEngine()
    {
        foreach (LevelDef def in LevelLibrary.All)
        {
            Level.Load(def);        // validates every level before the game starts
        }
        Level = Level.Load(LevelLibrary.All[0]);
        Player.Reset();
    }

    // ------------------------------------------------------------------ flow

    public void StartGame(int index)
    {
        TotalDeaths = 0;
        LoadLevel(Math.Max(0, Math.Min(LevelCount - 1, index)));
        State = GameState.Playing;
        Sfx.Play(SfxId.Start);
    }

    private void LoadLevel(int index)
    {
        LevelIndex = index;
        Level = Level.Load(LevelLibrary.All[index]);
        Attempt = 1;
        Particles.Clear();
        Respawn(false);
    }

    private void Respawn(bool countAttempt)
    {
        if (countAttempt) Attempt++;
        Player.Reset();
        DeathTimer = 0f;
        Completing = false;
        CompleteTimer = 0f;
        FlashTimer = 0f;
        jumpRequest = false;
    }

    public void RestartLevel()
    {
        Particles.Clear();
        Respawn(true);
    }

    public void AutoPause()
    {
        jumpRequest = false;
        if (State == GameState.Playing) State = GameState.Paused;
    }

    public void RequestJump()
    {
        if (State == GameState.Playing) jumpRequest = true;
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                if (State == GameState.Menu) StartGame(MenuSelect);
                else if (State == GameState.Paused) State = GameState.Playing;
                else if (State == GameState.Victory) State = GameState.Menu;
                break;
            case Keys.Escape:
                if (State == GameState.Playing) State = GameState.Paused;
                else if (State == GameState.Paused) State = GameState.Playing;
                else if (State == GameState.Victory) State = GameState.Menu;
                break;
            case Keys.M:
                if (State == GameState.Paused) State = GameState.Menu;
                break;
            case Keys.R:
                if (State == GameState.Playing || State == GameState.Paused)
                {
                    RestartLevel();
                    State = GameState.Playing;
                }
                else if (State == GameState.Victory)
                {
                    StartGame(0);
                }
                break;
            case Keys.Left:
            case Keys.A:
                if (State == GameState.Menu)
                {
                    MenuSelect = Math.Max(0, MenuSelect - 1);
                    Sfx.Play(SfxId.Click);
                }
                break;
            case Keys.Right:
            case Keys.D:
                if (State == GameState.Menu)
                {
                    MenuSelect = Math.Min(Unlocked, MenuSelect + 1);
                    Sfx.Play(SfxId.Click);
                }
                break;
            case Keys.Space:
            case Keys.Up:
                if (State == GameState.Playing) jumpRequest = true;
                else if (State == GameState.Menu) StartGame(MenuSelect);
                break;
            case Keys.N:
                Sfx.Muted = !Sfx.Muted;
                break;
        }
    }

    // ------------------------------------------------------------------ update

    public void Update()
    {
        Clock += Dt;
        if (State != GameState.Playing)
        {
            jumpRequest = false;
            if (State != GameState.Paused) UpdateParticles(Dt);
            return;
        }

        UpdateParticles(Dt);
        if (FlashTimer > 0f) FlashTimer -= Dt;

        if (Completing)
        {
            CompleteTimer += Dt;
            jumpRequest = false;
            if (CompleteTimer >= CompleteDelay) AdvanceLevel();
            return;
        }

        if (Player.Dead)
        {
            DeathTimer += Dt;
            jumpRequest = false;
            if (DeathTimer >= DeathDelay) Respawn(true);
            return;
        }

        bool jump = jumpRequest;
        jumpRequest = false;
        Player.Update(Level, jump);
        if (Player.EvJump) Sfx.Play(SfxId.Jump);
        if (Player.EvLand) Dust();

        if (Player.Dead) OnDeath();
        else if (Player.Finished) OnComplete();
    }

    private void OnDeath()
    {
        DeathReason = Player.DeathReason;
        TotalDeaths++;
        DeathTimer = 0f;
        FlashTimer = 0.35f;
        Best[LevelIndex] = Math.Max(Best[LevelIndex], Progress);
        Sfx.Play(SfxId.Death);
        float cx = (float)Player.X;
        float cy = (float)Math.Max(Player.Y, -1.0) + 0.5f;
        for (int i = 0; i < 26; i++)
        {
            double a = rng.NextDouble() * Math.PI * 2.0;
            float sp = (float)(rng.NextDouble() * 7.0 + 2.0);
            Particle p = new Particle();
            p.X = cx;
            p.Y = cy;
            p.VX = (float)Math.Cos(a) * sp;
            p.VY = (float)Math.Sin(a) * sp + 3f;
            p.Gravity = -26f;
            p.Size = 0.1f + (float)rng.NextDouble() * 0.2f;
            p.Rot = (float)(rng.NextDouble() * 6.28);
            p.Spin = (float)(rng.NextDouble() * 20.0 - 10.0);
            p.MaxLife = 0.5f + (float)rng.NextDouble() * 0.4f;
            p.Life = p.MaxLife;
            p.Color = (i % 3 == 0) ? Color.FromArgb(255, 210, 60) : ((i % 3 == 1) ? Color.FromArgb(255, 140, 20) : Color.White);
            Particles.Add(p);
        }
    }

    private void OnComplete()
    {
        Completing = true;
        CompleteTimer = 0f;
        Best[LevelIndex] = 1.0;
        Sfx.Play(SfxId.Complete);
        for (int i = 0; i < 50; i++)
        {
            double a = rng.NextDouble() * Math.PI * 2.0;
            float sp = (float)(rng.NextDouble() * 8.0 + 2.0);
            Particle p = new Particle();
            p.X = (float)Player.X;
            p.Y = (float)Player.Y + 0.5f;
            p.VX = (float)Math.Cos(a) * sp;
            p.VY = (float)Math.Sin(a) * sp + 4f;
            p.Gravity = -12f;
            p.Size = 0.08f + (float)rng.NextDouble() * 0.16f;
            p.Rot = (float)(rng.NextDouble() * 6.28);
            p.Spin = (float)(rng.NextDouble() * 12.0 - 6.0);
            p.MaxLife = 0.8f + (float)rng.NextDouble() * 0.7f;
            p.Life = p.MaxLife;
            p.Color = (i % 2 == 0) ? Color.FromArgb(120, 255, 120) : Color.White;
            Particles.Add(p);
        }
    }

    private void AdvanceLevel()
    {
        Unlocked = Math.Max(Unlocked, Math.Min(LevelCount - 1, LevelIndex + 1));
        if (LevelIndex + 1 >= LevelCount)
        {
            State = GameState.Victory;
            Completing = false;
            return;
        }
        MenuSelect = Math.Min(Unlocked, LevelIndex + 1);
        LoadLevel(LevelIndex + 1);
    }

    private void Dust()
    {
        for (int i = 0; i < 4; i++)
        {
            Particle p = new Particle();
            p.X = (float)Player.X + (float)(rng.NextDouble() * 0.6 - 0.3);
            p.Y = (float)Player.Y + 0.05f;
            p.VX = -(float)(rng.NextDouble() * 3.0 + 1.0);
            p.VY = (float)(rng.NextDouble() * 2.0 + 0.5);
            p.Gravity = -6f;
            p.Size = 0.06f + (float)rng.NextDouble() * 0.06f;
            p.MaxLife = 0.25f + (float)rng.NextDouble() * 0.15f;
            p.Life = p.MaxLife;
            p.Color = Color.FromArgb(200, 230, 255);
            Particles.Add(p);
        }
    }

    private void UpdateParticles(float dt)
    {
        for (int i = Particles.Count - 1; i >= 0; i--)
        {
            Particle p = Particles[i];
            p.Life -= dt;
            if (p.Life <= 0f)
            {
                Particles.RemoveAt(i);
                continue;
            }
            p.VY += p.Gravity * dt;
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            p.Rot += p.Spin * dt;
            Particles[i] = p;
        }
    }
}
