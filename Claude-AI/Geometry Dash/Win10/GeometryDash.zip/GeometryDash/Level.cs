namespace GeometryDash;

public static class Cfg
{
    public const int Unit = 40;               // pixels per block
    public const int LogicalW = 960;
    public const int LogicalH = 640;
    public const int HudH = 44;
    public const int FooterH = 32;
    public const int ViewH = LogicalH - HudH - FooterH;   // 564
    public const int GroundY = HudH + 440;                // screen y of the ground surface
    public const int PlayerScreenX = 240;
}

public sealed class BlockDef
{
    public readonly double X0, X1, Y0, Y1;
    public BlockDef(double x0, double x1, double y0, double y1)
    {
        X0 = x0; X1 = x1; Y0 = y0; Y1 = y1;
    }
}

public sealed class SpikeDef
{
    public readonly double X, Y;
    public SpikeDef(double x, double y)
    {
        X = x; Y = y;
    }
}

public sealed class SawDef
{
    public readonly double X, Y1, Y2, Period, Phase;
    public SawDef(double x, double y1, double y2, double period, double phase)
    {
        X = x; Y1 = y1; Y2 = y2; Period = period; Phase = phase;
    }
}

public sealed class GapDef
{
    public readonly double X0, X1;
    public GapDef(double x0, double x1)
    {
        X0 = x0; X1 = x1;
    }
}

public sealed class LevelDef
{
    public readonly string Name;
    public readonly double Speed, Bpm, FinishX, Hue;
    public readonly BlockDef[] Blocks;
    public readonly SpikeDef[] Spikes;
    public readonly SawDef[] Saws;
    public readonly GapDef[] Gaps;

    public LevelDef(string name, double speed, double bpm, double finishX, double hue,
        BlockDef[] blocks, SpikeDef[] spikes, SawDef[] saws, GapDef[] gaps)
    {
        Name = name; Speed = speed; Bpm = bpm; FinishX = finishX; Hue = hue;
        Blocks = blocks; Spikes = spikes; Saws = saws; Gaps = gaps;
    }
}

/// <summary>
/// All positions are in blocks. x grows to the right, y is the height above the ground surface.
/// A block is a solid rectangle (the player may land on top; touching a side or underside kills).
/// A spike sits on a surface at (x, y). A saw hangs at x and moves between heights y1 and y2.
/// A gap is a hole in the ground between x0 and x1.
/// </summary>
public static class LevelLibrary
{
    public static readonly LevelDef[] All =
    {
        new LevelDef("Первый прыжок", 7.0, 120.0, 160.0, 215.0,
        new[]
        {
            new BlockDef(84.0, 86.0, 0.0, 1.0)
        },
        new[]
        {
            new SpikeDef(18.0, 0.0),
            new SpikeDef(34.0, 0.0),
            new SpikeDef(50.0, 0.0),
            new SpikeDef(98.0, 0.0),
            new SpikeDef(110.0, 0.0),
            new SpikeDef(120.0, 0.0),
            new SpikeDef(146.0, 0.0)
        },
        new SawDef[0],
        new[]
        {
            new GapDef(66.0, 69.0),
            new GapDef(132.0, 135.0)
        }),
        new LevelDef("Ступеньки", 7.5, 124.0, 190.0, 190.0,
        new[]
        {
            new BlockDef(32.0, 34.0, 0.0, 1.0),
            new BlockDef(62.0, 64.0, 0.0, 1.0),
            new BlockDef(64.0, 66.0, 0.0, 2.0),
            new BlockDef(110.0, 113.0, 0.0, 1.0),
            new BlockDef(150.0, 152.0, 0.0, 2.0)
        },
        new[]
        {
            new SpikeDef(18.0, 0.0),
            new SpikeDef(48.0, 0.0),
            new SpikeDef(80.0, 0.0),
            new SpikeDef(124.0, 0.0),
            new SpikeDef(136.0, 0.0),
            new SpikeDef(178.0, 0.0)
        },
        new SawDef[0],
        new[]
        {
            new GapDef(94.0, 97.0),
            new GapDef(164.0, 168.0)
        }),
        new LevelDef("Двойные шипы", 8.0, 128.0, 210.0, 160.0,
        new[]
        {
            new BlockDef(34.0, 37.0, 0.0, 1.0),
            new BlockDef(96.0, 98.0, 0.0, 2.0),
            new BlockDef(146.0, 149.0, 0.0, 1.0)
        },
        new[]
        {
            new SpikeDef(18.0, 0.0),
            new SpikeDef(19.0, 0.0),
            new SpikeDef(42.0, 0.0),
            new SpikeDef(56.0, 0.0),
            new SpikeDef(57.0, 0.0),
            new SpikeDef(82.0, 0.0),
            new SpikeDef(108.0, 0.0),
            new SpikeDef(109.0, 0.0),
            new SpikeDef(122.0, 0.0),
            new SpikeDef(130.0, 0.0),
            new SpikeDef(131.0, 0.0),
            new SpikeDef(160.0, 0.0),
            new SpikeDef(161.0, 0.0),
            new SpikeDef(186.0, 0.0),
            new SpikeDef(187.0, 0.0),
            new SpikeDef(198.0, 0.0)
        },
        new SawDef[0],
        new[]
        {
            new GapDef(70.0, 73.0),
            new GapDef(174.0, 177.0)
        }),
        new LevelDef("Тройной удар", 8.0, 132.0, 230.0, 270.0,
        new[]
        {
            new BlockDef(36.0, 38.0, 0.0, 1.0),
            new BlockDef(86.0, 88.0, 0.0, 2.0),
            new BlockDef(124.0, 127.0, 0.0, 1.0),
            new BlockDef(138.0, 140.0, 0.0, 2.0)
        },
        new[]
        {
            new SpikeDef(18.0, 0.0),
            new SpikeDef(19.0, 0.0),
            new SpikeDef(20.0, 0.0),
            new SpikeDef(44.0, 0.0),
            new SpikeDef(45.0, 0.0),
            new SpikeDef(58.0, 0.0),
            new SpikeDef(59.0, 0.0),
            new SpikeDef(60.0, 0.0),
            new SpikeDef(100.0, 0.0),
            new SpikeDef(101.0, 0.0),
            new SpikeDef(108.0, 0.0),
            new SpikeDef(109.0, 0.0),
            new SpikeDef(110.0, 0.0),
            new SpikeDef(131.0, 0.0),
            new SpikeDef(132.0, 0.0),
            new SpikeDef(152.0, 0.0),
            new SpikeDef(153.0, 0.0),
            new SpikeDef(154.0, 0.0),
            new SpikeDef(178.0, 0.0),
            new SpikeDef(179.0, 0.0),
            new SpikeDef(190.0, 0.0),
            new SpikeDef(191.0, 0.0),
            new SpikeDef(192.0, 0.0),
            new SpikeDef(202.0, 0.0),
            new SpikeDef(203.0, 0.0),
            new SpikeDef(212.0, 0.0)
        },
        new SawDef[0],
        new[]
        {
            new GapDef(74.0, 77.0),
            new GapDef(166.0, 169.0)
        }),
        new LevelDef("Точный тайминг", 8.5, 136.0, 250.0, 300.0,
        new[]
        {
            new BlockDef(74.0, 76.0, 0.0, 1.0),
            new BlockDef(88.0, 90.0, 0.0, 2.0),
            new BlockDef(148.0, 151.0, 0.0, 1.0),
            new BlockDef(160.0, 162.0, 0.0, 2.0),
            new BlockDef(214.0, 216.0, 0.0, 1.0)
        },
        new[]
        {
            new SpikeDef(18.0, 0.0),
            new SpikeDef(19.0, 0.0),
            new SpikeDef(26.0, 0.0),
            new SpikeDef(34.0, 0.0),
            new SpikeDef(35.0, 0.0),
            new SpikeDef(60.0, 0.0),
            new SpikeDef(61.0, 0.0),
            new SpikeDef(80.0, 0.0),
            new SpikeDef(81.0, 0.0),
            new SpikeDef(102.0, 0.0),
            new SpikeDef(103.0, 0.0),
            new SpikeDef(104.0, 0.0),
            new SpikeDef(126.0, 0.0),
            new SpikeDef(134.0, 0.0),
            new SpikeDef(154.0, 0.0),
            new SpikeDef(166.0, 0.0),
            new SpikeDef(167.0, 0.0),
            new SpikeDef(192.0, 0.0),
            new SpikeDef(193.0, 0.0),
            new SpikeDef(200.0, 0.0),
            new SpikeDef(201.0, 0.0),
            new SpikeDef(202.0, 0.0),
            new SpikeDef(220.0, 0.0),
            new SpikeDef(228.0, 0.0),
            new SpikeDef(229.0, 0.0),
            new SpikeDef(238.0, 0.0)
        },
        new SawDef[0],
        new[]
        {
            new GapDef(48.0, 51.0),
            new GapDef(116.0, 119.0),
            new GapDef(180.0, 184.0)
        }),
        new LevelDef("Платформы", 8.5, 140.0, 260.0, 340.0,
        new[]
        {
            new BlockDef(18.0, 24.0, 0.0, 2.0),
            new BlockDef(56.0, 61.0, 0.0, 1.0),
            new BlockDef(86.0, 89.0, 0.0, 2.0),
            new BlockDef(114.0, 118.0, 0.0, 2.0),
            new BlockDef(150.0, 152.0, 0.0, 1.0),
            new BlockDef(152.0, 154.0, 0.0, 2.0),
            new BlockDef(198.0, 203.0, 0.0, 2.0)
        },
        new[]
        {
            new SpikeDef(22.0, 2.0),
            new SpikeDef(34.0, 0.0),
            new SpikeDef(35.0, 0.0),
            new SpikeDef(59.0, 1.0),
            new SpikeDef(72.0, 0.0),
            new SpikeDef(73.0, 0.0),
            new SpikeDef(74.0, 0.0),
            new SpikeDef(92.0, 0.0),
            new SpikeDef(93.0, 0.0),
            new SpikeDef(118.0, 0.0),
            new SpikeDef(119.0, 0.0),
            new SpikeDef(130.0, 0.0),
            new SpikeDef(138.0, 0.0),
            new SpikeDef(139.0, 0.0),
            new SpikeDef(158.0, 0.0),
            new SpikeDef(159.0, 0.0),
            new SpikeDef(184.0, 0.0),
            new SpikeDef(185.0, 0.0),
            new SpikeDef(186.0, 0.0),
            new SpikeDef(202.0, 2.0),
            new SpikeDef(212.0, 0.0),
            new SpikeDef(213.0, 0.0),
            new SpikeDef(224.0, 0.0),
            new SpikeDef(232.0, 0.0),
            new SpikeDef(233.0, 0.0),
            new SpikeDef(244.0, 0.0)
        },
        new SawDef[0],
        new[]
        {
            new GapDef(46.0, 49.0),
            new GapDef(104.0, 107.0),
            new GapDef(172.0, 176.0)
        }),
        new LevelDef("Пилы", 9.0, 144.0, 280.0, 235.0,
        new[]
        {
            new BlockDef(96.0, 99.0, 0.0, 2.0),
            new BlockDef(190.0, 192.0, 0.0, 1.0),
            new BlockDef(202.0, 204.0, 0.0, 2.0)
        },
        new[]
        {
            new SpikeDef(18.0, 0.0),
            new SpikeDef(19.0, 0.0),
            new SpikeDef(48.0, 0.0),
            new SpikeDef(49.0, 0.0),
            new SpikeDef(50.0, 0.0),
            new SpikeDef(104.0, 0.0),
            new SpikeDef(105.0, 0.0),
            new SpikeDef(118.0, 0.0),
            new SpikeDef(125.0, 0.0),
            new SpikeDef(126.0, 0.0),
            new SpikeDef(132.0, 0.0),
            new SpikeDef(176.0, 0.0),
            new SpikeDef(177.0, 0.0),
            new SpikeDef(196.0, 0.0),
            new SpikeDef(197.0, 0.0),
            new SpikeDef(232.0, 0.0),
            new SpikeDef(233.0, 0.0),
            new SpikeDef(234.0, 0.0),
            new SpikeDef(258.0, 0.0),
            new SpikeDef(259.0, 0.0),
            new SpikeDef(268.0, 0.0)
        },
        new[]
        {
            new SawDef(34.5, 1.2, 3.4, 2.4, 0.0),
            new SawDef(80.5, 1.0, 3.2, 2.2, 0.0),
            new SawDef(150.5, 1.2, 3.4, 2.0, 0.3),
            new SawDef(218.5, 1.0, 3.3, 2.2, 0.6)
        },
        new[]
        {
            new GapDef(62.0, 65.0),
            new GapDef(164.0, 167.0),
            new GapDef(246.0, 249.0)
        }),
        new LevelDef("Узкие посадки", 9.0, 148.0, 300.0, 12.0,
        new[]
        {
            new BlockDef(32.0, 34.0, 0.0, 2.0),
            new BlockDef(62.0, 64.0, 0.0, 1.0),
            new BlockDef(110.0, 112.0, 0.0, 2.0),
            new BlockDef(125.0, 128.0, 0.0, 2.0),
            new BlockDef(174.0, 176.0, 0.0, 1.0),
            new BlockDef(184.0, 186.0, 0.0, 2.0),
            new BlockDef(262.0, 264.0, 0.0, 1.0)
        },
        new[]
        {
            new SpikeDef(18.0, 0.0),
            new SpikeDef(19.0, 0.0),
            new SpikeDef(40.0, 0.0),
            new SpikeDef(41.0, 0.0),
            new SpikeDef(42.0, 0.0),
            new SpikeDef(96.0, 0.0),
            new SpikeDef(97.0, 0.0),
            new SpikeDef(117.0, 0.0),
            new SpikeDef(118.0, 0.0),
            new SpikeDef(138.0, 0.0),
            new SpikeDef(139.0, 0.0),
            new SpikeDef(140.0, 0.0),
            new SpikeDef(180.0, 0.0),
            new SpikeDef(198.0, 0.0),
            new SpikeDef(199.0, 0.0),
            new SpikeDef(226.0, 0.0),
            new SpikeDef(227.0, 0.0),
            new SpikeDef(228.0, 0.0),
            new SpikeDef(250.0, 0.0),
            new SpikeDef(251.0, 0.0),
            new SpikeDef(268.0, 0.0),
            new SpikeDef(269.0, 0.0),
            new SpikeDef(280.0, 0.0)
        },
        new[]
        {
            new SawDef(84.5, 1.1, 3.3, 2.1, 0.0),
            new SawDef(154.5, 1.0, 3.2, 2.0, 0.5),
            new SawDef(214.5, 1.2, 3.4, 2.2, 0.2)
        },
        new[]
        {
            new GapDef(54.0, 57.0),
            new GapDef(67.0, 70.0),
            new GapDef(166.0, 169.0),
            new GapDef(240.0, 243.0)
        }),
        new LevelDef("Быстрый ритм", 9.5, 152.0, 330.0, 175.0,
        new[]
        {
            new BlockDef(58.0, 61.0, 0.0, 1.0),
            new BlockDef(110.0, 112.0, 0.0, 2.0),
            new BlockDef(184.0, 187.0, 0.0, 1.0),
            new BlockDef(248.0, 250.0, 0.0, 2.0)
        },
        new[]
        {
            new SpikeDef(18.0, 0.0),
            new SpikeDef(19.0, 0.0),
            new SpikeDef(26.0, 0.0),
            new SpikeDef(34.0, 0.0),
            new SpikeDef(35.0, 0.0),
            new SpikeDef(64.0, 0.0),
            new SpikeDef(65.0, 0.0),
            new SpikeDef(94.0, 0.0),
            new SpikeDef(95.0, 0.0),
            new SpikeDef(96.0, 0.0),
            new SpikeDef(116.0, 0.0),
            new SpikeDef(117.0, 0.0),
            new SpikeDef(136.0, 0.0),
            new SpikeDef(143.0, 0.0),
            new SpikeDef(144.0, 0.0),
            new SpikeDef(150.0, 0.0),
            new SpikeDef(190.0, 0.0),
            new SpikeDef(191.0, 0.0),
            new SpikeDef(216.0, 0.0),
            new SpikeDef(217.0, 0.0),
            new SpikeDef(218.0, 0.0),
            new SpikeDef(254.0, 0.0),
            new SpikeDef(255.0, 0.0),
            new SpikeDef(276.0, 0.0),
            new SpikeDef(277.0, 0.0),
            new SpikeDef(282.0, 0.0),
            new SpikeDef(288.0, 0.0),
            new SpikeDef(289.0, 0.0),
            new SpikeDef(296.0, 0.0),
            new SpikeDef(297.0, 0.0),
            new SpikeDef(298.0, 0.0),
            new SpikeDef(309.0, 0.0),
            new SpikeDef(310.0, 0.0),
            new SpikeDef(320.0, 0.0)
        },
        new[]
        {
            new SawDef(80.5, 1.1, 3.3, 1.9, 0.0),
            new SawDef(168.5, 1.0, 3.2, 1.8, 0.4),
            new SawDef(232.5, 1.2, 3.4, 2.0, 0.7)
        },
        new[]
        {
            new GapDef(48.0, 51.0),
            new GapDef(124.0, 127.0),
            new GapDef(204.0, 208.0),
            new GapDef(264.0, 267.0)
        }),
        new LevelDef("Ритм мастера", 10.0, 160.0, 412.0, 285.0,
        new[]
        {
            new BlockDef(60.0, 62.0, 0.0, 2.0),
            new BlockDef(112.0, 115.0, 0.0, 1.0),
            new BlockDef(124.0, 126.0, 0.0, 2.0),
            new BlockDef(224.0, 226.0, 0.0, 2.0),
            new BlockDef(236.0, 238.0, 0.0, 1.0),
            new BlockDef(328.0, 330.0, 0.0, 2.0)
        },
        new[]
        {
            new SpikeDef(18.0, 0.0),
            new SpikeDef(19.0, 0.0),
            new SpikeDef(26.0, 0.0),
            new SpikeDef(27.0, 0.0),
            new SpikeDef(28.0, 0.0),
            new SpikeDef(36.0, 0.0),
            new SpikeDef(37.0, 0.0),
            new SpikeDef(65.0, 0.0),
            new SpikeDef(66.0, 0.0),
            new SpikeDef(96.0, 0.0),
            new SpikeDef(97.0, 0.0),
            new SpikeDef(98.0, 0.0),
            new SpikeDef(118.0, 0.0),
            new SpikeDef(119.0, 0.0),
            new SpikeDef(142.0, 0.0),
            new SpikeDef(149.0, 0.0),
            new SpikeDef(150.0, 0.0),
            new SpikeDef(156.0, 0.0),
            new SpikeDef(163.0, 0.0),
            new SpikeDef(164.0, 0.0),
            new SpikeDef(208.0, 0.0),
            new SpikeDef(209.0, 0.0),
            new SpikeDef(210.0, 0.0),
            new SpikeDef(230.0, 0.0),
            new SpikeDef(231.0, 0.0),
            new SpikeDef(242.0, 0.0),
            new SpikeDef(243.0, 0.0),
            new SpikeDef(272.0, 0.0),
            new SpikeDef(273.0, 0.0),
            new SpikeDef(274.0, 0.0),
            new SpikeDef(298.0, 0.0),
            new SpikeDef(299.0, 0.0),
            new SpikeDef(306.0, 0.0),
            new SpikeDef(314.0, 0.0),
            new SpikeDef(315.0, 0.0),
            new SpikeDef(316.0, 0.0),
            new SpikeDef(334.0, 0.0),
            new SpikeDef(335.0, 0.0),
            new SpikeDef(376.0, 0.0),
            new SpikeDef(377.0, 0.0),
            new SpikeDef(382.0, 0.0),
            new SpikeDef(388.0, 0.0),
            new SpikeDef(389.0, 0.0),
            new SpikeDef(394.0, 0.0),
            new SpikeDef(400.0, 0.0)
        },
        new[]
        {
            new SawDef(82.5, 1.0, 3.3, 1.8, 0.0),
            new SawDef(182.5, 1.1, 3.4, 1.7, 0.3),
            new SawDef(258.5, 1.0, 3.3, 1.8, 0.6),
            new SawDef(350.5, 1.2, 3.4, 1.7, 0.1)
        },
        new[]
        {
            new GapDef(50.0, 53.0),
            new GapDef(130.0, 133.0),
            new GapDef(196.0, 199.0),
            new GapDef(286.0, 290.0),
            new GapDef(364.0, 367.0)
        })
    };
}

/// <summary>A solid rectangle used for collisions. Ground segments are blocks too (with a small horizontal shrink).</summary>
public sealed class Block
{
    public readonly double X0, X1, Y0, Y1, Shrink;
    public readonly bool IsFloor;
    public Block(double x0, double x1, double y0, double y1, double shrink, bool isFloor)
    {
        X0 = x0; X1 = x1; Y0 = y0; Y1 = y1; Shrink = shrink; IsFloor = isFloor;
    }
}

public sealed class Spike
{
    public readonly double X, Y;
    public Spike(double x, double y)
    {
        X = x; Y = y;
    }
}

public sealed class Saw
{
    public readonly double X, Y1, Y2, Period, Phase;
    public Saw(SawDef d)
    {
        X = d.X; Y1 = d.Y1; Y2 = d.Y2; Period = d.Period; Phase = d.Phase;
    }

    /// <summary>Height of the saw centre after the given number of simulation steps (smooth, predictable ping-pong).</summary>
    public double CenterY(long step)
    {
        double t = step * Player.Dt;
        double u = (t / Period + Phase) % 1.0;
        if (u < 0.0) u += 1.0;
        double tri = u < 0.5 ? u * 2.0 : 2.0 - u * 2.0;
        double e = tri * tri * (3.0 - 2.0 * tri);
        return Y1 + (Y2 - Y1) * e;
    }
}

public sealed class Level
{
    public const double SawRadius = 0.42;

    public readonly string Name;
    public readonly double Speed, Bpm, FinishX, Hue;
    public readonly List<Block> Blocks = new List<Block>();
    public readonly List<Block> Floors = new List<Block>();
    public readonly List<Spike> Spikes = new List<Spike>();
    public readonly List<Saw> Saws = new List<Saw>();
    public readonly List<GapDef> Gaps = new List<GapDef>();

    private Level(LevelDef d)
    {
        Name = d.Name;
        Speed = d.Speed;
        Bpm = d.Bpm;
        FinishX = d.FinishX;
        Hue = d.Hue;
    }

    public static Level Load(LevelDef d)
    {
        if (d.Speed < 3.0 || d.Speed > 20.0) throw new InvalidDataException(d.Name + ": unreasonable speed.");
        if (d.FinishX < 40.0) throw new InvalidDataException(d.Name + ": the level is too short.");
        Level lv = new Level(d);

        // ground segments between the gaps
        List<GapDef> gaps = new List<GapDef>(d.Gaps);
        gaps.Sort((a, b) => a.X0.CompareTo(b.X0));
        double cur = -30.0;
        foreach (GapDef g in gaps)
        {
            if (g.X1 <= g.X0 || g.X0 < 8.0 || g.X1 > d.FinishX - 6.0)
                throw new InvalidDataException(d.Name + ": a gap is malformed or too close to the start or the finish.");
            if (g.X0 < cur) throw new InvalidDataException(d.Name + ": overlapping gaps.");
            lv.Floors.Add(new Block(cur, g.X0, -50.0, 0.0, 0.15, true));
            lv.Gaps.Add(g);
            cur = g.X1;
        }
        lv.Floors.Add(new Block(cur, d.FinishX + 40.0, -50.0, 0.0, 0.15, true));
        foreach (Block f in lv.Floors) lv.Blocks.Add(f);

        double lastX = 0.0;
        foreach (BlockDef b in d.Blocks)
        {
            if (b.X1 <= b.X0 || b.Y1 <= b.Y0 || b.X0 < 8.0) throw new InvalidDataException(d.Name + ": a block is malformed or in the safe start zone.");
            lv.Blocks.Add(new Block(b.X0, b.X1, b.Y0, b.Y1, 0.0, false));
            lastX = Math.Max(lastX, b.X1);
        }
        foreach (SpikeDef s in d.Spikes)
        {
            if (s.X < 8.0) throw new InvalidDataException(d.Name + ": a spike is in the safe start zone.");
            lv.Spikes.Add(new Spike(s.X, s.Y));
            lastX = Math.Max(lastX, s.X + 1.0);
        }
        foreach (SawDef w in d.Saws)
        {
            if (w.X < 8.0 || w.Period <= 0.0) throw new InvalidDataException(d.Name + ": a saw is malformed or in the safe start zone.");
            lv.Saws.Add(new Saw(w));
            lastX = Math.Max(lastX, w.X + 1.0);
        }
        if (lastX > d.FinishX - 5.0) throw new InvalidDataException(d.Name + ": an obstacle is too close to the finish line.");
        return lv;
    }
}
