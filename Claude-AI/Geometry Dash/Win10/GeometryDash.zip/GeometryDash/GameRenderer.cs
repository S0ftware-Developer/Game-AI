using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace GeometryDash;

/// <summary>
/// GDI+ renderer: neon geometric look with a beat-synchronised pulse. Everything is drawn in logical 960x640
/// coordinates (1 block = 40 px) and scaled to the window. Brushes, pens and fonts are cached.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    public static readonly Rectangle StartButton = new Rectangle(330, 470, 300, 50);

    private const float U = Cfg.Unit;

    private struct Deco
    {
        public float X, Y, W, H, Factor, Alpha;
    }

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fHud;
    private readonly Font fLabel;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fBig;
    private readonly Font fFooter;
    private readonly Font fTitle;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;
    private readonly StringFormat sfRight;
    private readonly GraphicsPath titlePath;
    private readonly LinearGradientBrush titleFill;
    private readonly Deco[] decos = new Deco[30];
    private readonly PointF[] tri = new PointF[3];
    private readonly PointF[] quad = new PointF[4];
    private readonly PointF[] teeth = new PointF[24];

    private LinearGradientBrush? bgBrush;
    private int bgFor = -1;

    public GameRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        fHud = new Font("Segoe UI", 15f, FontStyle.Bold, GraphicsUnit.Pixel);
        fLabel = new Font("Segoe UI", 11f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Segoe UI", 26f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Segoe UI", 18f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBig = new Font("Segoe UI", 48f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitle = new Font("Consolas", 88f, FontStyle.Bold, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;
        sfRight = new StringFormat();
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfRight.FormatFlags = StringFormatFlags.NoWrap;

        Random rnd = new Random(12);
        for (int i = 0; i < decos.Length; i++)
        {
            bool far = i % 2 == 0;
            decos[i].X = (float)(rnd.NextDouble() * 1920.0);
            decos[i].Y = 40f + (float)(rnd.NextDouble() * 500.0);
            float sz = far ? 80f + (float)(rnd.NextDouble() * 160.0) : 36f + (float)(rnd.NextDouble() * 90.0);
            decos[i].W = sz;
            decos[i].H = sz * (0.6f + (float)rnd.NextDouble() * 0.9f);
            decos[i].Factor = far ? 0.12f : 0.3f;
            decos[i].Alpha = far ? 0.10f : 0.17f;
        }

        titlePath = new GraphicsPath();
        titlePath.AddString("GEOMETRY DASH", fTitle.FontFamily, (int)FontStyle.Bold, 88f, new PointF(0f, 0f), StringFormat.GenericTypographic);
        RectangleF b = titlePath.GetBounds();
        using (Matrix m = new Matrix())
        {
            m.Translate(Cfg.LogicalW / 2f - (b.X + b.Width / 2f), 118f - (b.Y + b.Height / 2f));
            titlePath.Transform(m);
        }
        titleFill = new LinearGradientBrush(new RectangleF(0f, 70f, 10f, 100f), Color.FromArgb(214, 255, 70), Color.FromArgb(70, 190, 20), 90f);
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fHud.Dispose();
        fLabel.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fBig.Dispose();
        fFooter.Dispose();
        fTitle.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        sfRight.Dispose();
        titlePath.Dispose();
        titleFill.Dispose();
        if (bgBrush != null) bgBrush.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static Color Hsv(double h, double s, double v, int a)
    {
        h = ((h % 360.0) + 360.0) % 360.0;
        double c = v * s;
        double x = c * (1.0 - Math.Abs((h / 60.0) % 2.0 - 1.0));
        double m = v - c;
        double r, g, b;
        if (h < 60) { r = c; g = x; b = 0; }
        else if (h < 120) { r = x; g = c; b = 0; }
        else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; }
        else if (h < 300) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        return Color.FromArgb(a, (int)((r + m) * 255.0), (int)((g + m) * 255.0), (int)((b + m) * 255.0));
    }

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow)
        {
            Color sh = Color.FromArgb(Math.Min((int)c.A, 190), 2, 4, 16);
            g.DrawString(s, f, B(sh), x + 1.5f, y + 1.5f, sf);
        }
        g.DrawString(s, f, B(c), x, y, sf);
    }

    private void EnsureBackground(double hue, int key)
    {
        if (bgFor == key && bgBrush != null) return;
        if (bgBrush != null) bgBrush.Dispose();
        bgBrush = new LinearGradientBrush(new Rectangle(0, 0, Cfg.LogicalW, Cfg.LogicalH + 1), Hsv(hue, 0.85, 0.22, 255), Hsv(hue, 0.85, 0.58, 255), 90f);
        bgFor = key;
    }

    private static float Pulse(double time, double bpm)
    {
        double beat = time * bpm / 60.0;
        double frac = beat - Math.Floor(beat);
        return (float)Math.Exp(-frac * 5.0);
    }

    private void DrawDecos(Graphics g, double hue, double camPx, float pulse)
    {
        for (int i = 0; i < decos.Length; i++)
        {
            Deco d = decos[i];
            float x = (float)(((d.X - camPx * d.Factor) % 1920.0 + 1920.0) % 1920.0) - 200f;
            float grow = 1f + pulse * 0.05f * (i % 3);
            float w = d.W * grow;
            float h = d.H * grow;
            int a = (int)(255f * (d.Alpha + pulse * 0.05f));
            g.FillRectangle(B(Hsv(hue + 20.0, 0.5, 1.0, a)), x, d.Y, w, h);
            g.DrawRectangle(P(Hsv(hue + 20.0, 0.3, 1.0, Math.Min(255, a + 20)), 1.5f), x, d.Y, w, h);
        }
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)Cfg.LogicalW, clientH / (float)Cfg.LogicalH);
        float offX = (clientW - Cfg.LogicalW * scale) / 2f;
        float offY = (clientH - Cfg.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, Cfg.LogicalW, Cfg.LogicalH));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (e.State == GameState.Menu) DrawMenu(g, e);
            else if (e.State == GameState.Victory) DrawVictory(g, e);
            else
            {
                DrawGame(g, e);
                if (e.State == GameState.Paused) DrawPause(g);
            }
            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ game

    private void DrawGame(Graphics g, GameEngine e)
    {
        Level lv = e.Level;
        Player pl = e.Player;
        double time = pl.Steps * Player.Dt;
        float pulse = Pulse(time, lv.Bpm);
        double camX = pl.X;

        EnsureBackground(lv.Hue, e.LevelIndex);
        g.FillRectangle(bgBrush!, 0, 0, Cfg.LogicalW, Cfg.LogicalH);
        DrawDecos(g, lv.Hue, camX * U, pulse);
        g.FillRectangle(B(Color.FromArgb((int)(18f * pulse), 255, 255, 255)), 0, 0, Cfg.LogicalW, Cfg.LogicalH);

        GraphicsState st = g.Save();
        g.SetClip(new Rectangle(0, Cfg.HudH, Cfg.LogicalW, Cfg.ViewH));
        DrawWorld(g, e, camX, pulse);
        g.Restore(st);

        DrawHud(g, e);

        if (e.FlashTimer > 0f)
        {
            g.FillRectangle(B(Color.FromArgb((int)(120f * e.FlashTimer / 0.35f), 255, 255, 255)), 0, Cfg.HudH, Cfg.LogicalW, Cfg.ViewH);
        }
        if (pl.Dead)
        {
            float a = Math.Min(1f, e.DeathTimer * 6f);
            Txt(g, "ПОГИБ: " + e.DeathReason.ToUpperInvariant(), fMid, Color.FromArgb((int)(255 * a), 255, 255, 255), Cfg.LogicalW / 2f, Cfg.HudH + 70f, sfCenter, true);
        }
        if (e.Completing)
        {
            float a = Math.Min(1f, e.CompleteTimer * 3f);
            float ring = e.CompleteTimer * 520f;
            g.DrawEllipse(P(Color.FromArgb((int)(180 * (1f - Math.Min(1f, e.CompleteTimer / 1.2f))), 120, 255, 140), 6f),
                Cfg.PlayerScreenX - ring, Cfg.GroundY - 20f - ring, ring * 2f, ring * 2f);
            Txt(g, "УРОВЕНЬ ПРОЙДЕН!", fBig, Color.FromArgb((int)(255 * a), 140, 255, 150), Cfg.LogicalW / 2f, Cfg.HudH + 190f, sfCenter, true);
        }
    }

    private void DrawWorld(Graphics g, GameEngine e, double camX, float pulse)
    {
        Level lv = e.Level;
        Player pl = e.Player;
        double hue = lv.Hue;
        float sxMin = -60f;
        float sxMax = Cfg.LogicalW + 60f;
        double wxMin = camX - (Cfg.PlayerScreenX + 60.0) / U;
        double wxMax = camX + (Cfg.LogicalW - Cfg.PlayerScreenX + 60.0) / U;
        float viewBottom = Cfg.HudH + Cfg.ViewH;

        Color groundFill = Hsv(hue, 0.9, 0.14, 255);
        Color groundLine = Hsv(hue, 0.3, 1.0, 255);
        Color glow = Hsv(hue, 0.5, 1.0, (int)(55 + 70 * pulse));
        Color blockFill = Hsv(hue, 0.9, 0.09, 255);
        Color blockLine = Hsv(hue + 28.0, 0.55, 1.0, 255);

        // ground
        foreach (Block f in lv.Floors)
        {
            if (f.X1 < wxMin || f.X0 > wxMax) continue;
            float x0 = Math.Max(sxMin, SX(f.X0, camX));
            float x1 = Math.Min(sxMax, SX(f.X1, camX));
            g.FillRectangle(B(groundFill), x0, Cfg.GroundY, x1 - x0, viewBottom - Cfg.GroundY);
            double first = Math.Floor(Math.Max(f.X0, wxMin));
            for (double wx = first; wx <= Math.Min(f.X1, wxMax); wx += 1.0)
            {
                float lx = SX(wx, camX);
                g.DrawLine(P(Hsv(hue, 0.6, 1.0, 22), 1f), lx, Cfg.GroundY, lx, viewBottom);
            }
            g.DrawLine(P(glow, 9f), x0, Cfg.GroundY, x1, Cfg.GroundY);
            g.DrawLine(P(groundLine, 3f), x0, Cfg.GroundY, x1, Cfg.GroundY);
            // vertical edges of the ground at both ends of every gap
            if (f.X1 < lv.FinishX + 20.0 && f.X1 >= wxMin && f.X1 <= wxMax)
            {
                g.DrawLine(P(groundLine, 3f), x1, Cfg.GroundY, x1, viewBottom);
            }
            if (f.X0 > -20.0 && f.X0 >= wxMin && f.X0 <= wxMax)
            {
                g.DrawLine(P(groundLine, 3f), x0, Cfg.GroundY, x0, viewBottom);
            }
        }

        // solid blocks
        foreach (Block b in lv.Blocks)
        {
            if (b.IsFloor || b.X1 < wxMin || b.X0 > wxMax) continue;
            float x = SX(b.X0, camX);
            float y = SY(b.Y1);
            float w = (float)((b.X1 - b.X0) * U);
            float h = (float)((b.Y1 - b.Y0) * U);
            g.FillRectangle(B(blockFill), x, y, w, h);
            for (double tx = 0; tx < b.X1 - b.X0 - 0.01; tx += 1.0)
            {
                for (double ty = 0; ty < b.Y1 - b.Y0 - 0.01; ty += 1.0)
                {
                    g.DrawRectangle(P(Hsv(hue + 28.0, 0.5, 1.0, 70), 1.5f), x + (float)tx * U + 7f, y + (float)ty * U + 7f, U - 14f, U - 14f);
                }
            }
            g.DrawRectangle(P(Color.FromArgb(70, blockLine.R, blockLine.G, blockLine.B), 7f), x, y, w, h);
            g.DrawRectangle(P(blockLine, 2.6f), x, y, w, h);
        }

        // spikes (deadly: white outline with a red glow)
        foreach (Spike s in lv.Spikes)
        {
            if (s.X < wxMin || s.X > wxMax) continue;
            float x = SX(s.X, camX);
            float y = SY(s.Y);
            tri[0] = new PointF(x, y);
            tri[1] = new PointF(x + U, y);
            tri[2] = new PointF(x + U / 2f, y - U * 0.92f);
            g.FillPolygon(B(Color.FromArgb(255, 8, 8, 20)), tri);
            g.DrawPolygon(P(Color.FromArgb((int)(60 + 50 * pulse), 255, 60, 80), 8f), tri);
            g.DrawPolygon(P(Color.White, 2.6f), tri);
        }

        // moving saws
        foreach (Saw w in lv.Saws)
        {
            if (w.X < wxMin || w.X > wxMax) continue;
            float cx = SX(w.X, camX);
            float y1 = SY(w.Y1);
            float y2 = SY(w.Y2);
            g.DrawLine(P(Color.FromArgb(60, 255, 120, 140), 3f), cx, y1, cx, y2);
            float cy = SY(w.CenterY(pl.Steps));
            DrawSaw(g, cx, cy, (float)(pl.Steps * Player.Dt) * 8f, U * 0.52f, pulse);
        }

        // finish gate
        {
            float fx = SX(lv.FinishX, camX);
            if (fx > -40f && fx < Cfg.LogicalW + 40f)
            {
                for (int i = 0; i < 16; i++)
                {
                    float y = Cfg.HudH + i * 28f;
                    g.FillRectangle(B((i % 2 == 0) ? Color.FromArgb(240, 120, 255, 150) : Color.FromArgb(240, 255, 255, 255)), fx, y, 10f, 28f);
                    g.FillRectangle(B((i % 2 == 0) ? Color.FromArgb(240, 255, 255, 255) : Color.FromArgb(240, 120, 255, 150)), fx + 10f, y, 10f, 28f);
                }
                g.FillRectangle(B(Color.FromArgb(34, 120, 255, 150)), fx - 40f, Cfg.HudH, 100f, Cfg.ViewH);
            }
        }

        // particles
        foreach (Particle p in e.Particles)
        {
            float k = p.Life / p.MaxLife;
            Color c = Color.FromArgb((int)(255 * k), p.Color.R, p.Color.G, p.Color.B);
            float px = SX(p.X, camX);
            float py = SY(p.Y);
            float half = p.Size * U / 2f;
            float cs = MathF.Cos(p.Rot) * half;
            float sn = MathF.Sin(p.Rot) * half;
            quad[0] = new PointF(px - cs + sn, py - sn - cs);
            quad[1] = new PointF(px + cs + sn, py + sn - cs);
            quad[2] = new PointF(px + cs - sn, py + sn + cs);
            quad[3] = new PointF(px - cs - sn, py - sn + cs);
            g.FillPolygon(B(c), quad);
        }

        // attempt counter written into the world near the start, like a signpost
        float lx0 = SX(3.0, camX);
        if (lx0 > -300f && lx0 < Cfg.LogicalW)
        {
            Txt(g, "ПОПЫТКА " + e.Attempt, fMid, Color.FromArgb(255, 255, 255, 255), lx0, SY(5.0), sfLeft, true);
        }

        DrawCube(g, e, pulse);
    }

    private float SX(double wx, double camX)
    {
        return (float)(Cfg.PlayerScreenX + (wx - camX) * U);
    }

    private float SY(double wy)
    {
        return (float)(Cfg.GroundY - wy * U);
    }

    private void DrawSaw(Graphics g, float cx, float cy, float angle, float radius, float pulse)
    {
        g.FillEllipse(B(Color.FromArgb((int)(36 + 30 * pulse), 255, 50, 90)), cx - radius - 7f, cy - radius - 7f, (radius + 7f) * 2f, (radius + 7f) * 2f);
        int n = teeth.Length;
        for (int i = 0; i < n; i++)
        {
            float a = angle + i * MathF.PI * 2f / n;
            float rad = (i % 2 == 0) ? radius : radius * 0.72f;
            teeth[i] = new PointF(cx + MathF.Cos(a) * rad, cy + MathF.Sin(a) * rad);
        }
        g.FillPolygon(B(Color.FromArgb(255, 255, 56, 96)), teeth);
        g.DrawPolygon(P(Color.White, 1.8f), teeth);
        g.FillEllipse(B(Color.FromArgb(255, 30, 10, 30)), cx - radius * 0.55f, cy - radius * 0.55f, radius * 1.1f, radius * 1.1f);
        g.FillEllipse(B(Color.FromArgb(255, 255, 140, 170)), cx - radius * 0.28f, cy - radius * 0.28f, radius * 0.56f, radius * 0.56f);
    }

    private void DrawCube(Graphics g, GameEngine e, float pulse)
    {
        Player pl = e.Player;
        if (pl.Dead) return;
        float cx = Cfg.PlayerScreenX;
        float cy = SY(pl.Y) - U / 2f;

        // short motion trail
        for (int k = 4; k >= 1; k--)
        {
            float a = 0.10f * (5 - k);
            g.FillRectangle(B(Color.FromArgb((int)(255 * a), 255, 200, 60)), cx - k * 15f - 14f, cy - 14f, 28f, 28f);
        }

        GraphicsState st = g.Save();
        g.TranslateTransform(cx, cy);
        g.RotateTransform(pl.Rotation);
        float h = U / 2f;
        g.FillRectangle(B(Color.FromArgb(70, 255, 220, 80)), -h - 5f, -h - 5f, U + 10f, U + 10f);
        g.FillRectangle(B(Color.FromArgb(255, 255, 206, 40)), -h, -h, U, U);
        g.FillRectangle(B(Color.FromArgb(255, 255, 150, 24)), -h + 7f, -h + 7f, U - 14f, U - 14f);
        g.DrawRectangle(P(Color.White, 3f), -h, -h, U, U);
        g.FillRectangle(B(Color.FromArgb(255, 20, 30, 70)), -11f, -9f, 8f, 8f);
        g.FillRectangle(B(Color.FromArgb(255, 20, 30, 70)), 3f, -9f, 8f, 8f);
        g.FillRectangle(B(Color.FromArgb(255, 70, 230, 255)), -9f, -7f, 4f, 4f);
        g.FillRectangle(B(Color.FromArgb(255, 70, 230, 255)), 5f, -7f, 4f, 4f);
        g.FillRectangle(B(Color.FromArgb(255, 20, 30, 70)), -9f, 5f, 18f, 5f);
        g.Restore(st);
    }

    private void DrawHud(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(225, 4, 6, 22)), 0, 0, Cfg.LogicalW, Cfg.HudH);
        Color accent = Hsv(e.Level.Hue + 28.0, 0.55, 1.0, 255);
        g.FillRectangle(B(accent), 0, Cfg.HudH - 3, Cfg.LogicalW, 3);
        Txt(g, "УРОВЕНЬ " + (e.LevelIndex + 1) + " / " + e.LevelCount, fHud, Color.White, 16f, 15f, sfLeft, true);
        Txt(g, e.Level.Name.ToUpperInvariant(), fLabel, Color.FromArgb(255, 170, 200, 245), 16f, 31f, sfLeft, false);

        double prog = e.Completing ? 1.0 : e.Progress;
        float bx = 330f;
        float bw = 300f;
        g.FillRectangle(B(Color.FromArgb(255, 18, 22, 50)), bx, 15f, bw, 14f);
        g.FillRectangle(B(accent), bx, 15f, (float)(bw * prog), 14f);
        g.DrawRectangle(P(Color.White, 1.6f), bx, 15f, bw, 14f);
        Txt(g, ((int)(prog * 100.0)).ToString() + "%", fHud, Color.White, bx + bw + 12f, 22f, sfLeft, true);

        Txt(g, "ПОПЫТКА " + e.Attempt, fHud, Color.White, Cfg.LogicalW - 16f, 15f, sfRight, true);
        double best = e.Best[e.LevelIndex];
        Txt(g, "ЛУЧШИЙ " + ((int)(best * 100.0)) + "%", fLabel, Color.FromArgb(255, 170, 200, 245), Cfg.LogicalW - 16f, 31f, sfRight, false);
        if (e.State == GameState.Paused) Txt(g, "ПАУЗА", fHud, Color.FromArgb(255, 255, 220, 80), 270f, 22f, sfCenter, true);
    }

    // ------------------------------------------------------------------ menu and screens

    private void DrawMenu(Graphics g, GameEngine e)
    {
        float clock = e.Clock;
        double hue = 215.0;
        EnsureBackground(hue, 100);
        g.FillRectangle(bgBrush!, 0, 0, Cfg.LogicalW, Cfg.LogicalH);
        float pulse = Pulse(clock, 126.0);
        DrawDecos(g, hue, clock * 120.0, pulse);
        g.FillRectangle(B(Color.FromArgb((int)(18f * pulse), 255, 255, 255)), 0, 0, Cfg.LogicalW, Cfg.LogicalH);

        float gy = 380f;
        Color groundLine = Hsv(hue, 0.3, 1.0, 255);
        g.FillRectangle(B(Hsv(hue, 0.9, 0.14, 255)), 0, gy, Cfg.LogicalW, Cfg.LogicalH - gy);
        g.DrawLine(P(Hsv(hue, 0.5, 1.0, (int)(55 + 70 * pulse)), 9f), 0, gy, Cfg.LogicalW, gy);
        g.DrawLine(P(groundLine, 3f), 0, gy, Cfg.LogicalW, gy);
        for (float x = -((clock * 320f) % 40f); x < Cfg.LogicalW; x += 40f)
        {
            g.DrawLine(P(Hsv(hue, 0.6, 1.0, 22), 1f), x, gy, x, Cfg.LogicalH);
        }

        // demo: spikes scroll past and the cube hops over them
        float cubeX = 330f;
        float spikeStart = 1100f - (clock * 300f) % 1250f;
        for (int i = 0; i < 2; i++)
        {
            float x = spikeStart + i * U;
            tri[0] = new PointF(x, gy);
            tri[1] = new PointF(x + U, gy);
            tri[2] = new PointF(x + U / 2f, gy - U * 0.92f);
            g.FillPolygon(B(Color.FromArgb(255, 8, 8, 20)), tri);
            g.DrawPolygon(P(Color.White, 2.6f), tri);
        }
        float d = spikeStart + U - cubeX;
        float u = (d + 150f) / 300f;
        float lift = 0f;
        float rot = 0f;
        if (u > 0f && u < 1f)
        {
            lift = 4f * 110f * u * (1f - u);
            rot = 180f * u;
        }
        GraphicsState cs = g.Save();
        g.TranslateTransform(cubeX, gy - lift - U / 2f);
        g.RotateTransform(rot);
        float h = U / 2f;
        g.FillRectangle(B(Color.FromArgb(70, 255, 220, 80)), -h - 5f, -h - 5f, U + 10f, U + 10f);
        g.FillRectangle(B(Color.FromArgb(255, 255, 206, 40)), -h, -h, U, U);
        g.FillRectangle(B(Color.FromArgb(255, 255, 150, 24)), -h + 7f, -h + 7f, U - 14f, U - 14f);
        g.DrawRectangle(P(Color.White, 3f), -h, -h, U, U);
        g.FillRectangle(B(Color.FromArgb(255, 20, 30, 70)), -11f, -9f, 8f, 8f);
        g.FillRectangle(B(Color.FromArgb(255, 20, 30, 70)), 3f, -9f, 8f, 8f);
        g.FillRectangle(B(Color.FromArgb(255, 70, 230, 255)), -9f, -7f, 4f, 4f);
        g.FillRectangle(B(Color.FromArgb(255, 70, 230, 255)), 5f, -7f, 4f, 4f);
        g.FillRectangle(B(Color.FromArgb(255, 20, 30, 70)), -9f, 5f, 18f, 5f);
        g.Restore(cs);

        // title
        GraphicsState ts = g.Save();
        g.TranslateTransform(0f, MathF.Sin(clock * 2.2f) * 3f);
        g.DrawPath(P(Color.White, 12f), titlePath);
        g.DrawPath(P(Color.FromArgb(255, 20, 60, 30), 8f), titlePath);
        g.FillPath(titleFill, titlePath);
        g.Restore(ts);
        Txt(g, "R H Y T H M    P L A T F O R M E R", fText, Color.FromArgb(255, 220, 245, 255), Cfg.LogicalW / 2f, 188f, sfCenter, true);
        g.FillRectangle(B(Color.FromArgb(200, 120, 235, 255)), 150f, 188f, 120f, 3f);
        g.FillRectangle(B(Color.FromArgb(200, 120, 235, 255)), 690f, 188f, 120f, 3f);

        Txt(g, "Куб бежит сам. Прыгайте через шипы, блоки и пропасти строго в ритм —", fSmall, Color.FromArgb(255, 214, 230, 255), Cfg.LogicalW / 2f, 225f, sfCenter, true);
        Txt(g, "запоминайте узор препятствий и доберитесь до финиша. 10 уровней.", fSmall, Color.FromArgb(255, 214, 230, 255), Cfg.LogicalW / 2f, 246f, sfCenter, true);

        // level selector
        Txt(g, "ВЫБОР УРОВНЯ:  ←  →", fLabel, Color.FromArgb(255, 170, 200, 245), Cfg.LogicalW / 2f, 424f, sfCenter, true);
        for (int i = 0; i < e.LevelCount; i++)
        {
            float bx = 480f - e.LevelCount * 22f + i * 44f + 3f;
            bool unlocked = i <= e.Unlocked;
            bool sel = i == e.MenuSelect;
            g.FillRectangle(B(sel ? Color.FromArgb(255, 70, 220, 255) : (unlocked ? Color.FromArgb(230, 20, 50, 130) : Color.FromArgb(150, 10, 20, 60))), bx, 436f, 38f, 24f);
            if (sel) g.DrawRectangle(P(Color.White, 1.8f), bx, 436f, 38f, 24f);
            Txt(g, (i + 1).ToString(), fLabel, unlocked ? (sel ? Color.FromArgb(255, 5, 20, 50) : Color.White) : Color.FromArgb(120, 150, 170, 220), bx + 19f, 448f, sfCenter, false);
        }

        Rectangle sb = StartButton;
        float pulse2 = 0.5f + 0.5f * MathF.Sin(clock * 4f);
        quad[0] = new PointF(sb.X + 14f, sb.Y);
        quad[1] = new PointF(sb.Right - 14f, sb.Y);
        quad[2] = new PointF(sb.Right, sb.Y + sb.Height / 2f);
        quad[3] = new PointF(sb.Right - 14f, sb.Bottom);
        PointF[] hex = { quad[0], quad[1], quad[2], quad[3], new PointF(sb.X + 14f, sb.Bottom), new PointF(sb.X, sb.Y + sb.Height / 2f) };
        g.FillPolygon(B(Color.FromArgb(255, 6, 18, 60)), hex);
        g.DrawPolygon(P(Color.FromArgb((int)(150 + 105 * pulse2), 70, 230, 255), 3.4f), hex);
        string st = e.MenuSelect > 0 ? "ENTER — УРОВЕНЬ " + (e.MenuSelect + 1) : "ENTER — НАЧАТЬ ИГРУ";
        Txt(g, st, fText, Color.White, sb.X + sb.Width / 2f, sb.Y + sb.Height / 2f, sfCenter, true);

        Txt(g, "ПРОБЕЛ / ↑ / ЛЕВАЯ КНОПКА МЫШИ — прыжок     R — заново     Esc — пауза / меню", fSmall, Color.FromArgb(255, 200, 220, 255), Cfg.LogicalW / 2f, 548f, sfCenter, true);
        Txt(g, "N — звук     F11 — полный экран     Один прыжок с земли: в воздухе прыгать нельзя", fSmall, Color.FromArgb(255, 150, 175, 225), Cfg.LogicalW / 2f, 570f, sfCenter, true);
    }

    private void DrawPause(Graphics g)
    {
        g.FillRectangle(B(Color.FromArgb(165, 2, 4, 18)), 0, Cfg.HudH, Cfg.LogicalW, Cfg.ViewH);
        Txt(g, "ПАУЗА", fBig, Color.White, Cfg.LogicalW / 2f, 250f, sfCenter, true);
        g.FillRectangle(B(Color.FromArgb(255, 70, 230, 255)), 400, 282, 160, 3);
        Txt(g, "Enter / Esc — продолжить", fText, Color.FromArgb(255, 214, 230, 255), Cfg.LogicalW / 2f, 318f, sfCenter, true);
        Txt(g, "R — начать уровень заново", fText, Color.FromArgb(255, 214, 230, 255), Cfg.LogicalW / 2f, 346f, sfCenter, true);
        Txt(g, "M — главное меню", fText, Color.FromArgb(255, 214, 230, 255), Cfg.LogicalW / 2f, 374f, sfCenter, true);
    }

    private void DrawVictory(Graphics g, GameEngine e)
    {
        double hue = 285.0;
        EnsureBackground(hue, 101);
        g.FillRectangle(bgBrush!, 0, 0, Cfg.LogicalW, Cfg.LogicalH);
        float pulse = Pulse(e.Clock, 128.0);
        DrawDecos(g, hue, e.Clock * 160.0, pulse);
        Txt(g, "ВСЕ УРОВНИ ПРОЙДЕНЫ!", fBig, Color.FromArgb(255, 150, 255, 160), Cfg.LogicalW / 2f, 190f, sfCenter, true);
        g.FillRectangle(B(Color.FromArgb(255, 70, 230, 255)), 340, 228, 280, 3);
        Txt(g, "Вы освоили ритм всех десяти уровней.", fText, Color.FromArgb(255, 220, 235, 255), Cfg.LogicalW / 2f, 270f, sfCenter, true);
        Txt(g, "Смертей за последнюю игру: " + e.TotalDeaths, fMid, Color.White, Cfg.LogicalW / 2f, 330f, sfCenter, true);
        Txt(g, "Enter — в главное меню", fText, Color.White, Cfg.LogicalW / 2f, 430f, sfCenter, true);
        Txt(g, "R — сыграть снова", fText, Color.White, Cfg.LogicalW / 2f, 460f, sfCenter, true);
    }

    private void DrawFooter(Graphics g)
    {
        Rectangle r = new Rectangle(0, Cfg.LogicalH - Cfg.FooterH, Cfg.LogicalW, Cfg.FooterH);
        g.FillRectangle(B(Color.FromArgb(255, 4, 6, 20)), r);
        g.FillRectangle(B(Color.FromArgb(255, 70, 230, 255)), 0, r.Y, Cfg.LogicalW, 2);
        g.DrawString(FooterText, fFooter, B(Color.FromArgb(255, 220, 232, 252)),
            new RectangleF(0f, r.Y + 3f, Cfg.LogicalW, r.Height - 3f), sfCenter);
    }
}
