namespace GeometryDash;

/// <summary>
/// The cube. Fixed time step (1/120 s), constant forward speed, a single jump from the ground,
/// exact collision rules shared with the offline level checker that verified the levels.
/// </summary>
public sealed class Player
{
    public const double Dt = 1.0 / 120.0;
    public const double Gravity = 72.0;      // blocks / s^2
    public const double JumpV = 20.8;        // blocks / s, apex about 3.0 blocks, air time about 0.58 s
    public const double MaxFall = 36.0;
    public const double BufferTime = 0.10;   // a jump pressed slightly before landing is remembered

    public double X;
    public double Y;                          // height of the cube's bottom above the ground surface
    public double VY;
    public bool Grounded;
    public bool Dead;
    public string DeathReason = "";
    public bool Finished;
    public long Steps;
    public float Rotation;                    // visual only

    public bool EvJump;
    public bool EvLand;

    private double buffer;

    public void Reset()
    {
        X = 0.0;
        Y = 0.0;
        VY = 0.0;
        Grounded = true;
        Dead = false;
        DeathReason = "";
        Finished = false;
        Steps = 0;
        Rotation = 0f;
        buffer = 0.0;
        EvJump = false;
        EvLand = false;
    }

    private void Kill(string reason)
    {
        Dead = true;
        DeathReason = reason;
    }

    /// <summary>Advances the simulation by exactly one fixed step.</summary>
    public void Update(Level lv, bool jumpPressed)
    {
        EvJump = false;
        EvLand = false;
        if (Dead || Finished) return;

        if (jumpPressed) buffer = BufferTime;
        bool jumpNow = false;
        if (buffer > 0.0 && Grounded)
        {
            jumpNow = true;
            buffer = 0.0;
        }
        else
        {
            buffer = Math.Max(0.0, buffer - Dt);
        }

        if (jumpNow)
        {
            VY = JumpV;
            Grounded = false;
            EvJump = true;
        }

        VY -= Gravity * Dt;
        if (VY < -MaxFall) VY = -MaxFall;
        double prevY = Y;
        Y += VY * Dt;
        X += lv.Speed * Dt;
        Steps++;

        bool wasGrounded = Grounded;
        bool landed = false;
        double landY = 0.0;
        foreach (Block b in lv.Blocks)
        {
            double p0 = X - 0.5 + b.Shrink;
            double p1 = X + 0.5 - b.Shrink;
            if (p1 <= b.X0 - 1.0 || p0 >= b.X1 + 1.0) continue;
            bool overlapX = p1 > b.X0 && p0 < b.X1;
            if (VY <= 0.0 && prevY >= b.Y1 - 1e-7 && Y <= b.Y1 + 1e-7 && overlapX)
            {
                if (!landed || b.Y1 > landY)
                {
                    landed = true;
                    landY = b.Y1;
                }
                continue;
            }
            if (overlapX && Y < b.Y1 - 1e-7 && Y + 1.0 > b.Y0 + 1e-7)
            {
                Kill(b.IsFloor ? "Пропасть" : "Блок");
                return;
            }
        }
        if (landed)
        {
            Y = landY;
            VY = 0.0;
            Grounded = true;
            if (!wasGrounded) EvLand = true;
        }
        else
        {
            Grounded = false;
        }

        // spikes: a slightly smaller box than the cube against the spike's core
        double q0 = X - 0.4;
        double q1 = X + 0.4;
        double r0 = Y + 0.1;
        double r1 = Y + 0.9;
        foreach (Spike s in lv.Spikes)
        {
            if (s.X < X - 2.0 || s.X > X + 2.0) continue;
            double a0 = s.X + 0.3;
            double a1 = s.X + 0.7;
            double c0 = s.Y;
            double c1 = s.Y + 0.55;
            if (q1 > a0 && q0 < a1 && r1 > c0 && r0 < c1)
            {
                Kill("Шипы");
                return;
            }
        }
        foreach (Saw w in lv.Saws)
        {
            if (w.X < X - 2.0 || w.X > X + 2.0) continue;
            double cy = w.CenterY(Steps);
            double nx = Math.Max(q0, Math.Min(w.X, q1));
            double ny = Math.Max(r0, Math.Min(cy, r1));
            double dx = w.X - nx;
            double dy = cy - ny;
            if (dx * dx + dy * dy <= Level.SawRadius * Level.SawRadius)
            {
                Kill("Пила");
                return;
            }
        }
        if (Y < -6.0)
        {
            Kill("Пропасть");
            return;
        }
        if (X >= lv.FinishX) Finished = true;

        // visual rotation: a half turn per jump, then settle on a multiple of 90 degrees
        if (!Grounded) Rotation += (float)(311.0 * Dt);
        else
        {
            float target = (float)Math.Round(Rotation / 90f) * 90f;
            Rotation += (target - Rotation) * (float)Math.Min(1.0, Dt * 20.0);
        }
    }
}
