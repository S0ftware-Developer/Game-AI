using System.Drawing.Drawing2D;

namespace JetpackJoyride;

/// <summary>Coin Magnet: pulls nearby coins toward the hero for a limited time.</summary>
public sealed class MagnetEffect : BonusEffect
{
    public override string Id { get { return "magnet"; } }
    public override string Name { get { return "МАГНИТ"; } }
    public override Color Color { get { return Color.FromArgb(255, 80, 150, 255); } }
    public override float Duration { get { return GameConfig.MagnetDuration; } }
    public override float MagnetRadius { get { return GameConfig.MagnetRadius; } }

    public override void DrawIcon(Graphics g, RectangleF r)
    {
        float cx = r.X + r.Width / 2f;
        float cy = r.Y + r.Height / 2f;
        float s = r.Width / 2f;
        g.DrawArc(Gfx.Pen(Color.FromArgb(255, 235, 60, 60), s * 0.5f), cx - s * 0.55f, cy - s * 0.6f, s * 1.1f, s * 1.2f, 180f, 180f);
        g.DrawLine(Gfx.Pen(Color.FromArgb(255, 235, 60, 60), s * 0.5f), cx - s * 0.55f, cy, cx - s * 0.55f, cy + s * 0.5f);
        g.DrawLine(Gfx.Pen(Color.FromArgb(255, 235, 60, 60), s * 0.5f), cx + s * 0.55f, cy, cx + s * 0.55f, cy + s * 0.5f);
        g.FillRectangle(Gfx.Brush(Color.FromArgb(255, 235, 240, 250)), cx - s * 0.8f, cy + s * 0.5f, s * 0.5f, s * 0.3f);
        g.FillRectangle(Gfx.Brush(Color.FromArgb(255, 235, 240, 250)), cx + s * 0.3f, cy + s * 0.5f, s * 0.5f, s * 0.3f);
    }

    public override void DrawAura(Graphics g, PointF center, float time)
    {
        for (int i = 0; i < 3; i++)
        {
            float k = (time * 1.4f + i / 3f) % 1f;
            float rad = 70f - k * 40f;
            g.DrawEllipse(Gfx.Pen(Color.FromArgb((int)(150 * k), 90, 160, 255), 2.5f), center.X - rad, center.Y - rad, rad * 2f, rad * 2f);
        }
    }
}

/// <summary>Shield: absorbs one lethal hit, or disappears after its maximum duration. Never permanent.</summary>
public sealed class ShieldEffect : BonusEffect
{
    public override string Id { get { return "shield"; } }
    public override string Name { get { return "ЩИТ"; } }
    public override Color Color { get { return Color.FromArgb(255, 70, 230, 255); } }
    public override float Duration { get { return GameConfig.ShieldMaxDuration; } }

    public override bool AbsorbHit(BonusContext ctx)
    {
        Consumed = true;                                         // one hit and the shield is gone
        ctx.Player.Invulnerable = GameConfig.ShieldInvulnerability;
        ctx.PlaySound(SfxId.ShieldHit);
        ctx.Popup("Щит выдержал удар!", Color);
        return true;
    }

    public override void OnActivate(BonusContext ctx)
    {
        ctx.PlaySound(SfxId.ShieldUp);
    }

    public override void DrawIcon(Graphics g, RectangleF r)
    {
        float cx = r.X + r.Width / 2f;
        float cy = r.Y + r.Height / 2f;
        float s = r.Width / 2f;
        PointF[] pts =
        {
            new PointF(cx - s * 0.7f, cy - s * 0.6f), new PointF(cx + s * 0.7f, cy - s * 0.6f),
            new PointF(cx + s * 0.7f, cy + s * 0.1f), new PointF(cx, cy + s * 0.8f), new PointF(cx - s * 0.7f, cy + s * 0.1f)
        };
        g.FillPolygon(Gfx.Brush(Color.FromArgb(255, 60, 170, 255)), pts);
        g.DrawPolygon(Gfx.Pen(Color.White, 2f), pts);
        g.FillRectangle(Gfx.Brush(Color.FromArgb(255, 220, 250, 255)), cx - s * 0.12f, cy - s * 0.4f, s * 0.24f, s * 0.9f);
    }

    public override void DrawAura(Graphics g, PointF center, float time)
    {
        bool fading = Remaining < 3f && ((int)(time * 8f)) % 2 == 0;
        int a = fading ? 40 : 90;
        float rw = 36f;
        float rh = 46f;
        g.FillEllipse(Gfx.Brush(Color.FromArgb(a, 70, 220, 255)), center.X - rw, center.Y - rh, rw * 2f, rh * 2f);
        g.DrawEllipse(Gfx.Pen(Color.FromArgb(fading ? 120 : 230, 150, 245, 255), 3f), center.X - rw, center.Y - rh, rw * 2f, rh * 2f);
    }
}

/// <summary>Speed Boost: the whole world (scrolling, obstacles, distance) moves faster for a short time.</summary>
public sealed class SpeedBoostEffect : BonusEffect
{
    public override string Id { get { return "boost"; } }
    public override string Name { get { return "УСКОРЕНИЕ"; } }
    public override Color Color { get { return Color.FromArgb(255, 255, 170, 40); } }
    public override float Duration { get { return GameConfig.BoostDuration; } }
    public override float SpeedMultiplier { get { return GameConfig.BoostMultiplier; } }

    public override void DrawIcon(Graphics g, RectangleF r)
    {
        float cx = r.X + r.Width / 2f;
        float cy = r.Y + r.Height / 2f;
        float s = r.Width / 2f;
        PointF[] bolt =
        {
            new PointF(cx + s * 0.15f, cy - s * 0.85f), new PointF(cx - s * 0.55f, cy + s * 0.1f), new PointF(cx - s * 0.05f, cy + s * 0.1f),
            new PointF(cx - s * 0.2f, cy + s * 0.85f), new PointF(cx + s * 0.6f, cy - s * 0.2f), new PointF(cx + s * 0.05f, cy - s * 0.2f)
        };
        g.FillPolygon(Gfx.Brush(Color.FromArgb(255, 255, 220, 50)), bolt);
        g.DrawPolygon(Gfx.Pen(Color.FromArgb(255, 200, 90, 0), 1.6f), bolt);
    }

    public override void DrawAura(Graphics g, PointF center, float time)
    {
        for (int i = 0; i < 7; i++)
        {
            float y = center.Y - 34f + i * 11f;
            float k = (time * 3.2f + i * 0.37f) % 1f;
            float x0 = center.X - 50f - k * 90f;
            g.DrawLine(Gfx.Pen(Color.FromArgb((int)(190 * (1f - k)), 255, 210, 90), 3f), x0, y, x0 - 36f, y);
        }
    }
}
