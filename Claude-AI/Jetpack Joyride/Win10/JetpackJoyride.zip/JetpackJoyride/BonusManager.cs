namespace JetpackJoyride;

/// <summary>Owns the active bonuses: activation, timers, expiry and the combined modifiers the engine asks for.</summary>
public sealed class BonusManager
{
    public readonly List<BonusEffect> Active = new List<BonusEffect>();
    public Action<BonusEffect>? Expired;

    public void Clear()
    {
        Active.Clear();
    }

    /// <summary>Activates an effect. Picking up a bonus that is already active just refreshes its timer.</summary>
    public void Activate(BonusEffect effect, BonusContext ctx)
    {
        foreach (BonusEffect e in Active)
        {
            if (e.Id == effect.Id)
            {
                e.Remaining = e.Duration;
                e.Consumed = false;
                return;
            }
        }
        effect.Remaining = effect.Duration;
        effect.Consumed = false;
        Active.Add(effect);
        effect.OnActivate(ctx);
    }

    public void Update(float dt, BonusContext ctx)
    {
        for (int i = Active.Count - 1; i >= 0; i--)
        {
            BonusEffect e = Active[i];
            e.Remaining -= dt;
            e.OnUpdate(dt, ctx);
            if (e.Remaining <= 0f || e.Consumed)
            {
                e.OnExpire(ctx);
                Active.RemoveAt(i);
                if (Expired != null) Expired(e);
            }
        }
    }

    public float SpeedMultiplier
    {
        get
        {
            float m = 1f;
            foreach (BonusEffect e in Active) m *= e.SpeedMultiplier;
            return m;
        }
    }

    public float MagnetRadius
    {
        get
        {
            float r = 0f;
            foreach (BonusEffect e in Active) r = Math.Max(r, e.MagnetRadius);
            return r;
        }
    }

    /// <summary>Gives the active effects a chance to absorb a lethal hit. True means the hero survives.</summary>
    public bool TryAbsorbHit(BonusContext ctx)
    {
        for (int i = 0; i < Active.Count; i++)
        {
            if (Active[i].AbsorbHit(ctx)) return true;
        }
        return false;
    }
}
