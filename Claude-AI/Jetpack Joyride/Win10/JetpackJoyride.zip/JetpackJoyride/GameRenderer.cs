using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace JetpackJoyride;

/// <summary>
/// GDI+ renderer. Layered laboratory backgrounds are pre-rendered once into bitmaps and scrolled at different speeds
/// for depth; obstacles, coins, bonuses and the hero are drawn live. Everything is in logical 960x640 coordinates.
/// </summary>
public sealed class GameRenderer : IDisposable
{
    public const string FooterText = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";

    public static readonly Rectangle StartButton = new Rectangle(330, 478, 300, 52);
    public static readonly Rectangle RestartButton = new Rectangle(220, 420, 250, 52);
    public static readonly Rectangle MenuButton = new Rectangle(490, 420, 250, 52);

    private const int AreaH = GameConfig.LogicalH - GameConfig.FooterH;       // 608
    private const float Ceil = GameConfig.CeilingY;
    private const float Floor = GameConfig.FloorY;

    private readonly SolidBrush tmp = new SolidBrush(Color.White);
    private readonly Pen tmpPen = new Pen(Color.White, 1f);
    private readonly Font fHud;
    private readonly Font fLabel;
    private readonly Font fMid;
    private readonly Font fText;
    private readonly Font fSmall;
    private readonly Font fBig;
    private readonly Font fFooter;
    private readonly Font fTitle;
    private readonly StringFormat sfCenter;
    private readonly StringFormat sfLeft;
    private readonly StringFormat sfRight;
    private readonly Bitmap farBmp;
    private readonly Bitmap midBmp;
    private readonly Bitmap ceilBmp;
    private readonly Bitmap floorBmp;
    private readonly Bitmap pipesBmp;
    private readonly GraphicsPath titlePath1;
    private readonly GraphicsPath titlePath2;
    private readonly LinearGradientBrush titleFill1;
    private readonly LinearGradientBrush titleFill2;
    private readonly PointF[] tri = new PointF[3];
    private readonly PointF[] quad = new PointF[4];
    private readonly PointF[] bolt = new PointF[40];

    public GameRenderer()
    {
        tmpPen.LineJoin = LineJoin.Round;
        tmpPen.StartCap = LineCap.Round;
        tmpPen.EndCap = LineCap.Round;

        fHud = new Font("Segoe UI", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
        fLabel = new Font("Segoe UI", 11f, FontStyle.Bold, GraphicsUnit.Pixel);
        fMid = new Font("Segoe UI", 26f, FontStyle.Bold, GraphicsUnit.Pixel);
        fText = new Font("Segoe UI", 18f, FontStyle.Bold, GraphicsUnit.Pixel);
        fSmall = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fBig = new Font("Segoe UI", 44f, FontStyle.Bold, GraphicsUnit.Pixel);
        fFooter = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        fTitle = new Font("Impact", 100f, FontStyle.Regular, GraphicsUnit.Pixel);

        sfCenter = new StringFormat();
        sfCenter.Alignment = StringAlignment.Center;
        sfCenter.LineAlignment = StringAlignment.Center;
        sfCenter.FormatFlags = StringFormatFlags.NoWrap;
        sfLeft = new StringFormat();
        sfLeft.Alignment = StringAlignment.Near;
        sfLeft.LineAlignment = StringAlignment.Center;
        sfLeft.FormatFlags = StringFormatFlags.NoWrap;
        sfRight = new StringFormat();
        sfRight.Alignment = StringAlignment.Far;
        sfRight.LineAlignment = StringAlignment.Center;
        sfRight.FormatFlags = StringFormatFlags.NoWrap;

        farBmp = MakeFar();
        midBmp = MakeMid();
        ceilBmp = MakeCeiling();
        floorBmp = MakeFloor();
        pipesBmp = MakePipes();

        titlePath1 = MakeTitlePath("JETPACK", 96f, 470f, 140f, 4f);
        titlePath2 = MakeTitlePath("JOYRIDE", 116f, 500f, 252f, 4f);
        titleFill1 = new LinearGradientBrush(new RectangleF(0f, 90f, 10f, 100f), Color.FromArgb(255, 255, 255), Color.FromArgb(150, 170, 215), 90f);
        titleFill2 = new LinearGradientBrush(new RectangleF(0f, 190f, 10f, 120f), Color.FromArgb(255, 235, 70), Color.FromArgb(255, 140, 20), 90f);
    }

    public void Dispose()
    {
        tmp.Dispose();
        tmpPen.Dispose();
        fHud.Dispose();
        fLabel.Dispose();
        fMid.Dispose();
        fText.Dispose();
        fSmall.Dispose();
        fBig.Dispose();
        fFooter.Dispose();
        fTitle.Dispose();
        sfCenter.Dispose();
        sfLeft.Dispose();
        sfRight.Dispose();
        farBmp.Dispose();
        midBmp.Dispose();
        ceilBmp.Dispose();
        floorBmp.Dispose();
        pipesBmp.Dispose();
        titlePath1.Dispose();
        titlePath2.Dispose();
        titleFill1.Dispose();
        titleFill2.Dispose();
    }

    // ------------------------------------------------------------------ helpers

    private SolidBrush B(Color c)
    {
        tmp.Color = c;
        return tmp;
    }

    private Pen P(Color c, float w)
    {
        tmpPen.Color = c;
        tmpPen.Width = w;
        return tmpPen;
    }

    private static int A(float v)
    {
        return (int)Math.Max(0f, Math.Min(255f, v));
    }

    private void Txt(Graphics g, string s, Font f, Color c, float x, float y, StringFormat sf, bool shadow)
    {
        if (shadow)
        {
            g.DrawString(s, f, B(Color.FromArgb(Math.Min((int)c.A, 200), 4, 8, 20)), x + 2f, y + 2f, sf);
        }
        g.DrawString(s, f, B(c), x, y, sf);
    }

    private void DrawLayer(Graphics g, Bitmap bmp, double offset, int y)
    {
        int w = bmp.Width;
        float x = -(float)(((offset % w) + w) % w);
        while (x < GameConfig.LogicalW)
        {
            g.DrawImageUnscaled(bmp, (int)x, y);
            x += w;
        }
    }

    // ------------------------------------------------------------------ entry point

    public void Render(Graphics g, GameEngine e, int clientW, int clientH)
    {
        g.Clear(Color.Black);
        if (clientW < 8 || clientH < 8) return;

        float scale = Math.Min(clientW / (float)GameConfig.LogicalW, clientH / (float)GameConfig.LogicalH);
        float offX = (clientW - GameConfig.LogicalW * scale) / 2f;
        float offY = (clientH - GameConfig.LogicalH * scale) / 2f;

        GraphicsState saved = g.Save();
        try
        {
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);
            g.SetClip(new Rectangle(0, 0, GameConfig.LogicalW, GameConfig.LogicalH));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            if (e.State == GameState.Menu) DrawMenu(g, e);
            else
            {
                DrawGame(g, e);
                if (e.State == GameState.Paused) DrawPause(g);
                else if (e.State == GameState.GameOver) DrawGameOver(g, e);
            }
            DrawFooter(g);
        }
        finally
        {
            g.Restore(saved);
        }
    }

    // ------------------------------------------------------------------ game

    private void DrawBackground(Graphics g, double scroll)
    {
        DrawLayer(g, farBmp, scroll * 0.12, 0);
        DrawLayer(g, midBmp, scroll, 0);
        DrawLayer(g, ceilBmp, scroll, 0);
        DrawLayer(g, floorBmp, scroll, (int)Floor);
    }

    private void DrawGame(Graphics g, GameEngine e)
    {
        float scroll = e.Scroll;
        DrawBackground(g, scroll);

        // world objects
        foreach (Coin c in e.Coins.Coins)
        {
            float sx = c.X - scroll;
            if (sx < -30f || sx > GameConfig.LogicalW + 30f) continue;
            DrawCoin(g, sx, c.Y, e.RunTime, c.Phase);
        }
        foreach (BonusPickup p in e.Pickups)
        {
            float sx = p.X - scroll;
            if (sx < -60f || sx > GameConfig.LogicalW + 60f) continue;
            DrawPickup(g, p, sx, e.Clock);
        }
        foreach (Obstacle o in e.Obstacles)
        {
            if (o.Right - scroll < -40f || o.X - scroll > GameConfig.LogicalW + 40f) continue;
            DrawObstacle(g, o, scroll, e.RunTime);
        }

        // the ceiling and floor strips go over the bases of pistons and beams
        DrawLayer(g, ceilBmp, scroll, 0);
        DrawLayer(g, floorBmp, scroll, (int)Floor);
        DrawLayer(g, pipesBmp, scroll * 1.35, 0);

        // particles
        foreach (Particle p in e.Particles)
        {
            float k = p.Life / p.MaxLife;
            float px = p.X - scroll;
            if (px < -20f || px > GameConfig.LogicalW + 20f) continue;
            if (p.Kind == 0)
            {
                float r = p.Size * (1.6f - k);
                g.FillEllipse(B(Color.FromArgb(A(150 * k), p.Color.R, p.Color.G, p.Color.B)), px - r, p.Y - r, r * 2f, r * 2f);
            }
            else
            {
                g.FillRectangle(B(Color.FromArgb(A(255 * k), p.Color.R, p.Color.G, p.Color.B)), px - p.Size / 2f, p.Y - p.Size / 2f, p.Size, p.Size);
            }
        }

        DrawHero(g, GameConfig.PlayerScreenX, e.Player.Y, e.Player, e.Clock, e.Player.Invulnerable > 0f);
        if (!e.Player.Dead)
        {
            PointF center = new PointF(GameConfig.PlayerScreenX, e.Player.Y);
            foreach (BonusEffect fx in e.Bonuses.Active) fx.DrawAura(g, center, e.Clock);
        }

        DrawHud(g, e);

        foreach (Popup p in e.Popups)
        {
            float k = p.Life / p.MaxLife;
            Txt(g, p.Text, p.Big ? fBig : fText, Color.FromArgb(A(255 * Math.Min(1f, k * 2f)), p.Color.R, p.Color.G, p.Color.B), p.X, p.Y, sfCenter, true);
        }
        if (e.Player.Dead && e.Player.DeadTime < 0.22f)
        {
            g.FillRectangle(B(Color.FromArgb(A(160 * (1f - e.Player.DeadTime / 0.22f)), 255, 255, 255)), 0, 0, GameConfig.LogicalW, AreaH);
        }
    }

    private void DrawHud(Graphics g, GameEngine e)
    {
        Txt(g, "ДИСТАНЦИЯ", fLabel, Color.FromArgb(255, 150, 175, 215), 22f, 12f, sfLeft, false);
        Txt(g, e.Meters + " м", fHud, Color.White, 22f, 36f, sfLeft, true);

        g.FillEllipse(B(Color.FromArgb(255, 255, 205, 40)), 262f, 24f, 22f, 22f);
        g.DrawEllipse(P(Color.FromArgb(255, 190, 120, 0), 2f), 262f, 24f, 22f, 22f);
        Txt(g, "МОНЕТЫ", fLabel, Color.FromArgb(255, 150, 175, 215), 294f, 12f, sfLeft, false);
        Txt(g, e.CoinsCollected.ToString(), fHud, Color.FromArgb(255, 255, 220, 70), 294f, 36f, sfLeft, true);

        Txt(g, "СЧЁТ", fLabel, Color.FromArgb(255, 150, 175, 215), GameConfig.LogicalW / 2f, 12f, sfCenter, false);
        Txt(g, e.Score.ToString(), fHud, Color.White, GameConfig.LogicalW / 2f, 38f, sfCenter, true);

        Txt(g, "РЕКОРД", fLabel, Color.FromArgb(255, 150, 175, 215), GameConfig.LogicalW - 22f, 12f, sfRight, false);
        Txt(g, e.Scores.BestScore.ToString(), fHud, Color.FromArgb(255, 255, 220, 70), GameConfig.LogicalW - 22f, 36f, sfRight, true);

        // active bonuses with a remaining-time bar
        int row = 0;
        foreach (BonusEffect fx in e.Bonuses.Active)
        {
            float y = 84f + row * 36f;
            g.FillEllipse(B(Color.FromArgb(200, 10, 20, 50)), 16f, y, 30f, 30f);
            g.DrawEllipse(P(fx.Color, 2f), 16f, y, 30f, 30f);
            fx.DrawIcon(g, new RectangleF(20f, y + 4f, 22f, 22f));
            Txt(g, fx.Name, fLabel, Color.White, 54f, y + 7f, sfLeft, true);
            g.FillRectangle(B(Color.FromArgb(200, 10, 20, 50)), 54f, y + 16f, 130f, 9f);
            float frac = Math.Max(0f, Math.Min(1f, fx.Remaining / fx.Duration));
            g.FillRectangle(B(fx.Color), 54f, y + 16f, 130f * frac, 9f);
            row++;
        }
    }

    private void DrawCoin(Graphics g, float x, float y, float time, float phase)
    {
        float spin = Math.Abs(MathF.Cos(time * 5f + phase));
        float w = 3f + 13f * spin;
        float h = 15f;
        g.FillEllipse(B(Color.FromArgb(60, 255, 220, 80)), x - w - 4f, y - h - 4f, (w + 4f) * 2f, (h + 4f) * 2f);
        g.FillEllipse(B(Color.FromArgb(255, 255, 200, 30)), x - w, y - h, w * 2f, h * 2f);
        g.DrawEllipse(P(Color.FromArgb(255, 200, 120, 0), 2f), x - w, y - h, w * 2f, h * 2f);
        if (w > 8f) g.FillEllipse(B(Color.FromArgb(255, 255, 240, 130)), x - w * 0.55f, y - h * 0.62f, w * 0.7f, h * 1.2f);
    }

    private void DrawPickup(Graphics g, BonusPickup p, float sx, float clock)
    {
        float y = p.Y + MathF.Sin(clock * 3f + p.X) * 5f;
        Color c = p.Effect.Color;
        g.FillEllipse(B(Color.FromArgb(50, c.R, c.G, c.B)), sx - 38f, y - 38f, 76f, 76f);
        g.FillEllipse(B(Color.FromArgb(235, 14, 28, 66)), sx - 26f, y - 26f, 52f, 52f);
        g.DrawEllipse(P(c, 4f), sx - 26f, y - 26f, 52f, 52f);
        p.Effect.DrawIcon(g, new RectangleF(sx - 17f, y - 17f, 34f, 34f));
    }

    // ------------------------------------------------------------------ obstacles

    private void DrawObstacle(Graphics g, Obstacle o, float scroll, float time)
    {
        if (o is LaserBeam lb) DrawLaser(g, lb, scroll, time);
        else if (o is ElectricBarrier eb) DrawBarrier(g, eb, scroll, time);
        else if (o is Piston pi) DrawPiston(g, pi, scroll, time);
        else if (o is Spinner sp) DrawSpinner(g, sp, scroll, time);
        else if (o is MovingBarrier mb) DrawMovingBarrier(g, mb, scroll, time);
    }

    private void DrawEmitter(Graphics g, float x, float y, bool lit)
    {
        g.FillRectangle(B(Color.FromArgb(255, 70, 78, 100)), x - 11f, y - 13f, 22f, 26f);
        g.DrawRectangle(P(Color.FromArgb(255, 20, 26, 44), 2f), x - 11f, y - 13f, 22f, 26f);
        g.FillEllipse(B(lit ? Color.FromArgb(255, 255, 70, 60) : Color.FromArgb(255, 110, 30, 30)), x - 6f, y - 6f, 12f, 12f);
    }

    private void DrawLaser(Graphics g, LaserBeam l, float scroll, float time)
    {
        float x1 = l.X1 - scroll;
        float x2 = l.X2 - scroll;
        LaserState st = l.StateAt(time);
        if (st == LaserState.On)
        {
            float flick = 0.75f + 0.25f * MathF.Sin(time * 60f);
            g.DrawLine(P(Color.FromArgb(A(70 * flick), 255, 40, 40), 16f), x1, l.Y1, x2, l.Y2);
            g.DrawLine(P(Color.FromArgb(255, 255, 60, 60), 7f), x1, l.Y1, x2, l.Y2);
            g.DrawLine(P(Color.FromArgb(255, 255, 230, 230), 2.5f), x1, l.Y1, x2, l.Y2);
        }
        else if (st == LaserState.Warning && ((int)(time * 14f)) % 2 == 0)
        {
            g.DrawLine(P(Color.FromArgb(200, 255, 150, 150), 2f), x1, l.Y1, x2, l.Y2);
        }
        else if (l.Timed)
        {
            g.DrawLine(P(Color.FromArgb(50, 255, 120, 120), 1.5f), x1, l.Y1, x2, l.Y2);
        }
        DrawEmitter(g, x1, l.Y1, st == LaserState.On);
        DrawEmitter(g, x2, l.Y2, st == LaserState.On);
    }

    private void DrawBarrier(Graphics g, ElectricBarrier b, float scroll, float time)
    {
        float x1 = b.X1 - scroll;
        float x2 = b.X2 - scroll;
        float dx = x2 - x1;
        float dy = b.Y2 - b.Y1;
        float len = MathF.Sqrt(dx * dx + dy * dy);
        int n = Math.Max(2, Math.Min(bolt.Length - 1, (int)(len / 12f)));
        float nx = len > 0.01f ? -dy / len : 0f;
        float ny = len > 0.01f ? dx / len : 0f;
        for (int i = 0; i <= n; i++)
        {
            float f = i / (float)n;
            float jitter = (i == 0 || i == n) ? 0f : MathF.Sin(time * 40f + i * 2.3f + b.X) * 5f;
            bolt[i] = new PointF(x1 + dx * f + nx * jitter, b.Y1 + dy * f + ny * jitter);
        }
        PointF[] pts = new PointF[n + 1];
        Array.Copy(bolt, pts, n + 1);
        g.DrawLines(P(Color.FromArgb(70, 90, 170, 255), 16f), pts);
        g.DrawLines(P(Color.FromArgb(255, 120, 200, 255), 6f), pts);
        g.DrawLines(P(Color.FromArgb(255, 255, 255, 220), 2.4f), pts);
        DrawNode(g, x1, b.Y1, time);
        DrawNode(g, x2, b.Y2, time);
    }

    private void DrawNode(Graphics g, float x, float y, float time)
    {
        g.FillEllipse(B(Color.FromArgb(255, 60, 66, 88)), x - 12f, y - 12f, 24f, 24f);
        g.DrawEllipse(P(Color.FromArgb(255, 255, 220, 60), 3f), x - 12f, y - 12f, 24f, 24f);
        float k = 0.5f + 0.5f * MathF.Sin(time * 18f + x);
        g.FillEllipse(B(Color.FromArgb(A(150 + 105 * k), 200, 240, 255)), x - 5f, y - 5f, 10f, 10f);
    }

    private void DrawHazardStripes(Graphics g, RectangleF r)
    {
        g.FillRectangle(B(Color.FromArgb(255, 30, 30, 36)), r);
        GraphicsState st = g.Save();
        g.SetClip(r, CombineMode.Intersect);
        for (float x = r.X - r.Height; x < r.Right; x += 20f)
        {
            quad[0] = new PointF(x, r.Bottom);
            quad[1] = new PointF(x + 10f, r.Bottom);
            quad[2] = new PointF(x + 10f + r.Height, r.Top);
            quad[3] = new PointF(x + r.Height, r.Top);
            g.FillPolygon(B(Color.FromArgb(255, 245, 200, 30)), quad);
        }
        g.Restore(st);
        g.DrawRectangle(P(Color.FromArgb(255, 15, 15, 20), 2f), r.X, r.Y, r.Width, r.Height);
    }

    private void DrawPiston(Graphics g, Piston p, float scroll, float time)
    {
        float cx = p.CenterX - scroll;
        float e = p.ExtensionAt(time);
        float rodTop, rodH, headY;
        if (p.FromTop)
        {
            rodTop = Ceil;
            rodH = e;
            headY = Ceil + e - Piston.HeadH;
        }
        else
        {
            rodTop = Floor - e;
            rodH = e;
            headY = Floor - e;
        }
        g.FillRectangle(B(Color.FromArgb(255, 150, 158, 178)), cx - Piston.RodWidth / 2f, rodTop, Piston.RodWidth, rodH);
        g.FillRectangle(B(Color.FromArgb(255, 205, 212, 228)), cx - Piston.RodWidth / 2f + 2f, rodTop, 4f, rodH);
        g.DrawRectangle(P(Color.FromArgb(255, 40, 46, 66), 2f), cx - Piston.RodWidth / 2f, rodTop, Piston.RodWidth, rodH);
        DrawHazardStripes(g, new RectangleF(cx - Piston.HeadW / 2f, headY, Piston.HeadW, Piston.HeadH));
    }

    private void DrawSpinner(Graphics g, Spinner s, float scroll, float time)
    {
        float cx = s.CenterX - scroll;
        float a = Spinner.AngleAt(time);
        float cs = MathF.Cos(a);
        float sn = MathF.Sin(a);
        float ax = cx + cs * Spinner.ArmLength;
        float ay = s.CenterY + sn * Spinner.ArmLength;
        float bx = cx - cs * Spinner.ArmLength;
        float by = s.CenterY - sn * Spinner.ArmLength;
        g.DrawLine(P(Color.FromArgb(255, 30, 34, 50), 14f), bx, by, ax, ay);
        g.DrawLine(P(Color.FromArgb(255, 170, 178, 200), 9f), bx, by, ax, ay);
        g.DrawLine(P(Color.FromArgb(255, 235, 240, 250), 3f), bx, by, ax, ay);
        g.FillEllipse(B(Color.FromArgb(255, 235, 50, 50)), ax - 13f, ay - 13f, 26f, 26f);
        g.FillEllipse(B(Color.FromArgb(255, 235, 50, 50)), bx - 13f, by - 13f, 26f, 26f);
        g.DrawEllipse(P(Color.White, 2f), ax - 13f, ay - 13f, 26f, 26f);
        g.DrawEllipse(P(Color.White, 2f), bx - 13f, by - 13f, 26f, 26f);
        g.FillEllipse(B(Color.FromArgb(255, 70, 78, 100)), cx - 11f, s.CenterY - 11f, 22f, 22f);
        g.FillEllipse(B(Color.FromArgb(255, 255, 210, 50)), cx - 5f, s.CenterY - 5f, 10f, 10f);
    }

    private void DrawMovingBarrier(Graphics g, MovingBarrier m, float scroll, float time)
    {
        float cx = m.CenterX - scroll;
        float cy = m.CenterYAt(time);
        g.DrawLine(P(Color.FromArgb(120, 20, 26, 44), 8f), cx, m.MinY - MovingBarrier.H / 2f - 10f, cx, m.MaxY + MovingBarrier.H / 2f + 10f);
        g.DrawLine(P(Color.FromArgb(170, 150, 160, 185), 3f), cx, m.MinY - MovingBarrier.H / 2f - 10f, cx, m.MaxY + MovingBarrier.H / 2f + 10f);
        RectangleF r = new RectangleF(cx - MovingBarrier.W / 2f, cy - MovingBarrier.H / 2f, MovingBarrier.W, MovingBarrier.H);
        g.FillRectangle(B(Color.FromArgb(255, 120, 128, 150)), r);
        DrawHazardStripes(g, new RectangleF(r.X, r.Y, r.Width, 22f));
        DrawHazardStripes(g, new RectangleF(r.X, r.Bottom - 22f, r.Width, 22f));
        g.DrawRectangle(P(Color.FromArgb(255, 20, 26, 44), 3f), r.X, r.Y, r.Width, r.Height);
        g.FillEllipse(B(Color.FromArgb(255, 255, 70, 60)), cx - 6f, cy - 6f, 12f, 12f);
    }

    // ------------------------------------------------------------------ hero

    private void DrawHero(Graphics g, float cx, float cy, Player p, float time, bool blink)
    {
        if (blink && ((int)(time * 12f)) % 2 == 0) return;
        float tilt = Math.Max(-1f, Math.Min(1f, p.VY / GameConfig.MaxDownSpeed)) * 18f;
        if (p.Dead) tilt = p.DeadTime * 600f;
        DrawHeroPose(g, cx, cy, tilt, p.ThrustLevel, p.RunPhase, p.OnFloor && !p.Dead, p.VY, p.Dead, time);
    }

    private void DrawHeroPose(Graphics g, float cx, float cy, float tilt, float thrust, float runPhase, bool onFloor, float vy, bool dead, float time)
    {
        GraphicsState st = g.Save();
        g.TranslateTransform(cx, cy);
        g.RotateTransform(tilt);

        // jetpack flames: always point down from the nozzles, longer and brighter with more thrust
        if (thrust > 0.05f && !dead)
        {
            for (int i = 0; i < 2; i++)
            {
                float nx = -25f + i * 9f;
                float len = 22f + 36f * thrust + MathF.Sin(time * 70f + i * 2f) * 7f;
                tri[0] = new PointF(nx - 5f, 18f);
                tri[1] = new PointF(nx + 5f, 18f);
                tri[2] = new PointF(nx + MathF.Sin(time * 50f + i) * 2f, 18f + len);
                g.FillPolygon(B(Color.FromArgb(235, 255, 130, 20)), tri);
                tri[0] = new PointF(nx - 3f, 18f);
                tri[1] = new PointF(nx + 3f, 18f);
                tri[2] = new PointF(nx, 18f + len * 0.62f);
                g.FillPolygon(B(Color.FromArgb(255, 255, 235, 90)), tri);
            }
        }

        // jetpack
        g.FillRectangle(B(Color.FromArgb(255, 150, 156, 174)), -31f, -14f, 20f, 32f);
        g.FillRectangle(B(Color.FromArgb(255, 245, 200, 40)), -31f, -2f, 20f, 7f);
        g.DrawRectangle(P(Color.FromArgb(255, 40, 46, 66), 2f), -31f, -14f, 20f, 32f);
        g.FillRectangle(B(Color.FromArgb(255, 60, 66, 86)), -28f, 16f, 7f, 5f);
        g.FillRectangle(B(Color.FromArgb(255, 60, 66, 86)), -19f, 16f, 7f, 5f);

        // legs
        float hipY = 12f;
        float f1x, f1y, f2x, f2y;
        if (dead)
        {
            f1x = -8f; f1y = 26f; f2x = 10f; f2y = 22f;
        }
        else if (onFloor)
        {
            float s = MathF.Sin(runPhase);
            float c = MathF.Cos(runPhase);
            f1x = s * 11f; f1y = 29f - Math.Max(0f, c) * 9f;
            f2x = -s * 11f; f2y = 29f - Math.Max(0f, -c) * 9f;
        }
        else if (vy > 150f)
        {
            f1x = -9f; f1y = 30f; f2x = 11f; f2y = 27f;
        }
        else
        {
            f1x = -12f; f1y = 28f; f2x = -3f; f2y = 31f;
        }
        g.DrawLine(P(Color.FromArgb(255, 28, 40, 100), 8f), -2f, hipY, f1x, f1y - 3f);
        g.DrawLine(P(Color.FromArgb(255, 28, 40, 100), 8f), 5f, hipY, f2x + 4f, f2y - 3f);
        g.FillRectangle(B(Color.FromArgb(255, 50, 36, 30)), f1x - 6f, f1y - 4f, 13f, 7f);
        g.FillRectangle(B(Color.FromArgb(255, 50, 36, 30)), f2x - 2f, f2y - 4f, 13f, 7f);

        // torso and arm
        g.FillRectangle(B(Color.FromArgb(255, 55, 115, 225)), -12f, -19f, 27f, 33f);
        g.FillRectangle(B(Color.FromArgb(255, 240, 245, 255)), 3f, -17f, 8f, 20f);
        g.DrawRectangle(P(Color.FromArgb(255, 20, 36, 90), 2f), -12f, -19f, 27f, 33f);
        g.FillRectangle(B(Color.FromArgb(255, 235, 175, 40)), -12f, 8f, 27f, 5f);
        g.DrawLine(P(Color.FromArgb(255, 40, 80, 170), 7f), 6f, -10f, 21f, dead ? -22f : -3f);
        g.FillEllipse(B(Color.FromArgb(255, 255, 205, 160)), 17f, dead ? -27f : -8f, 10f, 10f);

        // head
        g.FillEllipse(B(Color.FromArgb(255, 255, 205, 160)), -5f, -42f, 26f, 26f);
        g.DrawEllipse(P(Color.FromArgb(255, 80, 50, 30), 2f), -5f, -42f, 26f, 26f);
        PointF[] hair =
        {
            new PointF(-6f, -28f), new PointF(-4f, -46f), new PointF(3f, -41f), new PointF(8f, -50f),
            new PointF(13f, -42f), new PointF(21f, -47f), new PointF(22f, -33f), new PointF(16f, -36f), new PointF(2f, -34f)
        };
        g.FillPolygon(B(Color.FromArgb(255, 125, 70, 30)), hair);
        if (dead)
        {
            g.DrawLine(P(Color.FromArgb(255, 30, 20, 20), 2f), 8f, -32f, 14f, -26f);
            g.DrawLine(P(Color.FromArgb(255, 30, 20, 20), 2f), 14f, -32f, 8f, -26f);
        }
        else
        {
            g.FillEllipse(B(Color.White), 8f, -33f, 10f, 10f);
            g.FillEllipse(B(Color.FromArgb(255, 30, 20, 20)), 12f, -31f, 5f, 6f);
            g.DrawArc(P(Color.FromArgb(255, 120, 50, 40), 2f), 6f, -28f, 12f, 8f, 20f, 140f);
        }
        g.Restore(st);
    }

    // ------------------------------------------------------------------ menu and overlays

    private void DrawMenu(Graphics g, GameEngine e)
    {
        float clock = e.Clock;
        DrawBackground(g, clock * 140.0);

        // decoration: a coin arc, a magnet bubble and the flying hero
        for (int i = 0; i < 7; i++)
        {
            float cx = 110f + i * 66f;
            float cy = 400f - 70f * MathF.Sin(i / 6f * MathF.PI) + 22f;
            DrawCoin(g, cx, cy, clock, i);
        }
        float bob = MathF.Sin(clock * 2.4f) * 8f;
        DrawHeroPose(g, 170f, 330f + bob, -12f, 1f, 0f, false, -200f, false, clock);
        for (int i = 0; i < 8; i++)
        {
            float k = (clock * 1.3f + i * 0.125f) % 1f;
            float r = 6f + 12f * k;
            g.FillEllipse(B(Color.FromArgb(A(160 * (1f - k)), 235, 238, 248)), 130f - k * 90f - r, 380f + k * 50f - r, r * 2f, r * 2f);
        }
        BonusEffect demo = new MagnetEffect();
        BonusPickup bp = new BonusPickup();
        bp.X = 0f;
        bp.Y = 400f;
        bp.Effect = demo;
        DrawPickup(g, bp, 820f, clock);

        // title
        GraphicsState ts = g.Save();
        g.TranslateTransform(0f, MathF.Sin(clock * 1.8f) * 3f);
        g.DrawPath(P(Color.FromArgb(255, 14, 24, 60), 14f), titlePath1);
        g.FillPath(titleFill1, titlePath1);
        g.DrawPath(P(Color.FromArgb(255, 14, 24, 60), 14f), titlePath2);
        g.FillPath(titleFill2, titlePath2);
        g.Restore(ts);

        Txt(g, "Держите ПРОБЕЛ, ↑ или левую кнопку мыши — реактивный ранец толкает вверх. Отпустили — вы падаете.", fSmall, Color.FromArgb(255, 235, 242, 255), GameConfig.LogicalW / 2f, 338f, sfCenter, true);
        Txt(g, "Собирайте монеты и бонусы, обходите лазеры, электричество и механизмы.", fSmall, Color.FromArgb(255, 235, 242, 255), GameConfig.LogicalW / 2f, 360f, sfCenter, true);

        Rectangle sb = StartButton;
        float pulse = 0.5f + 0.5f * MathF.Sin(clock * 4f);
        g.FillRectangle(B(Color.FromArgb(255, 14, 22, 56)), sb);
        g.DrawRectangle(P(Color.FromArgb(A(170 + 85 * pulse), 255, 205, 40), 4f), sb.X, sb.Y, sb.Width, sb.Height);
        Txt(g, "ENTER — ИГРАТЬ", fText, Color.FromArgb(255, 255, 215, 60), sb.X + sb.Width / 2f, sb.Y + sb.Height / 2f, sfCenter, true);

        Txt(g, "РЕКОРД: " + e.Scores.BestScore + " очков    ЛУЧШАЯ ДИСТАНЦИЯ: " + e.Scores.BestDistance + " м", fText, Color.White, GameConfig.LogicalW / 2f, 448f, sfCenter, true);
        Txt(g, "Пробел / ↑ / ЛКМ — лететь     R — заново     Esc — пауза     N — звук     F11 — полный экран", fSmall, Color.FromArgb(255, 215, 228, 250), GameConfig.LogicalW / 2f, 556f, sfCenter, true);
        Txt(g, "Двигайтесь плавно: можно и чуть подправить высоту, и резко взлететь.", fSmall, Color.FromArgb(255, 180, 200, 235), GameConfig.LogicalW / 2f, 578f, sfCenter, true);
    }

    private void DrawPause(Graphics g)
    {
        g.FillRectangle(B(Color.FromArgb(165, 4, 8, 22)), 0, 0, GameConfig.LogicalW, AreaH);
        Txt(g, "ПАУЗА", fBig, Color.White, GameConfig.LogicalW / 2f, 230f, sfCenter, true);
        g.FillRectangle(B(Color.FromArgb(255, 255, 205, 40)), 400, 262, 160, 4);
        Txt(g, "Enter / Esc — продолжить", fText, Color.FromArgb(255, 225, 235, 255), GameConfig.LogicalW / 2f, 300f, sfCenter, true);
        Txt(g, "R — начать забег заново", fText, Color.FromArgb(255, 225, 235, 255), GameConfig.LogicalW / 2f, 330f, sfCenter, true);
        Txt(g, "M — главное меню", fText, Color.FromArgb(255, 225, 235, 255), GameConfig.LogicalW / 2f, 360f, sfCenter, true);
    }

    private void DrawGameOver(Graphics g, GameEngine e)
    {
        g.FillRectangle(B(Color.FromArgb(175, 4, 8, 22)), 0, 0, GameConfig.LogicalW, AreaH);
        Rectangle r = new Rectangle(190, 96, 580, 400);
        g.FillRectangle(B(Color.FromArgb(245, 14, 24, 58)), r);
        g.DrawRectangle(P(Color.FromArgb(255, 255, 205, 40), 4f), r.X, r.Y, r.Width, r.Height);

        Txt(g, e.NewRecord ? "НОВЫЙ РЕКОРД!" : "ЗАБЕГ ОКОНЧЕН", fBig, e.NewRecord ? Color.FromArgb(255, 255, 220, 60) : Color.White, GameConfig.LogicalW / 2f, 142f, sfCenter, true);
        Txt(g, "Дистанция: " + e.Meters + " м", fMid, Color.White, GameConfig.LogicalW / 2f, 206f, sfCenter, true);
        Txt(g, "Монеты: " + e.CoinsCollected + "     Бонусы: " + e.BonusesCollected, fMid, Color.FromArgb(255, 255, 225, 90), GameConfig.LogicalW / 2f, 246f, sfCenter, true);
        Txt(g, "Счёт: " + e.Score, fBig, Color.White, GameConfig.LogicalW / 2f, 304f, sfCenter, true);
        Txt(g, "Лучший счёт: " + e.Scores.BestScore + "     Лучшая дистанция: " + e.Scores.BestDistance + " м", fText, Color.FromArgb(255, 190, 210, 245), GameConfig.LogicalW / 2f, 362f, sfCenter, true);
        Txt(g, "Seed забега: " + e.RunSeed + "  (запуск с параметром --seed повторит этот забег)", fSmall, Color.FromArgb(255, 150, 170, 210), GameConfig.LogicalW / 2f, 392f, sfCenter, false);

        g.FillRectangle(B(Color.FromArgb(255, 30, 120, 60)), RestartButton);
        g.DrawRectangle(P(Color.White, 2f), RestartButton.X, RestartButton.Y, RestartButton.Width, RestartButton.Height);
        Txt(g, "R / ENTER — ЕЩЁ РАЗ", fText, Color.White, RestartButton.X + RestartButton.Width / 2f, RestartButton.Y + RestartButton.Height / 2f, sfCenter, true);
        g.FillRectangle(B(Color.FromArgb(255, 50, 60, 110)), MenuButton);
        g.DrawRectangle(P(Color.White, 2f), MenuButton.X, MenuButton.Y, MenuButton.Width, MenuButton.Height);
        Txt(g, "ESC / M — МЕНЮ", fText, Color.White, MenuButton.X + MenuButton.Width / 2f, MenuButton.Y + MenuButton.Height / 2f, sfCenter, true);
    }

    private void DrawFooter(Graphics g)
    {
        Rectangle r = new Rectangle(0, GameConfig.LogicalH - GameConfig.FooterH, GameConfig.LogicalW, GameConfig.FooterH);
        g.FillRectangle(B(Color.FromArgb(255, 8, 12, 28)), r);
        g.FillRectangle(B(Color.FromArgb(255, 245, 200, 30)), 0, r.Y, GameConfig.LogicalW, 2);
        g.DrawString(FooterText, fFooter, B(Color.FromArgb(255, 225, 234, 252)),
            new RectangleF(0f, r.Y + 3f, GameConfig.LogicalW, r.Height - 3f), sfCenter);
    }

    // ------------------------------------------------------------------ pre-rendered artwork

    private GraphicsPath MakeTitlePath(string text, float size, float cx, float cy, float shear)
    {
        GraphicsPath path = new GraphicsPath();
        path.AddString(text, fTitle.FontFamily, (int)FontStyle.Regular, size, new PointF(0f, 0f), StringFormat.GenericTypographic);
        RectangleF b = path.GetBounds();
        using (Matrix m = new Matrix())
        {
            m.Translate(cx - (b.X + b.Width / 2f), cy - (b.Y + b.Height / 2f));
            path.Transform(m);
        }
        using (Matrix sh = new Matrix(1f, 0f, -0.2f, 1f, cy * 0.2f, 0f))
        {
            path.Transform(sh);
        }
        return path;
    }

    private static Bitmap MakeFar()
    {
        int W = 1280;
        Bitmap bmp = new Bitmap(W, AreaH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush sky = new LinearGradientBrush(new Rectangle(0, 0, W, AreaH), Color.FromArgb(96, 160, 232), Color.FromArgb(200, 226, 248), 90f))
            {
                g.FillRectangle(sky, 0, 0, W, AreaH);
            }
            Random rnd = new Random(5);
            using (SolidBrush cloud = new SolidBrush(Color.FromArgb(150, 255, 255, 255)))
            {
                for (int i = 0; i < 9; i++)
                {
                    float x = rnd.Next(W);
                    float y = 90 + rnd.Next(200);
                    g.FillEllipse(cloud, x, y, 150, 40);
                    g.FillEllipse(cloud, x + 30, y - 16, 100, 44);
                }
            }
            using (SolidBrush far = new SolidBrush(Color.FromArgb(110, 120, 160, 210)))
            using (SolidBrush near = new SolidBrush(Color.FromArgb(150, 70, 100, 160)))
            using (SolidBrush lit = new SolidBrush(Color.FromArgb(200, 255, 230, 150)))
            {
                int x = 0;
                while (x < W)
                {
                    int w = 40 + rnd.Next(60);
                    int h = 120 + rnd.Next(240);
                    g.FillRectangle(far, x, 520 - h, w, h);
                    x += w - 6;
                }
                x = 20;
                while (x < W)
                {
                    int w = 50 + rnd.Next(60);
                    int h = 80 + rnd.Next(200);
                    g.FillRectangle(near, x, 540 - h, w, h);
                    for (int wy = 540 - h + 10; wy < 530; wy += 18)
                    {
                        for (int wx = x + 8; wx < x + w - 10; wx += 14)
                        {
                            if (rnd.Next(5) == 0) g.FillRectangle(lit, wx, wy, 6, 8);
                        }
                    }
                    x += w + 10;
                }
            }
        }
        return bmp;
    }

    private static void Pipe(Graphics g, int x, int y, int w, int h)
    {
        using (LinearGradientBrush lg = new LinearGradientBrush(new Rectangle(x, y, w, h), Color.FromArgb(170, 182, 205), Color.FromArgb(70, 80, 104), 90f))
        {
            g.FillRectangle(lg, x, y, w, h);
        }
        using (Pen p = new Pen(Color.FromArgb(255, 24, 30, 48), 2f))
        {
            g.DrawRectangle(p, x, y, w, h);
        }
    }

    private static void Hazard(Graphics g, Rectangle r)
    {
        using (SolidBrush dark = new SolidBrush(Color.FromArgb(255, 30, 30, 36)))
        using (SolidBrush yellow = new SolidBrush(Color.FromArgb(255, 245, 200, 30)))
        {
            g.FillRectangle(dark, r);
            GraphicsState st = g.Save();
            g.SetClip(r, CombineMode.Intersect);
            for (int x = r.X - r.Height; x < r.Right; x += 24)
            {
                PointF[] q = { new PointF(x, r.Bottom), new PointF(x + 12, r.Bottom), new PointF(x + 12 + r.Height, r.Top), new PointF(x + r.Height, r.Top) };
                g.FillPolygon(yellow, q);
            }
            g.Restore(st);
        }
    }

    private static Bitmap MakeMid()
    {
        int W = 1920;
        Bitmap bmp = new Bitmap(W, AreaH, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush wall = new LinearGradientBrush(new Rectangle(0, 0, W, AreaH), Color.FromArgb(78, 92, 122), Color.FromArgb(40, 50, 74), 90f))
            {
                g.FillRectangle(wall, 0, 0, W, AreaH);
            }
            using (Pen seam = new Pen(Color.FromArgb(90, 12, 18, 34), 3f))
            using (SolidBrush rivet = new SolidBrush(Color.FromArgb(120, 20, 26, 44)))
            {
                for (int x = 0; x < W; x += 160)
                {
                    g.DrawLine(seam, x, 70, x, 548);
                    for (int y = 90; y < 540; y += 150) g.FillEllipse(rivet, x + 6, y, 7, 7);
                }
                g.DrawLine(seam, 0, 300, W, 300);
            }

            // pipes with joints
            Pipe(g, 0, 112, W, 18);
            Pipe(g, 0, 478, W, 22);
            for (int x = 90; x < W; x += 300)
            {
                Pipe(g, x, 106, 18, 30);
                Pipe(g, x + 120, 472, 20, 34);
            }

            // windows with the city behind them: the wall is cut away to transparency
            int[] wx = { 110, 770, 1430 };
            foreach (int x in wx)
            {
                Rectangle r = new Rectangle(x, 160, 340, 200);
                g.CompositingMode = CompositingMode.SourceCopy;
                using (SolidBrush clear = new SolidBrush(Color.FromArgb(0, 0, 0, 0)))
                {
                    g.FillRectangle(clear, r);
                }
                g.CompositingMode = CompositingMode.SourceOver;
                using (Pen frame = new Pen(Color.FromArgb(255, 22, 28, 46), 12f))
                using (Pen mull = new Pen(Color.FromArgb(255, 30, 38, 60), 6f))
                using (Pen hi = new Pen(Color.FromArgb(120, 200, 215, 240), 2f))
                {
                    g.DrawRectangle(frame, r.X - 4, r.Y - 4, r.Width + 8, r.Height + 8);
                    g.DrawLine(mull, r.X + r.Width / 3, r.Y, r.X + r.Width / 3, r.Bottom);
                    g.DrawLine(mull, r.X + r.Width * 2 / 3, r.Y, r.X + r.Width * 2 / 3, r.Bottom);
                    g.DrawRectangle(hi, r.X + 4, r.Y + 4, r.Width - 8, r.Height - 8);
                }
            }

            // signs
            using (Font sf = new Font("Impact", 40f, FontStyle.Regular, GraphicsUnit.Pixel))
            using (Font small = new Font("Segoe UI", 14f, FontStyle.Bold, GraphicsUnit.Pixel))
            using (SolidBrush dark = new SolidBrush(Color.FromArgb(255, 30, 36, 52)))
            using (SolidBrush gold = new SolidBrush(Color.FromArgb(255, 235, 190, 40)))
            using (Pen border = new Pen(Color.FromArgb(255, 235, 190, 40), 3f))
            {
                string[] names = { "SECTOR A", "SECTOR B", "SECTOR C" };
                int[] sx = { 520, 1180, 1720 };
                for (int i = 0; i < names.Length; i++)
                {
                    Rectangle r = new Rectangle(sx[i], 380, 190, 70);
                    g.FillRectangle(dark, r);
                    g.DrawRectangle(border, r);
                    g.DrawString(names[i], sf, gold, r.X + 12, r.Y + 8);
                }
                g.DrawString("ОПАСНО: ЛАЗЕРЫ", small, gold, 70, 420);
            }

            // doors
            int[] dx = { 1000, 380, 1560 };
            for (int i = 0; i < 1; i++)
            {
                Rectangle d = new Rectangle(dx[i], 230, 150, 300);
                using (SolidBrush door = new SolidBrush(Color.FromArgb(255, 58, 68, 92)))
                using (Pen dp = new Pen(Color.FromArgb(255, 18, 24, 40), 4f))
                {
                    g.FillRectangle(door, d);
                    g.DrawRectangle(dp, d);
                    g.DrawLine(dp, d.X + d.Width / 2, d.Y, d.X + d.Width / 2, d.Bottom);
                }
                Hazard(g, new Rectangle(d.X, d.Y + 40, d.Width, 16));
                Hazard(g, new Rectangle(d.X, d.Bottom - 56, d.Width, 16));
            }

            // monitors and tanks
            using (SolidBrush screen = new SolidBrush(Color.FromArgb(255, 20, 60, 50)))
            using (Pen line = new Pen(Color.FromArgb(255, 90, 230, 150), 2f))
            using (Pen casing = new Pen(Color.FromArgb(255, 18, 24, 40), 4f))
            {
                for (int i = 0; i < 3; i++)
                {
                    Rectangle m = new Rectangle(560 + i * 90, 210, 76, 56);
                    g.FillRectangle(screen, m);
                    g.DrawRectangle(casing, m);
                    g.DrawLine(line, m.X + 8, m.Y + 40, m.X + 24, m.Y + 20);
                    g.DrawLine(line, m.X + 24, m.Y + 20, m.X + 40, m.Y + 34);
                    g.DrawLine(line, m.X + 40, m.Y + 34, m.X + 66, m.Y + 12);
                }
                for (int i = 0; i < 3; i++)
                {
                    Rectangle t = new Rectangle(1340 + i * 70, 310, 54, 200);
                    using (LinearGradientBrush tank = new LinearGradientBrush(t, Color.FromArgb(150, 210, 230), Color.FromArgb(60, 100, 130), 0f))
                    {
                        g.FillRectangle(tank, t);
                    }
                    g.DrawRectangle(casing, t);
                    g.FillRectangle(Brushes.Transparent, 0, 0, 0, 0);
                }
            }

            // warning triangle and cables
            PointF[] warn = { new PointF(900, 395), new PointF(970, 395), new PointF(935, 335) };
            using (SolidBrush y = new SolidBrush(Color.FromArgb(255, 245, 200, 30)))
            using (Pen p = new Pen(Color.FromArgb(255, 20, 20, 26), 4f))
            using (Pen cable = new Pen(Color.FromArgb(255, 18, 22, 34), 5f))
            using (Font ex = new Font("Impact", 30f, FontStyle.Regular, GraphicsUnit.Pixel))
            {
                g.FillPolygon(y, warn);
                g.DrawPolygon(p, warn);
                g.DrawString("!", ex, Brushes.Black, 926, 350);
                for (int x = 0; x < W; x += 480)
                {
                    g.DrawBezier(cable, x + 40, 140, x + 160, 200, x + 280, 200, x + 400, 140);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakeCeiling()
    {
        int W = 480;
        Bitmap bmp = new Bitmap(W, (int)Ceil, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush lg = new LinearGradientBrush(new Rectangle(0, 0, W, (int)Ceil), Color.FromArgb(24, 30, 48), Color.FromArgb(50, 60, 84), 90f))
            {
                g.FillRectangle(lg, 0, 0, W, (int)Ceil);
            }
            using (Pen seam = new Pen(Color.FromArgb(120, 10, 14, 26), 2f))
            using (SolidBrush lamp = new SolidBrush(Color.FromArgb(255, 255, 240, 150)))
            using (SolidBrush glow = new SolidBrush(Color.FromArgb(60, 255, 240, 150)))
            {
                for (int x = 0; x < W; x += 120) g.DrawLine(seam, x, 0, x, (int)Ceil);
                g.FillRectangle(glow, 150, 56, 180, 14);
                g.FillRectangle(lamp, 180, 58, 120, 8);
            }
            Hazard(g, new Rectangle(0, (int)Ceil - 8, W, 8));
        }
        return bmp;
    }

    private static Bitmap MakeFloor()
    {
        int W = 480;
        int H = AreaH - (int)Floor;
        Bitmap bmp = new Bitmap(W, H, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush lg = new LinearGradientBrush(new Rectangle(0, 0, W, H), Color.FromArgb(72, 82, 108), Color.FromArgb(34, 40, 60), 90f))
            {
                g.FillRectangle(lg, 0, 0, W, H);
            }
            Hazard(g, new Rectangle(0, 0, W, 12));
            using (Pen seam = new Pen(Color.FromArgb(150, 10, 14, 26), 2f))
            using (SolidBrush vent = new SolidBrush(Color.FromArgb(255, 20, 26, 40)))
            {
                for (int x = 0; x < W; x += 160) g.DrawLine(seam, x, 12, x, H);
                for (int x = 30; x < W; x += 160)
                {
                    for (int i = 0; i < 4; i++) g.FillRectangle(vent, x, 24 + i * 8, 70, 4);
                }
            }
        }
        return bmp;
    }

    private static Bitmap MakePipes()
    {
        int W = 1440;
        Bitmap bmp = new Bitmap(W, (int)Ceil, PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (Pen cable = new Pen(Color.FromArgb(255, 14, 18, 30), 4f))
            {
                for (int x = 0; x < W; x += 360)
                {
                    g.DrawBezier(cable, x + 30, 52, x + 110, 76, x + 230, 76, x + 310, 52);
                }
            }
            using (SolidBrush post = new SolidBrush(Color.FromArgb(255, 18, 24, 40)))
            {
                for (int x = 200; x < W; x += 720) g.FillRectangle(post, x, 40, 10, 30);
            }
        }
        return bmp;
    }
}
