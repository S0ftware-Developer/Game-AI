namespace JetpackJoyride;

public struct Particle
{
    public float X, Y, VX, VY, Gravity, Size;
    public float Life, MaxLife;
    public int Kind;                 // 0 smoke, 1 spark, 2 debris
    public Color Color;
}

public struct Popup
{
    public string Text;
    public float X, Y, Life, MaxLife;
    public bool Big;
    public Color Color;
}

/// <summary>
/// Game rules and the fixed-step simulation (1/120 s). The engine talks to bonuses only through BonusManager and
/// receives generated content through ISpawnTarget.
/// </summary>
public sealed class GameEngine : ISpawnTarget
{
    public const float Dt = 1f / 120f;

    public GameState State = GameState.Menu;
    public readonly Player Player = new Player();
    public readonly PhysicsController Physics = new PhysicsController();
    public readonly List<Obstacle> Obstacles = new List<Obstacle>();
    public readonly CoinManager Coins = new CoinManager();
    public readonly List<BonusPickup> Pickups = new List<BonusPickup>();
    public readonly BonusManager Bonuses = new BonusManager();
    public readonly LevelGenerator Generator = new LevelGenerator();
    public readonly ScoreManager Scores = new ScoreManager();
    public readonly List<Particle> Particles = new List<Particle>();
    public readonly List<Popup> Popups = new List<Popup>();

    public bool Thrust;                 // held flight input, set by the window
    public float Scroll;                // distance the world has scrolled, in pixels
    public float Speed;                 // current world speed, px/s
    public float RunTime;               // seconds of simulated play, drives hazards
    public float Clock;                 // keeps running for menu animations
    public int CoinsCollected;
    public int BonusesCollected;
    public bool NewRecord;
    public float DeadTimer;
    public int RunSeed;

    private readonly Random rng = new Random();
    private readonly BonusContext ctx = new BonusContext();
    private readonly List<PointF> collected = new List<PointF>();
    private float deathScroll;
    private int nextMilestone;
    private bool recordAnnounced;
    private float smokeTimer;
    private bool wasThrust;
    private float lastThrustSound;

    public int Meters
    {
        get { return (int)((Player.Dead ? deathScroll : Scroll) / GameConfig.PixelsPerMeter); }
    }

    public int Score
    {
        get { return ScoreManager.Compute(Meters, CoinsCollected, BonusesCollected); }
    }

    public GameEngine()
    {
        ctx.Player = Player;
        ctx.Popup = (text, color) => AddPopup(text, color, false);
        ctx.PlaySound = id => Sfx.Play(id);
        Bonuses.Expired = e => AddPopup(e.Name + " закончился", e.Color, false);
        Scores.Load();
        Player.Reset();
    }

    // ------------------------------------------------------------------ ISpawnTarget

    public void AddObstacle(Obstacle o)
    {
        Obstacles.Add(o);
    }

    public void AddCoin(float x, float y)
    {
        Coins.Add(x, y);
    }

    public void AddBonus(float x, float y, BonusEffect effect)
    {
        BonusPickup p = new BonusPickup();
        p.X = x;
        p.Y = y;
        p.Effect = effect;
        Pickups.Add(p);
    }

    // ------------------------------------------------------------------ flow

    public void StartRun()
    {
        Obstacles.Clear();
        Coins.Clear();
        Pickups.Clear();
        Bonuses.Clear();
        Particles.Clear();
        Popups.Clear();
        Player.Reset();
        Physics.Reset();
        Scroll = 0f;
        Speed = GameConfig.BaseSpeed;
        RunTime = 0f;
        CoinsCollected = 0;
        BonusesCollected = 0;
        NewRecord = false;
        DeadTimer = 0f;
        deathScroll = 0f;
        nextMilestone = GameConfig.MilestoneEveryMeters;
        recordAnnounced = false;
        smokeTimer = 0f;
        wasThrust = false;
        Generator.Reset(GameConfig.Seed, this);
        RunSeed = Generator.Seed;
        Generator.Update(Scroll, 0f);
        State = GameState.Playing;
        Sfx.Play(SfxId.Start);
    }

    public void AutoPause()
    {
        Thrust = false;
        if (State == GameState.Playing) State = GameState.Paused;
    }

    public void HandleKey(Keys key)
    {
        switch (key)
        {
            case Keys.Enter:
                if (State == GameState.Menu || State == GameState.GameOver) StartRun();
                else if (State == GameState.Paused) State = GameState.Playing;
                else if (State == GameState.Playing && Player.Dead && DeadTimer > 0.25f) StartRun();
                break;
            case Keys.R:
                if (State == GameState.Playing || State == GameState.Paused || State == GameState.GameOver) StartRun();
                break;
            case Keys.Escape:
                if (State == GameState.Playing) State = GameState.Paused;
                else if (State == GameState.Paused) State = GameState.Playing;
                else if (State == GameState.GameOver) State = GameState.Menu;
                break;
            case Keys.M:
                if (State == GameState.Paused || State == GameState.GameOver) State = GameState.Menu;
                break;
            case Keys.Space:
                if (State == GameState.Menu) StartRun();
                break;
            case Keys.N:
                Sfx.Muted = !Sfx.Muted;
                break;
        }
    }

    public void GoToMenu()
    {
        State = GameState.Menu;
    }

    // ------------------------------------------------------------------ simulation

    public void Update()
    {
        Clock += Dt;
        if (State == GameState.Menu || State == GameState.Paused) return;
        if (State == GameState.GameOver)
        {
            UpdateEffects(Dt);
            return;
        }

        RunTime += Dt;
        if (!Player.Dead) UpdateRun(Dt);
        else UpdateDeath(Dt);
        UpdateEffects(Dt);
    }

    private void UpdateRun(float dt)
    {
        float meters = Scroll / GameConfig.PixelsPerMeter;
        Speed = GameConfig.SpeedAt(meters) * Bonuses.SpeedMultiplier;
        Scroll += Speed * dt;

        Physics.Step(Player, Thrust, dt);
        Player.AnimTime += dt;
        if (Player.OnFloor) Player.RunPhase += Speed * dt * 0.055f;
        if (Player.Invulnerable > 0f) Player.Invulnerable = Math.Max(0f, Player.Invulnerable - dt);

        if (Thrust && !wasThrust && RunTime - lastThrustSound > 0.25f)
        {
            Sfx.Play(SfxId.Thrust);
            lastThrustSound = RunTime;
        }
        wasThrust = Thrust;

        Bonuses.Update(dt, ctx);
        Generator.Update(Scroll, meters);

        RectangleF box = Player.Hitbox(Scroll);
        Coins.Update(dt, Scroll, box, Bonuses.MagnetRadius);
        CollectCoins(box);
        CollectPickups(box);
        CullWorld();
        CheckHazards(box);
        CheckMilestones();
        EmitExhaust(dt);
    }

    private void CollectCoins(RectangleF box)
    {
        collected.Clear();
        int n = Coins.Collect(box, collected);
        if (n == 0) return;
        CoinsCollected += n;
        Sfx.Play(SfxId.Coin);
        foreach (PointF c in collected)
        {
            for (int i = 0; i < 4; i++) Spark(c.X, c.Y, Color.FromArgb(255, 220, 70), 90f);
            AddPopupAt("+" + GameConfig.CoinPoints, Color.FromArgb(255, 230, 90), c.X - Scroll, c.Y - 18f, false);
        }
    }

    private void CollectPickups(RectangleF box)
    {
        for (int i = Pickups.Count - 1; i >= 0; i--)
        {
            BonusPickup p = Pickups[i];
            if (!Obstacle.CircleHitsRect(p.X, p.Y, GameConfig.BonusRadius, box)) continue;
            Pickups.RemoveAt(i);
            BonusesCollected++;
            Bonuses.Activate(p.Effect, ctx);
            Sfx.Play(SfxId.Bonus);
            AddPopup(p.Effect.Name + "!", p.Effect.Color, true);
            for (int k = 0; k < 14; k++) Spark(p.X, p.Y, p.Effect.Color, 170f);
        }
    }

    private void CullWorld()
    {
        float left = Scroll - 160f;
        for (int i = Obstacles.Count - 1; i >= 0; i--)
        {
            if (Obstacles[i].Right < left) Obstacles.RemoveAt(i);
        }
        for (int i = Pickups.Count - 1; i >= 0; i--)
        {
            if (Pickups[i].X < left) Pickups.RemoveAt(i);
        }
    }

    private void CheckHazards(RectangleF box)
    {
        if (Player.Invulnerable > 0f) return;
        foreach (Obstacle o in Obstacles)
        {
            if (o.X > box.Right + 60f || o.Right < box.Left - 60f) continue;
            if (!o.Hits(box, RunTime)) continue;
            if (Bonuses.TryAbsorbHit(ctx))
            {
                for (int k = 0; k < 18; k++) Spark(box.X + box.Width / 2f, box.Y + box.Height / 2f, Color.FromArgb(120, 240, 255), 200f);
                return;
            }
            Kill();
            return;
        }
    }

    private void Kill()
    {
        Player.Dead = true;
        Player.DeadTime = 0f;
        deathScroll = Scroll;
        DeadTimer = 0f;
        Thrust = false;
        Sfx.Play(SfxId.Crash);
        float cx = Scroll + GameConfig.PlayerScreenX;
        for (int k = 0; k < 26; k++) Spark(cx, Player.Y, (k % 2 == 0) ? Color.FromArgb(255, 200, 60) : Color.FromArgb(255, 110, 30), 280f);
        for (int k = 0; k < 10; k++) Debris(cx, Player.Y);
        Bonuses.Clear();
    }

    private void UpdateDeath(float dt)
    {
        DeadTimer += dt;
        Player.DeadTime += dt;
        Speed = Math.Max(0f, Speed - Speed * 3.2f * dt);
        Scroll += Speed * dt;
        Physics.StepDead(Player, dt);
        if (DeadTimer >= 1.0f) EndRun();
    }

    private void EndRun()
    {
        NewRecord = Score > Scores.BestScore;
        Scores.BestScore = Math.Max(Scores.BestScore, Score);
        Scores.BestDistance = Math.Max(Scores.BestDistance, Meters);
        Scores.Save();
        Sfx.Play(NewRecord ? SfxId.Record : SfxId.GameOver);
        State = GameState.GameOver;
    }

    private void CheckMilestones()
    {
        if (Meters >= nextMilestone)
        {
            AddPopup(nextMilestone + " М!", Color.FromArgb(255, 255, 255), true);
            Sfx.Play(SfxId.Milestone);
            nextMilestone += GameConfig.MilestoneEveryMeters;
        }
        if (!recordAnnounced && Scores.BestScore > 0 && Score > Scores.BestScore)
        {
            recordAnnounced = true;
            AddPopup("НОВЫЙ РЕКОРД!", Color.FromArgb(255, 220, 60), true);
            Sfx.Play(SfxId.Record);
        }
    }

    // ------------------------------------------------------------------ effects

    private void EmitExhaust(float dt)
    {
        smokeTimer -= dt;
        if (smokeTimer > 0f) return;
        smokeTimer = 0.018f;
        float x = Scroll + GameConfig.PlayerScreenX - 26f;
        float y = Player.Y + 20f;
        if (Player.ThrustLevel > 0.2f)
        {
            Particle p = new Particle();
            p.X = x + (float)(rng.NextDouble() * 6.0 - 3.0);
            p.Y = y;
            p.VX = -(float)(rng.NextDouble() * 40.0);
            p.VY = 140f + (float)(rng.NextDouble() * 120.0);
            p.Gravity = -60f;
            p.Size = 5f + (float)rng.NextDouble() * 5f;
            p.MaxLife = 0.5f + (float)rng.NextDouble() * 0.3f;
            p.Life = p.MaxLife;
            p.Kind = 0;
            p.Color = Color.FromArgb(235, 238, 248);
            Particles.Add(p);
        }
    }

    private void Spark(float x, float y, Color c, float speed)
    {
        double a = rng.NextDouble() * Math.PI * 2.0;
        float sp = (float)(rng.NextDouble() * 0.8 + 0.2) * speed;
        Particle p = new Particle();
        p.X = x;
        p.Y = y;
        p.VX = (float)Math.Cos(a) * sp;
        p.VY = (float)Math.Sin(a) * sp;
        p.Gravity = 200f;
        p.Size = 2f + (float)rng.NextDouble() * 3f;
        p.MaxLife = 0.3f + (float)rng.NextDouble() * 0.35f;
        p.Life = p.MaxLife;
        p.Kind = 1;
        p.Color = c;
        Particles.Add(p);
    }

    private void Debris(float x, float y)
    {
        double a = rng.NextDouble() * Math.PI * 2.0;
        float sp = (float)(rng.NextDouble() * 220.0 + 60.0);
        Particle p = new Particle();
        p.X = x;
        p.Y = y;
        p.VX = (float)Math.Cos(a) * sp - 80f;
        p.VY = (float)Math.Sin(a) * sp - 160f;
        p.Gravity = 900f;
        p.Size = 4f + (float)rng.NextDouble() * 5f;
        p.MaxLife = 0.8f + (float)rng.NextDouble() * 0.5f;
        p.Life = p.MaxLife;
        p.Kind = 2;
        p.Color = (rng.Next(2) == 0) ? Color.FromArgb(70, 100, 200) : Color.FromArgb(170, 175, 190);
        Particles.Add(p);
    }

    private void AddPopup(string text, Color color, bool big)
    {
        AddPopupAt(text, color, big ? GameConfig.LogicalW / 2f : GameConfig.PlayerScreenX + 20f,
            big ? 190f : Player.Y - 50f, big);
    }

    private void AddPopupAt(string text, Color color, float x, float y, bool big)
    {
        Popup p = new Popup();
        p.Text = text;
        p.X = x;
        p.Y = y;
        p.MaxLife = big ? 1.3f : 0.8f;
        p.Life = p.MaxLife;
        p.Big = big;
        p.Color = color;
        Popups.Add(p);
    }

    private void UpdateEffects(float dt)
    {
        for (int i = Particles.Count - 1; i >= 0; i--)
        {
            Particle p = Particles[i];
            p.Life -= dt;
            if (p.Life <= 0f)
            {
                Particles.RemoveAt(i);
                continue;
            }
            p.VY += p.Gravity * dt;
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            Particles[i] = p;
        }
        for (int i = Popups.Count - 1; i >= 0; i--)
        {
            Popup p = Popups[i];
            p.Life -= dt;
            if (p.Life <= 0f)
            {
                Popups.RemoveAt(i);
                continue;
            }
            p.Y -= 30f * dt;
            Popups[i] = p;
        }
    }
}
