using System.Drawing.Drawing2D;

namespace JetpackJoyride;

/// <summary>Shared, reusable GDI+ pen and brush for small drawing helpers (single UI thread, never disposed per frame).</summary>
public static class Gfx
{
    private static readonly SolidBrush brush = new SolidBrush(Color.White);
    private static readonly Pen pen = CreatePen();

    private static Pen CreatePen()
    {
        Pen p = new Pen(Color.White, 1f);
        p.StartCap = LineCap.Round;
        p.EndCap = LineCap.Round;
        p.LineJoin = LineJoin.Round;
        return p;
    }

    public static SolidBrush Brush(Color c)
    {
        brush.Color = c;
        return brush;
    }

    public static Pen Pen(Color c, float width)
    {
        pen.Color = c;
        pen.Width = width;
        return pen;
    }
}
