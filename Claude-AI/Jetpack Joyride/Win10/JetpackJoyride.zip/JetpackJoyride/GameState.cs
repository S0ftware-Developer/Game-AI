namespace JetpackJoyride;

public enum GameState { Menu, Playing, Paused, GameOver }
