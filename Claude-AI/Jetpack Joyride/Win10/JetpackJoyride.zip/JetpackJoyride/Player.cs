namespace JetpackJoyride;

/// <summary>The hero's state. Vertical position is the centre of the hitbox; the horizontal screen position is fixed.</summary>
public sealed class Player
{
    public float Y;
    public float VY;
    public float ThrustLevel;       // 0..1, drives the flame
    public bool OnFloor;
    public bool OnCeiling;
    public bool Dead;
    public float DeadTime;
    public float Invulnerable;      // seconds of protection left after a shield absorbed a hit
    public float RunPhase;          // animation
    public float AnimTime;

    public void Reset()
    {
        Y = GameConfig.FloorY - GameConfig.HitH / 2f;
        VY = 0f;
        ThrustLevel = 0f;
        OnFloor = true;
        OnCeiling = false;
        Dead = false;
        DeadTime = 0f;
        Invulnerable = 0f;
        RunPhase = 0f;
        AnimTime = 0f;
    }

    /// <summary>Hitbox in world coordinates for the given scroll position.</summary>
    public RectangleF Hitbox(float scrollX)
    {
        float cx = scrollX + GameConfig.PlayerScreenX;
        return new RectangleF(cx - GameConfig.HitW / 2f, Y - GameConfig.HitH / 2f, GameConfig.HitW, GameConfig.HitH);
    }
}
