namespace JetpackJoyride;

public sealed class Coin
{
    public float X;       // world coordinates
    public float Y;
    public float Phase;   // spin animation offset
}

/// <summary>Owns the coins of the run: spawning, magnet attraction, collection and clean-up.</summary>
public sealed class CoinManager
{
    public readonly List<Coin> Coins = new List<Coin>();

    public void Clear()
    {
        Coins.Clear();
    }

    public void Add(float x, float y)
    {
        Coin c = new Coin();
        c.X = x;
        c.Y = y;
        c.Phase = (x * 0.013f) % 6.28f;
        Coins.Add(c);
    }

    /// <summary>Moves coins toward the hero while a magnet is active.</summary>
    public void Update(float dt, float scrollX, RectangleF hitbox, float magnetRadius)
    {
        for (int i = Coins.Count - 1; i >= 0; i--)
        {
            Coin c = Coins[i];
            if (c.X < scrollX - 80f)
            {
                Coins.RemoveAt(i);
                continue;
            }
            if (magnetRadius > 0f)
            {
                float px = hitbox.X + hitbox.Width / 2f;
                float py = hitbox.Y + hitbox.Height / 2f;
                float dx = px - c.X;
                float dy = py - c.Y;
                float d = MathF.Sqrt(dx * dx + dy * dy);
                if (d < magnetRadius && d > 0.001f)
                {
                    float pull = GameConfig.MagnetPullSpeed * (1f - 0.5f * d / magnetRadius);
                    float step = Math.Min(d, pull * dt);
                    c.X += dx / d * step;
                    c.Y += dy / d * step;
                }
            }
        }
    }

    /// <summary>Removes and counts the coins touching the hitbox. Positions of the collected coins are returned.</summary>
    public int Collect(RectangleF hitbox, List<PointF> collected)
    {
        int n = 0;
        for (int i = Coins.Count - 1; i >= 0; i--)
        {
            Coin c = Coins[i];
            if (Obstacle.CircleHitsRect(c.X, c.Y, GameConfig.CoinRadius, hitbox))
            {
                collected.Add(new PointF(c.X, c.Y));
                Coins.RemoveAt(i);
                n++;
            }
        }
        return n;
    }
}
