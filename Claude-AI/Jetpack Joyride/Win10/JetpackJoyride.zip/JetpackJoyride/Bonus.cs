namespace JetpackJoyride;

/// <summary>What a bonus is allowed to touch. Bonuses never reach into the game engine directly.</summary>
public sealed class BonusContext
{
    public Player Player = null!;
    public Action<string, Color> Popup = (text, color) => { };
    public Action<SfxId> PlaySound = id => { };
}

/// <summary>
/// Base class of every power-up. To add a new bonus:
///   1. derive a class from BonusEffect (see BonusEffects.cs) and override what it needs;
///   2. register it once in BonusRegistry (one line).
/// The engine only talks to bonuses through BonusManager and this class: no bonus-specific code in the game loop.
/// </summary>
public abstract class BonusEffect
{
    public abstract string Id { get; }
    public abstract string Name { get; }
    public abstract Color Color { get; }
    public abstract float Duration { get; }          // seconds the effect lasts

    public float Remaining;                          // managed by BonusManager
    public bool Consumed;                            // an effect may end early by setting this

    // ---- lifecycle hooks (all optional)
    public virtual void OnActivate(BonusContext ctx) { }
    public virtual void OnUpdate(float dt, BonusContext ctx) { }
    public virtual void OnExpire(BonusContext ctx) { }

    // ---- gameplay modifiers; BonusManager combines them over all active effects
    public virtual float SpeedMultiplier { get { return 1f; } }
    public virtual float MagnetRadius { get { return 0f; } }
    /// <summary>Called when the hero touches a hazard. Return true to absorb the hit.</summary>
    public virtual bool AbsorbHit(BonusContext ctx) { return false; }

    // ---- visuals
    public abstract void DrawIcon(Graphics g, RectangleF r);
    public virtual void DrawAura(Graphics g, PointF center, float time) { }
}

/// <summary>A collectible bonus sitting in the world.</summary>
public sealed class BonusPickup
{
    public float X;                  // world coordinates
    public float Y;
    public BonusEffect Effect = null!;
}

/// <summary>Lists every bonus that can spawn. Add one line to register a new bonus.</summary>
public static class BonusRegistry
{
    public sealed class Entry
    {
        public readonly string Id;
        public readonly int Weight;
        public readonly Func<BonusEffect> Create;
        public Entry(string id, int weight, Func<BonusEffect> create)
        {
            Id = id;
            Weight = weight;
            Create = create;
        }
    }

    public static readonly List<Entry> All = new List<Entry>
    {
        new Entry("magnet", 3, () => new MagnetEffect()),
        new Entry("shield", 3, () => new ShieldEffect()),
        new Entry("boost", 2, () => new SpeedBoostEffect()),
        // new Entry("myBonus", 2, () => new MyBonusEffect()),
    };

    public static BonusEffect PickRandom(Random rng)
    {
        int total = 0;
        foreach (Entry e in All) total += e.Weight;
        int roll = rng.Next(total);
        foreach (Entry e in All)
        {
            roll -= e.Weight;
            if (roll < 0) return e.Create();
        }
        return All[0].Create();
    }
}
