namespace JetpackJoyride;

/// <summary>
/// Every tunable number of the game in one place: layout, flight physics, world speed, scoring, bonuses and
/// obstacle generation. Change a value here and nothing else needs to be touched.
/// </summary>
public static class GameConfig
{
    // ---- layout (logical pixels)
    public const int LogicalW = 960;
    public const int LogicalH = 640;
    public const int FooterH = 32;
    public const float CeilingY = 70f;        // lower edge of the ceiling: the top boundary of the playable area
    public const float FloorY = 548f;         // surface of the floor: the bottom boundary
    public const float PlayerScreenX = 220f;  // the hero stays at this x on screen, the world scrolls past

    // ---- hero hitbox (centred on the hero's position)
    public const float HitW = 22f;
    public const float HitH = 46f;

    // ---- flight physics (pixels and seconds, y grows downward)
    public const float Gravity = 1400f;          // downward acceleration while the jetpack is off
    public const float ThrustAccel = 3400f;      // upward acceleration while it is on (net upward = 2000)
    public const float MaxUpSpeed = 520f;
    public const float MaxDownSpeed = 640f;
    public const float ThrustRampTime = 0.05f;   // the thrust fades in over this time; releasing cuts it at once

    // ---- world speed and distance
    public const float BaseSpeed = 330f;         // px/s at the start
    public const float MaxSpeed = 620f;
    public const float SpeedGainPerMeter = 1.04f;
    public const float PixelsPerMeter = 50f;

    // ---- scoring: Score = meters * DistancePoints + coins * CoinPoints + bonuses * BonusPoints
    public const int DistancePoints = 1;
    public const int CoinPoints = 10;
    public const int BonusPoints = 50;
    public const int MilestoneEveryMeters = 250;

    // ---- bonuses
    public const float MagnetDuration = 8f;
    public const float MagnetRadius = 260f;
    public const float MagnetPullSpeed = 900f;
    public const float ShieldMaxDuration = 15f;  // the shield also disappears after absorbing one hit
    public const float ShieldInvulnerability = 1.2f;
    public const float BoostDuration = 6f;
    public const float BoostMultiplier = 1.3f;

    // ---- collectibles
    public const float CoinRadius = 15f;
    public const float BonusRadius = 24f;

    // ---- generation
    public const float FirstPatternX = 1400f;    // an empty warm-up stretch at the start of a run
    public const int BonusEveryPatterns = 5;
    public static int Seed = 0;                  // 0 = a new random seed for every run; set with --seed N

    /// <summary>World speed in px/s for the given distance (meters), without bonuses.</summary>
    public static float SpeedAt(float meters)
    {
        return Math.Min(MaxSpeed, BaseSpeed + SpeedGainPerMeter * meters);
    }

    /// <summary>Difficulty tier 0..3 chosen from the distance.</summary>
    public static int TierAt(float meters)
    {
        if (meters < 120f) return 0;
        if (meters < 350f) return 1;
        if (meters < 700f) return 2;
        return 3;
    }
}
