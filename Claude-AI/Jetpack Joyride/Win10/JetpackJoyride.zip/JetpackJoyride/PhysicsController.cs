namespace JetpackJoyride;

/// <summary>
/// Vertical flight physics on a fixed time step. While the jetpack is on, an upward acceleration is applied on
/// top of gravity; the velocity is clamped and the position is kept inside the playable area.
/// </summary>
public sealed class PhysicsController
{
    private float thrustLevel;

    public void Reset()
    {
        thrustLevel = 0f;
    }

    public void Step(Player p, bool thrustHeld, float dt)
    {
        // thrust ramps up smoothly but is cut immediately when the button is released
        if (thrustHeld) thrustLevel = Math.Min(1f, thrustLevel + dt / GameConfig.ThrustRampTime);
        else thrustLevel = 0f;
        p.ThrustLevel = thrustLevel;

        float ay = GameConfig.Gravity - GameConfig.ThrustAccel * thrustLevel;
        p.VY += ay * dt;
        if (p.VY < -GameConfig.MaxUpSpeed) p.VY = -GameConfig.MaxUpSpeed;
        if (p.VY > GameConfig.MaxDownSpeed) p.VY = GameConfig.MaxDownSpeed;
        p.Y += p.VY * dt;

        float top = GameConfig.CeilingY + GameConfig.HitH / 2f;
        float bottom = GameConfig.FloorY - GameConfig.HitH / 2f;
        p.OnCeiling = false;
        p.OnFloor = false;
        if (p.Y <= top)
        {
            p.Y = top;
            if (p.VY < 0f) p.VY = 0f;
            p.OnCeiling = true;
        }
        else if (p.Y >= bottom)
        {
            p.Y = bottom;
            if (p.VY > 0f) p.VY = 0f;
            p.OnFloor = true;
        }
    }

    /// <summary>After death the hero just falls: gravity only, no thrust.</summary>
    public void StepDead(Player p, float dt)
    {
        thrustLevel = 0f;
        p.ThrustLevel = 0f;
        p.VY = Math.Min(GameConfig.MaxDownSpeed, p.VY + GameConfig.Gravity * dt);
        p.Y += p.VY * dt;
        float bottom = GameConfig.FloorY - GameConfig.HitH / 2f;
        if (p.Y >= bottom)
        {
            p.Y = bottom;
            p.VY = 0f;
            p.OnFloor = true;
        }
    }
}
