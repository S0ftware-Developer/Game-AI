namespace JetpackJoyride;

/// <summary>Base class of every hazard. All positions are in world coordinates; time is the run time in seconds.</summary>
public abstract class Obstacle
{
    public float X;                                           // left edge, world x
    public abstract float Right { get; }                      // right edge, used for removal
    public abstract bool Hits(RectangleF box, float time);

    protected static float Smooth(float u)
    {
        float tri = u < 0.5f ? u * 2f : 2f - u * 2f;
        return tri * tri * (3f - 2f * tri);
    }

    protected static float Phase01(float time, float period, float phase)
    {
        float u = (time / period + phase) % 1f;
        return u < 0f ? u + 1f : u;
    }

    public static bool CircleHitsRect(float cx, float cy, float r, RectangleF rect)
    {
        float nx = Math.Max(rect.Left, Math.Min(cx, rect.Right));
        float ny = Math.Max(rect.Top, Math.Min(cy, rect.Bottom));
        float dx = cx - nx;
        float dy = cy - ny;
        return dx * dx + dy * dy <= r * r;
    }
}

public enum LaserState { Off, Warning, On }

/// <summary>An axis-aligned laser beam between two emitters. It can be always on or follow an off / warning / on cycle.</summary>
public sealed class LaserBeam : Obstacle
{
    public readonly float X1, Y1, X2, Y2;
    public readonly bool Timed;
    public readonly float OffTime, WarnTime, OnTime, Phase;

    public LaserBeam(float x1, float y1, float x2, float y2)
    {
        X1 = x1; Y1 = y1; X2 = x2; Y2 = y2;
        X = Math.Min(x1, x2);
        Timed = false;
    }

    public LaserBeam(float x1, float y1, float x2, float y2, float offTime, float warnTime, float onTime, float phase)
    {
        X1 = x1; Y1 = y1; X2 = x2; Y2 = y2;
        X = Math.Min(x1, x2);
        Timed = true;
        OffTime = offTime; WarnTime = warnTime; OnTime = onTime; Phase = phase;
    }

    public override float Right { get { return Math.Max(X1, X2) + 10f; } }

    public LaserState StateAt(float time)
    {
        if (!Timed) return LaserState.On;
        float cycle = OffTime + WarnTime + OnTime;
        float t = (time + Phase) % cycle;
        if (t < 0f) t += cycle;
        if (t < OffTime) return LaserState.Off;
        if (t < OffTime + WarnTime) return LaserState.Warning;
        return LaserState.On;
    }

    public override bool Hits(RectangleF box, float time)
    {
        if (StateAt(time) != LaserState.On) return false;
        RectangleF r = new RectangleF(Math.Min(X1, X2) - 4f, Math.Min(Y1, Y2) - 4f, Math.Abs(X2 - X1) + 8f, Math.Abs(Y2 - Y1) + 8f);
        return r.IntersectsWith(box);
    }
}

/// <summary>An electric barrier: a bar between two nodes with a ring of sparks. Always dangerous.</summary>
public sealed class ElectricBarrier : Obstacle
{
    public const float Thickness = 7f;
    public readonly float X1, Y1, X2, Y2;

    public ElectricBarrier(float x1, float y1, float x2, float y2)
    {
        X1 = x1; Y1 = y1; X2 = x2; Y2 = y2;
        X = Math.Min(x1, x2);
    }

    public override float Right { get { return Math.Max(X1, X2) + 12f; } }

    public override bool Hits(RectangleF box, float time)
    {
        float dx = X2 - X1;
        float dy = Y2 - Y1;
        float len = MathF.Sqrt(dx * dx + dy * dy);
        int steps = Math.Max(1, (int)(len / 6f));
        for (int i = 0; i <= steps; i++)
        {
            float f = i / (float)steps;
            if (CircleHitsRect(X1 + dx * f, Y1 + dy * f, Thickness, box)) return true;
        }
        return false;
    }
}

/// <summary>A hydraulic arm sliding out of the ceiling or the floor and back on a fixed rhythm.</summary>
public sealed class Piston : Obstacle
{
    public const float RodWidth = 14f;
    public const float HeadW = 58f;
    public const float HeadH = 26f;

    public readonly float CenterX;
    public readonly bool FromTop;
    public readonly float MinExt, MaxExt, Period, Phase;

    public Piston(float centerX, bool fromTop, float minExt, float maxExt, float period, float phase)
    {
        CenterX = centerX;
        X = centerX - HeadW / 2f;
        FromTop = fromTop;
        MinExt = minExt; MaxExt = maxExt; Period = period; Phase = phase;
    }

    public override float Right { get { return CenterX + HeadW / 2f; } }

    public float ExtensionAt(float time)
    {
        return MinExt + (MaxExt - MinExt) * Smooth(Phase01(time, Period, Phase));
    }

    public override bool Hits(RectangleF box, float time)
    {
        float e = ExtensionAt(time);
        RectangleF rod, head;
        if (FromTop)
        {
            float baseY = GameConfig.CeilingY;
            rod = new RectangleF(CenterX - RodWidth / 2f, baseY, RodWidth, e);
            head = new RectangleF(CenterX - HeadW / 2f, baseY + e - HeadH, HeadW, HeadH);
        }
        else
        {
            float baseY = GameConfig.FloorY;
            rod = new RectangleF(CenterX - RodWidth / 2f, baseY - e, RodWidth, e);
            head = new RectangleF(CenterX - HeadW / 2f, baseY - e, HeadW, HeadH);
        }
        return rod.IntersectsWith(box) || head.IntersectsWith(box);
    }
}

/// <summary>A rotating two-blade rotor on a fixed axis.</summary>
public sealed class Spinner : Obstacle
{
    public const float ArmLength = 58f;
    public const float Omega = 3.2f;          // rad/s

    public readonly float CenterX, CenterY;

    public Spinner(float cx, float cy)
    {
        CenterX = cx;
        CenterY = cy;
        X = cx - ArmLength - 14f;
    }

    public override float Right { get { return CenterX + ArmLength + 14f; } }

    public static float AngleAt(float time)
    {
        return Omega * time;
    }

    public override bool Hits(RectangleF box, float time)
    {
        float a = AngleAt(time);
        float cs = MathF.Cos(a);
        float sn = MathF.Sin(a);
        if (CircleHitsRect(CenterX, CenterY, 9f, box)) return true;
        for (int k = 1; k <= 5; k++)
        {
            float f = ArmLength * k / 5f;
            float r = (k == 5) ? 13f : 8f;
            if (CircleHitsRect(CenterX + cs * f, CenterY + sn * f, r, box)) return true;
            if (CircleHitsRect(CenterX - cs * f, CenterY - sn * f, r, box)) return true;
        }
        return false;
    }
}

/// <summary>A machine block that slides up and down a shaft.</summary>
public sealed class MovingBarrier : Obstacle
{
    public const float W = 46f;
    public const float H = 100f;

    public readonly float CenterX, MinY, MaxY, Period, Phase;

    public MovingBarrier(float centerX, float minY, float maxY, float period, float phase)
    {
        CenterX = centerX;
        X = centerX - W / 2f;
        MinY = minY; MaxY = maxY; Period = period; Phase = phase;
    }

    public override float Right { get { return CenterX + W / 2f; } }

    public float CenterYAt(float time)
    {
        return MinY + (MaxY - MinY) * Smooth(Phase01(time, Period, Phase));
    }

    public override bool Hits(RectangleF box, float time)
    {
        float cy = CenterYAt(time);
        RectangleF r = new RectangleF(CenterX - W / 2f, cy - H / 2f, W, H);
        return r.IntersectsWith(box);
    }
}
