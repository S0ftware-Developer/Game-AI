namespace JetpackJoyride;

/// <summary>Where the generator puts things. The game engine implements it.</summary>
public interface ISpawnTarget
{
    void AddObstacle(Obstacle o);
    void AddCoin(float x, float y);
    void AddBonus(float x, float y, BonusEffect effect);
}

/// <summary>
/// Builds the run from hand-designed patterns instead of random single objects. Each pattern keeps its own safe
/// corridor wide enough for the hero, reports where the safe path ends ("exit y"), and the generator keeps a
/// minimum distance between patterns so there is always time to react and recover. Random numbers are used only to
/// choose and vary patterns, and only here (never in physics or collisions), so a seed reproduces a run exactly.
/// </summary>
public sealed class LevelGenerator
{
    private sealed class PatternDef
    {
        public readonly string Name;
        public readonly int MinTier;
        public readonly int Weight;
        public readonly Func<float, int, (float Length, float ExitY)> Build;

        public PatternDef(string name, int minTier, int weight, Func<float, int, (float, float)> build)
        {
            Name = name;
            MinTier = minTier;
            Weight = weight;
            Build = build;
        }
    }

    private const float Top = GameConfig.CeilingY;
    private const float Bottom = GameConfig.FloorY;
    private const float Mid = (Top + Bottom) / 2f;

    private readonly List<PatternDef> patterns = new List<PatternDef>();
    private Random rng;
    private ISpawnTarget target = null!;
    private float nextX;
    private float lastExitY;
    private int patternCount;
    private string lastPattern = "";

    public int Seed { get; private set; }

    public LevelGenerator()
    {
        rng = new Random(0);
        patterns.Add(new PatternDef("LaserLow", 0, 4, LaserLow));
        patterns.Add(new PatternDef("LaserHigh", 0, 4, LaserHigh));
        patterns.Add(new PatternDef("LaserMid", 0, 3, LaserMid));
        patterns.Add(new PatternDef("CoinWave", 0, 3, CoinWave));
        patterns.Add(new PatternDef("ZapperDiagonal", 1, 3, ZapperDiagonal));
        patterns.Add(new PatternDef("NarrowPassage", 1, 3, NarrowPassage));
        patterns.Add(new PatternDef("PistonPair", 1, 3, PistonPair));
        patterns.Add(new PatternDef("SpinnerOverpass", 1, 3, SpinnerOverpass));
        patterns.Add(new PatternDef("MovingBarrier", 1, 3, MovingBarrierShaft));
        patterns.Add(new PatternDef("ZigZag", 2, 3, ZigZag));
        patterns.Add(new PatternDef("TimedLaserPair", 2, 3, TimedLaserPair));
        patterns.Add(new PatternDef("LaserThenPiston", 2, 3, LaserThenPiston));
    }

    /// <summary>Starts a new run. A seed of 0 picks a random one.</summary>
    public void Reset(int seed, ISpawnTarget spawnTarget)
    {
        Seed = seed != 0 ? seed : (Environment.TickCount & 0x7fffffff) + 1;
        rng = new Random(Seed);
        target = spawnTarget;
        nextX = GameConfig.FirstPatternX;
        lastExitY = Mid;
        patternCount = 0;
        lastPattern = "";
    }

    /// <summary>Creates patterns until the world is filled a little beyond the right edge of the screen.</summary>
    public void Update(float scrollX, float meters)
    {
        while (nextX < scrollX + GameConfig.LogicalW + 500f)
        {
            int tier = GameConfig.TierAt((nextX - scrollX) / GameConfig.PixelsPerMeter + meters);
            PatternDef p = Choose(tier);
            (float length, float exitY) = p.Build(nextX, tier);
            lastExitY = exitY;
            lastPattern = p.Name;
            patternCount++;

            float futureMeters = meters + (nextX + length - scrollX) / GameConfig.PixelsPerMeter;
            float spacing = Spacing(futureMeters);
            if (patternCount % GameConfig.BonusEveryPatterns == 0)
            {
                // a bonus in the quiet gap after a pattern, on the line the hero is already flying along
                float by = Math.Max(Top + 60f, Math.Min(Bottom - 60f, exitY));
                target.AddBonus(nextX + length + spacing / 2f, by, BonusRegistry.PickRandom(rng));
            }
            nextX += length + spacing;
        }
    }

    /// <summary>
    /// Distance between patterns. It is sized for the fastest case (speed boost active): at least about 0.75 s of
    /// flying time, so the hero can always climb or descend to the next safe corridor.
    /// </summary>
    public static float Spacing(float meters)
    {
        float speed = GameConfig.SpeedAt(meters) * GameConfig.BoostMultiplier;
        return Math.Max(520f, speed * 0.75f);
    }

    private PatternDef Choose(int tier)
    {
        int total = 0;
        foreach (PatternDef p in patterns)
        {
            if (p.MinTier > tier || p.Name == lastPattern) continue;
            total += Weight(p, tier);
        }
        int roll = rng.Next(Math.Max(1, total));
        foreach (PatternDef p in patterns)
        {
            if (p.MinTier > tier || p.Name == lastPattern) continue;
            roll -= Weight(p, tier);
            if (roll < 0) return p;
        }
        return patterns[0];
    }

    private static int Weight(PatternDef p, int tier)
    {
        // the introductory patterns become rarer as harder ones appear
        return p.MinTier == 0 ? Math.Max(1, p.Weight - tier) : p.Weight;
    }

    // ------------------------------------------------------------------ coin helpers

    private void CoinLine(float x0, float y0, float x1, float y1, int count)
    {
        for (int i = 0; i < count; i++)
        {
            float f = count == 1 ? 0f : i / (float)(count - 1);
            target.AddCoin(x0 + (x1 - x0) * f, y0 + (y1 - y0) * f);
        }
    }

    private float Clamp(float v, float lo, float hi)
    {
        return Math.Max(lo, Math.Min(hi, v));
    }

    // ------------------------------------------------------------------ patterns
    // every Build method returns (length of the pattern, y where the safe path ends)

    private (float, float) LaserLow(float x, int tier)
    {
        float y = rng.Next(385, 445);
        float len = 240 + tier * 20;
        target.AddObstacle(new LaserBeam(x + 80f, y, x + 80f + len, y));
        float safeY = y - 100f;
        CoinLine(x + 60f, safeY, x + 100f + len, safeY, 7);
        return (len + 200f, safeY);
    }

    private (float, float) LaserHigh(float x, int tier)
    {
        float y = rng.Next(170, 235);
        float len = 240 + tier * 20;
        target.AddObstacle(new LaserBeam(x + 80f, y, x + 80f + len, y));
        float safeY = y + 105f;
        CoinLine(x + 60f, safeY, x + 100f + len, safeY, 7);
        return (len + 200f, safeY);
    }

    private (float, float) LaserMid(float x, int tier)
    {
        float y = rng.Next(270, 350);
        float len = 200 + tier * 20;
        target.AddObstacle(new LaserBeam(x + 80f, y, x + 80f + len, y));
        float safeY = y - 95f;
        for (int i = 0; i < 7; i++)
        {
            float f = i / 6f;
            target.AddCoin(x + 60f + (len + 40f) * f, safeY - 26f * MathF.Sin(f * MathF.PI));
        }
        return (len + 200f, safeY);
    }

    private (float, float) CoinWave(float x, int tier)
    {
        float c = Clamp(rng.Next(210, 420), lastExitY - 120f, lastExitY + 120f);
        c = Clamp(c, 180f, 440f);
        for (int i = 0; i < 12; i++)
        {
            target.AddCoin(x + 40f + i * 38f, c + 80f * MathF.Sin(i * 0.55f));
        }
        return (520f, c + 80f * MathF.Sin(11 * 0.55f));
    }

    private (float, float) ZapperDiagonal(float x, int tier)
    {
        float y1 = rng.Next(150, 300);
        float y2 = rng.Next(150, 300);
        target.AddObstacle(new ElectricBarrier(x + 80f, y1, x + 250f, y2));
        CoinLine(x + 40f, 430f, x + 300f, 430f, 7);
        return (380f, 430f);
    }

    private (float, float) NarrowPassage(float x, int tier)
    {
        float half = tier <= 1 ? 92f : (tier == 2 ? 80f : 70f);
        float gc = Clamp(rng.Next(230, 390), lastExitY - 200f, lastExitY + 200f);
        gc = Clamp(gc, 210f, 410f);
        float gc2 = Clamp(gc + rng.Next(-60, 61), 210f, 410f);
        target.AddObstacle(new ElectricBarrier(x + 80f, Top, x + 80f, gc - half));
        target.AddObstacle(new ElectricBarrier(x + 80f, Bottom, x + 80f, gc + half));
        target.AddObstacle(new ElectricBarrier(x + 300f, Top, x + 300f, gc2 - half));
        target.AddObstacle(new ElectricBarrier(x + 300f, Bottom, x + 300f, gc2 + half));
        CoinLine(x + 80f, gc, x + 300f, gc2, 6);
        return (440f, gc2);
    }

    private (float, float) PistonPair(float x, int tier)
    {
        float period = 3.0f - 0.1f * tier;
        float ph = (float)rng.NextDouble();
        target.AddObstacle(new Piston(x + 140f, true, 60f, 230f, period, ph));
        target.AddObstacle(new Piston(x + 140f, false, 60f, 230f, period, ph + 0.5f));
        CoinLine(x + 20f, Mid, x + 100f, Mid, 4);
        return (340f, Mid);
    }

    private (float, float) SpinnerOverpass(float x, int tier)
    {
        float cy = rng.Next(260, 360);
        target.AddObstacle(new Spinner(x + 170f, cy));
        float safeY = cy - 115f;
        CoinLine(x + 60f, safeY, x + 280f, safeY, 6);
        return (380f, safeY);
    }

    private (float, float) MovingBarrierShaft(float x, int tier)
    {
        float period = 2.4f - 0.1f * tier;
        float ph = (float)rng.NextDouble();
        target.AddObstacle(new MovingBarrier(x + 150f, 190f, 430f, period, ph));
        float length = 340f;
        if (tier >= 2)
        {
            target.AddObstacle(new MovingBarrier(x + 380f, 190f, 430f, period, ph + 0.5f));
            length = 560f;
        }
        CoinLine(x + 20f, Mid, x + 100f, Mid, 4);
        return (length, Mid);
    }

    private (float, float) ZigZag(float x, int tier)
    {
        // low corridor (y > 330), then high corridor (y < 288), then low again: a 42 px change in 0.3 s at top speed
        target.AddObstacle(new ElectricBarrier(x + 80f, Top, x + 80f, 300f));
        target.AddObstacle(new ElectricBarrier(x + 300f, Bottom, x + 300f, 325f));
        target.AddObstacle(new ElectricBarrier(x + 520f, Top, x + 520f, 300f));
        CoinLine(x + 20f, 440f, x + 130f, 440f, 4);
        CoinLine(x + 220f, 200f, x + 360f, 200f, 4);
        CoinLine(x + 460f, 440f, x + 580f, 440f, 4);
        return (660f, 440f);
    }

    private (float, float) TimedLaserPair(float x, int tier)
    {
        // cycle 3.0 s: the top laser is on while the bottom one is off and vice versa, so one half is always free
        float ph = (float)rng.NextDouble() * 3f;
        target.AddObstacle(new LaserBeam(x + 120f, Top, x + 120f, 330f, 1.2f, 0.6f, 1.2f, ph));
        target.AddObstacle(new LaserBeam(x + 120f, Bottom, x + 120f, 298f, 1.2f, 0.6f, 1.2f, ph + 1.5f));
        CoinLine(x + 20f, Mid, x + 90f, Mid, 4);
        return (360f, Mid);
    }

    private (float, float) LaserThenPiston(float x, int tier)
    {
        target.AddObstacle(new LaserBeam(x + 60f, 190f, x + 260f, 190f));
        CoinLine(x + 60f, 300f, x + 260f, 300f, 6);
        float ph = (float)rng.NextDouble();
        target.AddObstacle(new Piston(x + 520f, false, 100f, 260f, 2.6f, ph));
        CoinLine(x + 440f, 240f, x + 600f, 240f, 5);
        return (660f, 240f);
    }
}
