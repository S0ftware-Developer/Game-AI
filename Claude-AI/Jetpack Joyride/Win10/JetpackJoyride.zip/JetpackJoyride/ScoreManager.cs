namespace JetpackJoyride;

/// <summary>The one place that knows the scoring formula, plus best-result persistence (optional, never required).</summary>
public sealed class ScoreManager
{
    public int BestScore;
    public int BestDistance;

    private static string SavePath
    {
        get
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "JetpackJoyride", "best.txt");
        }
    }

    public static int Compute(int meters, int coins, int bonuses)
    {
        return meters * GameConfig.DistancePoints + coins * GameConfig.CoinPoints + bonuses * GameConfig.BonusPoints;
    }

    public void Load()
    {
        try
        {
            string path = SavePath;
            if (!File.Exists(path)) return;
            string[] parts = File.ReadAllText(path).Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length >= 2)
            {
                int s, d;
                if (int.TryParse(parts[0], out s) && int.TryParse(parts[1], out d))
                {
                    BestScore = Math.Max(0, s);
                    BestDistance = Math.Max(0, d);
                }
            }
        }
        catch (Exception)
        {
            // saving is optional: the game works without it
        }
    }

    public void Save()
    {
        try
        {
            string path = SavePath;
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            File.WriteAllText(path, BestScore + " " + BestDistance);
        }
        catch (Exception)
        {
        }
    }
}
