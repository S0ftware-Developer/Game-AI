namespace JetpackJoyride;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        try
        {
            // optional: "--seed 12345" makes the obstacle sequence reproducible for testing
            for (int i = 0; i + 1 < args.Length; i++)
            {
                if (args[i] == "--seed" && int.TryParse(args[i + 1], out int seed)) GameConfig.Seed = seed;
            }
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new GameForm());
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString(), "Jetpack Joyride - критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
