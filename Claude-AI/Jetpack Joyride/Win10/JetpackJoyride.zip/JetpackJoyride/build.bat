@echo off
rem Re-launch inside "cmd /k" so that every message stays visible if something goes wrong.
if not "%~1"=="child" cmd /k ""%~f0" child" & exit /b

setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "PUB=%~dp0bin\Release\net8.0-windows\win-x64\publish"
set "EXE=%PUB%\JetpackJoyride.exe"
set "RESULT=1"

echo ==============================================
echo   Jetpack Joyride - build
echo ==============================================
echo.

rem 1. dotnet available?
where dotnet >nul 2>&1
if errorlevel 1 goto :nodotnet

rem 2. SDK major version 8 or newer (SDK 9 and 10 are fine too)
set "SDKMAJOR=0"
for /f "tokens=1 delims=. " %%M in ('dotnet --version 2^>nul') do set "SDKMAJOR=%%M"
set /a SDKNUM=SDKMAJOR
if !SDKNUM! LSS 8 goto :nosdk
echo Using .NET SDK major version !SDKNUM!.
echo Note: the first build needs internet access to download the .NET 8 runtime packs (NuGet).
echo.

if not exist "%~dp0JetpackJoyride.csproj" goto :noproject

rem 3. remove the previous publish folder
if exist "%PUB%" echo Removing previous publish folder...
if exist "%PUB%" rmdir /s /q "%PUB%"
if exist "%PUB%" goto :cantremove

rem 4. publish
echo Publishing... this can take a minute.
dotnet publish "%~dp0JetpackJoyride.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishTrimmed=false
set "RC=!errorlevel!"
if not "!RC!"=="0" goto :pubfail

rem 5. verify the executable
if not exist "%PUB%" goto :nopub
if not exist "%EXE%" goto :noexe
set "SIZE=0"
for %%F in ("%EXE%") do set "SIZE=%%~zF"
if "!SIZE!"=="0" goto :emptyexe

rem 6. keep only the executable in the publish folder
for %%F in ("%PUB%\*") do if /i not "%%~nxF"=="JetpackJoyride.exe" del /f /q "%%F" >nul 2>&1
for /d %%D in ("%PUB%\*") do rmdir /s /q "%%D" >nul 2>&1

rem 7. exactly one file, and it is JetpackJoyride.exe
set "COUNT=0"
set "ONLY="
for /f "delims=" %%F in ('dir /b /a "%PUB%"') do set /a COUNT+=1 & set "ONLY=%%F"
if not "!COUNT!"=="1" goto :badcount
if /i not "!ONLY!"=="JetpackJoyride.exe" goto :badfile

echo.
echo ==============================================
echo   BUILD SUCCEEDED
echo   Game: %EXE%
echo   Size: !SIZE! bytes
echo   The publish folder contains exactly one file.
echo ==============================================
set "RESULT=0"
goto :end

:nodotnet
echo ERROR: "dotnet" was not found. Install the .NET SDK 8 or newer:
echo https://dotnet.microsoft.com/download/dotnet/8.0
goto :fail
:nosdk
echo ERROR: the installed .NET SDK is older than version 8. Installed SDKs:
dotnet --list-sdks
echo Install the .NET SDK 8 or newer: https://dotnet.microsoft.com/download/dotnet/8.0
goto :fail
:noproject
echo ERROR: JetpackJoyride.csproj was not found next to build.bat.
goto :fail
:cantremove
echo ERROR: could not remove the old publish folder. Close JetpackJoyride.exe if it is running.
goto :fail
:pubfail
echo ERROR: dotnet publish failed with exit code !RC!. Read the messages above.
echo If you see NuGet or download errors, check your internet connection:
echo the first self-contained build must download the .NET 8 runtime packs.
goto :fail
:nopub
echo ERROR: the publish folder was not created.
goto :fail
:noexe
echo ERROR: the expected JetpackJoyride.exe was not produced.
goto :fail
:emptyexe
echo ERROR: JetpackJoyride.exe is empty.
goto :fail
:badcount
echo ERROR: the publish folder should contain exactly one file but contains !COUNT!.
goto :fail
:badfile
echo ERROR: the remaining file is "!ONLY!", expected JetpackJoyride.exe.
goto :fail

:fail
echo.
echo ==============================================
echo   BUILD FAILED
echo ==============================================

:end
echo.
pause
exit %RESULT%
