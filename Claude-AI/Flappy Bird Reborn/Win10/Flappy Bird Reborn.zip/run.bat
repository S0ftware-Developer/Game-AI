@echo off
dotnet build -c Release || pause
start "" "bin\Release\net8.0-windows\FlappyBirdReborn.exe"
