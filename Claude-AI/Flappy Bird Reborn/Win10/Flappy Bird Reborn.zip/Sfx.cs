using System;
using System.Collections.Generic;
using System.IO;
using System.Media;

namespace FlappyBirdReborn
{
    /// <summary>
    /// Tiny sound engine: synthesises short WAV clips in memory and plays them with
    /// System.Media.SoundPlayer. Every call is wrapped in try/catch, so the game stays
    /// fully playable if audio is unavailable.
    /// </summary>
    internal sealed class Sfx
    {
        private readonly Dictionary<string, SoundPlayer> players = new Dictionary<string, SoundPlayer>();
        public bool Muted;

        public Sfx()
        {
            // (startFreq, endFreq, milliseconds, wave: 0=square 1=sine 2=noise, volume)
            Add("flap", MakeWav((350, 650, 90, 1, 0.45)));
            Add("point", MakeWav((880, 880, 70, 0, 0.18), (1320, 1320, 130, 0, 0.18)));
            Add("hit", MakeWav((0, 0, 120, 2, 0.35), (220, 60, 260, 0, 0.25)));
            Add("start", MakeWav((440, 440, 70, 1, 0.4), (554, 554, 70, 1, 0.4), (659, 659, 140, 1, 0.4)));
        }

        public void Play(string name)
        {
            if (Muted) return;
            SoundPlayer p;
            if (players.TryGetValue(name, out p))
            {
                try { p.Play(); } catch { /* audio unavailable - ignore */ }
            }
        }

        private void Add(string name, byte[] wav)
        {
            try
            {
                var p = new SoundPlayer(new MemoryStream(wav));
                p.Load();
                players[name] = p;
            }
            catch { /* audio unavailable - ignore */ }
        }

        private static byte[] MakeWav(params (double f0, double f1, int ms, int wave, double vol)[] segs)
        {
            const int sr = 22050;
            var samples = new List<short>();
            var rnd = new Random(1);
            double phase = 0;

            foreach (var s in segs)
            {
                int n = sr * s.ms / 1000;
                for (int i = 0; i < n; i++)
                {
                    double t = (double)i / n;
                    double f = s.f0 + (s.f1 - s.f0) * t;
                    phase += 2 * Math.PI * f / sr;
                    double v;
                    switch (s.wave)
                    {
                        case 0: v = Math.Sin(phase) >= 0 ? 1.0 : -1.0; break;
                        case 1: v = Math.Sin(phase); break;
                        default: v = rnd.NextDouble() * 2 - 1; break;
                    }
                    double env = Math.Min(1.0, i / (sr * 0.004)) * (1.0 - t);
                    samples.Add((short)(v * env * s.vol * short.MaxValue));
                }
            }

            var ms2 = new MemoryStream();
            var w = new BinaryWriter(ms2);
            int dataLen = samples.Count * 2;
            w.Write(new[] { 'R', 'I', 'F', 'F' });
            w.Write(36 + dataLen);
            w.Write(new[] { 'W', 'A', 'V', 'E' });
            w.Write(new[] { 'f', 'm', 't', ' ' });
            w.Write(16);
            w.Write((short)1);          // PCM
            w.Write((short)1);          // mono
            w.Write(sr);
            w.Write(sr * 2);
            w.Write((short)2);
            w.Write((short)16);
            w.Write(new[] { 'd', 'a', 't', 'a' });
            w.Write(dataLen);
            foreach (short sm in samples) w.Write(sm);
            w.Flush();
            return ms2.ToArray();
        }
    }
}
