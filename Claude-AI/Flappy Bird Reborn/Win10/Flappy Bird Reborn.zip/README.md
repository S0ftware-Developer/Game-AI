# Flappy Bird Reborn

C# / .NET 8 / Windows Forms. No NuGet packages, no external assets: all graphics are drawn
with GDI+ primitives and all sounds are synthesised in memory.

## Build and run (Windows 10/11)
Install the .NET 8 SDK (https://dotnet.microsoft.com/download), then in this folder:

    dotnet build -c Release
    bin\Release\net8.0-windows\FlappyBirdReborn.exe

Or use `run.bat`. For a single self-contained .exe (no .NET install needed to play):

    dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
    bin\Release\net8.0-windows\win-x64\publish\FlappyBirdReborn.exe

## Controls
Space / Up Arrow / Left click = flap, Enter / Space = start or restart, Esc = pause, M = mute.

High score is stored in %LocalAppData%\FlappyBirdReborn\highscore.txt
