using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Windows.Forms;

namespace FlappyBirdReborn
{
    internal enum GameState { Start, Playing, Paused, GameOver }

    internal sealed class Pipe
    {
        public float X;
        public int GapTop;
        public int Gap;
        public bool Scored;
    }

    /// <summary>
    /// The whole game: one WinForms window, a fixed-timestep loop, and all drawing done with
    /// GDI+ primitives into a 360x600 off-screen bitmap that is scaled (nearest-neighbour)
    /// to fit the window. This gives the chunky pixel look without any external assets.
    /// </summary>
    internal sealed class GameForm : Form
    {
        // ---------- Logical play-area geometry ----------
        private const int W = 360;
        private const int H = 600;
        private const int GY = 530;          // ground top
        private const int FooterH = 30;      // native-resolution footer strip (pixels)

        // ---------- Gameplay tuning ----------
        private const float BX = 90f;        // bird x position
        private const float R = 12f;         // bird collision radius
        private const float Gravity = 1400f;
        private const float FlapV = -400f;
        private const float MaxFall = 650f;
        private const float BaseSpeed = 120f;
        private const float MaxSpeed = 230f;
        private const float PipeW = 56f;
        private const float CapW = 64f;
        private const float CapH = 24f;
        private const float PipeSpacing = 200f;
        private const float StepDt = 1f / 120f;

        // ---------- State ----------
        private GameState state = GameState.Start;
        private float by = 280f, vy;
        private float wingTime;
        private float t;                     // global time for bobbing/blinking
        private int score, best;
        private bool newRecord;
        private float restartLock;
        private bool keyHeld;
        private int lastTop = -1;

        private readonly List<Pipe> pipes = new List<Pipe>();
        private readonly Random rng = new Random();
        private readonly Sfx sfx = new Sfx();

        // ---------- Scrolling world ----------
        private float groundScroll, hillScroll, skyScroll;
        private readonly float[] cloudX = { 30, 150, 260, 340 };
        private readonly float[] cloudY = { 70, 150, 40, 210 };
        private readonly float[] cloudS = { 4, 6, 4, 5 };
        private readonly float[] cloudV = { 10, 6, 14, 8 };
        private readonly List<Rectangle> buildings = new List<Rectangle>();
        private int skyTile = W;

        // ---------- Rendering ----------
        private readonly Bitmap frame = new Bitmap(W, H, PixelFormat.Format32bppPArgb);
        private readonly Graphics fg;
        private Rectangle gameRect;
        private readonly Font fBig = new Font("Consolas", 38f, FontStyle.Bold, GraphicsUnit.Pixel);
        private readonly Font fTitle2 = new Font("Consolas", 32f, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Pixel);
        private readonly Font fMid = new Font("Consolas", 22f, FontStyle.Bold, GraphicsUnit.Pixel);
        private readonly Font fSmall = new Font("Consolas", 14f, FontStyle.Bold, GraphicsUnit.Pixel);
        private readonly Font fTiny = new Font("Consolas", 11f, FontStyle.Bold, GraphicsUnit.Pixel);
        private readonly StringFormat sf = new StringFormat(StringFormatFlags.NoWrap);

        private readonly Rectangle startBtn = new Rectangle(80, 425, 200, 46);
        private readonly Rectangle restartBtn = new Rectangle(80, 372, 200, 46);
        private readonly Rectangle muteRect = new Rectangle(W - 118, 6, 112, 18);

        private readonly Stopwatch clock = Stopwatch.StartNew();
        private double lastTime;
        private double acc;
        private readonly string scorePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "FlappyBirdReborn", "highscore.txt");

        public GameForm()
        {
            Text = "Flappy Bird Reborn";
            DoubleBuffered = true;
            BackColor = Color.FromArgb(6, 18, 60);
            ClientSize = new Size(432, 720 + FooterH);
            MinimumSize = new Size(340, 560);
            StartPosition = FormStartPosition.CenterScreen;

            fg = Graphics.FromImage(frame);
            fg.SmoothingMode = SmoothingMode.None;
            fg.PixelOffsetMode = PixelOffsetMode.Half;
            fg.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;

            BuildSkyline();
            LoadBest();
            RecalcLayout();

            var timer = new System.Windows.Forms.Timer { Interval = 8 };
            timer.Tick += (s, e) => Tick();
            timer.Start();
            lastTime = clock.Elapsed.TotalSeconds;
        }

        // =====================================================================
        //  Persistence
        // =====================================================================
        private void LoadBest()
        {
            try
            {
                int v;
                if (File.Exists(scorePath) && int.TryParse(File.ReadAllText(scorePath).Trim(), out v) && v > 0)
                    best = v;
            }
            catch { }
        }

        private void SaveBest()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(scorePath));
                File.WriteAllText(scorePath, best.ToString());
            }
            catch { }
        }

        // =====================================================================
        //  Layout & input
        // =====================================================================
        private void RecalcLayout()
        {
            int availW = Math.Max(1, ClientSize.Width);
            int availH = Math.Max(1, ClientSize.Height - FooterH);
            float s = Math.Min(availW / (float)W, availH / (float)H);
            int w = Math.Max(1, (int)(W * s));
            int h = Math.Max(1, (int)(H * s));
            gameRect = new Rectangle((availW - w) / 2, (availH - h) / 2, w, h);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            RecalcLayout();
            Invalidate();
        }

        protected override void OnDeactivate(EventArgs e)
        {
            base.OnDeactivate(e);
            if (state == GameState.Playing) state = GameState.Paused;
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Space:
                case Keys.Up:
                    if (!keyHeld) { keyHeld = true; PressAction(); }
                    e.SuppressKeyPress = true;
                    break;
                case Keys.Enter:
                    if (state == GameState.Start || state == GameState.GameOver) PressAction();
                    e.SuppressKeyPress = true;
                    break;
                case Keys.Escape:
                    if (state == GameState.Playing) state = GameState.Paused;
                    else if (state == GameState.Paused) state = GameState.Playing;
                    e.SuppressKeyPress = true;
                    break;
                case Keys.M:
                    sfx.Muted = !sfx.Muted;
                    break;
            }
            base.OnKeyDown(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Up) keyHeld = false;
            base.OnKeyUp(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left || !gameRect.Contains(e.Location)) return;
            float lx = (e.X - gameRect.X) * W / (float)gameRect.Width;
            float ly = (e.Y - gameRect.Y) * H / (float)gameRect.Height;
            var p = new Point((int)lx, (int)ly);

            if (muteRect.Contains(p)) { sfx.Muted = !sfx.Muted; return; }

            switch (state)
            {
                case GameState.Start:
                    StartGame();   // button or anywhere: click always starts
                    break;
                case GameState.Playing:
                    Flap();
                    break;
                case GameState.GameOver:
                    if (restartBtn.Contains(p) && restartLock <= 0f) StartGame();
                    break;
                case GameState.Paused:
                    state = GameState.Playing;
                    break;
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e) { /* painted in OnPaint */ }

        // =====================================================================
        //  Game logic
        // =====================================================================
        private void PressAction()
        {
            switch (state)
            {
                case GameState.Start: StartGame(); break;
                case GameState.Playing: Flap(); break;
                case GameState.GameOver: if (restartLock <= 0f) StartGame(); break;
            }
        }

        private void StartGame()
        {
            pipes.Clear();
            lastTop = -1;
            score = 0;
            newRecord = false;
            by = 280f;
            vy = 0f;
            SpawnPipe(W + 120, 0);
            state = GameState.Playing;
            sfx.Play("start");
            Flap();
        }

        private void Flap()
        {
            vy = FlapV;
            wingTime = 0f;
            sfx.Play("flap");
        }

        private void Die()
        {
            if (state != GameState.Playing) return;
            state = GameState.GameOver;
            restartLock = 0.5f;
            if (score > best) { best = score; newRecord = true; SaveBest(); }
            sfx.Play("hit");
        }

        private float CurrentSpeed()
        {
            return Math.Min(MaxSpeed, BaseSpeed + score * 4f);
        }

        private void SpawnPipe(float x, int forScore)
        {
            int gap = (int)Math.Max(130f, 165f - forScore * 1.5f);
            int minTop = 70;
            int maxTop = GY - 70 - gap;
            int top;
            if (lastTop < 0)
            {
                top = rng.Next(minTop + 20, maxTop - 20);
            }
            else
            {
                // Limit the vertical jump between consecutive gaps so every pipe is reachable.
                const int maxDelta = 140;
                top = Math.Max(minTop, Math.Min(maxTop, lastTop + rng.Next(-maxDelta, maxDelta + 1)));
            }
            lastTop = top;
            pipes.Add(new Pipe { X = x, GapTop = top, Gap = gap });
        }

        private void MovePipes(float dt, float speed, int forScore)
        {
            for (int i = pipes.Count - 1; i >= 0; i--)
            {
                pipes[i].X -= speed * dt;
                if (pipes[i].X < -CapW - 10) pipes.RemoveAt(i);
            }
            if (pipes.Count == 0 || pipes[pipes.Count - 1].X <= W + 10 - PipeSpacing)
                SpawnPipe(W + 10, forScore);
        }

        private void ScrollWorld(float dt, float speed)
        {
            groundScroll += speed * dt;
            hillScroll += speed * 0.3f * dt;
            skyScroll += speed * 0.12f * dt;
            for (int i = 0; i < cloudX.Length; i++)
            {
                cloudX[i] -= cloudV[i] * dt;
                if (cloudX[i] < -70) { cloudX[i] = W + 20; cloudY[i] = 30 + rng.Next(0, 190); }
            }
        }

        private static bool CircleRect(float cx, float cy, float r, float rx, float ry, float rw, float rh)
        {
            float nx = Math.Max(rx, Math.Min(cx, rx + rw));
            float ny = Math.Max(ry, Math.Min(cy, ry + rh));
            float dx = cx - nx, dy = cy - ny;
            return dx * dx + dy * dy < r * r;
        }

        private bool HitsPipe(Pipe p)
        {
            float gapBot = p.GapTop + p.Gap;
            return CircleRect(BX, by, R, p.X, -100, PipeW, p.GapTop - CapH + 100)          // top body
                || CircleRect(BX, by, R, p.X - 4, p.GapTop - CapH, CapW, CapH)             // top cap
                || CircleRect(BX, by, R, p.X - 4, gapBot, CapW, CapH)                      // bottom cap
                || CircleRect(BX, by, R, p.X, gapBot + CapH, PipeW, GY - gapBot - CapH);   // bottom body
        }

        private void Step(float dt)
        {
            t += dt;
            if (restartLock > 0f) restartLock -= dt;

            switch (state)
            {
                case GameState.Start:
                    ScrollWorld(dt, 60f);
                    MovePipes(dt, 60f, 0);
                    by = 280f + (float)Math.Sin(t * 4f) * 8f;
                    wingTime += dt;
                    break;

                case GameState.Playing:
                    {
                        float speed = CurrentSpeed();
                        ScrollWorld(dt, speed);
                        wingTime += dt;

                        vy = Math.Min(MaxFall, vy + Gravity * dt);
                        by += vy * dt;

                        MovePipes(dt, speed, score);

                        foreach (var p in pipes)
                        {
                            if (!p.Scored && p.X + PipeW / 2f < BX)
                            {
                                p.Scored = true;
                                score++;
                                sfx.Play("point");
                            }
                        }

                        if (by + R >= GY) { by = GY - R; Die(); }
                        else if (by - R <= 0f) { by = R; vy = 0f; Die(); }
                        else
                        {
                            foreach (var p in pipes)
                                if (HitsPipe(p)) { Die(); break; }
                        }
                        break;
                    }

                case GameState.GameOver:
                    vy = Math.Min(MaxFall, vy + Gravity * dt);
                    by += vy * dt;
                    if (by + R >= GY) { by = GY - R; vy = 0f; }
                    break;
            }
        }

        private void Tick()
        {
            double now = clock.Elapsed.TotalSeconds;
            double dt = now - lastTime;
            lastTime = now;
            if (dt > 0.1) dt = 0.1;
            acc += dt;
            while (acc >= StepDt)
            {
                Step(StepDt);
                acc -= StepDt;
            }
            Invalidate();
        }

        // =====================================================================
        //  Rendering – window level
        // =====================================================================
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Color.FromArgb(6, 18, 60));

            Render(fg);

            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.DrawImage(frame, gameRect, 0, 0, W, H, GraphicsUnit.Pixel);

            var border = gameRect;
            border.Inflate(3, 3);
            using (var pen = new Pen(Color.FromArgb(0, 210, 255), 3))
                g.DrawRectangle(pen, border);

            DrawFooter(g);
        }

        private void DrawFooter(Graphics g)
        {
            int cw = ClientSize.Width;
            int top = ClientSize.Height - FooterH;
            using (var b = new SolidBrush(Color.FromArgb(5, 14, 48)))
                g.FillRectangle(b, 0, top, cw, FooterH);
            using (var pen = new Pen(Color.FromArgb(0, 150, 230), 2))
                g.DrawLine(pen, 0, top, cw, top);

            string a = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: ";
            string c = "orlovandrei.space";

            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            var fmt = StringFormat.GenericTypographic;
            float size = 12f;
            Font f = null;
            float wa = 0, wc = 0;
            while (true)
            {
                if (f != null) f.Dispose();
                f = new Font("Consolas", size, FontStyle.Regular, GraphicsUnit.Pixel);
                wa = g.MeasureString(a, f, 2000, fmt).Width;
                wc = g.MeasureString(c, f, 2000, fmt).Width;
                if (wa + wc <= cw - 12 || size <= 7f) break;
                size -= 0.5f;
            }
            float x = (cw - (wa + wc)) / 2f;
            float y = top + (FooterH - f.Height) / 2f;
            using (var b1 = new SolidBrush(Color.White))
                g.DrawString(a, f, b1, x, y, fmt);
            using (var b2 = new SolidBrush(Color.FromArgb(90, 255, 90)))
                g.DrawString(c, f, b2, x + wa, y, fmt);
            f.Dispose();
        }

        // =====================================================================
        //  Rendering – game frame (logical 360x600)
        // =====================================================================
        private void Render(Graphics g)
        {
            DrawSky(g);
            DrawClouds(g);
            DrawSkyline(g);
            DrawHills(g);
            DrawWater(g);
            DrawPipes(g);
            DrawGround(g);

            float angle = 0f;
            if (state == GameState.Playing || state == GameState.GameOver)
                angle = Math.Max(-25f, Math.Min(80f, vy * 0.12f));
            DrawBird(g, BX, by, angle, WingFrame());

            switch (state)
            {
                case GameState.Start: DrawStartUi(g); break;
                case GameState.Playing: DrawHud(g); break;
                case GameState.Paused: DrawHud(g); DrawPausedUi(g); break;
                case GameState.GameOver: DrawHud(g); DrawGameOverUi(g); break;
            }
        }

        private static float Mod(float a, float b)
        {
            return a - b * (float)Math.Floor(a / b);
        }

        private int WingFrame()
        {
            if (state == GameState.GameOver || state == GameState.Paused) return 1;
            int[] seq = { 0, 1, 2, 1 };
            return seq[((int)(wingTime * 14f)) % 4];
        }

        private void DrawSky(Graphics g)
        {
            using (var br = new LinearGradientBrush(new Rectangle(0, 0, W, GY + 1),
                Color.FromArgb(70, 165, 250), Color.FromArgb(175, 222, 255), 90f))
                g.FillRectangle(br, 0, 0, W, GY + 1);
        }

        private void DrawClouds(Graphics g)
        {
            // Rows of a pixel cloud: (startUnit, rowIndex, widthUnits)
            int[,] rows = { { 2, 0, 5 }, { 1, 1, 7 }, { 0, 2, 9 }, { 0, 3, 9 } };
            using (var white = new SolidBrush(Color.White))
            using (var shade = new SolidBrush(Color.FromArgb(205, 228, 250)))
            {
                for (int i = 0; i < cloudX.Length; i++)
                {
                    float u = cloudS[i];
                    for (int r = 0; r < rows.GetLength(0); r++)
                    {
                        var br = (r == rows.GetLength(0) - 1) ? shade : white;
                        g.FillRectangle(br, (int)(cloudX[i] + rows[r, 0] * u), (int)(cloudY[i] + rows[r, 1] * u),
                            (int)(rows[r, 2] * u), (int)Math.Ceiling(u));
                    }
                }
            }
        }

        private void BuildSkyline()
        {
            var r = new Random(7);
            int x = 0;
            while (x < W)
            {
                int w = r.Next(18, 35);
                int h = r.Next(40, 115);
                buildings.Add(new Rectangle(x, 0, w, h));
                x += w + r.Next(0, 5);
            }
            skyTile = x;
        }

        private void DrawSkyline(Graphics g)
        {
            int baseY = GY - 40;
            float off = -Mod(skyScroll, skyTile);
            using (var body = new SolidBrush(Color.FromArgb(120, 172, 228)))
            using (var win = new SolidBrush(Color.FromArgb(175, 210, 244)))
            {
                for (int k = 0; k < 2; k++)
                {
                    foreach (var b in buildings)
                    {
                        int bx = (int)(b.X + off + k * skyTile);
                        if (bx > W || bx + b.Width < 0) continue;
                        g.FillRectangle(body, bx, baseY - b.Height, b.Width, b.Height);
                        if (b.Height > 85) g.FillRectangle(body, bx + b.Width / 2 - 1, baseY - b.Height - 12, 3, 12);
                        for (int wy = baseY - b.Height + 6; wy < baseY - 6; wy += 8)
                            for (int wx = bx + 4; wx < bx + b.Width - 5; wx += 7)
                                g.FillRectangle(win, wx, wy, 3, 4);
                    }
                }
            }
        }

        private void DrawHills(Graphics g)
        {
            float off = -Mod(hillScroll, 24f);
            using (var dark = new SolidBrush(Color.FromArgb(36, 140, 48)))
            using (var light = new SolidBrush(Color.FromArgb(70, 186, 62)))
            {
                for (float x = off - 24; x < W + 24; x += 24)
                    g.FillEllipse(dark, (int)x, GY - 78, 36, 36);
                for (float x = off - 12; x < W + 24; x += 24)
                    g.FillEllipse(light, (int)x, GY - 72, 30, 30);
                g.FillRectangle(dark, 0, GY - 58, W, 30);
            }
        }

        private void DrawWater(Graphics g)
        {
            using (var water = new SolidBrush(Color.FromArgb(66, 172, 238)))
            using (var hi = new SolidBrush(Color.FromArgb(150, 214, 252)))
            {
                g.FillRectangle(water, 0, GY - 36, W, 36);
                g.FillRectangle(hi, 0, GY - 36, W, 2);
                float off = -Mod(groundScroll * 0.5f, 40f);
                for (float x = off - 40; x < W; x += 40)
                {
                    g.FillRectangle(hi, (int)x + 6, GY - 24, 16, 2);
                    g.FillRectangle(hi, (int)x + 24, GY - 12, 12, 2);
                }
            }
        }

        private void DrawPipeRect(Graphics g, float x, float y, float w, float h)
        {
            if (h <= 0) return;
            int ix = (int)x, iy = (int)y, iw = (int)w, ih = (int)h;
            using (var baseB = new SolidBrush(Color.FromArgb(116, 200, 44)))
            using (var hiB = new SolidBrush(Color.FromArgb(176, 238, 92)))
            using (var shB = new SolidBrush(Color.FromArgb(70, 150, 30)))
            using (var pen = new Pen(Color.FromArgb(38, 88, 22), 2))
            {
                g.FillRectangle(baseB, ix, iy, iw, ih);
                g.FillRectangle(hiB, ix + 4, iy + 2, 7, ih - 4);
                g.FillRectangle(shB, ix + iw - 11, iy + 2, 8, ih - 4);
                g.DrawRectangle(pen, ix + 1, iy + 1, iw - 2, ih - 2);
            }
        }

        private void DrawPipes(Graphics g)
        {
            foreach (var p in pipes)
            {
                float gapBot = p.GapTop + p.Gap;
                DrawPipeRect(g, p.X, -10, PipeW, p.GapTop - CapH + 10);
                DrawPipeRect(g, p.X - 4, p.GapTop - CapH, CapW, CapH);
                DrawPipeRect(g, p.X - 4, gapBot, CapW, CapH);
                DrawPipeRect(g, p.X, gapBot + CapH, PipeW, GY - gapBot - CapH);
            }
        }

        private void DrawGround(Graphics g)
        {
            float off = -Mod(groundScroll, 16f);
            using (var grass = new SolidBrush(Color.FromArgb(112, 204, 52)))
            using (var grassD = new SolidBrush(Color.FromArgb(76, 166, 40)))
            using (var edge = new SolidBrush(Color.FromArgb(46, 96, 26)))
            using (var dirt = new SolidBrush(Color.FromArgb(224, 186, 112)))
            using (var dirtD = new SolidBrush(Color.FromArgb(200, 158, 88)))
            {
                g.FillRectangle(edge, 0, GY, W, 2);
                g.FillRectangle(grass, 0, GY + 2, W, 12);
                for (float x = off - 16; x < W; x += 16)
                    g.FillRectangle(grassD, (int)x + 2, GY + 4, 8, 6);
                g.FillRectangle(edge, 0, GY + 14, W, 3);
                g.FillRectangle(dirt, 0, GY + 17, W, H - GY - 17);
                for (float x = off - 16; x < W; x += 16)
                {
                    g.FillRectangle(dirtD, (int)x + 4, GY + 28, 4, 4);
                    g.FillRectangle(dirtD, (int)x + 12, GY + 46, 4, 4);
                }
            }
        }

        private void DrawBird(Graphics g, float x, float y, float angle, int wing)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(x, y);
            g.RotateTransform(angle);

            using (var body = new SolidBrush(Color.FromArgb(255, 206, 40)))
            using (var belly = new SolidBrush(Color.FromArgb(255, 238, 150)))
            using (var wingB = new SolidBrush(Color.FromArgb(244, 156, 34)))
            using (var beakT = new SolidBrush(Color.FromArgb(244, 84, 32)))
            using (var beakB = new SolidBrush(Color.FromArgb(212, 52, 24)))
            using (var white = new SolidBrush(Color.White))
            using (var black = new SolidBrush(Color.FromArgb(20, 20, 30)))
            using (var outline = new Pen(Color.FromArgb(150, 78, 16), 2))
            using (var eyeLine = new Pen(Color.FromArgb(20, 20, 30), 2))
            {
                // beak
                g.FillRectangle(beakT, 11, -1, 13, 6);
                g.FillRectangle(beakB, 11, 5, 11, 5);
                // body
                g.FillEllipse(body, -14, -11, 28, 22);
                g.FillEllipse(belly, -9, 2, 18, 8);
                g.DrawEllipse(outline, -14, -11, 28, 22);
                // eye
                g.FillEllipse(white, 2, -10, 13, 13);
                g.DrawEllipse(eyeLine, 2, -10, 13, 13);
                g.FillRectangle(black, 9, -6, 4, 6);
                // wing (3 frames: up / middle / down)
                int wy = wing == 0 ? -7 : (wing == 1 ? -2 : 3);
                g.FillEllipse(wingB, -13, wy, 16, 9);
                g.DrawEllipse(outline, -13, wy, 16, 9);
            }
            g.Restore(st);
        }

        // =====================================================================
        //  Rendering – UI helpers
        // =====================================================================
        private void DrawTxt(Graphics g, string s, Font f, float x, float y, Color fill, Color outline,
            int th, StringAlignment al)
        {
            sf.Alignment = al;
            if (th > 0)
            {
                using (var ob = new SolidBrush(outline))
                    for (int dx = -th; dx <= th; dx += th)
                        for (int dy = -th; dy <= th; dy += th)
                            if (dx != 0 || dy != 0) g.DrawString(s, f, ob, x + dx, y + dy, sf);
            }
            using (var fb = new SolidBrush(fill)) g.DrawString(s, f, fb, x, y, sf);
        }

        private void Center(Graphics g, string s, Font f, float y, Color fill, Color outline, int th)
        {
            DrawTxt(g, s, f, W / 2f, y, fill, outline, th, StringAlignment.Center);
        }

        private static readonly Color Yellow = Color.FromArgb(255, 204, 30);
        private static readonly Color Brown = Color.FromArgb(110, 50, 0);
        private static readonly Color Cyan = Color.FromArgb(80, 224, 255);
        private static readonly Color Navy = Color.FromArgb(8, 24, 80);
        private static readonly Color Green = Color.FromArgb(90, 255, 90);

        private void DrawPanel(Graphics g, Rectangle r, int alpha)
        {
            using (var fill = new SolidBrush(Color.FromArgb(alpha, 10, 28, 90)))
                g.FillRectangle(fill, r);
            using (var p1 = new Pen(Color.FromArgb(0, 210, 255), 3))
                g.DrawRectangle(p1, r.X + 1, r.Y + 1, r.Width - 3, r.Height - 3);
            using (var p2 = new Pen(Color.FromArgb(0, 90, 190), 1))
                g.DrawRectangle(p2, r.X + 5, r.Y + 5, r.Width - 11, r.Height - 11);
        }

        private void DrawButton(Graphics g, Rectangle r, string label, bool playIcon)
        {
            using (var fill = new SolidBrush(Color.FromArgb(14, 100, 36)))
                g.FillRectangle(fill, r);
            using (var p1 = new Pen(Color.FromArgb(90, 255, 90), 3))
                g.DrawRectangle(p1, r.X + 1, r.Y + 1, r.Width - 3, r.Height - 3);
            using (var p2 = new Pen(Color.FromArgb(40, 170, 60), 1))
                g.DrawRectangle(p2, r.X + 5, r.Y + 5, r.Width - 11, r.Height - 11);

            float textX = r.X + r.Width / 2f;
            if (playIcon)
            {
                using (var tri = new SolidBrush(Green))
                    g.FillPolygon(tri, new[]
                    {
                        new Point(r.X + 24, r.Y + 13),
                        new Point(r.X + 24, r.Y + r.Height - 13),
                        new Point(r.X + 40, r.Y + r.Height / 2)
                    });
                textX += 14;
            }
            DrawTxt(g, label, fMid, textX, r.Y + (r.Height - 22) / 2f - 1, Green, Color.FromArgb(0, 50, 10), 1,
                StringAlignment.Center);
        }

        private void DrawDim(Graphics g, int alpha)
        {
            using (var b = new SolidBrush(Color.FromArgb(alpha, 0, 0, 20)))
                g.FillRectangle(b, 0, 0, W, H);
        }

        private void DrawMuteLabel(Graphics g)
        {
            DrawTxt(g, sfx.Muted ? "[M] SOUND OFF" : "[M] SOUND ON", fTiny, W - 8, 8,
                sfx.Muted ? Color.FromArgb(255, 120, 120) : Color.White, Navy, 1, StringAlignment.Far);
        }

        private int Level { get { return score / 5 + 1; } }

        private void DrawHud(Graphics g)
        {
            DrawTxt(g, "BEST " + Math.Max(best, score).ToString("D6"), fTiny, 8, 8, Yellow, Brown, 1,
                StringAlignment.Near);
            DrawTxt(g, "LEVEL " + Level, fTiny, 8, 24, Green, Navy, 1, StringAlignment.Near);
            DrawMuteLabel(g);
            Center(g, score.ToString(), fBig, 34, Color.White, Color.FromArgb(40, 40, 60), 2);
        }

        private void DrawStartUi(Graphics g)
        {
            DrawPanel(g, new Rectangle(14, 24, W - 28, 128), 170);
            Center(g, "FLAPPY BIRD", fBig, 36, Yellow, Brown, 2);
            Center(g, "REBORN", fTitle2, 86, Cyan, Navy, 2);
            DrawMuteLabel(g);

            Center(g, "GET READY!", fBig, 200, Yellow, Brown, 2);

            DrawPanel(g, new Rectangle(14, 330, W - 28, 36), 190);
            Center(g, "PRESS SPACE / UP ARROW / CLICK TO FLY", fSmall, 340, Color.White, Navy, 1);

            Center(g, "HIGH SCORE " + best.ToString("D6"), fMid, 380, Yellow, Brown, 1);
            DrawButton(g, startBtn, "START GAME", true);
            Center(g, "ESC = PAUSE   M = MUTE", fTiny, 482, Color.White, Navy, 1);
        }

        private void DrawPausedUi(Graphics g)
        {
            DrawDim(g, 130);
            var r = new Rectangle(40, 225, W - 80, 140);
            DrawPanel(g, r, 235);
            Center(g, "PAUSED", fBig, 245, Yellow, Brown, 2);
            Center(g, "PRESS ESC TO RESUME", fSmall, 310, Color.White, Navy, 1);
            Center(g, "OR CLICK THE GAME", fTiny, 332, Cyan, Navy, 1);
        }

        private void DrawGameOverUi(Graphics g)
        {
            DrawDim(g, 120);
            DrawPanel(g, new Rectangle(30, 140, W - 60, 330), 240);
            Center(g, "GAME OVER", fBig, 158, Yellow, Brown, 2);
            Center(g, "SCORE", fSmall, 216, Cyan, Navy, 1);
            Center(g, score.ToString("D6"), fBig, 232, Color.White, Navy, 2);
            Center(g, "BEST", fSmall, 282, Yellow, Brown, 1);
            Center(g, best.ToString("D6"), fMid, 300, Color.White, Navy, 1);
            if (newRecord && ((int)(t * 3f) % 2 == 0))
                Center(g, "NEW RECORD!", fMid, 335, Green, Color.FromArgb(0, 60, 10), 1);
            DrawButton(g, restartBtn, "RESTART", false);
            Center(g, "SPACE / ENTER TO RESTART", fTiny, 430, Color.White, Navy, 1);
        }
    }
}
