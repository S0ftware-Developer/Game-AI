KING KONG ALIVE - 2D arcade platformer (C# / .NET 8 / Windows Forms / GDI+)
==========================================================================

Level "The Giant Construction Site": climb six girders and a rescue platform, jump
rolling barrels, avoid fires, collect golden tools and rescue the girl from King Kong.
All graphics are drawn in code and all sounds are generated at runtime.
No external files are needed to play.

BUILD (Windows 10/11 x64, .NET 8 SDK required)
----------------------------------------------
1. Extract the whole archive into a folder.
2. Double-click build.bat (it opens its own console window and keeps it open).
   Equivalent manual command, run from the project folder:

   dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishTrimmed=false

3. The finished game is:

   bin\Release\net8.0-windows\win-x64\publish\KingKongAlive.exe

   build.bat removes every other file from that folder, so only KingKongAlive.exe remains.
   The exe is self-contained: the .NET Runtime does not need to be installed.

CONTROLS
--------
Left/A, Right/D   move             Space        jump (fixed height; steer in the air)
Up/W, Down/S      climb ladders    Esc          pause / resume
R                 restart          F11          fullscreen          M  mute
Jump sideways off a ladder with Space + Left/Right.

JUMPING NOTES
-------------
Girders are one-way platforms: Jack can jump up through them but only lands on their top
surface. The jump (72 px) is lower than the smallest floor spacing (81 px), so floors can
only be reached by ladders. Pressing Space up to 0.12 s after stepping off an edge still
jumps (coyote time), so the 70 px gap on the middle floor can be crossed.

SCORING
-------
Golden tool +100, jump over a barrel +100, new platform +50,
reach the top +500, complete the level +1000. Three lives. High score is saved in
%LocalAppData%\KingKongAlive\highscore.txt (the game works without it).

TUNING
------
Speeds, gravity, jump, barrel limits: Config.cs.  Girders, ladders, fires, bonuses: Level.cs.

TROUBLESHOOTING
---------------
- "dotnet" not found: install the .NET 8 SDK (not only the Runtime) and run build.bat again.
- Do not run build.bat from inside the ZIP viewer; extract first.
- The footer line at the bottom of the window is part of the game.
