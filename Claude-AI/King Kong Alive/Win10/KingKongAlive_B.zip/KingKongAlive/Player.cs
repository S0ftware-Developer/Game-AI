using System.Drawing;

namespace KingKongAlive;

public enum PS { Ground, Air, Ladder }

public class Player
{
    public float X, Y, VY;                      // X,Y = feet position
    public int Facing = 1, Cur, MaxRow;
    public PS State = PS.Ground;
    public Ladder? Lad;
    public float WalkAnim, ClimbAnim, LandT, ClimbSfxT, CoyoteT;
    public bool Moving;
    public Action? OnJump, OnClimb;
    public Action<int>? OnNewRow;
    readonly Level lv;

    public Player(Level l) { lv = l; Reset(); }

    public void Reset()
    {
        X = lv.Start.X; Y = lv.Start.Y; VY = 0; Facing = 1; Cur = 0; Lad = null;
        State = PS.Ground; LandT = 0; Moving = false; CoyoteT = 0;
    }

    public RectangleF HitBox() => new(X - 7, Y - 38, 14, 35);

    public void Update(float dt, bool left, bool right, bool up, bool down, bool jump)
    {
        int dx = (right ? 1 : 0) - (left ? 1 : 0);
        LandT = MathF.Max(0, LandT - dt);
        Moving = false;

        if (State == PS.Ground)
        {
            if (jump) { State = PS.Air; VY = Cfg.JumpVel; CoyoteT = 0; OnJump?.Invoke(); }
            else
            {
                if (dx != 0) { Facing = dx; Moving = true; X += dx * Cfg.Walk * dt; WalkAnim += dt * 10f; }
                X = Math.Clamp(X, Cfg.MinX, Cfg.MaxX);
                var p = lv.Plats[Cur];
                if (p.Has(X)) Y = p.YAt(X);
                else { State = PS.Air; VY = 0; CoyoteT = Cfg.Coyote; }   // walked off the edge: jump still allowed briefly
                if (State == PS.Ground && (up || down)) TryLadder(up);
            }
        }

        if (State == PS.Air && CoyoteT > 0)
        {   // "coyote time": pressing jump just after leaving the edge still jumps from the girder level
            CoyoteT -= dt;
            if (jump) { VY = Cfg.JumpVel; CoyoteT = 0; OnJump?.Invoke(); }
        }
        if (State == PS.Air) AirStep(dt, dx);
        else if (State == PS.Ladder) LadderStep(dt, up, down, dx, jump);
    }

    void TryLadder(bool up)
    {
        foreach (var l in lv.Ladders)
        {
            if (MathF.Abs(X - l.X) > 11f) continue;
            if (up && Cur == l.Lower) { Enter(l, -2f); return; }
            if (!up && Cur == l.Upper) { Enter(l, 2f); return; }
        }
    }

    void Enter(Ladder l, float yOff) { State = PS.Ladder; Lad = l; X = l.X; Y += yOff; VY = 0; }

    void LadderStep(float dt, bool up, bool down, int dx, bool jump)
    {
        if (jump && dx != 0)
        {   // hop off the ladder sideways
            State = PS.Air; VY = Cfg.JumpVel * 0.55f; Facing = dx; Lad = null; CoyoteT = 0; OnJump?.Invoke();
            return;
        }
        float dy = (down ? 1 : 0) - (up ? 1 : 0);
        if (dy != 0)
        {
            Y += dy * Cfg.Climb * dt; ClimbAnim += dt * 8f; Moving = true;
            ClimbSfxT -= dt;
            if (ClimbSfxT <= 0) { ClimbSfxT = 0.16f; OnClimb?.Invoke(); }
        }
        float topY = lv.Plats[Lad!.Upper].YAt(Lad.X), botY = lv.Plats[Lad.Lower].YAt(Lad.X);
        if (Y <= topY) { Y = topY; ExitTo(Lad.Upper); }
        else if (Y >= botY) { Y = botY; ExitTo(Lad.Lower); }
    }

    void ExitTo(int plat)
    {
        State = PS.Ground; Cur = plat; Lad = null; VY = 0;
        CheckRow(lv.Plats[plat]);
    }

    void AirStep(float dt, int dx)
    {
        if (dx != 0) Facing = dx;
        float oy = Y;
        X = Math.Clamp(X + dx * Cfg.Walk * dt, Cfg.MinX, Cfg.MaxX);
        VY += Cfg.Gravity * dt;
        Y += VY * dt;

        // Girders are one-way: you can jump up through them, you only land on their top surface.
        // (Jump height < smallest floor spacing, so a jump can never reach the next floor without a ladder.)
        if (VY > 0)
        {
            foreach (var p in lv.Plats)
            {
                if (!p.Has(X)) continue;
                float s = p.YAt(X);
                if (oy <= s + 1f && Y >= s)
                {
                    Y = s; VY = 0; State = PS.Ground; Cur = p.Id; LandT = 0.12f; CoyoteT = 0;
                    CheckRow(p);
                    break;
                }
            }
        }
    }

    void CheckRow(Plat p)
    {
        if (p.Row > MaxRow) { MaxRow = p.Row; OnNewRow?.Invoke(p.Row); }
    }
}
