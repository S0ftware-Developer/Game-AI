using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace KingKongAlive;

public enum GameState { Title, Playing, Paused, GameOver, Complete }

public class GameForm : Form
{
    const string Footer = "\u00A9 2026 Andrei Orlov (together with Claude AI). Website: orlovandrei.space";
    const int FooterH = 28;                       // screen pixels reserved at the bottom of the window
    static readonly Font FooterFont = new("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);

    Level lv = null!;
    Player pl = null!;
    Kong kong = null!;
    GameState state = GameState.Title;
    readonly List<Barrel> barrels = new();
    readonly List<Pop> pops = new();
    readonly List<Particle> parts = new();
    readonly HashSet<Keys> held = new();
    bool jumpPressed, fullscreen;
    int score, highScore, lives, pauseSel;
    float time, t, dyingT = -1f, dyVY, dyElapsed, victoryT = -1f;
    readonly Random rng = new();
    readonly System.Windows.Forms.Timer timer = new() { Interval = 8 };
    readonly Stopwatch sw = Stopwatch.StartNew();
    double last, acc;

    static string HighPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KingKongAlive", "highscore.txt");

    public GameForm()
    {
        Text = "King Kong Alive";
        ClientSize = new Size(Cfg.W, Cfg.H + FooterH);
        MinimumSize = new Size(640, 520);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.Black;
        DoubleBuffered = true;
        KeyPreview = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        try { if (File.Exists(HighPath)) int.TryParse(File.ReadAllText(HighPath).Trim(), out highScore); } catch { }
        NewGame();
        timer.Tick += Tick;
        timer.Start();
        Deactivate += (s, e) => { held.Clear(); if (state == GameState.Playing) { state = GameState.Paused; pauseSel = 0; } };
        FormClosed += (s, e) => timer.Stop();
    }

    // ---------------- setup ----------------
    void NewGame()
    {
        lv = new Level();
        pl = new Player(lv);
        kong = new Kong();
        pl.OnJump = () => Sfx.Jump.Play();
        pl.OnClimb = () => Sfx.Climb.Play();
        pl.OnNewRow = row => { score += 50; AddPop(pl.X, pl.Y - 54, "+50", Color.Cyan); };
        barrels.Clear(); pops.Clear(); parts.Clear();
        score = 0; lives = 3; time = 0; dyingT = -1f; victoryT = -1f; jumpPressed = false;
    }

    void StartGame() { NewGame(); state = GameState.Playing; held.Clear(); }

    void Respawn()
    {
        pl.Reset();
        barrels.Clear();
        kong.State = KongState.Idle; kong.StateT = 0; kong.NextThrow = 2.2f;
        dyingT = -1f;
    }

    void EndGame(bool won)
    {
        if (score > highScore)
        {
            highScore = score;
            try { Directory.CreateDirectory(Path.GetDirectoryName(HighPath)!); File.WriteAllText(HighPath, highScore.ToString()); } catch { }
        }
        state = won ? GameState.Complete : GameState.GameOver;
    }

    void AddPop(float x, float y, string text, Color c) => pops.Add(new Pop { X = x, Y = y, Life = 1.0f, Text = text, Col = c });

    void Spark(float x, float y, int n, Color c, float speed)
    {
        for (int i = 0; i < n; i++)
        {
            float a = rng.NextSingle() * MathF.Tau, v = speed * (0.3f + rng.NextSingle() * 0.7f);
            parts.Add(new Particle { X = x, Y = y, VX = MathF.Cos(a) * v, VY = MathF.Sin(a) * v, Life = 0.5f, Max = 0.5f, Size = 5 + rng.NextSingle() * 4, Col = c, Kind = 0 });
        }
    }

    void SpawnHeart()
    {
        parts.Add(new Particle
        {
            X = lv.GirlPos.X - 14 + rng.Next(-14, 14), Y = lv.GirlPos.Y - 60,
            VX = (rng.NextSingle() - 0.5f) * 40f, VY = -50f, Life = 1.4f, Max = 1.4f, Size = 7, Col = Color.HotPink, Kind = 1
        });
    }

    // ---------------- input ----------------
    protected override void OnKeyDown(KeyEventArgs e)
    {
        var k = e.KeyCode;
        e.Handled = true; e.SuppressKeyPress = true;
        if (k == Keys.F11 || (e.Alt && k == Keys.Enter)) { ToggleFullscreen(); return; }
        if (k == Keys.M) { Sfx.Muted = !Sfx.Muted; return; }
        if (k == Keys.ShiftKey || k == Keys.ControlKey || k == Keys.Menu) return;

        switch (state)
        {
            case GameState.Title:
                if (k != Keys.Escape) StartGame();
                break;
            case GameState.Playing:
                if (k == Keys.Escape) { state = GameState.Paused; pauseSel = 0; held.Clear(); }
                else if (k == Keys.R) StartGame();
                else { bool first = held.Add(k); if (first && k == Keys.Space) jumpPressed = true; }
                break;
            case GameState.Paused:
                if (k == Keys.Escape) state = GameState.Playing;
                else if (k == Keys.R) StartGame();
                else if (k == Keys.Up || k == Keys.W || k == Keys.Down || k == Keys.S) pauseSel = 1 - pauseSel;
                else if (k == Keys.Enter || k == Keys.Space) { if (pauseSel == 0) state = GameState.Playing; else StartGame(); }
                break;
            default:
                if (k == Keys.Enter || k == Keys.Space || k == Keys.R) StartGame();
                break;
        }
    }

    protected override void OnKeyUp(KeyEventArgs e) { held.Remove(e.KeyCode); e.Handled = true; }

    void ToggleFullscreen()
    {
        fullscreen = !fullscreen;
        if (fullscreen) { FormBorderStyle = FormBorderStyle.None; WindowState = FormWindowState.Maximized; }
        else { WindowState = FormWindowState.Normal; FormBorderStyle = FormBorderStyle.Sizable; }
    }

    // ---------------- main loop ----------------
    void Tick(object? s, EventArgs e)
    {
        double now = sw.Elapsed.TotalSeconds;
        double frame = Math.Min(now - last, 0.1);
        last = now;
        acc += frame;
        while (acc >= Cfg.Step) { Update(Cfg.Step); acc -= Cfg.Step; }
        Invalidate();
    }

    void Update(float dt)
    {
        t += dt;
        if (state == GameState.Complete) { UpdateFx(dt); if (rng.NextDouble() < dt * 3.0) SpawnHeart(); return; }
        if (state != GameState.Playing) return;
        UpdateFx(dt);
        if (victoryT >= 0) { UpdateVictory(dt); return; }
        if (dyingT >= 0) { UpdateDying(dt); return; }

        time += dt;
        bool left = held.Contains(Keys.Left) || held.Contains(Keys.A);
        bool right = held.Contains(Keys.Right) || held.Contains(Keys.D);
        bool up = held.Contains(Keys.Up) || held.Contains(Keys.W);
        bool down = held.Contains(Keys.Down) || held.Contains(Keys.S);
        bool jp = jumpPressed; jumpPressed = false;

        pl.Update(dt, left, right, up, down, jp);
        UpdateKong(dt);
        UpdateBarrels(dt);
        UpdateFires(dt);
        UpdateBonuses();

        if (dyingT < 0 && pl.Y > Cfg.H + 40) Die(false);
        if (dyingT < 0 && pl.State == PS.Ground && pl.Cur == Level.TopPlat) Win();
    }

    void UpdateFx(float dt)
    {
        for (int i = parts.Count - 1; i >= 0; i--)
        {
            var p = parts[i];
            p.Life -= dt;
            if (p.Life <= 0) { parts.RemoveAt(i); continue; }
            p.X += p.VX * dt; p.Y += p.VY * dt;
            p.VY += (p.Kind == 0 ? 500f : -10f) * dt;
        }
        for (int i = pops.Count - 1; i >= 0; i--)
        {
            var p = pops[i];
            p.Life -= dt; p.Y -= 30f * dt;
            if (p.Life <= 0) pops.RemoveAt(i);
        }
    }

    // ---------------- Kong and barrels ----------------
    void UpdateKong(float dt)
    {
        kong.Agitated = lv.Plats[pl.Cur].Row >= 5;       // Kong reacts when the player reaches his platform
        switch (kong.State)
        {
            case KongState.Idle:
                kong.NextThrow -= dt;
                if (kong.NextThrow <= 0 && barrels.Count < Cfg.MaxBarrels)
                {
                    if (SpawnBlocked()) kong.NextThrow = 0.35f;
                    else { kong.State = KongState.Grab; kong.StateT = 0; }
                }
                break;
            case KongState.Grab:
                kong.StateT += dt;
                if (kong.StateT >= 0.6f) { kong.State = KongState.Throw; kong.StateT = 0; SpawnBarrel(); }
                break;
            case KongState.Throw:
                kong.StateT += dt;
                if (kong.StateT >= 0.3f) { kong.State = KongState.Idle; kong.NextThrow = NextInterval(); }
                break;
        }
    }

    // never spawn a barrel on top of the player
    bool SpawnBlocked() => pl.Cur == Level.KongPlat && pl.State != PS.Ladder && pl.X > 150f && pl.X < 330f;

    float NextInterval()
    {
        float b = MathF.Max(1.5f, 3.6f - time * 0.018f);          // barrels come faster as the level goes on
        if (kong.Agitated) b *= 0.85f;
        return b + (float)(rng.NextDouble() * 0.9 - 0.3);
    }

    void SpawnBarrel()
    {
        float speed = (Cfg.BarrelBaseSpeed + MathF.Min(70f, time * 0.45f)) * (0.88f + rng.NextSingle() * 0.3f);
        barrels.Add(new Barrel
        {
            X = lv.KongSpawnX, Y = lv.Plats[Level.KongPlat].YAt(lv.KongSpawnX),
            Dir = 1, CurPlat = Level.KongPlat, State = BState.Roll, Speed = speed
        });
        Sfx.Roll.Play();
    }

    static bool CircleHitsRect(float cx, float cy, float r, RectangleF rc)
    {
        float nx = Math.Clamp(cx, rc.Left, rc.Right), ny = Math.Clamp(cy, rc.Top, rc.Bottom);
        float dx = cx - nx, dy = cy - ny;
        return dx * dx + dy * dy < r * r;
    }

    void UpdateBarrels(float dt)
    {
        for (int i = barrels.Count - 1; i >= 0; i--)
        {
            var b = barrels[i];
            b.Update(dt, lv, rng);
            if (b.Dead)
            {
                if (b.CurPlat == 0) Spark(b.X, b.Y - 12, 8, Color.OrangeRed, 160f);   // fell into the oil drum
                barrels.RemoveAt(i);
                continue;
            }
            if (dyingT >= 0) continue;
            if (CircleHitsRect(b.X, b.Y - Cfg.BarrelR, 10.5f, pl.HitBox())) { Die(true); continue; }
            if (!b.Scored && pl.State == PS.Air && b.State != BState.Ladder
                && MathF.Abs(b.X - pl.X) < 16f && pl.Y < b.Y - 14f && pl.Y > b.Y - 80f)
            {
                b.Scored = true; score += 100;
                AddPop(pl.X, pl.Y - 54, "+100", Color.Gold);
                Sfx.Score.Play();
            }
        }
    }

    void UpdateFires(float dt)
    {
        foreach (var f in lv.Fires)
        {
            f.X += f.Dir * f.Speed * dt;
            if (f.X > f.MaxX) { f.X = f.MaxX; f.Dir = -1f; }
            if (f.X < f.MinX) { f.X = f.MinX; f.Dir = 1f; }
            if (dyingT >= 0) continue;
            float y = lv.Plats[f.PlatId].YAt(f.X);
            if (new RectangleF(f.X - 6, y - 20, 12, 20).IntersectsWith(pl.HitBox())) Die(true);
        }
    }

    void UpdateBonuses()
    {
        if (dyingT >= 0) return;
        foreach (var b in lv.Bonuses)
        {
            if (b.Taken) continue;
            float dx = b.X - pl.X, dy = b.Y - (pl.Y - 20f);
            if (dx * dx + dy * dy < 20f * 20f)
            {
                b.Taken = true; score += 100;
                AddPop(b.X, b.Y - 16, "+100", Color.Gold);
                Spark(b.X, b.Y, 8, Color.Gold, 150f);
                Sfx.Collect.Play();
            }
        }
    }

    // ---------------- lives / victory ----------------
    void Die(bool hit)
    {
        if (dyingT >= 0 || victoryT >= 0) return;
        dyingT = 1.5f; dyElapsed = 0; dyVY = -320f;
        (hit ? Sfx.Hit : Sfx.Lose).Play();
        Spark(pl.X, pl.Y - 20, 12, Color.OrangeRed, 220f);
    }

    void UpdateDying(float dt)
    {
        dyElapsed += dt;
        dyVY += Cfg.Gravity * 0.8f * dt;
        pl.Y += dyVY * dt;
        dyingT -= dt;
        if (dyingT <= 0)
        {
            lives--;
            dyingT = -1f;
            if (lives <= 0) EndGame(false); else Respawn();
        }
    }

    void Win()
    {
        victoryT = 0; score += 500;
        AddPop(pl.X, pl.Y - 54, "+500", Color.Cyan);
        Sfx.Win.Play();
        foreach (var b in barrels) Spark(b.X, b.Y - 12, 6, Color.OrangeRed, 140f);
        barrels.Clear();
        pl.Lad = null;
    }

    void UpdateVictory(float dt)
    {
        victoryT += dt;
        float targetX = lv.GirlPos.X - 28f;
        if (victoryT < 1.6f && MathF.Abs(pl.X - targetX) > 2f)
        {
            int d = pl.X < targetX ? 1 : -1;
            pl.X += d * 90f * dt; pl.Facing = d; pl.WalkAnim += dt * 10f;
        }
        else pl.Facing = 1;
        pl.Y = lv.Plats[Level.TopPlat].YAt(pl.X);
        if (victoryT > 1.6f && (int)(victoryT * 5f) != (int)((victoryT - dt) * 5f)) SpawnHeart();
        if (victoryT > 4.0f) { score += 1000; EndGame(true); }
    }

    // ---------------- rendering ----------------
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Color.Black);
        int availH = Math.Max(1, ClientSize.Height - FooterH);
        float s = MathF.Min(ClientSize.Width / (float)Cfg.W, availH / (float)Cfg.H);
        if (s > 0.01f)
        {
            var gs = g.Save();
            g.TranslateTransform((ClientSize.Width - Cfg.W * s) / 2f, (availH - Cfg.H * s) / 2f);
            g.ScaleTransform(s, s);
            g.SetClip(new RectangleF(0, 0, Cfg.W, Cfg.H));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAlias;
            DrawGame(g);
            g.Restore(gs);
        }
        DrawFooter(g);   // always drawn last: title, play, pause, game over, victory, fullscreen
    }

    void DrawFooter(Graphics g)
    {
        int w = ClientSize.Width, y = ClientSize.Height - FooterH;
        if (y < 0) return;
        g.ResetClip();
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        using (var br = new SolidBrush(Color.FromArgb(255, 8, 10, 28))) g.FillRectangle(br, 0, y, w, FooterH);
        using (var pen = new Pen(Color.FromArgb(255, 90, 120, 200))) g.DrawLine(pen, 0, y, w, y);
        var size = g.MeasureString(Footer, FooterFont);
        float k = MathF.Min(1f, (w - 16) / MathF.Max(1f, size.Width));   // shrink instead of cropping
        var gs = g.Save();
        g.TranslateTransform(w / 2f, y + FooterH / 2f + 1f);
        g.ScaleTransform(k, k);
        using var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        g.DrawString(Footer, FooterFont, Brushes.White, 0f, 0f, sf);
        g.Restore(gs);
    }

    bool NearPlayer(Barrel b) => dyingT < 0 && MathF.Abs(b.X - pl.X) < 110f && MathF.Abs(b.Y - pl.Y) < 60f;

    void DrawGame(Graphics g)
    {
        if (state == GameState.Title) { Renderer.Title(g, lv, t); return; }

        Renderer.Scene(g, lv, t);
        foreach (var b in lv.Bonuses) if (!b.Taken) Renderer.DrawBonus(g, b, t);
        foreach (var f in lv.Fires) Renderer.DrawFire(g, lv, f, t);
        Renderer.DrawKong(g, lv.KongPos.X, lv.KongPos.Y, 0.7f, kong, t);
        Renderer.DrawGirl(g, lv.GirlPos.X, lv.GirlPos.Y, t, victoryT >= 0);
        foreach (var b in barrels) Renderer.DrawBarrel(g, b, NearPlayer(b), t);

        JPose pose; float spin = 0f;
        if (dyingT >= 0) { pose = JPose.Hurt; spin = dyElapsed * 720f; }
        else if (victoryT >= 0) pose = victoryT < 1.6f && state == GameState.Playing ? JPose.Walk : JPose.Cheer;
        else if (pl.State == PS.Ladder) pose = JPose.Climb;
        else if (pl.State == PS.Air) pose = JPose.Jump;
        else if (pl.LandT > 0) pose = JPose.Land;
        else if (pl.Moving) pose = JPose.Walk;
        else pose = JPose.Idle;
        float anim = pose == JPose.Climb ? pl.ClimbAnim : pose == JPose.Cheer || pose == JPose.Idle ? t * 3f : pl.WalkAnim;
        Renderer.DrawJack(g, pl.X, pl.Y, pl.Facing, pose, anim, spin);

        foreach (var p in parts) Renderer.DrawParticle(g, p);
        foreach (var p in pops) Renderer.DrawPop(g, p);
        Renderer.Hud(g, score, Math.Max(score, highScore), lives, 1);

        switch (state)
        {
            case GameState.Paused:
                Renderer.Overlay(g, "PAUSED", Color.White, new[] { "RESUME", "RESTART" }, pauseSel, "UP/DOWN + ENTER   (ESC: resume, R: restart)", t);
                break;
            case GameState.GameOver:
                Renderer.Overlay(g, "GAME OVER", Color.OrangeRed, new[] { $"FINAL SCORE  {score:D6}" }, -1, "PRESS ENTER TO RESTART", t, 190);
                break;
            case GameState.Complete:
                Renderer.Overlay(g, "LEVEL COMPLETE", Color.Gold, new[] { $"FINAL SCORE  {score:D6}", "THE RESCUE IS DONE!" }, -1, "PRESS ENTER TO PLAY AGAIN", t, 90);
                break;
        }
    }
}
