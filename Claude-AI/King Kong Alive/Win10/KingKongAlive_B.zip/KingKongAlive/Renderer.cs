using System.Drawing;
using System.Drawing.Drawing2D;

namespace KingKongAlive;

public enum JPose { Idle, Walk, Climb, Jump, Land, Hurt, Cheer }

/// <summary>All drawing code: static background is pre-rendered once, characters are drawn from primitives.</summary>
public static class Renderer
{
    // ---------- helpers ----------
    static Color C(int r, int g, int b, int a = 255) => Color.FromArgb(a, r, g, b);
    static SolidBrush B(int r, int g, int b, int a = 255) => new(C(r, g, b, a));
    static Pen P(int r, int g, int b, float w, int a = 255) =>
        new(C(r, g, b, a), w) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round };
    static float Mod(float a, float m) => ((a % m) + m) % m;
    static float Lerp(float a, float b, float u) => a + (b - a) * u;

    static readonly SolidBrush WhiteB = B(255, 255, 255), BlackB = B(24, 14, 40);
    static readonly Pen Ol = P(30, 16, 10, 2f);

    static readonly Font FLabel = new("Consolas", 14f, FontStyle.Bold, GraphicsUnit.Pixel);
    static readonly Font FValue = new("Consolas", 24f, FontStyle.Bold, GraphicsUnit.Pixel);
    static readonly Font FMid = new("Consolas", 28f, FontStyle.Bold, GraphicsUnit.Pixel);
    static readonly Font FSmall = new("Consolas", 16f, FontStyle.Bold, GraphicsUnit.Pixel);
    static readonly Font FPop = new("Consolas", 20f, FontStyle.Bold, GraphicsUnit.Pixel);
    static readonly Font FOverlay = new("Arial Black", 48f, FontStyle.Regular, GraphicsUnit.Pixel);

    public static void Text(Graphics g, string s, Font f, Color c, float x, float y, StringAlignment al = StringAlignment.Near, int shadow = 2)
    {
        using var sf = new StringFormat { Alignment = al, LineAlignment = StringAlignment.Near };
        if (shadow > 0) { using var sb = new SolidBrush(C(0, 0, 0, Math.Min(200, (int)c.A))); g.DrawString(s, f, sb, x + shadow, y + shadow, sf); }
        using var br = new SolidBrush(c);
        g.DrawString(s, f, br, x, y, sf);
    }

    static GraphicsPath RoundRect(RectangleF r, float rad)
    {
        var p = new GraphicsPath(); float d = rad * 2;
        p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure(); return p;
    }

    // ================= STATIC BACKGROUND =================
    static Bitmap? bg;
    public static void Prepare(Level lv) { bg ??= BuildStatic(lv); }

    static Bitmap BuildStatic(Level lv)
    {
        var bmp = new Bitmap(Cfg.W, Cfg.H);
        using var g = Graphics.FromImage(bmp);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var rect = new Rectangle(0, 0, Cfg.W, Cfg.H);
        using (var br = new LinearGradientBrush(rect, C(12, 16, 70), C(240, 120, 100), 90f))
        {
            br.InterpolationColors = new ColorBlend
            {
                Positions = new[] { 0f, 0.5f, 1f },
                Colors = new[] { C(12, 16, 70), C(80, 50, 150), C(240, 120, 100) }
            };
            g.FillRectangle(br, rect);
        }
        var rnd = new Random(4);
        using (var star = B(255, 255, 255, 200)) for (int i = 0; i < 70; i++) g.FillRectangle(star, rnd.Next(Cfg.W), rnd.Next(330), 2, 2);
        using (var glow = B(255, 210, 120, 50)) g.FillEllipse(glow, 410, 530, 140, 140);
        using (var sun = B(255, 232, 150)) g.FillEllipse(sun, 446, 566, 68, 68);

        Skyline(g, rnd, 640, 120, 300, C(70, 55, 130), 0);
        Skyline(g, rnd, 720, 150, 380, C(28, 24, 76), 0.3);
        using (var tw = B(34, 32, 92))
        {
            g.FillRectangle(tw, 770, 400, 60, 320); g.FillRectangle(tw, 780, 340, 40, 60);
            g.FillRectangle(tw, 790, 290, 20, 50); g.FillRectangle(tw, 798, 200, 4, 90);
        }
        DrawCrane(g);

        foreach (var pl in lv.Plats)
            for (float x = pl.X1 + 40; x < pl.X2 - 20; x += 150)
            {
                float y0 = pl.YAt(x) + Cfg.PlatThick;
                DrawColumn(g, x, y0, pl.Id == 0 ? Cfg.H : y0 + 86f);
            }
        foreach (var pl in lv.Plats) DrawGirder(g, pl);
        foreach (var l in lv.Ladders) DrawLadder(g, lv, l);

        DrawWarning(g, 60, lv.Plats[0].YAt(60));
        DrawWarning(g, 120, lv.Plats[2].YAt(120));
        DrawWarning(g, 880, lv.Plats[5].YAt(880));
        DrawWarning(g, 760, lv.Plats[6].YAt(760));
        DrawDrum(g, lv);
        return bmp;
    }

    static void Skyline(Graphics g, Random rnd, float baseY, int minH, int maxH, Color col, double winChance)
    {
        using var br = new SolidBrush(col); using var win = B(255, 215, 110);
        float x = -10;
        while (x < Cfg.W)
        {
            float w = rnd.Next(28, 60), h = rnd.Next(minH, maxH);
            g.FillRectangle(br, x, baseY - h, w, h);
            if (winChance > 0)
                for (float wy = baseY - h + 8; wy < baseY - 8; wy += 10)
                    for (float wx = x + 5; wx < x + w - 6; wx += 8)
                        if (rnd.NextDouble() < winChance) g.FillRectangle(win, wx, wy, 3, 4);
            x += w + rnd.Next(0, 6);
        }
    }

    static void DrawCrane(Graphics g)
    {
        using (var mast = B(62, 28, 44)) g.FillRectangle(mast, 918, 0, 28, Cfg.H);
        using (var lat = P(120, 54, 66, 2f))
            for (int y = 0; y < Cfg.H; y += 24) { g.DrawLine(lat, 918, y, 946, y + 24); g.DrawLine(lat, 946, y, 918, y + 24); }
        using (var jib = B(80, 36, 52)) g.FillRectangle(jib, 690, 46, 256, 10);
        using (var rope = P(150, 150, 160, 2f)) g.DrawLine(rope, 730, 56, 730, 130);
        using (var cage = B(70, 76, 96)) g.FillRectangle(cage, 718, 130, 24, 20);
        g.DrawRectangle(Ol, 718, 130, 24, 20);
    }

    static void DrawColumn(Graphics g, float x, float y0, float y1)
    {
        using var br = new LinearGradientBrush(new RectangleF(x - 6, y0, 12, y1 - y0), C(104, 116, 190), C(44, 54, 116), 0f);
        g.FillRectangle(br, x - 6, y0, 12, y1 - y0);
        using var pen = P(24, 28, 70, 1.5f);
        g.DrawRectangle(pen, x - 6, y0, 12, y1 - y0);
        using var riv = B(170, 180, 230);
        for (float y = y0 + 8; y < y1 - 4; y += 24) g.FillEllipse(riv, x - 1.5f, y, 3, 3);
    }

    public static void DrawGirder(Graphics g, Plat p)
    {
        float th = Cfg.PlatThick;
        var poly = new[] { new PointF(p.X1, p.Y1), new PointF(p.X2, p.Y2), new PointF(p.X2, p.Y2 + th), new PointF(p.X1, p.Y1 + th) };
        if (p.Style == 0)
        {
            using (var fill = B(196, 36, 46)) g.FillPolygon(fill, poly);
            using (var truss = P(112, 14, 30, 2f))
                for (float x = p.X1; x < p.X2 - 14; x += 14)
                {
                    g.DrawLine(truss, x, p.YAt(x) + 3, x + 7, p.YAt(x + 7) + th - 3);
                    g.DrawLine(truss, x + 7, p.YAt(x + 7) + th - 3, x + 14, p.YAt(x + 14) + 3);
                }
            using (var lip = P(255, 130, 80, 3f)) g.DrawLine(lip, p.X1, p.Y1 + 1.5f, p.X2, p.Y2 + 1.5f);
            using (var bot = P(90, 10, 25, 3f)) g.DrawLine(bot, p.X1, p.Y1 + th, p.X2, p.Y2 + th);
            using (var riv = B(255, 176, 146))
                for (float x = p.X1 + 8; x < p.X2; x += 28) g.FillEllipse(riv, x - 1.5f, p.YAt(x) + th / 2 - 1.5f, 3, 3);
        }
        else
        {
            using (var fill = B(150, 96, 48)) g.FillPolygon(fill, poly);
            using (var planks = P(92, 56, 26, 1.5f))
                for (float x = p.X1 + 20; x < p.X2; x += 22) g.DrawLine(planks, x, p.YAt(x), x, p.YAt(x) + th);
            using (var lip = P(214, 156, 90, 3f)) g.DrawLine(lip, p.X1, p.Y1 + 1.5f, p.X2, p.Y2 + 1.5f);
        }
        using (var outline = P(40, 12, 16, 2f)) g.DrawPolygon(outline, poly);
    }

    static void DrawLadder(Graphics g, Level lv, Ladder l)
    {
        float top = lv.Plats[l.Upper].YAt(l.X), bot = lv.Plats[l.Lower].YAt(l.X);
        using var rail = P(70, 170, 240, 3f); using var rung = P(40, 120, 200, 2.5f); using var hi = P(190, 230, 255, 1f);
        g.DrawLine(rail, l.X - 9, top, l.X - 9, bot); g.DrawLine(rail, l.X + 9, top, l.X + 9, bot);
        for (float y = bot - 6; y > top + 2; y -= 10) g.DrawLine(rung, l.X - 9, y, l.X + 9, y);
        g.DrawLine(hi, l.X - 10, top, l.X - 10, bot);
    }

    static void DrawWarning(Graphics g, float x, float y)
    {
        using (var pole = P(90, 90, 110, 3f)) g.DrawLine(pole, x, y, x, y - 40);
        var d = new[] { new PointF(x, y - 74), new PointF(x + 16, y - 58), new PointF(x, y - 42), new PointF(x - 16, y - 58) };
        using (var yel = B(255, 210, 30)) g.FillPolygon(yel, d);
        g.DrawPolygon(Ol, d);
        g.FillRectangle(BlackB, x - 1.5f, y - 68, 3, 8); g.FillEllipse(BlackB, x - 1.5f, y - 56, 3, 3);
    }

    static void DrawDrum(Graphics g, Level lv)
    {
        float x = lv.DrumX, y = lv.Plats[0].YAt(x - 20);
        using (var body = B(50, 100, 170)) g.FillRectangle(body, x - 40, y - 46, 40, 46);
        using (var hoop = P(180, 190, 210, 3f)) { g.DrawLine(hoop, x - 40, y - 36, x, y - 36); g.DrawLine(hoop, x - 40, y - 10, x, y - 10); }
        using (var band = B(255, 205, 30)) g.FillRectangle(band, x - 40, y - 28, 40, 12);
        using (var stripe = B(30, 30, 40)) for (float sx = x - 40; sx < x; sx += 10) g.FillRectangle(stripe, sx, y - 28, 5, 12);
        g.DrawRectangle(Ol, x - 40, y - 46, 40, 46);
    }

    // ================= ANIMATED SCENE =================
    public static void Scene(Graphics g, Level lv, float t)
    {
        Prepare(lv);
        g.DrawImageUnscaled(bg!, 0, 0);
        foreach (var p in lv.Plats)
        {
            int i = 0;
            for (float x = p.X1 + 10; x < p.X2 - 5; x += 38, i++)
            {
                float y = p.YAt(x) + Cfg.PlatThick + 5;
                float a = 0.5f + 0.5f * MathF.Sin(t * 3f + i * 0.9f + p.Id);
                Color col = i % 3 == 0 ? C(255, 80, 80) : i % 3 == 1 ? C(255, 220, 80) : C(90, 200, 255);
                using var glow = new SolidBrush(Color.FromArgb((int)(60 + 120 * a), col));
                g.FillEllipse(glow, x - 5, y - 5, 10, 10);
                using var core = new SolidBrush(Color.FromArgb((int)(120 + 135 * a), 255, 255, 230));
                g.FillEllipse(core, x - 2, y - 2, 4, 4);
            }
        }
        float dy = lv.Plats[0].YAt(lv.DrumX - 20);
        DrawFlame(g, lv.DrumX - 20, dy - 46, t, 1.1f, false);
    }

    // ================= OBJECTS =================
    public static void DrawBarrelRaw(Graphics g, float cx, float cy, float rot, float s)
    {
        var gs = g.Save();
        g.TranslateTransform(cx, cy); g.ScaleTransform(s, s); g.RotateTransform(rot * 180f / MathF.PI);
        using var body = B(168, 98, 46); using var dark = B(110, 62, 28);
        g.FillEllipse(body, -12, -12, 24, 24);
        using (var stv = P(100, 56, 24, 1.5f))
            for (int k = 0; k < 4; k++)
            {
                float a = k * MathF.PI / 4f;
                g.DrawLine(stv, MathF.Cos(a) * 12, MathF.Sin(a) * 12, -MathF.Cos(a) * 12, -MathF.Sin(a) * 12);
            }
        using (var hoop = P(190, 195, 205, 2.5f)) { g.DrawEllipse(hoop, -10, -10, 20, 20); g.DrawEllipse(hoop, -5, -5, 10, 10); }
        g.DrawEllipse(Ol, -12, -12, 24, 24);
        g.FillEllipse(dark, -2.5f, -2.5f, 5, 5);
        g.Restore(gs);
    }

    public static void DrawBarrel(Graphics g, Barrel b, bool near, float t)
    {
        DrawBarrelRaw(g, b.X, b.Y - Cfg.BarrelR, b.Rot, 1f);
        if (near && ((int)(t * 8f) & 1) == 0)
        {   // warning marker above a barrel that is close to the player
            float x = b.X, y = b.Y - 40;
            var tri = new[] { new PointF(x, y - 14), new PointF(x + 9, y + 2), new PointF(x - 9, y + 2) };
            using var yel = B(255, 220, 40);
            g.FillPolygon(yel, tri); g.DrawPolygon(Ol, tri);
            g.FillRectangle(BlackB, x - 1, y - 8, 2, 6); g.FillEllipse(BlackB, x - 1, y - 1, 2, 2);
        }
    }

    public static void DrawFlame(Graphics g, float x, float y, float t, float s, bool eyes)
    {
        var gs = g.Save();
        g.TranslateTransform(x, y); g.ScaleTransform(s, s);
        float fl = MathF.Sin(t * 12f + x);
        PointF[] Shape(float k) => new[]
        {
            new PointF(-11 * k, 0), new PointF(-13 * k, -14 * k), new PointF(-6 * k, (-22 - fl * 3) * k),
            new PointF(-3 * k, (-34 - fl * 4) * k), new PointF(2 * k, -24 * k), new PointF(8 * k, (-32 + fl * 3) * k),
            new PointF(12 * k, -16 * k), new PointF(11 * k, 0)
        };
        using (var o = B(255, 90, 0)) g.FillClosedCurve(o, Shape(1f));
        using (var m = B(255, 170, 0)) g.FillClosedCurve(m, Shape(0.7f));
        using (var i = B(255, 240, 130)) g.FillClosedCurve(i, Shape(0.4f));
        if (eyes)
        {
            g.FillEllipse(WhiteB, -7, -14, 6, 6); g.FillEllipse(WhiteB, 1, -14, 6, 6);
            g.FillEllipse(BlackB, -5, -12, 3, 4); g.FillEllipse(BlackB, 3, -12, 3, 4);
            using var brow = P(90, 20, 0, 1.5f);
            g.DrawLine(brow, -8, -17, -2, -15); g.DrawLine(brow, 8, -17, 2, -15);
        }
        g.Restore(gs);
    }

    public static void DrawFire(Graphics g, Level lv, Fire f, float t)
    {
        float y = lv.Plats[f.PlatId].YAt(f.X);
        DrawFlame(g, f.X, y, t, 0.8f, true);
    }

    public static void DrawBonus(Graphics g, Bonus b, float t)
    {
        var gs = g.Save();
        g.TranslateTransform(b.X, b.Y + MathF.Sin(t * 3f + b.Phase) * 2f);
        g.RotateTransform(MathF.Sin(t * 2f + b.Phase) * 18f);
        using (var glow = B(255, 220, 60, 55)) g.FillEllipse(glow, -15, -15, 30, 30);
        using var gold = B(255, 205, 40); using var dark = B(150, 100, 0);
        g.FillRectangle(gold, -2.5f, -6, 5, 16);
        g.FillEllipse(gold, -7, -14, 14, 11);
        g.FillRectangle(BlackB, -2, -15, 4, 6);
        g.FillEllipse(dark, -2.5f, 7, 5, 4);
        g.DrawEllipse(Ol, -7, -14, 14, 11);
        using (var hi = P(255, 255, 210, 1.5f)) g.DrawLine(hi, -1, -4, -1, 6);
        g.Restore(gs);
    }

    static void DrawHeart(Graphics g, float x, float y, float s, Color c)
    {
        using var br = new SolidBrush(c);
        g.FillEllipse(br, x - s, y - s, s, s); g.FillEllipse(br, x, y - s, s, s);
        g.FillPolygon(br, new[] { new PointF(x - s, y - s * 0.4f), new PointF(x + s, y - s * 0.4f), new PointF(x, y + s * 1.1f) });
    }

    public static void DrawParticle(Graphics g, Particle p)
    {
        float k = p.Life / p.Max; int a = (int)(255 * Math.Clamp(k * 1.5f, 0f, 1f));
        var col = Color.FromArgb(a, p.Col);
        if (p.Kind == 1) { DrawHeart(g, p.X, p.Y, p.Size, col); return; }
        float s = p.Size * (0.4f + k);
        using var br = new SolidBrush(col);
        g.FillPolygon(br, new[]
        {
            new PointF(p.X, p.Y - s), new PointF(p.X + s * 0.3f, p.Y - s * 0.3f), new PointF(p.X + s, p.Y), new PointF(p.X + s * 0.3f, p.Y + s * 0.3f),
            new PointF(p.X, p.Y + s), new PointF(p.X - s * 0.3f, p.Y + s * 0.3f), new PointF(p.X - s, p.Y), new PointF(p.X - s * 0.3f, p.Y - s * 0.3f)
        });
    }

    public static void DrawPop(Graphics g, Pop p)
    {
        int a = (int)(255 * Math.Clamp(p.Life * 2f, 0f, 1f));
        Text(g, p.Text, FPop, Color.FromArgb(a, p.Col), p.X, p.Y, StringAlignment.Center, 1);
    }

    // ================= JACK THE BUILDER =================
    static PointF Hand(JPose pose, float anim, float bob, int which)
    {
        float ph = anim + (which == 0 ? 0f : MathF.PI);
        switch (pose)
        {
            case JPose.Walk: return new PointF(2 + MathF.Sin(ph) * 6, -16 + bob);
            case JPose.Climb: return new PointF(which == 0 ? 4 : -4, -36 + bob - (which == 0 ? 1 : -1) * MathF.Sin(anim) * 4);
            case JPose.Jump: return which == 0 ? new PointF(8, -37 + bob) : new PointF(-6, -34 + bob);
            case JPose.Cheer: return new PointF(which == 0 ? 7 : -7, -42 + bob + (which == 0 ? 1 : -1) * MathF.Sin(anim * 3) * 3);
            case JPose.Hurt: return which == 0 ? new PointF(-8, -33) : new PointF(8, -29);
            default: return new PointF(which == 0 ? 5 : -5, -13 + bob + MathF.Sin(anim * 2 + ph) * 0.8f);
        }
    }

    static void DrawArm(Graphics g, PointF sh, PointF hand)
    {
        using (var o = P(30, 20, 40, 7f)) g.DrawLine(o, sh, hand);
        using (var i = P(240, 110, 40, 5f)) g.DrawLine(i, sh, hand);
        using var glove = B(226, 186, 140);
        g.FillEllipse(glove, hand.X - 3.5f, hand.Y - 3.5f, 7, 7); g.DrawEllipse(Ol, hand.X - 3.5f, hand.Y - 3.5f, 7, 7);
    }

    public static void DrawJack(Graphics g, float x, float y, int facing, JPose pose, float anim, float spin, float scale = 1f)
    {
        var gs = g.Save();
        g.TranslateTransform(x, y);
        g.ScaleTransform(facing * scale, scale);
        float hop = pose == JPose.Cheer ? -MathF.Abs(MathF.Sin(anim * 1.5f)) * 6f : 0f;
        g.TranslateTransform(0, hop);
        if (pose == JPose.Land) g.ScaleTransform(1.15f, 0.85f);
        if (pose == JPose.Hurt) { g.TranslateTransform(0, -20); g.RotateTransform(spin); g.TranslateTransform(0, 20); }
        float bob = pose == JPose.Idle ? MathF.Sin(anim * 2f) * 0.8f : 0f;

        PointF f1, f2;
        switch (pose)
        {
            case JPose.Walk:
                f1 = new PointF(MathF.Sin(anim) * 7, -MathF.Max(0, MathF.Cos(anim)) * 4);
                f2 = new PointF(MathF.Sin(anim + MathF.PI) * 7, -MathF.Max(0, MathF.Cos(anim + MathF.PI)) * 4); break;
            case JPose.Jump: f1 = new PointF(7, -8); f2 = new PointF(-5, -4); break;
            case JPose.Climb: f1 = new PointF(3, -MathF.Sin(anim) * 5); f2 = new PointF(-3, MathF.Sin(anim) * 5); break;
            case JPose.Hurt: f1 = new PointF(6, -6); f2 = new PointF(-6, -3); break;
            case JPose.Cheer: f1 = new PointF(6, 0); f2 = new PointF(-6, 0); break;
            default: f1 = new PointF(3, 0); f2 = new PointF(-3, 0); break;
        }
        var hip = new PointF(0, -15 + bob);
        using (var lo = P(30, 20, 40, 9f)) using (var li = P(40, 90, 200, 6f))
            foreach (var f in new[] { f2, f1 })
            {
                g.DrawLine(lo, hip, f); g.DrawLine(li, hip, f);
            }
        using (var boot = B(112, 62, 30))
            foreach (var f in new[] { f2, f1 })
            {
                g.FillEllipse(boot, f.X - 5, f.Y - 6, 14, 7); g.DrawEllipse(Ol, f.X - 5, f.Y - 6, 14, 7);
            }

        DrawArm(g, new PointF(0, -25 + bob), Hand(pose, anim, bob, 1));       // back arm

        using (var shirt = B(240, 110, 40)) g.FillEllipse(shirt, -8, -29 + bob, 16, 17);
        g.DrawEllipse(Ol, -8, -29 + bob, 16, 17);
        using (var blue = B(40, 90, 200)) { g.FillRectangle(blue, -6, -24 + bob, 12, 9); g.FillRectangle(blue, -7, -17 + bob, 14, 5); }
        using (var strap = P(40, 90, 200, 2.5f)) { g.DrawLine(strap, -4, -29 + bob, -4, -24 + bob); g.DrawLine(strap, 4, -29 + bob, 4, -24 + bob); }
        using (var belt = B(122, 80, 40)) g.FillRectangle(belt, -8, -18 + bob, 16, 3);
        using (var metal = B(196, 200, 212)) g.FillRectangle(metal, 5, -17 + bob, 3, 7);
        using (var btn = B(255, 214, 60)) { g.FillEllipse(btn, -4.5f, -23 + bob, 2.5f, 2.5f); g.FillEllipse(btn, 2, -23 + bob, 2.5f, 2.5f); }

        // head
        float hy = -35 + bob;
        using (var skin = B(255, 214, 180)) g.FillEllipse(skin, -8.5f, hy - 8.5f, 17, 17);
        g.DrawEllipse(Ol, -8.5f, hy - 8.5f, 17, 17);
        using (var hair = B(200, 90, 30)) g.FillEllipse(hair, pose == JPose.Climb ? -8f : -10f, hy - 3, pose == JPose.Climb ? 16f : 7f, 9);
        if (pose != JPose.Climb)
        {
            if (pose == JPose.Hurt)
            {
                using var xp = P(24, 14, 46, 1.5f);
                g.DrawLine(xp, 1, hy - 1, 6, hy + 4); g.DrawLine(xp, 6, hy - 1, 1, hy + 4);
            }
            else
            {
                g.FillEllipse(WhiteB, 1, hy - 1, 5.5f, 6.5f); g.FillEllipse(BlackB, 3.2f, hy + 1, 2.6f, 3.6f);
            }
            using (var nose = B(236, 180, 146)) g.FillEllipse(nose, 7, hy + 2, 3.5f, 3.5f);
            if (pose == JPose.Jump || pose == JPose.Cheer || pose == JPose.Hurt) g.FillEllipse(BlackB, 2, hy + 5, 5, 4);
            else using (var sm = P(120, 50, 40, 1.5f)) g.DrawArc(sm, 1, hy + 3, 7, 4, 20, 140);
        }
        // helmet
        using (var hel = B(255, 205, 30)) g.FillPie(hel, -10, hy - 12, 20, 18, 180, 180);
        g.DrawArc(Ol, -10, hy - 12, 20, 18, 180, 180);
        using (var brim = B(224, 152, 0)) g.FillEllipse(brim, -12, hy - 4.5f, 24, 4);
        using (var stripe = B(255, 255, 255)) g.FillRectangle(stripe, 1, hy - 11, 3, 6);

        DrawArm(g, new PointF(0, -25 + bob), Hand(pose, anim, bob, 0));       // front arm
        g.Restore(gs);
    }

    // ================= KING KONG =================
    public static void DrawKong(Graphics g, float x, float y, float scale, Kong k, float t)
    {
        var gs = g.Save();
        g.TranslateTransform(x, y); g.ScaleTransform(scale, scale);
        float bob = MathF.Sin(t * 2.2f) * 2f;
        g.TranslateTransform(k.Agitated ? MathF.Sin(t * 30f) * 1.5f : 0f, 0);
        using var fur = B(88, 52, 30); using var furD = B(60, 34, 20); using var furL = B(124, 78, 48); using var skin = B(166, 114, 84);
        using var penO = P(30, 16, 10, 34f); using var penF = P(88, 52, 30, 28f);

        g.FillEllipse(furD, -50, -34, 40, 34); g.FillEllipse(furD, 10, -34, 40, 34);
        g.FillEllipse(furL, -46, -10, 32, 12); g.FillEllipse(furL, 14, -10, 32, 12);
        g.FillEllipse(fur, -60, -122 + bob, 120, 104); g.DrawEllipse(Ol, -60, -122 + bob, 120, 104);
        g.FillEllipse(skin, -34, -104 + bob, 68, 72);
        using (var pec = P(60, 34, 20, 2f)) g.DrawLine(pec, 0, -100 + bob, 0, -72 + bob);

        PointF hl, hr; bool barrel = false;
        switch (k.State)
        {
            case KongState.Grab:
            {
                float u = Math.Clamp(k.StateT / 0.6f, 0f, 1f);
                hl = new PointF(Lerp(-72, -24, u), Lerp(-34, -150, u) + bob);
                hr = new PointF(Lerp(72, 24, u), Lerp(-34, -150, u) + bob);
                barrel = u > 0.5f; break;
            }
            case KongState.Throw:
            {
                float u = Math.Clamp(k.StateT / 0.3f, 0f, 1f);
                hl = new PointF(-72, -34 + bob);
                hr = new PointF(Lerp(30, 92, u), Lerp(-150, -98, u) + bob); break;
            }
            default:
                if (k.Agitated)
                {
                    float b = MathF.Sin(t * 10f);
                    hl = new PointF(-26, -84 + bob + (b > 0 ? -8 : 0)); hr = new PointF(26, -84 + bob + (b > 0 ? 0 : -8));
                }
                else
                {
                    hl = new PointF(-72 + MathF.Sin(t * 2f) * 3, -34 + bob); hr = new PointF(72 - MathF.Sin(t * 2f) * 3, -34 + bob);
                }
                break;
        }
        foreach (var (sh, hand) in new[] { (new PointF(-52, -104 + bob), hl), (new PointF(52, -104 + bob), hr) })
        {
            g.DrawLine(penO, sh, hand); g.DrawLine(penF, sh, hand);
            g.FillEllipse(furL, hand.X - 15, hand.Y - 15, 30, 30); g.DrawEllipse(Ol, hand.X - 15, hand.Y - 15, 30, 30);
        }
        if (barrel) DrawBarrelRaw(g, 0, -164 + bob, 0, 1.4f);

        float hy = -134 + bob;
        g.FillEllipse(furD, -36, hy - 4, 10, 14); g.FillEllipse(furD, 26, hy - 4, 10, 14);
        g.FillEllipse(furD, -32, hy - 26, 64, 52); g.DrawEllipse(Ol, -32, hy - 26, 64, 52);
        g.FillEllipse(skin, -22, hy - 12, 44, 34);
        using (var brow = P(20, 10, 6, 6f)) { g.DrawLine(brow, -22, hy - 6, -4, hy - 1); g.DrawLine(brow, 22, hy - 6, 4, hy - 1); }
        g.FillEllipse(WhiteB, -17, hy - 3, 11, 8); g.FillEllipse(WhiteB, 6, hy - 3, 11, 8);
        g.FillEllipse(BlackB, -12, hy - 1.5f, 4, 5); g.FillEllipse(BlackB, 9, hy - 1.5f, 4, 5);
        g.FillEllipse(furD, -6, hy + 10, 4, 3); g.FillEllipse(furD, 2, hy + 10, 4, 3);
        if (k.Agitated || k.State == KongState.Throw)
        {
            using var mouth = B(50, 10, 10);
            g.FillEllipse(mouth, -14, hy + 14, 28, 14);
            g.FillRectangle(WhiteB, -10, hy + 14, 5, 4); g.FillRectangle(WhiteB, 5, hy + 14, 5, 4);
        }
        else
        {
            using (var sm = P(30, 10, 10, 2.5f)) g.DrawArc(sm, -12, hy + 12, 24, 10, 10, 160);
            g.FillPolygon(WhiteB, new[] { new PointF(5, hy + 21), new PointF(9, hy + 21), new PointF(7, hy + 26) });
        }
        var crown = new[] { new PointF(-14, hy - 24), new PointF(-14, hy - 38), new PointF(-7, hy - 30), new PointF(0, hy - 42), new PointF(7, hy - 30), new PointF(14, hy - 38), new PointF(14, hy - 24) };
        using (var gold = B(255, 200, 40)) g.FillPolygon(gold, crown);
        g.DrawPolygon(Ol, crown);
        g.Restore(gs);
    }

    // ================= RESCUE CHARACTER =================
    public static void DrawGirl(Graphics g, float x, float y, float t, bool rescued)
    {
        var gs = g.Save();
        g.TranslateTransform(x, y);
        float wave = MathF.Sin(t * 6f);
        using (var leg = P(255, 214, 180, 4f)) { g.DrawLine(leg, -4, -10, -4, 0); g.DrawLine(leg, 4, -10, 4, 0); }
        using (var shoe = B(40, 190, 170)) { g.FillEllipse(shoe, -8, -4, 9, 5); g.FillEllipse(shoe, 0, -4, 9, 5); }
        var dress = new[] { new PointF(-8, -28), new PointF(8, -28), new PointF(14, -8), new PointF(-14, -8) };
        using (var pink = B(255, 80, 150)) g.FillPolygon(pink, dress);
        g.DrawPolygon(Ol, dress);
        using (var belt = P(255, 255, 255, 2f)) g.DrawLine(belt, -9, -21, 9, -21);
        using (var arm = P(255, 214, 180, 4f))
        {
            g.DrawLine(arm, 8, -26, 11, -14);
            var hand = rescued ? new PointF(-14, -44 + wave * 2) : new PointF(-15, -42 + wave * 4);
            g.DrawLine(arm, -8, -26, hand.X, hand.Y);
        }
        using (var skin = B(255, 214, 180)) g.FillEllipse(skin, -9, -45, 18, 18);
        g.DrawEllipse(Ol, -9, -45, 18, 18);
        using (var hair = B(255, 205, 70)) g.FillPie(hair, -11, -48, 22, 18, 180, 180);
        using (var tail = P(255, 205, 70, 5f)) g.DrawLine(tail, 8, -42, 15 + wave * 2, -30);
        using (var bow = B(40, 190, 170)) { g.FillEllipse(bow, -9, -50, 7, 5); g.FillEllipse(bow, -3, -50, 7, 5); }
        g.FillEllipse(WhiteB, -5, -38, 4, 5); g.FillEllipse(WhiteB, 1, -38, 4, 5);
        g.FillEllipse(BlackB, -4, -37, 2, 3); g.FillEllipse(BlackB, 2, -37, 2, 3);
        using (var sm = P(150, 50, 60, 1.5f)) g.DrawArc(sm, -3, -34, 6, 4, 20, 140);
        if (!rescued && MathF.Sin(t * 5f) > -0.2f)
        {
            var r = new RectangleF(14, -54, 58, 22);
            using var path = RoundRect(r, 8);
            using (var bubble = B(255, 255, 255)) g.FillPath(bubble, path);
            g.DrawPath(Ol, path);
            g.FillPolygon(WhiteB, new[] { new PointF(16, -34), new PointF(24, -34), new PointF(10, -28) });
            Text(g, "HELP!", FSmall, Color.FromArgb(255, 200, 30, 50), 43, -51, StringAlignment.Center, 0);
        }
        g.Restore(gs);
    }

    // ================= HUD & SCREENS =================
    static void DrawHelmetIcon(Graphics g, float x, float y)
    {
        using var hel = B(255, 205, 30); using var brim = B(224, 152, 0);
        g.FillPie(hel, x - 9, y - 12, 18, 16, 180, 180);
        g.DrawArc(Ol, x - 9, y - 12, 18, 16, 180, 180);
        g.FillEllipse(brim, x - 11, y - 5, 22, 4);
    }

    public static void Hud(Graphics g, int score, int high, int lives, int level)
    {
        using (var strip = new LinearGradientBrush(new RectangleF(0, 0, Cfg.W, 46), C(0, 0, 0, 200), C(0, 0, 0, 90), 90f))
            g.FillRectangle(strip, 0f, 0f, Cfg.W, 46f);
        using (var line = P(120, 150, 230, 2f, 160)) g.DrawLine(line, 0, 46, Cfg.W, 46);
        Text(g, "SCORE", FLabel, C(255, 220, 60), 20, 4);
        Text(g, score.ToString("D6"), FValue, Color.White, 20, 18);
        Text(g, "HIGH SCORE", FLabel, C(255, 220, 60), 260, 4);
        Text(g, high.ToString("D6"), FValue, Color.White, 260, 18);
        Text(g, "LIVES", FLabel, C(255, 220, 60), 520, 4);
        for (int i = 0; i < lives; i++) DrawHelmetIcon(g, 540 + i * 28, 36);
        Text(g, "LEVEL " + level, FValue, C(120, 220, 255), Cfg.W - 20, 10, StringAlignment.Far);
    }

    public static void Overlay(Graphics g, string title, Color tc, string[] lines, int sel, string footer, float t, int dim = 160)
    {
        using (var br = B(0, 0, 20, dim)) g.FillRectangle(br, 0f, 0f, Cfg.W, Cfg.H);
        var panel = new RectangleF(Cfg.W / 2f - 300, 190, 600, 340);
        using (var path = RoundRect(panel, 18))
        {
            using (var br = B(14, 24, 80, 230)) g.FillPath(br, path);
            using (var pen = P(120, 170, 255, 4f)) g.DrawPath(pen, path);
        }
        Text(g, title, FOverlay, tc, Cfg.W / 2f, 212, StringAlignment.Center, 4);
        float y = 300;
        for (int i = 0; i < lines.Length; i++)
        {
            bool s = i == sel;
            Text(g, (s ? "> " : "") + lines[i], FMid, s ? C(255, 230, 60) : Color.White, Cfg.W / 2f, y, StringAlignment.Center);
            y += 44;
        }
        if (footer.Length > 0 && ((int)(t * 2) & 1) == 0)
            Text(g, footer, FSmall, C(200, 220, 255), Cfg.W / 2f, 480, StringAlignment.Center);
    }

    static void LogoText(Graphics g, string text, float cx, float cy, float em, Color top, Color bottom, Color halo, Color outline, float shear)
    {
        FontFamily fam; try { fam = new FontFamily("Arial Black"); } catch { fam = FontFamily.GenericSansSerif; }
        var gs = g.Save();
        g.TranslateTransform(cx, cy);
        g.MultiplyTransform(new Matrix(1, 0, -shear, 1, 0, 0));
        using (var gp = new GraphicsPath())
        {
            using var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            gp.AddString(text, fam, (int)FontStyle.Regular, em, new PointF(0, 0), sf);
            using (var p1 = P(halo.R, halo.G, halo.B, 16f)) g.DrawPath(p1, gp);
            using (var p2 = P(outline.R, outline.G, outline.B, 8f)) g.DrawPath(p2, gp);
            var bb = gp.GetBounds();
            using var fill = new LinearGradientBrush(bb, top, bottom, 90f);
            g.FillPath(fill, gp);
        }
        g.Restore(gs);
    }

    public static void Title(Graphics g, Level lv, float t)
    {
        Prepare(lv);
        g.DrawImageUnscaled(bg!, 0, 0);
        using (var dim = B(0, 0, 30, 120)) g.FillRectangle(dim, 0f, 0f, Cfg.W, Cfg.H);

        var a = new Plat { X1 = -10, Y1 = 530, X2 = 470, Y2 = 540 };
        var b = new Plat { X1 = 520, Y1 = 560, X2 = 980, Y2 = 548 };
        DrawGirder(g, a); DrawGirder(g, b);
        DrawKong(g, 190, a.YAt(190), 1.8f, new Kong { State = KongState.Idle, Agitated = true }, t);
        float bx = 330 + Mod(t * 70f, 130f);
        DrawBarrelRaw(g, bx, a.YAt(bx) - 22, t * 4f, 1.8f);
        DrawJack(g, 760, b.YAt(760), 1, JPose.Walk, t * 12f, 0f, 3f);
        DrawFlame(g, 900, b.YAt(900), t, 2f, true);

        var crown = new[] { new PointF(450, 52), new PointF(450, 26), new PointF(465, 38), new PointF(480, 14), new PointF(495, 38), new PointF(510, 26), new PointF(510, 52) };
        using (var gold = B(255, 200, 40)) g.FillPolygon(gold, crown);
        g.DrawPolygon(Ol, crown);
        LogoText(g, "KING KONG", 480, 112, 100f, C(255, 240, 70), C(255, 130, 0), C(30, 10, 10), C(150, 40, 10), 0f);
        LogoText(g, "ALIVE", 600, 196, 74f, C(255, 70, 70), C(190, 0, 0), C(255, 255, 255), C(110, 0, 0), 0.25f);

        var r = new RectangleF(Cfg.W / 2f - 190, 584, 380, 56);
        using (var path = RoundRect(r, 12))
        {
            using (var br = B(10, 12, 40, 235)) g.FillPath(br, path);
            using (var pen = P(230, 50, 50, 3f)) g.DrawPath(pen, path);
        }
        if (((int)(t * 2) & 1) == 0) Text(g, "START GAME", FMid, Color.White, Cfg.W / 2f, 590, StringAlignment.Center);
        Text(g, "PRESS ANY KEY", FSmall, C(200, 220, 255), Cfg.W / 2f, 620, StringAlignment.Center, 1);
        Text(g, "LEFT/RIGHT or A/D: move    UP/DOWN or W/S: climb    SPACE: jump", FSmall, Color.White, Cfg.W / 2f, 656, StringAlignment.Center, 1);
        Text(g, "ESC: pause    R: restart    F11: fullscreen    M: mute", FSmall, Color.White, Cfg.W / 2f, 678, StringAlignment.Center, 1);
    }
}
