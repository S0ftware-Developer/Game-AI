using System.Drawing;

namespace KingKongAlive;

/// <summary>A girder / plank segment. Y grows downward; the walkable surface is the top edge.</summary>
public class Plat
{
    public int Id, Row, Style;                 // Style 0 = steel girder, 1 = wooden planks
    public float X1, Y1, X2, Y2;
    public float YAt(float x) => Y1 + (Y2 - Y1) * (x - X1) / (X2 - X1);
    public bool Has(float x) => x >= X1 && x <= X2;
    public int DownDir => Y2 > Y1 ? 1 : -1;    // direction a barrel rolls on this segment
}

public class Ladder { public float X; public int Lower, Upper; }
public class Bonus { public float X, Y, Phase; public bool Taken; }
public class Fire { public int PlatId; public float MinX, MaxX, X, Dir = 1f, Speed = 38f; }
public class Pop { public float X, Y, Life; public string Text = ""; public Color Col; }
public class Particle { public float X, Y, VX, VY, Life, Max, Size; public Color Col; public int Kind; } // 0 spark, 1 heart

public enum KongState { Idle, Grab, Throw }
public class Kong
{
    public KongState State;
    public float StateT, NextThrow = 2.0f;
    public bool Agitated;
}
