using System.Drawing;

namespace KingKongAlive;

/// <summary>"The Giant Construction Site": zigzag girders, ladders, hazards and collectibles.</summary>
public class Level
{
    public readonly List<Plat> Plats = new();
    public readonly List<Ladder> Ladders = new();
    public readonly List<Bonus> Bonuses = new();
    public readonly List<Fire> Fires = new();
    public PointF Start, GirlPos, KongPos;
    public float DrumX = 250f, KongSpawnX = 215f;
    public const int TopPlat = 7, KongPlat = 6;

    void P(int row, int style, float x1, float y1, float x2, float y2) =>
        Plats.Add(new Plat { Id = Plats.Count, Row = row, Style = style, X1 = x1, Y1 = y1, X2 = x2, Y2 = y2 });
    void L(float x, int lower, int upper) => Ladders.Add(new Ladder { X = x, Lower = lower, Upper = upper });
    void B(int plat, float x) => Bonuses.Add(new Bonus { X = x, Y = Plats[plat].YAt(x) - 20f, Phase = x * 0.01f });

    public Level()
    {
        //  id  row style  x1   y1     x2   y2        (barrels roll toward the lower end)
        P(0, 1, 30, 675, 930, 665);          // 0  ground walkway (rolls left)
        P(1, 0, 30, 575, 850, 585);          // 1  rolls right
        P(2, 0, 100, 485, 930, 475);         // 2  rolls left
        P(3, 0, 30, 375, 450, 382.9f);       // 3  left part, rolls right
        P(3, 0, 520, 384.2f, 830, 390);      // 4  right part (70 px gap = timed jump / barrel drop point)
        P(4, 0, 150, 285, 930, 275);         // 5  rolls left
        P(5, 0, 30, 175, 800, 190);          // 6  Kong's platform, rolls right
        P(6, 1, 330, 105, 600, 105);         // 7  rescue platform

        L(420, 0, 1); L(720, 0, 1);
        L(260, 1, 2); L(640, 1, 2);
        L(600, 2, 4);                        // must climb to the right part...
        L(250, 3, 5);                        // ...then jump the gap to reach the next ladder
        L(450, 5, 6); L(700, 5, 6);
        L(480, 6, 7);

        Start = new PointF(330, Plats[0].YAt(330));
        KongPos = new PointF(105, Plats[6].YAt(105));
        GirlPos = new PointF(540, Plats[7].YAt(540));

        B(0, 600); B(1, 790); B(2, 880); B(4, 800); B(5, 900); B(6, 720);

        Fires.Add(new Fire { PlatId = 2, MinX = 700, MaxX = 880, X = 780 });
        Fires.Add(new Fire { PlatId = 5, MinX = 300, MaxX = 420, X = 360, Dir = -1f });
    }
}
