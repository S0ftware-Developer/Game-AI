namespace KingKongAlive;

public enum BState { Roll, Fall, Ladder }

public class Barrel
{
    public float X, Y, VX, VY, Rot, Speed;     // X,Y = contact point with the surface (bottom of barrel)
    public int Dir, CurPlat;
    public BState State;
    public bool Scored, Dead;
    public Ladder? Lad;

    public void Update(float dt, Level lv, Random rng)
    {
        switch (State)
        {
            case BState.Roll:
            {
                float ox = X;
                X += Dir * Speed * dt;
                Rot += Dir * Speed * dt / Cfg.BarrelR;
                var p = lv.Plats[CurPlat];
                if (!p.Has(X))
                {   // rolled off the end of the girder -> fall to the next one
                    Y = p.YAt(Math.Clamp(X, p.X1, p.X2));
                    State = BState.Fall; VY = 0; VX = Dir * 50f;
                    break;
                }
                Y = p.YAt(X);
                foreach (var l in lv.Ladders)
                {   // sometimes a barrel takes a ladder down
                    if (l.Upper == CurPlat && ox != X && (ox - l.X) * (X - l.X) <= 0 && rng.NextDouble() < Cfg.BarrelLadderChance)
                    { State = BState.Ladder; Lad = l; X = l.X; break; }
                }
                if (State == BState.Roll && CurPlat == 0 && X < lv.DrumX) Dead = true;   // vanishes into the oil drum
                break;
            }
            case BState.Fall:
            {
                float oy = Y;
                VY += Cfg.Gravity * dt; Y += VY * dt; X += VX * dt; VX -= VX * 2f * dt;
                Rot += Dir * 3f * dt;
                foreach (var p in lv.Plats)
                {
                    if (!p.Has(X)) continue;
                    float s = p.YAt(X);
                    if (oy <= s + 1f && Y >= s) { Y = s; VY = 0; CurPlat = p.Id; Dir = p.DownDir; State = BState.Roll; break; }
                }
                if (Y > Cfg.H + 60) Dead = true;
                break;
            }
            case BState.Ladder:
            {
                Y += 120f * dt; Rot += 6f * dt;
                var low = lv.Plats[Lad!.Lower];
                float s = low.YAt(X);
                if (Y >= s) { Y = s; CurPlat = low.Id; Dir = low.DownDir; State = BState.Roll; }
                break;
            }
        }
    }
}
