namespace KingKongAlive;

/// <summary>All tunable values in one place (virtual resolution 960x720, pixels and seconds).</summary>
public static class Cfg
{
    public const int W = 960, H = 720;
    public const float Step = 1f / 120f;        // fixed simulation step

    // Player
    public const float Walk = 150f;             // horizontal speed (ground and air control)
    public const float Climb = 95f;             // ladder speed
    public const float Gravity = 1400f;
    public const float JumpVel = -480f;         // fixed jump: ~82 px high, ~0.69 s in the air
    public const float MinX = 14f, MaxX = 946f;
    public const float PlatThick = 14f;

    // Barrels
    public const float BarrelR = 12f;
    public const float BarrelBaseSpeed = 95f;
    public const float BarrelLadderChance = 0.18f;
    public const int MaxBarrels = 7;
}
