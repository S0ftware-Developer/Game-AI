using System.Media;

namespace KingKongAlive;

/// <summary>Procedurally generated sound effects (no asset files).</summary>
public static class Sfx
{
    public static bool Muted;
    public static readonly Snd Jump    = new((300, 620, 0.14, 1, 0.22));
    public static readonly Snd Climb   = new((220, 260, 0.05, 1, 0.14));
    public static readonly Snd Roll    = new((90, 60, 0.22, 2, 0.16));
    public static readonly Snd Hit     = new((200, 50, 0.45, 2, 0.30));
    public static readonly Snd Collect = new((1000, 1000, 0.05, 0, 0.25), (1500, 1500, 0.10, 0, 0.25));
    public static readonly Snd Score   = new((700, 950, 0.09, 0, 0.22));
    public static readonly Snd Lose    = new((420, 90, 0.70, 1, 0.28));
    public static readonly Snd Win     = new((523, 523, 0.14, 0, 0.3), (659, 659, 0.14, 0, 0.3), (784, 784, 0.14, 0, 0.3),
                                             (1047, 1047, 0.14, 0, 0.3), (1047, 1047, 0.35, 0, 0.3));
}

public sealed class Snd
{
    readonly SoundPlayer? sp;
    static readonly Random Noise = new(1);

    public Snd(params (double f0, double f1, double dur, int wave, double vol)[] segs)
    {
        try { sp = new SoundPlayer(new MemoryStream(Wav(segs))); sp.Load(); }
        catch { sp = null; }
    }

    public void Play()
    {
        if (Sfx.Muted || sp == null) return;
        try { sp.Play(); } catch { }
    }

    static byte[] Wav((double f0, double f1, double dur, int wave, double vol)[] segs)
    {
        const int sr = 22050;
        var data = new List<short>();
        double phase = 0;
        foreach (var s in segs)
        {
            int n = (int)(s.dur * sr);
            for (int i = 0; i < n; i++)
            {
                double u = (double)i / n;
                phase += 2 * Math.PI * (s.f0 + (s.f1 - s.f0) * u) / sr;
                double v = s.wave == 0 ? Math.Sin(phase) : s.wave == 1 ? (Math.Sin(phase) >= 0 ? 0.55 : -0.55) : Noise.NextDouble() * 2 - 1;
                double env = Math.Min(1.0, u * 20) * (1 - u);
                data.Add((short)(v * env * s.vol * 32767));
            }
        }
        var ms = new MemoryStream();
        var bw = new BinaryWriter(ms);
        int bytes = data.Count * 2;
        bw.Write(new[] { 'R', 'I', 'F', 'F' }); bw.Write(36 + bytes);
        bw.Write(new[] { 'W', 'A', 'V', 'E', 'f', 'm', 't', ' ' });
        bw.Write(16); bw.Write((short)1); bw.Write((short)1); bw.Write(sr); bw.Write(sr * 2); bw.Write((short)2); bw.Write((short)16);
        bw.Write(new[] { 'd', 'a', 't', 'a' }); bw.Write(bytes);
        foreach (var d in data) bw.Write(d);
        bw.Flush();
        return ms.ToArray();
    }
}
