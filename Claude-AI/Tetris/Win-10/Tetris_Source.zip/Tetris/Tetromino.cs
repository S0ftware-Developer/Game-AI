using System;
using System.Drawing;

namespace Tetris
{
    // Семь стандартных тетрамино
    public enum PieceType
    {
        I = 0,
        O = 1,
        T = 2,
        S = 3,
        Z = 4,
        J = 5,
        L = 6
    }

    // Формы, цвета и таблицы "wall kick" (система вращения SRS)
    public static class Tetromino
    {
        public const int TypeCount = 7;

        // Shapes[тип][поворот] = 4 клетки (x, y) внутри квадратной рамки фигуры
        private static readonly Point[][][] Shapes = BuildShapes();

        // Цвета как на референсе
        public static readonly Color[] Colors =
        {
            Color.FromArgb(40, 205, 255),   // I — голубой
            Color.FromArgb(255, 205, 30),   // O — жёлтый
            Color.FromArgb(172, 62, 232),   // T — фиолетовый
            Color.FromArgb(54, 205, 56),    // S — зелёный
            Color.FromArgb(232, 42, 34),    // Z — красный
            Color.FromArgb(44, 112, 238),   // J — синий
            Color.FromArgb(255, 142, 22)    // L — оранжевый
        };

        // Таблицы сдвигов для вращения по часовой стрелке (индекс = текущий поворот 0..3).
        // Формат стандарта SRS: положительный Y означает "вверх" (при использовании Y вычитается).
        private static readonly Point[][] KicksJLSTZ =
        {
            new[] { new Point(0, 0), new Point(-1, 0), new Point(-1, 1), new Point(0, -2), new Point(-1, -2) }, // 0 -> 1
            new[] { new Point(0, 0), new Point(1, 0), new Point(1, -1), new Point(0, 2), new Point(1, 2) },     // 1 -> 2
            new[] { new Point(0, 0), new Point(1, 0), new Point(1, 1), new Point(0, -2), new Point(1, -2) },    // 2 -> 3
            new[] { new Point(0, 0), new Point(-1, 0), new Point(-1, -1), new Point(0, 2), new Point(-1, 2) }   // 3 -> 0
        };

        private static readonly Point[][] KicksI =
        {
            new[] { new Point(0, 0), new Point(-2, 0), new Point(1, 0), new Point(-2, -1), new Point(1, 2) },   // 0 -> 1
            new[] { new Point(0, 0), new Point(-1, 0), new Point(2, 0), new Point(-1, 2), new Point(2, -1) },   // 1 -> 2
            new[] { new Point(0, 0), new Point(2, 0), new Point(-1, 0), new Point(2, 1), new Point(-1, -2) },   // 2 -> 3
            new[] { new Point(0, 0), new Point(1, 0), new Point(-2, 0), new Point(1, -2), new Point(-2, 1) }    // 3 -> 0
        };

        private static readonly Point[] KicksNone = { new Point(0, 0) };

        public static int BoxSize(PieceType type)
        {
            return (type == PieceType.I || type == PieceType.O) ? 4 : 3;
        }

        public static Point[] GetCells(PieceType type, int rotation)
        {
            return Shapes[(int)type][rotation & 3];
        }

        // Варианты сдвигов при вращении по часовой стрелке из состояния fromRotation
        public static Point[] GetKicks(PieceType type, int fromRotation)
        {
            int r = fromRotation & 3;
            if (type == PieceType.O) return KicksNone;
            if (type == PieceType.I) return KicksI[r];
            return KicksJLSTZ[r];
        }

        private static Point[][][] BuildShapes()
        {
            // Базовые (нулевые) повороты в стандартной ориентации SRS
            Point[][] bases =
            {
                new[] { new Point(0, 1), new Point(1, 1), new Point(2, 1), new Point(3, 1) }, // I
                new[] { new Point(1, 0), new Point(2, 0), new Point(1, 1), new Point(2, 1) }, // O
                new[] { new Point(1, 0), new Point(0, 1), new Point(1, 1), new Point(2, 1) }, // T
                new[] { new Point(1, 0), new Point(2, 0), new Point(0, 1), new Point(1, 1) }, // S
                new[] { new Point(0, 0), new Point(1, 0), new Point(1, 1), new Point(2, 1) }, // Z
                new[] { new Point(0, 0), new Point(0, 1), new Point(1, 1), new Point(2, 1) }, // J
                new[] { new Point(2, 0), new Point(0, 1), new Point(1, 1), new Point(2, 1) }  // L
            };

            var result = new Point[TypeCount][][];
            for (int t = 0; t < TypeCount; t++)
            {
                result[t] = new Point[4][];
                result[t][0] = bases[t];

                int size = (t == (int)PieceType.I) ? 4 : 3;
                for (int r = 1; r < 4; r++)
                {
                    if (t == (int)PieceType.O)
                    {
                        result[t][r] = bases[t]; // квадрат при вращении не меняется
                        continue;
                    }

                    // Поворот на 90° по часовой стрелке внутри рамки size x size: (x, y) -> (size-1-y, x)
                    Point[] prev = result[t][r - 1];
                    var next = new Point[4];
                    for (int i = 0; i < 4; i++)
                    {
                        next[i] = new Point(size - 1 - prev[i].Y, prev[i].X);
                    }
                    result[t][r] = next;
                }
            }
            return result;
        }
    }
}
