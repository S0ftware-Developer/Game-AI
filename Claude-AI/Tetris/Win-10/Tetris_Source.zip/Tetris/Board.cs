using System;
using System.Collections.Generic;
using System.Drawing;

namespace Tetris
{
    // Игровая сетка: 10 колонок, 20 видимых строк + 2 скрытые строки сверху для появления фигур.
    // Строка 0 — самая верхняя (скрытая), строка TotalHeight-1 — самая нижняя.
    public class Board
    {
        public const int Width = 10;
        public const int VisibleHeight = 20;
        public const int HiddenRows = 2;
        public const int TotalHeight = VisibleHeight + HiddenRows;

        // 0 — пусто, иначе (int)PieceType + 1
        private readonly int[,] cells = new int[TotalHeight, Width];

        public int Get(int x, int y)
        {
            return cells[y, x];
        }

        public void Clear()
        {
            Array.Clear(cells, 0, cells.Length);
        }

        // Свободна ли клетка (за пределами поля — не свободна)
        public bool IsFree(int x, int y)
        {
            if (x < 0 || x >= Width || y < 0 || y >= TotalHeight) return false;
            return cells[y, x] == 0;
        }

        // Пересекается ли фигура с занятыми клетками или границами поля
        public bool Collides(PieceType type, int rotation, int boxX, int boxY)
        {
            Point[] shape = Tetromino.GetCells(type, rotation);
            for (int i = 0; i < shape.Length; i++)
            {
                if (!IsFree(boxX + shape[i].X, boxY + shape[i].Y))
                {
                    return true;
                }
            }
            return false;
        }

        public void Place(PieceType type, int rotation, int boxX, int boxY)
        {
            Point[] shape = Tetromino.GetCells(type, rotation);
            for (int i = 0; i < shape.Length; i++)
            {
                int x = boxX + shape[i].X;
                int y = boxY + shape[i].Y;
                if (x >= 0 && x < Width && y >= 0 && y < TotalHeight)
                {
                    cells[y, x] = (int)type + 1;
                }
            }
        }

        public bool IsRowFull(int y)
        {
            for (int x = 0; x < Width; x++)
            {
                if (cells[y, x] == 0) return false;
            }
            return true;
        }

        // Номера полностью заполненных строк (сверху вниз)
        public List<int> FindFullRows()
        {
            var rows = new List<int>();
            for (int y = 0; y < TotalHeight; y++)
            {
                if (IsRowFull(y)) rows.Add(y);
            }
            return rows;
        }

        // Удаляет указанные строки и сдвигает всё, что выше, вниз
        public void RemoveRows(List<int> rows)
        {
            if (rows.Count == 0) return;

            var remove = new HashSet<int>(rows);
            int writeY = TotalHeight - 1;

            for (int readY = TotalHeight - 1; readY >= 0; readY--)
            {
                if (remove.Contains(readY)) continue;

                if (writeY != readY)
                {
                    for (int x = 0; x < Width; x++)
                    {
                        cells[writeY, x] = cells[readY, x];
                    }
                }
                writeY--;
            }

            // Верх поля заполняем пустотой
            for (int y = writeY; y >= 0; y--)
            {
                for (int x = 0; x < Width; x++)
                {
                    cells[y, x] = 0;
                }
            }
        }
    }
}
