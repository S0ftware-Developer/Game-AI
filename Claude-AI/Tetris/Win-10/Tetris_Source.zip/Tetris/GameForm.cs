using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace Tetris
{
    // Частица эффекта
    public class FxParticle
    {
        public float X, Y, VX, VY;
        public float Life, MaxLife;
        public float Size;
        public Color Color;
    }

    // Светящийся след при жёстком падении
    public class FxTrail
    {
        public float X, Y0, Y1, Width;
        public Color Color;
        public float Life, MaxLife;
    }

    // Вспышка клетки при приземлении
    public class FxFlash
    {
        public float X, Y, Size;
        public float Life, MaxLife;
    }

    // Фигура, медленно плывущая по полю на стартовом экране (превью стиля игры)
    public class DemoPiece
    {
        public PieceType Type;
        public int Rotation;
        public float X, Y, Speed;
    }

    // Главное окно игры
    public partial class GameForm : Form
    {
        // ==========================================================
        //  Логический размер холста (4:3, как на референсе); окно масштабируется под него
        // ==========================================================
        private const int DesignWidth = 1200;
        private const int DesignHeight = 900;

        // Поле: 10 x 20 клеток по 40 px
        private const int Cell = 40;
        private const float FieldX = 400f;
        private const float FieldY = 36f;
        private const float FieldW = Board.Width * Cell;           // 400
        private const float FieldH = Board.VisibleHeight * Cell;   // 800

        private static readonly RectangleF FieldFrame = new RectangleF(388f, 24f, 424f, 824f);

        // ==========================================================
        //  Игра и состояние интерфейса
        // ==========================================================
        private readonly TetrisGame game;
        private GameState lastState = GameState.Start;
        private double overlayTime;   // время с момента смены состояния (плавные переходы)
        private double globalTime;    // общее время (мигание, пульсации)

        private readonly HashSet<Keys> keysDown = new HashSet<Keys>();
        private readonly Random rng = new Random();

        private readonly Stopwatch stopwatch = new Stopwatch();
        private readonly System.Windows.Forms.Timer gameTimer;
        private long lastElapsedMs;

        // Эффекты
        private readonly List<FxParticle> particles = new List<FxParticle>();
        private readonly List<FxTrail> trails = new List<FxTrail>();
        private readonly List<FxFlash> flashes = new List<FxFlash>();
        private readonly List<DemoPiece> demoPieces = new List<DemoPiece>();
        private float levelBannerTimer;
        private float levelPulse;
        private float screenFlash;
        private Color screenFlashColor = Color.White;
        private int bannerLevel = 1;

        // Рекорд сохраняется между запусками в папке пользователя
        private static readonly string BestFilePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TetrisReborn", "best.txt");

        public GameForm()
        {
            this.Text = "Tetris";
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.MaximizeBox = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Black;
            this.KeyPreview = true;
            this.AutoScaleMode = AutoScaleMode.None;

            // Начальный размер 1200x900, но не больше доступной области экрана
            Rectangle workArea = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
            double fit = Math.Min(1.0, Math.Min((workArea.Width - 40) / (double)DesignWidth,
                                                (workArea.Height - 80) / (double)DesignHeight));
            fit = Math.Max(fit, 0.5);
            this.ClientSize = new Size((int)(DesignWidth * fit), (int)(DesignHeight * fit));
            this.MinimumSize = new Size(600, 480);

            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw,
                true);

            game = new TetrisGame(rng, LoadBest());

            InitFonts();
            InitBlockBitmaps();
            staticBitmap = BuildStaticBitmap();
            InitDemoPieces();
            InitSounds();

            this.KeyDown += GameForm_KeyDown;
            this.KeyUp += GameForm_KeyUp;
            this.Paint += GameForm_Paint;
            this.Deactivate += GameForm_Deactivate;

            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 10;   // реальная частота ~64 Гц; время считается по Stopwatch
            gameTimer.Tick += GameTimer_Tick;

            stopwatch.Start();
            lastElapsedMs = 0;
            gameTimer.Start();
        }

        // ==========================================================
        //  Клавиатура
        // ==========================================================
        private void GameForm_KeyDown(object? sender, KeyEventArgs e)
        {
            // Автоповтор клавиши не должен многократно срабатывать для разовых команд
            bool isRepeat = !keysDown.Add(e.KeyCode);
            if (!isRepeat)
            {
                HandleKeyPressed(e.KeyCode);
            }

            if (IsGameKey(e.KeyCode))
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        private void GameForm_KeyUp(object? sender, KeyEventArgs e)
        {
            keysDown.Remove(e.KeyCode);

            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.A:
                    if (!keysDown.Contains(Keys.Left) && !keysDown.Contains(Keys.A))
                    {
                        game.ReleaseDirection(-1);
                    }
                    break;

                case Keys.Right:
                case Keys.D:
                    if (!keysDown.Contains(Keys.Right) && !keysDown.Contains(Keys.D))
                    {
                        game.ReleaseDirection(1);
                    }
                    break;
            }
        }

        // Потеря фокуса: отпускаем клавиши и ставим игру на паузу
        private void GameForm_Deactivate(object? sender, EventArgs e)
        {
            keysDown.Clear();
            game.ReleaseAllInput();
            if (game.State == GameState.Playing)
            {
                game.TogglePause();
            }
        }

        private static bool IsGameKey(Keys key)
        {
            switch (key)
            {
                case Keys.Left:
                case Keys.Right:
                case Keys.Up:
                case Keys.Down:
                case Keys.A:
                case Keys.D:
                case Keys.W:
                case Keys.S:
                case Keys.C:
                case Keys.ShiftKey:
                case Keys.LShiftKey:
                case Keys.RShiftKey:
                case Keys.Space:
                case Keys.P:
                case Keys.R:
                case Keys.M:
                case Keys.Escape:
                    return true;
                default:
                    return false;
            }
        }

        private void HandleKeyPressed(Keys key)
        {
            switch (key)
            {
                case Keys.Left:
                case Keys.A:
                    game.PressDirection(-1);
                    break;

                case Keys.Right:
                case Keys.D:
                    game.PressDirection(1);
                    break;

                case Keys.Up:
                case Keys.W:
                    game.Rotate();
                    break;

                case Keys.Space:
                    if (game.State == GameState.Start)
                    {
                        StartNewGame();
                    }
                    else if (game.State == GameState.Playing)
                    {
                        game.HardDrop();
                    }
                    break;

                case Keys.C:
                case Keys.ShiftKey:
                case Keys.LShiftKey:
                case Keys.RShiftKey:
                    game.HoldCurrent();
                    break;

                case Keys.P:
                    if (game.State == GameState.Playing || game.State == GameState.Paused)
                    {
                        game.TogglePause();
                        Play(sndPause, 2, 120);
                    }
                    break;

                case Keys.R:
                    StartNewGame();
                    break;

                case Keys.M:
                    soundEnabled = !soundEnabled;
                    break;

                case Keys.Escape:
                    if (game.State == GameState.Start)
                    {
                        this.Close();
                    }
                    else
                    {
                        GoToStartScreen();
                    }
                    break;
            }
        }

        private void StartNewGame()
        {
            SaveBestIfNeeded();
            ClearEffects();
            game.NewGame();
            Play(sndStart, 3, 250);
        }

        private void GoToStartScreen()
        {
            SaveBestIfNeeded();
            ClearEffects();
            game.ResetToStart();
        }

        // ==========================================================
        //  Игровой цикл
        // ==========================================================
        private void GameTimer_Tick(object? sender, EventArgs e)
        {
            long now = stopwatch.ElapsedMilliseconds;
            double dt = (now - lastElapsedMs) / 1000.0;
            lastElapsedMs = now;
            if (dt > 0.05) dt = 0.05; // защита от скачка после сворачивания окна
            if (dt < 0.0) dt = 0.0;

            globalTime += dt;
            overlayTime += dt;

            if (game.State != lastState)
            {
                lastState = game.State;
                overlayTime = 0.0;
            }

            game.SoftDropHeld = keysDown.Contains(Keys.Down) || keysDown.Contains(Keys.S);
            game.Update(dt);
            ProcessGameEvents();

            if (game.State != GameState.Paused)
            {
                UpdateEffects((float)dt);
            }

            // Смена состояния могла произойти внутри Update (например, GameOver)
            if (game.State != lastState)
            {
                lastState = game.State;
                overlayTime = 0.0;
            }

            this.Invalidate();
        }

        // ==========================================================
        //  Рекорд
        // ==========================================================
        private static int LoadBest()
        {
            try
            {
                if (File.Exists(BestFilePath))
                {
                    string text = File.ReadAllText(BestFilePath).Trim();
                    if (int.TryParse(text, out int value) && value >= 0)
                    {
                        return value;
                    }
                }
            }
            catch (Exception)
            {
                // рекорд — необязательная функция
            }
            return 0;
        }

        private void SaveBest()
        {
            try
            {
                string? dir = Path.GetDirectoryName(BestFilePath);
                if (!string.IsNullOrEmpty(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                File.WriteAllText(BestFilePath, game.Best.ToString());
            }
            catch (Exception)
            {
                // не удалось сохранить — игра продолжает работать
            }
        }

        // ==========================================================
        //  Освобождение ресурсов
        // ==========================================================
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                SaveBestIfNeeded();
                gameTimer?.Stop();
                gameTimer?.Dispose();
                staticBitmap?.Dispose();
                DisposeBlockBitmaps();
                DisposeFonts();
                DisposeSounds();
            }
            base.Dispose(disposing);
        }
    }
}
