using System;
using System.Collections.Generic;
using System.Drawing;

namespace Tetris
{
    public enum GameState
    {
        Start,      // стартовый экран
        Playing,    // идёт игра
        Paused,     // пауза
        GameOver    // игра окончена
    }

    // Внутренняя фаза игры: фигура падает или идёт анимация удаления линий
    public enum Phase
    {
        Falling,
        Clearing
    }

    public enum EventKind
    {
        Move,
        Rotate,
        Land,
        HardDrop,
        Hold,
        LineClear,
        LevelUp,
        GameOver
    }

    // Клетка поля с типом фигуры (для эффектов)
    public class CellInfo
    {
        public int X;
        public int Y;       // координата строки в сетке (с учётом скрытых строк)
        public PieceType Type;
    }

    // Событие игры: интерфейс забирает их для звука и визуальных эффектов
    public class GameEvent
    {
        public EventKind Kind;
        public PieceType Piece;
        public int Rotation;
        public int X;
        public int Y;
        public int Y2;
        public int Count;
        public List<CellInfo>? Cells;
    }

    // Вся логика игры без привязки к WinForms
    public class TetrisGame
    {
        // ==========================================================
        //  Настройки игры
        // ==========================================================
        public const int NextCount = 5;                 // сколько следующих фигур показывается
        public const int LinesPerLevel = 10;

        public const double DasDelay = 0.17;            // задержка до автоповтора движения, с
        public const double ArrInterval = 0.05;         // интервал автоповтора, с
        public const double SoftDropInterval = 0.045;   // интервал шага при удержании "вниз", с
        public const double LockDelay = 0.5;            // время до фиксации фигуры, лежащей на опоре, с
        public const double SoftLockDelay = 0.12;       // то же при удержании "вниз"
        public const int MaxLockResets = 15;            // сколько раз движение может сбросить таймер фиксации
        public const double ClearAnimTime = 0.40;       // длительность анимации удаления линий, с

        private const int SpawnX = 3;
        private const int SpawnY = 1;

        // Очки за 0..4 линии, умножаются на уровень
        private static readonly int[] LineScores = { 0, 100, 300, 500, 800 };

        // Интервал падения (в секундах) для уровней 1, 2, 3 ...; дальше — минимальное значение
        private static readonly double[] GravityTable =
        {
            0.800, 0.700, 0.600, 0.500, 0.400, 0.320, 0.250,
            0.200, 0.160, 0.130, 0.100, 0.080, 0.065, 0.050
        };

        public static double GravityInterval(int level)
        {
            int index = Math.Min(Math.Max(level, 1), GravityTable.Length) - 1;
            return GravityTable[index];
        }

        // ==========================================================
        //  Состояние
        // ==========================================================
        private readonly Board board = new Board();
        private readonly Random rng;
        private readonly List<PieceType> queue = new List<PieceType>();
        private readonly List<GameEvent> events = new List<GameEvent>();

        private PieceType? current;
        private int curRot;
        private int curX;
        private int curY;

        private PieceType? hold;
        private bool holdUsed;

        private bool grounded;
        private double gravityTimer;
        private double lockTimer;
        private int lockResets;

        private Phase phase = Phase.Falling;
        private double clearTimer;
        private List<int> clearingRows = new List<int>();

        private bool leftHeld;
        private bool rightHeld;
        private int lastDir;
        private double dasTimer;

        private int bestAtStart;

        public Board Board => board;
        public GameState State { get; private set; } = GameState.Start;
        public Phase CurrentPhase => phase;
        public int Score { get; private set; }
        public int Best { get; set; }
        public int Level { get; private set; } = 1;
        public int Lines { get; private set; }
        public bool IsNewBest { get; private set; }
        public bool SoftDropHeld { get; set; }

        public PieceType? Current => current;
        public int CurrentRotation => curRot;
        public int CurrentX => curX;
        public int CurrentY => curY;
        public PieceType? HoldPiece => hold;
        public bool HoldUsed => holdUsed;

        public IReadOnlyList<int> ClearingRows => clearingRows;
        public double ClearProgress => phase == Phase.Clearing ? 1.0 - clearTimer / ClearAnimTime : 0.0;

        public TetrisGame(Random? random = null, int best = 0)
        {
            rng = random ?? new Random();
            Best = best;
            ResetToStart();
        }

        // ==========================================================
        //  Управление состоянием игры
        // ==========================================================
        private void ResetValues()
        {
            board.Clear();
            queue.Clear();
            events.Clear();

            current = null;
            hold = null;
            holdUsed = false;
            grounded = false;
            gravityTimer = 0;
            lockTimer = 0;
            lockResets = 0;
            phase = Phase.Falling;
            clearTimer = 0;
            clearingRows = new List<int>();

            leftHeld = false;
            rightHeld = false;
            lastDir = 0;
            dasTimer = DasDelay;
            SoftDropHeld = false;

            Score = 0;
            Level = 1;
            Lines = 0;
            IsNewBest = false;
            bestAtStart = Best;

            RefillQueue();
        }

        // Показать стартовый экран (счёт и уровень сброшены)
        public void ResetToStart()
        {
            ResetValues();
            State = GameState.Start;
        }

        // Начать новую игру (кнопка Space на стартовом экране или R)
        public void NewGame()
        {
            ResetValues();
            State = GameState.Playing;
            SpawnNext();
        }

        public void TogglePause()
        {
            if (State == GameState.Playing)
            {
                State = GameState.Paused;
            }
            else if (State == GameState.Paused)
            {
                State = GameState.Playing;
            }
        }

        public List<GameEvent> DrainEvents()
        {
            var copy = new List<GameEvent>(events);
            events.Clear();
            return copy;
        }

        // ==========================================================
        //  Очередь фигур (мешок "7-bag": каждая фигура встречается ровно раз в семёрке)
        // ==========================================================
        private void RefillQueue()
        {
            while (queue.Count < NextCount + 1)
            {
                var bag = new List<PieceType>();
                for (int i = 0; i < Tetromino.TypeCount; i++)
                {
                    bag.Add((PieceType)i);
                }
                for (int i = bag.Count - 1; i > 0; i--)
                {
                    int j = rng.Next(i + 1);
                    PieceType tmp = bag[i];
                    bag[i] = bag[j];
                    bag[j] = tmp;
                }
                queue.AddRange(bag);
            }
        }

        private PieceType DequeueNext()
        {
            RefillQueue();
            PieceType t = queue[0];
            queue.RemoveAt(0);
            RefillQueue();
            return t;
        }

        public PieceType PeekNext(int index)
        {
            RefillQueue();
            return queue[index];
        }

        // ==========================================================
        //  Появление фигур
        // ==========================================================
        private void SpawnNext()
        {
            SpawnPiece(DequeueNext());
        }

        private void SpawnPiece(PieceType type)
        {
            current = type;
            curRot = 0;
            curX = SpawnX;
            curY = SpawnY;
            grounded = false;
            gravityTimer = 0;
            lockTimer = 0;
            lockResets = 0;
            dasTimer = DasDelay;

            if (board.Collides(type, curRot, curX, curY))
            {
                // Новая фигура не помещается — игра окончена
                State = GameState.GameOver;
                events.Add(new GameEvent { Kind = EventKind.GameOver });
                return;
            }

            UpdateGrounded(false);
        }

        // ==========================================================
        //  Ввод игрока
        // ==========================================================
        private bool CanControl()
        {
            return State == GameState.Playing && phase == Phase.Falling && current.HasValue;
        }

        public void PressDirection(int dir)
        {
            if (dir < 0) leftHeld = true; else rightHeld = true;
            lastDir = dir;
            dasTimer = DasDelay;

            if (CanControl())
            {
                TryMove(dir, 0);
            }
        }

        public void ReleaseDirection(int dir)
        {
            if (dir < 0) leftHeld = false; else rightHeld = false;

            if (lastDir == dir)
            {
                lastDir = leftHeld ? -1 : (rightHeld ? 1 : 0);
                dasTimer = DasDelay;
            }
        }

        public void ReleaseAllInput()
        {
            leftHeld = false;
            rightHeld = false;
            lastDir = 0;
            SoftDropHeld = false;
        }

        // Вращение по часовой стрелке с простыми "wall kick" по таблицам SRS
        public bool Rotate()
        {
            if (!CanControl()) return false;

            PieceType type = current!.Value;
            if (type == PieceType.O) return false;

            int newRot = (curRot + 1) & 3;
            Point[] kicks = Tetromino.GetKicks(type, curRot);

            for (int i = 0; i < kicks.Length; i++)
            {
                int nx = curX + kicks[i].X;
                int ny = curY - kicks[i].Y;
                if (!board.Collides(type, newRot, nx, ny))
                {
                    curRot = newRot;
                    curX = nx;
                    curY = ny;
                    AfterPieceChanged(true);
                    events.Add(new GameEvent { Kind = EventKind.Rotate, Piece = type });
                    return true;
                }
            }
            return false;
        }

        public bool TryMove(int dx, int dy)
        {
            if (!CanControl()) return false;

            PieceType type = current!.Value;
            if (board.Collides(type, curRot, curX + dx, curY + dy))
            {
                return false;
            }

            curX += dx;
            curY += dy;
            AfterPieceChanged(dx != 0);

            if (dx != 0)
            {
                events.Add(new GameEvent { Kind = EventKind.Move, Piece = type });
            }
            return true;
        }

        // Мгновенное падение до самого низа с фиксацией
        public void HardDrop()
        {
            if (!CanControl()) return;

            PieceType type = current!.Value;
            int startY = curY;
            int y = curY;
            while (!board.Collides(type, curRot, curX, y + 1))
            {
                y++;
            }

            int distance = y - startY;
            curY = y;
            AddScore(distance * 2);

            events.Add(new GameEvent
            {
                Kind = EventKind.HardDrop,
                Piece = type,
                Rotation = curRot,
                X = curX,
                Y = startY,
                Y2 = y,
                Count = distance
            });

            LockPiece();
        }

        // Отложить фигуру (один раз на каждую падающую фигуру)
        public bool HoldCurrent()
        {
            if (!CanControl() || holdUsed) return false;

            PieceType type = current!.Value;

            if (hold == null)
            {
                hold = type;
                SpawnNext();
            }
            else
            {
                PieceType swapped = hold.Value;
                hold = type;
                SpawnPiece(swapped);
            }

            holdUsed = true;
            events.Add(new GameEvent { Kind = EventKind.Hold, Piece = type });
            return true;
        }

        // ==========================================================
        //  Игровой цикл
        // ==========================================================
        public void Update(double dt)
        {
            if (State != GameState.Playing) return;

            if (phase == Phase.Clearing)
            {
                clearTimer -= dt;
                if (clearTimer <= 0)
                {
                    FinishClearing();
                }
                return;
            }

            if (!current.HasValue) return;

            UpdateHorizontalRepeat(dt);

            double baseInterval = GravityInterval(Level);
            double interval = SoftDropHeld ? Math.Min(baseInterval, SoftDropInterval) : baseInterval;

            if (grounded)
            {
                // Фигура лежит на опоре: считаем время до фиксации
                if (SoftDropHeld)
                {
                    lockTimer = Math.Min(lockTimer, SoftLockDelay);
                }
                lockTimer -= dt;
                if (lockTimer <= 0)
                {
                    LockPiece();
                }
                return;
            }

            gravityTimer += dt;
            while (gravityTimer >= interval && !grounded && current.HasValue && State == GameState.Playing)
            {
                gravityTimer -= interval;

                PieceType type = current.Value;
                if (board.Collides(type, curRot, curX, curY + 1))
                {
                    UpdateGrounded(false);
                    break;
                }

                curY++;
                if (SoftDropHeld)
                {
                    AddScore(1); // очко за каждую клетку ускоренного падения
                }
                AfterPieceChanged(false);
            }
        }

        private void UpdateHorizontalRepeat(double dt)
        {
            if (lastDir == 0) return;

            dasTimer -= dt;
            while (dasTimer <= 0)
            {
                if (!TryMove(lastDir, 0))
                {
                    dasTimer = ArrInterval;
                    break;
                }
                dasTimer += ArrInterval;
            }
        }

        // Пересчёт "стоит ли фигура на опоре" после любого перемещения
        private void AfterPieceChanged(bool userAction)
        {
            UpdateGrounded(userAction);
        }

        private void UpdateGrounded(bool userAction)
        {
            if (!current.HasValue) return;

            bool nowGrounded = board.Collides(current.Value, curRot, curX, curY + 1);

            if (nowGrounded)
            {
                if (!grounded)
                {
                    grounded = true;
                    lockTimer = LockDelay;
                    lockResets = 0;
                    gravityTimer = 0;
                }
                else if (userAction && lockResets < MaxLockResets)
                {
                    lockTimer = LockDelay;
                    lockResets++;
                }
            }
            else
            {
                grounded = false;
            }
        }

        // ==========================================================
        //  Фиксация фигуры и удаление линий
        // ==========================================================
        private void LockPiece()
        {
            if (!current.HasValue) return;

            PieceType type = current.Value;
            Point[] shape = Tetromino.GetCells(type, curRot);

            board.Place(type, curRot, curX, curY);

            var landed = new List<CellInfo>();
            for (int i = 0; i < shape.Length; i++)
            {
                landed.Add(new CellInfo { X = curX + shape[i].X, Y = curY + shape[i].Y, Type = type });
            }
            events.Add(new GameEvent { Kind = EventKind.Land, Piece = type, Cells = landed });

            current = null;
            grounded = false;
            holdUsed = false;

            List<int> rows = board.FindFullRows();
            if (rows.Count > 0)
            {
                StartClearing(rows);
            }
            else
            {
                SpawnNext();
            }
        }

        private void StartClearing(List<int> rows)
        {
            int count = rows.Count;

            // Очки считаются по уровню на момент сбора линий
            AddScore(LineScores[Math.Min(count, 4)] * Level);

            var cleared = new List<CellInfo>();
            foreach (int y in rows)
            {
                for (int x = 0; x < Board.Width; x++)
                {
                    cleared.Add(new CellInfo { X = x, Y = y, Type = (PieceType)(board.Get(x, y) - 1) });
                }
            }

            Lines += count;
            events.Add(new GameEvent { Kind = EventKind.LineClear, Count = count, Cells = cleared });

            int newLevel = Lines / LinesPerLevel + 1;
            if (newLevel > Level)
            {
                Level = newLevel;
                events.Add(new GameEvent { Kind = EventKind.LevelUp, Count = Level });
            }

            phase = Phase.Clearing;
            clearTimer = ClearAnimTime;
            clearingRows = rows;
        }

        private void FinishClearing()
        {
            board.RemoveRows(clearingRows);
            clearingRows = new List<int>();
            phase = Phase.Falling;
            SpawnNext();
        }

        private void AddScore(int points)
        {
            if (points <= 0) return;

            Score += points;
            if (Score > Best)
            {
                Best = Score;
            }
            if (Score > bestAtStart)
            {
                IsNewBest = true;
            }
        }

        // ==========================================================
        //  Данные для отрисовки
        // ==========================================================
        // Клетки активной фигуры в координатах сетки
        public Point[] GetCurrentCells()
        {
            if (!current.HasValue) return Array.Empty<Point>();
            return GetCellsAt(current.Value, curRot, curX, curY);
        }

        public static Point[] GetCellsAt(PieceType type, int rotation, int boxX, int boxY)
        {
            Point[] shape = Tetromino.GetCells(type, rotation);
            var result = new Point[shape.Length];
            for (int i = 0; i < shape.Length; i++)
            {
                result[i] = new Point(boxX + shape[i].X, boxY + shape[i].Y);
            }
            return result;
        }

        // Строка, на которую приземлится фигура ("призрак")
        public int GhostY()
        {
            if (!current.HasValue) return curY;

            int y = curY;
            while (!board.Collides(current.Value, curRot, curX, y + 1))
            {
                y++;
            }
            return y;
        }
    }
}
