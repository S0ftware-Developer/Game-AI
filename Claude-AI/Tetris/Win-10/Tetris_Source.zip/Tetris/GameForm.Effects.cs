using System;
using System.Collections.Generic;
using System.Drawing;

namespace Tetris
{
    public partial class GameForm
    {
        // Пиксельные координаты клетки сетки (строки с учётом скрытых верхних рядов)
        private static float CellPx(int boardX)
        {
            return FieldX + boardX * Cell;
        }

        private static float CellPy(int boardY)
        {
            return FieldY + (boardY - Board.HiddenRows) * Cell;
        }

        // ==========================================================
        //  События игры -> звук и эффекты
        // ==========================================================
        private void ProcessGameEvents()
        {
            foreach (GameEvent ev in game.DrainEvents())
            {
                switch (ev.Kind)
                {
                    case EventKind.Move:
                        Play(sndMove, 1, 40);
                        break;

                    case EventKind.Rotate:
                        Play(sndRotate, 1, 50);
                        break;

                    case EventKind.Hold:
                        Play(sndHold, 1, 80);
                        break;

                    case EventKind.Land:
                        SpawnLandFlashes(ev);
                        Play(sndLand, 2, 80);
                        break;

                    case EventKind.HardDrop:
                        SpawnHardDropEffect(ev);
                        Play(sndHardDrop, 2, 90);
                        break;

                    case EventKind.LineClear:
                        SpawnLineClearParticles(ev);
                        bool tetris = ev.Count >= 4;
                        Play(tetris ? sndTetris : sndLine, 3, tetris ? 520 : 260);
                        screenFlash = tetris ? 0.45f : 0.22f;
                        screenFlashColor = tetris ? Color.FromArgb(255, 220, 90) : Color.FromArgb(160, 220, 255);
                        break;

                    case EventKind.LevelUp:
                        bannerLevel = ev.Count;
                        levelBannerTimer = 1.5f;
                        levelPulse = 1f;
                        Play(sndLevelUp, 3, 520);
                        break;

                    case EventKind.GameOver:
                        Play(sndGameOver, 3, 800);
                        SaveBestIfNeeded();
                        break;
                }
            }
        }

        private void SaveBestIfNeeded()
        {
            if (game.IsNewBest)
            {
                SaveBest();
            }
        }

        // Короткая белая вспышка на клетках приземлившейся фигуры
        private void SpawnLandFlashes(GameEvent ev)
        {
            if (ev.Cells == null) return;
            foreach (CellInfo c in ev.Cells)
            {
                if (c.Y < Board.HiddenRows) continue;
                flashes.Add(new FxFlash { X = CellPx(c.X), Y = CellPy(c.Y), Size = Cell, Life = 0.22f, MaxLife = 0.22f });
            }
        }

        // Светящийся след по колонкам фигуры + пыль в месте удара
        private void SpawnHardDropEffect(GameEvent ev)
        {
            Color color = Tetromino.Colors[(int)ev.Piece];
            System.Drawing.Point[] start = TetrisGame.GetCellsAt(ev.Piece, ev.Rotation, ev.X, ev.Y);
            System.Drawing.Point[] end = TetrisGame.GetCellsAt(ev.Piece, ev.Rotation, ev.X, ev.Y2);

            var topByColumn = new Dictionary<int, int>();
            var bottomByColumn = new Dictionary<int, int>();
            foreach (System.Drawing.Point p in start)
            {
                if (!topByColumn.TryGetValue(p.X, out int t) || p.Y < t) topByColumn[p.X] = p.Y;
            }
            foreach (System.Drawing.Point p in end)
            {
                if (!bottomByColumn.TryGetValue(p.X, out int b) || p.Y > b) bottomByColumn[p.X] = p.Y;
            }

            foreach (KeyValuePair<int, int> kv in topByColumn)
            {
                int col = kv.Key;
                if (!bottomByColumn.ContainsKey(col)) continue;

                float y0 = CellPy(kv.Value);
                float y1 = CellPy(bottomByColumn[col]) + Cell;
                if (y1 - y0 < Cell * 1.5f) continue; // слишком короткое падение — след не нужен

                trails.Add(new FxTrail { X = CellPx(col), Y0 = y0, Y1 = y1, Width = Cell, Color = color, Life = 0.30f, MaxLife = 0.30f });

                // Пыль внизу колонки
                float cx = CellPx(col) + Cell / 2f;
                float cy = CellPy(bottomByColumn[col]) + Cell;
                for (int i = 0; i < 4; i++)
                {
                    float vx = ((float)rng.NextDouble() - 0.5f) * 260f;
                    float vy = -40f - (float)rng.NextDouble() * 120f;
                    particles.Add(new FxParticle
                    {
                        X = cx, Y = cy, VX = vx, VY = vy,
                        Life = 0.35f, MaxLife = 0.35f, Size = 3f + rng.Next(0, 3),
                        Color = Color.FromArgb(220, 235, 255)
                    });
                }
            }
        }

        // Частицы цветов разрушенных блоков
        private void SpawnLineClearParticles(GameEvent ev)
        {
            if (ev.Cells == null) return;

            foreach (CellInfo c in ev.Cells)
            {
                if (c.Y < Board.HiddenRows) continue;

                float cx = CellPx(c.X) + Cell / 2f;
                float cy = CellPy(c.Y) + Cell / 2f;
                Color color = Tetromino.Colors[(int)c.Type];

                for (int i = 0; i < 3; i++)
                {
                    double angle = rng.NextDouble() * Math.PI * 2.0;
                    float speed = 80f + (float)rng.NextDouble() * 360f;
                    float life = 0.5f + (float)rng.NextDouble() * 0.55f;
                    particles.Add(new FxParticle
                    {
                        X = cx, Y = cy,
                        VX = (float)Math.Cos(angle) * speed,
                        VY = (float)Math.Sin(angle) * speed - 120f,
                        Life = life, MaxLife = life,
                        Size = 4f + rng.Next(0, 5),
                        Color = color
                    });
                }
            }
        }

        // ==========================================================
        //  Обновление эффектов
        // ==========================================================
        private void UpdateEffects(float dt)
        {
            for (int i = particles.Count - 1; i >= 0; i--)
            {
                FxParticle p = particles[i];
                p.X += p.VX * dt;
                p.Y += p.VY * dt;
                p.VY += 820f * dt;
                p.VX *= 0.985f;
                p.Life -= dt;
                if (p.Life <= 0f) particles.RemoveAt(i);
            }

            for (int i = trails.Count - 1; i >= 0; i--)
            {
                trails[i].Life -= dt;
                if (trails[i].Life <= 0f) trails.RemoveAt(i);
            }

            for (int i = flashes.Count - 1; i >= 0; i--)
            {
                flashes[i].Life -= dt;
                if (flashes[i].Life <= 0f) flashes.RemoveAt(i);
            }

            levelBannerTimer = Math.Max(0f, levelBannerTimer - dt);
            levelPulse = Math.Max(0f, levelPulse - dt * 1.2f);
            screenFlash = Math.Max(0f, screenFlash - dt * 1.6f);

            if (game.State == GameState.Start)
            {
                foreach (DemoPiece d in demoPieces)
                {
                    d.Y += d.Speed * dt;
                    if (d.Y > FieldY + FieldH + 20f)
                    {
                        ResetDemoPiece(d, false);
                    }
                }
            }
        }

        private void ClearEffects()
        {
            particles.Clear();
            trails.Clear();
            flashes.Clear();
            levelBannerTimer = 0f;
            levelPulse = 0f;
            screenFlash = 0f;
        }

        // ==========================================================
        //  Фигуры-"декорации" на стартовом экране
        // ==========================================================
        private void InitDemoPieces()
        {
            for (int i = 0; i < 8; i++)
            {
                var d = new DemoPiece();
                ResetDemoPiece(d, true);
                demoPieces.Add(d);
            }
        }

        private void ResetDemoPiece(DemoPiece d, bool anywhere)
        {
            d.Type = (PieceType)rng.Next(Tetromino.TypeCount);
            d.Rotation = rng.Next(4);
            d.X = FieldX + rng.Next(0, Board.Width - 2) * Cell;
            d.Y = anywhere
                ? FieldY - 80f + (float)rng.NextDouble() * (FieldH + 60f)
                : FieldY - 4f * Cell - (float)rng.NextDouble() * 200f;
            d.Speed = 45f + (float)rng.NextDouble() * 75f;
        }
    }
}
