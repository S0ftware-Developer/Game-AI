using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace Tetris
{
    public partial class GameForm
    {
        // ==========================================================
        //  Главный обработчик отрисовки (масштабирование с сохранением пропорций 4:3)
        // ==========================================================
        private void GameForm_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.Black);

            float scale = Math.Min(
                this.ClientSize.Width / (float)DesignWidth,
                this.ClientSize.Height / (float)DesignHeight);
            if (scale <= 0f) return;

            float offX = (this.ClientSize.Width - DesignWidth * scale) / 2f;
            float offY = (this.ClientSize.Height - DesignHeight * scale) / 2f;
            g.TranslateTransform(offX, offY);
            g.ScaleTransform(scale, scale);

            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

            if (staticBitmap != null)
            {
                g.DrawImage(staticBitmap, 0, 0, DesignWidth, DesignHeight);
            }

            DrawHudValues(g);
            DrawHoldAndNext(g);
            DrawHintPanel(g);
            DrawFieldContents(g);
            DrawEffects(g);
            DrawLevelBanner(g);
            DrawStateOverlay(g);
            DrawScreenFlash(g);
        }

        // ==========================================================
        //  Значения в панелях HUD
        // ==========================================================
        private void DrawHudValues(Graphics g)
        {
            float cx = ScoreRect.X + ScoreRect.Width / 2f;

            // SCORE (7 цифр) и BEST
            DrawGlowText(g, game.Score.ToString("0000000"), 50f, cx, ScoreRect.Y + 70f, CyanValue, CyanValue, 1f);
            DrawLeftText(g, "BEST", fontSmall, Color.FromArgb(170, 200, 235), ScoreRect.X + 26f, ScoreRect.Y + 110f);
            DrawRightText(g, game.Best.ToString("0000000"), fontSmall, Color.FromArgb(255, 214, 90), ScoreRect.Right - 26f, ScoreRect.Y + 110f);

            // LINES
            DrawGlowText(g, game.Lines.ToString(), 46f, cx + 20f, LinesRect.Y + 56f, GreenValue, GreenValue, 1f);

            // LEVEL (пульсирует при повышении уровня)
            float levelSize = 46f * (1f + 0.35f * Smooth(levelPulse));
            DrawGlowText(g, game.Level.ToString(), levelSize, cx + 20f, LevelRect.Y + 56f, YellowValue, YellowValue, 1f);
        }

        // ==========================================================
        //  HOLD и NEXT
        // ==========================================================
        private void DrawHoldAndNext(Graphics g)
        {
            if (game.HoldPiece.HasValue)
            {
                DrawPreviewPiece(g, game.HoldPiece.Value,
                    HoldWell.X + HoldWell.Width / 2f, HoldWell.Y + HoldWell.Height / 2f,
                    game.HoldUsed ? 0.38f : 1f);
            }

            for (int i = 0; i < TetrisGame.NextCount; i++)
            {
                DrawPreviewPiece(g, game.PeekNext(i),
                    NextWell.X + NextWell.Width / 2f, NextWell.Y + 44f + i * 88f, 1f);
            }
        }

        // Фигура маленькими блоками, отцентрированная по точке (cx, cy)
        private void DrawPreviewPiece(Graphics g, PieceType type, float cx, float cy, float alpha)
        {
            const int size = 28;
            System.Drawing.Point[] cells = Tetromino.GetCells(type, 0);

            int minX = int.MaxValue, maxX = int.MinValue, minY = int.MaxValue, maxY = int.MinValue;
            foreach (System.Drawing.Point p in cells)
            {
                minX = Math.Min(minX, p.X); maxX = Math.Max(maxX, p.X);
                minY = Math.Min(minY, p.Y); maxY = Math.Max(maxY, p.Y);
            }

            float width = (maxX - minX + 1) * size;
            float height = (maxY - minY + 1) * size;
            float ox = cx - width / 2f - minX * size;
            float oy = cy - height / 2f - minY * size;

            DrawCells(g, blockSmall[(int)type], cells, ox, oy, size, alpha);
        }

        private void DrawCells(Graphics g, Bitmap block, System.Drawing.Point[] cells, float ox, float oy, int size, float alpha)
        {
            if (alpha >= 0.99f)
            {
                foreach (System.Drawing.Point p in cells)
                {
                    g.DrawImage(block, ox + p.X * size, oy + p.Y * size, size, size);
                }
                return;
            }

            using (var attr = new ImageAttributes())
            {
                attr.SetColorMatrix(new ColorMatrix { Matrix33 = alpha });
                foreach (System.Drawing.Point p in cells)
                {
                    var dest = new Rectangle((int)(ox + p.X * size), (int)(oy + p.Y * size), size, size);
                    g.DrawImage(block, dest, 0, 0, block.Width, block.Height, GraphicsUnit.Pixel, attr);
                }
            }
        }

        // ==========================================================
        //  Панель подсказки справа внизу
        // ==========================================================
        private void DrawHintPanel(Graphics g)
        {
            string line1, line2;
            switch (game.State)
            {
                case GameState.Start:
                    line1 = "PRESS SPACE"; line2 = "TO START";
                    break;
                case GameState.Paused:
                    line1 = "PRESS P"; line2 = "TO RESUME";
                    break;
                case GameState.GameOver:
                    line1 = "PRESS R"; line2 = "TO RESTART";
                    break;
                default:
                    line1 = "PRESS P"; line2 = "TO PAUSE";
                    break;
            }

            float cx = HintRect.X + HintRect.Width / 2f;
            Color fill = Color.FromArgb(120, 235, 255);
            Color outline = Color.FromArgb(4, 20, 60);
            DrawOutlinedText(g, line1, 26f, cx, HintRect.Y + 44f, fill, outline, 5f);
            DrawOutlinedText(g, line2, 26f, cx, HintRect.Y + 80f, fill, outline, 5f);
            DrawCenteredText(g, soundEnabled ? "SOUND: ON  (M)" : "SOUND: OFF  (M)", fontSmall,
                Color.FromArgb(170, 200, 235), cx, HintRect.Y + 112f);
        }

        // ==========================================================
        //  Содержимое игрового поля
        // ==========================================================
        private void DrawFieldContents(Graphics g)
        {
            g.SetClip(new RectangleF(FieldX, FieldY, FieldW, FieldH));

            if (game.State == GameState.Start)
            {
                DrawDemoPieces(g);
            }
            else
            {
                DrawLockedBlocks(g);
                DrawActivePiece(g);
            }

            g.ResetClip();
        }

        private void DrawDemoPieces(Graphics g)
        {
            foreach (DemoPiece d in demoPieces)
            {
                DrawCells(g, blockBig[(int)d.Type], Tetromino.GetCells(d.Type, d.Rotation), d.X, d.Y, Cell, 0.42f);
            }
        }

        private void DrawLockedBlocks(Graphics g)
        {
            IReadOnlyList<int> clearing = game.ClearingRows;
            float progress = (float)game.ClearProgress;

            for (int y = Board.HiddenRows; y < Board.TotalHeight; y++)
            {
                bool isClearing = false;
                for (int i = 0; i < clearing.Count; i++)
                {
                    if (clearing[i] == y) { isClearing = true; break; }
                }

                for (int x = 0; x < Board.Width; x++)
                {
                    int value = game.Board.Get(x, y);
                    if (value == 0) continue;

                    Bitmap block = blockBig[value - 1];
                    float px = CellPx(x);
                    float py = CellPy(y);

                    if (!isClearing)
                    {
                        g.DrawImage(block, px, py, Cell, Cell);
                        continue;
                    }

                    // Анимация удаления: клетка сжимается к центру и вспыхивает белым
                    float scale = 1f - Smooth(progress);
                    float size = Cell * scale;
                    if (size < 1f) continue;

                    float ox = px + (Cell - size) / 2f;
                    float oy = py + (Cell - size) / 2f;
                    g.DrawImage(block, ox, oy, size, size);

                    int flash = (int)(210 * (1f - progress));
                    using (Brush white = new SolidBrush(Color.FromArgb(Math.Clamp(flash, 0, 255), 255, 255, 255)))
                    {
                        g.FillRectangle(white, ox, oy, size, size);
                    }
                }
            }
        }

        private void DrawActivePiece(Graphics g)
        {
            if (!game.Current.HasValue) return;

            PieceType type = game.Current.Value;
            Color color = Tetromino.Colors[(int)type];
            System.Drawing.Point[] cells = game.GetCurrentCells();

            int minCol = int.MaxValue, maxCol = int.MinValue, minRow = int.MaxValue;
            foreach (System.Drawing.Point p in cells)
            {
                minCol = Math.Min(minCol, p.X);
                maxCol = Math.Max(maxCol, p.X);
                minRow = Math.Min(minRow, p.Y);
            }

            // Подсветка колонок над фигурой (как на референсе)
            float guideTop = FieldY;
            float guideBottom = CellPy(minRow);
            if (guideBottom - guideTop > 2f)
            {
                var guide = new RectangleF(CellPx(minCol), guideTop, (maxCol - minCol + 1) * Cell, guideBottom - guideTop);
                using (var brush = new LinearGradientBrush(guide, Color.FromArgb(0, 70, 190, 255), Color.FromArgb(36, 70, 190, 255), LinearGradientMode.Vertical))
                {
                    g.FillRectangle(brush, guide);
                }
            }

            // Призрак — место приземления
            int ghostY = game.GhostY();
            if (ghostY != game.CurrentY)
            {
                foreach (System.Drawing.Point p in TetrisGame.GetCellsAt(type, game.CurrentRotation, game.CurrentX, ghostY))
                {
                    if (p.Y < Board.HiddenRows) continue;
                    var r = new RectangleF(CellPx(p.X) + 2f, CellPy(p.Y) + 2f, Cell - 4f, Cell - 4f);
                    using (Brush fill = new SolidBrush(Color.FromArgb(48, color)))
                    using (var pen = new Pen(Color.FromArgb(190, color), 2f))
                    {
                        g.FillRectangle(fill, r);
                        g.DrawRectangle(pen, r.X, r.Y, r.Width, r.Height);
                    }
                }
            }

            // Мягкое свечение вокруг активной фигуры
            float pulse = 0.75f + 0.25f * MathF.Sin((float)globalTime * 5f);
            foreach (System.Drawing.Point p in cells)
            {
                if (p.Y < Board.HiddenRows) continue;
                var r = new RectangleF(CellPx(p.X), CellPy(p.Y), Cell, Cell);
                using (Brush outer = new SolidBrush(Color.FromArgb((int)(20 * pulse), color)))
                using (Brush inner = new SolidBrush(Color.FromArgb((int)(34 * pulse), color)))
                {
                    g.FillRectangle(outer, RectangleF.Inflate(r, 9f, 9f));
                    g.FillRectangle(inner, RectangleF.Inflate(r, 4f, 4f));
                }
            }

            // Сама фигура
            Bitmap block = blockBig[(int)type];
            foreach (System.Drawing.Point p in cells)
            {
                if (p.Y < Board.HiddenRows) continue;
                g.DrawImage(block, CellPx(p.X), CellPy(p.Y), Cell, Cell);
            }
        }

        // ==========================================================
        //  Эффекты: следы жёсткого падения, вспышки приземления, частицы
        // ==========================================================
        private void DrawEffects(Graphics g)
        {
            g.SetClip(new RectangleF(FieldFrame.X + 4f, FieldFrame.Y + 4f, FieldFrame.Width - 8f, FieldFrame.Height - 8f));

            foreach (FxTrail t in trails)
            {
                float life = Math.Clamp(t.Life / t.MaxLife, 0f, 1f);
                float height = t.Y1 - t.Y0;
                if (height < 2f) continue;

                var rect = new RectangleF(t.X, t.Y0, t.Width, height);
                using (var brush = new LinearGradientBrush(rect,
                           Color.FromArgb(0, t.Color), Color.FromArgb((int)(150 * life), t.Color), LinearGradientMode.Vertical))
                {
                    g.FillRectangle(brush, rect);
                }
            }

            foreach (FxFlash f in flashes)
            {
                float life = Math.Clamp(f.Life / f.MaxLife, 0f, 1f);
                using (Brush brush = new SolidBrush(Color.FromArgb((int)(190 * life), 255, 255, 255)))
                {
                    g.FillRectangle(brush, f.X, f.Y, f.Size, f.Size);
                }
            }

            foreach (FxParticle p in particles)
            {
                float life = Math.Clamp(p.Life / p.MaxLife, 0f, 1f);
                float size = p.Size * (0.4f + 0.6f * life);
                using (Brush brush = new SolidBrush(Color.FromArgb((int)(255 * life), p.Color)))
                {
                    g.FillRectangle(brush, p.X - size / 2f, p.Y - size / 2f, size, size);
                }
            }

            g.ResetClip();
        }

        private void DrawScreenFlash(Graphics g)
        {
            if (screenFlash <= 0f) return;

            using (Brush brush = new SolidBrush(Color.FromArgb((int)(Math.Clamp(110 * screenFlash, 0f, 255f)), screenFlashColor)))
            {
                g.FillRectangle(brush, FieldX, FieldY, FieldW, FieldH);
            }
        }

        // Баннер LEVEL UP! при повышении уровня
        private void DrawLevelBanner(Graphics g)
        {
            if (levelBannerTimer <= 0f) return;

            float t = 1.5f - levelBannerTimer;
            float a = Smooth(t / 0.2f) * Smooth(levelBannerTimer / 0.45f);
            float pop = 1f + 0.25f * (1f - Smooth(t / 0.3f));

            float cx = FieldX + FieldW / 2f;
            float cy = FieldY + FieldH * 0.40f;

            using (Brush band = new SolidBrush(Color.FromArgb((int)(120 * a), 0, 4, 24)))
            {
                g.FillRectangle(band, FieldX, cy - 70f, FieldW, 150f);
            }

            DrawTitleText(g, "LEVEL UP!", cx, cy - 8f, 330f * pop, 70f * pop,
                Color.FromArgb(255, 240, 90), Color.FromArgb(255, 130, 20), Color.FromArgb(120, 40, 0), true, a);
            DrawOutlinedText(g, "LEVEL " + bannerLevel, 34f, cx, cy + 50f,
                Ac(Color.White, a), Ac(Color.FromArgb(8, 24, 70), a), 6f);
        }

        // ==========================================================
        //  Экраны состояний (плавное появление)
        // ==========================================================
        private void DrawDim(Graphics g, float alpha, Color tint)
        {
            using (Brush brush = new SolidBrush(Color.FromArgb((int)(Math.Clamp(185 * alpha, 0f, 255f)), tint)))
            {
                g.FillRectangle(brush, FieldX, FieldY, FieldW, FieldH);
            }
        }

        private float BlinkFactor()
        {
            return 0.62f + 0.38f * MathF.Sin((float)globalTime * 5f);
        }

        private void DrawStateOverlay(Graphics g)
        {
            float a = Smooth((float)(overlayTime / 0.35));
            float blink = BlinkFactor();
            float cx = FieldX + FieldW / 2f;
            Color dark = Color.FromArgb(8, 24, 70);
            Color tint = Color.FromArgb(3, 6, 26);

            switch (game.State)
            {
                case GameState.Start:
                    DrawDim(g, a * 0.6f, tint);
                    DrawTitleText(g, "TETRIS", cx, 230f, 340f, 110f,
                        Color.FromArgb(255, 232, 60), Color.FromArgb(255, 100, 20), Color.FromArgb(150, 25, 40), true, a);
                    DrawOutlinedText(g, "PRESS SPACE TO START", 28f, cx, 330f,
                        Ac(Color.White, a * blink), Ac(dark, a * blink), 6f);

                    DrawCenteredText(g, "SCORE " + game.Score.ToString("0000000") + "    LEVEL " + game.Level,
                        fontSmall, Ac(LabelColor, a), cx, 392f);
                    DrawCenteredText(g, "BEST " + game.Best.ToString("0000000"),
                        fontSmall, Ac(Color.FromArgb(255, 214, 90), a), cx, 418f);

                    string[] help =
                    {
                        "A / D or ARROWS  - MOVE",
                        "W / UP - ROTATE   S / DOWN - SOFT DROP",
                        "SPACE - HARD DROP   C / SHIFT - HOLD",
                        "P - PAUSE   R - RESTART   M - SOUND"
                    };
                    for (int i = 0; i < help.Length; i++)
                    {
                        DrawCenteredText(g, help[i], fontSmall, Ac(Color.FromArgb(190, 215, 245), a), cx, 480f + i * 26f);
                    }
                    break;

                case GameState.Paused:
                    DrawDim(g, a * 0.7f, tint);
                    DrawTitleText(g, "PAUSED", cx, 330f, 320f, 90f,
                        Color.FromArgb(245, 250, 255), Color.FromArgb(150, 200, 255), Color.FromArgb(20, 60, 140), true, a);
                    DrawOutlinedText(g, "PRESS P TO RESUME", 26f, cx, 410f,
                        Ac(Color.White, a * blink), Ac(dark, a * blink), 6f);
                    break;

                case GameState.GameOver:
                    DrawDim(g, a * 0.75f, Color.FromArgb(40, 0, 8));
                    DrawTitleText(g, "GAME OVER", cx, 250f, 340f, 90f,
                        Color.FromArgb(255, 120, 110), Color.FromArgb(200, 20, 40), Color.FromArgb(80, 0, 10), true, a);
                    DrawOutlinedText(g, "SCORE " + game.Score.ToString("0000000"), 32f, cx, 332f,
                        Ac(Color.White, a), Ac(dark, a), 6f);

                    if (game.IsNewBest)
                    {
                        DrawOutlinedText(g, "NEW BEST!", 30f, cx, 380f,
                            Ac(Color.FromArgb(255, 220, 70), a * blink), Ac(Color.FromArgb(90, 50, 0), a * blink), 6f);
                    }
                    else
                    {
                        DrawOutlinedText(g, "BEST " + game.Best.ToString("0000000"), 24f, cx, 380f,
                            Ac(Color.FromArgb(255, 214, 90), a), Ac(dark, a), 5f);
                    }

                    DrawOutlinedText(g, "LINES " + game.Lines + "   LEVEL " + game.Level, 24f, cx, 428f,
                        Ac(LabelColor, a), Ac(dark, a), 5f);
                    DrawOutlinedText(g, "PRESS R TO RESTART", 28f, cx, 500f,
                        Ac(Color.White, a * blink), Ac(dark, a * blink), 6f);
                    DrawCenteredText(g, "ESC - MENU", fontSmall, Ac(Color.FromArgb(190, 215, 245), a), cx, 546f);
                    break;
            }
        }
    }
}
