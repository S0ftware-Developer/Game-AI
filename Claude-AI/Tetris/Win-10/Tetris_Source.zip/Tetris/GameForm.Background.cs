using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace Tetris
{
    public partial class GameForm
    {
        // ==========================================================
        //  Палитра и раскладка панелей (логические координаты)
        // ==========================================================
        private static readonly Color NeonBlue = Color.FromArgb(40, 150, 255);
        private static readonly Color LabelColor = Color.FromArgb(225, 240, 255);
        private static readonly Color CyanValue = Color.FromArgb(40, 232, 255);
        private static readonly Color GreenValue = Color.FromArgb(60, 232, 50);
        private static readonly Color YellowValue = Color.FromArgb(255, 214, 40);

        private static readonly RectangleF LogoRect = new RectangleF(40f, 24f, 300f, 110f);
        private static readonly RectangleF ScoreRect = new RectangleF(40f, 150f, 300f, 134f);
        private static readonly RectangleF LinesRect = new RectangleF(40f, 298f, 300f, 92f);
        private static readonly RectangleF LevelRect = new RectangleF(40f, 404f, 300f, 92f);
        private static readonly RectangleF ControlsRect = new RectangleF(40f, 510f, 300f, 338f);
        private static readonly RectangleF HoldRect = new RectangleF(860f, 24f, 300f, 160f);
        private static readonly RectangleF NextRect = new RectangleF(860f, 198f, 300f, 500f);
        private static readonly RectangleF HintRect = new RectangleF(860f, 712f, 300f, 136f);

        private static readonly RectangleF HoldWell = new RectangleF(880f, 70f, 260f, 100f);
        private static readonly RectangleF NextWell = new RectangleF(878f, 246f, 264f, 440f);

        // ==========================================================
        //  Шрифты
        // ==========================================================
        private FontFamily titleFamily = null!;
        private FontFamily monoFamily = null!;
        private Font fontLabel = null!;
        private Font fontSmall = null!;
        private Font fontFooter = null!;

        private Bitmap? staticBitmap;
        private readonly Bitmap[] blockBig = new Bitmap[Tetromino.TypeCount];    // 40 px — поле
        private readonly Bitmap[] blockSmall = new Bitmap[Tetromino.TypeCount];  // 28 px — NEXT и HOLD

        private void InitFonts()
        {
            titleFamily = PickFamily("Arial Black", "Impact", "Segoe UI Black", "Consolas");
            monoFamily = PickFamily("Consolas", "Courier New", "Lucida Console");

            fontLabel = new Font(monoFamily, 22f, SafeStyle(monoFamily), GraphicsUnit.Pixel);
            fontSmall = new Font(monoFamily, 16f, SafeStyle(monoFamily), GraphicsUnit.Pixel);
            fontFooter = new Font(monoFamily, 16f, SafeStyle(monoFamily), GraphicsUnit.Pixel);
        }

        private void DisposeFonts()
        {
            fontLabel?.Dispose();
            fontSmall?.Dispose();
            fontFooter?.Dispose();
            titleFamily?.Dispose();
            monoFamily?.Dispose();
        }

        private static FontFamily PickFamily(params string[] names)
        {
            FontFamily[] installed = FontFamily.Families;
            foreach (string name in names)
            {
                foreach (FontFamily family in installed)
                {
                    if (string.Equals(family.Name, name, StringComparison.OrdinalIgnoreCase))
                    {
                        return new FontFamily(name);
                    }
                }
            }
            return FontFamily.GenericMonospace;
        }

        // Некоторые гарнитуры (например, Arial Black) не имеют отдельного Bold — выбираем доступный стиль
        private static FontStyle SafeStyle(FontFamily family)
        {
            FontStyle[] candidates = { FontStyle.Bold, FontStyle.Regular, FontStyle.Italic, FontStyle.Bold | FontStyle.Italic };
            foreach (FontStyle style in candidates)
            {
                if (family.IsStyleAvailable(style)) return style;
            }
            return FontStyle.Regular;
        }

        // ==========================================================
        //  Вспомогательные функции рисования
        // ==========================================================
        private static Color Ac(Color c, float alpha)
        {
            return Color.FromArgb(Math.Clamp((int)(c.A * alpha), 0, 255), c);
        }

        private static float Smooth(float t)
        {
            t = Math.Clamp(t, 0f, 1f);
            return t * t * (3f - 2f * t);
        }

        // Смешивание двух цветов (t = 0 — первый, t = 1 — второй)
        private static Color Mix(Color a, Color b, float t)
        {
            return Color.FromArgb(255,
                (int)(a.R + (b.R - a.R) * t),
                (int)(a.G + (b.G - a.G) * t),
                (int)(a.B + (b.B - a.B) * t));
        }

        private static GraphicsPath RoundedRect(RectangleF rect, float radius)
        {
            var path = new GraphicsPath();
            float d = Math.Min(radius * 2f, Math.Min(rect.Width, rect.Height));
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        private static StringFormat CreateTypographicFormat()
        {
            var sf = new StringFormat(StringFormat.GenericTypographic);
            sf.FormatFlags |= StringFormatFlags.MeasureTrailingSpaces | StringFormatFlags.NoWrap;
            return sf;
        }

        private static float MeasureTextWidth(Graphics g, string text, Font font, StringFormat sf)
        {
            return g.MeasureString(text, font, PointF.Empty, sf).Width;
        }

        private static GraphicsPath BuildTextPath(FontFamily family, string text, float pixelSize)
        {
            var path = new GraphicsPath();
            path.AddString(text, family, (int)SafeStyle(family), pixelSize, PointF.Empty, StringFormat.GenericTypographic);
            return path;
        }

        // Неоновая панель: свечение, градиентная заливка, двойная рамка
        private static void DrawNeonPanel(Graphics g, RectangleF r, float radius, Color border, float alpha)
        {
            for (int i = 3; i >= 1; i--)
            {
                using (var pen = new Pen(Ac(Color.FromArgb(14 + (4 - i) * 6, border), alpha), 4f + i * 4f) { LineJoin = LineJoin.Round })
                using (var path = RoundedRect(r, radius))
                {
                    g.DrawPath(pen, path);
                }
            }

            using (var path = RoundedRect(r, radius))
            using (var fill = new LinearGradientBrush(r, Ac(Color.FromArgb(240, 8, 20, 70), alpha),
                       Ac(Color.FromArgb(245, 4, 9, 40), alpha), LinearGradientMode.Vertical))
            using (var pen = new Pen(Ac(border, alpha), 4f) { LineJoin = LineJoin.Round })
            {
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
            }

            using (var hiPath = RoundedRect(RectangleF.Inflate(r, -5f, -5f), Math.Max(2f, radius - 4f)))
            using (var hiPen = new Pen(Ac(Color.FromArgb(120, 160, 210, 255), alpha), 1.2f))
            {
                g.DrawPath(hiPen, hiPath);
            }
        }

        // Тёмная "ниша" внутри панели (как на референсе)
        private static void DrawWell(Graphics g, RectangleF r, float radius)
        {
            using (var path = RoundedRect(r, radius))
            using (Brush fill = new SolidBrush(Color.FromArgb(235, 3, 8, 30)))
            using (var pen = new Pen(Color.FromArgb(150, 24, 96, 160), 1.5f))
            {
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
            }
        }

        // Крупный заголовок с градиентом, обводкой и тенью; вписывается в maxW x maxH
        private void DrawTitleText(Graphics g, string text, float cx, float cy, float maxW, float maxH,
            Color top, Color bottom, Color outline, bool shadow, float alpha)
        {
            using (GraphicsPath path = BuildTextPath(titleFamily, text, 100f))
            {
                RectangleF b = path.GetBounds();
                if (b.Width <= 0f || b.Height <= 0f) return;

                float k = MathF.Min(maxW / b.Width, maxH / b.Height);
                using (var m = new Matrix())
                {
                    m.Translate(-(b.X + b.Width / 2f), -(b.Y + b.Height / 2f));
                    m.Scale(k, k, MatrixOrder.Append);
                    m.Translate(cx, cy, MatrixOrder.Append);
                    path.Transform(m);
                }
                RectangleF nb = path.GetBounds();

                if (shadow)
                {
                    using (var shadowPath = (GraphicsPath)path.Clone())
                    using (var sm = new Matrix())
                    using (Brush shadowBrush = new SolidBrush(Ac(Color.FromArgb(200, 0, 0, 30), alpha)))
                    {
                        sm.Translate(3f, 4f);
                        shadowPath.Transform(sm);
                        g.FillPath(shadowBrush, shadowPath);
                    }
                }

                using (var pen = new Pen(Ac(outline, alpha), MathF.Max(3f, k * 9f)) { LineJoin = LineJoin.Round })
                {
                    g.DrawPath(pen, path);
                }
                using (var fill = new LinearGradientBrush(nb, Ac(top, alpha), Ac(bottom, alpha), LinearGradientMode.Vertical))
                {
                    g.FillPath(fill, path);
                }
            }
        }

        // Моноширинный текст с обводкой и мягким свечением, центрируется по (cx, cy)
        private void DrawGlowText(Graphics g, string text, float pixelSize, float cx, float cy,
            Color fill, Color glow, float alpha)
        {
            using (GraphicsPath path = BuildTextPath(monoFamily, text, pixelSize))
            {
                RectangleF b = path.GetBounds();
                using (var m = new Matrix())
                {
                    m.Translate(cx - (b.X + b.Width / 2f), cy - (b.Y + b.Height / 2f));
                    path.Transform(m);
                }

                using (var glowPen = new Pen(Ac(glow, 0.22f * alpha), pixelSize * 0.26f) { LineJoin = LineJoin.Round })
                using (var outline = new Pen(Ac(Color.FromArgb(0, 30, 70), alpha), pixelSize * 0.12f) { LineJoin = LineJoin.Round })
                using (Brush brush = new SolidBrush(Ac(fill, alpha)))
                {
                    g.DrawPath(glowPen, path);
                    g.DrawPath(outline, path);
                    g.FillPath(brush, path);
                }
            }
        }

        // Обычный текст с обводкой (для оверлеев)
        private void DrawOutlinedText(Graphics g, string text, float pixelSize, float cx, float cy,
            Color fill, Color outline, float outlineWidth)
        {
            using (GraphicsPath path = BuildTextPath(monoFamily, text, pixelSize))
            {
                RectangleF b = path.GetBounds();
                using (var m = new Matrix())
                {
                    m.Translate(cx - (b.X + b.Width / 2f), cy - (b.Y + b.Height / 2f));
                    path.Transform(m);
                }

                using (var pen = new Pen(outline, outlineWidth) { LineJoin = LineJoin.Round })
                using (Brush brush = new SolidBrush(fill))
                {
                    g.DrawPath(pen, path);
                    g.FillPath(brush, path);
                }
            }
        }

        private static void DrawLeftText(Graphics g, string text, Font font, Color color, float x, float cy)
        {
            using (StringFormat sf = CreateTypographicFormat())
            using (Brush shadow = new SolidBrush(Color.FromArgb((int)(color.A * 0.6f), 0, 6, 30)))
            using (Brush brush = new SolidBrush(color))
            {
                float y = cy - font.Height / 2f;
                g.DrawString(text, font, shadow, x + 1.5f, y + 1.5f, sf);
                g.DrawString(text, font, brush, x, y, sf);
            }
        }

        private static void DrawCenteredText(Graphics g, string text, Font font, Color color, float cx, float cy)
        {
            using (StringFormat sf = CreateTypographicFormat())
            {
                float w = MeasureTextWidth(g, text, font, sf);
                DrawLeftText(g, text, font, color, cx - w / 2f, cy);
            }
        }

        private static void DrawRightText(Graphics g, string text, Font font, Color color, float rightX, float cy)
        {
            using (StringFormat sf = CreateTypographicFormat())
            {
                float w = MeasureTextWidth(g, text, font, sf);
                DrawLeftText(g, text, font, color, rightX - w, cy);
            }
        }

        // ==========================================================
        //  Объёмные блоки (рисуются один раз в Bitmap)
        // ==========================================================
        private void InitBlockBitmaps()
        {
            for (int i = 0; i < Tetromino.TypeCount; i++)
            {
                blockBig[i] = RenderBlock(Tetromino.Colors[i], Cell);
                blockSmall[i] = RenderBlock(Tetromino.Colors[i], 28);
            }
        }

        private void DisposeBlockBitmaps()
        {
            for (int i = 0; i < Tetromino.TypeCount; i++)
            {
                blockBig[i]?.Dispose();
                blockSmall[i]?.Dispose();
            }
        }

        private static void FillQuad(Graphics g, Color color, PointF a, PointF b, PointF c, PointF d)
        {
            using (Brush brush = new SolidBrush(color))
            {
                g.FillPolygon(brush, new[] { a, b, c, d });
            }
        }

        // Блок с фаской: светлые верх и лево, тёмные низ и право, блик и тёмная окантовка
        private static Bitmap RenderBlock(Color c, int s)
        {
            var bmp = new Bitmap(s, s, PixelFormat.Format32bppPArgb);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;

                float bevel = Math.Max(3f, s * 0.16f);
                float o = 1f; // тёмная окантовка
                float l = o, t = o, r = s - o, bt = s - o;

                using (Brush edge = new SolidBrush(Mix(c, Color.Black, 0.72f)))
                {
                    g.FillRectangle(edge, 0, 0, s, s);
                }

                FillQuad(g, Mix(c, Color.White, 0.55f), new PointF(l, t), new PointF(r, t), new PointF(r - bevel, t + bevel), new PointF(l + bevel, t + bevel));
                FillQuad(g, Mix(c, Color.White, 0.28f), new PointF(l, t), new PointF(l + bevel, t + bevel), new PointF(l + bevel, bt - bevel), new PointF(l, bt));
                FillQuad(g, Mix(c, Color.Black, 0.42f), new PointF(l, bt), new PointF(l + bevel, bt - bevel), new PointF(r - bevel, bt - bevel), new PointF(r, bt));
                FillQuad(g, Mix(c, Color.Black, 0.58f), new PointF(r, t), new PointF(r, bt), new PointF(r - bevel, bt - bevel), new PointF(r - bevel, t + bevel));

                var face = new RectangleF(l + bevel, t + bevel, r - l - 2f * bevel, bt - t - 2f * bevel);
                using (var faceBrush = new LinearGradientBrush(face, Mix(c, Color.White, 0.20f), Mix(c, Color.Black, 0.14f), LinearGradientMode.ForwardDiagonal))
                {
                    g.FillRectangle(faceBrush, face);
                }
                using (Brush glint = new SolidBrush(Color.FromArgb(125, 255, 255, 255)))
                {
                    g.FillRectangle(glint, face.X + 2f, face.Y + 2f, face.Width * 0.45f, Math.Max(2f, face.Height * 0.15f));
                }
            }
            return bmp;
        }

        // ==========================================================
        //  Статический фон: город, панели, лого, управление, рамка поля, футер
        // ==========================================================
        private Bitmap BuildStaticBitmap()
        {
            var bmp = new Bitmap(DesignWidth, DesignHeight, PixelFormat.Format32bppPArgb);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                DrawCity(g);

                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

                DrawLogo(g);
                DrawStatPanels(g);
                DrawControlsPanel(g);
                DrawSidePanels(g);
                DrawFieldFrame(g);
                DrawFooter(g);
            }
            return bmp;
        }

        // ----------------------------------------------------------
        //  Ночной город в стиле пиксель-арта
        // ----------------------------------------------------------
        private static readonly Color[] WindowColors =
        {
            Color.FromArgb(255, 176, 64), Color.FromArgb(255, 96, 170), Color.FromArgb(86, 224, 255),
            Color.FromArgb(255, 240, 150), Color.FromArgb(255, 130, 60)
        };

        private void DrawCity(Graphics g)
        {
            g.SmoothingMode = SmoothingMode.None;
            const int horizon = 600;

            var sky = new Rectangle(0, 0, DesignWidth, horizon);
            using (var brush = new LinearGradientBrush(sky, Color.Black, Color.Black, LinearGradientMode.Vertical))
            {
                brush.InterpolationColors = new ColorBlend
                {
                    Positions = new[] { 0f, 0.5f, 0.8f, 1f },
                    Colors = new[]
                    {
                        Color.FromArgb(4, 5, 30), Color.FromArgb(12, 10, 64),
                        Color.FromArgb(40, 18, 104), Color.FromArgb(96, 34, 128)
                    }
                };
                g.FillRectangle(brush, sky);
            }

            var rnd = new Random(4242);

            // Звёзды
            for (int i = 0; i < 150; i++)
            {
                int x = rnd.Next(DesignWidth);
                int y = rnd.Next(0, 430);
                int size = rnd.Next(12) == 0 ? 3 : 2;
                using (Brush star = new SolidBrush(Color.FromArgb(90 + rnd.Next(150), 200, 220, 255)))
                {
                    g.FillRectangle(star, x, y, size, size);
                }
            }

            var lit = new List<(int X, int Y, Color C)>();
            DrawBuildingLayer(g, rnd, horizon, true, lit);
            DrawBuildingLayer(g, rnd, horizon, false, lit);
            DrawWater(g, rnd, horizon, lit);
        }

        private void DrawBuildingLayer(Graphics g, Random rnd, int horizon, bool far, List<(int X, int Y, Color C)> lit)
        {
            int x = -20;
            while (x < DesignWidth)
            {
                int w = rnd.Next(far ? 36 : 44, far ? 72 : 100);
                float edge = Math.Abs(x + w / 2 - DesignWidth / 2) / (DesignWidth / 2f);
                int maxH = far ? 140 + (int)(130 * edge) : 90 + (int)(260 * edge);
                int h = rnd.Next(50, Math.Max(60, maxH));
                int top = horizon - h;

                Color body = far ? Color.FromArgb(34, 26, 104) : Color.FromArgb(13, 15, 60);
                using (Brush bodyBrush = new SolidBrush(body))
                {
                    g.FillRectangle(bodyBrush, x, top, w, h);
                }
                if (!far)
                {
                    using (Brush hi = new SolidBrush(Color.FromArgb(38, 46, 132)))
                    {
                        g.FillRectangle(hi, x, top, 2, h);
                        g.FillRectangle(hi, x, top, w, 2);
                    }
                }

                if (rnd.Next(100) < 28)
                {
                    int ah = rnd.Next(14, 40);
                    using (Brush antenna = new SolidBrush(body))
                    using (Brush light = new SolidBrush(Color.FromArgb(255, 60, 60)))
                    {
                        g.FillRectangle(antenna, x + w / 2 - 1, top - ah, 2, ah);
                        g.FillRectangle(light, x + w / 2 - 2, top - ah - 3, 4, 4);
                    }
                }

                for (int wy = top + 10; wy < horizon - 8; wy += 12)
                {
                    for (int wx = x + 6; wx < x + w - 8; wx += 10)
                    {
                        if (rnd.Next(100) >= (far ? 22 : 30)) continue;

                        Color c = WindowColors[rnd.Next(WindowColors.Length)];
                        using (Brush wb = new SolidBrush(Color.FromArgb(far ? 140 : 255, c)))
                        {
                            g.FillRectangle(wb, wx, wy, 5, 6);
                        }
                        if (!far && rnd.Next(3) == 0)
                        {
                            lit.Add((wx, wy, c));
                        }
                    }
                }

                x += w + rnd.Next(-6, 8);
            }
        }

        private void DrawWater(Graphics g, Random rnd, int horizon, List<(int X, int Y, Color C)> lit)
        {
            var water = new Rectangle(0, horizon, DesignWidth, DesignHeight - horizon);
            using (var brush = new LinearGradientBrush(water, Color.FromArgb(28, 20, 108), Color.FromArgb(6, 6, 40), LinearGradientMode.Vertical))
            {
                g.FillRectangle(brush, water);
            }
            using (Brush glow = new SolidBrush(Color.FromArgb(120, 170, 80, 190)))
            {
                g.FillRectangle(glow, 0, horizon, DesignWidth, 2);
            }

            // Отражения освещённых окон
            foreach ((int X, int Y, Color C) w in lit)
            {
                int ry = horizon + (int)((horizon - w.Y) * 0.55) + 4;
                int len = rnd.Next(8, 26);
                using (Brush wide = new SolidBrush(Color.FromArgb(40, w.C)))
                using (Brush core = new SolidBrush(Color.FromArgb(120, w.C)))
                {
                    g.FillRectangle(wide, w.X - 1, ry - 2, 7, len + 4);
                    g.FillRectangle(core, w.X, ry, 5, len);
                }
            }

            // Длинные неоновые дорожки на воде
            for (int i = 0; i < 26; i++)
            {
                int x = rnd.Next(DesignWidth);
                Color c = WindowColors[rnd.Next(WindowColors.Length)];
                int y = horizon + 8;
                for (int seg = 0; seg < 12; seg++)
                {
                    int alpha = Math.Max(10, 95 - seg * 7);
                    int len = rnd.Next(6, 14);
                    using (Brush brush = new SolidBrush(Color.FromArgb(alpha, c)))
                    {
                        g.FillRectangle(brush, x, y, 4, len);
                    }
                    y += len + rnd.Next(4, 12);
                }
            }

            // Рябь
            for (int i = 0; i < 90; i++)
            {
                int x = rnd.Next(DesignWidth);
                int y = horizon + rnd.Next(4, 280);
                int w = rnd.Next(20, 90);
                bool light = rnd.Next(2) == 0;
                using (Brush brush = new SolidBrush(light ? Color.FromArgb(40, 120, 150, 255) : Color.FromArgb(110, 4, 4, 28)))
                {
                    g.FillRectangle(brush, x, y, w, 2);
                }
            }
        }

        // ----------------------------------------------------------
        //  Лого
        // ----------------------------------------------------------
        private void DrawLogo(Graphics g)
        {
            DrawNeonPanel(g, LogoRect, 14f, NeonBlue, 1f);
            DrawTitleText(g, "2D-TETRIS", LogoRect.X + LogoRect.Width / 2f, LogoRect.Y + LogoRect.Height / 2f,
                266f, 62f, Color.FromArgb(255, 232, 60), Color.FromArgb(255, 100, 20), Color.FromArgb(150, 25, 40), true, 1f);
        }

        // ----------------------------------------------------------
        //  Панели SCORE / LINES / LEVEL (рамки и подписи)
        // ----------------------------------------------------------
        private void DrawStatPanels(Graphics g)
        {
            DrawNeonPanel(g, ScoreRect, 14f, NeonBlue, 1f);
            DrawWell(g, RectangleF.Inflate(ScoreRect, -12f, -12f), 10f);
            DrawLeftText(g, "SCORE", fontLabel, LabelColor, ScoreRect.X + 26f, ScoreRect.Y + 30f);

            DrawNeonPanel(g, LinesRect, 14f, NeonBlue, 1f);
            DrawWell(g, RectangleF.Inflate(LinesRect, -12f, -12f), 10f);
            DrawLeftText(g, "LINES", fontLabel, LabelColor, LinesRect.X + 26f, LinesRect.Y + 28f);

            DrawNeonPanel(g, LevelRect, 14f, NeonBlue, 1f);
            DrawWell(g, RectangleF.Inflate(LevelRect, -12f, -12f), 10f);
            DrawLeftText(g, "LEVEL", fontLabel, LabelColor, LevelRect.X + 26f, LevelRect.Y + 28f);
        }

        // ----------------------------------------------------------
        //  Панель CONTROLS с клавишами
        // ----------------------------------------------------------
        private void DrawControlsPanel(Graphics g)
        {
            RectangleF r = ControlsRect;
            DrawNeonPanel(g, r, 14f, NeonBlue, 1f);
            DrawWell(g, RectangleF.Inflate(r, -12f, -12f), 10f);

            DrawLeftText(g, "CONTROLS:", fontLabel, Color.FromArgb(120, 235, 255), r.X + 26f, r.Y + 30f);

            float y = r.Y + 62f;
            const float step = 31f;
            float capLeft = r.X + 24f;
            float textX = r.X + 134f;

            // 1: ← →
            DrawArrowCap(g, capLeft + 16f, y, 0);
            DrawArrowCap(g, capLeft + 54f, y, 1);
            DrawLeftText(g, "Move  (A / D)", fontSmall, LabelColor, textX, y);
            y += step;

            // 2: ↓
            DrawArrowCap(g, capLeft + 16f, y, 3);
            DrawLeftText(g, "Soft drop  (S)", fontSmall, LabelColor, textX, y);
            y += step;

            // 3: ↑
            DrawArrowCap(g, capLeft + 16f, y, 2);
            DrawLeftText(g, "Rotate  (W)", fontSmall, LabelColor, textX, y);
            y += step;

            // 4: SPACE
            DrawTextCap(g, capLeft + 50f, y, 100f, "SPACE");
            DrawLeftText(g, "Hard drop", fontSmall, LabelColor, textX + 16f, y);
            y += step;

            DrawTextCap(g, capLeft + 16f, y, 32f, "C");
            DrawLeftText(g, "Hold  (or Shift)", fontSmall, LabelColor, textX, y);
            y += step;

            DrawTextCap(g, capLeft + 16f, y, 32f, "P");
            DrawLeftText(g, "Pause / resume", fontSmall, LabelColor, textX, y);
            y += step;

            DrawTextCap(g, capLeft + 16f, y, 32f, "R");
            DrawLeftText(g, "Restart", fontSmall, LabelColor, textX, y);
            y += step;

            DrawTextCap(g, capLeft + 16f, y, 32f, "M");
            DrawLeftText(g, "Sound on / off", fontSmall, LabelColor, textX, y);
            y += step;

            DrawTextCap(g, capLeft + 22f, y, 44f, "ESC");
            DrawLeftText(g, "Menu / exit", fontSmall, LabelColor, textX, y);
        }

        private void DrawCapBase(Graphics g, float cx, float cy, float w)
        {
            var rect = new RectangleF(cx - w / 2f, cy - 13f, w, 26f);
            using (var path = RoundedRect(rect, 6f))
            using (var fill = new LinearGradientBrush(rect, Color.FromArgb(34, 70, 160), Color.FromArgb(10, 24, 80), LinearGradientMode.Vertical))
            using (var pen = new Pen(Color.FromArgb(120, 190, 255), 1.8f))
            {
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
            }
        }

        private void DrawTextCap(Graphics g, float cx, float cy, float w, string label)
        {
            DrawCapBase(g, cx, cy, w);
            DrawCenteredText(g, label, fontSmall, Color.White, cx, cy);
        }

        // dir: 0 — влево, 1 — вправо, 2 — вверх, 3 — вниз
        private void DrawArrowCap(Graphics g, float cx, float cy, int dir)
        {
            DrawCapBase(g, cx, cy, 32f);

            PointF[] head;
            RectangleF stem;
            switch (dir)
            {
                case 0:
                    head = new[] { new PointF(cx - 9f, cy), new PointF(cx - 1f, cy - 7f), new PointF(cx - 1f, cy + 7f) };
                    stem = new RectangleF(cx - 2f, cy - 2.5f, 11f, 5f);
                    break;
                case 1:
                    head = new[] { new PointF(cx + 9f, cy), new PointF(cx + 1f, cy - 7f), new PointF(cx + 1f, cy + 7f) };
                    stem = new RectangleF(cx - 9f, cy - 2.5f, 11f, 5f);
                    break;
                case 2:
                    head = new[] { new PointF(cx, cy - 9f), new PointF(cx - 7f, cy - 1f), new PointF(cx + 7f, cy - 1f) };
                    stem = new RectangleF(cx - 2.5f, cy - 2f, 5f, 11f);
                    break;
                default:
                    head = new[] { new PointF(cx, cy + 9f), new PointF(cx - 7f, cy + 1f), new PointF(cx + 7f, cy + 1f) };
                    stem = new RectangleF(cx - 2.5f, cy - 9f, 5f, 11f);
                    break;
            }

            using (Brush brush = new SolidBrush(Color.White))
            {
                g.FillPolygon(brush, head);
                g.FillRectangle(brush, stem);
            }
        }

        // ----------------------------------------------------------
        //  Правая колонка: HOLD, NEXT, подсказка
        // ----------------------------------------------------------
        private void DrawSidePanels(Graphics g)
        {
            DrawNeonPanel(g, HoldRect, 14f, NeonBlue, 1f);
            DrawCenteredText(g, "HOLD", fontLabel, Color.FromArgb(120, 235, 255), HoldRect.X + HoldRect.Width / 2f, HoldRect.Y + 30f);
            DrawWell(g, HoldWell, 10f);

            DrawNeonPanel(g, NextRect, 14f, NeonBlue, 1f);
            DrawCenteredText(g, "NEXT", fontLabel, Color.FromArgb(120, 235, 255), NextRect.X + NextRect.Width / 2f, NextRect.Y + 30f);
            DrawWell(g, NextWell, 10f);

            DrawNeonPanel(g, HintRect, 14f, NeonBlue, 1f);
            DrawWell(g, RectangleF.Inflate(HintRect, -12f, -12f), 10f);
        }

        // ----------------------------------------------------------
        //  Неоновая рамка и сетка игрового поля
        // ----------------------------------------------------------
        private void DrawFieldFrame(Graphics g)
        {
            var fieldRect = new RectangleF(FieldX, FieldY, FieldW, FieldH);

            // Тёмная подложка под рамкой
            using (var path = RoundedRect(FieldFrame, 16f))
            using (Brush back = new SolidBrush(Color.FromArgb(250, 3, 8, 30)))
            {
                g.FillPath(back, path);
            }

            // Фон поля
            using (var fill = new LinearGradientBrush(fieldRect, Color.FromArgb(6, 14, 44), Color.FromArgb(3, 8, 30), LinearGradientMode.Vertical))
            {
                g.FillRectangle(fill, fieldRect);
            }

            // Сетка
            using (Brush gridBrush = new SolidBrush(Color.FromArgb(150, 18, 82, 124)))
            {
                for (int i = 0; i <= Board.Width; i++)
                {
                    g.FillRectangle(gridBrush, FieldX + i * Cell - (i == Board.Width ? 1f : 0f), FieldY, 1f, FieldH);
                }
                for (int j = 0; j <= Board.VisibleHeight; j++)
                {
                    g.FillRectangle(gridBrush, FieldX, FieldY + j * Cell - (j == Board.VisibleHeight ? 1f : 0f), FieldW, 1f);
                }
            }

            // Неоновая рамка
            for (int i = 4; i >= 1; i--)
            {
                using (var glowPen = new Pen(Color.FromArgb(14 + (5 - i) * 5, NeonBlue), 6f + i * 6f) { LineJoin = LineJoin.Round })
                using (var glowPath = RoundedRect(FieldFrame, 16f))
                {
                    g.DrawPath(glowPen, glowPath);
                }
            }
            using (var mainPen = new Pen(NeonBlue, 7f) { LineJoin = LineJoin.Round })
            using (var mainPath = RoundedRect(FieldFrame, 16f))
            {
                g.DrawPath(mainPen, mainPath);
            }
            using (var hiPen = new Pen(Color.FromArgb(190, 150, 225, 255), 1.6f) { LineJoin = LineJoin.Round })
            using (var hiPath = RoundedRect(RectangleF.Inflate(FieldFrame, -5f, -5f), 12f))
            {
                g.DrawPath(hiPen, hiPath);
            }
        }

        // ----------------------------------------------------------
        //  Футер с авторской подписью
        // ----------------------------------------------------------
        private void DrawFooter(Graphics g)
        {
            const float top = 868f;
            using (Brush band = new SolidBrush(Color.FromArgb(4, 8, 28)))
            using (Brush neon = new SolidBrush(Color.FromArgb(40, 130, 255)))
            {
                g.FillRectangle(band, 0f, top, DesignWidth, DesignHeight - top);
                g.FillRectangle(neon, 0f, top, DesignWidth, 2f);
            }

            const string before = "© 2026 Андрей Орлов (совместно с Claude AI). Сайт: ";
            const string site = "orlovandrei.space";

            using (StringFormat sf = CreateTypographicFormat())
            {
                Font font = fontFooter;
                bool ownsFont = false;

                float w1 = MeasureTextWidth(g, before, font, sf);
                float w2 = MeasureTextWidth(g, site, font, sf);
                float maxWidth = DesignWidth - 40f;

                // Если подпись не помещается — уменьшаем шрифт, чтобы она была видна целиком
                if (w1 + w2 > maxWidth)
                {
                    float k = maxWidth / (w1 + w2);
                    font = new Font(fontFooter.FontFamily, fontFooter.Size * k, fontFooter.Style, GraphicsUnit.Pixel);
                    ownsFont = true;
                    w1 = MeasureTextWidth(g, before, font, sf);
                    w2 = MeasureTextWidth(g, site, font, sf);
                }

                float x = (DesignWidth - (w1 + w2)) / 2f;
                float y = top + 2f + (DesignHeight - top - 2f - font.Height) / 2f;

                using (Brush white = new SolidBrush(Color.FromArgb(235, 240, 250)))
                using (Brush green = new SolidBrush(Color.FromArgb(70, 235, 50)))
                {
                    g.DrawString(before, font, white, x, y, sf);
                    g.DrawString(site, font, green, x + w1, y, sf);
                }

                if (ownsFont) font.Dispose();
            }
        }
    }
}
