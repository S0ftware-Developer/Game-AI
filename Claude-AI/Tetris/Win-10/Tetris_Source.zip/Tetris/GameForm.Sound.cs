using System;
using System.Collections.Generic;
using System.IO;
using System.Media;

namespace Tetris
{
    public partial class GameForm
    {
        private SoundPlayer? sndMove;
        private SoundPlayer? sndRotate;
        private SoundPlayer? sndHold;
        private SoundPlayer? sndLand;
        private SoundPlayer? sndHardDrop;
        private SoundPlayer? sndLine;
        private SoundPlayer? sndTetris;
        private SoundPlayer? sndLevelUp;
        private SoundPlayer? sndGameOver;
        private SoundPlayer? sndStart;
        private SoundPlayer? sndPause;

        private bool soundEnabled = true;

        // SoundPlayer проигрывает один звук за раз: новый звук обрывает предыдущий.
        // Чтобы короткие звуки движения не обрывали важные (линии, уровень, game over),
        // у каждого звука есть приоритет.
        private long soundBusyUntilMs;
        private int soundBusyPriority;

        // Все звуки генерируются кодом (квадратная волна, как в аркадных автоматах).
        // Если звуковая подсистема недоступна — игра просто работает без звука.
        private void InitSounds()
        {
            try
            {
                sndMove = CreateSound(new[] { (700.0, 18) }, 0.14);
                sndRotate = CreateSound(new[] { (820.0, 22), (1020.0, 22) }, 0.16);
                sndHold = CreateSound(new[] { (500.0, 55), (720.0, 55) }, 0.20);
                sndLand = CreateSound(new[] { (170.0, 55) }, 0.30);
                sndHardDrop = CreateSound(new[] { (130.0, 40), (80.0, 60) }, 0.34);
                sndLine = CreateSound(new[] { (620.0, 50), (820.0, 50), (1040.0, 90) }, 0.28);
                sndTetris = CreateSound(new[] { (523.0, 70), (659.0, 70), (784.0, 70), (1047.0, 70), (1319.0, 220) }, 0.30);
                sndLevelUp = CreateSound(new[] { (523.0, 80), (659.0, 80), (784.0, 80), (1047.0, 80), (784.0, 60), (1047.0, 200) }, 0.28);
                sndGameOver = CreateSound(new[] { (392.0, 150), (330.0, 150), (262.0, 150), (196.0, 420) }, 0.30);
                sndStart = CreateSound(new[] { (440.0, 60), (660.0, 110) }, 0.26);
                sndPause = CreateSound(new[] { (600.0, 40), (450.0, 50) }, 0.22);
            }
            catch (Exception)
            {
                sndMove = sndRotate = sndHold = sndLand = sndHardDrop = null;
                sndLine = sndTetris = sndLevelUp = sndGameOver = sndStart = sndPause = null;
            }
        }

        private void Play(SoundPlayer? player, int priority, int durationMs)
        {
            if (!soundEnabled || player == null) return;

            long now = stopwatch.ElapsedMilliseconds;
            if (now < soundBusyUntilMs && priority < soundBusyPriority)
            {
                return; // сейчас звучит более важный звук
            }

            try
            {
                player.Play(); // асинхронно, не блокирует игровой цикл
                soundBusyUntilMs = now + durationMs;
                soundBusyPriority = priority;
            }
            catch (Exception)
            {
                // звук не критичен для игры
            }
        }

        private void DisposeSounds()
        {
            sndMove?.Dispose();
            sndRotate?.Dispose();
            sndHold?.Dispose();
            sndLand?.Dispose();
            sndHardDrop?.Dispose();
            sndLine?.Dispose();
            sndTetris?.Dispose();
            sndLevelUp?.Dispose();
            sndGameOver?.Dispose();
            sndStart?.Dispose();
            sndPause?.Dispose();
        }

        // Собирает WAV (16 бит, моно, 22050 Гц) из последовательности нот (частота Гц, длительность мс)
        private static SoundPlayer CreateSound((double Freq, int Ms)[] notes, double volume)
        {
            const int sampleRate = 22050;
            var samples = new List<short>();

            foreach (var note in notes)
            {
                int count = sampleRate * note.Ms / 1000;
                for (int i = 0; i < count; i++)
                {
                    double t = i / (double)sampleRate;
                    double attack = Math.Min(1.0, i / (sampleRate * 0.004));
                    double release = Math.Min(1.0, (count - i) / (sampleRate * 0.015));
                    double env = attack * release;

                    double sine = Math.Sin(2.0 * Math.PI * note.Freq * t);
                    double square = sine >= 0 ? 1.0 : -1.0;
                    double v = (0.65 * square + 0.35 * sine) * env * volume;

                    samples.Add((short)(v * short.MaxValue));
                }
            }

            int dataLength = samples.Count * 2;
            var stream = new MemoryStream();
            using (var writer = new BinaryWriter(stream, System.Text.Encoding.ASCII, true))
            {
                writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
                writer.Write(36 + dataLength);
                writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"));
                writer.Write(System.Text.Encoding.ASCII.GetBytes("fmt "));
                writer.Write(16);                 // размер блока fmt
                writer.Write((short)1);           // PCM
                writer.Write((short)1);           // моно
                writer.Write(sampleRate);
                writer.Write(sampleRate * 2);     // байт в секунду
                writer.Write((short)2);           // выравнивание блока
                writer.Write((short)16);          // бит на сэмпл
                writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));
                writer.Write(dataLength);
                foreach (short s in samples)
                {
                    writer.Write(s);
                }
            }

            stream.Position = 0;
            var player = new SoundPlayer(stream);
            player.Load();
            return player;
        }
    }
}
