using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace BreakoutReborn
{
    // Цвет строки кирпичей и связанная с ним ценность в очках
    public enum BrickColorType
    {
        Yellow,  // нижние строки — 1 очко
        Green,   // 3 очка
        Orange,  // 5 очков
        Red      // верхние строки — 7 очков
    }

    // Один кирпич игрового поля
    public class Brick
    {
        public float X;
        public float Y;
        public float Width;
        public float Height;
        public BrickColorType ColorType;
        public bool IsAlive;
    }

    // Главное окно игры — клон аркады Breakout (1976)
    public class GameForm : Form
    {
        // ==========================================================
        //  Константы игрового поля
        // ==========================================================
        private const int FieldWidth = 900;
        private const int FieldHeight = 650;

        // ==========================================================
        //  Параметры ракетки
        // ==========================================================
        private const float PaddleFullWidth = 60f;
        private const float PaddleShrunkWidth = 30f; // ракетка укорачивается в 2 раза
        private const int PaddleHeight = 12;
        private const int PaddleBottomMargin = 30;
        private const float PaddleSpeed = 5.33f; // пикселей за один тик таймера

        private float paddleWidth;
        private float paddleX;
        private int paddleY;
        private bool paddleShrunkThisLife;

        // ==========================================================
        //  Параметры мяча (круг; хитбокс — квадратная область BallSize x BallSize)
        // ==========================================================
        private const int BallSize = 14;

        private float ballX;
        private float ballY;
        private float prevBallX;
        private float prevBallY;
        private float ballVX;
        private float ballVY;

        // Уровни скорости мяча. Индекс может только расти, никогда не уменьшается
        // в рамках одной "жизни" мяча — так вело себя оригинальное аркадное железо.
        private static readonly float[] SpeedLevels = { 4.5f, 5.5f, 6.0f, 6.5f, 7.5f };
        private int speedLevelIndex;

        // Счётчики событий текущего мяча (сбрасываются при потере мяча и на новом экране)
        private int hitsThisLife;
        private bool orangeHitThisLife;
        private bool redHitThisLife;

        // ==========================================================
        //  Параметры сетки кирпичей
        // ==========================================================
        private const int BrickRows = 8;
        private const int BrickCols = 14;
        private const float BrickAreaLeft = 40f;
        private const float BrickAreaRight = FieldWidth - 40f;
        private const float BrickAreaTop = 80f;
        private const float BrickHeight = 18f;
        private const float BrickGapX = 3f;
        private const float BrickGapY = 4f;

        private readonly List<Brick> bricks = new List<Brick>();

        // ==========================================================
        //  Общее состояние игры
        // ==========================================================
        private int score;
        private int lives;
        private int screenNumber;      // 1 или 2 — номер текущего экрана кирпичей
        private bool screensCompleted; // оба экрана пройдены, кирпичей больше нет
        private bool isGameOver;

        private bool leftPressed;
        private bool rightPressed;

        private readonly System.Windows.Forms.Timer gameTimer;

        private readonly Font hudFont;
        private readonly Font titleFont;
        private readonly Font subtitleFont;
        private readonly Font copyrightFont;

        private const string CopyrightText =
            "© 2026 [Орлов Андрей (совместно с Claude AI)]. Сайт: orlovandrei.space. Все права защищены.";

        public GameForm()
        {
            this.Text = "Breakout Reborn (2026 by Claude AI)";
            this.ClientSize = new Size(FieldWidth, FieldHeight);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Black;
            this.KeyPreview = true;

            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer,
                true);

            hudFont = new Font("Consolas", 14f, FontStyle.Bold);
            titleFont = new Font("Consolas", 28f, FontStyle.Bold);
            subtitleFont = new Font("Consolas", 16f, FontStyle.Regular);
            copyrightFont = new Font("Consolas", 10f, FontStyle.Regular);

            this.KeyDown += GameForm_KeyDown;
            this.KeyUp += GameForm_KeyUp;
            this.Paint += GameForm_Paint;

            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 16; // примерно 60 кадров в секунду
            gameTimer.Tick += GameTimer_Tick;

            InitializeGame();

            gameTimer.Start();
        }

        // ==========================================================
        //  Полный запуск / перезапуск игры
        // ==========================================================
        private void InitializeGame()
        {
            score = 0;
            lives = 3;
            screenNumber = 1;
            screensCompleted = false;
            isGameOver = false;

            BuildBrickGrid();
            ResetBallAndPaddleForNewLife();
        }

        // --- Создание полного набора кирпичей для текущего экрана ---
        private void BuildBrickGrid()
        {
            bricks.Clear();

            float totalGapWidth = (BrickCols - 1) * BrickGapX;
            float brickWidth = (BrickAreaRight - BrickAreaLeft - totalGapWidth) / BrickCols;

            for (int row = 0; row < BrickRows; row++)
            {
                BrickColorType colorType = GetColorForRow(row);
                float y = BrickAreaTop + row * (BrickHeight + BrickGapY);

                for (int col = 0; col < BrickCols; col++)
                {
                    float x = BrickAreaLeft + col * (brickWidth + BrickGapX);

                    bricks.Add(new Brick
                    {
                        X = x,
                        Y = y,
                        Width = brickWidth,
                        Height = BrickHeight,
                        ColorType = colorType,
                        IsAlive = true
                    });
                }
            }
        }

        // --- Верхние 2 строки — красные, затем оранжевые, зелёные, жёлтые внизу ---
        private static BrickColorType GetColorForRow(int row)
        {
            if (row < 2) return BrickColorType.Red;
            if (row < 4) return BrickColorType.Orange;
            if (row < 6) return BrickColorType.Green;
            return BrickColorType.Yellow;
        }

        private static int GetPointsForColor(BrickColorType colorType)
        {
            switch (colorType)
            {
                case BrickColorType.Red: return 7;
                case BrickColorType.Orange: return 5;
                case BrickColorType.Green: return 3;
                default: return 1; // Yellow
            }
        }

        private static Color GetDisplayColor(BrickColorType colorType)
        {
            switch (colorType)
            {
                case BrickColorType.Red: return Color.Red;
                case BrickColorType.Orange: return Color.Orange;
                case BrickColorType.Green: return Color.LimeGreen;
                default: return Color.Yellow;
            }
        }

        // --- Подготовка нового мяча: после потери мяча или в начале нового экрана ---
        private void ResetBallAndPaddleForNewLife()
        {
            paddleWidth = PaddleFullWidth;
            paddleShrunkThisLife = false;
            paddleX = (FieldWidth - paddleWidth) / 2f;
            paddleY = FieldHeight - PaddleHeight - PaddleBottomMargin;

            ballX = (FieldWidth - BallSize) / 2f;
            ballY = paddleY - 150f;
            prevBallX = ballX;
            prevBallY = ballY;

            speedLevelIndex = 0;
            hitsThisLife = 0;
            orangeHitThisLife = false;
            redHitThisLife = false;

            ballVX = 0f;
            ballVY = SpeedLevels[speedLevelIndex];

            leftPressed = false;
            rightPressed = false;
        }

        private void RestartGame()
        {
            InitializeGame();
        }

        // ==========================================================
        //  Ввод с клавиатуры
        // ==========================================================
        private void GameForm_KeyDown(object? sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.A:
                    leftPressed = true;
                    break;

                case Keys.Right:
                case Keys.D:
                    rightPressed = true;
                    break;

                case Keys.R:
                    if (isGameOver)
                    {
                        RestartGame();
                    }
                    break;

                case Keys.Escape:
                    this.Close();
                    break;
            }

            e.Handled = true;
            e.SuppressKeyPress = true;
        }

        private void GameForm_KeyUp(object? sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.A:
                    leftPressed = false;
                    break;

                case Keys.Right:
                case Keys.D:
                    rightPressed = false;
                    break;
            }
        }

        // ==========================================================
        //  Главный игровой цикл
        // ==========================================================
        private void GameTimer_Tick(object? sender, EventArgs e)
        {
            if (!isGameOver)
            {
                UpdateGame();
            }
            this.Invalidate();
        }

        private void UpdateGame()
        {
            HandlePaddleInput();
            MoveBall();
            CheckWallCollisions();
            CheckBrickCollisions();
            CheckPaddleCollision();
            CheckBallLost();
        }

        // --- Обработка ввода: перемещение ракетки ---
        private void HandlePaddleInput()
        {
            if (leftPressed) paddleX -= PaddleSpeed;
            if (rightPressed) paddleX += PaddleSpeed;

            if (paddleX < 0f) paddleX = 0f;
            if (paddleX + paddleWidth > FieldWidth) paddleX = FieldWidth - paddleWidth;
        }

        // --- Перемещение мяча ---
        private void MoveBall()
        {
            prevBallX = ballX;
            prevBallY = ballY;
            ballX += ballVX;
            ballY += ballVY;
        }

        // --- Столкновения с левой, правой и верхней стенками ---
        private void CheckWallCollisions()
        {
            if (ballX <= 0f)
            {
                ballX = 0f;
                ballVX = -ballVX;
            }
            if (ballX + BallSize >= FieldWidth)
            {
                ballX = FieldWidth - BallSize;
                ballVX = -ballVX;
            }

            if (ballY <= 0f)
            {
                ballY = 0f;
                ballVY = -ballVY;

                // Ракетка укорачивается один раз за мяч, если мяч уже пробил
                // красную строку и после этого долетел до самого верха поля.
                if (redHitThisLife && !paddleShrunkThisLife)
                {
                    paddleShrunkThisLife = true;
                    paddleWidth = PaddleShrunkWidth;

                    if (paddleX + paddleWidth > FieldWidth)
                    {
                        paddleX = FieldWidth - paddleWidth;
                    }
                }
            }
        }

        // --- Столкновения мяча с кирпичами ---
        private void CheckBrickCollisions()
        {
            for (int i = 0; i < bricks.Count; i++)
            {
                Brick brick = bricks[i];
                if (!brick.IsAlive) continue;

                bool overlapsX = ballX + BallSize > brick.X && ballX < brick.X + brick.Width;
                bool overlapsY = ballY + BallSize > brick.Y && ballY < brick.Y + brick.Height;

                if (!(overlapsX && overlapsY)) continue;

                // Определяем сторону удара по положению мяча в предыдущем кадре
                bool cameFromAbove = prevBallY + BallSize <= brick.Y;
                bool cameFromBelow = prevBallY >= brick.Y + brick.Height;

                if (cameFromAbove || cameFromBelow)
                {
                    ballVY = -ballVY;
                }
                else
                {
                    ballVX = -ballVX;
                }

                brick.IsAlive = false;
                score += GetPointsForColor(brick.ColorType);
                hitsThisLife++;

                RegisterBrickHitEvents(brick.ColorType);

                // За один кадр разрушаем только один кирпич — этого достаточно
                // для простой и надёжной физики при обычных скоростях мяча.
                break;
            }

            if (AllBricksDestroyed())
            {
                AdvanceToNextScreen();
            }
        }

        // --- События увеличения скорости после ударов по кирпичам ---
        private void RegisterBrickHitEvents(BrickColorType colorType)
        {
            if (colorType == BrickColorType.Orange && !orangeHitThisLife)
            {
                orangeHitThisLife = true;
                RaiseSpeedLevel(3);
            }

            if (colorType == BrickColorType.Red && !redHitThisLife)
            {
                redHitThisLife = true;
                RaiseSpeedLevel(4);
            }

            if (hitsThisLife == 4)
            {
                RaiseSpeedLevel(1);
            }
            if (hitsThisLife == 12)
            {
                RaiseSpeedLevel(2);
            }
        }

        // --- Скорость мяча может только увеличиваться в рамках одной жизни ---
        private void RaiseSpeedLevel(int newLevelIndex)
        {
            if (newLevelIndex <= speedLevelIndex) return;

            speedLevelIndex = newLevelIndex;
            float targetSpeed = SpeedLevels[speedLevelIndex];

            float currentSpeed = (float)Math.Sqrt(ballVX * ballVX + ballVY * ballVY);
            if (currentSpeed < 0.0001f)
            {
                ballVX = 0f;
                ballVY = -targetSpeed;
                return;
            }

            float scale = targetSpeed / currentSpeed;
            ballVX *= scale;
            ballVY *= scale;
        }

        private bool AllBricksDestroyed()
        {
            for (int i = 0; i < bricks.Count; i++)
            {
                if (bricks[i].IsAlive) return false;
            }
            return true;
        }

        // --- Переход между экранами кирпичей (всего два экрана) ---
        private void AdvanceToNextScreen()
        {
            if (screenNumber == 1)
            {
                screenNumber = 2;
                BuildBrickGrid();
                ResetBallAndPaddleForNewLife();
            }
            else
            {
                // Второй экран тоже пройден: кирпичей больше нет. Мяч и ракетка
                // продолжают работать как обычно (отскок от пустых стен),
                // но новых очков уже не начисляется — счёт естественным
                // образом останавливается на максимуме в 896.
                screensCompleted = true;
                bricks.Clear();
            }
        }

        // --- Столкновение мяча с ракеткой ---
        private void CheckPaddleCollision()
        {
            float ballBottomPrev = prevBallY + BallSize;
            float ballBottomNow = ballY + BallSize;

            bool horizontallyOverPaddle =
                (ballX + BallSize >= paddleX) &&
                (ballX <= paddleX + paddleWidth);

            bool crossedPaddleTop =
                ballVY > 0f &&
                ballBottomPrev <= paddleY &&
                ballBottomNow >= paddleY;

            if (crossedPaddleTop && horizontallyOverPaddle)
            {
                ballY = paddleY - BallSize;

                // Точка попадания относительно центра ракетки: от -1 до 1
                float paddleCenter = paddleX + paddleWidth / 2f;
                float ballCenter = ballX + BallSize / 2f;
                float hitOffset = (ballCenter - paddleCenter) / (paddleWidth / 2f);

                if (hitOffset < -1f) hitOffset = -1f;
                if (hitOffset > 1f) hitOffset = 1f;

                // Скорость на отражении определяется текущим уровнем скорости мяча,
                // а не увеличивается от самого факта удара о ракетку.
                float speed = SpeedLevels[speedLevelIndex];
                const float maxHorizontalRatio = 0.8f;

                float newVX = speed * maxHorizontalRatio * hitOffset;
                float newVYSquared = speed * speed - newVX * newVX;
                float minVYSquared = speed * speed * 0.2f;
                float newVY = -(float)Math.Sqrt(Math.Max(newVYSquared, minVYSquared));

                ballVX = newVX;
                ballVY = newVY;
            }
        }

        // --- Проверка потери мяча (улетел ниже нижней границы) ---
        private void CheckBallLost()
        {
            if (ballY > FieldHeight)
            {
                lives--;

                if (lives > 0)
                {
                    ResetBallAndPaddleForNewLife();
                }
                else
                {
                    isGameOver = true;
                }
            }
        }

        // ==========================================================
        //  Отрисовка игры
        // ==========================================================
        private void GameForm_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.Black);

            using (Brush whiteBrush = new SolidBrush(Color.White))
            {
                DrawBricks(g);

                // Ракетка (голубая)
                using (Brush paddleBrush = new SolidBrush(Color.DeepSkyBlue))
                {
                    g.FillRectangle(paddleBrush, paddleX, paddleY, paddleWidth, PaddleHeight);
                }

                // Мяч (круг)
                g.FillEllipse(whiteBrush, ballX, ballY, BallSize, BallSize);

                // Мячи слева, счёт справа
                g.DrawString($"Мячи: {lives}", hudFont, whiteBrush, 15f, 15f);

                string scoreText = $"Счёт: {score}";
                SizeF scoreSize = g.MeasureString(scoreText, hudFont);
                g.DrawString(scoreText, hudFont, whiteBrush, FieldWidth - scoreSize.Width - 15f, 15f);

                // Строка авторства внизу окна
                SizeF copyrightSize = g.MeasureString(CopyrightText, copyrightFont);
                g.DrawString(
                    CopyrightText,
                    copyrightFont,
                    whiteBrush,
                    (FieldWidth - copyrightSize.Width) / 2f,
                    FieldHeight - copyrightSize.Height - 8f);

                if (isGameOver)
                {
                    DrawGameOverText(g, whiteBrush);
                }
            }
        }

        private void DrawBricks(Graphics g)
        {
            foreach (Brick brick in bricks)
            {
                if (!brick.IsAlive) continue;

                using (Brush brickBrush = new SolidBrush(GetDisplayColor(brick.ColorType)))
                {
                    g.FillRectangle(brickBrush, brick.X, brick.Y, brick.Width, brick.Height);
                }
            }
        }

        private void DrawGameOverText(Graphics g, Brush brush)
        {
            string title = "Игра окончена";
            string scoreLine = $"Счёт: {score}";
            string restartLine = "Нажмите R для новой игры";

            SizeF titleSize = g.MeasureString(title, titleFont);
            SizeF scoreSize = g.MeasureString(scoreLine, subtitleFont);
            SizeF restartSize = g.MeasureString(restartLine, subtitleFont);

            float centerX = FieldWidth / 2f;
            float centerY = FieldHeight / 2f;

            float titleY = centerY - titleSize.Height - 10f;
            float scoreY = centerY + 10f;
            float restartY = scoreY + scoreSize.Height + 10f;

            g.DrawString(title, titleFont, brush, centerX - titleSize.Width / 2f, titleY);
            g.DrawString(scoreLine, subtitleFont, brush, centerX - scoreSize.Width / 2f, scoreY);
            g.DrawString(restartLine, subtitleFont, brush, centerX - restartSize.Width / 2f, restartY);
        }

        // ==========================================================
        //  Освобождение ресурсов при закрытии формы
        // ==========================================================
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                gameTimer?.Stop();
                gameTimer?.Dispose();
                hudFont?.Dispose();
                titleFont?.Dispose();
                subtitleFont?.Dispose();
                copyrightFont?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
